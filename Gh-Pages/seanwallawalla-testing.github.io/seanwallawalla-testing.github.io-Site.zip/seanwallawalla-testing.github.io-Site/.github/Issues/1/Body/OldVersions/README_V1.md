***

### Build failing 1: sub-dropdown is not functional

I am writing this so others don't have to point it out: build V1 is currently failing due to bad syntax with the sub-dropdown menu.

Issues:

- [ ] Sub-dropdown caused a syntax failure

- [ ] Language list is garbled

I am still working on a fix for this, this may take a while. Please point it out if I take too long or get sidetracked for over a week. This isn't the most active of a project at the moment.

Seanpm2001 - Tuesday, June 22nd 2021 at 4:30 pm

***
