// Start of script
// I chose Rust as the project language for this project (SeansLifeArchive_Images-Mozilla-firefox) as Firefox is notably mostly written in Rust, and I don't have very many projects written in this language.

fn main() {
    println!("I chose Rust as the project language for this project (SeansLifeArchive_Images-Mozilla-firefox) as Firefox is notably mostly written in Rust, and I don't have very many projects written in this language.");
    break;
}
return main();
break;

// File info
// File version: 1 (Thursday, June 3rd 2021 at 7:05 pm)
// File type: Rust Source file (*.rs)
// Line count (including blank lines and compiler line): 17

// End of script
