# SNU_0DMode
The 0 Dimensional joke mode for SNU, the missing dimension.

---

# About

SNU 0D mode is a 0 dimensional filler mode of SNU that doesn't accept content, since content can't be made in 0 dimensions (unless it is a single point or a line)

It is a filler mode that tells you why a 0 dimensional mode isn't that good of a thing.

---

# Contributers

Currently, I am the only contributer, and there really isn't that much to do here.

> * 1. [seanpm2001](https://github.com/seanpm2001/) - 10 commits (As of Sunday, May 31st 2020 at 5:20 pm)

> * 2. No other contributers at the moment

---

# Version history

This section is coming soon

---

# ReadMe info

ReadMe version: 1 (Sunday, May 31st 2020 at 5:20 pm)

---
