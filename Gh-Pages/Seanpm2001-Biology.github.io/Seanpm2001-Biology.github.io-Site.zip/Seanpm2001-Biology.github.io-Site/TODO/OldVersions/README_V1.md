
***

# Todo

## July 8th tasks

- [ ] Mention usage of Cayman theme on the site page

- [ ] Add direct links to individual biology organizagions and their GitHub pages

- [ ] Improve the article

***
