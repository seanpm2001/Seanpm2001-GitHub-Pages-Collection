
***

# Trailer

## The old trailer for Touch Pets Dogs 2

![The trailer has failed to load. A link to the video is below, although inconvenient.](/OldTrailer/Trailer1.mp4)

Did this test not work? You can view the trailer directly by [clicking/tapping here (your browser may automatically download it)](/OldTrailer/Trailer1.mp4)

***
