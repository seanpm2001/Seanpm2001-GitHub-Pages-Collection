# TouchPetsDogs2Rewritten
A recreation of the old iOS game "Touch Pets Dogs 2" by ngmoco. The game has been shut down for over 6 years, and I have really missed it.

---

About
-----------

Touch Pets Dogs 2 is a game about taking care of virtual dogs. You can feed them, clean up after them, dress them up, play with them, and more

---

Why the recreation?
-----------

It was a game from my early childhood, and I really miss it. It no longer exists, as the servers went down almost a whole decade ago. ngmoco isn't even an active company anymore

---

Contributers
-----------

Currently, the only contributer is SeanPM2001 (myself) I will add more contributers in the future.

1. [seanpm2001](https://github.com/seanpm2001/) - 25 commits (As of May 28th 2020 at 2:51 pm)
2. No other contributers at the moment

---

# Languages

Human spoken languages
-----------

Currently, the game is only made in 1 human-spoken language:

> 1. English

Computer languages
-----------

The game is currently planned to be written in 3 programming, markup, and markdown languages:

> 1. HTML 5.3 

> 2. Markdown

> 3. Python

---

# Version history

---

Concept releases
-----------

> 1. [Concept release 1: 0.0.0.1](https://github.com/seanpm2001/TouchPetsDogs2Rewritten/tree/V0.0.0.1) [pre-release]

> 2. [Coming soon](https://www.example.com)

Alpha releases
-----------

> * No Alpha releases have been made yet

Beta releases
-----------

> * No Beta releases have been made yet

Full releases
-----------

> * No Full releases have been made yet

---

# About ReadME.md

ReadMe version: 2 (May 28th 2020 at 2:51 pm)

**Description:**

`Explains the project, and its goals.`

---
