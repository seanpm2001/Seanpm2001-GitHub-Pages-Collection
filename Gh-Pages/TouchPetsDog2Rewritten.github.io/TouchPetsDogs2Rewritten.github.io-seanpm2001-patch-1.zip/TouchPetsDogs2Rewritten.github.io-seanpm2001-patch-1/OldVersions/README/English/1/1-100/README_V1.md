# TouchPetsDogs2Rewritten
A recreation of the old iOS game "Touch Pets Dogs 2" by ngmoco. The game has been shut down for over 6 years, and I have really missed it.

---

About
-----------

Touch Pets Dogs 2 is a game about taking care of virtual dogs. You can feed them, clean up after them, dress them up, play with them, and more

---

Why the recreation?
-----------

It was a game from my early childhood, and I really miss it. It no longer exists, as the servers went down almost a whole decade ago. ngmoco isn't even an active company anymore

---

Contributers
-----------

Currently, the only contributer is SeanPM2001 (myself) I will add more contributers in the future.

1. [seanpm2001](https://github.com/seanpm2001/) - 4 commits (As of May 28th 2020 at 1:41 pm)
2. No other contributers at the moment

---

# Languages

Human spoken languages
-----------

Currently, the game is only made in 1 human-spoken language:

> 1. English

Computer languages
-----------

The game is currently planned to be written in 3 programming, markup, and markdown languages:

> 1. HTML 5.3 

> 2. Markdown

> 3. Python

---

# About ReadME.md

ReadMe version: 1 (May 28th 2020 at 1:41 pm)
Description: 

`Explains the project, and its goals.`

---
