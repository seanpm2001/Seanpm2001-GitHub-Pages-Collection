# Ignore this file

This file is here so that I can import some images after creating the file path required to upload. This file is not used for anything else.
