
***

### Top

# `README.md`

***

# Index

[00.0 - Top](#Top)

[01.0 - Index](#Index)

[02.0 - Description](#Reactop)

[03.0 - About](#About)

[04.0 - Wiki](#Wiki)

[05.0 - Version history](#Version-history)

[06.0 - Contributers](#Contributers)

[07.0 - Sources](#Sources)

[08.0 - About README](#About-README)

[09.0 - README Version history](#README-Version-history)

[10.0 - Footer](#You-have-reached-the-end-of-the-README-file)

***

# Reactop
A old idea I had for a series of laptops that run ReactOS (an operating system that runs Windows programs natively, but isn't built on Windows code) I am unsure if I will continue this project.

***

## About

See above

***

## Wiki

[Click/tap here to view this projects Wiki](https://github.com/seanpm2001/Reactop/wiki/)

***

## Version history

[More versions coming soon](https://www.example.com)

***

## Contributers

Currently, I am the only contributer. I will not accept any other contributers, this is a personal project.

> * 1. [seanpm2001](https://github.com/seanpm2001/) - 32 commits (As of Friday, July 17th 2020 at 7:07 pm)

> * 2. No other contributers allowed

***

## Contributing

Please read the `CONTRIBUTING.md` file and obey its rules to commit here. [Here is the file if you couldn't find it](https://github.com/seanpm2001/Reactop/blob/master/CONTRIBUTING.md)

***

## Sources

You can read about ReactOS on Wikipedia. Search for it yourself, or [click here](https://en.wikipedia.org/wiki/ReactOS).

You can help to contribute to the ReactOS project on GitHub. Search for it yourself, or [click here](https://github.com/reactos/reactos).

Other sources currently aren't listed.

***

## About README

File type: `Markdown (*.md)`

File version: `1 (Friday, July 17th 2020 at 7:07 pm)`

Line count (including blank lines and compiler line): `0,138`

***

## README Version history

* Version 1  (Friday, July 17th 2020 at 7:07 pm)

> Changes:

> * Created the README.md file

> * Added the title section

> * Added the index section

> * Added the about section

> * Added the Wiki section

> * Added the version history section

> * Added the contributers section

> * Added the contributing section

> * Added the sources section

> * Added the About README section

> * Added the README Version history section

> * Added the footer

* Version 2 (Coming soon)

> Changes:

> * Coming soon

***

### You have reached the end of the README file

[Back to top](#Top) [Exit](https://github.com)

***
