
***

## Repo description

# Seanpm2001-NimbleBit
This is my NimbleBit game linking, partnership, and discovery repo, containing general info about the 10 NimbleBit games I currently play.

***

## Seanpm2001-NimbleBit

This is my NimbleBit game linking, partnership, and discovery repo, containing general info about the 10 NimbleBit games I currently play.

## Image repos

[Tiny Tower images](https://github.com/seanpm2001/SeansLifeArchive_Images_TinyTower) <!-- 01 !-->

[Tiny Tower Vegas images](https://github.com/seanpm2001/SeansLifeArchive_Images_TinyTowerVegas) <!-- 02 !-->

[Bit City images](https://github.com/seanpm2001/SeansLifeArchive_Images_Bit_City_-NimbleBit_Game-) <!-- 03 !-->

[Tiny Death Star images](https://github.com/seanpm2001/SeansLifeArchive_Images_TinyDeathStar) <!-- 04 !-->

[Pocket Trains images](https://github.com/seanpm2001/SeansLifeArchive_Images_Pocket_Trains) <!-- 05 !-->

[Pocket Planes images](https://github.com/seanpm2001/SeansLifeArchive_Images_PocketPlanes) <!-- 06 !-->

[Sky Burger (modern) images](https://github.com/seanpm2001/SeansLifeArchive_Images_ModernSkyBurger) <!-- 07 !-->

[Disco Zoo images](https://github.com/seanpm2001/SeansLifeArchive_Images_DiscoZoo) <!-- 08 !-->

[Lego Tower images](https://github.com/seanpm2001/SeansLifeArchive_Images_LegoTower) <!-- 09 !-->

[Pocket Frogs images](https://github.com/seanpm2001/SeansLifeArchive_Images_PocketFrogs) <!-- 10 !-->

[Sky Burger (classic) images](https://github.com/seanpm2001/SeansLifeArchive_Images_ClassicSkyBurger) <!-- 11 !-->

[Mega Panda images](https://github.com/seanpm2001/SeansLifeArchive_Images_MegaPanda-NimbleBit_Game-) <!-- 12 !-->

[Scoops images](https://github.com/seanpm2001/SeansLifeArchive_Images_Scoops_-NimbleBit_Game-) <!-- 13 !-->

Coming soon: Other NimbleBit games

## How long I have been playing

I originally started playing NimbleBit games on my iPod Touch 4/iPod Touch 5 (running iOS 5, later 6) around 2011. After I phased out iOS and had to start over, I later started playing again on Android in 2019.

***

<!--
Tags
Nimblebit
GPL3
GPLV3
TXT
MD
Wiki
Discovery
Tiny-tower
Bit-city

!-->
