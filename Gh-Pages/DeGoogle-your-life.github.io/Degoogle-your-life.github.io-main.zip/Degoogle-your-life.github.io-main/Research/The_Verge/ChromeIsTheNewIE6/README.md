
***

# The Verge Article

## Chrome is turning into the new Internet Explorer 6

![Videos can't be embedded in markdown yet, or the file could not be reached](/Research/The_Verge/ChromeIsTheNewIE6/Media/MP4/chrome_ie_fade_2.0.mp4)

I cannot re-upload the article here due to copyright reasons. You can [read it here (https://www.theverge.com/2018/1/4/16805216/google-chrome-only-sites-internet-explorer-6-web-standards)](https://www.theverge.com/2018/1/4/16805216/google-chrome-only-sites-internet-explorer-6-web-standards)

***
