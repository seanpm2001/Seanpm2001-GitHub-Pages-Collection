
***

# Degoogle campaign 2021 Roadmap part AB

Roadmap AB:

A - First planned roadmap
B - Map already started 12 articles ago on February 3rd 2021

**New targets starting Monday (2 articles for Saturday, 2 targets for Sunday first; do not start early)**

## 2.22.2021

* Google Translate <!-- 13 !-->

* Google Account <!-- 14 !-->

## 2.23.2021

* Gerrit <!-- 15 !-->

* Google analytics <!-- 16 !-->

## 2.24.2021

* Google AdSense <!-- 17 !-->

* Google One <!-- 18 !-->

## 2.25.2021

* Google Plus (defunct) <!-- 19 !-->

### Defunct notice

This service was discontinued on [date] this article will stay up to list the problems and alternates to [defunct product]

* Google Play Store <!-- 20 !-->

## 2.26.2021

* Google Docs <!-- 21 !-->

* Google Slides <!-- 22 !-->

## 2.27.2021

* Google Sheets <!-- 23 !-->

* Google Forms <!-- 24 !-->

## 2.28.2021

* Google Cardboard <!-- 25 !-->

* Google Messages <!-- 26 !-->

## 3.01.2021

* Google Material Design <!-- 27 !-->

* Google Glass <!-- 28 !-->

## 3.02.2021

* Google Fushsia <!-- 29 !-->

* GBoard <!-- 30 !-->

## 3.03.2021

* Google Home <!-- 31 !-->

* Google Nest <!-- 32 !-->

## 03.04.2021

* Google Hangouts (defunct) <!-- 33 !-->

### Defunct notice

This service was discontinued on [date] this article will stay up to list the problems and alternates to [defunct product]

* Google Duo (possible discontinuation, support has been limited (2020) plug may be pulled at any time)  <!-- 34 !-->

## 03.05.2021

* Tensorflow  <!-- 35 !-->

* Blockly  <!-- 36 !-->

## 03.06.2021

* Flutter  <!-- 37 !-->

* Go  <!-- 38 !-->

## 03.07.2021

* Dart  <!-- 39 !-->

* WEBP <!-- 40 !-->

## 03.08.2021

* WEBM <!-- 41 !-->

* Google Video <!-- 42 !-->

## 03.09.2021

* Google Sites classic (defunct) <!-- 43 !-->

### Defunct notice

This service was discontinued on [date] this article will stay up to list the problems and alternates to [defunct product]

* New Google Sites <!-- 44 !-->

## 03.10.2021

* Google Pay <!-- 45 !-->

* Android Pay <!-- 46 !-->

## 03.11.2021

* Google VPN (Oxymoron) <!-- 47 !-->

* Google Photos <!-- 48 !-->

## 03.12.2021

* Google Calendar <!-- 49 !-->

* VirusTotal <!-- 50 !-->

## 03.13.2021

* More entries coming soon

***

## Templates

```markdown

### Defunct notice

This service was discontinued on [date] this article will stay up to list the problems and alternates to [defunct product]

```

***

