
***

# Add to Degoogle

* Scroogled

* Spyware claims

* Sources

* The privacy statement with every character as a link

* General info

* Translation status

* Article help status

* Install links for: {Firefox, Tor, etc.}

* Google graveyard + others

* Wikipedia links: "Criticism of Google" "PRISM" "Five eyes alliance" "1984" other

***

