
***

# Current translation priorities

Languages based on priority

## Foreign aid

Myanmar (Burmese) - Translated to help the people of Myanmar attempt to continue life normally, despite a government Coup d'état

Ukrainian

Total: 2

## Europe

Translations to help Europe stay pro-privacy

Swedish - Because Sweden is a pretty awesome country

German - over 8 million speakers, and an important country in Europe

Polish - over 50 million speakers, also an important language, as 1 degoogle article I reference is in Polish

Serbian - Due to European presence, and their contribution to society: Nikola Tesla

French - Over 600 million speakers around the world

Georgian - Inspired language

Total: 6

### Nordic countries

Danish

Dutch

Swedish (see above)

Icelandic

Norwegian

Finnish

Total: 5/6

## Asia

Indonesian (I have/had a friend online from Indonesia)

Japanese

Chinese (see below)

Korean (see below)

Arabic (see below)

Hindi (see below)

Total: 2/6

## Very common languages

English (over 1.4 billion speakers)

Spanish (over 400 million speakers)

Chinese (Traditional) - traditional first, out of respect for the Chinese language

Chinese (Simplified)

Hindi (over 600 million speakers)

Arabic (over 1.1 billion speakers)

Russian (over 200 million speakers)

Portuguese (over 200 million speakers)

Total: 8

## Korean

Korean (South)

Korean (North) - duplicate of South Korean, open for the reunification of Korea

Total: 2

## Universal languages

Esperanto

Total: 1

Grand total: 26 + 5 duplicates

***
