***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle elämääsi

Tämä on tärkein degoogling-artikkeli yleisistä degoogling-tiedoista ja linkki muihin artikkeleihin.

[Katso luettelo GitHub-organisaationa] (https://github.com/Degoogle-your-life)

***

_Lue tämä artikkeli toisella kielellä: _

** Nykyinen kieli on: ** `englanti (Yhdysvallat)` _ (käännökset saatetaan joutua korjaamaan oikean kielen korvaamiseksi.

_🌐 Luettelo kielistä_

** Lajiteltu: ** `` A-Z``

[Lajitteluvaihtoehdot eivät ole käytettävissä] (https://github.com/Degoogle-your-Life)

([af afrikaans] (/. github / README_AF.md) afrikaans | [sq Shqiptare] (/. github / README_SQ.md) albania | [am አማርኛ] (/. github / README_AM.md) amhara | [ar عربى] (/.github/README_AR.md) arabia | [hy հայերեն] (/. github / README_HY.md) armenia | [az Azərbaycan dili] (/. github / README_AZ.md) azerbaidžanilainen | [eu Euskara] (/. github /README_EU.md) baski | [be Беларуская] (/. Github / README_BE.md) valkovenäjä | [bn বাংলা] (/. Github / README_BN.md) bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) bulgaria | [ca Català] (/. Github / README_CA.md) katalaani | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichew ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) kiina (yksinkertaistettu) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) kiina (perinteinen) | [co Corsu] (/. Github / README_CO.md) korsikalainen | [hr Hrvatski] (/. Github / README_HR.md) kroatia | [cs čeština] (/. Github / README_CS .md) tšekki | [da dansk] (README_DA.md) tanska | [nl Nederlands] (/. github / README_ NL.md) hollanti | [** fi-fi englanti **] (/. github / README.md) englanti | [EO esperanto] (/. Github / README_EO.md) esperanto | [et Eestlane] (/. github / README_ET.md) viro | [tl Pilipino] (/. github / README_TL.md) filippiiniläinen | [fi Suomalainen] (/. github / README_FI.md) suomi | [fr français] (/. github / README_FR.md) ranska | [fy Frysk] (/. github / README_FY.md) Friisi | [gl Galego] (/. github / README_GL.md) galicia | [ka ქართველი] (/. github / README_KA) georgialainen | [de Deutsch] (/. github / README_DE.md) saksa | [el Ελληνικά] (/. github / README_EL.md) kreikka | [gu ગુજરાતી] (/. github / README_GU.md) gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitin kreoli | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) havaijilainen | [he עִברִית] (/. github / README_HE.md) heprea | [hi हिन्दी] (/. github / README_HI.md) hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) unkari | [on Íslenska] (/. github / README_IS.md) islanti | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) islanti | [ga Gaeilge] (/. github / README_GA.md) irlanti | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) japani | [jw Wong jawa] (/. github / README_JW.md) jaava | [kn ಕನ್ನಡ] (/. github / README_KN.md) kannada | [kk Қазақ] (/. github / README_KK.md) kazakstan | [km ខ្មែរ] (/. github / README_KM.md) khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-etelä 韓國 語] (/. github / README_KO_SOUTH.md) korea (etelä) | [ko-pohjoinen 문화어] (README_KO_NORTH.md) korea (pohjoinen) (EI Vielä Käännetty) | [ku Kurdî] (/. github / README_KU.md) kurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) kirgisia | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) liettua | [lb Lëtzebuergesch] (/. github / README_LB.md) luxemburg | [mk Македонски] (/. github / README_MK.md) makedonia | [mg madagaskaria] (/. github / README_MG.md) madagaskaria | [ms Bahasa Melayu] (/. github / README_MS.md) malaiji | [ml മലയാളം] (/. github / README_ML.md) malajalam | [mt Malti] (/. github / README_MT.md) maltan kieli | [mi maori] (/. github / README_MI.md) maori | [herra मराठी] (/. github / README_MR.md) marathi | [mn Монгол] (/. github / README_MN.md) mongoli | [my မြန်မာ] (/. github / README_MY.md) Myanmar (burmalainen) | [ne नेपाली] (/. github / README_NE.md) Nepali | [ei norsk] (/. github / README_NO.md) norja | [tai ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) pastu | [fa فارسی] (/. github / README_FA.md) | persia [pl polski] (/. github / README_PL.md) puola | [pt português] (/. github / README_PT.md) portugali | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) pandžabi | Q-kirjaimella alkavia kieliä ei ole käytettävissä [ro Română] (/. github / README_RO.md) romania | [ru русский] (/. github / README_RU.md) venäjä | [sm Faasamoa] (/. github / README_SM.md) Samoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) skotti gaeli | [sr Српски] (/. github / README_SR.md) serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) slovakia | [sl Slovenščina] (/. github / README_SL.md) sloveeni | [niin Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) espanja | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) suahili | [sv Svenska] (/. github / README_SV.md) ruotsi | [tg Тоҷикӣ] (/. github / README_TG.md) tadžiki | [ta தமிழ்] (/. github / README_TA.md) tamili | [tt Татар] (/. github / README_TT.md) tataari | [te తెలుగు] (/. github / README_TE.md) telugu | [th ไทย] (/. github / README_TH.md) thai | [tr Türk] (/. github / README_TR.md) turkki | [tk Türkmenler] (/. github / README_TK.md) turkmeeni | [uk Український] (/. github / README_UK.md) ukraina | [ur اردو] (/. github / README_UR.md) urdu | [ug ئۇيغۇر] (/. github / README_UG.md) uiguuri | [uz O'zbek] (/. github / README_UZ.md) uzbekki | [vi Tiếng Việt] (/. github / README_VI.md) vietnam | [cy Cymraeg] (/. github / README_CY.md) kymri | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jiddiš | [yo joruba] (/. github / README_YO.md) joruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Saatavilla 110 kielellä (108, kun ei lasketa englantia ja pohjoiskorealaista, koska pohjoiskorealaista ei ole vielä käännetty [lue tästä täältä] (/ OldVersions / korea (pohjoinen) ) /README.md))

Käännökset muille kielille kuin englanniksi käännetään koneella, eivätkä ne ole vielä tarkkoja. Virheitä ei ole vielä korjattu 5. helmikuuta 2021. Ilmoita käännösvirheet [tässä] (https://github.com/seanpm2001/Degoogle-your-life/issues/), varmista, että korjaat korjauksesi lähteillä ja opastat , koska en tiedä muita kieliä kuin englantia hyvin (aion saada kääntäjän lopulta), mainitse [wikisanakirja] (https://fi.wiktionary.org) ja muut lähteet raportissasi. Jos näin ei tehdä, korjauksen julkaiseminen hylätään.

Huomaa: GitHubin tulkinnan rajoitusten vuoksi (ja melkein kaikki muut verkkopohjaiset merkinnät) näiden linkkien napsauttaminen ohjaa sinut erilliseen tiedostoon erilliselle sivulle, joka ei ole minun GitHub-profiilisivu. Sinut ohjataan [seanpm2001 / seanpm2001-arkistoon] (https://github.com/seanpm2001/seanpm2001), jossa README-palvelinta isännöidään.

Käännökset tehdään Google Kääntäjän kanssa, koska tarvitsen vain vähän tai ei lainkaan tarvitsemiani kieliä muissa käännöspalveluissa, kuten DeepL ja Bing Translate (melko ironista Google-vastaista kampanjaa varten). Pyrin löytämään vaihtoehdon. Jostain syystä muotoilu (linkit, jakajat, taivutus, kursivointi jne.) Sekoitetaan erilaisissa käännöksissä. Se on tylsää korjata, enkä tiedä kuinka korjata nämä ongelmat kielillä, joissa ei ole latinankielisiä merkkejä, ja oikealta vasemmalle (kuten arabia) käytetyille kielille tarvitaan lisäapua näiden ongelmien korjaamiseen

Huolto-ongelmien takia monet käännökset ovat vanhentuneita ja käyttävät tämän `` README`` -artikkelitiedoston vanhentunutta versiota. Kääntäjä tarvitaan. Lisäksi 9. huhtikuuta 2021 alkaen minulla kestää jonkin aikaa saada kaikki uudet linkit toimimaan.

***

## Indeksi

[00.0 - Otsikko] (# Degoogling --- Degoogle-elämäsi)

> [00.1 - Hakemisto] (# Hakemisto)

[01.0 - Peruskuvaus] (# Peruskuvaus)

> [01.1 - arkiston otsikko] (# Degoogle-your-life)

> [01.2 - Wuest3NFuchs-kuvauksen yleiskatsaus] (# Overview-by-Wuest3nFuchs)

>> [01.2.1 - Mitä se tarkoittaa?] (# Mitä-se-tarkoittaa-by-Wuest3nFuchs)

>> [01.2.2 - Miksi Degoogle?] (# Why-Degoogle - by-Wuest3nFuchs)

[02.0 - Artikkelit] (# Artikkelia)

[03.0 - Tietosuoja] (# Tietosuoja)

[04.0 - Muut Googlen vastaiset kampanjat] (# Muut-Google-vastaiset kampanjat)

> [04.0.1 - Poissa käytöstä] (# Poissa käytöstä)

> [04.0.2 - käynnissä] (# käynnissä)

[05.0 - Muiden argumenttien torjunta] (# Countering-other-argumentit)

> [05.0.1 - Mukavuus] (# Mukavuus)

> [05.0.2 - Miksi sillä on merkitystä? On joka tapauksessa liian myöhäistä] (# Miksi-sillä on väliä,-se-liian myöhään-joka tapauksessa)

> [05.0.3 - Muu] (# Muu)

[06.0 - lähteet] (# lähdettä)

[07.0 - Lataa linkit] (# Download-linkkiä)

[08.0 - Minun degoogling-kokemukseni] (# My-degoogling-kokemukseni)

> [08.1 - mistä vaihdoin] (# mitä-vaihdoin-käytöstä)

> [08.2 - Tuotteet, joista en vieläkään pääse eroon] (# Tuotteet-en-vieläkään-pääse pakenemaan)

[09.0 - Muut tarkistettavat asiat] (# Muut - lähtöselvitys)

[10.0 - tiedostotiedot] (# tiedosto-tiedot)

> [10.1 - Ohjelmiston tila] (# Ohjelmiston tila)

> [10.2 - Sponsor info] (# Sponsor-info)

[11.0 - Tiedostohistoria] (# Tiedosto-historia)

[12.0 - alatunniste] (# alatunniste)

***

## Perustiedot

[Wikipediasta: Degoogle] (https://fi.wikipedia.org/wiki/DeGoogle)

DeGoogle-liike (jota kutsutaan myös de-Google-liikkeiksi) on ruohonjuuritason kampanja, joka on syntynyt, kun yksityisyyden suoja-aktivistit kehottavat käyttäjiä lopettamaan Google-tuotteiden käytön kokonaan yrityksen kasvavien yksityisyyden huolenaiheiden vuoksi. Termillä tarkoitetaan Googlen poistamista elämästään. Kun Internet-jättiläisen kasvava markkinaosuus luo yritykselle monopoliaseman digitaalisissa tiloissa, yhä useammat toimittajat ovat huomanneet, että on vaikea löytää vaihtoehtoja yrityksen tuotteille.

**Historia**

Vuonna 2013 John Koetsier Venturebeatista sanoi, että Amazonin Kindle Fire Android-pohjainen tabletti oli "Googlen poistama Android-versio". John Simpson (US News) kirjoitti vuonna 2014 Googlen ja muiden hakukoneiden "oikeudesta tulla unohdetuksi". Irish Timesin Derek Scally kirjoitti vuonna 2015 artikkelin siitä, miten "Googlesta poistetaan elämäsi". Vuonna 2016 Androin Kris Carlond Viranomainen ehdotti, että CyanogenMod 14: n käyttäjät voisivat "poistaa Googlen" puhelimestaan, koska CyanogenMod toimii hyvin myös ilman Google-sovelluksia. Vuonna 2018 Nick Lucchesi Inversestä kirjoitti kuinka ProtonMail mainosti miten "pystyä poistamaan Google-elämäsi kokonaan". Lifehackerin Brendan Hesse kirjoitti yksityiskohtaisen opastuksen "Googlen lopettamisesta". Gizmodon toimittaja Kashmir Hill väittää, että hän menetti kokouksia ja kokenut vaikeuksia tapaamisien järjestämisessä ilman Google-kalenteria. Vuonna 2019 Huawei maksoi hyvityksen Filippiineillä oleville puhelimen omistajille. estetty käyttämästä Googlen tarjoamia palveluja, koska vaihtoehtoja on niin vähän, että yrityksen tuotteiden puuttuminen teki tavanomaisesta Internetin käytöstä mahdotonta.

***

# Degoogle-elämäsi
Säilö yleisten tietojenkäsittelytietojen ja linkkien löytämiseen muihin degoogling-arkistoihini.

***

## Katsaus kirjoittanut Wuest3nFuchs

Parempi kuvaus, tarjoaa [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - lähde: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Mitä se tarkoittaa? kirjoittanut Wuest3nFuchs

Degoogling tarkoittaa lopettaa kaiken Googlelle kuuluvan käyttäminen, mikä tahansa Googlen tekemä. Puhun heidän hakukoneestaan, heidän sähköpostipalvelustaan ​​(Gmail), Youtubesta jne.

### Miksi Degoogle? kirjoittanut Wuest3nFuchs

Google on tällä hetkellä yksi maailman tehokkaimmista yrityksistä. He ovat tallentaneet valtavan määrän tietoa meistä kaikista. Jotkut väittävät, että tietomme ovat heidän kanssaan turvallisia, koska he osaavat suojata niitä. Mutta tämä ei ole totta. Google on tunkeutunut aiemmin ja se tunkeutuu tulevaisuudessa. Ehkä ei joku käsikirjoituksen lapsi, mutta sen tekee kansallisvaltio. Google tallentaa henkilötietoja meille kaikille, koska näin he ansaitsevat rahaa.

He skannaavat sähköpostit, tallentavat mitä etsimme, kun käytämme heidän hakukoneitaan, mitä videoita katsomme Youtubessa. Näin he kohdistavat meidät ja rakentavat meille profiilin, joka näyttää meille mainoksen sen perusteella, mistä puhuimme parhaan ystävämme kanssa, jotta he voivat näyttää meille mainoksen jostakin tarvitsemastamme, mutta tämä on liian kammottavaa. Herra Snowdenin ansiosta tiedämme nyt, että Google on jakanut henkilökohtaiset tietomme NSA: n kanssa nimellä "PRISM" **.


Jatkossa joku pystyy saamaan kaiken tiedon ja vakuutan, että jotain todella pahaa tapahtuu. Voit estää tämän tapahtumisen aloittamalla Degooglingin juuri nyt. Älä myöskään saa käyttää sellaisten yritysten tuotteita, jotka jakavat tietosi ** NSA: n ** kanssa. Sinun pitäisi lopettaa tämä kaikki degooglingilla.

** Jos muut ihmiset pystyvät siihen, voit tehdä sen myös. **

[Lue lisää täältä] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Linkkiä haarukkaan ei ole tällä hetkellä luettelossa, koska en omista tätä arkistoa kokonaan ja haluan mainostaa muita lähteitä. Olisi itsekästä linkittää omaan https://github.com/Degoogle-your-life/Degoogle! ->

***

## Artikkelit

### Artikkelin tila

_Kaikki artikkelit ovat parhaillaan kesken ja tarvitsevat mittavia parannuksia. Ehdotukset ja korjaukset ovat sallittuja.

_ Useimpia artikkeleita ei ole vielä aloitettu 18. huhtikuuta 2021 klo 16.09. Pyrin löytämään aikaa ja vaivaa niiden aloittamiseksi.

[Miksi sinun pitäisi lopettaa Google Chromen käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Lopeta Chrome-kirjojen käyttö] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Lopeta WideVine DRM: n käyttö / On aika leikata WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Miksi sinun pitäisi lopettaa ReCaptchan käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Vaihtelee YouTubesta] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Lopeta Googling, miksi sinun pitäisi lopettaa Google-haun käyttäminen] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[Miksi sinun pitäisi lopettaa Gmailin käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Miksi sinun pitäisi lopettaa Androidin käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Miksi sinun pitäisi välttää Google-vahvistinta] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Miksi sinun pitäisi lopettaa Google Driven käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Miksi sinun pitäisi lopettaa Google Mapsin ja Google Earthin käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Hei Google, lopeta] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Lopeta lukeminen Google / Play-kirjoista] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Lopeta Google Classroomin käyttö] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Miksi sinun pitäisi lopettaa Google-kääntäjän käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Miksi sinun pitäisi lopettaa Google-tiliesi käyttäminen] (https://github.com/seanpm2001/Why-you-should-ssuosituimmat Google-tilit) <! - 16! ->

** Uudet artikkelit kirjoitetaan pian: **

[Miksi sinun pitäisi lopettaa Gerritin käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Miksi sinun pitäisi lopettaa Google Analyticsin käyttö (arkisto on rikki keskiviikkona 24. helmikuuta 2021 kello 16.13)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics) <! - 18! ->

<! - Työnjakaja! ->

[Miksi sinun pitäisi lopettaa Google AdSensen käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Miksi sinun pitäisi lopettaa Google Onen käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Miksi sinun pitäisi lopettaa Google+ -palvelun käyttö (poissa käytöstä)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Miksi sinun pitäisi lopettaa Google Play -kaupan käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Miksi sinun pitäisi lopettaa Google-dokumenttien käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Miksi sinun pitäisi lopettaa Google Slidesin käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Miksi sinun pitäisi lopettaa Google Sheetsin käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Miksi sinun pitäisi lopettaa Google Formsin käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Miksi sinun pitäisi lopettaa Google Cardboardin käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Miksi sinun pitäisi lopettaa Google Messagesin käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Miksi sinun pitäisi lopettaa Google Material Designin käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Miksi sinun pitäisi lopettaa Google Glass / Glassesin käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Miksi sinun pitäisi lopettaa Google Fuchsian käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Miksi sinun pitäisi lopettaa GBoardin käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Miksi sinun pitäisi lopettaa Google Homen käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Miksi sinun pitäisi lopettaa Google Nestin käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Miksi sinun pitäisi lopettaa Google Hangouts -palvelun käyttö (poissa käytöstä)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Miksi sinun pitäisi lopettaa Google Duon käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Miksi sinun pitäisi lopettaa Google Tensorflow -palvelun käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Miksi sinun pitäisi lopettaa Google Blocklyn käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Miksi sinun pitäisi lopettaa Google Flutterin käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Miksi sinun pitäisi lopettaa Googles Go -ohjelmointikielen käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Miksi sinun pitäisi lopettaa Googles Dart -ohjelmointikielen käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Miksi sinun tulisi lopettaa Googlen WebP-kuvamuodon käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Miksi sinun pitäisi lopettaa Googlen WebM-videoformaatin käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Miksi sinun pitäisi lopettaa Google Video -palvelun käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Miksi sinun pitäisi lopettaa Google-sivustojen (klassinen) käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Miksi sinun pitäisi lopettaa Google-sivustojen ("Uusi") käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Miksi sinun pitäisi lopettaa Google Payn käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Miksi sinun pitäisi lopettaa Android Payn käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Miksi sinun pitäisi lopettaa Google VPN: n (oxymoron) käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Miksi sinun pitäisi lopettaa Google-kuvien käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[Miksi Google-kalenterin käyttö tulisi lopettaa] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Miksi sinun pitäisi lopettaa VirusTotalin käyttö (koska se on Googlen omistama syyskuusta 2012] (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Miksi sinun pitäisi lopettaa Google Fi: n käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi) <! - 53! ->

[Miksi sinun pitäisi lopettaa Google Stadian käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Miksi sinun tulisi lopettaa Google Keepin käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Miksi sinun pitäisi lopettaa Google Base -palvelun käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Miksi sinun pitäisi lopettaa osallistuminen Google Summer of Code -ohjelmaan] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Miksi Google Kameran käyttö tulisi lopettaa] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Miksi sinun pitäisi lopettaa Google-laskimen käyttö (voi tuntua äärimmäiseltä, mutta sinun tulisi riistää kaikesta, erittäin helppo vaihtaa)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Laskin) <! - 59! ->

[Miksi sinun pitäisi lopettaa Google Survey + -palkintojen käyttö] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Miksi sinun pitäisi lopettaa Google Drawingsin käyttäminen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Miksi sinun pitäisi lopettaa Tenorin (GIF-sivusto, jonka omistaa Google vuodesta 2019 lähtien)]] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Mikä FLoC - miksi sinun pitäisi välttää Googlen suurta FLoCing-ongelmaa (lopeta Google Chromen käyttö)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Artikkeleita yhteensä: ** `63 '

** Artikkeli [tiekartta AB] (DegoogleCampaign_2021Roadmap_Part1.md) (12. maaliskuuta 2021 asti) 2 vapaapäivää **

** Artikkeli [tiekartta BB] (DegoogleCampaign_2021Roadmao_Part2.md) (enintään 2021) 2 vapaapäivää **

Artikkelin tila

Kaikki artikkelit ovat tällä hetkellä kesken ja tarvitsevat mittavia parannuksia. Ehdotukset ja korjaukset ovat sallittuja.

** Haarukat **

Laajentamalla Degoogle-verkkoani, lisäämällä helppokäyttöisyyttä ja yhteisöhuutoja.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Haaroitettu: [https://github.com/wacko1805/Fossapps](https://github.com/wacko1805/Fossapps) (englanti)

2. [Tietosuoja-linkit] (https://github.com/Degoogle-your-life/Privacy-linkit) | Haaroitettu: [https://github.com/Arturro43/privacy-links](https://github.com/Arturro43/privacy-links) (puola)

3. [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Haarautunut osoitteesta: [https://github.com/LinuxCafeFederation/Delightful-Privacy](https://github.com/LinuxCafeFederation/Delightful-Privacy) (englanti)

4. [Estolistat] (https://github.com/Degoogle-your-life/blocklists) | Haarautunut: [https://github.com/jmdugan/blocklists](https://github.com/jmdugan/blocklists) (englanti)

5. [Degoogle, kirjoittanut Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Haaroitettu: [https://github.com/Wuest3nFuchs/Degoogle](https://github.com/Wuest3nFuchs/Degoogle) (englanti)

** Liittyvät **

[Degoogled Android phone Virtual Machine -tutkimus] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Katso myös:**

[Googlen kritiikki Wikipediassa] (https://fi.wikipedia.org/wiki/Criticism_of_Google)

[Google Graveyard (killbygoogle.com) - lajiteltu luettelo yli 224 tuotteesta, jonka Google on tappanut] (https://killedbygoogle.com/)

> [GitHub-linkki] (https://github.com/codyogden/killedbygoogle)

[Aakkosellinen työntekijäliitto - Googlen uusi työntekijäjärjestö, jossa on yli 800 jäsentä] (https://alphabetworkersunion.org/people/our-union/)

[Etkö halua erota dinosaurus pääsiäismunasta? Tämä verkkosivusto on katettu] (https://chromedino.com/)

***

## Yksityisyys

[G] (https://fi.wikipedia.org/wiki/Criticism_of_Google) [o] (https://fi.wikipedia.org/wiki/PRISM_ (valvonta_ohjelma)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -huono /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. fi / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -selain /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://fi.wikipedia.org/wiki/Nothing_to_hide_argument # Criticism) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -essay-sample / nothing-to-hide-argument - ei ole mitään sanottavaa /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- tietoja-voit-löytää-poistaa-poistaa-nyt /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -your-personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -monetizes-and) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-on-sinun-yksityisyytesi) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- collection-paljastettu.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ terveys-kunto-data-yksityisyys /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-Government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https://moz.com /blog/where-does-google-draw-the-data-collection-line)[e](https://mashable.com/article/google-android-data-collection-study/)[s](https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)[o](https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -vaatimus-5-m: n puolesta illion-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy) -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaengerss-consented-to-data-collection/)[r](https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/)[i](https://www.cbsnews.com/news/google-education-spies-on-collects- data-miljoonista-lapsista-väittää-oikeusjuttu-uusi-meksiko-lakimies /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -nasemme / nenämme /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / technology / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : //medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Voisin jatkaa ja jatkaa todisteita tästä, mutta näiden kaikkien löytäminen ja läpikäyminen kesti kauan. artikkelit)

Google-tuotteiden tietosuoja on aina huono, johtuen kaikista vakoojaohjelmia sisältävistä Google-tuotteista.

Ei ole väliä mitä teet, kun käytät Googlea, kaikki arkaluontoiset henkilötietosi lähetetään Googlelle ja muille. Google on myös havaittu käyvän läpi avoimia ohjelmia. Esimerkiksi henkilökohtaisesta kokemuksestani (Firefoxilla), kun YouTube-välilehti oli auki, missä en käynyt, katselin useita videoita offline-tilassa (VLC Media Player) Myöhemmin, kun menin tarkistamaan suosituksia, se oli melkein kaikki mitä olin katsellut. Epäilemättä he vakoilevat myös muita ohjelmia.

Chromessa (ja monissa muissa selaimissa) on incognito-tila. Chromessa tämä tila on turha, koska Google silti louhitsee tietosi. Vaikka poistat tiedonlouhinnan / seurannan käytöstä ja otat "ei seuraa" -signaalin käyttöön, yllätys, Google kaivaa silti tietojasi.

Jos luulet, ettei sinulla ole mitään salattavaa, olet väärässä **. Tämä väite on purettu monta kertaa:

[Wikipedian kautta] (https://fi.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden huomautti, että "väittäen, että et välitä oikeudesta yksityisyyteen, koska sinulla ei ole mitään salattavaa, ei ole eroa kuin sanomalla, ettet välitä sananvapaudesta, koska sinulla ei ole mitään sanottavaa." Kun sanot, Minulla ei ole mitään salattavaa, sanot: "Minua ei kiinnosta tämä oikeus." Sanot: "Minulla ei ole tätä oikeutta, koska olen päässyt siihen pisteeseen, että minun on perusteltava Se, miten oikeudet toimivat, hallituksen on perusteltava tunkeutumisen oikeuksiisi. "

2. Daniel J. Solove ilmoitti artikkelissa The Chronicle of Higher Education, että hän vastustaa väitettä; hän totesi, että hallitus voi jättääk henkilöä koskevia tietoja ja vahingoittaa henkilöä tai käytä henkilöä koskevia tietoja palvelujen käytön estämiseksi, vaikka henkilö ei tosiasiallisesti tekisi väärintekoja, ja että hallitus voi vahingoittaa henkilökohtaista elämää tekemällä virheitä. Solove kirjoitti: "Ollessaan suorassa yhteydessä ei-piilotettava väite voi vallata, sillä se pakottaa keskustelun keskittymään kapeaan yksityisyyden käsitykseen. Mutta kun se joutuu kohtaamaan yksityisyyden ongelmia, joihin valtion tiedonkeruu ja käyttö liittyy valvonnan ulkopuolella paljastamisella, ei-piilotettavalla argumentilla ei lopulta ole mitään sanottavaa. "

3. Adam D. Moore, julkaisun Privacy Rights: Moral and Legal Foundations kirjoittaja, väitti, että "näkemys on siitä, että oikeudet ovat vastustuskykyisiä kustannus-hyöty tai seuraamuksellisille argumenteille. Tässä hylätään näkemys, että yksityisyyden edut ovat kaikenlaisia asioista, joilla voidaan käydä kauppaa turvallisuuden vuoksi. " Hän totesi myös, että valvonta voi vaikuttaa suhteettomasti tiettyihin yhteiskunnan ryhmiin ulkonäön, etnisen alkuperän, seksuaalisuuden ja uskonnon perusteella.

4. Tietoturva-asiantuntija ja kryptografi Bruce Schneier ilmaisi vastustuksensa vedoten kardinaali Richelieun lausuntoon "Jos minulle annetaan kuusi riviä, jotka on kirjoittanut rehellisimmän miehen käsissä, löytäisin heistä jotain, joka ripustaisi hänet". siihen, kuinka osavaltion hallitus voi löytää näkökohtia ihmisen elämästä syytteeseenpanoa tai kiristämistä varten. Schneier väitti myös, että "liian monet luonnehtivat keskustelua väärin" turvallisuudeksi kuin yksityisyydeksi ". Todellinen valinta on vapaus vs. hallinta. "

5. Harvey A. Silverglate arvioi, että tavallinen henkilö tekee keskimäärin tietämättään kolme rikosta päivässä Yhdysvalloissa.

6. Filosofi ja psykoanalyytikko Emilio Mordini väitti, että "ei mitään salattavaa" -peruste on luonnostaan ​​paradoksaalista. Ihmisillä ei tarvitse olla "jotain piilotettavaa" piilottaakseen "jotain". Piilotettu ei ole välttämättä merkitystä, väittää Mordini. Sen sijaan hän väittää, että intiimi alue, joka voi olla sekä piilotettu että pääsyn rajoitus, on välttämätöntä, koska psykologisesti ottaen meistä tulee yksilöitä havaitsemalla, että voimme piilottaa jotain muille.

7. Julian Assange totesi: "Tappajalle ei ole vielä vastausta. Jacob Appelbaumilla (@ioerror) on älykäs vastaus, joka pyytää tätä sanovia ihmisiä antamaan hänelle puhelimen avattuna ja vetämään housunsa alas. Minun versioni on sanoa: "No, jos olet niin tylsää, meidän ei pitäisi puhua sinulle eikä kenenkään muulle", mutta filosofisesti todellinen vastaus on seuraava: joukkovalvonta on massa rakenteellinen muutos. Kun yhteiskunta menee huonosti, se menee ottamaan sinut mukaan, vaikka olisitkin maan hämärin ihminen. "

8. Oikeusprofessori Ignacio Cofone väittää, että väite on virheellinen omin sanoin, koska aina kun ihmiset paljastavat asiaankuuluvia tietoja muille, he paljastavat myös epäolennaisia ​​tietoja. Tällä merkityksettömällä tiedolla on yksityisyyden kustannuksia ja se voi johtaa muihin haitoihin, kuten syrjintään.

***

## Muut Googlen vastaiset kampanjat

Tämä on luettelo muista merkittävistä Google-vastaisista kampanjoista. Tämä luettelo on epätäydellinen. Voit auttaa laajentamalla sitä.

### Poissa käytöstä

[Scroogled - Microsoft (marraskuu 2012 - 2014)] (https://fi.wikipedia.org/wiki/Scroogled)

_ Ei muita merkintöjä tällä hetkellä.

### Meneillään oleva

_Tämä luettelo on tällä hetkellä tyhjä.

***

## Muut argumentit

Joitakin väitteitä ihmiset esittävät Googlen perustelemiseksi. Yksi ensimmäisistä suurimmista on jo poistettu käytöstä [täällä] (# Privacy), mutta tässä on joitain muita:

### Mukavuus

Kyllä, Google-tuotteet näyttävät käteviltä. Kaupat ovat kuitenkin kaikkea hyvää mukavuuden kannalta, mukaan lukien turvallisuus, yksityisyys ja luotettavuus. Google on ollut vuosien varrella laiskempi, ja heidän palvelimensa ovat laskeneet yhä enemmän. Tällä hetkellä Google-palvelimet menevät alas lähes tunnin ajan 1-2 kertaa kuukaudessa (etenkin YouTube)

Valitettavasti, koska yhteiskunnat luottavat Googleen, Google on tullut hallitsemaan Internetiä ja pyrkii hallitsemaan yhä enemmän. Vuonna 2012, kun Google putosi viiden minuutin ajaksi, ilmoitettiin, että ** maailmanlaajuinen ** Internet-liikenne ** laski 40% ** Google laskee usein 1-2 tunniksi ja [eettisen tiiminsä potkut] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) muun muassa, niistä tulee vähemmän ja vähemmän käteviä.

Mukavuus ei ole aina hyvä asia. Sinun tulisi olla tietoinen siitä, mitä tapahtuu ja olla varautunut, kun he menevät alas, koska ei ole tapaa, jolla palvelin ei mene alas aina silloin tällöin.

Google ei myöskään ole niin kätevä kuin luulet. On muitakin paljon helpompia sivustoja. Google ei ole kaukana kätevästä tilanteesta, kun kirjaat heidän satunnaiset tilien keskeyttämisensä ja lopettamisensa ilman vastausta (ellet kiinnitä tarpeeksi huomiota Google twitter -tiliin tai haastat heitä 100 000 000 dollarin tai suuremmalla haastehakemuksella), niin he ovat käyttäneet sinua hyväkseen, huijata sinua pakotti sinut huutamaan tyynyyn, jossa kukaan ei voinut kuulla huutasiavuksi.

### Miksi sillä on merkitystä, se on joka tapauksessa liian myöhäistä

Tämä on harvinaisempi argumentti, mutta se tarvitsee selitystä. Nykyisessä tilassa suurin osa maailman hallituksista, yhdessä useiden voimakkaiden yritysten kanssa, näyttävät tietävän jokaisen liikkeesi. Vastaus on yksinkertainen: ** ansaitset parempaa **. Jos onnistut pääsemään eroon heistä tässä vaiheessa, heidän on vaikeampi seurata liikkeitäsi edelleen, ja voit rakentaa uuden yksityisemmän elämän.

[1 lähde] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Muuten, olen antanut ilmaisen Reddit-palkintoni tälle viestille aina, kun saan sen yli viikon ajan nyt (yhdessä kaikkien 500 ilmaisen kolikon kanssa) lisätä tätä aihetta edelleen. Toistaiseksi olen antanut tämän viestin yli 14 ilmaista palkintoa. Se ei ole paljon, mutta pienillä asioilla voi olla suuri vaikutus riippuen siitä, miten se koetaan ja kenen toimesta.

### Muu

Minulla ei ole muita argumentteja tällä hetkellä.

_Tämä luettelo on epätäydellinen_

***

## Lähteet

Kopio:

[G] (https://fi.wikipedia.org/wiki/Criticism_of_Google) [o] (https://fi.wikipedia.org/wiki/PRISM_ (valvonta_ohjelma)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -huono /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. fi / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -selain /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://fi.wikipedia.org/wiki/Nothing_to_hide_argument# Kritiikki) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a- pelottava-mount-of- data-sinusta-löydät-ja-poista-se-nyt /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes ja [c] (https://www.wired.com/story/google-tracks-you -tietosuoja /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-do-google-piirtää datakokoelmalinjan) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- väitteet 5 miljoonan iphone-käyttäjän puolesta) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaengerss-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technology / 2014/01 / what-google-can-do-do-with-pesä-tai-todella-pesii-data /) [i] (https://www.cbsnews.com/news/google-education -spies-on-kerää tietoja miljoonista lapsista-väittää-oikeusjuttu-uusi-meksiko-oikeusasianajaja /) [v] (https://www.nationalreview.com/2018/04/the- opiskelijatietojen kaivos-skandaali-nenämme alla /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did -have-something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Muut lähteet:

[Viiden silmän allianssi] (https://fi.wikipedia.org/wiki/Five_Eyes) [Yhdeksäntoista kahdeksankymmentäneljä] (https://fi.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Lataa linkit

[Hanki Firefox] (https://www.mozilla.org/en-US/firefox/new/) [Hanki Tor-selain] (https://www.torproject.org/download/) [Muu / ei käytettävissä] (https : //www.esimerkki.fi)

***

## Oma degoogling-kokemukseni

Aloin vihdoin nähdä suurten tekniikoiden ongelmat vuonna 2018, ja aloitin degooglingin. Ensimmäisten kuukausien aikana edistyin merkittävästi. Siitä lähtien se hidastui valtavasti.


### mitä vaihdoin

Google Chrome -> Firefox / Tor

Google-haku -> DuckDuckGo (oletus) / Ecosia (kun minusta tuntuu) / Bing (harvoin)

GMail - ProtonMail (ei vielä täysin kytketty)

Google-sivustot -> Itsepalvelu (ei vielä täysin kytketty)

Google+ -> Tuskin koskaan käytetty, poistanut itsensä oman sammuttamisensa vuoksi

Google Docs -> Ei koskaan käytetty, käytän vain Microsoft Word 2013: ta (ennen vuotta 2019) ja LibreOfficea (vuodesta 2019 eteenpäin).

Google Sheets -> Ei koskaan käytetty, käytän vain Microsoft Excel 2013: ta (ennen vuotta 2019) ja LibreOfficea (vuodesta 2019 eteenpäin).

Google Slides -> Ei koskaan käytetty, käytän vain Microsoft PowerPoint 2013: ta (ennen vuotta 2019) ja LibreOfficea (vuodesta 2019 eteenpäin).

Google-piirustukset -> Ei koskaan käytetty, käytän vain LibreOffice-ohjelmaa (vuodesta 2019 eteenpäin).

Gerrit -> Ei koskaan käytetty, käytän vain GitHubia (nykyinen oletus), GitLab, BitBucket ja SourceForge.

Google Kuvat -> Ei koskaan käytetty

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-nykypäivä)

Google Maps -> OpenStreetMaps / Apple Maps

Go - Erityisen poikkeuksen tekeminen, mutta ei käyttäminen toiminnallisena ohjelmointikielenä

Dart - Erityisen poikkeuksen tekeminen, mutta ei käyttäminen toiminnallisena ohjelmointikielenä

Flutter - Erityisen poikkeuksen tekeminen, mutta ei käyttäminen toiminnallisena ohjelmointikielenä

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> Ei koskaan käytetty, minusta se on erityisen kammottava

Google Fi -> Ei koskaan käytetty

Google-kalenteri -> Ei koskaan käytetty

Google-laskin -> Kirjaimellisesti mikä tahansa muu laskinohjelma, jopa Python-tilassa toimiva Linux-pääte, jos minusta tuntuu

Google Nest -> Ei koskaan käytetty

Google AMP -> Ei koskaan käytetty

Google VPN -> Ei koskaan käytetty, myös oksimoroni

Google Pay -> Ei koskaan käytetty

Google Summer of Code -> Ei koskaan osallistunut

Tenori -> Muut GIF-sivustot, vaikka GIF-tiedostot eivät ole minulle liian tärkeitä. Saan yleensä GIF-tiedostot DuckDuckGo-kuvista, Imgurista, Redditistä tai muilta sivustoilta.

Estetty -> Ei enää käytössä, etkö ole varma, suorittiinko Scratch suoraan estossa. Minusta tuli toimiva ohjelmoija vuodesta 2017 eteenpäin ja kasvoin Scratchista.

GBoard -> Käytetty kerran, mutta hylätty

Google Glass -> Ei koskaan käytetty, pidetään pienenä lapsena, mutta päätti olla hankimatta sitä / käyttämättä sitä, jos minulla olisi mahdollisuus

_Lista voi olla puutteellinen ._

### Tuotteet, joista en silti pääse eroon

Nämä ovat Google-tuotteita, jotka estävät minua täysin hajauttamasta 25. helmikuuta 2021:

1. YouTube

2. Android

3. Google Play Kauppa

4. GMail (vain koululle ja joillekin sivustoille)

5. Google Classroom (vain koulua varten)

6. Google Translate

7. Google-tili

8. Google-sivustot (koska Google rikkoo GDPR: n lakeja (ja voi saada uuden 5 000 000,00 euron sakon, kunnes se korjataan) ja kieltää tämän tuotteen lataamisen)

Olen katsonut kaikesta muusta.

***

## Go on paha

Google höyrytti vuoden 2003 agenttipohjaisen ohjelmointikielen Go! Ohjelmointikielellään Go (vuodesta 2009, kuusi vuotta myöhemmin) ja väitti, että heidän kielensä ei vaikuta lainkaan toiseen kieleen. Googlea kritisoitiin tästä voimakkaasti, koska heidän "Älä ole paha" -motto oli vielä aktiivinen tuolloin, ja tämä on yksi monista tapauksista, jotka saivat "älä ole paha" -elokuvan eläkkeelle.

Loppujen lopuksi `` Go! '' -Kehitys lopetettiin, kun taas `` Go '' tuli yhä yleisemmäksi. Google väitti, etteivät he harhaillut `` Go! '' -Ohjelmaa, mutta lopulta he tekivät, ja he pääsivät siitä eroon (9. huhtikuuta 2021 alkaen)

[Lue lisää Goista ja vuorottelusta täältä] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## DRM: n käyttö

Google käyttää DRM: ää (Digital Restrictions Management) WideVine DRM -palvelunsa ja muiden lomakkeiden kautta. DRM: n tavoitteena on tuhota avoin Internet ja antaa yrityksille monopoliasema käyttäjien suhteen. Sinun pitäisi päästä eroon WideVine-ohjelmasta kokonaan, riippumatta kustannuksista.

[Lue lisää WideVine-ohjelmasta ja sen ongelmista täältä] (https://github.com/Degoogle-your-life/Its-time-leikata-WideVine-DRM)

***

## Yleisiä väärinkäsityksiä

Tämä on luettelo yleisimmistä väärinkäsityksistä Google-tuotteissa.

### Google ei ole Internet

Google / Google-haku ei ole Internet, Google-haku on vain hakukone, eräänlainen kuin kuinka kaikki pelit Nintendo-alustalle eivät ole Nintendon tekemiä, mutta Nintendo on lisensoinut ne, mutta paljon enemmän. Jos kaikki Googlen palvelimet tuhottaisiin samanaikaisesti juuri nyt, vain Google-sivustot, kuten YouTube, Gmail, Google-dokumentit, Google-haku jne., Olisivat poissa, mutta suurin osa Internetistä olisi silti siellä (Wikipedia, Stackoverflow, GitHub, kaikki Microsofts-sivustot, NYTimes, Samsung, TikTok jne.), he saattavat menettää Google-kirjautumis- ja analyyttisen toiminnallisuutensa, mutta ne olisivat silti toimivia (ellei heitä olisi ohjelmoitu heikosti ja luotettu suoraan Googleen)

***

## Internet Explorer 6 ja Chrome

Google Chromesta on tulossa uusi Internet Explorer 6. Kun Google Chrome alun perin ilmestyi, Firefox oli hallitseva selain, ja se oli enimmäkseen tappanut Internet Explorers -markkinoiden jakamisen (joka ylitti 96% ennen miljoonien ihmisten siirtymistä Firefoxiin ja muihin selaimiin), kun Google Chrome tuli ulos, ihmiset vaihtivat sen nopeuden ja Googlen vuoksi (jota ei pidetty tuolloin pahana, koska useimmat yksityisyydensuojakysymykset eivät olleet palanneet vielä) Google Chrome noudatti alun perin verkkostandardeja (mitä Firefox teki joka tappoi Internet Explorerin 96% selaimen markkinaosuudesta), mutta kun Google Chromes -markkinoiden osuus nousi, Google alkoi poistaa yhä enemmän ominaisuuksia, lisätä vakoiluohjelmia ja lopettaa verkkostandardien hyväksymisen, Google Chrome on tullut uusi Internet Explorer 6.

Suurin ongelma on tällä hetkellä vain Chrome-verkkosivustot, jotka eivät toimi muissa selaimissa, koska niiden kehittäjät päättivät, etteivät halua, että muut 30–40% Internetin käyttäjistä, jotka eivät käytä Chromea, käyttävät sivustoaan.

Jopa Google itse tekee sivustoistaan ​​vain Chrome. Esimerkiksi Google-haku kehottaa lataamaan Chromen 3 kertaa 10 sekunnin välein, jos se havaitsee, että et käytä Google Chromea (jopa muut Chromium-pohjaiset selaimet, kuten Brave, vaikuttavat) ja Google Earthin kaltaiset sivustot eivät salli Firefox-käyttäjien käyttävät sivustoaan (vuodesta 2020 lähtien) ja Google Translate ei tue puhesyöttöä Firefoxissa ja muissa muissa kuin Google Chrome -selaimissa.

### Ongelma rohkean kanssa

Muut Chromiumiin perustuvat selaimet, kuten Brave ja Microsoft Edge, eivät ole täysin vapaita Googlen vakoiluohjelmista. Rohkeaa suosittelee yleensä yksityisyyden suojan väärä puoli, mutta rohkea on edelleen ongelma, koska se käyttää Chromiumia. Internetin ei tulisi koostua pelkästään Chromium-selaimista, valinnanvaraa tulisi olla monenlaisia. Rohkea on väärä tapa edetä.

[Lue lisää Google Chromen / Chromiumin poistamisesta täältä] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Lue lisää ChromeOS: n / ChromiumOS: n (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) poistamisesta täältä] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Faux-tietosuoja uusiminen

Google on yrittänyt kertoa maailmalle, että he välittävät yksityisyydestä, kun oli jo liian myöhäistä. He väittävät edelleen kunnioittavansa käyttäjien yksityisyyttä, mutta eivät silti korjaa kaikkia yksityisyysongelmiaan.

### Avoin lähdekoodi ei voi olla osittainen

Avoin lähdekoodi ei voi olla osittainen. Google on todiste tästä. Lähdekoodin jokaisen bitin ja tavun on oltava yleisön nähtävissä, eikä edes kahdeksas tavu ole piilotettu.

Projektit, kuten Android ja ChromeOS, ovat osittain avoimen lähdekoodin, mutta sisältävät suurimman osan omista vakoiluohjelmien elementeistä.

### Itseristiriita

Google VPN on oksimoroni. Google ei välitä yksityisyydestä, ja heidän kaltaisensa yrityksen virtuaalinen yksityinen verkko (VPN) olisi yksi pahimmista mahdollisista vaihtoehdoista VPN-palvelulle.

***

## Huono suorituskyky

Google ei välitä tuotteidensa suorituskyvystä ainakin vuonna 2017, koska heidän viimeinen vertailuohjelmisto (Google Octane) lopetettiin vuonna 2017.

***

## Huono projektinhallinta

Googlella on erittäin huono sisäinen projektinhallintajärjestelmä. Joitakin yleisiä esimerkkejä ohjelmista, jotka ovat päivittyneet yhä uudemmaksi, ovat Google Duo ja YouTube-musiikki (aiemmin Google Play Music)

Googlen sisäisessä kehitysjärjestelmässä yksi sovellus johtaa toiseen sovellukseen, jossa on puolet toiminnoista, sitten alkuperäinen sovellus poistetaan. Pari vuotta myöhemmin tehdään uusi sovellus, jossa on 75% vähemmän toiminnallisuutta, ja sitten sovellus, jonka toiminnot ovat 50%, seuraa uusi sovellus, jonka 87,5% toiminnallisuudesta luodaan, sitten sovellus, jonka toiminnallisuus on 75%, lopetetaan , ja niin edelleen.

***

## Kauhea tai ei maltillista palveluita

YouTube on yleisin esimerkki huonon maltillisuuden maailmassa, joka luo olemassa olevan pahin alustan. Google ei myöskään näytä saavan, että YouTube ei ole YouTube-lapsia.

YouTubessa käyttäjille tarjotaan vihamielistä natseja suosivaa ja valkoista supremacistista sisältöä enemmän sitoutumisaikaa ja enemmän rahaa varten. Google on myös tehnyt joitakin hyvintyhmät asiat maltillisesti, kuten kristillisen anaaliseksivideon hyväksyminen "lapsille tehdyksi" sisällöksi, samalla kun ikä rajoittaa videota. Ei ole myöskään liian harvinaista, että pornografiset tai gore-mainokset ovat oikeassa Baby Shark -videon alla, sekä muita "lapsille tehtyjä" sisältöjä.

YouTube-käyttäjät valittavat erittäin usein huonosta sisällöstä (kuten yllä luetelluista esimerkeistä) YouTuben heikosta maltillisuudesta, kun taas käyttäjät voivat poistaa videonsa satunnaisesti ilman syytä kumoamatta, ja käyttäjiä rangaistaan ​​kaikesta kiroilusta, jopa hyvin pienet tapaukset, kuten sanominen "paska" käyttäjille, vertaa YouTubea yleisesti [Neuvostoliittoon] (https://fi.wikipedia.org/wiki/Soviet_Union) Stalinin aikakaudella näiden eriarvoisten rangaistusten vuoksi.

Vuonna 2021 Google ilmoitti asettavansa mainoksia kaikkiin videoihin huolimatta siitä, että video on demonisoitu (jotta Google ansaitsee rahaa, mutta tekijä ei), tämä ei liity kohtuullisuuteen, mutta on tärkeää huomata.

YouTube on valvottu (vaikkakin erittäin huonosti), mutta Googlen mainospalvelussa, joka tekee heistä suurimman osan rahastaan, näyttää olevan vähän tai ei lainkaan maltillista.

[Lue lisää YouTuben valvontakysymyksistä ja siitä, miten voit vaihtaa YouTubesta] (https://github.com/seanpm2001/Alternating-from-YouTube)

Google Playn mainokset luodaan bottitiloilta, voit kertoa samoilla mainosskenaarioilla, joita sadat yritykset käyttävät pienin muutoksin ja joilla ei ole yhteyttä tuotteeseen (yleisiä esimerkkejä: Playrix (kotimaisemat, puutarhamaisemat) Fishdom, Mafia City ja tuhannet muut) sekä kukoistava haitallinen trendi mainoksista, joissa väitetään, että käyttäjät voivat ansaita rahaa pelaamalla pelejä, kuuntelemalla musiikkia jne. PayPal ei ole kommentoinut tätä, mutta on selvää, että tämä on huijaus, ikään kuin voisit tehdä yli 10 000 dollaria alle 20 sekunnissa pelaamalla taattua peliä, kukaan ei tekisi työtä ja tekisi sen sijaan, mikä on mahdotonta, eikä yritys voi toimia näin. Tämä ilmeinen huijaus on kasvanut voimakkaasti vuodesta 2019 lähtien, ja nyt näitä mainoksia tuottavat bottilit taistelevat keskenään omissa mainoksissaan.

Useat mainokset ovat myös hyvin petollisia ja yrittävät saada käyttäjät (joista suurin osa on alle 13-vuotiaita tai botteja) napsauttamaan seksuaalista manipulaatiota.

Monet sovellukset käyttävät botteja ja astroturf-tuotteitaan, joten aina kun tehdään huono arvostelu, sukkanauhabottitilit alkavat lähettää viiden tähden arvosteluja ja yrittävät kumota kritiikkisi. [Google tekee myös tämän itse] (# Astroturfing)

[Lue lisätietoja Google AdSensen ongelmista] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

Yleinen määritelmä [(Wikipediasta)] (https://fi.wikipedia.org/wiki/Astroturfing)

``
Astroturfing on käytäntö, jolla peitetään viestin tai organisaation sponsorit (esim. Poliittinen, mainonta-, uskonnollinen tai suhdetoiminta), jotta se näyttäisi siltä kuin se olisi peräisin ruohonjuuritason osallistujilta ja sitä tukevat. Se on käytäntö, jonka tarkoituksena on antaa lausunnoille tai organisaatioille uskottavuus pidättämällä tietoja lähteen taloudellisesta yhteydestä. Termi astroturfing on johdettu AstroTurf-tuotemerkistä, synteettisistä matoista, jotka on suunniteltu muistuttamaan luonnollista ruohoa, leikkinä sanalla "ruohonjuuritaso". Termin käytön taustalla on se, että "todellisen" tai "luonnollisen" ruohonjuuritason ponnistelun sijaan kyseisen toiminnan taustalla on "väärennetty" tai "keinotekoinen" tuen ulkonäkö.
``

Googlella on ollut astroturfing-historia, jotta näyttää siltä, ​​että he eivät tee mitään pahaa (prosessin aikana astroturfing on pahaa), esimerkiksi Googlen kritiikin lähettäminen Twitterin kaltaiselle alustalle (jolla heillä on tili) johtaa useita tilejä, jotka ovat olleet jonkin aikaa olemassa, mutta joita ei ole koskaan julkaistu ennen ilmoittautumista ja väittämistä, että sanomasi on väärä, ja väittäen sitten, että Google on paras yritys, mutta tehty tavalla, joka ei välttämättä ole ilmeistä, että nämä ovat botteja useimmille ihmiset.

***

## Laittomat ja epäeettiset liiketoimintatavat

Google käyttää laitonta ja epäeettistä liiketoimintatapaa monopolinsa edistämiseen, kuten veroparatiisien käyttö, työpaikkojen ulkoistaminen ja laittoman invasiivisen toiminnan jatkaminen liiketoiminnan kustannuksena.

### Euroopassa

Eurooppa on haastanut Googlen usein, suurin oikeusjuttu on laitonta käyttäytymistä vastaan ​​Androidissa, minkä seurauksena Google sai 5 000 000 000 euroa (vastaten 5 947 083 703,68 dollaria 9. huhtikuuta 2021).

### Pohjois-Amerikassa

Yhdysvallat ei ole vielä antanut Googlelle melkein tarpeeksi sakkoa, kun taas eurooppalaisten sakkojen määrä on 5 000 000 000 euroa.

### Kiistat

Google ei välitä ongelmasta, ennen kuin se aiheuttaa kiistan, sitten he yrittävät huonosti yrittää korjata sen, riittää, että kiista poistuu väliaikaisesti, ja sitten ongelma pahenee eksponentiaalisesti, kunnes se aiheuttaa uuden kiistan, ja sykli jatkuu. He eivät yksinkertaisesti välitä tarpeeksi tekemään mitään vakavaa asialle.

***

## Google on automatisoitu

Koska comGoogle on enimmäkseen automatisoitu, vähemmän maltillista kuin automaatio.

Yritystä ei pitäisi täysin automatisoida. Google on esimerkki tästä. Kohtuutus on kamalaa, kun vain tekoäly tekee sen, YouTube on hyvä esimerkki, vaikka muutama ylimääräinen (satoja tai ehkä tuhat) ihmistä moderoisi sivustoa, jossa se on ilmeisesti niin huono, että useimpien heidän on hoidettava työskennellessään.

***

## Android

Android omistaa Google. Osa Open Handset Alliancesta (joka ei ole ollut auki Androidin jälkeen) Androidista on tullut toinen monopoliasema Googlelle ja erittäin vaikea paeta.

Androidin on ilmoitettu soittaneen Googlen kotiin vähintään 10 kertaa päivässä, ja huolimatta osittain avoimen lähdekoodin toiminnasta, se toimii edelleen voimakkaasti vakoiluohjelmana.

Useita projekteja on luotu vuorotellen Androidista, mutta ne edellyttävät laitteen juurtumista. Tämä ei yksinkertaisesti ole enää mahdollista tietyille Samsung-puhelimille Yhdysvalloissa Knox DRM: n takia. Yleisimpiä vaihtoehtoja Androidille ovat iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch ja PiPhone (Pi Phone on tuotemerkki puhelimista, jotka käyttävät erilaisia ​​Linux-järjestelmiä mobiililaitteilla, kuten Fedora, Ubuntu, Arch jne.)

[Katso tutkimukseni siitä, miten Androidin virtuaalikone voidaan poistaa käytöstä) (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Katso, miten deglugata Androidista] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Pienet toimet auttamiseksi

Tietoisuuden levittäminen kaikin mahdollisin tavoin on tärkeää. Minulle en vain puhu usein degooglingista ja kirjoitan artikkeleita, mutta minulla on myös pieni pieni tapa, jossa annan päivittäisen ilmaisen Reddit-palkintoni r / degooglen kiinnitetylle viestille tietoisuuden lisäämiseksi. Tähän mennessä olen antanut lähes 30 palkintoa kiinnitetylle postille (käytin myös 500 ilmaista kolikkoa 10 palkintoon kyseisestä viestistä)

***

## Epäluotettava

Googleen ei voida luottaa eikä koskaan enää koskaan. He ovat siirtyneet kokonaan "älä ole pahaa" (he olivat aina pahoja) vain olemaan täysin pahoja eivätkä yrittäneet salata sitä.

***

## Muita tarkistettavia asioita

[Google Graveyard (killbygoogle.com) - lajiteltu luettelo yli 224 tuotteesta, jonka Google on tappanut] (https://killedbygoogle.com/)

> [GitHub-linkki] (https://github.com/codyogden/killedbygoogle)

[Aakkosellinen työntekijäliitto - Googlen uusi työntekijäjärjestö, jossa on yli 800 jäsentä] (https://alphabetworkersunion.org/people/our-union/)

[Etkö halua erota dinosaurus pääsiäismunasta? Tämä verkkosivusto on katettu] (https://chromedino.com/)

On muita vaihtoehtoja, etsi vain niitä.

***

Tässä artikkelissa tarvitaan jonkin verran tosiseikkoja

***

## Tiedoston tiedot

Tiedostotyyppi: `Markdown (* .md)`

Rivien lukumäärä (tyhjät rivit ja kääntäjärivi mukaan lukien): "968"

Tiedostoversio: "6 (sunnuntaina 18. huhtikuuta 2021 klo 16.18)"

***

### Ohjelmiston tila

Kaikilla teoksillani on joitain rajoituksia. DRM (** D ** igital ** R ** estektiot ** M ** anagement) ei ole missään teoksissani.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Tätä tarraa tukee Free Software Foundation. En koskaan aio sisällyttää DRM: ää teoksihini.

Käytän lyhennettä "Digital Restrictions Management" tunnetumman "Digital Rights Management": n sijaan, koska yleinen tapa puuttua siihen on väärä, DRM: llä ei ole oikeuksia. Oikeinkirjoitus "Digital Restrictions Management" on tarkempi, ja sitä tukevat [Richard M. Stallman (RMS)] (https://fi.wikipedia.org/wiki/Richard_Stallman) ja [Free Software Foundation (FSF)] ( https://fi.wikipedia.org/wiki/Free_Software_Foundation)

Tätä osaa käytetään lisäämään tietoisuutta DRM-ongelmista ja myös vastustamaan sitä. DRM on rakenteeltaan viallinen ja on suuri uhka kaikille tietokoneen käyttäjille ja ohjelmistovapaudelle.

Kuvahyvitys: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Sponsoritiedot

! [SponsorButton.png] (SponsorButton.png) <- Älä napsauta tätä painiketta, se ei toimi, se on vain kuva. Todellinen painike on sivun yläreunassa oikeassa (<- L ** R ** ->) kulmassa

Voit sponsoroida tätä projektia, jos haluat, mutta täsmennä, mihin haluat lahjoittaa. [Katso varat, joita voit lahjoittaa täältä] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Voit tarkastella muita sponsoritietoja [täällä] (https://github.com/seanpm2001/Sponsor-info/)

Kokeile! Sponsoripainike on aivan katselu- / katselupainikkeen vieressä.

***

## Tiedostohistoria



 * Käynnisti tiedosto

> * Lisätty otsikko-osa

> * Lisätty hakemisto

> * Lisätty Tietoja-osio

> * Lisätty Wiki-osio

> * Lisätty versiohistoria-osio

> * Lisäsi aihealueen.

> * Lisäsi aiemmat numerot -osion

> * Lisättiin aikaisemmat vetopyynnöt

> * Lisätty aktiivisten vetopyyntöjen osio

> * Lisätty avustajat-osio

> * Lisätty avustava osa

> * Lisäsi about README -osion

> * Lisäsi README-versiohistoria-osan

> * Lisätty resurssit-osio

> * Lisätty ohjelmiston tilaosio, jossa on DRM-vapaa tarra ja viesti

> *Lisätty sponsorin tiedot -osio

> * Ei muita muutoksia versiossa 0.1

Versio 1 (perjantai 19. helmikuuta 2021 klo 17.20)

> Muutokset:

> * Käynnisti tiedosto

> * Lisätty kuvauksen perusosa

> * Lisätty arkiston kuvausosa

> * Lisätty artikkeliluettelo, jossa on 14 merkintää

>> * Lisäsi osion `aiheeseen liittyvät artikkelit`

>> * Lisätty `katso myös` -osa

> * Lisäsi tiedostotiedot-osion

> * Lisätty tiedostohistoria-osio

> * Lisätty alatunniste

> * Ei muita muutoksia versiossa 1

Versio 2 (perjantai 19. helmikuuta 2021 klo 17.26)

> Muutokset:

> * Lisätty käännöksen tila -osio

> * Lisäsi Muut tarkistettavat -osan

> * Lisätty yksityisyysosio

> * Lisätty hakemisto

> * Lisätty ohjelmiston tila-alaosio

> * Lisäsi muut Google-vastaisten kampanjoiden osiot

>> * Lisättiin poistettu alaosio

>> * Lisäsi meneillään olevan alaosan

> * Lisätty lähde-osio

> * Lisäsi latauslinkit-osion

> * Päivitetty tiedostotiedot

> * Päivitetty tiedostohistoria-osio

> * Ei muita muutoksia versiossa 2

Versio 3 (keskiviikkona 24. helmikuuta 2021 klo 19.56)

> Muutokset:

> * Päivitetty hakemisto

> * Viittasi degoogle-kuvakkeeseen ja uuteen GitHub-organisaatioon

> * Lisätty linkkejä uudempiin artikkeleihin

> * Lisäsi laskurin muut argumentit -osion

>> * Lisätty mukavuusosio

>> * Lisättiin Miksi edes häiritä -osio

>> * Lisätty toinen alaosa

> * Päivitetty joitain tietoja

> * Päivitetty tiedostotiedot

> * Päivitetty tiedostohistoria-osio

> * Ei muita muutoksia versiossa 3

Versio 4 (torstaina 25. helmikuuta 2021 klo 21.31)

> Muutokset:

> * Lisätty linkkejä 10 uuteen artikkeliin

> * Lisäsi osion kokemuksistani

> * Päivitetty hakemisto

> * Päivitetty tiedostotiedot

> * Päivitetty tiedostohistoria-osio

> * Ei muita muutoksia versiossa 4

Versio 5 (perjantai 9. huhtikuuta 2021 klo 18.02)

_ Google-vastaisen liikkeen päivityksistä on puuttunut viime aikoina, yritän palata siihen yli 1 kuukauden tauon jälkeen.

> Muutokset:

> * Päivitetty otsikkokohta

> * Päivitetty hakemisto

> * Päivitetty kieliluettelo: kiinteät linkit ja lisää tuettuja kieliä

> * Päivitetty artikkelin tilaosio lisäämällä 4 haarukkalinkkiä

> * Päivitetty ohjelmiston tila -osio

> * Lisätty Go is evil -osio

> * Lisäsi DRM-käytön osion

> * Lisätty Yleiset väärinkäsitykset -osa

>> * Lisätty Google ei ole Internet-alaosio

> * Lisätty Internet Explorer 6 ja Chrome -osio

>> * Lisäsi ongelman Brave-alaosaan

> * Lisätty Faux-yksityisyyden poisto

> * Lisätty Avoin lähdekoodi ei voi olla osittainen alaosio

> * Lisätty Oxymoron-alaosio

> * Lisätty Huono suorituskyky -osio

> * Lisätty Huono projektinhallinta -osa

> * Lisätty Palvelujen kauhea tai ei lainkaan maltillinen -osa

> * Lisätty Astroturfing-osio

> * Lisätty laitonta ja epäeettistä liiketoimintaa koskeva osio

> * Lisätty Euroopassa-alaosio

>> * Lisätty Pohjois-Amerikassa -alajako

>> * Lisättiin Kiistat-alaosio

> * Lisätty Google is automatized -osio

> * Lisätty Android-osio

> * Lisätty Pienet toimet -osiossa osio

> * Lisäsi Epäluotettava-osion

> * Lisätty sponsorin tiedot -osio

> * Päivitetty alatunniste

> * Päivitetty tiedostotiedot

> * Päivitetty tiedostohistoria-osio

> * Ei muita muutoksia versiossa 5

Versio 6 (sunnuntaina 18. huhtikuuta 2021 klo 16.18)

> Muutokset:

> * Päivitetty hakemisto

> * Lisätty uusi yleiskuvaus

> * Päivitetyt artikkelin tilatiedot

> * Lisäsi linkin uuteen Google FLoC -artikkeliin

> * Lisäsi linkin Wuest 3n Fuchs Degoogle -artikkeliin ja yleistä tietoa siitä

> * Päivitetty tiedostotiedot

> * Päivitetty tiedostohistoria-osio

> * Ei muita muutoksia versiossa 6

Versio 7 (Tulossa pian)

> Muutokset:

> * Tulossa pian

> * Ei muita muutoksia versiossa 7

Versio 8 (Tulossa pian)

> Muutokset:

> * Tulossa pian

> * Ei muita muutoksia versiossa 8

Versio 9 (Tulossa pian)

> Muutokset:

> * Tulossa pian

> * Ei muita muutoksia versiossa 9

Versio 10 (Tulossa pian)

> Muutokset:

> * Tulossa pian

> * Ei muita muutoksia versiossa 10

Versio 11 (Tulossa pian)

> Muutokset:

> * Tulossa pian

> * Ei muita muutoksia versiossa 11

Versio 12 (Tulossa pian)

> Muutokset:

> * Tulossa pian

> * Ei muita muutoksia versiossa 12

***

## Alatunniste

Olet tullut tämän tiedoston loppuun

([Takaisin alkuun] (# ylös) | [Palaa GitHubiin] (https://github.com))

### EOF

***
