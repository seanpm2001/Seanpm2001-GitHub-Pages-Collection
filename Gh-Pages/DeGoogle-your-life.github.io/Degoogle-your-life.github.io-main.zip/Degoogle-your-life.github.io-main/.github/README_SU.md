***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle hirup anjeun

Ieu artikel degoogling utama kanggo inpo degoogling umum sareng tautan kana artikel anu sanés.

[Tingali daptar salaku organisasi GitHub] (https://github.com/Degoogle-your-life)

***

_Baca tulisan ieu dina basa anu béda: _

** Bahasa ayeuna nyaéta: ** `English (US)` _ (tarjamahan panginten kedah dilereskeun kanggo ngalereskeun basa Inggris ngagentos bahasa anu leres) _

_🌐 Daptar bahasa_

** Diurutkeun ku: ** `A-Z`

[Pilihan asihan henteu sayogi] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albania | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) Arab | [hy հայերեն] (/. github / README_HY.md) Armenia | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijan | [eu Euskara] (/. github /README_EU.md) Basque | [janten Беларуская] (/. Github / README_BE.md) Bélarus | [bn বাংলা] (/. Github / README_BN.md) Benggali | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) Bulgaria | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Cina (Disederhanakeun) | [zh-t 中國 國 的）] (/. github / README_ZH -T.md) Cina (Tradisional) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Kroasia | [cs čeština] (/. Github / README_CS .md) Czech | [da dansk] (README_DA.md) Denmark | [nl Nederlands] (/. github / README_ NL.md) Walanda | [** en-us English **] (/. github / README.md) Inggris | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Éstonia | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finlandia | [fr français] (/. github / README_FR.md) Perancis | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galicia | [ka ქართველი] (/. github / README_KA) Georgia | [de Deutsch] (/. github / README_DE.md) Jérman | [el Ελληνικά] (/. github / README_EL.md) Yunani | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaii | [anjeunna עִברִית] (/. github / README_HE.md) Ibrani | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hungaria | [nyaéta Íslenska] (/. github / README_IS.md) Islandia | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandia | [ga Gaeilge] (/. github / README_GA.md) Irlandia | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Jepang | [jw Wong jawa] (/. github / README_JW.md) Java | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-kidul 韓國 語] (/. github / README_KO_SOUTH.md) Koréa (Kidul) | [ko-kalér 문화어] (README_KO_NORTH.md) Koréa (Kalér) (TEU BISA DITERJAR) [ku Kurdî] (/. github / README_KU.md) Kurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kyrgyz | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lituania | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksemburg | [mk Македонски] (/. github / README_MK.md) Macedonian | [mg Malagasi] (/. github / README_MG.md) Malagasi | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Malta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolian | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Burma) | [ne नेपाली] (/. github / README_NE.md) Nepali | [henteu norsk] (/. github / README_NO.md) Norwegia | [atanapi ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persia [pl polski] (/. github / README_PL.md) Polandia | [pt português] (/. github / README_PT.md) Portugis | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Teu aya basa anu dimimiti ku huruf Q | [ro Română] (/. github / README_RO.md) Romania | [ru русский] (/. github / README_RU.md) Rusia | [sm Faasamoa] (/. github / README_SM.md) Samoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scots Gaelic | [sr Српски] (/. github / README_SR.md) Serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slowakia] (/. github / README_SK.md) Slowakia | [sl Slovenščina] (/. github / README_SL.md) Slovenia | [jadi Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spanyol | [su Sundanis] (/. github / README_SU.md) Sundanis | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Swédia | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెల English] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thailand | [tr Türk] (/. github / README_TR.md) Turki | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukraina | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnam | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Sadia dina 110 basa (108 nalika henteu kaétang Inggris sareng Koréa Kalér, sabab Koréa Kalér teu acan ditarjamahkeun [Maca ngeunaan ieu di dieu] (/ OldVersions / Korea (Kalér ) /README.md))

Tarjamahan dina basa sanés basa Inggris anu ditarjamahkeun ku mesin sareng teu akurat. Teu aya kasalahan anu parantos dibéréskeun dugi ka 5 Pébruari 2021. Punten laporkeun kasalahan tarjamahan [didieu] (https://github.com/seanpm2001/Degoogle-your-life/issues/) pastikeun nyadangkeun koréksi anjeun sareng sumber sareng nungtun kuring , sabab kuring henteu terang bahasa anu sanés basa Inggris ogé (kuring rarancang bakal kéngingkeun penerjemah antukna) punten nyebatkeun [wikipedia] (https://en.wiktionary.org) sareng sumber sanés dina laporan anjeun. Gagal ngalakukeunana bakal ngahasilkeun panolakan kana koreksi anu diterbitkeun.

Catetan: kusabab keterbatasan sareng interpretasi GitHub ngeunaan markdown (sareng seueur unggal penafsiran markdown dumasar kana wéb sanés) ngaklik tautan ieu bakal ngarahkeun anjeun kana file anu misah dina halaman anu sanés halaman profil GitHub kuring. Anjeun bakal dialihkeun ka [seanpm2001 / seanpm2001 Repository] (https://github.com/seanpm2001/seanpm2001), dimana README disimpen.

Tarjamahan parantos dilakukeun ku Google Translate kusabab terbatas atanapi henteu aya dukungan pikeun basa-basa anu kuring peryogikeun dina jasa tarjamahan anu sanés sapertos DeepL sareng Bing Translate (anu ironis pisan pikeun kampanye anti Google) Kuring nuju milarian milarian alternatif. Kusabab kitu, pormatna (tautan, pamisah, kandel, miring, sareng sajabana) kacau dina sababaraha tarjamahan. Éta matak ngamudahkeun pikeun ngalereskeun, sareng kuring henteu terang kumaha ngalereskeun masalah ieu dina basa anu nganggo karakter sanés latin, sareng basa katuhu ka kénca (sapertos basa Arab) peryogi bantosan tambahan pikeun ngalereskeun masalah ieu

Kusabab masalah pangropéa, seueur tarjamahan anu kadaluarsa sareng nganggo pérsi kuno tina file artikel `README` ieu. Panarjamah peryogi. Ogé, dugi ka 9 April 2021, éta bakal ngabutuhkeun kuring bari nyandak sadaya tautan énggal jalan.

***

## Indéks

[00.0 - Judul] (# Degoogling --- Degoogle-your-life)

> [00.1 - Indéks] (# Indéks)

[01.0 - Pedaran dasar] (# Dasar-katerangan)

> [01.1 - Lulugu Repository] (# Degoogle-your-life)

> [01.2 - Ihtisar pedaran Wuest3NFuchs] (# Ihtisar-ku-Wuest3nFuchs)

>> [01.2.1 - Naon maksadna?] (# What-does-it-mean - by-Wuest3nFuchs)

>> [01.2.2 - Naha Degoogle?] (# Naha-Degoogle - ku-Wuest3nFuchs)

[02.0 - Tulisan] (# Tulisan)

[03.0 - Privasi] (# Privasi)

[04.0 - Kampanye anti Google sanés] (# Lain-anti-Google-kampanye)

> [04.0.1 - Defunct] (# Defunct)

> [04.0.2 - Sateuacanna] (# Lumangsung)

[05.0 - Ngalawan alesan anu sanés] (# Counter-other-arguments)

> [05.0.1 - genah] (# genah)

> [05.0.2 - Naha masalahna? Kasép teuing kumaha ogé] (# Naha-henteu-masalah, -ieu-kasép-ogé)

> [05.0.3 - Lain] (# Lain)

[06.0 - Sumber] (# Sumber)

[07.0 - Unduh tautan] (# Unduh-tautan)

[08.0 - Pangalaman degoogling abdi] (# Pangalaman-degoogling-abdi)

> [08.1 - Naon anu kuring ngalihkeun] [# Naon-abdi-ngalih-ti)

> [08.2 - Produk anu kuring masih henteu tiasa uih tina] (# Produk-I-masih-henteu-tiasa-lepas-ti)

[09.0 - Hal-hal sanés anu kedah diperhatoskeun] (# Lain-hal-pikeun-dipariksa)

[10.0 - Inpo file] (# File-info)

> [10.1 - Status parangkat lunak] (# Parangkat lunak-status)

> [10.2 - Inpo sponsor] (# Inpormasi-sponsor)

[11.0 - Sejarah file] (# File-history)

[12.0 - Pijak] (# Pijak)

***

## Pedaran dasar

[Tina Wikipedia: Degoogle] (https://id.wikipedia.org/wiki/DeGoogle)

Gerakan DeGoogle (ogé disebut gerakan de-Google) mangrupikeun kampanye akar rumput anu parantos nyababkeun salaku aktivis privasi ngadesek pangguna pikeun ngeureunkeun panggunaan produk Google sapinuhna kusabab masalah privasi anu ningkat ngeunaan perusahaan. Istilah ieu ngarujuk kana tindakan ngaleungitkeun Google tina kahirupan seseorang. Nalika pangsa pasar anu ngembang tina raksasa internét nyiptakeun kakuatan monopolistik pikeun perusahaan di rohangan digital, beuki seueur wartawan nyatet kasusah pikeun milarian alternatif pikeun produk perusahaan.

** Sejarah **

Dina 2013, John Koetsier ti Venturebeat nyarios tablet berbasis Android Kindle Fire Android mangrupikeun "versi de-Google-ized tina Android." Dina 2014 John Simpson ti US News nyerat ngeunaan "hak dipohokeun" ku Google sareng mesin pencari anu sanés. Dina 2015, Derek Scally ti Irlandia Times nyerat tulisan ngeunaan kumaha "De-Google hirup anjeun." Dina 2016 Kris Carlon ti Android Otoritas nyarankeun yén pangguna CyanogenMod 14 tiasa "de-Google" teleponna, kusabab CyanogenMod tiasa dianggo kalayan saé tanpa aplikasi Google ogé. Dina 2018 Nick Lucchesi ti Inverse nyerat ngeunaan kumaha ProtonMail promosi kumaha "tiasa lengkep de-Google-ngabahekeun kahirupan anjeun." Lifehacker Brendan Hesse nyerat tutorial anu lengkep ngeunaan "kaluar tina Google." Wartawan Gizmodo Kashmir Hill nyatakeun yén anjeunna sono rapat sareng ngalaman kasusah ngatur pendaptaran tanpa nganggo Kalénder Google. Dina 2019, Huawei masihan ngabalikeun duit ka pamilik telepon di Filipina anu dipeungpeuk tina ngagunakeun jasa anu disayogikeun ku Google kusabab kitu aya sababaraha alternatif anu henteuna produk perusahaan janten internét normal henteu tiasa dianggo.

***

# Degoogle-hirup anjeun
Repository kanggo inpo degoogling umum sareng tautan ka Repository degoogling anu sanés.

***

## Ihtisar ku Wuest3nFuchs

Katerangan anu langkung saé, disayogikeun ku [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - sumber: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Naon éta hartosna? ku Wuest3nFuchs

Degoogling hartosna lirén nganggo naon waé anu kagungan Google, naon waé anu didamel ku Google. Abdi nyarioskeun mesin pencari, jasa suratna (Gmail), Youtube, jst.

### Naha Degoogle? ku Wuest3nFuchs

Google mangrupikeun perusahaan anu paling kuat di dunya ayeuna. Aranjeunna parantos nyimpen seueur inpormasi pikeun urang sadayana. Sababaraha bakal ngajawab yén inpormasi kami aman sareng aranjeunna sabab terang kumaha ngajagaana. Tapi ieu henteu leres. Google parantos ditembus sateuacanna sareng éta bakal ditembus kapayunna. Meureun sanés ku sababaraha naskah budak tapi bakal dilakukeun ku nagara bangsa. Google nyimpen inpormasi pribadi ka urang sadayana kusabab ieu cara ngasilkeun artos.

Aranjeunna nyeken email kami, nyimpen naon anu urang milarian nalika kami nganggo mesin pencari, naon video anu urang nonton dina Youtube. Ieu kumaha aranjeunna nargétkeun kami sareng ngawangun profil pikeun kami pikeun nunjukkeun sababaraha iklan dumasar kana naon anu kami ngobrolkeun sareng sahabat kami ngarah aranjeunna tiasa nunjukkeun iklan pikeun hal anu urang butuhkeun, tapi ieu teuing menyeramkeun. Hatur nuhun ka Mr. Snowden urang ayeuna terang yén Google parantos ngabagi inpormasi pribadi kami sareng NSA dina program anu disebut ** "PRISM" **.


Ka hareupna batur bakal tiasa ngaksés sadaya inpormasi éta sareng kuring mastikeun yén aya kajadian anu parah bakal kajadian. Pikeun nyegah kajadian éta, anjeun kedah ngamimitian Degoogling ayeuna. Ogé anjeun henteu kedah nganggo produk ku perusahaan anu ngabagi data anjeun sareng ** NSA **. Anjeun kedah lirénkeun sadayana ieu ku degoogling.

** Upami jalma sanés tiasa ngalakukeun éta, anjeun ogé tiasa ngalakukeun éta. **

[Maca deui didieu] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Tautan kana garpu ayeuna henteu didaptarkeun, sabab kuring henteu ngagaduhan gudang ieu sadayana, sareng hoyong ngamajukeun sumber anu sanés. Éta bakal egois numbu ka https://github.com/Degoogle-your-life/Degoogle kuring sorangan! ->

***

## Tulisan

### Status tulisan

_Sakabéh tulisan ayeuna nuju jalan sareng kedah diénggalkeun. Saran sareng ngalereskeun diidinan._

_Sopet 18 April 2021 jam 4:09 siang, kaseueuran tulisan teu acan dimimitian. Kuring nuju milarian milarian waktos sareng usaha pikeun ngamimitianana._

[Naha anjeun kedah lirén nganggo Google Chrome] (https://github.com/seanpm2001/Naha-you-should-stop-using-Chrome) <! - 1! ->

[Eureun nganggo ChromeBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Eureun nganggo WideVine DRM / Waktosna kanggo motong WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Naha anjeun kedah lirén nganggo ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Alternating ti YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Eureun Googling, naha anjeun kedah lirén nganggo Pilarian Google] (https://github.com/seanpm2001/Stop-Googling-- Naha-you-should-stop-using-Google-Search) <! - 6! - >

[Naha anjeun kedah lirén nganggo Gmail] (https://github.com/seanpm2001/Naha-you-should-stop-using-GMail) <! - 7! ->

[Naha anjeun kedah lirén nganggo Android] (https://github.com/seanpm2001/Naha-you-should-stop-using-Android) <! - 8! ->

[Naha anjeun kedah nyingkahan Google Amp] (https://github.com/seanpm2001/Naha-you-should-avoid-Google-AMP) <! - 9! ->

[Naha anjeun kedah lirén nganggo Google Drive] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-Drive) <! - 10! ->

[Naha anjeun kedah lirén nganggo Google Maps sareng Google Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Hei Google, lirén] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Eureun maca tina buku Google / Play] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Eureun nganggo Google Classroom] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Kunaon anjeun kedah lirén nganggo Google Tarjamah] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-Translate) <! - 15! ->

[Kunaon anjeun kedah lirén nganggo Akun Google anjeun (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Account) <! - 16! ->

** Tulisan anyar anu badé ditulis: **

[Kunaon anjeun kedah lirén nganggo Gerrit] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Kunaon anjeun kedah lirén nganggo Google Analytics (Repository rusak di tungtung kuring ti dinten Rebo, 24 Pébruari 2021 tabuh 4: 13 pm)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics) <! - 18! ->

<! - Pembagi kerja! ->

[Naha anjeun kedah lirén nganggo Google AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Naha anjeun kedah lirén nganggo Google One] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-One) <! - 20! ->

[Naha anjeun kedah lirén nganggo Google+ (teu nganggo)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Naha anjeun kedah lirén nganggo Google Play Store] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Kunaon anjeun kedah lirén nganggo Google Docs] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Naha anjeun kedah lirén nganggo Google Slides] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Kunaon anjeun kedah lirén nganggo Google Sheets] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Kunaon anjeun kedah lirén nganggo Google Forms] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Naha anjeun kedah lirén nganggo Google Cardboard] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Kunaon anjeun kedah lirén nganggo Google Messages] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Naha anjeun kedah lirén nganggo Desain Bahan Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Naha anjeun kedah lirén nganggo Google Glass / Kacamata] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Naha anjeun kedah lirén nganggo Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Kunaon anjeun kedah lirén nganggo GBoard] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Naha anjeun kedah lirén nganggo Google Home] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-Home) <! - 33! ->

[Naha anjeun kedah lirén nganggo Google Nest] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-Nest) <! - 34! ->

[Naha anjeun kedah lirén nganggo Google Hangouts (teu nganggo)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Naha anjeun kedah lirén nganggo Google Duo] (https://github.com/seanpm2001/Ngaon-you-should-stop-using-Google-Duo) <! - 36! ->

[Naha anjeun kedah lirén nganggo Google Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Naha anjeun kedah lirén nganggo Google Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Naha anjeun kedah lirén nganggo Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Kunaon anjeun kedah lirén nganggo basa pamrograman Googles Go] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Naha anjeun kedah lirén nganggo basa pamrograman Googles Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Naha anjeun kedah lirén nganggo format gambar Googles WebP] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Naha anjeun kedah lirén nganggo format video Googles WebM] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Naha anjeun kedah lirén nganggo Google Video] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-Video) <! - 44! ->

[Naha anjeun kedah lirén nganggo Situs Google (klasik)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Naha anjeun kedah lirén nganggo Situs Google ("Anyar")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Naha anjeun kedah lirén nganggo Google Pay] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-Pay) <! - 47! ->

[Kunaon anjeun kedah lirén nganggo Android Pay] (https://github.com/seanpm2001/Naha-you-should-stop-using-Android-Pay) <! - 48! ->

[Naha anjeun kedah lirén nganggo Google VPN (oxymoron)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Naha anjeun kedah lirén nganggo Poto Google] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-Photos) <! - 50! ->

[Naha anjeun kedah lirén nganggo Google Kalénder] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-Calendar) <! - 51! ->

[Naha anjeun kedah lirén nganggo VirusTotal (kumargi éta parantos dipimilik ku Google ti Séptémber 2012] (https://github.com/seanpm2001/Naha-you-should-stop-using-VirusTotal) <! - 52! - >

[Naha anjeun kedah lirén nganggo Google Fi] (https://github.com/seanpm2001/Ngaon-you-should-stop-using-Google-Fi) <! - 53! ->

[Naha anjeun kedah lirén nganggo Google Stadia] (https://github.com/seanpm2001/Ngaon-you-should-stop-using-Google-Stadia) <! - 54! ->

[Naha anjeun kedah lirén nganggo Google Keep] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-Keep) <! - 55! ->

[Naha anjeun kedah lirén nganggo Google Base] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-Base) <! - 56! ->

[Naha anjeun kedah lirén ilubiung dina Musim Panas Kodeu Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Naha anjeun kedah lirén nganggo Kaméra Google] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-Camera) <! - 58! ->

[Naha anjeun kedah lirén nganggo Google Calculator (sigana katingalina ekstrim, tapi anjeun kedah degoogle tina sagala hal, gampang pisan diganti)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Kalkulator) <! - 59! ->

[Naha anjeun kedah lirén nganggo Google Survey + hadiah] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Kunaon anjeun kedah lirén nganggo Gambar Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Kunaon anjeun kedah lirén nganggo Tenor (situs GIF, milik Google ti saprak 2019)] (https://github.com/seanpm2001/Naha-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Naon FLoC - Naha anjeun kedah nyingkahan masalah googles FLoCing ageung (lirén nganggo Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Total tulisan: ** `63`

** Tulisan [roadmap AB] (DegoogleCampaign_2021Roadmap_Part1.md) (dugi ka 12 Maret 2021) 2 dinten deui **

** Tulisan [roadmap BB] (DegoogleCampaign_2021Roadmao_Part2.md) (dugi ka? 2021) cuti 2 dinten **

Status tulisan

Sadaya tulisan ayeuna nuju hasil sareng kedah diénggalkeun. Saran sareng ngalereskeun diijinkeun.

** Garpu **

Ngembangna jaringan Degoogle kuring, sareng nambihan sababaraha gampang aksés, sareng ngagorowok komunitas.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Forked from: [https://github.com/wacko1805/Fossapps Ingles(https://github.com/wacko1805/Fossapps) (Inggris)

2. [Tautan Privasi] (https://github.com/Degoogle-your-life/Privacy-links) | Garpu tina: [https://github.com/Arturro43/privacy-linksgris(https://github.com/Arturro43/privacy-links) (Polandia)

3. [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Forked ti: [https://github.com/LinuxCafeFederation/Delightful-Privacy Ingles(https://github.com/LinuxCafeFederation/Delightful-Privacy) (Inggris)

4. [Blocklists] (https://github.com/Degoogle-your-life/blocklists) | Forked from: [https://github.com/jmdugan/blocklists Ingles(https://github.com/jmdugan/blocklists) (Inggris)

5. [Degoogle, ku Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Forked ti: [https://github.com/Wuest3nFuchs/Degoogle Ingles(https://github.com/Wuest3nFuchs/Degoogle) (Inggris)

** Patali **

[Panalitian Mesin Virtual telepon Android Degoogled] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

** Tingali ogé: **

[Kritik Google di Wikipedia] (https://id.wikipedia.org/wiki/Criticism_of_Google)

[The Google Graveyard (slaybygoogle.com) - daptar diurut tina 224+ produk anu ditelasan ku Google] (https://killedbygoogle.com/)

> [Tautan GitHub] (https://github.com/codyogden/killedbygoogle)

[Union union pekerja - Serikat pekerja anyar di Google kalayan langkung ti 800 anggota] (https://alphabetworkersunion.org/people/our-union/)

[Entong pisah sareng endog easter dinosaurus? Halaman wéb ieu parantos anjeun rangkep] (https://chromedino.com/)

***

## Privasi

[G] (https://id.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico- Children-privacy-school-chromebook-lawsuit)[sopito(https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https:// Medium.com/digiprivacy/i-stopping-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acqu acquisition-he data-alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/site/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument # Kritik) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -essay-sampel / nanaon-pikeun-sumputkeun-argumen-teu-nanaon-ngomong /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- of-data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -your-personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -monetizes-and) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- koleksi-wangsit.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ health-fitness-data-privacy /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks] [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-government-google-data-koleksi-gugatan-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)[o Ingles(https://en.wikipedia.org/wiki/2018_Google_data_breach)[mopito(https://moz.com /blog/where-does-google-draw-the-data-collection-line)[eiwan(https://mashable.com/article/google-android-data-collection-study/)[sopito(https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)[o Ingles(https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -klaim-atas-pikeun-5-m illion-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/)[ropito(https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/)[i Ingles(https://www.cbsnews.com/news/google-education-spies-on-collects- data-dina-jutaan-budak-ngagugat-gugatan-anyar-mexico-jaksa-umum /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / teknologi / google-yout ube-fine-ftc.html) [y] (https:// Medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : // Medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Abdi tiasa neraskeun sareng teras ku bukti ieu, tapi peryogi lami pikeun milarian sareng ngalangkungan ieu sadayana tulisan)

Privasi dina produk Google sok goréng, kusabab sadaya produk Google anu ngandung spyware.

Henteu janten masalah naon anu anjeun lakukeun, nalika anjeun nganggo Google, sadaya data pribadi sénsitip anjeun dikirim ka Google sareng anu sanés. Google ogé ditingali ngaliwat program kabuka. Salaku conto, tina pangalaman pribadi (dina Firefox) sareng tab YouTube kabuka anu kuring henteu kadatangan, kuring nonton sababaraha video sacara offline (VLC Media Player) Teras nalika kuring mariksa rekomendasi, éta ampir sadayana anu kuring nonton. Teu aya ragu aranjeunna nenjo program anu sanés ogé.

Dina Chrome (sareng seueur panyungsi anu sanés) modeu samaran aya. Dina Chrome, modeu ieu teu aya gunana, sabab Google masih bakal nambangkeun data anjeun. Sanajan anjeun mareuman data pertambangan / lacak, sareng ngaktipkeun sinyal "entong lacak", kejutan kejutan, Google masih ngagali data anjeun.

Upami anjeun pikir anjeun teu kedah nyumput, ** anjeun leres-leres salah **. Argumen ieu parantos dibatalkeun sababaraha kali deui:

[Ngaliwatan Wikipedia] (https://id.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden nyarios "Perdebatan yén anjeun teu paduli ngeunaan hak karusiahan kusabab anjeun teu kedah disumputkeun henteu bénten tibatan nyarios yén anjeun teu paduli ngeunaan kabébasan bebas sabab anjeun teu kedah nyarios. Kuring teu boga naon-naon pikeun disumputkeun, 'anjeun nyarios,' Kuring henteu paduli ngeunaan hak ieu. 'Anjeun nyarios,' Kuring henteu ngagaduhan hak ieu, sabab kuring parantos dugi ka titik anu kuring kedah menerkeun Éta. 'Cara jalanna hak-hakna, pamaréntah kedah menerkeun panyusutanana kana hak-hak anjeun. "

2. Daniel J. Solove nyatakeun dina tulisan pikeun The Chronicle of Higher Education yén anjeunna nentang argumen; anjeunna nyatakeun yén pamaréntahan tiasa leyk inpormasi ngeunaan jalma sareng nyababkeun karuksakan jalma éta, atanapi nganggo inpormasi ngeunaan jalma pikeun nampik aksés kana jasa sanaos jalma éta henteu leres-leres ngalakukeun kalakuan salah, sareng pamaréntahan tiasa nyababkeun karusakan dina kahirupan pribadi urang ku ngalakukeun kasalahan. Solove nyerat "Nalika aktipitas langsung, argumen anu teu disumputkeun tiasa kajiret, sabab maksa debat fokus dina pamahaman sempit ngeunaan privasi. Tapi nalika nyanghareupan pluralitas masalah privasi anu kasangkut ku pengumpulan data pamaréntah sareng panggunaan saluareun panjagaan sareng panyingkepan, argumen anu teu disumputkeun, tungtungna, teu kedah nyarios. "

3. Adam D. Moore, panulis Hak Privasi: Yayasan Moral sareng Hukum, nyatakeun, "éta mangrupikeun pandangan yén hak-hak tahan tina biaya / tunjangan atanapi jinis arguméntatipis. Di dieu urang nolak pandangan yén kapentingan privasi mangrupikeun jinisna hal-hal anu tiasa diperdagangkan pikeun kaamanan. " Anjeunna ogé nyatakeun yén panjagaan sacara teu proporsional mangaruhan sababaraha kelompok di masarakat dumasar kana penampilan, etnis, seksualitas, sareng agama.

4. Bruce Schneier, ahli kaamanan komputer sareng kriptografi, nyatakeun panolakanana, nyebatkeun pernyataan Kardinal Richelieu "Upami aya anu masihan kuring genep garis anu ditulis ku lalaki anu paling jujur, kuring bakal mendakan hal éta pikeun anjeunna digantung", ngarujuk kana kumaha pamaréntahan nagara tiasa mendakan aspek-aspek dina kahirupan hiji jalma pikeun ngadakwa atanapi meres ka jalma éta. Schneier ogé nyatakeun "Teuing salah ciri perdebatan salaku 'kaamanan ngalawan privasi.' Pilihan anu nyata nyaéta kabébasan ngalawan kontrol. "

5. Harvey A. Silverglate memperkirakan yén jalma biasa, rata-rata, henteu sadar ngalakukeun tilu kajahatan sapoé di Amérika Serikat.

6. Emilio Mordini, filsuf sareng psikoanalis, nyatakeun yén argumen "teu kedah disumputkeun" sacara alami paradoks. Jalma-jalma henteu kedah ngagaduhan "sesuatu pikeun disumputkeun" pikeun nyumputkeun "sesuatu". Naon anu disumputkeun henteu merta aya hubunganana, saur Mordini. Sabalikna, anjeunna nyatakeun daérah anu intim anu tiasa disumputkeun sareng aksés-diwatesan diperyogikeun kumargi, sacara psikologis, urang janten individu ngalangkungan penemuan yén urang tiasa nyumputkeun hal batur.

7. Julian Assange nyatakeun "Teu acan aya jawaban anu ngabunuh. Jacob Appelbaum (@ioerror) ngagaduhan tanggapan anu palinter, naros ka jalma-jalma anu nyarios ieu teras masihan teleponna henteu dikonci sareng nurunkeun calana. Versi kuring pikeun nyebatkeun, 'muhun, upami anjeun bosen pisan maka kami henteu kedah nyarios sareng anjeun, sareng sanés ogé anu sanés', tapi sacara filosofis, jawaban anu asli nyaéta: Panineungan massal mangrupikeun parobihan struktural massal. Nalika masarakat goréng, éta bakal nyandak anjeun, sanaos anjeun jalma paling hambar di bumi. "

8. Ignacio Cofone, profésor hukum, nyatakeun yén argumen éta salah kaprah dina istilahna nyalira kusabab, iraha jalma-jalma nyebarkeun inpormasi anu aya hubunganana sareng anu sanés, aranjeunna ogé ngungkabkeun inpormasi anu teu aya hubunganana. Inpormasi henteu relevan ieu ngagaduhan biaya privasi sareng tiasa nyababkeun cilaka sanés, sapertos diskriminasi.

***

## Kampanye anti Google sanés

Ieu daptar kampanye anti-Google terkenal anu terkenal. Daptar ieu henteu lengkep. Anjeun tiasa ngabantosan ku ngamekarkeunna.

### Lengser

[Scroogled - Ku Microsoft (November 2012 dugi ka 2014)] (https://id.wikipedia.org/wiki/Scroogled)

_Teu aya entri sanésna ayeuna._

### Lumangsung

_Daptar ieu ayeuna kosong._

***

## Ngalawan argumen anu sanés

Aya sababaraha alesan anu dilakukeun ku jalma pikeun menerkeun Google. Salah sahiji anu utama anu munggaran parantos dibolaykeun [didieu] (# Privasi) tapi ieu sababaraha anu sanés:

### genah

Leres, produk Google siga anu merenah. Nanging, anjeun dagang sagalana saé pikeun genah, kalebet kaamanan, karusiahan, sareng reliabilitas. Google parantos langkung lami langkung mangtaun-taun, sareng sérverna sateuacana beuki turun. Ayeuna, sérver Google turun ampir sajam 1-2 kali per bulan (khususna YouTube)

Hanjakalna, kusabab masarakat ngandelkeun Google, Google parantos ngadominasi Internét, sareng ngupayakeun ngadalikeun langkung seueur. Dina 2012, nalika Google turun 5 menit, dilaporkeun yén ** global ** Lalu lintas Internét ** turun 40% ** Google remen turun salami 1-2 jam, sareng sareng [némbakan tim étika na] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) diantara hal-hal sanésna, aranjeunna bakal janten kirang sareng kirang merenah.

Genah henteu teras-terasan hal anu saé. Anjeun kedah waspada kana naon anu kajantenan sareng siap-siap nalika turun, sabab teu aya jalan pikeun server henteu turun unggal-unggal.

Google ogé henteu merenah sapertos anu anjeun pikirkeun. Aya situs sanés anu langkung merenah. Google jauh tina merenah, nalika anjeun nyatakeun gantung akun sareng penghentian akun na tanpa réspon (kecuali upami anjeun narik perhatian kana akun twitter Google atanapi ngagugat aranjeunna $ 100,000,000 atanapi langkung) maka aranjeunna parantos ngamanfaatkeun anjeun, ngaco anjeun, sareng maksa anjeun ngajerit kana bantal, dimana teu aya anu tiasa nguping jeritan anjeunpikeun pitulung.

### Naha janten masalah, telat ogé

Ieu argumen anu kirang umum, tapi peryogi katerangan. Kalayan kaayaan ayeuna, kaseueuran pamaréntahan dunya, babarengan sareng sababaraha perusahaan anu kuat sigana terang unggal gerakan anjeun, janten naha malah repot-repot jauh tina éta? Jawabanana saderhana: ** anjeun pantes hadé **. Upami anjeun ngatur jauh ti aranjeunna dina waktos ieu, langkung hésé pikeun aranjeunna ngalacak gerakan anjeun langkung jauh, sareng anjeun tiasa ngawangun kahirupan anu langkung pribadi.

[1 sumber] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Ku jalan kitu, kuring parantos masihan penghargaan Reddit gratis ka tulisan ieu unggal-unggal kuring nampi langkung ti saminggu ayeuna (sareng sadayana 500 koin gratis kuring) pikeun ningkatkeun topik ieu langkung jauh. Sajauh ieu, kuring parantos masihan postingan ieu langkung ti 14 penghargaan gratis. Éta henteu seueur, tapi hal-hal leutik tiasa ngahasilkeun pangaruh ageung, gumantung kana kumaha katarima, sareng ku saha.

### Anu sanés

Abdi henteu ngagaduhan argumen anu sanés dina waktos ayeuna.

_ Daptar ieu henteu lengkep_

***

## Sumber

Nyalin:

[G] (https://id.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico- Children-privacy-school-chromebook-lawsuit)[sopito(https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https:// Medium.com/digiprivacy/i-stopping-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acqu acquisition-he data-alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/site/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritik) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-about-you-you-can-find-and-Delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -na) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[dopito(https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks] [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o Ingles(https://en.wikipedia.org/wiki/2018_Google_data_breach)[mopito(https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019 / 01/21 / teknologi / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- klaim-atas-pikeun-5-juta-iphone-pangguna) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[eiwan(https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technology / 2014/01 / naon-google-can-really-do-with-Nest-or-really-nests-data /) [i] (https://www.cbsnews.com/news/google-education -spies-on-collects-data-on-jutaan-budak-tuduhan-gugatan-anyar-mexico-Attorney-general /) [v] (https://www.nationalreview.com/2018/04/the- student-data-mining-scandal-under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y Ingles(https:// Medium.com/@hansdezwart/during-world-war-ii-we-did -have-something-to-hide-40689565c550) [.] (https:// Medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Sumber sanésna:

[Lima panon Alliance] (https://en.wikipedia.org/wiki/Five_Eyes) [Salapan belas dalapan puluh opat] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Unduh tautan

[Kéngingkeun Firefox] (https://www.mozilla.org/en-US/fireoks/new/) [Kéngingkeun Tor browser] (https://www.torproject.org/download/) [Lian / teu aya] (https : //www.example.com)

***

## Pangalaman degoogling kuring

Tungtungna kuring mimiti ningali masalah sareng tech ageung di 2018, sareng kuring mimiti degoogling. Dina sababaraha bulan kahiji, kuring nyieun kamajuan anu signifikan. Éta kalem laun ti saprak éta.


### Naon anu kuring ngalihkeun

Google Chrome -> Firefox / Tor

Milarian Google -> DuckDuckGo (standar) / Ecosia (nalika kuring resep) / Bing (jarang)

GMail - ProtonMail (teu acan dialihkeun pinuh)

Situs Google -> Hosting nyalira (teu acan dialihkeun pinuh)

Google+ -> Boro-boro dipaké, mupus sorangan kusabab mareumanana sorangan

Google Docs -> Pernah dianggo, kuring ngan ukur nganggo Microsoft Word 2013 (sateuacan 2019) sareng LibreOffice (2019-saterusna).

Google Sheets -> Pernah dianggo, kuring ngan ukur nganggo Microsoft Excel 2013 (sateuacan 2019) sareng LibreOffice (2019-saterusna).

Google Slides -> Teu pernah dianggo, kuring ngan ukur nganggo Microsoft PowerPoint 2013 (sateuacan 2019) sareng LibreOffice (2019-saterusna).

Gambar Google -> Teu pernah dianggo, kuring ngan ukur nganggo LibreOffice (2019-saterusna).

Gerrit -> Pernah dianggo, kuring ngan ukur nganggo GitHub (standar ayeuna), GitLab, BitBucket, sareng SourceForge.

Poto Google -> Teu pernah dianggo

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-ayeuna)

Google Maps -> OpenStreetMaps / Apple Maps

Buka - Nyiptakeun pengecualian khusus, tapi henteu nganggo basa pamrograman anu fungsional

Dart - Nyiptakeun pengecualian khusus, tapi henteu nganggo basa pamrograman anu fungsional

Flutter - Nyiptakeun pengecualian khusus, tapi henteu nganggo basa pamrograman anu fungsional

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> Teu kantos dianggo, kuring ngaraos langkung serem

Google Fi -> Teu pernah dianggo

Kalénder Google -> Teu kantos dianggo

Kalkulator Google -> Sacara harfiah aplikasi kalkulator sanés, bahkan terminal Linux anu dijalankeun dina modeu Python upami kuring resep

Google Nest -> Teu pernah dianggo

Google AMP -> Teu kantos dianggo

Google VPN -> Pernah dianggo, ogé oxymoron

Google Pay -> Teu pernah dianggo

Google Summer of Code -> Teu pernah miluan

Tenor -> Situs GIF anu sanés, sanaos GIF henteu penting teuing pikeun kuring. Kuring biasana kéngingkeun file GIF tina gambar DuckDuckGo, Imgur, Reddit, atanapi situs sanés.

Blokir -> Henteu dianggo deui, teu yakin kana Scratch langsung lumpat sacara blok. Kuring janten programmer fungsional di 2017 sareng payun, sareng tumuh tina Scratch.

GBoard -> Dipaké sakali, tapi ditinggal

Google Glass -> Teu pernah dianggo, dianggap salaku budak leutik tapi mutuskeun teu meunang hiji / anggo upami kuring gaduh pilihan

_Daptar tiasa henteu lengkep._

### Produk anu kuring masih teu tiasa kabur

Ti tanggal 25 Pébruari 2021, ieu mangrupikeun produk Google anu ngajagi kuring tina teu leres degoogling:

1. YouTube

2. Android

3. Google Play Store

4. GMail (ngan ukur pikeun sakola sareng sababaraha situs)

5. Google Classroom (ngan ukur pikeun sakola)

6. Google Tarjamahkeun

7. Akun Google

8. Situs Google (sabab Google ngalanggar hukum GDPR (sareng tiasa nyanghareupan denda € 5.000.000,00 dugi ka ngalereskeun) sareng ngalarang unduhan produk ieu)

Kuring parantos degoogle tina sagala rupa anu sanés.

***

## Go jahat

Google ngadaptarkeun basa pamrograman Agen Dumasar 2003 "Go!" Kalayan basa pamrogramanna "Go` (ti 2009, 6 taun ka hareup) sareng nyatakeun yén basana moal mangaruhan basa séjén. Google dikritik pisan pikeun ieu, sabab motto `Entong jahat` masih aktif dina waktos éta, sareng ieu mangrupikeun salah sahiji seueur kajadian anu ngagaduhan Motto jahat janten pensiunan.

Tungtungna, pamekaran `Go !` lirén, sedengkeun` Go` janten langkung umum. Google nyatakeun yén aranjeunna moal stramroll ngalangkungan 'Go!' Tapi tungtungna, aranjeunna leres, sareng aranjeunna kabur (dugi ka 9 April 2021)

[Maca langkung seueur ngeunaan Go sareng cara ngagentos didieu] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Pamakéan DRM

Google nganggo DRM (Digital Watesan Manajemén) ngalangkungan WideVine DRM "jasa" na sareng bentuk sanésna. Tujuan DRM nyaéta ngancurkeun Internét anu kabuka sareng masihan perusahaan kakuatan monopolistik tibatan pangguna. Anjeun kedah ngaleungitkeun WideVine sapinuhna, sanés biaya.

[Baca langkung seueur ngeunaan WideVine sareng masalahna di dieu] (https://github.com/Degoogle-your-life/Its-time-ka-motong-WideVine-DRM)

***

## Salah paham umum

Ieu daptar sababaraha salah paham umum sareng produk Google.

### Google sanés Internét

Milarian Google / Google sanés Internét, milarian Google ngan ukur mesin pencari, sapertos kumaha teu unggal buruan pikeun platform Nintendo didamel ku Nintendo, tapi dilisensikeun ku Nintendo, tapi dugi ka jauhna langkung ageung. Upami sadaya server Googles kedah ditumpes sakaligus ayeuna, mung Situs Google sapertos YouTube, Gmail, Google Docs, sungsi Google, sareng sajabana anu bakal musna, tapi seuseueurna Internét tetep bakal aya (Wikipedia, Stackoverflow, GitHub, sadaya halaman wéb Mikropon, NYTimes, Samsung, TikTok, sareng sajabana) aranjeunna tiasa kaleungitan aksés Google sareng fungsionalitas analitisna, tapi éta bakal tetep fungsional (kacuali aranjeunna kirang diprogram sareng ngandelkeun langsung kana Google)

***

## Internet Explorer 6 sareng Chrome

Google Chrome janten Internet Explorer anyar 6. Nalika Google Chrome asalna kaluar, Firefox mangrupikeun peramban anu dominan, sareng seuseueurna maéhan pamasar Internet Explorer (anu ngalangkungan 96% sateuacan jutaan jalma ngalih ka Firefox sareng panyungsi anu sanés) nalika Google Chrome kaluar, jalma-jalma ngalih kusabab kagancangan sareng éta ku Google (anu teu dianggap jahat dina waktos éta, sabab kaseueuran masalah privasi teu acan terang-terang) Google Chrome tadina ngahargaan standar wéb (anu dilakukeun ku Firefox anu maéhan pangsa pasar panjelajah Internét 96%) kumaha ogé, nalika pasar Google Chromes naék, Google mimiti ngaleungitkeun langkung seueur fitur, nambihan deui spyware, sareng lirén nampi standar wéb, Google Chrome parantos janten Internet Explorer 6 énggal.

Masalah utama ayeuna nyaéta halaman wéb anu ngan ukur Chrome, sareng moal dianggo dina panyungsi anu sanés, sabab pamekarna mutuskeun yén aranjeunna henteu hoyong anu 30-40% pangguna Internét sanés anu henteu nganggo Chrome pikeun nganggo situsna.

Malah Google nyalira ngadamel situsna Chrome waé. Salaku conto, pamilarian Google bakal ngajurung anjeun pikeun ngaunduh Chrome 3 kali unggal 10 detik upami éta mendakan anjeun henteu nganggo Google Chrome (bahkan panyungsi basis Chromium sanés sapertos Wani kapangaruhan) sareng situs sapertos Google Earth henteu ngijinkeun pangguna Firefox pikeun anggo situsna (dugi ka taun 2020) ditambah Google Translate henteu ngadukung input sora dina Firefox, sareng panyungsi sanés Google Chrome sanés.

### Masalahna Wani

Browser sanés anu dumasar kana Chromium, sapertos Wani sareng Microsoft Edge henteu lengkep bébas tina spyware Google. Wani ilahar disarankeun ku sisi masarakat komunitas anu lepat, tapi Wani masih janten masalah, sabab nganggo Chromium. Internét henteu kedah ngan ukur browser Chromium, kedah aya sababaraha pilihan. Wani mangrupakeun jalan anu salah pikeun indit.

[Maca langkung seueur ngeunaan degoogling ti Google Chrome / Chromium didieu] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Maca langkung seueur ngeunaan degoogling ti ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) didieu] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Pembaharuan privasi faux

Google parantos nyobian nyarios ka dunya yén aranjeunna paduli kana privasi, saatos éta parantos telat. Aranjeunna teras ngaku yén aranjeunna ngahargaan privasi pangguna, tapi aranjeunna tetep henteu ngalereskeun sadaya masalah privasi.

### Sumber terbuka moal tiasa parsial

Sumber kabuka moal tiasa parsial. Google mangrupikeun buktina ieu. Unggal bit sareng bait tina kode sumber kedah tiasa ditingali ku umum, bahkan henteu disumputkeun 8 tina bait.

Proyék sapertos Android sareng ChromeOS sawaréh sumber kabuka, tapi ngandung seuseueurna propriétari, unsur spyware.

### Oxymoron

Google VPN mangrupikeun oxymoron. Google henteu paduli ngeunaan karusiahan, sareng Jaringan Wasta Virtual (VPN) ti perusahaan sapertos aranjeunna bakal janten salah sahiji pilihan anu paling parah pikeun layanan VPN.

***

## Pagelaran goréng

Google henteu paduli kana kinerja produk na sahanteuna taun 2017, sabab parangkat lunak benchmarking pamungkas na (Google Octane) dihentikan di 2017.

***

## Manajemén proyék goréng

Google ngagaduhan sistem manajemen proyek internal anu parah pisan. Sababaraha conto umum program anu ngagaduhan langkung seueur diturunkeun kalebet musik Google Duo sareng YouTube (tilas Google Play Music)

Dina sistem pangembangan internal Googles, 1 aplikasi nuju kana aplikasi anu sanés kalayan satengah fungsina, maka aplikasi aslina dihapus. Sababaraha taun ka pengker, aplikasi anyar anu 75% kirang fungsina dilakukeun, teras aplikasi anu fungsina 50% dihapus, dituturkeun ku aplikasi anyar kalayan 87,5% pungsionalitasna didamel, teras aplikasi anu fungsina 75% dihentikan , teras salajengna.

***

## Pikareueuseun atanapi henteu moderasi jasa

YouTube mangrupikeun conto anu paling umum di dunya moderasi goréng nyiptakeun platform anu paling parah dina ayana. Google ogé sigana henteu nampi yén YouTube sanés murangkalih YouTube.

Pikeun YouTube, eusi pro-Nazi sareng Bodas Supremacist anu bencong disayogikeun ka pangguna pikeun tujuan langkung waktos papacangan sareng artos langkung. Google ogé parantos ngalakukeun sababaraha pisanhal bodo dina kasederhanaanana, sapertos nyatujuan pidéo Christian Anal Sex salaku kontén `didamel kanggo murangkalih` nalika dina waktos anu sami ngawatesan pidéo. Éta ogé henteu jarang pikeun ningali iklan pornografi atanapi gore anu leres aya handapeun video Baby Shark, sareng sababaraha jinis `didamel kanggo eusi murangkalih`.

Pangguna YouTube geuleuh sering ngeunaan kasederhanaan goréng dina YouTube pikeun eusi goréng (sapertos conto anu didaptarkeun di luhur) sedengkeun pangguna tiasa ngahapus pidéoana sacara acak tanpa alesan tanpa kabisa mupus, babarengan sareng pangguna dihukum pikeun bentuk sumpah naon, malah kasus anu leutik pisan sapertos nyarios pangguna `crap` biasana ngabandingkeun YouTube kana [Uni Soviét] (https://en.wikipedia.org/wiki/Soviet_Union) dina jaman Stalin, kusabab hukuman anu teu sami ieu.

Dina 2021, Google ngumumkeun yén aranjeunna bakal nempatkeun iklan dina sadaya pidéo, sanaos pidéo anu kasurupan (sahingga Google ngahasilkeun artos, tapi panyipta na henteu) ieu henteu aya hubunganana teuing sareng moderasi, tapi penting pikeun dicatet.

YouTube dimoderasi (sanaos henteu saé pisan) tapi jasa iklan Google anu ngajantenkeun artos ageung artos na sigana teu gaduh moderasi.

[Maca langkung seueur perkawis masalah moderasi YouTube sareng cara ngaganti ti YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Iklan pikeun Google Play dihasilkeun tina kebon bot, anjeun tiasa terang ku skénario iklan anu sami anu dianggo ku ratusan perusahaan kalayan sakedik perobihan, sareng henteu aya hubunganana sareng produk (conto umum: Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City, sareng rébuan deui) sasarengan sareng tren jahat pikeun iklan anu nyatakeun yén pangguna tiasa ngasilkeun artos ku maén gim, ngupingkeun musik, sareng sajabana PayPal henteu acan ngomentaran hal ieu, tapi jelas yén ieu mangrupikeun scam, saolah-olah anjeun tiasa ngadamel langkung ti $ 10.000 dina waktos kirang ti 20 detik ku maén kaulinan dijamin, teu aya anu ngalakukeun pagawéan sareng bakal ngalakukeun ieu tibatan, anu mustahil, sareng bisnis henteu tiasa dianggo sapertos kieu. Panipuan anu jelas ieu parantos naék kuat ti taun 2019, sareng ayeuna kebon bot anu ngahasilkeun iklan ieu saling gelut dina iklanna sorangan.

Sababaraha pariwara ogé lewd, sareng nyobian kéngingkeun pangguna (seuseueurna janten pangguna di handapeun umur 13 taun, atanapi bot) pikeun ngeklik manipulasi séks.

Seueur aplikasi nganggo bot sareng astroturf produkna, janten iraha waé tinjauan goréng dilakukeun, akun bot boneka kaos kaki bakal ngamimitian ngeposkeun ulasan bintang 5 sareng nyobian ngabantah kritik anjeun. [Google ogé ngalakukeun ieu sorangan] (# Astroturfing)

[Maca langkung seueur perkawis masalah sareng Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

Definisi umum [(tina Wikipedia)] (https://id.wikipedia.org/wiki/Astroturfing)

"."
Astroturfing mangrupikeun prakték masking sponsor sponsor atanapi organisasi (contona, politik, pariwara, agama atanapi hubungan masarakat) pikeun némbongan siga anu asalna sareng didukung ku pamilon akar rumput. Mangrupikeun prakték anu ditujukeun pikeun masihan kredibilitas pernyataan atanapi organisasi ku nahan inpormasi ngeunaan hubungan kauangan sumberna. Istilah astroturfing diturunkeun tina AstroTurf, mérek karpét sintétik anu dirancang pikeun nyarupaan jukut alami, salaku sandiwara dina kecap "akar rumput". Implikasina dina dasar panggunaan istilah éta nyaéta alih-alih usaha akar rumput "leres" atanapi "alami" di balik kagiatan anu dimaksud, aya tampilan "palsu" atanapi "ponggawa" dukungan.
"."

Google ngagaduhan sejarah astroturfing pikeun ngajantenkeun siga aranjeunna henteu ngalakukeun nanaon jahat (dina prosésna, astroturfing jahat) contona, masang kritik Google dina platform sapertos Twitter (anu aranjeunna ngagaduhan akun) bakal ngahasilkeun sababaraha rekening anu parantos aya bari tapi henteu pernah dipasang sateuacan kaluar sareng nyatakeun yén naon anu anjeun nyarioskeun palsu, teras nyatakeun yén Google mangrupikeun perusahaan anu pangsaéna, tapi dilakukeun ku cara anu tiasa écés yén ieu bot-bot pikeun paling jelema.

***

## Praktek bisnis anu teu sah sareng teu étis

Google nganggo prakték bisnis haram sareng henteu étis pikeun nuluykeun monopoli na, sapertos ngagunakeun tempat perlindungan pajak, padamelan outsourcing, sareng neraskeun ngalakukeun kagiatan invasif ilegal salaku biaya usaha.

### Di Éropa

Éropa sering ngagugat Google, gugatan panggedéna ngalawan palanggaran ilegal di Android, anu ngakibatkeun Google nampi € 5,000,000,000 (sami sareng $ 5,947,083,703,68 dina 9 April 2021 artos)

### Di Amérika Kalér

Amérika Serikat teu acan masihan ampir cekap pikeun denda ka Google, dibandingkeun sareng Europe € 5.000.000.000 denda.

### Kontroversi

Google henteu paduli masalah dugi ka nyiptakeun kontropérsi, maka aranjeunna bakal ngalakukeun usaha anu goréng pikeun ngalereskeunana, ngan cukup pikeun kontropérsi éta samentawis musna, sareng masalah éta teras-terasan parah dugi ka nyiptakeun kontropérsi anu sanés, sareng siklus terus. Aranjeunna ngan saukur teu paduli pikeun ngalakukeun nanaon serius ngeunaan éta.

***

## Google otomatis

Salaku kompany, Google seuseueurna otomatis, kalayan kirang moderasi tibatan otomatis.

Perusahaan kedah henteu otomatis otomatis. Google mangrupikeun conto ieu. Moderasi pikareueuseun upami dilakukeun ku AI, YouTube mangrupikeun conto anu saé, bahkan ku sababaraha urang tambahan (ratusan, atanapi panginten sarébu) jalma modérasi situs, dimana tétéla goréng pisan anu seuseueurna kedah ngagaduhan terapi nalika damel.

***

## Android

Android dipimilik ku Google. Bagian tina Open Handset Alliance (anu teu acan kabuka ti Android) Android parantos janten titik monopoli sanés pikeun Google, sareng salah sahiji anu hésé pisan kabur.

Android parantos dilaporkeun ka telepon ka Google sahenteuna 10 kali per dinten, sareng sanaos janten sumber kabuka sabagean, éta tetep bertindak beurat sakumaha spyware.

Sababaraha proyék parantos diciptakeun pikeun silih ganti tina Android, tapi meryogikeun ngakar perangkat anjeun. Ieu ngan saukur henteu mungkin deui pikeun telepon Samsung khusus di Amérika Serikat, kusabab DRM Knox. Ganti umum pikeun Android kalebet ios, iPadOS, LineageOS, Android x86, Ubuntu Touch, sareng PiPhone (Pi Phone mangrupikeun mérek telepon anu ngajalankeun sababaraha sistem Linux dina alat sélulér, sapertos Fedora, Ubuntu, Arch, jst.)

[Tingali panilitian kuring ngeunaan kéngingkeun mesin virtual Android anu degoogled] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Tingali kumaha carana degoogle tina Android] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Peta leutik pikeun ngabantosan

Nyebarkeun kasadaran ku unggal cara anjeun tiasa penting. Pikeun kuring, kuring henteu ngan ukur sering nyarioskeun ngeunaan degoogling, sareng nyerat tulisan, tapi kuring ogé ngagaduhan kabiasaan sakedik, dimana kuring masihan penghargaan Reddit gratis harian kuring ka tulisan anu dipasang dina r / degoogle pikeun ningkatkeun kasadaran. Sajauh ieu, kuring parantos masihan ampir 30 panghargaan kana pos anu dipasang (kuring ogé nyéépkeun 500 koin gratis kuring dina 10 penghargaan kanggo pos éta)

***

## Teu dipercaya

Google moal tiasa dipercaya, sareng moal tiasa dipercaya deui. Aranjeunna parantos lengkep tina "ulah jahat" (aranjeunna sok jahat) janten ngan ukur jahat pisan sareng henteu nyobian nyumputkeunana.

***

## Hal-hal sanés anu kedah diperiksa

[The Google Graveyard (slaybygoogle.com) - daptar diurut tina 224+ produk anu ditelasan ku Google] (https://killedbygoogle.com/)

> [Tautan GitHub] (https://github.com/codyogden/killedbygoogle)

[Union union pekerja - Serikat pekerja anyar di Google kalayan langkung ti 800 anggota] (https://alphabetworkersunion.org/people/our-union/)

[Entong pisah sareng endog easter dinosaurus? Halaman wéb ieu parantos anjeun rangkep] (https://chromedino.com/)

Aya deui alternatip anu sanés, ngan ukur milarian waé.

***

Sababaraha pamariksaan kanyataan diperyogikeun pikeun tulisan ieu

***

## Inpo file

Jenis file: `Markdown (* .md)`

Jumlah garis (kalebet garis kosong sareng garis kompiler): `968`

Vérsi file: `6 (Minggu, 18 April 2021 jam 4:18)

***

### Status parangkat lunak

Sadaya padamelan abdi gratis sababaraha larangan. DRM (** D ** igital ** R ** estructions ** M ** anagement) henteu aya dina karya kuring.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Stiker ieu dirojong ku Free Software Foundation. Kuring henteu pernah niat ngalebetkeun DRM dina karya kuring.

Kuring nganggo singkatan "Digital Watesan Manajemén" tibatan anu langkung dikenal "Digital Rights Management" salaku cara umum pikeun nyebatkeun éta palsu, teu aya hak sareng DRM. Éjahan "Manajemén Watesan Digital" langkung akurat, sareng dirojong ku [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) sareng [Free Software Foundation (FSF)] ( https://id.wikipedia.org/wiki/Free_Software_Foundation)

Bagéan ieu dipaké pikeun ningkatkeun kasadaran pikeun masalah anu aya dina DRM, sareng ogé protés. DRM rusak ku desain sareng mangrupikeun ancaman utama pikeun sadaya pangguna komputer sareng kabébasan parangkat lunak.

Kiridit gambar: [defectivebydesign.org/drm-free/...gris(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Inpo sponsor

! [Sponsorbutton.png] (Sponsor Button.png) <- Entong pencét tombol ieu, éta henteu tiasa dianggo, éta ngan ukur gambar. Tombol asli aya di luhur halaman di belah katuhu (<- L ** R ** ->)

Anjeun tiasa sponsor proyék ieu upami anjeun resep, tapi punten tangtukeun naon anu rék disumbangkeun. [Tingali dana anjeun tiasa nyumbang ka dieu] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Anjeun tiasa ningali inpormasi sponsor sanésna [didieu] (https://github.com/seanpm2001/Sponsor-info/)

Coba éta! Tombol sponsor langsung aya di gigireun tombol nonton / henteu dibuka.

***

## Riwayat file



 * Ngamimitian file

> * Ditambahkeun bagian judulna

> * Ditambahkeun indéks na

> * Ditambahkeun perkawis bagian

> * Ditambahkeun bagian Wiki

> * Ditambahkeun bagian riwayat vérsi

> * Ditambahkeun bagian masalah.

> * Ditambahkeun bagian masalah anu katukang

> * Ditambahkeun bagian paménta narik anu kapengker

> * Ditambahkeun bagian permintaan tarik aktif

> * Ditambahkeun bagian kontributor

> * Ditambahkeun bagian anu nyumbang

> * Ditambahkeun ngeunaan bagian README

> * Ditambahkeun bagian riwayat vérsi README

> * Ditambahkeun bagian sumberdaya

> * Nambahkeun bagian status parangkat lunak, kalayan stiker sareng pesen gratis DRM

> *Ditambahkeun bagian inpormasi sponsor

> * Teu aya parobahan anu sanés dina vérsi 0.1

Vérsi 1 (Jumaah, Pébruari 19 2021 di 5:20 pm)

> Parobihan:

> * Ngamimitian file na

> * Ditambahkeun bagian déskripsi dasar

> * Ditambahkeun bagian déskripsi Repository

> * Nambahkeun daptar tulisan, kalayan 14 éntri

>> * Ditambahkeun bagian `artikel patali`

>> * Ditambahkeun bagian 'tingali ogé`

> * Ditambahkeun bagian inpormasi file

> * Ditambahkeun bagian riwayat file

> * Ditambahkeun footer na

> * Teu aya parobahan anu sanés dina vérsi 1

Vérsi 2 (Jumaah, Pébruari 19 2021 di 5:26 pm)

> Parobihan:

> * Ditambahkeun bagian status tarjamah

> * Nambahkeun Hal-hal Lain kanggo mariksa bagian

> * Ditambahkeun bagian privasi

> * Ditambahkeun indéks

> * Ditambahkeun subséksi status parangkat lunak

> * Ditambahkeun bagian kampanye anti Google sanés

>> * Ditambahkeun kana subséksi anu teu aya

>> * Ditambahkeun subséksi anu lumangsung

> * Ditambahkeun bagian sumber

> * Ditambahkeun bagian tautan unduhan

> * Diénggalan bagian inpormasi file

> * Perbarui bagian riwayat file

> * Teu aya parobahan anu sanés dina vérsi 2

Vérsi 3 (Rebo, Pébruari 24th 2021 jam 7:56 wengi)

> Parobihan:

> * Ngénggalan indéks

> * Dirujuk ikon degoogle sareng organisasi GitHub énggal

> * Ditambahkeun tautan kana tulisan anu langkung énggal

> * Ditambahkeun dina bagian anu ngabantah alesan séjén

>> * Ditambahkeun subséksi genah

>> * Ditambahkeun Naha malah ngaganggu subséksi

>> * Ditambahkeun kana subséksi anu sanés

> * Ngamutahirkeun sababaraha data

> * Diénggalan bagian inpormasi file

> * Perbarui bagian riwayat file

> * Teu aya parobahan anu sanés dina vérsi 3

Versi 4 (Kamis, 25 Pébruari 2021 tabuh 9:31)

> Parobihan:

> * Ditambahkeun tautan kana 10 tulisan énggal

> * Nambahkeun bagian ngeunaan pangalaman kuring degoogling

> * Ngénggalan indéks

> * Diénggalan bagian inpormasi file

> * Perbarui bagian riwayat file

> * Teu aya parobahan anu sanés dina vérsi 4

Versi 5 (Jumaah, 9 April 2021 tabuh 6:02 pm)

_Ateh kurangna pembaruan pikeun gerakan anti Google ti kuring akhir-akhir ieu, kuring nuju ngupayakeun balik deui saatos hiatus 1+ bulan._

> Parobihan:

> * Perbarui bagian judul

> * Ngénggalan indéks

> * Ngamutahirkeun daptar basa: tautan maneuh, sareng nambihan deui basa anu didukung

> * Ngabagikeun bagian status artikel, nambihan 4 tautan garpu

> * Ngamutahirkeun bagian status parangkat lunak

> * Ditambahkeun Go nyaéta bagian jahat

> * Nambahkeun bagian Pamakéan DRM

> * Ditambahkeun kana bagian salah paham umum

>> * Ditambahkeun Google sanés subséksi Internét

> * Ditambahkeun bagian Internet Explorer 6 sareng Chrome

>> * Ditambih masalah sareng subseksi Wani

> * Ditambahkeun panyabutan privasi Faux

> * Ditambahkeun sumber Terbuka moal tiasa bagéan bagéan

> * Nambahkeun bagéan Oxymoron

> * Ditambahkeun bagian kinerja Goréng

> * Ditambahkeun bagian manajemén proyék Goréng

> * Ditambahkeun bagian anu pikareueuseun atanapi henteu moderasi tina jasa

> * Ditambahkeun bagian Astroturfing

> * Ditambahkeun bagian prakték bisnis haram sareng teu étis

> * Ditambahkeun dina subséksi Di Éropa

>> * Ditambahkeun dina subséksi Amérika Kalér

>> * Nambahkeun subséksi Kontroversi

> * Ditambahkeun Google mangrupikeun bagian otomatis

> * Ditambahkeun bagian Android

> * Ditambahkeun tindakan Leutik pikeun ngabantosan bagian

> * Ditambahkeun bagian Teu dipercaya

> * Ditambahkeun bagian inpormasi sponsor

> * Ngamutahirkeun footer

> * Diénggalan bagian inpormasi file

> * Perbarui bagian riwayat file

> * Teu aya parobihan anu sanés dina vérsi 5

Vérsi 6 (Minggu, 18 April 2021 jam 4:18)

> Parobihan:

> * Ngénggalan indéks

> * Nambihan gambaran umum anyar

> * Inpo status artikel anu diénggalan

> * Nambahkeun tautan kana artikel Google FLoC anu énggal

> * Nambahkeun tautan kana tulisan Wuest 3n Fuchs Degoogle sareng inpormasi umum di dinya

> * Diénggalan bagian inpormasi file

> * Perbarui bagian riwayat file

> * Teu aya parobahan anu sanés dina vérsi 6

Versi 7 (Kadieu)

> Parobihan:

> * Kadieu

> * Teu aya parobahan anu sanés dina vérsi 7

Versi 8 (Kadieu)

> Parobihan:

> * Kadieu

> * Teu aya parobahan anu sanés dina vérsi 8

Versi 9 (Kadieu)

> Parobihan:

> * Kadieu

> * Teu aya parobahan anu sanés dina vérsi 9

Versi 10 (Kadieu)

> Parobihan:

> * Kadieu

> * Teu aya parobahan anu sanés dina vérsi 10

Versi 11 (Datang deui)

> Parobihan:

> * Kadieu

> * Teu aya parobahan anu sanés dina vérsi 11

Versi 12 (Datang deui)

> Parobihan:

> * Kadieu

> * Teu aya parobahan anu sanés dina vérsi 12

***

## Footer

Anjeun parantos ngahontal tungtung file ieu

([Balik deui ka luhur] (# Top) | [Balik deui ka GitHub] (https://github.com))

### EOF

***
