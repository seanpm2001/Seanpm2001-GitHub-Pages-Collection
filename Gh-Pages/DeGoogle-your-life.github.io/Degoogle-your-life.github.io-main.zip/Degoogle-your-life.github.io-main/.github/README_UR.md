***

! [DEGoogle1.jpeg] (DEGOOGLE1.jpeg)

# ڈیگوگلنگ - اپنی زندگی کو ڈیگل کریں

عمومی ڈگوگلنگ معلومات اور دوسرے مضامین کا ایک لنک کے ل This یہ اہم ڈگوگلنگ مضمون ہے۔

[فہرست کو ایک گٹہب تنظیم کے طور پر دیکھیں] (https://github.com/Degoogle-your- Life)

***

_ اس مضمون کو مختلف زبان میں پڑھیں: _

** موجودہ زبان یہ ہے: ** `انگریزی (امریکی)` _ (انگریزی کو درست زبان کی جگہ ٹھیک کرنے کے ل translations ترجمے کو درست کرنے کی ضرورت پڑسکتی ہے) _

_🌐 زبانوں کی فہرست_

** ترتیب کردہ: ** `A-Z`

[چھانٹنے کے اختیارات دستیاب نہیں ہیں] (https://github.com/Degoogle-your- زندگی)

([افریقہ افریقی] (/. گتوب / README_AF.md) افریقی | [[مربع شقپٹیر] (/. گیتوب / README_SQ.md) البانی | [am am አማርኛ] (/. github / README_AM.md) امہاری | [ar عربى] (/.github/README_AR.md) عربی | [hy հայերեն] (/. github / README_HY.md) آرمینیائی | [Az Azərbaycan dili] (/. github / README_AZ.md) آذربائیجان | [eu Euskara] (/. github /README_EU.md) باسکی | [be Беларуская] (/. github / README_BE.md) بیلاروس | [bn বাংলা] (/. گیتوب / README_BN.md) بنگالی | [بی ایس بوسنکی] (/. گیتوب / README_BS.md) بوسنیا | [bg български] (/. github / README_BG.md) بلغاریائی | [ca caalà] (/. github / README_CA.md) کتالان | [ceb Sugbuanon] (/. github / README_CEB.md) سیبانو | | ] (/. گیتوب / README_NY.md) چیچہوا | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) چینی (آسان) | [zh-t 傳統 的 的）] (/. گیتوب / README_ZH -T.md) چینی (روایتی) | [co Corsu] (/. github / README_CO.md) Corsican | [hr Hrvatski] (/. github / README_HR.md) کروشین | [cs čeština] (/. github / README_CS .md) چیک | [da dansk] (README_DA.md) ڈینش | [nl Nederland] (/. github / README_ NL.md) ڈچ | [** این-انگلش **] (/. گتھوب / README.md) انگریزی | [ای او ایسپرانٹو] (/. github / README_EO.md) ایسپرانٹو | [et Eestlane] (/. github / README_ET.md) اسٹونین | [tl پیلیپو] (/. github / README_TL.md) فلپائنی | [fi Suomalainen] (/. github / README_FI.md) فینیش | [fr français] (/. github / README_FR.md) فرانسیسی | [fy Frysk] (/. github / README_FY.md) فرینشین | [gl galego] (/. github / README_GL.md) گالیشین | [کا ქართველი] (/. گیتوب / README_KA) جارجیائی | [ڈی ڈوئچ] (/. گیتوب / README_DE.md) جرمن | [el Ελληνικά] (/. github / README_EL.md) یونانی | [گجراتی] (/. گتوب / README_GU.md) گجراتی | [ht Kreyòl ayisyen] (/. github / README_HT.md) ہیتی کریول | [ہا ہاؤسا] (/. گیتوب / README_HA.md) ہاؤسا | [haw Ōlelo हवाईʻی] (/. github / README_HAW.md) ہوائی | [he עִברִית] (/. github / README_HE.md) عبرانی | [ہندی ہندی] (/. گیتوب / README_HI.md) ہندی | [hmn Hmong] (/. github / README_HMN.md) ہمونگ | [ہو ماگیار] (/. گیتوب / README_HU.md) ہنگری | [isÍslenska ہے] (/. github / README_IS.md) آئس لینڈ کا | [ig Igbo] (/. github / README_IG.md) Igbo | [id بہاس انڈونیشیا] (/. github / README_ID.md) آئس لینڈ کا | [ga Gaeilge] (/. github / README_GA.md) آئرش | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) جاپانی | [jw Wong jawa] (/. github / README_JW.md) جاوانیز | [kn ಕನ್ನಡ] (/. github / README_KN.md) کنڑا | [kk Қазақ] (/. github / README_KK.md) قازق | [کلومیٹر ខ្មែរ] (/. گیتوب / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) کینیاروانڈا | [کو-ساؤتھ 韓國 語] (/. گیتوب / README_KO_SOUTH.md) کورین (جنوبی) | [ko-شمال 문화어] (README_KO_NORTH.md) کورین (شمالی) (آپ کا تبادلہ نہیں) | [ku کردî] (/. github / README_KU.md) کرد (کرمانجی) | [کیی Кыргызча] (/. گیتوب / README_KY.md) کرغیز | [lo ລາວ] (/. github / README_LO.md) لاؤ | [لا لیٹین] (/. github / README_LA.md) لاطینی | [لیفٹینٹ لیٹووئس] (/. github / README_LT.md) لتھوانیائی | [lb Lëtzebuergesch] (/. github / README_LB.md) لکسمبرگ | [mk Македонски] (/. github / README_MK.md) مقدونیائی | [ملیگرام ملاگاسی] (/. گتوب / README_MG.md) ملاگاسی | [MS بہاسہ میلیو] (/. github / README_MS.md) مالائی | [ml മലയാളം] (/. github / README_ML.md) ملیالم | [mt ملٹی] (/. github / README_MT.md) مالٹیش | [mi ماوری] (/. github / README_MI.md) ماوری | [مسٹر انگریزی] (/. github / README_MR.md) مراٹھی | [mn Монгол] (/. github / README_MN.md) منگولیا | [my မြန်မာ] (/. github / README_MY.md) میانمار (برمی) | [نی नेपाली] (/. github / README_NE.md) نیپالی | [Norsk] (/. github / README_NO.md) ناروے | [یا ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) اوڈیہ (اوریا) | [پی ایس پښتو] (/. github / README_PS.md) پشتو | [فا فارسی] (/. github / README_FA.md) | فارسی [pl plski] (/. github / README_PL.md) پولش | [pt Português] (/. github / README_PT.md) پرتگالی | [پنجابی] (/. گیتوب / README_PA.md) پنجابی | ایسی زبانیں دستیاب نہیں ہیں جو حرف Q کے ساتھ شروع ہوں [ro Română] (/. github / README_RO.md) رومانیہ | [ru русский] (/. github / README_RU.md) روسی | [ایس ایم فاسامووا] (/. گتوب / README_SM.md) سموان | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) اسکاٹ گیلک | [sr Српски] (/. github / README_SR.md) سربیا | [سینٹ سیسوتھو] (/. github / README_ST.md) سیسوتھو | [sn shona] (/. github / README_SN.md) شونا | [ایس ڈی سنڌي] (/. github / README_SD.md) سندھی | [si සිංහල] (/. github / README_SI.md) سنہالا | [sk سلوووک] (/. github / README_SK.md) سلوواک | [sl سلوščščina] (/. github / README_SL.md) سلووینیائی | [تو سومالی] (/. github / README_SO.md) صومالی | [[es en español] (/. github / README_ES.md) ہسپانوی | [ایس یو سنڈینس] (/. گیتوب / README_SU.md) سنڈانیز | [swiswawawa] (/. github / README_SW.md) سواحلی | [ایس آر سویونسکا] (/. گتوب / README_SV۔ایم ڈی) سویڈش | [tg Тоҷикӣ] (/. github / README_TG.md) تاجک | [ta தமிழ்] (/. github / README_TA.md) تمل | [tt Татар] (/. github / README_TT.md) تاتار | [te తెలుగు] (/. github / README_TE.md) تیلگو | [th ไทย] (/. github / README_TH.md) تھائی | [tr Türk] (/. github / README_TR.md) ترکی | [tk Türkmenler] (/. github / README_TK.md) ترکمان | [uk Український] (/. github / README_UK.md) یوکرین | [ur اردو] (/. github / README_UR.md) اردو | [ug ئۇيغۇر] (/. github / README_UG.md) یوغور | [اوز اوزبک] (/. گیتوب / README_UZ.md) ازبک | [vi Tiếng Việt] (/. github / README_VI.md) ویتنامی | [cy Cymraeg] (/. github / README_CY.md) ویلش | [xh isihhosa] (/. github / README_XH.md) ژوسا | [yi יידיש] (/. github / README_YI.md) یدش | [yo Yoruba] (/. github / README_YO.md) یوروبا | [زو زولو] (/. گتوب / README_ZU.md) زولو) 110 زبانوں میں دستیاب ہے (108 جب انگریزی اور شمالی کورین کی گنتی نہیں کررہا ہے ، کیوں کہ شمالی کورین کا ترجمہ ابھی نہیں ہوا ہے [اس کے بارے میں یہاں پڑھیں]) / (اولڈ ورزن / کورین (شمالی) ) /README.md))

انگریزی کے علاوہ دوسری زبانوں میں ترجمہ مشین کا ترجمہ کیا جاتا ہے اور ابھی تک درست نہیں ہے۔ 5 فروری 2021 تک تاحال کسی غلطی کا تعی beenن نہیں کیا گیا ہے۔ براہ کرم ترجمے کی غلطیوں کی اطلاع دیں [یہاں] (https://github.com/seanpm2001/Degoogle-your- Life/issues/) ذرائع کے ساتھ اپنی اصلاح کا بیک اپ یقینی بنائیں اور میری رہنمائی کریں ، چونکہ مجھے انگریزی کے علاوہ دوسری زبانیں نہیں آتی ہیں (میں آخرکار مترجم لینے کا ارادہ رکھتا ہوں) برائے کرم [ویکیشنری] (https://en.wiktionary.org) اور اپنی رپورٹ کے دیگر ذرائع کا حوالہ دیں۔ ایسا کرنے میں ناکامی کا نتیجہ شائع ہونے والی تصحیح کو مسترد کردے گا۔

نوٹ: گٹ ہب کی مارک ڈاون کی تشریح کی حدود کی وجہ سے (اور مارک ڈاون کی ہر دوسری ویب پر مبنی تشریح) ان لنکس پر کلک کرنے سے آپ کو ایک علیحدہ پیج پر ایک علیحدہ فائل کی طرف رجوع کیا جائے گا جو میرا گٹ ہب پروفائل پیج نہیں ہے۔ آپ کو [seanpm2001 / seanpm2001 مخزن] (https://github.com/seanpm2001/seanpm2001) پر ری ڈائریکٹ کیا جائے گا ، جہاں README کی میزبانی کی گئی ہے۔

گوگل ترجمے کے ساتھ ترجمے دوسرے زبان کی خدمات جیسے ڈی پی ایل اور بنگ ٹرانسلیشن (جس میں گوگل مخالف مہم کے لئے ایک خوبصورت ستم ظریفی) کی ضرورت ہے ان کی محدود زبانوں میں مدد کی وجہ سے کیا جاتا ہے۔ میں متبادل تلاش کرنے پر کام کر رہا ہوں۔ کسی وجہ سے ، فارمیٹنگ (روابط ، تقسیم ، بولڈنگ ، ترچ وغیرہ) مختلف تراجم میں گڑبڑ ہوتی ہے۔ یہ طے کرنا تکلیف دہ ہے ، اور میں نہیں جانتا کہ ان لاطینی حرفوں والی زبانوں میں ان مسائل کو کس طرح حل کرنا ہے ، اور دائیں سے بائیں زبانوں (جیسے عربی) کو ان مسائل کو ٹھیک کرنے میں اضافی مدد کی ضرورت ہے۔

بحالی کی پریشانیوں کی وجہ سے ، بہت سارے ترجمے پرانے ہیں اور اس `README` مضمون فائل کا پرانا ورژن استعمال کر رہے ہیں۔ مترجم کی ضرورت ہے۔ نیز ، 9 اپریل 2021 تک ، تمام نئے لنکس کو کام کرنے میں مجھے کچھ وقت لگے گا۔

***

## انڈیکس

[00.0 - عنوان] (# Degoogling --- Degoogle-your-Life)

> [00.1 - اشاریہ] (# انڈیکس)

[01.0 - بنیادی تفصیل] (# بنیادی تفصیل)

> [01.1 - مخزن ہیڈر] (# Degoogle-your-Life)

> [01.2 - Wuest3NFuchs وضاحت کا عمومی جائزہ] (# جائزہ بہ ویسٹ 3 این فوچ)

>> [01.2.1 - اس کا کیا مطلب ہے؟] (# اس کا کیا مطلب ہے - بذریعہ Wuest3nFuchs)

>> [01.2.2 - ڈیگل گوگل کیوں؟] (# کیوں - ڈیگل گوگل - بذریعہ Wuest3nFuchs)

[02.0 - مضامین] (# مضامین)

[03.0 - رازداری] (# رازداری)

[04.0 - گوگل کے خلاف دیگر مہمات] (# دیگر گوگل مخالف مہمات)

> [04.0.1 - ناکارہ] (# ناکارہ)

> [04.0.2 - جاری] (# جاری ہے)

[05.0 - دوسرے دلائل کا مقابلہ کرنا] (# کاؤنٹرنگ-دیگر دلائل)

> [05.0.1 - سہولت] (# سہولت)

> [05.0.2 - اس سے کیوں فرق پڑتا ہے؟ بہرحال بہت دیر ہو چکی ہے] ((# اس سے کیا فرق پڑتا ہے ، ویسے بھی بہت دیر ہو چکی ہے))

> [05.0.3 - دیگر] (# دوسرے)

[06.0 - ذرائع] (# ذرائع)

[07.0 - ڈاؤن لوڈ لنک] (# ڈاؤن لوڈ لنک)

[08.0 - میرا ڈگوگلنگ کا تجربہ] (# میرا-ڈگوگلنگ تجربہ)

> [08.1 - میں نے جس چیز سے تبدیل کیا ہے]] (# کیا میں نے تبدیل کیا)

> [08.2 - وہ پروڈکٹ جن سے میں اب بھی دور نہیں ہوسکتا] (# مصنوعات-I-still-get-दूर-نہیں ہوسکتے ہیں)

[09.0 - چیک آؤٹ کرنے کے لئے دوسری چیزیں] (# دوسری چیزوں سے چیک آؤٹ)

[10.0 - فائل کی معلومات] (# فائل معلومات)

> [10.1 - سافٹ ویئر کی حیثیت] (# سافٹ ویئر کی حیثیت)

> [10.2 - اسپانسر کی معلومات] (# اسپانسر-معلومات)

[11.0 - فائل کی تاریخ] (# فائل ہسٹری)

[12.0 - فوٹر] (# فوٹر)

***

## بنیادی تفصیل

[ویکیپیڈیا سے: ڈیگل گوگل] (https://en.wikedia.org/wiki/DeGoogle)

ڈی گوگل موومنٹ (جسے ڈی گوگل موومنٹ بھی کہا جاتا ہے) ایک نچلی سطح کی مہم ہے جس کی وجہ سے رازداری کے کارکنان کمپنی سے متعلق رازداری کے بڑھتے ہوئے خدشات کی وجہ سے صارفین کو مکمل طور پر گوگل پروڈکٹ کا استعمال بند کرنے کی تاکید کرتے ہیں۔ اس اصطلاح سے مراد کسی کی زندگی سے گوگل کو ہٹانے کا عمل ہے۔ چونکہ انٹرنیٹ دیو کی بڑھتی ہوئی مارکیٹ شیئر کمپنی کے لئے ڈیجیٹل جگہوں پر اجارہ داری طاقت پیدا کرتی ہے ، صحافیوں کی بڑھتی ہوئی تعداد نے کمپنی کی مصنوعات کے متبادل تلاش کرنے میں دشواری کا ذکر کیا ہے۔

**تاریخ**

2013 میں ، وینچربیٹ کے جان کویسیئر نے کہا تھا کہ ایمیزون کی جلائی فائر اینڈرائیڈ پر مبنی گولی "اینڈروئیڈ کا ایک ڈی گوگل ورژن ہے۔" 2014 میں یو ایس نیوز کے جان سمپسن نے گوگل اور دیگر سرچ انجنوں کے ذریعہ "فراموش ہونے کا حق" کے بارے میں لکھا تھا۔ 2015 میں ، آئرش ٹائمز کے ڈیرک اسکیلی نے "آپ کی زندگی کو ڈی-گوگل" کرنے کے بارے میں ایک مضمون لکھا۔ 2016 میں اینڈروئی کے کرس کارلونd اتھارٹی نے تجویز پیش کی کہ سیانوجن ماڈ 14 کے استعمال کنندہ اپنے فونوں کو "ڈی گوگل" کرسکتے ہیں ، کیونکہ سیانوجن ماڈ گوگل ایپس کے بغیر بھی ٹھیک کام کرتا ہے۔ 2018 میں الٹا کے نک لوکسی نے اس بارے میں لکھا کہ پروٹون میل "کس طرح اپنی زندگی کو ڈی-گوگل-فائی کرنے کے قابل ہو جائے" کے بارے میں فروغ دے رہا ہے۔ لائف ہیکر کے برینڈن ہیسی نے "گوگل چھوڑنا" کے بارے میں ایک تفصیلی ٹیوٹوریل لکھا۔ گیزموڈو صحافی کشمیر ہل کا دعوی ہے کہ وہ ملاقاتوں سے محروم رہ گئیں اور انہیں گوگل کیلنڈر کے استعمال کے بغیر میٹنگ اپ کو منظم کرنے میں دشواری کا سامنا کرنا پڑا۔ گوگل کے ذریعہ فراہم کردہ خدمات کے استعمال سے روک دیا گیا کیونکہ بہت کم متبادل موجود ہیں کہ کمپنی کی مصنوعات کی عدم موجودگی نے عام انٹرنیٹ کا ناقابل استعمال استعمال کردیا۔

***

# Degoogle-your-Life
عمومی ڈگوگلنگ معلومات اور میرے دوسرے ڈیگوگلنگ ذخیروں کے لنکس کیلئے ایک ذخیرہ۔

***

## Wuest3nFuchs کے ذریعے جائزہ

ایک بہتر وضاحت ، جو [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) کے ذریعہ فراہم کی گئی ہے - ماخذ: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### اس کا کیا مطلب ہے؟ بذریعہ Wuest3nFuchs

ڈیگوگلنگ کا مطلب ہے کہ کسی بھی ایسی چیز کو استعمال کرنا بند کردیں جو گوگل سے تعلق رکھتا ہو ، کوئی بھی چیز جو گوگل نے بنائی ہو۔ میں ان کے سرچ انجن ، ان کی میل سروس (جی میل) ، یوٹیوب وغیرہ کے بارے میں بات کر رہا ہوں۔

### کیوں ڈیگل؟ بذریعہ Wuest3nFuchs

گوگل اس وقت دنیا کی سب سے طاقتور کمپنیوں میں سے ایک ہے۔ انہوں نے ہم سب پر معلومات کی ایک بڑی رقم ذخیرہ کرلی ہے۔ کچھ لوگ یہ استدلال کریں گے کہ ہماری معلومات ان کے پاس محفوظ ہے کیونکہ وہ جانتے ہیں کہ اس کا تحفظ کرنا ہے۔ لیکن یہ سچ نہیں ہے۔ گوگل پہلے بھی داخل ہوچکا ہے اور آئندہ بھی اس میں دخول لیا جائے گا۔ ہوسکتا ہے کہ کسی اسکرپٹ کڈی کے ذریعہ نہ ہو لیکن یہ ایک قومی ریاست کرے گی۔ گوگل ہم سب پر ذاتی معلومات ذخیرہ کرتا ہے کیونکہ اس طرح وہ پیسہ کماتے ہیں۔

وہ ہمارے ای میلز کو اسکین کرتے ہیں ، جب ہم ان کے سرچ انجن کا استعمال کرتے ہیں تو ہم کیا تلاش کرتے ہیں ، جو یوٹیوب پر ہم دیکھتے ہیں اسے اسٹور کرتے ہیں۔ اس طرح وہ ہمیں نشانہ بناتے ہیں اور ہم پر ایک پروفائل بناتے ہیں تاکہ ہمیں اپنے اشتہار پر مبنی کچھ اشتہار دکھایا جا we جو ہم نے اپنے بہترین دوست کے ساتھ بات کی تھی تاکہ وہ ہمیں کسی چیز کی ضرورت کے لئے اشتہار دکھا سکیں ، لیکن یہ بہت عجیب ہے۔ مسٹر سنوڈن کا شکریہ اب ہم جان چکے ہیں کہ ** "PRISM" ** کے نام سے ایک پروگرام کے تحت گوگل نے ہماری ذاتی معلومات NSA کے ساتھ شیئر کی ہے۔


مستقبل میں کوئی ان تمام معلومات تک رسائی حاصل کرنے کے اہل ہو گا اور میں آپ کو یقین دلاتا ہوں کہ واقعی کچھ خراب ہونے والا ہے۔ اس سے بچنے کے ل To ، آپ کو ابھی ڈیگوگلنگ شروع کرنی چاہئے۔ نیز آپ کو کسی کمپنی کے ذریعہ ایسی مصنوعات کا استعمال نہیں کرنا چاہئے جو آپ کا ڈیٹا ** NSA ** کے ساتھ شیئر کریں۔ آپ کو ڈیگوگلنگ کر کے ان سب کو روکنا چاہئے۔

** اگر دوسرے لوگ یہ کرسکتے ہیں تو ، آپ بھی کر سکتے ہیں۔ **

[یہاں مزید پڑھیں] (https://github.com/Wuest3nFuchs/Degoogle)

<! - کانٹا کا ایک لنک فی الحال درج نہیں ہے ، کیوں کہ میں اس ذخیرہ اندوزی کا مکمل مالک نہیں ہوں ، اور دوسرے ذرائع کو فروغ دینا چاہتا ہوں۔ اپنے ہی https://github.com/Degoogle-your- Life/Degoogle سے لنک کرنا خود غرض ہوگا! ->

***

## مضامین

### مضمون کی حیثیت

_اس وقت تمام مضامین جاری کام ہیں اور ان میں بڑے پیمانے پر بہتری کی ضرورت ہے۔ تجاویز اور اصلاحات کی اجازت ہے ۔_

_ 18 اپریل 2021 کی شام 4:09 بجے تک ، زیادہ تر مضامین ابھی شروع نہیں کیے گئے ہیں۔ میں ان کو شروع کرنے کے لئے وقت اور کوشش کی تلاش میں کام کر رہا ہوں ۔_

[آپ کو گوگل کروم کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[کروم بوکس کا استعمال بند کریں] (https://github.com/seanpm2001/Stop-used-Chromebooks) <! - 2! ->

[وائڈ وائن DRM کا استعمال بند کرو / WideVine DRM کاٹنے کا وقت آگیا ہے]

[آپ کو ReCaptcha کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-ReCaptcha) <! - 4! ->

[یوٹیوب سے ردوبدل] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[گوگلنگ کو روکیں ، آپ کو گوگل سرچ کا استعمال کیوں بند کرنا چاہ]] >

[آپ کو جی میل کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Gmail) <! - 7! ->

[آپ کو Android کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Android) <! - 8! ->

[آپ کو گوگل امپ سے کیوں گریز کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[آپ کو گوگل ڈرائیو کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Drive) <! - 10! ->

[آپ کو گوگل میپس اور گوگل ارتھ کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-maps-and-Google-Earth) <! - 11! - ->

[ارے گوگل ، رکو] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[گوگل / پلے کی کتابوں سے پڑھنا بند کریں] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[گوگل کلاس روم کا استعمال بند کریں] (https://github.com/seanpm2001/Stop-used-Google-Classroom) <! - 14! ->

[آپ کو گوگل ٹرانسلیٹ کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Translate) <! - 15! ->

[آپ کو اپنا گوگل اکاؤنٹ (زبانیں) کیوں استعمال کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-sسب سے اوپر استعمال کرنے والے - گوگل اکاؤنٹس) <! - 16! ->

** جلد ہی نئے مضامین لکھے جائیں گے: **

[آپ کو جیریٹ کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Gerrit) <! - 17! ->

[آپ کو گوگل تجزیات کا استعمال کیوں چھوڑنا چاہئے (24 فروری 2021 ء بروز بدھ شام شام 4 بج کر 24 منٹ پر ذخیرے ٹوٹ گئے ہیں)] (https://github.com/seanpm2001/ کیوں- آپ - شاول- اسٹاپ- استعمال -Google-تجزیات) <! - 18! ->

<! - کام تقسیم! ->

[آپ کو گوگل ایڈسینس کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-AdSense) <! - 19! ->

[آپ کو گوگل ون کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-One) <! - 20! ->

[آپ کو Google+ کا استعمال کیوں بند کرنا چاہئے (ناکارہ)] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Plus) <! - 21! ->

[آپ کو گوگل پلے اسٹور کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-the-Google-Play-Store) <! - 22! ->

[آپ کو گوگل دستاویزات کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Docs) <! - 23! ->

[آپ کو گوگل سلائیڈوں کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Slides) <! - 24! ->

[آپ کو گوگل شیٹس کا استعمال بند کیوں کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google- شیٹس) <! - 25! ->

[آپ کو گوگل فارم کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google- forms) <! - 26! ->

[آپ کو گوگل کارڈ بورڈ کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Cardboard) <! - 27! ->

[آپ کو گوگل پیغامات کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Messages) <! - 28! ->

[آپ کو گوگل میٹریل ڈیزائن کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Material-Design) <! - 29! ->

[آپ کو گوگل گلاس / شیشے کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google- Glass) <! - 30! ->

[آپ کو گوگل فوچیا کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Fuchsia) <! - 31! ->

[آپ کو GBoard کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-GBoard) <! - 32! ->

[آپ کو گوگل ہوم کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Home) <! - 33! ->

[آپ کو گوگل گھوںسلا کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google- Nest) <! - 34! ->

[آپ کو گوگل ہینگٹس (ناکارہ) کیوں استعمال کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Hangouts) <! - 35! ->

[آپ کو گوگل جوڑی کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Duo) <! - 36! ->

[آپ کو گوگل ٹینسور فلو کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Tensorflow) <! - 37! ->

[آپ کو گوگل بلاکلی سے استعمال کرنا کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-B blockly) <! - 38! ->

[آپ کو گوگل پھڑپھڑانا کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Flutter) <! - 39!>

[آپ کو گوگلز گو پروگرامنگ زبان کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Go) <! - 40! ->

[آپ کو گوگلز ڈارٹ پروگرامنگ لینگویج کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Dart) <! - 41! ->

[آپ کو گوگلز ویب پی پی کی شکل کی شکل کیوں استعمال کرنا بند کرنی چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-WebP) <! - 42! ->

[آپ کو Googles WebM ویڈیو فارمیٹ کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-WebM) <! - 43! ->

[آپ کو گوگل ویڈیو کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Video) <! - 44! ->

[آپ کو گوگل سائٹس (کلاسک) کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Sites_Classic) <! - 45! ->

[آپ کو گوگل سائٹیں ("نیا") کیوں استعمال کرنا چھوڑنا چاہ]؟] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Sites_New) <! - 46! ->

[آپ کو گوگل پے کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Pay) <! - 47! ->

[آپ کو Android پے کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Android-Pay) <! - 48! ->

[آپ کو گوگل وی پی این (آکسیمونون) کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-VPN) <! - 49! ->

[آپ کو گوگل فوٹو کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Photos) <! - 50! ->

[آپ کو گوگل کیلنڈر کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-C کیلنڈر) <! - 51! ->

[آپ کو وائرس ٹوٹل کا استعمال کیوں بند کرنا چاہئے (چونکہ یہ ستمبر 2012 سے گوگل کی ملکیت ہے] (https://github.com/seanpm2001/Why-you-should-stop- using-VirusTotal) <! - 52! - >

[آپ کو گوگل فائی کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Wy-you-should-stop-using-Google-Fi) <! - 53! ->

[آپ کو گوگل اسٹڈیا کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/ کیوں- آپ آپ-Sould-stop- using-Google-Stadia) <! - 54! ->

[آپ کو گوگل کیپ کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Kip) <! - 55! ->

[آپ کو گوگل بیس کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Base) <! - 56! ->

[آپ کو گوگل سمر آف کوڈ میں شرکت کرنا کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Summer-of-code) <! - 57! - >

[آپ کو گوگل کیمرہ استعمال کرنا کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Camera) <! - 58! ->

[آپ کو گوگل کیلکولیٹر کا استعمال کیوں چھوڑنا چاہئے (انتہائی معلوم ہوسکتا ہے ، لیکن آپ کو ہر چیز سے ڈیگول کرنا چاہئے ، جس سے متبادل آسان ہے)] (https://github.com/seanpm2001/Why-you-should-stop- using-Google- کیلکولیٹر) <! - 59! ->

[آپ کو گوگل سروے + انعامات کا استعمال کیوں بند کرنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-Survey-rewards) <! - 60! ->

[آپ کو گوگل ڈرائنگ کا استعمال کیوں چھوڑنا چاہئے] (https://github.com/seanpm2001/Why-you-should-stop- using-Google- Drawings) <! - 61! ->

[آپ کو ٹینر (GIF سائٹ ، جو گوگل کی ملکیت 2019 سے ہے) کو استعمال کرنے سے کیوں روکا جائے؟] (https://github.com/seanpm2001/Why-you-should-stop- using-Google-enor) <! - 62! - ->

[کیا FLoC ہے - آپ Googles کے بڑے FLoCing مسئلے سے کیوں گریز کریں (گوگل کروم کا استعمال بند کریں)] (https://github.com/seanpm2001/What-tL-FLoC) <! - 63! ->

** کل مضامین: ** `63`

** آرٹیکل [روڈ میپ اے بی] (ڈیگل گوگل کمپین_2021 روڈ میپ_Part1.md) (12 مارچ 2021 تک) 2 دن کی چھٹی **

** آرٹیکل [روڈ میپ بی بی] (ڈیگل گوگلکیمپین_2021 روڈ ماؤ_پارٹ 2. ایم ڈی) (2021 تک) 2 دن کی چھٹی **

مضمون کی حیثیت

تمام مضامین فی الحال کام جاری ہیں اور ان میں بڑے پیمانے پر بہتری کی ضرورت ہے۔ تجاویز اور اصلاحات کی اجازت ہے۔

** فورکس **

میرے ڈیگول نیٹ ورک کو وسعت دینا ، اور رسائی میں آسانی اور برادری کے شور مچانا شامل کرنا۔

1. [فوس ایپز] (https://github.com/Degoogle-your- Life/Fossapps) | منجانب: [https://github.com/wacko1805/Fossapps ٹھٹہ https://github.com/wacko1805/Fossapps) (انگریزی)

2. [پرائیویسی لینکز] (https://github.com/Degoogle-your- Life/Privacy-links) | منجانب: [https://github.com/Arturro43/privacy-links پوٹhhps://github.com/Arturro43/privacy-links) (پولش)

3. [لذت انگیز رازداری] (https://github.com/Degoogle-your- Life/Delightful- رازداری) | سے تشکیل دی گئی: [https://github.com/LinuxCafeFederation/Delightful- رازداری کے لئے

4. [بلاک لسٹس] (https://github.com/Degoogle-your- Life/ blocklists) | منجانب: [https://github.com/jmdugan/ blocklists پو(https://github.com/jmdugan/ blocklists) (انگریزی)

5. [Degoogle ، بذریعہ Wuest3nFuchs] (https://github.com/Degoogle-your- Life/Degoogle) | منجانب: [https://github.com/Wuest3nFuchs/Degoogle قرآن(https://github.com/Wuest3nFuchs/Degoogle) (انگریزی)

**متعلقہ**

[ڈیگولڈ اینڈرائڈ فون ورچوئل مشین ریسرچ] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Rearch)

**بھی دیکھو:**

[ویکی پیڈیا پر گوگل پر تنقید] (https://en.wikedia.org/wiki/Criticism_of_Google)

[گوگل قبرستان (مارٹ بائی گوگل ڈاٹ کام) - گوگل نے مارے گئے 224+ مصنوعات کی چھانٹی کی فہرست] (https://killedbygoogle.com/)

> [گٹ ہب لنک] (https://github.com/codyogden/killedbygoogle)

[حروف تہجی ورکر یونین - 800 میں ممبروں پر مشتمل گوگل میں نئی ​​ورکرز یونین] (https://lphabetworkersunion.org/people/our-union/)

[ڈایناسور ایسٹر انڈے کے ساتھ حصہ نہیں لینا چاہتے ہیں؟ اس ویب سائٹ نے آپ کا احاطہ کیا ہے] (https://chromedino.com/)

***

## رازداری

[جی] (https://en.wikedia.org/wiki/Criticism_of_Google) [o] (https://en.wikedia.org/wiki/PRISM_ (نگرانی_پگرام)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-ivil/) [l] (https://securitygladiators.com/chrome- رازداری -باد /) [ای] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-on-on-on-गोपनीयता آپ کی نجی معلومات کے مطابق [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)(s/( https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / اندراج / کیوں googles-spying-on-use_b_3530296) [ای] (https://medium.com/digiprivacy/i-stopped-used-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-hehe alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // پروٹون میل۔ com / بلاگ / google-رازداری-مسئلہ /) [ای] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upreg-दीप-link-update-chrome -باؤزر /) [r] (https://www.wired.co.uk/article/duckduckgo-google-al متبادل-search-privacy) [y] (https://en.wikedia.org/wiki/No_hide_arتعزیر # تنقید) [b] (https://spreadprivacy.com/three-reason-why-the-n nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -essay-नमस्ते / کچھ بھی نہیں چھپانے کی دلیل-کے پاس کچھ بھی نہیں کہنا ہے /) [d] (https://www.cnet.com/how-to/google-collects-a-frighting-amount- آپ کے اعداد و شمار کے بارے میں آپ کو اب ڈھونڈ سکتے ہیں اور اسے حذف کر سکتے ہیں /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-f ਭਵਿੱਖ- طاقت -آپ-پرسنل-ڈیٹا-n870501) [ای] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -مونیٹیز-اور) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-on-on-you-رازداری) [r] (https://www.dailymail.co.uk/sज्ञानtech/article-5743829/ Googles-vision-TOTAL-data- کلیکشن-انکشاف. html) [d] (https://www.reuters.com/article/us-lphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ صحت-صحت-ڈیٹا-پرائیویسی /) [h] (https://www.pcmag.com/news/google-sued-ov er-Kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project- nightingale-ascension/index.html) oلو_ہٹ https://en.wikedia.org/wiki/2018_Google_data_breach)eml(https://moz.com /blog/where-does-google-draw-the-data-collection-line) یحیی کے بارے میں https://mashable.com/article/google-android-data-collection-study/)layss/( https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html) oدو نمبر https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -قائد دعوے کی طرف سے -5-م آئی فون استعمال کنندہ) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reilers.com/article/dataprivacy -googleyoutube-Kidsdata-idUSL1N2J306W) [ای] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your- iPhone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // ٹاپ کلاسیکیشنز /لاوسوٹ- سیٹلمینٹ / پرائیویسی /google-says-class-action-lawsuit-plaintiffs-conmitted-to-data-collection/) دهر_( https://arstechnica.com/information-technology/2014/01 /hat-google-can-really-do-with-nest-or-really-nests-data/) yetihttps://www.cbsnews.com/news/google-education-spies-on-collections- ڈیٹا آن لاکھوں میں بچوں کا الزام لگایا گیا مقدمہ نیا میکسیکو اٹارنی جنرل /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -ندر-ہماری-ناک /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / ٹکنالوجی / گوگل- yout ube-ফাইন-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : //medium.com/digitlprivacywise/why-you-should-stop- using-google-chrome-6c934c9a827c) (میں اس کے ثبوت کے ساتھ آگے بڑھ سکتا تھا ، لیکن ان سب کو تلاش کرنے اور اس میں گزرنے میں زیادہ وقت درکار تھا مضامین)

اسپائی ویئر پر مشتمل گوگل کی تمام مصنوعات کی وجہ سے گوگل پروڈکٹ پر رازداری ہمیشہ ہی خراب رہتی ہے۔

اس سے کوئی فرق نہیں پڑتا ہے کہ آپ کیا کرتے ہیں ، جب آپ گوگل استعمال کررہے ہیں تو ، آپ کا تمام حساس ذاتی ڈیٹا گوگل اور دوسروں کو بھیجا جارہا ہے۔ گوگل کو بھی کھلا پروگراموں کے ذریعے دیکھا گیا ہے۔ مثال کے طور پر ، ذاتی تجربے سے (فائر فاکس پر) یوٹیوب ٹیب کھلا جس کا میں نے دورہ نہیں کیا تھا ، میں نے کئی ویڈیوز آف لائن دیکھے تھے (VLC Media Player) بعد میں جب میں سفارشات چیک کرنے گیا تو ، یہ تقریبا everything سب کچھ تھا جو میں نے دیکھا تھا۔ اس میں کوئی شک نہیں ہے کہ وہ دوسرے پروگراموں میں بھی جاسوسی کررہے ہیں۔

کروم (اور بہت سے دوسرے براؤزر) میں ایک پوشیدگی وضع موجود ہے۔ کروم میں ، یہ وضع بے معنی ہے ، کیوں کہ گوگل اب بھی آپ کے ڈیٹا کو میرا بنائے گا۔ یہاں تک کہ اگر آپ ڈیٹا مائننگ / ٹریکنگ کو بند کردیتے ہیں ، اور "ٹریک نہ کریں" سگنل ، حیرت کی حیرت کو اہل بناتے ہیں تو ، گوگل اب بھی آپ کے ڈیٹا کی کھدائی کررہا ہے۔

اگر آپ کو لگتا ہے کہ آپ کو چھپانے کے لئے کچھ نہیں ہے تو ، ** آپ بالکل غلط ہیں **۔ یہ دلیل کئی بار ختم کردی گئی ہے:

[ویکیپیڈیا کے توسط سے)

1. ایڈورڈ سنوڈن نے ریمارکس دیئے "یہ استدلال کرنا کہ آپ کو رازداری کے حق کی پرواہ نہیں ہے کیونکہ آپ کو چھپانے کے لئے کچھ بھی نہیں ہے یہ کہنا اس سے مختلف نہیں ہے کہ آپ کو آزادانہ تقریر کی پرواہ نہیں ہے کیونکہ آپ کے پاس کچھ کہنا نہیں ہے۔" میرے پاس کچھ بھی چھپانے کے لئے نہیں ہے ، 'آپ کہہ رہے ہیں ،' مجھے اس حق کی کوئی پرواہ نہیں ہے۔ ' حقوق کا کام کرنے کا طریقہ یہ ہے کہ حکومت کو آپ کے حقوق میں دخل اندازی کا جواز پیش کرنا ہوگا۔

Daniel. ڈینیل جے سولوو نے کرانیکل آف ہائیر ایجوکیشن کے لئے ایک مضمون میں کہا ہے کہ وہ اس دلیل کی مخالفت کرتا ہے۔ انہوں نے کہا کہ حکومت قرض دے سکتی ہےk کسی شخص کے بارے میں معلومات اور اس شخص کو نقصان پہنچانے ، یا خدمات تک رسائی سے انکار کے لئے کسی شخص کے بارے میں معلومات کا استعمال کرنا یہاں تک کہ اگر کوئی فرد واقعی غلط کاموں میں ملوث نہ ہوا ہو ، اور یہ کہ حکومت غلطیاں کرنے سے کسی کی ذاتی زندگی کو نقصان پہنچا سکتی ہے۔ سولوو نے لکھا "جب براہ راست مشغول ہوجاتے ہیں تو ، چھپی ہوئی کوئی بھی دلیل نہیں پکڑ سکتی ہے ، کیونکہ اس بحث کو اس کی رازداری کے بارے میں تنگ نظری پر توجہ مرکوز کرنے پر مجبور کرتی ہے۔ لیکن جب رازداری سے متعلق مسائل کی کثرت کا سامنا کرنا پڑتا ہے جس میں حکومتی اعداد و شمار جمع کرنے اور نگرانی سے آگے کا استعمال ہوتا ہے۔ انکشاف ، کچھ بھی نہیں چھپانے کی دلیل ، آخر میں ، کچھ کہنے کی ضرورت نہیں ہے۔ "

Privacy. ایڈم ڈی مور ، رازداری کے حقوق کے مصنف: اخلاقی اور قانونی بنیادیں ، نے استدلال کیا ، "یہ قول ہے کہ حقوق قیمت / فائدہ یا نتیجہ خیز قسم کے دلائل کے خلاف مزاحم ہیں۔ ہم یہاں اس نظریہ کو مسترد کر رہے ہیں کہ رازداری کے مفادات ہی نوعیت کے ہیں سیکیورٹی کے ل things تجارت کی جاسکتی ہے۔ انہوں نے یہ بھی بتایا کہ نگرانی معاشرے میں ظاہری شکل ، نسل ، جنسیت اور مذہب پر مبنی بعض گروہوں کو غیر متناسب طور پر متاثر کرسکتی ہے۔

computer. کمپیوٹر سیکیورٹی کے ماہر اور خفیہ نگاری کے بارے میں بروس شنئیر نے کارڈنل رچیلیو کے اس بیان کا حوالہ کرتے ہوئے مخالفت کا اظہار کیا ، "اگر کوئی مجھے سب سے ایماندار آدمی کے ہاتھ سے لکھے ہوئے لکیریں دے تو مجھے ان میں کچھ پائے گا کہ اس کو پھانسی پر لٹکایا جا" "۔ ریاست کی حکومت کسی فرد کو قانونی کارروائی یا بلیک میل کرنے کے لئے کسی شخص کی زندگی میں پہلو کیسے تلاش کرسکتی ہے۔ شنائئر نے بھی استدلال کیا کہ "بہت ساری غلط بحث کو 'سیکیورٹی کے خلاف رازداری' کی حیثیت سے پیش کرتے ہیں۔ اصل انتخاب آزادی کے مقابلہ میں کنٹرول ہے۔ "

Har. ہاروی اے سلور گلیٹ نے اندازہ لگایا ہے کہ عام آدمی ، اوسطا ، اچھinglyی طور پر امریکہ میں ایک دن میں تین سنگینیت کا ارتکاب کرتا ہے۔

6. فلسفی اور ماہر نفسیات ، ایمیلیو موردینی نے استدلال کیا کہ "چھپانے کے لئے کچھ بھی نہیں" دلیل فطری طور پر متضاد ہے۔ لوگوں کو "کچھ" چھپانے کے لئے "کچھ چھپانے" کی ضرورت نہیں ہوتی ہے۔ موردینی کا دعوی ہے کہ جو کچھ پوشیدہ ہے وہ ضروری نہیں ہے۔ اس کے بجائے ، وہ ایک قریبی علاقے کی دلیل دیتے ہیں جو پوشیدہ ہوسکتا ہے اور دونوں تک رسائی محدود ہوسکتی ہے ، نفسیاتی طور پر ، ہم اس دریافت کے ذریعہ افراد بن جاتے ہیں کہ ہم دوسروں کے لئے کچھ چھپا سکتے ہیں۔

Jul. جولین اسانج نے بتایا کہ "ابھی تک اس کا کوئی قاتل جواب نہیں ملا ہے۔ جیکب اپیلبم (@ آئیرر) کا ایک چالاک جواب ہے ، انہوں نے ایسے لوگوں سے پوچھا جو اسے کہتے ہیں اس کے بعد اس کا فون کھلا اور اپنی پتلون کو نیچے کھینچ دو۔ میرا اس ورژن کا کہنا ہے کہ ، 'ٹھیک ہے ، اگر آپ اتنے غضبناک ہیں تو ہمیں آپ سے بات نہیں کرنی چاہئے ، اور نہ ہی کسی اور سے ہونا چاہئے' ، لیکن فلسفیانہ طور پر ، اصل جواب یہ ہے: بڑے پیمانے پر نگرانی ایک اجتماعی ساختی تبدیلی ہے۔ جب معاشرہ خراب ہوتا ہے تو ، یہ چل رہا ہے آپ کو اپنے ساتھ لے جانے کے ل. ، چاہے آپ زمین کے سب سے کمزور فرد ہو۔ "

law. قانون کے پروفیسر ، اِگناسیو کوفون نے استدلال کیا ہے کہ اس دلیل کو اپنی شرائط میں غلطی سے سمجھا جاتا ہے کیونکہ ، جب بھی لوگ دوسروں کو متعلقہ معلومات کا انکشاف کرتے ہیں تو وہ بھی غیر متعلقہ معلومات کا انکشاف کرتے ہیں۔ اس غیر متعلقہ معلومات پر رازداری کے اخراجات ہوتے ہیں اور اس سے امتیازی سلوک جیسے دیگر نقصانات ہوسکتے ہیں۔

***

## دوسری اینٹی گوگل مہمات

یہ گوگل کے خلاف قابل ذکر دیگر مہموں کی فہرست ہے۔ یہ فہرست نامکمل ہے۔ آپ اس میں توسیع کرکے مدد کرسکتے ہیں۔

### ناکارہ

[سکروگلیڈ - مائیکروسافٹ کے ذریعہ (نومبر 2012 سے 2014)] (https://en.wikedia.org/wiki/Scroogled)

_ اس وقت کوئی اور اندراجات نہیں ہیں ۔_

### جاری ہے

_اس لسٹ میں فی الحال خالی ہے ۔_

***

## دوسرے دلائل کا مقابلہ کرنا

گوگل کو جواز پیش کرنے کے لئے لوگ کچھ دلائل دیتے ہیں۔ پہلے بڑے میں سے ایک کو پہلے ہی ڈیبونک کردیا گیا ہے [یہاں] (# رازداری) لیکن یہاں کچھ اور ہیں:

### سہولت

ہاں ، گوگل پروڈکٹ آسان محسوس ہوتے ہیں۔ تاہم ، آپ سہولت کے ل everything ہر چیز کا اچھ includingا تجارت کر رہے ہیں ، بشمول سیکیورٹی ، رازداری اور قابل اعتماد۔ گوگل گذشتہ برسوں سے زیادہ مستحکم ہوتا جارہا ہے ، اور ان کے سرورز زیادہ کم ہو رہے ہیں۔ ابھی ، گوگل سرور ماہانہ تقریبا ایک گھنٹہ میں 1-2 مرتبہ نیچے جاتے ہیں (خاص طور پر یوٹیوب)

بدقسمتی سے ، معاشروں کو گوگل پر انحصار کرنے کی وجہ سے ، گوگل انٹرنیٹ پر حاوی ہوچکا ہے ، اور زیادہ سے زیادہ کنٹرول کرنے کی کوشش میں ہے۔ 2012 میں ، جب گوگل 5 منٹ کے لئے نیچے چلا گیا ، تو یہ اطلاع ملی کہ ** عالمی ** انٹرنیٹ ٹریفک ** میں 40٪ کمی واقع ہوئی ** گوگل اکثر 1-2 گھنٹے کم رہتا ہے ، اور [اپنی اخلاقیات کی ٹیم کی فائرنگ سے] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) دوسری چیزوں کے علاوہ ، وہ کم سے کم آسان بننے جا رہے ہیں۔

سہولت ہمیشہ اچھی چیز نہیں ہوتی ہے۔ آپ کو کیا ہو رہا ہے اس سے آگاہ ہونا چاہئے اور جب وہ نیچے جاتے ہیں تو اس کے لئے تیار رہنا چاہئے ، کیوں کہ ایسا کرنے کا کوئی راستہ نہیں ہے کہ سرور ہر دفعہ ایک بار نہ نیچے آجائے۔

گوگل بھی اتنا آسان نہیں ہے جتنا آپ سوچتے ہیں۔ اور بھی زیادہ آسان سائٹیں ہیں۔ گوگل اس سے آسان نہیں ہے ، جب آپ ان کے بے ترتیب اکاؤنٹ کی معطلیوں اور منسوخوں کا جواب نہیں دیتے (جب تک کہ آپ گوگل کے ٹویٹر اکاؤنٹ پر کافی توجہ مبذول نہیں کرتے یا ان پر ،000 100،000،000 یا اس سے زیادہ کا مقدمہ نہیں لیتے ہیں) تب وہ آپ سے فائدہ اٹھاتے ہیں ، آپ کو خراب کرتے ہیں اور آپ کو ایک تکیا میں چیخنے پر مجبور کیا ، جہاں آپ کی چیخیں کوئی نہیں سن سکتا تھامدد کےلیے.

### کیوں فرق پڑتا ہے ، ویسے بھی بہت دیر ہوچکی ہے

یہ ایک کم عام دلیل ہے ، لیکن اس کی وضاحت کی ضرورت ہے۔ موجودہ حالت کے ساتھ ، بیشتر عالمی حکومتیں ، کئی طاقتور کارپوریشنوں کے ساتھ ، آپ کے ہر اقدام کو جانتے ہیں ، تو پھر کیوں اس سے دور ہونے کی زحمت کیوں کریں؟ اس کا جواب بہت آسان ہے: ** آپ مستحق ہیں **۔ اگر آپ اس مقام پر ان سے دور ہونے کا انتظام کرتے ہیں تو ، ان کے ل your آپ کی چالوں کو مزید جانچنا ان کے لئے مشکل ہے ، اور آپ ایک اور زیادہ نجی زندگی گزار سکتے ہیں۔

[1 ماخذ] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) ویسے ، میں جب بھی ایک ہفتہ سے بھی زیادہ وقت حاصل کرتا ہوں اس پوسٹ کو اپنا فری ریڈٹ ایوارڈ دیتا رہا ہوں۔ اب (میرے 500 کے تمام مفت سککوں کے ساتھ) اس موضوع کو مزید فروغ دینے کے لئے۔ اب تک ، میں نے اس پوسٹ کو 14 سے زیادہ مفت ایوارڈز دیئے ہیں۔ یہ زیادہ نہیں ہے ، لیکن چھوٹی چھوٹی چیزیں اس پر منحصر ہوتی ہیں کہ یہ کس طرح سمجھا جاتا ہے ، اور کس کے ذریعہ۔

### دوسرا

اس وقت میرے پاس کوئی اور دلیل نہیں ہے۔

_یہ فہرست نامکمل ہے_

***

## ذرائع

کاپی:

[جی] (https://en.wikedia.org/wiki/Criticism_of_Google) [o] (https://en.wikedia.org/wiki/PRISM_ (نگرانی_پگرام)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-ivil/) [l] (https://securitygladiators.com/chrome- رازداری -باد /) [ای] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-on-on-on-गोपनीयता آپ کی نجی معلومات کے مطابق [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)(s/( https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / اندراج / کیوں googles-spying-on-use_b_3530296) [ای] (https://medium.com/digiprivacy/i-stopped-used-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-hehe alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // پروٹون میل۔ com / بلاگ / google-رازداری-مسئلہ /) [ای] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upreg-दीप-link-update-chrome -باؤزر /) [r] (https://www.wired.co.uk/article/duckduckgo-google-al متبادل-search-privacy) [y] (https://en.wikedia.org/wiki/No_hide_argument# تنقید) [b] (https://spreadprivacy.com/three-re मौसम-why-the-n nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -مثالات / کچھ بھی نہیں چھپانے کی دلیل - کے پاس کچھ بھی نہیں کہنا ہے /) [d] (https://www.cnet.com/how-to/google-collections-a-frighting-amount-of- اس کے بارے میں آپ کو اعداد و شمار کے بارے میں آپ ڈھونڈ سکتے ہیں اور اسے حذف کر سکتے ہیں /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-yur -پرسنل-ڈیٹا-n870501) [ای] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -اور) [c] (https://www.wired.com/story/google-tracks-you -پرائیویسی /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/s سائنسtech/article-5743829/Googles-vision-TOTAL-data-colલેક્--veve.h.hml) دوہائٹ ​​https://www.reuters.com/article/us-lphabet- google-رازداری - قانونی چارہ جوئی - idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google تعلیم سے متعلق کروم بوکس کے اوپر بچوں کا ڈیٹا کلیکشن) [ای] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-go સરકાર-google-data-colલેક્-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project- nightingale-ascension/index.html) oo(https://en.wikedia.org/wiki/2018_Google_data_breach) পরিবার میں moz.com/bl og / where-do-google-draw-the-Data-collection-line) [ای] (https://mashable.com/article/google-android-data-colલેક્-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / ٹکنالوجی / google-europe-gdpr-ফাইনھ html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- دعوے کے مطابق - 5-ملین-آئی فون صارفین کی نمائندگی) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reilers.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)eeee(( http://www.adweek.com/performance-marketing/google-is-collecting-yur-data-even-when-yur استعمال میں آئی فون نہیں ہے /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. ایچ ٹی ایم ایل) [p] (https://topclassजे.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-conmitted-to-data-collection/) [r] (https: // arstechnica .com / معلوماتیآن ٹکنالوجی / २०१ / / 01 / گھوںسلا یا واقعی گھوںسلا کے اعداد و شمار کے ساتھ کیا کر سکتے ہیں- [i] (https://www.cbsnews.com/news/google-education بچوں کے الزامات کے دعوے کے مطابق نیا میکسیکو-اٹارنی جنرل / -اسپیس آن ڈیٹیرکس ڈیٹا آن-میکسیکو-اٹارنی جنرل /) [v] (https://www.nationalreview.com/2018/04/the- اسٹوڈنٹ ڈیٹا مائننگ اسکینڈل کے تحت ہماری ناک /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) y]]]]]]]]]yytt https://medium.com/@hansdezwart/during-world-war-ii-we-did -Ave-things-to-hide-40689565c550) [.] (https://medium.com/digitlprivacywise/why-you-should-stop- using-google-chrome-6c934c9a827c)

دوسرے ذرائع:

[پانچ آنکھوں کا اتحاد] (https://en.wikedia.org/wiki/Five_Eyes) [انیس سو اٹھاسی] (https://en.wikedia.org/wiki/Nineteen_Eight-Four)

***

## لنکس ڈاؤن لوڈ کریں

[فائر فاکس حاصل کریں] (https://www.mozilla.org/en-US/firefox/new/) [ٹور براؤزر حاصل کریں] (https://www.torproject.org/download/) [دیگر / دستیاب نہیں] (https : //www.example.com)

***

## میرا ڈگولنگ تجربہ

میں نے آخر کار 2018 میں بڑی ٹیک والی پریشانیوں کو دیکھنا شروع کیا ، اور میں نے ڈگولنگ شروع کردی۔ پہلے چند مہینوں میں ، میں نے اہم پیشرفت کی۔ تب سے اس نے بے حد سست روی کا مظاہرہ کیا۔


### میں نے کیا بدلا ہے

گوگل کروم -> فائر فاکس / ٹور

گوگل سرچ -> ڈک ڈکگو (ڈیفالٹ) / ایکوسیہ (جب مجھے ایسا لگتا ہے) / بنگ (شاذ و نادر)

جی میل - پروٹون میل (ابھی تک مکمل طور پر تبدیل نہیں ہوا)

گوگل سائٹیں -> سیلف ہوسٹنگ (ابھی تک مکمل طور پر تبدیل نہیں)

Google+ -> کبھی بھی مشکل سے استعمال کیا گیا ، خود ہی اپنے بند ہونے کی وجہ سے خود کو حذف کردیا گیا

گوگل دستاویزات -> کبھی استعمال نہیں ہوتا ، اس کے بجائے میں مائیکروسافٹ ورڈ 2013 (2019 سے پہلے) اور لِبر آفس (2019 سے آگے) استعمال کرتا ہوں۔

گوگل شیٹس -> کبھی استعمال نہیں ہوا ، میں اس کے بجائے صرف مائیکروسافٹ ایکسل 2013 (2019 سے پہلے) اور لائبر آفس (2019 سے آگے) استعمال کرتا ہوں۔

گوگل سلائیڈ -> کبھی استعمال نہیں ہوا ، اس کے بجائے میں مائیکروسافٹ پاورپوائنٹ 2013 (2019 سے پہلے) اور لائبر آفس (2019 سے آگے) استعمال کرتا ہوں۔

گوگل ڈرائنگز -> کبھی استعمال نہیں ہوا ، میں اس کی بجائے صرف لِبر آفس (2019 ء) استعمال کرتا ہوں۔

جیریٹ -> کبھی استعمال نہیں ہوا ، میں اس کے بجائے صرف گٹ ہب (موجودہ ڈیفالٹ) ، گٹ لیب ، بٹ بکٹ اور سورس فورج استعمال کرتا ہوں۔

گوگل فوٹو -> کبھی استعمال نہیں ہوا

گوگل ڈرائیو -> ون ڈرائیو (2019-2020) ڈیگو (2020-2020) پی کلاؤڈ (2020-موجودہ)

گوگل نقشہ جات -> اوپن اسٹریٹ میپز / ایپل میپس

جاؤ - ایک خاص استثناء بنانا ، لیکن عملی پروگرامنگ زبان کے طور پر استعمال نہیں کرنا

ڈارٹ - ایک خاص استثناء بنانا ، لیکن عملی پروگرامنگ زبان کے طور پر استعمال نہیں کرنا

پھڑپڑڑ - ایک خاص استثناء بنانا ، لیکن عملی پروگرامنگ زبان کے طور پر استعمال نہیں کرنا

گوگل ارتھ -> اوپن اسٹریٹ میپز / ایپل میپس

گوگل اسٹریٹ ویو -> کبھی استعمال نہیں ہوا ، مجھے یہ اضافی عجیب لگتا ہے

Google Fi -> کبھی استعمال نہیں ہوا

گوگل کیلنڈر -> کبھی استعمال نہیں ہوا

گوگل کیلکولیٹر -> لفظی طور پر کوئی دوسرا کیلکولیٹر ایپ ، حتی کہ ایک لینکس ٹرمینل بھی اگر یہ مجھے اچھا لگتا ہے تو ازگر موڈ میں چلتا ہے

گوگل گھوںسلا -> کبھی استعمال نہیں کیا گیا

گوگل AMP -> کبھی استعمال نہیں ہوا

گوگل وی پی این -> کبھی استعمال نہیں ہوتا ہے ، آکسیومرون بھی

گوگل پے -> کبھی استعمال نہیں ہوا

گوگل سمر آف کوڈ -> کبھی حصہ نہیں لیا

ٹینر -> دیگر GIF سائٹیں ، اگرچہ GIF میرے لئے زیادہ اہم نہیں ہیں۔ میں عام طور پر ڈک ڈکگو امیجز ، امگور ، ریڈڈیٹ ، یا دوسری سائٹوں سے GIF فائلیں حاصل کرتا ہوں۔

ناکہ بندی -> اب استعمال نہیں ہوگا ، اس بات کا یقین نہیں ہے کہ سکریچ براہ راست بلاک چل رہا ہے۔ میں 2017 کے بعد ایک باضابطہ پروگرامر بن گیا ، اور شروع سے ہی بڑھ گیا۔

GBoard -> ایک بار استعمال ہوا ، لیکن ترک کردیا گیا

گوگل گلاس -> کبھی استعمال نہیں ہوا ، چھوٹا بچہ سمجھا جاتا ہے لیکن فیصلہ کیا ہے کہ اگر میرے پاس آپشن ہوتا تو کوئی ایک / استعمال نہ کریں

_ فہرست نامکمل ہوسکتی ہے ۔_

### وہ مصنوع جو میں اب بھی دور نہیں کر سکتا

25 فروری 2021 تک ، یہ وہ گوگل پروڈکٹس ہیں جو مجھے پوری طرح سے ڈاگلنگ سے روک رہے ہیں:

1. یوٹیوب

2. لوڈ ، اتارنا Android

3. گوگل پلے اسٹور

GM. جیمیل (صرف اسکول اور کچھ سائٹوں کے لئے)

5. گوگل کلاس روم (صرف اسکول کے لئے)

6. گوگل ترجمہ

7. گوگل اکاؤنٹ

8. گوگل سائٹیں (چونکہ گوگل جی ڈی پی آر کے قوانین کی خلاف ورزی کررہا ہے (اور جب تک وہ اس کو طے نہیں کر لیتے ہیں تب تک اس میں مزید ،000 5،000،000.00 جرمانے کا سامنا کرنا پڑسکتا ہے) اور اس پروڈکٹ کو ڈاؤن لوڈ کرنے سے منع کرتے ہیں)

میں باقی ہر چیز سے ہٹ گیا ہوں۔

***

## جانا شر ہے

گوگل نے 2003 کے ایجنٹ پر مبنی پروگرامنگ زبان `گو! over پر ان کی پروگرامنگ زبان` گو` (2009 سے ، 6 سال بعد) کے ساتھ بھاپ لیا اور دعوی کیا کہ ان کی زبان دوسری زبان کو بالکل بھی متاثر نہیں کرے گی۔ گوگل کو اس کے لئے بہت زیادہ تنقید کا نشانہ بنایا گیا تھا ، کیوں کہ اس وقت ان کا `برائی نہ بنو to مقصد ابھی تک متحرک تھا ، اور یہ بہت سے واقعات میں سے ایک ہے جو موٹو کو ریٹائر نہیں ہوا۔

آخر میں ، `گو! development کی ترقی ختم ہوگئی ، جبکہ` گو` زیادہ عام ہوتا گیا۔ گوگل نے دعوی کیا کہ وہ `گو! over پر گھومنے نہیں دیں گے لیکن آخر میں ، وہ کر گئے ، اور وہ اس سے دور ہو گئے (9 اپریل 2021 تک)

[گو اور یہاں متبادل کے بارے میں مزید معلومات حاصل کریں]

***

## DRM کا استعمال

گوگل اپنی وائڈ وائن DRM "سروس" اور دیگر فارموں کے ذریعہ DRM (ڈیجیٹل پابندیوں کا انتظام) استعمال کرتا ہے۔ ڈی آر ایم کا ہدف کھلا انٹرنیٹ کو ختم کرنا اور کمپنیوں کو صارفین پر اجارہ دار طاقت دینا ہے۔ آپ کو وائیڈ وائن کو مکمل طور پر چھٹکارا دینی چاہئے ، اس سے قطع نظر قیمت نہیں ہے۔

[وائڈ وائن اور اس کے مسائل کے بارے میں مزید پڑھیں]ٹو کٹ وائڈ وائن-ڈی آر ایم)

***

## عام غلط فہمیاں

یہ گوگل مصنوعات کے ساتھ کچھ عام غلط فہمیوں کی فہرست ہے۔

### گوگل انٹرنیٹ نہیں ہے

گوگل / گوگل سرچ انٹرنیٹ نہیں ہے ، گوگل سرچ صرف ایک سرچ انجن ہے ، اس طرح کی طرح کہ نینٹینڈو کے پلیٹ فارم کے لئے ہر کھیل نینٹینڈو کے ذریعہ نہیں بنایا جاتا ، بلکہ نائنٹینڈو کے ذریعہ لائسنس یافتہ ہوتا ہے ، لیکن اس سے کہیں زیادہ حد تک۔ اگر ابھی سارے گوگل سرور بیک وقت تباہ کردیئے جاتے تو صرف گوگل سائٹس جیسی یوٹیوب ، جی میل ، گوگل دستاویزات ، گوگل سرچ وغیرہ ختم ہوجاتی ، لیکن انٹرنیٹ کی اکثریت اب بھی وہاں موجود ہوگی (ویکیپیڈیا ، اسٹیک اوور فلو ، گٹ ہب ، مائیکروسوفٹس کی تمام ویب سائٹس ، این وائی ٹائمز ، سیمسنگ ، ٹک ٹوک وغیرہ۔ وہ اپنی گوگل سائن ان اور تجزیاتی فعالیت سے محروم ہوسکتے ہیں ، لیکن وہ پھر بھی فعال رہیں گے (بشرطیکہ وہ غیر تسلی بخش پروگرام نہ ہوتے اور براہ راست گوگل پر انحصار نہ کرتے)

***

## انٹرنیٹ ایکسپلورر 6 اور کروم

گوگل کروم نیا انٹرنیٹ ایکسپلورر 6 بن رہا ہے۔ جب گوگل کروم اصل میں سامنے آیا تھا تو ، فائر فاکس غالب براؤزر تھا ، اور اس نے انٹرنیٹ ایکسپلورر مارکیٹ کے شیئر کو زیادہ تر ہلاک کردیا تھا (جو لاکھوں افراد نے فائر فاکس اور دوسرے براؤزرز میں تبدیل ہونے سے پہلے ہی٪٪٪ کو پیچھے چھوڑ دیا تھا) جب گوگل کروم باہر آگیا ، لوگ اس کی رفتار کی وجہ سے تبدیل ہوگئے اور یہ گوگل کے ذریعہ ہونے کی وجہ سے تھا (جسے اس وقت برا سمجھا نہیں جاتا تھا ، کیوں کہ ابھی تک زیادہ تر رازداری کے معاملات سامنے نہیں آئے تھے) گوگل کروم اصل میں ویب معیارات کا احترام کرتا تھا (جس نے فائر فاکس نے کیا تھا) جس نے انٹرنیٹ ایکسپلورر کو٪ 96٪ براؤزر مارکیٹ شیئر سے ہلاک کردیا) تاہم ، جیسے جیسے گوگل کروم مارکیٹ کے شیئر میں اضافہ ہوا ، گوگل نے زیادہ سے زیادہ خصوصیات کو ہٹانا شروع کیا ، مزید اسپائی ویئر کو شامل کیا ، اور ویب معیار کو قبول کرنا چھوڑ دیا ، گوگل کروم نیا انٹرنیٹ ایکسپلورر 6 بن گیا ہے۔

ابھی سب سے بڑی پریشانی وہ ویب سائٹ ہے جو صرف کروم ہیں ، اور دوسرے براؤزرز پر کام نہیں کریں گی ، کیونکہ ان کے ڈویلپرز نے فیصلہ کیا ہے کہ وہ نہیں چاہتے ہیں کہ انٹرنیٹ کے دوسرے 30-40٪ صارفین جو اپنی سائٹ کو استعمال نہیں کریں گے۔

یہاں تک کہ گوگل خود بھی ان کی سائٹس کو صرف کروم بنا رہا ہے۔ مثال کے طور پر ، گوگل سرچ آپ کو ہر 10 سیکنڈ میں 3 بار کروم ڈاؤن لوڈ کرنے کا اشارہ کرے گی اگر اس سے پتہ چلتا ہے کہ آپ گوگل کروم استعمال نہیں کررہے ہیں (یہاں تک کہ دیگر کرومیم پر مبنی براؤزر جیسے بہادر بھی متاثر ہوئے ہیں) اور گوگل ارتھ جیسی سائٹیں فائر فاکس صارفین کو اجازت نہیں دیتی ہیں۔ ان کی سائٹ (2020 تک) استعمال کریں اور گوگل ٹرانسلیٹ فائر فاکس ، اور دوسرے غیر گوگل کروم براؤزرز پر وائس ان پٹ کی حمایت نہیں کرتا ہے۔

### بہادر کا مسئلہ

دوسرے براؤزر جو کرومیم پر مبنی ہیں ، جیسے بہادر اور مائیکروسافٹ ایج گوگل اسپائی ویئر سے مکمل طور پر آزاد نہیں ہیں۔ بہادری کی تجویز عام طور پر پرائیویسی برادری کے غلط رخ کے ذریعہ کی جاتی ہے ، لیکن بہادر ابھی بھی ایک مسئلہ ہے ، کیونکہ اس میں کرومیم استعمال ہوتا ہے۔ انٹرنیٹ میں صرف کرومیم براؤزرز پر مشتمل نہیں ہونا چاہئے ، اس میں مختلف قسم کا انتخاب ہونا چاہئے۔ بہادر غلط راستہ ہے۔

[گوگل کروم / کرومیم سے ڈگگلنگ کے بارے میں مزید پڑھیں] (https://github.com/Degoogle-your- Life/Why-you-should-stop- using-Chrome)

[ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) سے دیگگلنگ کے بارے میں مزید پڑھیں] (https://github.com/Degoogle-your- Life/Stop-used-Chromebooks)

***

## غلط رازداری کی تجدید

گوگل بہت حد تک دیر گزر جانے کے بعد ، دنیا کو یہ بتانے کی کوشش کر رہا ہے کہ وہ رازداری کے بارے میں اپنی پرواہ رکھتا ہے۔ ان کا یہ دعوی جاری ہے کہ وہ صارف کی رازداری کا احترام کرتے ہیں ، لیکن وہ اب بھی اپنی تمام رازداری کی دشواریوں کو ٹھیک نہیں کررہے ہیں۔

### اوپن سورس جزوی نہیں ہوسکتا

اوپن سورس جزوی نہیں ہوسکتا۔ گوگل اس کا ثبوت ہے۔ ماخذ کوڈ کے ہر بٹ اور بائٹ کو عوام کے ل visible نظر آنا ضروری ہے ، بائٹ کا آٹھواں حصہ بھی پوشیدہ نہیں ہے۔

Android اور ChromeOS جیسے منصوبے جزوی طور پر اوپن سورس ہیں ، لیکن اس میں زیادہ تر ملکیتی ، اسپائی ویئر عناصر ہوتے ہیں۔

### آکسیمون

گوگل وی پی این ایک آکسیمون ہے۔ گوگل کو رازداری کی پرواہ نہیں ہے ، اور ان جیسی کمپنی کا ورچوئل پرائیوٹ نیٹ ورک (وی پی این) وی پی این سروس کے ل the بدترین انتخاب میں سے ایک ہوگا۔

***

## خراب کارکردگی

گوگل کم سے کم 2017 تک اپنی مصنوعات کی کارکردگی کی پرواہ نہیں کرتا ہے ، کیونکہ ان کا آخری بینچ مارک سافٹ ویئر (گوگل آکٹین) کو 2017 میں بند کردیا گیا تھا۔

***

## خراب پراجیکٹ مینجمنٹ

گوگل کا اندرونی پراجیکٹ مینجمنٹ کا ایک بہت ہی خراب نظام ہے۔ پروگراموں کی کچھ عام مثالوں میں جو زیادہ سے زیادہ تنزلی کا شکار ہوچکے ہیں ان میں گوگل جوڑی اور یوٹیوب میوزک شامل ہیں (سابقہ ​​گوگل پلے میوزک)

گوگلز کے اندرونی ترقیاتی نظام میں ، 1 ایپ کسی اور ایپ کی طرف جاتا ہے جس میں نصف فعالیت ہوتی ہے ، پھر اصل ایپ حذف ہوجاتی ہے۔ کچھ سال بعد ، 75 less کم فعالیت والی ایک نئی ایپ بنائی گئی ہے ، اور پھر 50 function فعالیت والی ایپ کو ہٹا دیا جائے گا ، اس کے بعد ایک نیا ایپ تیار کیا جائے گا جس کے بعد 87 ٪.٪ function فعالیت پیدا ہوگی ، پھر 75 75 فیصد فعالیت والی ایپ کو بند کردیا گیا ہے۔ ، اور اسی طرح.

***

## خوفناک یا خدمات کا اعتدال نہیں

خراب اعتدال کی دنیا میں یوٹیوب سب سے عام مثال ہے جس کا وجود سب سے خراب پلیٹ فارم ہے۔ گوگل کو بھی ایسا نہیں لگتا ہے کہ یوٹیوب یوٹیوب بچے نہیں ہے۔

یوٹیوب کے لئے ، زیادہ مصروفیت کے وقت اور زیادہ سے زیادہ رقم کے مقصد سے نفرت انگیز نواز نازی اور سفید فام ماہر آمیز مواد صارفین کو پیش کیا جاتا ہے۔ گوگل نے بھی کچھ بہت کچھ کیا ہےان کے اعتدال پسندی میں بیوقوف چیزیں ، جیسے ایک کرسچن انل سیکس ویڈیو کو بطور مواد `بچوں کے لئے بنایا ہوا مواد کی منظوری دینا` جبکہ ایک ہی وقت میں ویڈیو پر پابندی عائد ہے۔ بچوں کے لئے تیار کردہ مختلف دیگر مواد کے ساتھ ساتھ ، بے بی شارک ویڈیو کے تحت فحش نگاری یا گور کے اشتہار دیکھنا بھی معمولی بات نہیں ہے۔

یوٹیوب کے صارفین خراب مواد (جیسے کہ اوپر دی گئی مثالوں کی طرح) پر یوٹیوب کے اعتدال پسندی کے بارے میں انتہائی کثرت سے شکایت کرتے ہیں جبکہ صارفین بغیر کسی وجہ کے منسوخ کرنے کی اہلیت کی بنا پر اپنے ویڈیوز کو بے ترتیب طور پر حذف کرسکتے ہیں ، ساتھ ہی صارفین کو کسی بھی قسم کی قسم کھاتے ہوئے سزا دی جاتی ہے ، یہاں تک کہ بہت معمولی معاملات جیسے کہ `کراپ` استعمال کرنے والے عام طور پر یوٹیوب کا تقابل اسٹالین دور میں [سوویت یونین] (https://en.wikedia.org/wiki/Soviet_Union) سے کرتے ہیں ، ان غیر معمولی سزاوں کی وجہ سے۔

2021 میں ، گوگل نے اعلان کیا کہ وہ ویڈیو کو شیطان بنائے جانے کے باوجود ، تمام ویڈیوز پر اشتہار لگائیں گے (تاکہ گوگل پیسہ کما سکے ، لیکن تخلیق کار نہیں کرتا ہے) اس کا اعتدال سے بہت زیادہ تعلق نہیں ہے ، لیکن یہ نوٹ کرنا ضروری ہے۔

یوٹیوب معتدل ہے (اگرچہ بہت خراب)

[یوٹیوب کے اعتدال پسندی کے معاملات اور یوٹیوب سے متبادل کے بارے میں مزید پڑھیں] (https://github.com/seanpm2001/Alternating-from-YouTube)

گوگل پلے کے اشتہارات بوٹ فارموں سے تیار کیے گئے ہیں ، آپ اسی اشتہاری منظرنامے کے ذریعہ بتاسکتے ہیں کہ سیکڑوں کمپنیاں بہت کم تبدیلیاں لیتے ہیں ، اور اس مصنوع سے کوئی تعلق نہیں رکھتے ہیں (عام مثالوں میں: پلے رکس (ہوم ​​اسکیپز ، گارڈنکیپس) فشڈوم ، مافیا سٹی ، اور ہزاروں مزید) اشتہارات کے عروج پر مبنی مذموم رجحان کے ساتھ یہ بھی دعوی کیا گیا ہے کہ صارفین کھیل کھیل کر ، موسیقی سننے وغیرہ سے رقم کما سکتے ہیں۔ پے پال نے اس پر کوئی تبصرہ نہیں کیا ہے ، لیکن یہ ظاہر ہے کہ یہ ایک اسکینڈل ہے ، گویا آپ یہ بنا سکتے ہیں۔ 20 سیکنڈ سے بھی کم وقت میں 10،000 سے بھی کم رقم کی ضمانت کا کھیل کھیل کر ، کوئی بھی کام نہیں کرے گا اور اس کی بجائے یہ کام کر رہا ہوگا ، جو ناممکن ہے ، اور کوئی کاروبار اس طرح کام نہیں کرسکتا ہے۔ یہ واضح گھوٹالہ 2019 کے بعد سے مضبوط ہورہا ہے ، اور اب یہ اشتہار تیار کرنے والے بوٹ فارم اپنے اشتہارات میں ایک دوسرے سے لڑ رہے ہیں۔

متعدد اشتہارات بھی بے حد فحش ہیں ، اور جنسی جوڑتوڑ کے ذریعے صارفین (جن میں سے زیادہ تر 13 سال سے کم عمر کے افراد ، یا بوٹس) ہیں کو کلک کرنے کی کوشش کرتے ہیں۔

بہت ساری ایپس اپنی مصنوعات کو بوٹس اور ایسٹروٹرف استعمال کرتی ہیں ، لہذا جب بھی کوئی خراب جائزہ لیا جائے گا تو ساک کٹھ پتلی بوٹ اکاؤنٹس 5 اسٹار جائزے شائع کرنا شروع کردیں گے اور آپ کی تنقید کی نفی کرنے کی کوشش کریں گے۔ [گوگل خود بھی یہ کام کر رہا ہے] (# Astroturfing)

[گوگل ایڈسینس سے متعلق امور کے بارے میں مزید پڑھیں] (https://github.com/Degoogle-your- Life/Why-you-should-stop- using-Google-AdSense)

***

## آسٹرو ٹرفنگ

عمومی تعریف [(ویکیپیڈیا سے)] (https://en.wikedia.org/wiki/Astroturfing)

`` `
ایسٹروٹرفنگ ایک پیغام یا تنظیم (جیسے ، سیاسی ، اشتہار بازی ، مذہبی یا عوامی تعلقات) کے کفیل افراد کو نقاب پوش کرنے کا رواج ہے تاکہ اس کو ظاہر کیا جاسکے جیسے اس کی ابتداء نچلی سطح کے شرکاء کے ذریعہ کی جاتی ہے۔ یہ ذریعہ کے مالی رابطے کے بارے میں معلومات کو روک کر بیانات یا تنظیموں کو ساکھ دینا ایک مشق ہے۔ ایسٹروٹرفنگ کی اصطلاح ایسٹرو ٹرف سے ماخوذ ہے ، جو مصنوعی قالین کا ایک برانڈ ہے جو قدرتی گھاس سے ملنے کے لئے ڈیزائن کیا گیا ہے ، لفظ "گراس روٹس" پر ایک ڈرامے کے طور پر۔ اصطلاح کے استعمال کے پس پردہ مطلب یہ ہے کہ زیربحث سرگرمی کے پیچھے "سچ" یا "قدرتی" نچلی کوششوں کی بجائے ، حمایت کی "جعلی" یا "مصنوعی" نمائش ہے۔
`` `

گوگل کے پاس ایسٹروٹرفنگ کی تاریخ ہے جس سے یہ معلوم ہوتا ہے کہ وہ کوئی برائی نہیں کر رہے ہیں (اس عمل میں ، ایسٹروٹرفنگ برائی ہے) مثال کے طور پر ، ٹویٹر جیسے پلیٹ فارم پر گوگل (جس کا انکا اکاؤنٹ ہے) پر تنقید پوسٹ کرنا نتیجہ نکلے گا۔ متعدد اکاؤنٹس جو کچھ عرصے کے لئے موجود ہیں لیکن کبھی بھی شائع نہیں ہوئے اور سامنے آنے سے پہلے یہ دعویٰ کیا کہ آپ نے جو کہا وہ جھوٹا ہے ، اور پھر یہ دعویٰ کرنا کہ گوگل سب سے اچھی کمپنی ہے ، لیکن ایسا اس طرح کیا گیا کہ یہ واضح نہیں ہوگا کہ یہ زیادہ تر لوگوں کے لئے بوٹ ہیں۔ لوگ

***

## غیر قانونی اور غیر اخلاقی کاروباری عمل

گوگل اپنی اجارہ داری کو آگے بڑھانے کے لئے غیر قانونی اور غیر اخلاقی کاروباری طریقوں کا استعمال کرتا ہے ، جیسے ٹیکس پناہ گاہوں کا استعمال ، آؤٹ سورسنگ ملازمتیں ، اور کاروبار کرنے کے اخراجات کے طور پر غیر قانونی حملہ آور سرگرمیاں جاری رکھنا۔

### یورپ میں

یوروپ نے اکثر گوگل پر مقدمہ چلایا ، جو اینڈرائڈ میں غیر قانونی سلوک کے خلاف سب سے بڑا مقدمہ ہے ، جس کے نتیجے میں گوگل کو 5،000،000،000 (9 اپریل 2021 کے پیسے میں، 5،947،083،703.68 کے برابر) وصول ہوئے۔

### شمالی امریکہ میں

یوروپس € 5،000،000،000 جرمانہ کے مقابلے میں ، امریکہ نے ابھی تک گوگل کو تقریبا nearly زیادہ جرمانہ نہیں دیا ہے۔

### تنازعات

گوگل اس وقت تک کسی مسئلے کی پرواہ نہیں کرتا جب تک یہ تنازعہ پیدا نہیں کرتا ہے ، پھر وہ اس کو حل کرنے کے لئے ایک بری طرح کوشش کریں گے ، تنازعہ کو عارضی طور پر دور کرنے کے لئے کافی ہوگا اور مسئلہ اس وقت تک شدت سے بدتر ہوجاتا ہے جب تک کہ یہ ایک اور تنازعہ پیدا نہیں کرتا ہے۔ سائیکل جاری ہے. انہیں محض اس بات کی کوئی پرواہ نہیں ہے کہ وہ اس میں سنجیدہ ہیں۔

***

## گوگل خودکار ہے

بطور کامپان ، گوگل زیادہ تر خود کار ہوتا ہے ، آٹومیشن سے کم اعتدال کے ساتھ۔

کسی کمپنی کو مکمل طور پر خودکار نہیں ہونا چاہئے۔ گوگل اس کی ایک مثال ہے۔ اعتدال پسندی خوفناک ہے جب صرف اے آئی کے ذریعہ ہی کیا جاتا ہے ، یوٹیوب ایک اچھی مثال ہے ، یہاں تک کہ اضافی چند (سینکڑوں ، یا ایک ہزار) لوگوں نے سائٹ کو معتدل کیا ، جہاں یہ بظاہر اتنا خراب ہے کہ ان میں سے بیشتر کو کام کرتے ہوئے ہی تھراپی کرنی پڑتی ہے۔

***

## انڈروئد

Android کی ملکیت گوگل کے پاس ہے۔ اوپن ہینڈسیٹ الائنس کا ایک حصہ (جو اینڈرائیڈ کے بعد سے کھلا نہیں ہے) اینڈرائڈ گوگل کے لئے ایک اور اجارہ داری بن گیا ہے ، اور اس سے بچنا بہت مشکل ہے۔

اینڈرائڈ کو روزانہ کم سے کم 10 بار گوگل پر فون کرنے کی اطلاع دی گئی ہے ، اور جزوی طور پر کھلا ذریعہ ہونے کے باوجود ، یہ اب بھی اسپائی ویئر کی حیثیت سے بہت زیادہ کام کرتا ہے۔

اینڈروئیڈ سے متبادل کے ل Several کئی پروجیکٹس بنائے گئے ہیں ، لیکن آپ کے آلے کو جڑ سے اکھاڑنے کی ضرورت ہے۔ ناکس ڈی آر ایم کی وجہ سے ، امریکہ میں مخصوص سیمسنگ فونز کے لئے یہ آسانی سے ممکن نہیں ہے۔ اینڈروئیڈ کے عام متبادلات میں آئی او ایس ، آئی پیڈ او ایس ، لائن ای او ایس ، اینڈروئیڈ ایکس 86 ، اوبنٹو ٹچ اور پی فون شامل ہیں (پی فون ایک ایسے فون کا برانڈ ہے جو موبائل ڈیوائس پر مختلف لینکس سسٹم چلاتا ہے ، جیسے فیڈورا ، اوبنٹو ، آرک ، وغیرہ)

[دیگولڈ اینڈروئیڈ ورچوئل مشین کو فنکشنل حاصل کرنے کے بارے میں میری تحقیق دیکھیں] (https://github.com/Degoogle-your- Life/Degoogled_Android_Phone_VM_Rearch)

[دیکھیں Android سے ڈیگولس کو کیسے دیکھیں] (https://github.com/Degoogle-your- Life/Why-you-should-stop- using-Android)

***

## مدد کیلئے چھوٹے چھوٹے اقدامات

ہر ممکن طریقے سے آگاہی پھیلانا ضروری ہے۔ میرے لئے ، میں نہ صرف کثرت سے ڈیگوگلنگ کے بارے میں بات کرتا ہوں ، اور مضامین لکھتا ہوں ، لیکن میری ایک چھوٹی سی عادت بھی ہے ، جہاں میں بیداری پیدا کرنے کے لئے اپنے روزانہ مفت ریڈڈیٹ ایوارڈ کو r / degoogle پر پنڈ پوسٹ کو دیتا ہوں۔ اب تک ، میں نے پن کی ہوئی پوسٹ کو تقریبا 30 30 ایوارڈز دیئے ہیں (میں نے اپنے اشتہارات پر اپنے 500 میں سے 500 سکے بھی اس پوسٹ کے لئے 10 ایوارڈز پر خرچ کیے تھے)

***

## ناقابل برداشت

گوگل پر اعتبار نہیں کیا جاسکتا ، اور کبھی بھی کبھی اعتبار نہیں کیا جاسکتا۔ وہ "برائی مت بنو" (وہ ہمیشہ ہی بدکار تھے) سے مکمل طور پر بری ہو چکے ہیں اور اسے چھپانے کی کوشش نہیں کررہے ہیں۔

***

## چیک کرنے کے ل Other دوسری چیزیں

[گوگل قبرستان (مارٹ بائی گوگل ڈاٹ کام) - گوگل نے مارے گئے 224+ مصنوعات کی چھانٹی کی فہرست] (https://killedbygoogle.com/)

> [گٹ ہب لنک] (https://github.com/codyogden/killedbygoogle)

[حروف تہجی ورکر یونین - 800 میں ممبروں پر مشتمل گوگل میں نئی ​​ورکرز یونین] (https://lphabetworkersunion.org/people/our-union/)

[ڈایناسور ایسٹر انڈے کے ساتھ حصہ نہیں لینا چاہتے ہیں؟ اس ویب سائٹ نے آپ کا احاطہ کیا ہے] (https://chromedino.com/)

اور بھی متبادل ہیں ، بس ان کی تلاش کریں۔

***

اس مضمون کے لئے کچھ حقائق کی جانچ کی ضرورت ہے

***

## فائل کی معلومات

فائل کی قسم: `مارک ڈاون (* .md)`

لائن گنتی (بشمول خالی لکیریں اور مرتب لائن): `968`

فائل ورژن: `6 (اتوار ، 18 اپریل 2021 شام 4:18 بجے)`

***

### سافٹ ویئر کی حیثیت

میرے تمام کام مفت کچھ پابندیاں ہیں۔ DRM (** D ** igal ** R ** estrictions ** M ** anagement) میرے کسی بھی کام میں موجود نہیں ہے۔

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

یہ اسٹیکر مفت سافٹ ویئر فاؤنڈیشن کے ذریعہ تعاون یافتہ ہے۔ میں کبھی بھی DRM کو اپنے کاموں میں شامل کرنے کا ارادہ نہیں رکھتا ہوں۔

میں "ڈیجیٹل رائٹس مینجمنٹ" کے بجائے "ڈیجیٹل رکاوٹوں کا انتظام" کا مخفف استعمال کررہا ہوں کیونکہ اس کا ازالہ کرنے کا عام طریقہ باطل ہے ، ڈی آر ایم کے ساتھ کوئی حقوق نہیں ہیں۔ ہج "ہ "ڈیجیٹل پابندیوں کا انتظام" زیادہ درست ہے ، اور [رچرڈ ایم اسٹال مین (آر ایم ایس)] (https://en.wikedia.org/wiki/Richard_Stallman) اور [فری سافٹ ویئر فاؤنڈیشن (FSF)] کی حمایت کرتا ہے https://en.wikedia.org/wiki/Free_Software_Foundation)

اس حصے کا استعمال ڈی آر ایم کے ساتھ مسائل کے بارے میں شعور بیدار کرنے ، اور اس کے خلاف احتجاج کرنے کے لئے بھی کیا جاتا ہے۔ ڈی آر ایم ڈیزائن کے ذریعہ عیب دار ہے اور کمپیوٹر کے تمام صارفین اور سافٹ ویئر کی آزادی کے لئے ایک بڑا خطرہ ہے۔

تصویری کریڈٹ: [defectivebydesign.org/drm-free/... th(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## اسپانسر سے متعلق معلومات

! [اسپانسر بٹن ڈاٹ پی این جی] (اسپانسر بٹن ڈاٹ پی این جی) <- اس بٹن پر کلک نہ کریں ، یہ کام نہیں کرتا ہے ، یہ صرف ایک تصویر ہے۔ اصل بٹن دائیں (<- L ** R ** ->) کونے میں صفحے کے اوپری حصے میں ہے

اگر آپ چاہیں تو آپ اس منصوبے کی کفالت کرسکتے ہیں ، لیکن براہ کرم اس کی وضاحت کریں کہ آپ کونسا عطیہ کرنا چاہتے ہیں۔ [فنڈز دیکھیں جو آپ یہاں فراہم کرسکتے ہیں] (https://github.com/seanpm2001/Sponsor-info/tree/main/for-sponsors)

آپ اسپانسر کی دوسری معلومات [یہاں] دیکھ سکتے ہیں (https://github.com/seanpm2001/Sponsor-info/)

اسے آزمائیں! اسپانسر کا بٹن واچ / انچواچ بٹن کے بالکل ساتھ ہے۔

***

## فائل کی تاریخ



 * فائل شروع کی

> * عنوان کے حصے میں شامل کیا گیا

> * انڈیکس کو شامل کیا

> * کے بارے میں سیکشن شامل

> * وکی سیکشن شامل کر دیا گیا

> * ورژن کی تاریخ کے حصے کو شامل کیا گیا

> * مسائل کے سیکشن کو شامل کیا۔

> * ماضی کے مسائل کا سیکشن شامل کیا گیا

> * پچھلی پل کی درخواستوں کا سیکشن شامل کیا گیا

> * فعال پل درخواستوں کے سیکشن کو شامل کیا گیا

> * شراکت کاروں کا حصہ شامل کیا گیا

> * حصہ دینے والا حصہ شامل کیا گیا

> * README سیکشن کے بارے میں شامل کیا گیا

> * README ورژن کی تاریخ کا سیکشن شامل کیا گیا

> * وسائل کے حصے کو شامل کیا گیا

> * ڈی آر ایم فری اسٹیکر اور میسج کے ساتھ سافٹ ویئر اسٹیٹس سیکشن شامل کیا گیا

> *اسپانسر انفارمیشن سیکشن شامل کیا

> * ورژن 0.1 میں کوئی دوسری تبدیلی نہیں ہے

ورژن 1 (جمعہ ، 19 فروری 2021 شام 5:20 بجے)

> تبدیلیاں:

> * فائل شروع کی

> * بنیادی وضاحت کے حصے کو شامل کیا گیا

> * مخزن تفصیل کے سیکشن کو شامل کیا

> * مضامین کی فہرست میں 14 اندراجات شامل ہیں

>> * ایک "متعلقہ مضامین" سیکشن میں شامل کیا گیا

>> * ایک سیکشن بھی ملاحظہ کریں

> * فائل انفارمیشن سیکشن کو شامل کیا

> * فائل ہسٹری سیکشن شامل کیا

> * فوٹر شامل

> * ورژن 1 میں کوئی دوسری تبدیلیاں نہیں

ورژن 2 (جمعہ ، 19 فروری 2021 شام 5:26 بجے)

> تبدیلیاں:

> * ترجمہ کی حیثیت کا سیکشن شامل کیا گیا

> * سیکشن چیک کرنے کے لئے دوسری چیزیں شامل کیں

> * رازداری کے حصے کو شامل کیا گیا

> * ایک انڈیکس شامل کیا

> * سافٹ ویئر کی حیثیت سبجکشن شامل کیا

> * گوگل کے خلاف دیگر مہمات کا دوسرا سیکشن شامل کیا گیا

>> * ناکارہ ذیلی حصہ شامل کیا

>> * جاری سب سبشن شامل کیا

> * ذرائع کے سیکشن کو شامل کیا

> * ڈاؤن لوڈ کے لنکس سیکشن کو شامل کیا

> * فائل انفارمیشن سیکشن کو اپ ڈیٹ کیا

> * فائل ہسٹری سیکشن کو اپ ڈیٹ کیا

> * ورژن 2 میں کوئی دوسری تبدیلیاں نہیں

ورژن 3 (بدھ ، 24 فروری 2021 شام 7:56 بجے)

> تبدیلیاں:

> * انڈیکس کو اپ ڈیٹ کیا

> * ڈیگل گوگل آئیکن اور نئی گٹ ہب تنظیم کا حوالہ دیا

> * نئے مضامین میں لنک شامل کردیئے گئے

> * کاؤنٹرنگ کرنے والے دوسرے دلائل سیکشن کو شامل کیا گیا

>> * سہولت سبجکشن شامل کیا

>> * کیوں سب سیکشن کو پریشان کیوں کرتا ہے

>> * دوسرا ذیلی حصہ شامل کیا

> * کچھ ڈیٹا کو اپ ڈیٹ کیا

> * فائل انفارمیشن سیکشن کو اپ ڈیٹ کیا

> * فائل ہسٹری سیکشن کو اپ ڈیٹ کیا

> * ورژن 3 میں کوئی دوسری تبدیلیاں نہیں

ورژن 4 (ہفتہ ، 25 فروری 2021 بج کر 9:30 بجے)

> تبدیلیاں:

> * 10 نئے مضامین کے لنکس شامل کردیئے گئے

> * میرے تجربے کو کم کرنا کے بارے میں ایک سیکشن شامل کیا گیا

> * انڈیکس کو اپ ڈیٹ کیا

> * فائل انفارمیشن سیکشن کو اپ ڈیٹ کیا

> * فائل ہسٹری سیکشن کو اپ ڈیٹ کیا

> * ورژن 4 میں کوئی دوسری تبدیلیاں نہیں

ورژن 5 (جمعہ ، 9 اپریل 2021 شام 6:02 بجے)

_میں حال ہی میں گوگل کی جانب سے گوگل مخالف تحریک کی تازہ کاریوں کا فقدان رہا ہے ، میں 1+ ماہ کے وقفے کے بعد اس میں واپس جانے پر کام کر رہا ہوں ۔_

> تبدیلیاں:

> * عنوان کے حصے کو اپ ڈیٹ کیا

> * انڈیکس کو اپ ڈیٹ کیا

> * زبان کی فہرست کو اپ ڈیٹ کریں: فکسڈ لنکس ، اور مزید معاون زبانیں شامل کی گئیں

> * چار کانٹے کے لنکس شامل کرتے ہوئے ، آرٹیکل اسٹیٹس سیکشن کو اپ ڈیٹ کیا گیا

> * سافٹ ویئر اسٹیٹس سیکشن کو اپ ڈیٹ کیا گیا

> * شامل کریں برا سیکشن ہے

> * DRM سیکشن کے استعمال کو شامل کیا گیا

> * عام غلط فہمیوں کا سیکشن شامل کیا گیا

>> * شامل کیا گوگل انٹرنیٹ ذیلی نہیں ہے

> * انٹرنیٹ ایکسپلورر 6 اور کروم سیکشن شامل کیا گیا

>> * بہادر سبکشن کے ساتھ مسئلہ کو شامل کیا

> * غلط رازداری کو ختم کرنا شامل کیا گیا

> * اوپن سورس کو جزوی طور پر ضمنی نہیں بنایا جاسکتا

> * اوکسیمرون سبجکشن شامل کیا

> * خراب کارکردگی کا سیکشن شامل کیا گیا

> * خراب پروجیکٹ مینیجمنٹ سیکشن کو شامل کیا گیا

> * خدمات کے سیکشن میں خوفناک یا کوئی اعتدال پسندی شامل کی گئی

> * Astroturfing سیکشن شامل کر دیا گیا

> * غیر قانونی اور غیر اخلاقی کاروباری طریقوں کا سیکشن شامل کیا گیا

> * یورپ میں سبجکشن شامل کیا گیا

>> * شمالی امریکہ میں سب شامل کیا

>> * تنازعات سب سب شامل کیا

> * شامل کردہ گوگل خودکار سیکشن ہے

> * لوڈ ، اتارنا Android سیکشن شامل کر دیا گیا

> * سیکشن کی مدد کے لئے چھوٹی چھوٹی حرکتیں شامل کیں

> * ناقابل اعتماد حصے کو شامل کیا گیا

> * اسپانسر انفارمیشن سیکشن شامل کیا گیا

> * فوٹر کو اپ ڈیٹ کیا گیا

> * فائل انفارمیشن سیکشن کو اپ ڈیٹ کیا

> * فائل ہسٹری سیکشن کو اپ ڈیٹ کیا

> * ورژن 5 میں کوئی دوسری تبدیلیاں نہیں ہیں

ورژن 6 (اتوار ، 18 اپریل 2021 بج کر 4:18 بجے)

> تبدیلیاں:

> * انڈیکس کو اپ ڈیٹ کیا

> * ایک عمومی جائزہ کی تفصیل شامل کی گئ

> * مضمون کی حیثیت سے تازہ ترین معلومات

> * نئے گوگل ایف ایل او سی مضمون میں ایک لنک شامل کیا گیا

> * اس پر وئسٹ 3 این فوچ ڈیگول مضمون اور عام معلومات میں ایک لنک شامل کیا گیا

> * فائل انفارمیشن سیکشن کو اپ ڈیٹ کیا

> * فائل ہسٹری سیکشن کو اپ ڈیٹ کیا

> * ورژن 6 میں کوئی دوسری تبدیلیاں نہیں

ورژن 7 (جلد آرہا ہے)

> تبدیلیاں:

> * جلد آرہا ہے

> * ورژن 7 میں کوئی دوسری تبدیلیاں نہیں

ورژن 8 (جلد آرہا ہے)

> تبدیلیاں:

> * جلد آرہا ہے

> * ورژن 8 میں کوئی دوسری تبدیلیاں نہیں

ورژن 9 (جلد آرہا ہے)

> تبدیلیاں:

> * جلد آرہا ہے

> * ورژن 9 میں کوئی دوسری تبدیلیاں نہیں

ورژن 10 (جلد آرہا ہے)

> تبدیلیاں:

> * جلد آرہا ہے

> * ورژن 10 میں کوئی دوسری تبدیلیاں نہیں

ورژن 11 (جلد آرہا ہے)

> تبدیلیاں:

> * جلد آرہا ہے

> * ورژن 11 میں کوئی دوسری تبدیلیاں نہیں

ورژن 12 (جلد آرہا ہے)

> تبدیلیاں:

> * جلد آرہا ہے

> * ورژن 12 میں کوئی دوسری تبدیلیاں نہیں

***

## فوٹر

آپ اس فائل کے اختتام کو پہنچ گئے ہیں

([اوپر واپس جائیں) (# اوپر) | [گٹ ہب پر واپس جائیں] (https://github.com))

### ای او ایف

***
