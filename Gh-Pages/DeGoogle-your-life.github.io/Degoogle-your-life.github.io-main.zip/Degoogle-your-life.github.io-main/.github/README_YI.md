***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# דעגאָאָגלינג - דעגאָאָגלע דיין לעבן

דאָס איז דער הויפּט אַרטיקל וועגן דיעגאָאָגלינג פֿאַר אַלגעמיינע אינפֿאָרמאַציע וועגן דעגאָאָגלינג און אַ לינק צו די אנדערע אַרטיקלען.

[זעט די רשימה ווי אַ גיטהוב אָרגאַניזאַציע] (https://github.com/Degoogle-your-life)

***

_לייען דעם אַרטיקל אין אַ אַנדערש שפּראַך: _

** קראַנט שפּראַך איז: ** `ענגליש (יו. עס.) _ (איבערזעצונגען קען זיין קערעקטאַד צו פאַרריכטן ענגליש ריפּלייסינג די ריכטיק שפּראַך) _

_🌐 רשימה פון שפראַכן_

** סאָרטירט דורך: ** `א-ז`

[סאָרטינג אָפּציעס ניט בארעכטיגט] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanian | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) אַראַביש | [hy հայերեն] (/. github / README_HY.md) אַרמעניש | [az Azərbaycan dili] (/. github / README_AZ.md) אַזערבײַדזשאַניש | [eu Euskara] (/. github /README_EU.md) באַסקיש | [be аеларуская] (/. Github / README_BE.md) בעלאָרוסיש | [bn বাংলা] (/. Github / README_BN.md) בענגאַליש | [bs Bosanski] (/. Github / README_BS.md) באסניש | [bg български] (/. Github / README_BG.md) בולגאַריש | [ca Català] (/. Github / README_CA.md) קאַטאַלאניש | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chinese (Simplified) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) כינעזיש (טראדיציאנעל) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) קראָאַטיש | [cs čeština] (/. Github / README_CS .md) טשעכיש [da dansk] (README_DA.md) דעניש | [nl Nederlands] (/. github / README_ NL.md) האָלענדיש | [** en-us ענגליש **] (/. github / README.md) ענגליש | [EO Esperanto] (/. Github / README_EO.md) עספּעראַנטאָ | [et Eestlane] (/. github / README_ET.md) עסטיש | [tl Pilipino] (/. github / README_TL.md) טאַגאַלאָג | [fi Suomalainen] (/. github / README_FI.md) פֿיניש | [fr français] (/. github / README_FR.md) פראנצויזיש | [fy Frysk] (/. github / README_FY.md) פריזיש | [gl Galego] (/. github / README_GL.md) גאליציאנער | [ka ქართველი] (/. github / README_KA) גרוזיניש | [de Deutsch] (/. github / README_DE.md) דייַטש | [el Ελληνικά] (/. github / README_EL.md) גריכיש | [gu ગુજરાતી] (/. github / README_GU.md) גודזשאַראַטי | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) האַוואַייאַן | [he עִברִית] (/. github / README_HE.md) עברית | [hi हिन्दी] (/. github / README_HI.md) הינדיש | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) אונגעריש | [is Íslenska] (/. github / README_IS.md) איסלענדיש | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) איסלענדיש | [ga Gaeilge] (/. github / README_GA.md) איריש | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) יאַפּאַניש | [jw וואָנג דזשאַוואַ] (/. github / README_JW.md) יאַוואַנעזיש | [kn ಕನ್ನಡ] (/. github / README_KN.md) קאַנאַדאַ | [kk Қазақ] (/. github / README_KK.md) קאַזאַכיש | [קילאמעטער ខ្មែរ] (/. github / README_KM.md) כמער | [rw קיניאַרוואַנדאַ] (/. github / README_RW.md) קיניאַרוואַנדאַ | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) קאָרעיִש (דרום) | [ko-north 문화어] (README_KO_NORTH.md) קאָרעיִש (North) (נאָך נישט איבערזעצט) | [ku Kurdî] (/. github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) קירגיז | [lo ລາວ] (/. github / README_LO.md) לאַו | [לאַ לאַטינע] (/. github / README_LA.md) לאַטייַן | [lt Lietuvis] (/. github / README_LT.md) ליטוויש | [lb Lëtzebuergesch] (/. github / README_LB.md) לוקסעמבאָורג | [mk Македонски] (/. github / README_MK.md) מאַקעדאָניש | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) מאַלייַיש | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) מאַלטעזיש | [מי Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) מאַראַטהי | [mn Монгол] (/. github / README_MN.md) מאנגאליש | [מיין မြန်မာ] (/. github / README_MY.md) מיאַנמאַר (בורמעסע) | [ne नेपाली] (/. github / README_NE.md) נעפּאַליש [no norsk] (/. github / README_NO.md) נאָרוועגיש | [אָדער ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) אָדיאַ (אָריייאַ) | [ps پښتو] (/. github / README_PS.md) פּאַשטאָ | [fa فارسی] (/. github / README_FA.md) | פּערסיש [pl polski] (/. github / README_PL.md) פּויליש | [pt português] (/. github / README_PT.md) פּאָרטוגעזיש | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) פּונדזשאַבי | קיין שפּראַכן זענען פאַראַנען וואָס אָנהייבן מיט דעם בריוו Q | [ro Română] (/. github / README_RO.md) רומעניש | [ru русский] (/. github / README_RU.md) רוסיש | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) סקאָטיש Gaelic | [sr Српски] (/. github / README_SR.md) סערביש | [סט סעסאָטהאָ] (/. github / README_ST.md) סעסאָטהאָ | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) סינהאַלאַ | [sk Slovák] (/. github / README_SK.md) סלאָוואַקיש | [sl Slovenščina] (/. github / README_SL.md) סלאוועניש | [so Soomaali] (/. github / README_SO.md) סאָמאַליש | [[es en español] (/. github / README_ES.md) שפּאַניש | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) סוואַהילי | [sv Svenska] (/. github / README_SV.מד) שוועדיש | [tg Тоҷикӣ] (/. github / README_TG.md) טאַדזשיק | [ta தமிழ்] (/. github / README_TA.md) טאַמיל | [tt Татар] (/. github / README_TT.md) טאַטאַר | [te తెలుగు] (/. github / README_TE.md) טעלוגו | [טה ไทย] (/. github / README_TH.md) טייַלענדיש | [tr Türk] (/. github / README_TR.md) טערקיש | [tk Türkmenler] (/. github / README_TK.md) טורקמען | [uk Український] (/. github / README_UK.md) אוקראיניש | [ur اردو] (/. github / README_UR.md) אורדו | [ug ئۇيغۇر] (/. github / README_UG.md) ויגהור | [uz O'zbek] (/. github / README_UZ.md) אוזבעקיש | [vi Tiếng Việt] (/. github / README_VI.md) וויעטנאַמעזיש | [cy Cymraeg] (/. github / README_CY.md) וועלש | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [יידיש] (/. github / README_YI.md) ייִדיש | [יאָ יאָרובאַ] (/. github / README_YO.md) יאָרובאַ | [zu Zulu] (/. github / README_ZU.md) Zulu) בארעכטיגט אין 110 שפראכן (108 ווען מען רעכנט נישט ענגליש און צפון קארעא, ווייל צפון קארעא איז נאך נישט איבערגעזעצט געוואָרן [לייענען וועגן דעם דאָ] (/ OldVersions / Korean (צפון ) / README.md))

איבערזעצונגען אין אנדערע שפּראַכן ווי ענגליש זענען איבערגעזעצט אין מאַשין און זענען נישט נאָך פּינטלעך. קיינע ערראָרס זענען נאָך נישט פאַרפעסטיקט פֿון 5 טן פעברואר 2021. ווייַל איך קען נישט גוט אנדערע שפּראַכן ווי ענגליש (איך פּלאַנירן צו באַקומען אַ יבערזעצער יווענטשאַוואַלי) ביטע ביטע ציטירן [וויקיפּעדיע] (https://en.wiktionary.org) און אנדערע מקורים אין דיין באַריכט. אויב איר טאָן ניט טאָן דאָס, וועט זיין רידזשעקשאַן פון די קערעקשאַן ארויס.

באַמערקונג: רעכט צו לימיטיישאַנז מיט גיטהוב ס ינטערפּריטיישאַן פון מאַרקדאַון (און כּמעט יעדער אנדערע וועב-באזירט ינטערפּריטיישאַן פון מאַרקדאַון) קליקינג די לינקס וועט רידערעקט איר צו אַ באַזונדער טעקע אויף אַ באַזונדער בלאַט וואָס איז נישט מיין גיטהוב פּראָפיל בלאַט. איר וועט זיין רידערעקטיד צו די [seanpm2001 / seanpm2001 ריפּאַזאַטאָרי] (https://github.com/seanpm2001/seanpm2001), וווּ די README איז כאָוסטיד.

איבערזעצונגען זענען דורכגעקאָכט מיט Google זעץ ווייַל פון לימיטעד אָדער קיין שטיצן פֿאַר די שפּראַכן וואָס איך דאַרפֿן אין אנדערע איבערזעצונג באַדינונגס ווי DeepL און Bing Translate (שיין ייראַניק פֿאַר אַן אַנטי-Google קאמפאניע). איך אַרבעט צו געפֿינען אַן אָלטערנאַטיוו. פֿאַר עטלעכע סיבה, די פאָרמאַטטינג (לינקס, דיווידערז, דרייסט, ייטאַליקס, אאז"ו ו) איז צעמישט אין פאַרשידענע איבערזעצונגען. עס איז טידיאַס צו פאַרריכטן, און איך טאָן ניט וויסן ווי צו פאַרריכטן די ישוז אין שפּראַכן מיט ניט-לאַטייַן אותיות, און רעכט צו לינקס שפּראַכן (ווי אַראַביש), עס דאַרף זיין עקסטרע הילף צו פאַרריכטן די ישוז.

רעכט צו וישאַלט ישוז, פילע איבערזעצונגען זענען אויס פון טאָג און נוצן אַ אַוטדייטיד ווערסיע פון ​​דעם 'README' אַרטיקל טעקע. מען דאַרף האָבן אַן איבערזעצער. פֿון 9 אפריל 2021, עס וועט נעמען מיר אַ ביסל צייט ביז אַלע נייַע לינקס אַרבעט.

***

## אינדעקס

[00.0 - טיטל] (# דעגאָאָגלינג --- דעגאָאָגלע-דיין-לעבן)

> [00.1 - אינדעקס] (# אינדעקס)

[01.0 - באַסיק באַשרייַבונג] (# באַסיק-באַשרייַבונג)

> [01.1 - ריפּאַזאַטאָרי כעדער] (# דעגאָאָגלע-דיין-לעבן)

> [01.2 - Wuest3NFuchs באַשרייַבונג איבערבליק] (# איבערבליק-דורך-Wuest3nFuchs)

>> [01.2.1 - וואָס טוט עס מיינען?] (# What-does-it-mean - by-Wuest3nFuchs)

>> [01.2.2 - פארוואס דעגאָאָגלע?] (# Why-Degoogle - by-Wuest3nFuchs)

[02.0 - אַרטיקלען] (# ארטיקלען)

[03.0 - פריוואטקייט] (# פריוואטקייט)

[04.0 - אנדערע אַנטי-Google קאַמפּיינז] (# אנדערע אַנטי-Google קאַמפּיינז)

> [04.0.1 - דעפאַנגקט] (# דעפאַנגקט)

> [04.0.2 - אָנגאָינג] (# אָנגאָינג)

[05.0 - קאָונטערינג אנדערע טענות] (# קאָונטערינג-אנדערע-טענות)

> [05.0.1 - קאָנוועניענסע] (# קאָנוועניענסע)

> [05.0.2 - פארוואס טוט עס ענין? עס איז סייַ ווי סייַ צו שפּעט] (# פארוואס-טוט-עס-ענין-ס'איז צו-שפּעט-עניווייז)

> [05.0.3 - אַנדערער] (# אַנדערער)

[06.0 - סאָורסעס] (# סאָורסעס)

[07.0 - אראפקאפיע לינקס] (# אראפקאפיע-לינקס)

[08.0 - מייַן דעגאָאָגלינג דערפאַרונג] (# My-degoogling-experience)

> [08.1 - וואָס איך סוויטשט פֿון] (# וואָס-איך-סוויטשט-פֿון)

> [08.2 - פּראָדוקטן וואָס איך קען נאָך נישט באַקומען אַוועק פון] (# פּראָדוקץ-איך-נאָך-קען נישט באַקומען-אַוועק-אַוועק)

[09.0 - אנדערע טינגז צו טשעק אויס] (# אנדערע-טינגז-צו-טשעק-אויס)

[10.0 - טעקע אינפֿאָרמאַציע] (# טעקע אינפֿאָרמאַציע)

> [10.1 - ווייכווארג סטאַטוס] (# ווייכווארג סטאַטוס)

> [10.2 - פּאַטראָן אינפֿאָרמאַציע] (# פּאַטראָן אינפֿאָרמאַציע)

[11.0 - טעקע געשיכטע] (# טעקע-געשיכטע)

[12.0 - פוס] [# פוס]

***

## באַסיק באַשרייַבונג

[פֿון Wikipedia: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

די DeGoogle באַוועגונג (אויך גערופן דע-Google באַוועגונג) איז אַ גראַסרוץ קאמפאניע וואָס ספּאָנד ווי פּריוואַטקייט אַקטיוויס בעטן וסערס צו האַלטן גאָר ניצן Google פּראָדוקטן רעכט צו גראָוינג פּריוואַטקייט קאַנסערנז וועגן די פירמע. דער טערמין רעפערס צו די אַקט פון רימוווינג Google פון זיין לעבן. ווי די גראָוינג מאַרק טיילן פון דער אינטערנעץ ריז קריייץ מאָנאָפּאָליסטיק מאַכט פֿאַר די פירמע אין דיגיטאַל ספּייסאַז, ינקריסינג נומער פון פובליציסטן האָבן באמערקט די שוועריקייט צו געפֿינען אַלטערנאַטיוועס צו די פירמע 'ס פּראָדוקטן.

** געשיכטע **

אין 2013, John Koetsier פון Venturebeat האט אַמאַזאָן ס קינדלע פייער אַנדרויד-באזירט טאַבלעט איז געווען "אַ דע-Google- יזעד ווערסיע פון ​​אַנדרויד." אין 2014 יוחנן סימפּסאָן פון יו. עס. נייַעס געשריבן וועגן די "רעכט צו ווערן פארגעסן" דורך Google און אנדערע זוכן ענדזשאַנז. אין 2015, Derek Scally פון Irish Times געשריבן אַן אַרטיקל וועגן ווי צו "דע-גוגל דיין לעבן." אין 2016 קריס קאַרלאָן פון אַנדראָידי אויטאָריטעט סאַגדזשעסטיד אַז וסאַנאָגענמאָד 14 וסערס קענען "דע-גוגל" זייער פאָנעס ווייַל סיאַנאָגענמאָד אַרבעט פייַן אָן Google אַפּפּס אויך. אין 2018, Nick Lucchesi פון ינווערסע האָט געשריבן וועגן ווי ProtonMail פּראַמאָוטינג ווי צו "קענען צו גאַנץ Google-FY דיין לעבן." Lifehacker's Brendan Hesse געשריבן אַ דיטיילד טוטאָריאַל וועגן "קוויטינג פון Google." ינכיבאַטיד ניצן סערוויסעס געפֿינט דורך Google ווייַל עס זענען אַזוי ווייניק אַלטערנאַטיוועס אַז דער אַוועק פון די פּראָדוקטן פון די פירמע איז געווען אַנפעראַבאַל פֿאַר נאָרמאַל אינטערנעט.

***

# דעגאָאָגלע-דיין-לעבן
א ריפּאַזאַטאָרי פֿאַר אַלגעמיינע דעגאָאָגלינג אינפֿאָרמאַציע און לינקס צו מיין אנדערע דעגאָאָגלינג ריפּאַזאַטאָריז.

***

## איבערבליק פון Wuest3nFuchs

א בעסערע שילדערונג, צוגעשטעלט דורך [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - מקור: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### וואס מיינט עס? דורך Wuest3nFuchs

דעגאָאָגלינג מיטל צו האַלטן ניצן עפּעס וואָס געהערט צו Google, עפּעס וואָס איז געווען געמאכט דורך Google. איך בין גערעדט וועגן זייער זוכן מאָטאָר, זייער פּאָסט (Gmail), יאָוטובע, עטק.

### פארוואס דעגאָאָגלע? דורך Wuest3nFuchs

Google איז איצט איינער פון די מערסט שטאַרק קאָמפּאַניעס אין דער וועלט. זיי האָבן סטאָרד אַ ריזיק נומער פון אינפֿאָרמאַציע וועגן אונדז אַלע. עטלעכע וואָלט טייַנען אַז אונדזער אינפֿאָרמאַציע איז זיכער מיט זיי ווייַל זיי וויסן ווי צו באַשיצן עס. אָבער דאָס איז נישט אמת. Google איז ביז אַהער דורכגעקאָכט און עס וועט זיין דורכגעקאָכט אין דער צוקונפֿט. אפֿשר נישט דורך עטלעכע קידי סקריפּט, אָבער דאָס וועט זיין געטאן דורך אַ פאָלק שטאַט. Google סטאָרז פּערזענלעך אינפֿאָרמאַציע אויף אונדז אַלע ווייַל זיי מאַכן געלט.

זיי יבערקוקן אונדזער ימיילז, קראָם וואָס מיר זוכן ווען מיר נוצן זייער זוכן מאָטאָר, ווידיאס מיר זען אויף יאָוטובע. דאָס איז ווי זיי צילן אונדז און בויען אַ פּראָפיל אויף אונדז צו ווייַזן עטלעכע אַדס באזירט אויף וואָס מיר גערעדט וועגן מיט אונדזער בעסטער פרייַנד, אַזוי זיי קענען ווייַזן אונדז אַ אַד פֿאַר עפּעס מיר דאַרפֿן, אָבער דאָס איז אויך קריפּי. דאַנק צו הער סנאָוודען, מיר איצט וויסן אַז Google שערד אונדזער פּערזענלעך אינפֿאָרמאַציע מיט NSA אונטער אַ פּראָגראַם גערופֿן ** "PRISM" **.


אין דער צוקונפֿט, עמעצער וועט זיין ביכולת צו אַקסעס אַלע די אינפֿאָרמאַציע און איך פאַרזיכערן איר אַז עפּעס טאַקע שלעכט וועט פּאַסירן. צו פאַרמיידן אַז דאָס קען פּאַסירן, איר זאָל אָנהייבן Degoogling רעכט איצט. איר זאָל נישט נוצן פּראָדוקטן פון אַ פירמע וואָס שאַרעס דיין דאַטן מיט ** NSA **. איר זאָל שטעלן אַ האַלטן צו אַלע דעם דורך דעגאָאָגלינג.

** אויב אנדערע קענען דאָס טאָן, איר קענט אויך טאָן דאָס. **

[לייענען מער דאָ] (https://github.com/Wuest3nFuchs/Degoogle)

<! - א לינק צו די גאָפּל איז דערווייַל נישט ליסטעד, ווייַל איך טאָן ניט האָבן דעם ריפּאַזאַטאָרי לעגאַמרע און איך ווילן צו העכערן אנדערע קוואלן. עס וואָלט זיין עגאָיסטיש צו פאַרבינדן מיין אייגענע https://github.com/Degoogle-your-life/Degoogle! ->

***

## ארטיקלען

### אַרטיקל סטאַטוס

_ אַלע אַרטיקלען זענען דערווייַל אַ אַרבעט אין פּראָגרעס און דאַרפֿן מאַסיוו ימפּרווומאַנץ. פארשלאגן און פיקסעס זענען ערלויבט ._

_ פון אפריל 18, 2021, 4:09 פּם, רובֿ אַרטיקלען האָבן נישט סטאַרטעד נאָך. איך אַרבעט מיט דערגייונג צייט און מי צו אָנהייבן זיי ._

[פארוואס איר זאָל האַלטן Google Chrome] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[האַלטן ניצן ChromeBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[האַלטן ניצן WideVine DRM / עס ס צייַט צו שנייַדן WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[פארוואס איר זאָל האַלטן ניצן ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[אָלטערנייטינג פֿון יאָוטובע] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[האַלטן גאָאָגלינג, פארוואס איר זאָל האַלטן ניצן Google זוך] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[פארוואס איר זאָל האַלטן ניצן Gmail] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[פארוואס איר זאָל האַלטן אַנדרויד] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[פארוואס איר זאָל ויסמיידן Google אַמפּ] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[פארוואס איר זאָל האַלטן Google Drive] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[פארוואס איר זאָל האַלטן Google Maps און Google Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[היי Google, האַלטן] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[האַלטן לייענען פֿון Google / פּלייַ ביכער] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[האַלטן ניצן Google קלאַסצימער] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[פארוואס איר זאָל האַלטן ניצן Google זעץ] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[פארוואס איר זאָל האַלטן דיין Google אַקאַונט (s)] (https://github.com/seanpm2001/Why-you-should-sשפּיץ-ניצן-Google- אַקקאָונץ) <! - 16! ->

** נייַע אַרטיקלען צו זיין געשריבן באַלד: **

[פארוואס איר זאָל האַלטן ניצן Gerrit] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[פארוואס איר זאָל האַלטן ניצן Google Analytics (די ריפּאַזאַטאָרי איז געווען צעבראכן אויף מיין סוף פון מיטוואך, פעברואר 24, 2021, 4:13 PM)] -Google-Analytics) <! - 18! ->

<! - ווערק דיווידער! ->

[פארוואס איר זאָל האַלטן Google AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[פארוואס איר זאָל האַלטן Google One] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[פארוואס איר זאָל האַלטן ניצן Google+ (דעפאַנגקט)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[פארוואס איר זאָל האַלטן די נוצן פון די Google פּלייַ סטאָר] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[פארוואס איר זאָל האַלטן ניצן Google Docs] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[פארוואס איר זאָל האַלטן מיט Google Slides] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[פארוואס איר זאָל האַלטן Google Sheets] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[פארוואס איר זאָל האַלטן Google Forms] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[פארוואס איר זאָל האַלטן מיט Google Cardboard] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[פארוואס איר זאָל האַלטן Google Messages] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[פארוואס איר זאָל האַלטן ניצן Google מאַטעריאַל פּלאַן] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[פארוואס איר זאָל האַלטן Google Glass / Glasses] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[פארוואס איר זאָל האַלטן מיט Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[פארוואס איר זאָל האַלטן ניצן GBoard] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[פארוואס איר זאָל האַלטן Google Home] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[פארוואס איר זאָל האַלטן ניצן Google נעסט] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[פארוואס איר זאָל האַלטן Google Hangouts (דעפאַנגקט)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[פארוואס איר זאָל האַלטן ניצן Google Duo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[פארוואס איר זאָל האַלטן Google Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[פארוואס איר זאָל האַלטן ניצן Google Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[פארוואס איר זאָל האַלטן Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[פארוואס איר זאָל האַלטן די נוצן פון Google פּראָגראַממינג שפּראַך] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[פארוואס איר זאָל האַלטן די אַפּלאַקיישאַן שפּראַך פון Googles Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[פארוואס איר זאָל האַלטן ניצן Googles וועבפּ בילד פֿאָרמאַט] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[פארוואס איר זאָל האַלטן ניצן Googles וועבם ווידעא פֿאָרמאַט] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[פארוואס איר זאָל האַלטן Google Video] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[פארוואס איר זאָל האַלטן מיט Google זייטלעך (קלאַסיש)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[פארוואס איר זאָל האַלטן ניצן Google זייטלעך ("ניו")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[פארוואס איר זאָל האַלטן מיט Google Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[פארוואס איר זאָל האַלטן אַנדרויד פּייַ] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[פארוואס איר זאָל האַלטן ניצן Google VPN (oxymoron)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[פארוואס איר זאָל האַלטן Google Photos] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[פארוואס איר זאָל האַלטן ניצן Google קאַלענדאַר] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[פארוואס איר זאָל האַלטן ניצן VirusTotal (זינט Google איז אָונד זינט סעפטעמבער 2012] (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[פארוואס איר זאָל האַלטן ניצן Google Fi] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi) <! - 53! ->

[פארוואס איר זאָל האַלטן Google Stadia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[פארוואס איר זאָל האַלטן Google Keep] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[פארוואס איר זאָל האַלטן Google Base] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[פארוואס איר זאָל האַלטן פּאַרטיסאַפּייטינג אין די Google Summer of Code] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[פארוואס איר זאָל האַלטן Google Camera] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[פארוואס איר זאָל האַלטן די נוצן פון Google קאַלקולאַטאָר (איר קען זיין עקסטרעם, אָבער איר זאָל דעגאָאָגלע פֿון אַלץ, גאָר גרינג צו זיין אָלטערנאַטיוו)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- קאַלקולאַטאָר) <! - 59! ->

[פארוואס איר זאָל האַלטן ניצן Google סורוויי + ריוואָרדז] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[פארוואס איר זאָל האַלטן ניצן Google Drawings] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[פארוואס איר זאָל האַלטן ניצן טענאָר (GIF פּלאַץ, אָונד דורך Google זינט 2019)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[וואָס די FLoC - פארוואס איר זאָל ויסמיידן Google גרויס FLoCing פּראָבלעם (האַלטן ניצן Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** גאַנץ אַרטיקלען: ** `63`

** אַרטיקל [ראָאַדמאַפּ אַב] (DegoogleCampaign_2021Roadmap_Part1.md) (אַרויף צו 12 מערץ 2021) 2 טעג אַוועק **

** אַרטיקל [ראָאַדמאַפּ בב] (DegoogleCampaign_2021Roadmao_Part2.md) (אַרויף צו? 2021) 2 טעג אַוועק **

אַרטיקל סטאַטוס

אַלע אַרטיקלען זענען דערווייַל אַ אַרבעט אין פּראָגרעס און דאַרפֿן מאַסיוו ימפּרווומאַנץ. פֿירלייגן און פיקסיז זענען ערלויבט.

** פאָרקס **

יקספּאַנדינג מיין דעגאָאָגלע נעץ און לייגן אַ ביסל יז פון אַקסעס און קאַמיוניטי שאָוטאַוץ.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | פאָרקעד פֿון: [https://github.com/wacko1805/Fossapps ](https://github.com/wacko1805/Fossapps) (ענגליש)

2. [פּריוואַטקייט-לינקס] (https://github.com/Degoogle-your-life/Privacy-links) | פאָרקעד פֿון: [https://github.com/Arturro43/privacy-links ](https://github.com/Arturro43/privacy-links) (פויליש)

3. [דילייטפאַל-פּריוואַטקייט] (https://github.com/Degoogle-your-life/Delightful-Privacy) | פאָרקעד פֿון: [https://github.com/LinuxCafeFederation/Delightful-Privacy] (https://github.com/LinuxCafeFederation/Delightful-Privacy) (ענגליש)

4. [בלאַקליסץ] (https://github.com/Degoogle-your-life/blocklists) | פאָרקעד פֿון: [https://github.com/jmdugan/blocklists] (https://github.com/jmdugan/blocklists) (ענגליש)

5. [Degoogle, by Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | פאָרקעד פֿון: [https://github.com/Wuest3nFuchs/Degoogle ](https://github.com/Wuest3nFuchs/Degoogle) (ענגליש)

**פֿאַרבונדענע**

[דעגאָאָגלעד אַנדרויד טעלעפאָנירן פאָרשונג פון ווירטואַל מאַשין] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

** זען אויך: **

[קריטיק פון Google אויף Wikipedia] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[דער גוגל גראַווייאַרד (killbygoogle.com) - אַ סאָרטירטע רשימה פון די 224+ פּראָדוקטן וואָס Google האָט געהרגעט] (https://killedbygoogle.com/)

> [גיטהוב לינק] (https://github.com/codyogden/killedbygoogle)

[אַלפאַבעט אַרבעטער פאַרבאַנד - דער נייַע אַרבעטער פאַרבאַנד אין Google מיט איבער 800 מיטגלידער] (https://alphabetworkersunion.org/people/our-union/)

[צי איר נישט וועלן צו שיידן די יאָג פון דער דיינאַסאָר? איר האָט קאַווערד דעם וועבזייטל] (https://chromedino.com/)

***

## פריוואטקייט

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) [s ](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [אַ] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / פּאָזיציע / פארוואס-גוגלז-ספּייינג-אויף-נוצן_ב_3530296) [e] ] [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (הטטפּס: // פּראָטאָנמאַיל. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -בראַוזער /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_arגומענט # קריטיקיזם) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -סייַ-סאַמפּאַלז / גאָרנישט-צו-באַהאַלטן-אַרגומענט-האט-גאָרנישט-צו-זאָגן /) [ד] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- פון-דאַטן-וועגן-איר-איר-קענען-געפֿינען-און-ויסמעקן-עס-איצט /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -דייַן-פערזענלעכע-דאַטן-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -מאָנעטיזעס-און) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- זאַמלונג-גילוי.הטמל) [ד] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ health-fitness-data-privacy /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks] [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-government-google-data-collection-process-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html) [o ](https://en.wikipedia.org/wiki/2018_Google_data_breach) [m ](https://moz.com /blog/where-does-google-draw-the-data-collection-line) [e ](https://mashable.com/article/google-android-data-collection-study/) [s ](https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html) [o ](https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -קלאַימס-אויף-ביכאַף-פון-5-עם illion-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/) [i ](https://www.cbsnews.com/news/google-education-spies-on-collects- דאַטן-אויף-מיליאַנז-פון-קידס-אַלעגעס-פּראָצעס-נייַ-מעקסיקא-אַדוואָקאַט-אַלגעמיינע /) [V] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -אונטער-אונדזער-נאָסעס /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / טעכנאָלאָגיע / google-yout Ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https (//medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (איך קען פאָרזעצן און אויף אויף מיט זאָגן פון דעם, אָבער עס גענומען אַ לאַנג צייַט צו געפֿינען און גיין דורך אַלע די אַרטיקלען)

פּריוואַטקייט אויף Google פּראָדוקטן איז שטענדיק שלעכט ווייַל פון אַלע Google פּראָדוקטן מיט ספּיוואַרע.

ניט קיין ענין וואָס איר טאָן, ווען איר נוצן Google, אַלע דיין שפּירעוודיק פערזענלעכע דאַטן זענען געשיקט צו Google און אנדערע. Google איז אויך ספּאַטיד דורך עפֿענען מגילה. פֿאַר בייַשפּיל, פֿון פּערזענלעך דערפאַרונג (אויף Firefox) מיט אַ יאָוטובע קוויטל וואָס איך האט נישט באַזוכן, איך וואָטשט עטלעכע ווידיאס אָפפלינע (VLC Media Player) שפּעטער ווען איך געגאנגען צו קאָנטראָלירן די רעקאַמאַנדיישאַנז, עס איז געווען כּמעט אַלץ וואָס איך וואָטשט. עס זענען קיין צווייפל אַז זיי ספּייינג אויך אנדערע מגילה.

אין קראָום (און פילע אנדערע בראַוזערז) עס איז אַן ינקאָגניטאָו מאָדע. אין קראָום, די מאָדע איז טעמפּ, ווייַל Google וועט נאָך מיינען דיין דאַטן. אפילו אויב איר באַשליסן דאַטן מיינינג / טראַקינג אַוועק און געבן די סיגנאַל "טאָן ניט שפּור", ​​יבערראַשן, Google נאָך מיינינג דיין דאַטן.

אויב איר טראַכטן איר האָט גאָרנישט צו באַהאַלטן, ** איר זענט לעגאַמרע פאַלש **. דער אַרגומענט איז פילע מאָל דעבונקעד:

[דורך וויקיפּעדיע] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. עדוואַרד סנאָוודען האָט באַמערקט: "טענהט אז איר קימערט זיך נישט וועגן דעם רעכט צו פריוואטקייט, ווייל איר האָט גאָרנישט צו באַהאַלטן, איז ניט אַנדערש ווי זאגן אז איר קימערט ניט וועגן פרייע רעדע, ווייל איר האָט גאָרנישט צו זאָגן." ווען איר זאָגט, ' איך האב גאָרנישט צו באַהאַלטן, 'איר'רע זאָגן,' איך טאָן ניט זאָרגן וועגן דעם רעכט. 'איר' רע זאגן, 'איך טאָן ניט האָבן דעם רעכט, ווייַל איך'ווע גאַט צו די פונט ווו איך האָבן צו באַרעכטיקן. דאָס. ווי די רעכט אַרבעט איז, די רעגירונג דאַרף באַרעכטיקן איר ינטרוזשאַן אין דיין רעכט. "

2. דניאל י. סאָלאָווע האָט דערקלערט אין אן ארטיקל פאר דער כראָניק פון העכערער בילדונג אז ער איז קעגן דעם אַרגומענט; ער סטייטיד אַז אַ רעגירונג קענען ליק אינפֿאָרמאַציע וועגן אַ מענטש און פאַרשאַפן שעדיקן צו דעם מענטש, אָדער נוצן אינפֿאָרמאַציע וועגן אַ מענטש צו אָפּלייקענען אַקסעס צו סערוויסעס אפילו אויב אַ מענטש האט נישט אַקשלי אַ פאַלש טאן, און אַז אַ רעגירונג קען פאַרשאַפן שעדיקן צו זיין פערזענלעכע לעבן דורך ערראָרס. סאָלאָווע האָט געשריבן "ווען עס איז גלייך פאַרקנאַסט אין דעם גאָרנישט-צו-באַהאַלטן אַרגומענט, קען זיין ינסערשאַן, ווייַל עס פאָרסעס די דעבאַטע צו פאָקוס אויף זיין ענג פארשטאנד פון פּריוואַטקייט. אָבער ווען עס איז קאָנפראָנטעד מיט די פּלוראַליטעט פון פּריוואַטקייט פּראָבלעמס ימפּלאַקייטיד דורך רעגירונג דאַטן זאַמלונג און נוצן אַנטפּלעקונג, דער גאָרנישט-צו-באַהאַלטן אַרגומענט, אין די סוף, האט גאָרנישט צו זאָגן. "

3. Adam D. Moore, מחבר פון פּריוואַטקייט רעכט: מאָראַל און לעגאַל יסודות, טענהט, "עס איז די מיינונג אַז רעכט זענען קעגנשטעליק צו קאָסטן / נוץ אָדער קאָנסעקווענטיאַליסט סאָרט פון אַרגומענטן. דאָ מיר אָפּוואַרפן די מיינונג אַז פּריוואַטקייט אינטערעסן זענען די סאָרץ. פון זאכן וואס מען קען איינהאנדלען פאר זיכערקייט. " ער האָט אויך דערקלערט אז די סערוויילאַנס קען דיספּראַפּאָרשאַנאַטלי ווירקן עטלעכע גרופּעס אין דער געזעלשאַפט באזירט אויף אויסזען, עטהניסיטי, סעקשואַלאַטי און רעליגיע.

4. ברוס שנייער, א קאמפיוטער זיכערקייט עקספּערט און קריפּטאָגראף, האָט אויסגעדריקט קעגנערשאפט, מיט ציטירן דעם קארדינאל ריטשעליו'ס דערקלערונג "אויב איינער וואלט מיר געגעבן זעקס שורות געשריבן דורך דער האנט פון דעם ערלעכסטן מאן, וואלט איך געפונען עפּעס אין זיי אז מען זאל אים הענגען", רעפערירט וויאזוי א סטעיט רעגירונג קען טרעפן אספעקטן אין א מענטשנס לעבן כדי צו אנקלאגן אדער אויסשמאלן דעם פערזאן. שנייער האָט אויך אַרגומירט "צו פילע קערעקטלי דיסקרייבד די דעבאַטע ווי 'זיכערקייט קעגן פּריוואַטקייט.' די פאַקטיש ברירה איז פרייהייט קעגן קאָנטראָל. "

5. Harvey A. Silverglate עסטימאַטעד אַז די פּראָסט מענטש, אין דורכשניטלעך, אַננאָוינגלי קאַמיטז דרייַ פעלאָניז אַ טאָג אין די יו.

6. עמיליאָ מאָרדיני, פילאָסאָף און פּסיכאָאַנאַליטיקער, האָט געטענהט אז דער "גאָרנישט צו באַהאַלטן" אַרגומענט איז אייגנטלעך פאראדאקסאל. מענטשן טאָן ניט דאַרפֿן צו האָבן "עפּעס צו באַהאַלטן" צו באַהאַלטן "עפּעס". וואָס איז פאַרבאָרגן איז ניט דאַווקע באַטייַטיק, קליימז מאָרדיני. אַנשטאָט, ער טענהט אַז אַ אָנווינקען געגנט וואָס קענען זיין ביידע פאַרבאָרגן און אַקסעס-ריסטריקטיד איז נייטיק ווייַל, סייקאַלאַדזשיקלי גערעדט, מיר ווערן מענטשן דורך די ופדעקונג אַז מיר קען באַהאַלטן עפּעס צו אנדערע.

7. דזשוליאַן אַססאַנגע סטייטיד "עס איז קיין קיללער ענטפֿערן נאָך. Jacob Appelbaum (@ioerror) האט אַ קלוג ענטפער און געבעטן מענטשן וואָס זאָגן דאָס צו געבן אים זייער טעלעפאָן אַנלאַקט און ציען אַראָפּ זייער הויזן. מיין ווערסיע פון ​​עס איז צו זאָגן, "נו, אויב איר'רע אַזוי נודנע, מיר זאָל נישט רעדן צו איר, און ניט ווער עס יז אַנדערש", אָבער פילאָסאָפיקאַללי, דער עמעס ענטפער איז דאָס: מאַסע סערוויילאַנס איז אַ מאַסע סטראַקטשעראַל ענדערונג. צו נעמען איר מיט אים, אפילו אויב איר זענט דער בלאַסט מענטש אויף דער ערד. "

8. יגנאַסיאָ קאָפאָנע, פּראָפעסאָר אין געזעץ, טענהט אַז דער אַרגומענט איז פאַלש אין זיין אייגענע טערמינען, ווייַל ווען מענטשן אַנטפּלעקן באַטייטיק אינפֿאָרמאַציע צו אנדערע, זיי אויך אַנטדעקן ירעלאַוואַנט אינפֿאָרמאַציע. די ירעלאַוואַנט אינפֿאָרמאַציע האט פּריוואַטקייט קאָס און קען פירן צו אנדערע שאָדן, אַזאַ ווי דיסקרימינאַציע.

***

## אנדערע אַנטי-Google קאַמפּיינז

דאָס איז אַ רשימה פון אנדערע נאָוטאַבאַל אַנטי-Google קאַמפּיינז. די רשימה איז דערענדיקט. איר קענען העלפֿן דורך יקספּאַנדינג עס.

### דעפאַנגקט

[Scroogled - פֿון Microsoft (נאָוועמבער 2012 צו 2014)] (https://en.wikipedia.org/wiki/Scroogled)

_קיין אנדערע איינסן דערווייל ._

### אָנגאָינג

די רשימה איז ליידיק.

***

## קאָונטערינג אנדערע טענות

עס זענען עטלעכע טענות וואָס מענטשן מאַכן צו באַרעכטיקן Google. איינער פון די ערשטע הויפּט איז שוין דעבונקעד [דאָ] (# פּריוואַטקייט) אָבער דאָ זענען עטלעכע אנדערע:

### קאַנוויניאַנס

יאָ, Google פּראָדוקטן ויסקומען באַקוועם. אָבער, איר האַנדל אַלץ גוט פֿאַר קאַנוויניאַנס, אַרייַנגערעכנט זיכערהייט, פּריוואַטקייט און רילייאַבילאַטי. Google איז ליידיק מיט די יאָרן און זייער סערווערס האָבן שוין מער און מער אַראָפּ. רעכט איצט, די Google סערווערס אַראָפּ 1-2 שעה פּער חודש פֿאַר קימאַט אַ שעה (דער הויפּט יאָוטובע)

צום באַדויערן, רעכט צו די סאַסייישאַנז פון Google, Google איז דאָמינירן די אינטערנעט און זוכט צו קאָנטראָלירן מער און מער. אין 2012, ווען גוגל איז אַראָפּ פֿאַר 5 מינוט, עס איז געווען געמאלדן אַז ** גלאבאלע ** אינטערנעט פאַרקער ** דראַפּט דורך 40% ** גוגל אָפט גייט אַראָפּ פֿאַר 1-2 שעה, און מיט די [פירינג פון זייער עטיקס מאַנשאַפֿט] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/), זיי וועלן ווערן ווייניקער און ווייניקער באַקוועם.

קאַנוויניאַנס איז ניט שטענדיק אַ גוטע זאַך. איר זאָל זיין אַווער פון וואָס איז געגאנגען אויף און זיין צוגעגרייט ווען זיי פאַלן אַראָפּ, ווייַל עס איז נישט אַ וועג צו האָבן אַ סערווער וואָס קען נישט פאַלן אַראָפּ.

גוגל איז אויך נישט אַזוי באַקוועם ווי איר טראַכטן. עס זענען אנדערע פּלאַץ מער באַקוועם זייטלעך. Google איז ווייַט פון באַקוועם ווען איר טאָן ניט האָבן קיין ענטפער צו האַלטן זייער טראַפ - חשבון סאַספּענשאַן און טערמאַניישאַנז (סייַדן איר ציען גענוג ופמערקזאַמקייט צו די Google טוויטטער אקאונט אָדער סו פֿאַר $ 100.000.000 אָדער מער), זיי האָבן גענוצט איר, סקרוד איר און געצווונגען איר צו שרייַען אין אַ קישן, ווו קיין איינער קען הערן דיין סקרימזפֿאַר הילף.

### פארוואס איז עס וויכטיק?

דאָס איז אַ ווייניקער פּראָסט אַרגומענט, אָבער עס דאַרף זיין דערקלערט. מיט דער איצטיקער שטאַט, רובֿ וועלט גאַווערמאַנץ, צוזאַמען מיט עטלעכע שטאַרק קאָרפּעריישאַנז, ווייזן ווי יעדער מאַך, אַזוי וואָס טאָן ניט אַרן זיך אַוועק פון אים? דער ענטפער איז פּשוט: ** איר פאַרדינען בעסער **. אויב איר איצט באַקומען אַוועק פון זיי, עס איז האַרדער פֿאַר זיי צו נאָכפאָלגן דיין מאָוועס ווייַטער, און איר קענען בויען אַ נייַע מער פּריוואַט לעבן.

[1 מקור] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) דורך דעם וועג, איך האָבן געגעבן מיין פריי רעדדיט אַוואָרד צו דעם פּאָסטן יעדער מאָל איך באַקומען עס פֿאַר איבער אַ וואָך איצט (צוזאַמען מיט אַלע 500 פון מיין פריי קאָינס) צו פאַרגרעסערן דעם טעמע ווייַטער. ביז איצט, איך האָב געגעבן דעם פּאָסטן איבער 14 פריי אַוואַרדס. עס איז נישט פיל, אָבער קליין טינגז קענען האָבן אַ גרויס פּראַל, דיפּענדינג אויף ווי עס איז באמערקט און דורך וועמען.

### אנדערע

איך האָב דערווײַל קיין אַנדערע אַרגומענטן.

_ די רשימה איז דערענדיקט_

***

## קוועלער

קאָפּיע:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) [s ](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [אַ] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / פּאָזיציע / פארוואס-גוגלז-ספּייינג-אויף-נוצן_ב_3530296) [e] ] [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (הטטפּס: // פּראָטאָנמאַיל. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -בראַוזער /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# קריטיק) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -סאַמפּאַלז / גאָרנישט-צו-באַהאַלטן-אַרגומענט-האט-גאָרנישט-צו-זאָגן /) [ד] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- דאַטן-וועגן-איר-איר-קענען-געפֿינען-און-ויסמעקן-עס-איצט /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -און) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html) [די ](https://www.reuters.com/article/us-alphabet- google-privacy-process-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -סוד-איבער-קידס-דאַטן-זאַמלונג-אויף-בילדונג-טשראָמעבאָאָקס) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html) [o ](https://en.wikipedia.org/wiki/2018_Google_data_breach) [m ](https:// moz.com/bl og / where-do-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- קליימז-אויף-ביכאַף פון 5-מיליאָן-יפאָנע וסערס) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) [e ](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -פאָנע-איז ניט-אין-נוצן /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / ינפאָרמאַטיאויף-טעכנאָלאָגיע / 2014/01 / וואָס-Google- קענען-טאַקע-טאָן-מיט-נעסט-אָדער-טאַקע-נעסץ-דאַטן /) [i] (https://www.cbsnews.com/news/google-education -ספּיעס-אויף-קאַלעקץ-דאַטן-אויף-מיליאַנז-פון-קידס-אַלעגעס-פּראָצעס-נייַ-מעקסיקא-אַדוואָקאַט-אַלגעמיינע /) [V] (https://www.nationalreview.com/2018/04/the- תּלמיד-דאַטן-מיינינג-סקאַנדאַל-אונטער-אונדזער-נאָסעס /) [אַ] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) [y ](https://medium.com/@hansdezwart/during-world-war-ii-we-did -האבן-עפּעס-צו-באַהאַלטן-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

אנדערע מקורים:

[Alliance of Five eyes] (https://en.wikipedia.org/wiki/Five_Eyes) [Nineteen eighty four] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## אראפקאפיע לינקס

[באַקומען Firefox] (https://www.mozilla.org/en-US/firefox/new/) [באַקומען Tor browser] (https://www.torproject.org/download/) [אַנדערער / אַנאַוויילאַבאַל] (https : //www.example.com)

***

## מייַן דעגאָאָגלינג דערפאַרונג

איך לעסאָף אנגעהויבן צו זען די פּראָבלעמס מיט גרויס טעק אין 2018, און איך אנגעהויבן דעגאָאָגלינג. אין די ערשטע חדשים האָב איך געמאכט אַ גרויסע פּראָגרעס. זינט דעמאָלט עס סלאָוד אַראָפּ ימענסלי.


### וואָס איך סוויטשט פון

Google קראָום -> Firefox / Tor

Google זוך -> DuckDuckGo (פעליקייַט) / Ecosia (ווען איך פילן ווי עס) / Bing (ראַרעלי)

Gmail - פּראָטאָנמאַיל (נאָך נישט גאָר סוויטשט)

Google זייטלעך -> זעלבסט האָסטינג (ניט נאָך גאָר סוויטשט)

Google+ -> קוים געוויינט, זיך אויסגעמעקט רעכט צו זיין שאַטדאַון

Google Docs -> קיינמאָל געוויינט, איך נאָר נוצן Microsoft Word 2013 (איידער 2019) און LibreOffice (2019-onward) אַנשטאָט.

Google שיץ -> קיינמאָל געוויינט, איך נאָר נוצן Microsoft Excel 2013 (איידער 2019) און LibreOffice (2019-onward) אַנשטאָט.

Google סליידז -> קיינמאָל געוויינט, איך נאָר נוצן Microsoft PowerPoint 2013 (איידער 2019) און LibreOffice (2019-onward) אַנשטאָט.

גוגל דראַווינגס -> קיינמאָל געוויינט, איך נאָר נוצן LibreOffice (2019-onward) אַנשטאָט.

גערריט -> קיינמאָל געניצט, איך נאָר נוצן גיטהוב (קראַנט פעליקייַט), גיטלאַב, ביטבוקקעט, און סאָורסעפאָרגע אַנשטאָט.

Google Photos -> קיינמאָל געוויינט

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-פאָרשטעלן)

Google מאַפּס -> OpenStreetMaps / Apple Maps

גיין - מאַכן אַ ספּעציעל ויסנעם, אָבער נישט נוצן ווי אַ פאַנגקשאַנאַל פּראָגראַממינג שפּראַך

דאַרט - מאַכן אַ ספּעציעל ויסנעם, אָבער נישט נוצן ווי אַ פאַנגקשאַנאַל פּראָגראַממינג שפּראַך

פלאַטער - מאַכן אַ ספּעציעל ויסנעם, אָבער נישט נוצן ווי אַ פאַנגקשאַנאַל פּראָגראַממינג שפּראַך

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> קיינמאָל געוויינט, איך געפֿינען עס עקסטרע קריפּי

Google Fi -> קיינמאָל געניצט

Google קאַלענדאַר -> קיינמאָל געניצט

Google קאַלקולאַטאָר - ממש קיין אנדערע קאַלקולאַטאָר אַפּ, אפילו אַ לינוקס וואָקזאַל אין פּיטהאָן מאָדע אויב איך פילן ווי עס

Google נעסט -> קיינמאָל געוויינט

Google AMP -> קיינמאָל געוויינט

Google VPN -> קיינמאָל געוויינט, אויך אַן אָקסימאָראָן

גוגל פּייַ -> קיינמאָל געוויינט

Google זומער פון קאָד -> קיינמאָל אנטייל

טענאָר -> אנדערע GIF זייטלעך, כאָטש GIF זענען נישט צו וויכטיק פֿאַר מיר. איך יוזשאַוואַלי באַקומען GIF טעקעס פֿון DuckDuckGo בילדער, Imgur, Reddit אָדער אנדערע זייטלעך.

בלאָקקלי -> ניט מער געוויינט, ניט זיכער צי סקראַטטש איז גלייך געלאפן. איך געווארן אַ פאַנגקשאַנאַל פּראָגראַממער אין 2017 און וואַקסן אויס פון קראַצן.

GBoard -> געוויינט אַמאָל, אָבער פארלאזן

Google Glass -> קיינמאָל געוויינט, גערעכנט ווי אַ יונג קינד אָבער באַשלאָסן נישט צו באַקומען איין / נוצן איין אויב איך האָבן די אָפּציע

_ רשימה קען זיין דערענדיקט._

### פּראָדוקטן איך קען נאָך נישט באַקומען אַוועק פון זיי

פֿון 25 פעברואר 2021, דאָס זענען די Google פּראָדוקטן וואָס האַלטן מיר פון גאָר דעגאָאָגלינג:

1. יאָוטובע

2. אַנדרויד

3. Google פּלייַ סטאָר

4. Gmail (בלויז פֿאַר שולע און עטלעכע זייטלעך)

5. Google קלאַסצימער (בלויז פֿאַר שולע)

6. Google זעץ

7. Google אַקאַונט

8. Google זייטלעך (ווייַל Google ווייאַלייץ די געזעצן פון די GDPR (און קענען באַקומען נאָך פייַן € 5,000,000.00 ביז זיי פאַרריכטן עס) און פאַרווערן דאַונלאָודז פון דעם פּראָדוקט)

איך האָבן דעגאָאָגלעד פון אַלץ אַנדערש.

***

## גיין איז בייז

Google סטעאַמראָללעד איבער די 2003 אַגענט באַזירט פּראָגראַממינג שפּראַך 'גיין!' מיט זייער פּראָגראַממינג שפּראַך 'גיין' (פון 2009, 6 יאָר שפּעטער) און קליימד אַז זייער שפּראַך קען נישט ווירקן די אנדערע שפּראַך. גוגל איז געווען קריטיקירט שווער פֿאַר דעם, ווייַל זייער דעוויז "דו זאלסט נישט זיין בייז" איז נאָך אַקטיוו אין דער צייט, און דאָס איז איינער פון די פילע ינסאַדאַנץ אַז די ביי ביי ביי מאָטאָ איז געווען ויסגעדינט.

אין די סוף, די אַנטוויקלונג פון 'גיין!' אויפגעהערט, בשעת 'גיין' איז געווען מער און מער געוויינטלעך. גוגל האָט געטענהט אז זיי וועלן נישט שפּאַצירן איבער 'גיי!', אָבער צום סוף האבן זיי דאס געטון און זיי זענען אוועק מיט דעם (פון אפריל 9, 2021)

[לייענען מער וועגן Go און ווי צו זיין אָלטערנאַטיוו דאָ] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## באַניץ פון DRM

Google ניצט DRM (Digital Restrictions Management) דורך זייער WideVine DRM "דינסט" און אנדערע פארמען. דער ציל פון DRM איז צו צעשטערן די עפענען אינטערנעט און געבן קאָמפּאַניעס מאָנאָפּאָליסטיק מאַכט איבער וסערס. איר זאָל באַקומען באַפרייַען פון WideVine גאָר, קיין ענין די קאָסטן.

[לייענען מער וועגן WideVine און זייַן פּראָבלעמס דאָ] (https://github.com/Degoogle-your-life/Its-time-צו-שנייַדן-WideVine-DRM)

***

## פּראָסט מיסקאַנסעפּשאַנז

דאָס איז אַ רשימה פון עטלעכע פּראָסט מיסקאַנסעפּשאַנז מיט Google פּראָדוקטן.

### Google איז נישט דער אינטערנעץ

Google / Google זוכן איז ניט דער אינטערנעץ, Google זוכן איז נאָר אַ זוכן מאָטאָר, אַזוי ווי נישט יעדער שפּיל פֿאַר אַ נינטענדאָו פּלאַטפאָרמע איז געמאכט דורך נינטענדאָו, אָבער איז לייסאַנסט דורך נינטענדאָו, אָבער אין אַ פיל גרעסערע מאָס. אויב אַלע Google סערווערס וואָלט זיין סיימאַלטייניאַסלי חרובֿ פּונקט איצט, בלויז Google זייטלעך ווי יאָוטובע, Gmail, Google דאָקס, Google זוכן, אאז"ו ו, אָבער די מערהייט פון די אינטערנעט וואָלט זיין דאָרט (Wikipedia, Stackoverflow, GitHub, אויף אַלע מיקראָסאָפץ וועבסיטעס, NYTimes, Samsung, TikTok, אאז"ו ו.) זיי קען פאַרלירן זייער Google צייכן אין און אַנאַליטיקאַל פונקטיאָנאַליטי, אָבער זיי וואָלט נאָך זיין פאַנגקשאַנאַל (סייַדן זיי זענען נישט פּראָוגראַמד און רילייד גלייַך אויף Google)

***

## Internet Explorer 6 און Chrome

Google Chrome איז געוואָרן דער נייַער Internet Explorer 6. ווען Google Chrome איז אָריגינעל ארויס, Firefox איז געווען די דאָמינאַנט בלעטערער און האט מערסטנס געהרגעט Internet Internet Explorer מאַרקעט (וואָס סאַפּרייזד 96% איידער מיליאַנז פון מענטשן סוויטשט צו Firefox און אנדערע בראַוזערז) ווען Google Chrome ארויסגעקומען, מענטשן סוויטשט רעכט צו דער גיכקייט און עס איז געווען דורך Google (וואָס איז נישט גערעכנט ווי בייז אין דער צייט, ווייַל רובֿ פּריוואַטקייט ישוז האָבן נישט קומען צו ליכט נאָך) Google Chrome ערידזשנאַלי רעספּעקטעד וועב סטאַנדאַרדס (וואָס איז וואָס Firefox האט אָבער, ווי Google Chromes מאַרקעטשאַרע רויז, Google אנגעהויבן רימוווינג מער און מער פֿעיִקייטן, אַדינג מער ספּיוואַרע און סטאַפּט אַקסעפּטינג וועב סטאַנדאַרדס, Google Chrome איז געווארן דער נייַ Internet Explorer 6.

דער הויפּט פּראָבלעם רעכט איצט איז וועבסיטעס בלויז Chrome און וואָס וועט נישט אַרבעטן אויף אנדערע בראַוזערז ווייַל זייער דעוועלאָפּערס האָבן באַשלאָסן אַז די 30-40% פון אינטערנעט ניצערס וואָס טאָן ניט נוצן Chrome נוצן זייער פּלאַץ.

אפילו Google זיך בלויז מאַכן זיי Chrome. פֿאַר בייַשפּיל, Google זוכן וועט פּינטלעך צו אָפּלאָדירן Chrome 3 מאָל יעדער 10 סעקונדעס אויב עס דיטעקט אַז איר טאָן ניט נוצן Google Chrome (אפילו אנדערע קראָומיאַם-באזירט בראַוזערז אַזאַ ווי Brave זענען אַפעקטאַד) און זייטלעך ווי Google Earth טאָן ניט לאָזן Firefox ניצערס צו נוצן זייער פּלאַץ (פֿון 2020) פּלוס Google זעץ שטיצט נישט קול ינפּוט אויף Firefox און אנדערע ניט-Google קראָום בראַוזערז.

### די פּראָבלעם מיט העלדיש

אנדערע בראַוזערז וואָס זענען באזירט אויף Chromium, אַזאַ ווי Brave און Microsoft Edge, זענען נישט גאָר פריי פון Google ספּיוואַרע. העלדיש איז אָפט רעקאַמענדיד דורך די פאַלש זייַט פון די פּריוואַטקייט קהל, אָבער העלדיש איז נאָך אַ פּראָבלעם ווייַל עס ניצט Chromium. דער אינטערנעץ זאָל נישט זיין בלויז פֿון קראָומיאַם בראַוזערז, עס זאָל זיין אַ פאַרשיידנקייַט פון ברירה. העלדיש איז דער אומרעכט וועג צו גיין.

[לייענען מער וועגן דעגאָאָגלינג פֿון Google Chrome / Chromium דאָ] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[לייענען מער וועגן דעגאָאָגלינג פֿון ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) דאָ] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## פאָקס פּריוואַטקייט רינואַל

גוגל האט געפרוווט צו זאָגן די וועלט אַז זיי זאָרגן וועגן פּריוואַטקייט נאָך עס איז שוין צו שפּעט. זיי פאָרזעצן צו פאָדערן אַז זיי אָנערקענען פּריוואַטקייט פון באַניצער, אָבער זיי נאָך נישט פאַרריכטן אַלע זייער פּריוואַטקייט פּראָבלעמס.

### עפֿן מקור קען נישט זיין פּאַרטיייש

עפענען מקור קען נישט זיין פּאַרטיייש. Google איז דערווייַז פון דעם. יעדער ביסל און בייט פון די מקור קאָד מוזן זיין קענטיק פֿאַר דעם פּובליק, מיט ניט אפילו אַ 8th פון אַ בייט פאַרבאָרגן.

פּראַדזשעקס ווי אַנדרויד און טשראָמאָסאָס זענען טייל אָופּאַנד, אָבער אַנטהאַלטן אַ מערהייט פון פּראַפּרייאַטערי, ספּיוואַרע עלעמענטן.

### אָקסימאָראָן

Google VPN איז אַן אָקסימאָראָן. Google קען נישט זאָרגן וועגן פּריוואַטקייט, און אַ ווירטואַל פּריוואַטע נעטוואָרק (VPN) פון אַ פירמע ווי זיי וואָלט זיין איינער פון די ערגסט מעגלעך ברירות פֿאַר אַ וופּן דינסט.

***

## שלעכט פאָרשטעלונג

Google קען נישט זאָרגן וועגן די פאָרשטעלונג פון זייער פּראָדוקטן אין מינדסטער 2017, ווייַל זייער לעצטע בענטשמאַרקינג ווייכווארג (Google Octane) איז געווען דיסקאַנטיניוד אין 2017.

***

## שלעכט פּרויעקט פאַרוואַלטונג

Google האט אַ זייער שלעכט ינערלעך פּרויעקט פאַרוואַלטונג סיסטעם. עטלעכע פּראָסט ביישפילן פון מגילה וואָס האָבן שוין מער און מער דאַונלאָודיד זענען Google Duo און YouTube מוזיק (אַמאָל Google Play Music)

אין גאָאָגלעס ינערלעך אַנטוויקלונג סיסטעם, 1 אַפּ פירט צו אן אנדער אַפּ מיט האַלב פאַנגקשאַנאַליטי און דער אָריגינעל אַפּ איז אויסגעמעקט. א פּאָר יאָר שפּעטער, אַ נייַ אַפּ מיט 75% ווייניקער פאַנגקשאַנאַליטי איז געמאכט, און דערנאָך די אַפּ מיט 50% פאַנגקשאַנאַליטי איז אַוועקגענומען, נאכגעגאנגען דורך אַ נייַ אַפּ מיט 87.5% פון די פאַנגקשאַנאַליטי איז באשאפן, און די אַפּ מיט 75% פאַנגקשאַנאַליטי איז דיסקאַנטיניוד. , און אזוי ווייטער.

***

## שרעקלעך אָדער קיין מאַדעריישאַן פון באַדינונגס

יאָוטובע איז די מערסט פּראָסט ביישפּיל אין דער וועלט פון בייז מאַדעריישאַן וואָס קריייץ די ערגסט פּלאַטפאָרמע. Google קען אויך נישט באַקומען אַז יאָוטובע איז נישט יאָוטובע קידס.

פֿאַר יאָוטובע, כייטפאַל פּראָ-נאַצי און ווייסע סופּרעמאַסיסט אינהאַלט איז סערווירט צו וסערס פֿאַר די ציל פון מער באַשטעלונג צייט און מער געלט. גוגל אויך האט עטלעכענאַריש טינגז אין זייער מאַדעריישאַן, אַזאַ ווי אַפּפּראָוועד אַ קריסטלעך אַנאַל סעקס ווידעא ווי אינהאַלט `געמאכט פֿאַר קידס`, בשעת אין דער זעלביקער צייט ריסטריקטינג די ווידעא. עס איז אויך נישט ומגעוויינטלעך צו זען פּאָרנאַגראַפיק אָדער גאָר אַדס אונטער די בעיבי שאַרק ווידעא, צוזאַמען מיט פאַרשידענע אינהאַלט 'געמאכט פֿאַר קידס'.

יאָוטובע יוזערז באַקלאָגנ זיך זייער אָפט וועגן די נעבעך מאַדעריישאַן אויף יאָוטובע פֿאַר שלעכט אינהאַלט (ווי די ביישפילן אויבן), בשעת די וסערס קענען באַקומען ווידיאס אויסגעמעקט ראַנדאַמלי אָן קיין סיבה אָן ריפּילינג, און די ניצערס זענען באשטראפט פֿאַר קיין פאָרעם פון סווערינג. אפילו זייער מינערווערטיק פאלן ווי זאָגן 'באָבקעס' יוזערז פאַרגלייכן יאָוטובע צו די [סאוועטן פארבאנד] (https://en.wikipedia.org/wiki/Soviet_Union) אין די סטאַלין טקופע, רעכט צו די אַניקוואַל שטראָף.

אין 2021, גוגל אַנאַונסט אַז זיי וועלן שטעלן אַדס אויף אַלע ווידיאס, טראָץ דעם דימאַנייזד ווידעא (אַזוי אַז Google מאכט געלט, אָבער דער באשעפער טוט נישט) דאָס איז נישט צו פיל צו מאַדעריישאַן, אָבער עס איז וויכטיק צו טאָן.

יאָוטובע איז מאַדערייטיד (כאָטש זייער שוואַך), אָבער די Google אַד סערוויס וואָס מאכט זיי רובֿ פון זייער געלט מיינט צו האָבן אַ ביסל צו קיין מאַדעריישאַן.

[לייענען מער וועגן YouTube מאָדעראַטיאָן ישוז און ווי צו זיין אָלטערנאַטיוו פֿון YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

אַדס פֿאַר Google פּלייַ זענען דזשענערייטאַד פֿון באָט פאַרמס. איר קענען זען די זעלבע אַד סינעריאָוז געוויינט דורך הונדערטער קאָמפּאַניעס מיט קליין ענדערונגען און קיין שייכות צו די פּראָדוקט (פּראָסט ביישפילן: Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City און טויזנטער מער), צוזאַמען מיט אַ בומינג בייזע גאַנג פון אַדס וואָס פאָדערן אַז וסערס קענען פאַרדינען געלט דורך פּלייינג שפּילערייַ, צוגעהערט צו מוזיק, אאז"ו ו. פּייַפּאַל האט נישט קאַמענטאַד אויף דעם, אָבער עס איז קלאָר ווי דער טאָג אַז דאָס איז אַ סקאַם, ווי אויב איר קען מאַכן איבער $ 10.000 אין ווייניקער ווי 20 סעקונדעס דורך פּלייינג אַ שפּיל געראַנטיד, קיינער וואָלט טאָן אַרבעט און וואָלט טאָן דאָס אַנשטאָט, וואָס איז אוממעגלעך, און אַ געשעפט קען נישט אַרבעטן ווי דאָס. די קלאָר ווי דער טאָג סקאַם איז גראָוינג שטאַרק זינט 2019, און איצט די באָט פאַרמס וואָס פּראָדוצירן די אַדס פייטינג מיט יעדער אנדערע אין זייער אייגענע אַדס.

עטלעכע גאַנצע זענען אויך זייער ומגעלומפּערט, און פּרווון צו באַקומען וסערס (מערהייט פון זיי זענען יוזערז אונטער די עלטער פון 13 אָדער באָץ) צו קליקינג דורך געשלעכט מאַניפּיאַליישאַן.

פילע אַפּפּס נוצן באָץ און אַסטראָטורף זייער פּראָדוקטן, אַזוי ווען אַ שלעכט אָפּשאַצונג איז געמאכט, די אַקאַונץ פון סאָק ליאַלקע באָץ וועט אָנהייבן 5 שטערן באריכטן און פּרווון צו פאַרלאָזן דיין קריטיק. [Google טוט דאָס אויך זיך] (# Astroturfing)

[לייענען מער וועגן ישוז מיט Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## אַסטראָטורפינג

אַלגעמיינע דעפֿיניציע [(פֿון Wikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

""
אַסטראָטורפינג איז די פיר פון מאַסקינג די ספּאָנסאָרס פון אַ אָנזאָג אָדער אָרגאַניזאַציע (למשל, פּאָליטיש, גאַנצע, רעליגיעז אָדער עפֿנטלעכע באַציונגען) צו מאַכן עס דערשייַנען ווי אויב עס ערידזשאַנייץ פון און איז געשטיצט דורך גראַסרוץ פּאַרטיסאַפּאַנץ. עס איז פּראַקטיסיז צו געבן די סטייטמאַנץ אָדער אָרגאַנאַזיישאַנז קרעדיביליטי דורך וויטכאָולדינג אינפֿאָרמאַציע וועגן די פינאַנציעל פֿאַרבינדונג פון די מקור. דער טערמין אַסטראָטורפינג איז דערייווד פון אַסטראָטורף, אַ סאָרט פון סינטעטיש טעפּעך דיזיינד צו ריזעמבאַל נאַטירלעך גראָז, ווי אַ שפּיל אויף די וואָרט "גראַסרוץ". די ימפּלאַקיישאַן הינטער די נוצן פון דעם טערמין איז אַז אַנשטאָט אַ "אמת" אָדער "נאַטירלעך" גראַסרוץ מי הינטער די אַקטיוויטעט אין קשיא, עס איז אַ "שווינדל" אָדער "קינסטלעך" אויסזען פון שטיצן.
""

גוגל האט אַ געשיכטע פון ​​אַסטראָטורפינג צו מאַכן עס ויסקומען ווי זיי טאָן ניט טאָן עפּעס בייז (אין דעם פּראָצעס, אַסטראָטורפינג איז בייז). פֿאַר בייַשפּיל פּאָוסטינג קריטיק פון Google אויף אַ פּלאַטפאָרמע ווי טוויטטער (וואָס זיי האָבן אַ חשבון אויף) וועט רעזולטאַט אין עטלעכע אַקאַונץ וואָס האָבן שוין עקסיסטירט פֿאַר אַ בשעת אָבער קיינמאָל פּאָסטעד איידער קומען אויס און קליימינג אַז וואָס איר האָט געזאָגט איז פאַלש, און דעמאָלט קליימינג אַז Google איז דער בעסטער פירמע, אָבער געטאן אין אַ וועג אַז עס קען נישט זיין קלאָר ווי דער טאָג אַז דאָס איז באָץ פֿאַר רובֿ מענטשן.

***

## ומלעגאַל און אַנעטיקאַל געשעפט פּראַקטיסיז

גוגל ניצט ומלעגאַל און אַנעטיקאַל געשעפט פּראַקטיסיז צו ווייַטער זייער מאָנאָפּאָל, אַזאַ ווי ניצן שטייער כייווז, אַוצאָרסינג דזשאָבס און פאָרזעצן צו טאָן ומלעגאַל ינווייסיוו אַקטיוויטעטן ווי אַ קאָסטן פון געשעפט.

### אין אייראָפּע

אייראָפּע האָט אָפט אָנגעקלאָגט Google, די ביגאַסט פּראָצעס קעגן ומלעגאַל נאַטור אין אַנדרויד, וואָס ריזאַלטיד אין Google באקומען אַ € 5,000,000,000 (עקוויוואַלענט צו $ 5,947,083,703.68 אין 9 אפריל 2021 געלט)

### אין צפון אַמעריקע

די פארייניקטע שטאַטן האָבן נאָך נישט קימאַט גענוג פון אַ שטראַף צו Google, קאַמפּערד מיט אייראָפּעס € 5,000,000,000 שטראַף.

### קאָנטראָווערסיעס

גוגל קען נישט זאָרגן וועגן אַ פּראָבלעם ביז עס קריייץ אַ קאָנטראָווערסי, דערנאָך זיי וועלן מאַכן אַ נעבעך פּרווון צו פאַרריכטן עס, פּונקט גענוג פֿאַר די סיכסעך צו טעמפּערעראַלי פאַרשווינדן, און דער פּראָבלעם איז יקספּאַנשאַלי ערגער ביז עס קריייץ אן אנדער קאָנטראָווערסי. ציקל האלט. זיי פשוט טאָן ניט זאָרגן גענוג צו טאָן עפּעס ערנסט וועגן אים.

***

## גוגל איז אָטאַמייטיד

ווי אַ קאַםGoogle, Google איז מערסטנס אָטאַמייטיד, מיט ווייניקער מאַדעריישאַן ווי אָטאַמיישאַן.

א פירמע זאָל נישט זיין גאָר אָטאַמייטיד. Google איז אַ בייַשפּיל פון דעם. מאָדעראַטיאָן איז שרעקלעך ווען עס איז בלויז דורכגעקאָכט דורך אַי, יאָוטובע איז אַ גוט בייַשפּיל, אפילו מיט אַ ביסל ביסל (הונדערטער, אָדער אפֿשר טויזנט) מענטשן וואָס מאַדערייט דעם פּלאַץ, וווּ עס איז משמעות אַזוי שלעכט אַז רובֿ פון זיי האָבן צו באַקומען טעראַפּיע בשעת ארבעטן.

***

## אַנדרויד

אַנדרויד איז אָונד דורך Google. טייל פון די Open Handset Alliance (וואָס איז נישט אָפן זינט אַנדרויד) אַנדרויד איז געווארן אן אנדער מאָנאָפּאָל פונט פֿאַר Google און אַ זייער שווער צו אַנטלויפן.

אַנדרויד האט שוין געמאלדן צו טעלעפאָנירן היים צו Google בייַ מינדסטער 10 מאל פּער טאָג, און טראָץ זיין טייל אָפֿן מקור, עס נאָך אַקץ שווער ווי ספּיוואַרע.

עטלעכע פּראַדזשעקס זענען באשאפן צו זיין אַלטערנאַטיוו פֿון אַנדרויד, אָבער איר דאַרפֿן צו וואָרצל דיין מיטל. דאָס איז ניט מעגלעך מער פֿאַר ספּעציעלע סאַמסונג פאָנעס אין די יו. עס. רעכט צו די Knox DRM. פּראָסט אַלטערנאַטעס צו אַנדרויד אַרייַננעמען iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch און PiPhone (Pi Phone איז אַ סאָרט פון פאָנעס וואָס לויפן פאַרשידן לינוקס סיסטעמען אויף אַ רירעוודיק מיטל, אַזאַ ווי Fedora, Ubuntu, Arch, עטק.)

[זען מיין פאָרשונג וועגן געטינג אַ דעגאָאָגלעד אַנדרויד ווירטואַל מאַשין פאַנגקשאַנאַל] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[זען ווי צו דעגאָאָגלע פֿון אַנדרויד] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## קליין אַקשאַנז צו העלפן

עס איז וויכטיק צו פאַרשפּרייטן וויסיקייַט אויף יעדער וועג איר קענען. פֿאַר מיר, איך טאָן ניט נאָר אָפט רעדן וועגן דעגאָאָגלינג און שרייַבן אַרטיקלען, אָבער איך אויך האָבן אַ קליין ביסל מידע, ווו איך געבן מיין טעגלעך פריי רעדדיט אַוואָרד צו די פּיננעד פּאָסטן אויף r / degoogle צו כאַפּן וויסיקייַט. ביז איצט, איך האָבן קימאַט 30 אַוואַרדס צו די פּיננעד פּאָסטן (איך אויך פארבראכט 500 פון מיין פריי קאָינס אויף 10 אַוואַרדס פֿאַר דעם פּאָסטן)

***

## ניט טראַסטאַבאַל

Google קען נישט זיין טראַסטיד און קיינמאָל קענען זיין טראַסטיד. זיי האָבן גאָר ניטאָ פון "טאָן ניט זיין בייז" (זיי זענען שטענדיק בייז) צו זיין גאָר בייז און נישט טריינג צו באַהאַלטן עס.

***

## אנדערע טינגז צו קאָנטראָלירן

[דער גוגל גראַווייאַרד (killbygoogle.com) - אַ סאָרטירטע רשימה פון די 224+ פּראָדוקטן וואָס Google האָט געהרגעט] (https://killedbygoogle.com/)

> [גיטהוב לינק] (https://github.com/codyogden/killedbygoogle)

[אַלפאַבעט אַרבעטער פאַרבאַנד - דער נייַע אַרבעטער פאַרבאַנד אין Google מיט איבער 800 מיטגלידער] (https://alphabetworkersunion.org/people/our-union/)

[צי איר נישט וועלן צו שיידן די יאָג פון דער דיינאַסאָר? איר האָט קאַווערד דעם וועבזייטל] (https://chromedino.com/)

עס זענען אנדערע אָלטערנייץ, נאָר זוכן פֿאַר זיי.

***

אין דעם אַרטיקל, איר דאַרפֿן עטלעכע פאַקט קאָנטראָלירונג

***

## טעקע אינפֿאָרמאַציע

טעקע טיפּ: "מאַרקדאַון (* .מד)"

שורה ציילן (אַרייַנגערעכנט ליידיק שורות און קאַמפּיילער שורה): `968`

טעקע ווערסיע: "6 (זונטיק 18 אפריל 2021, 16:18)"

***

### ווייכווארג סטאַטוס

אַלע פון ​​מיין ווערק זענען פריי עטלעכע ריסטריקשאַנז. DRM (** D ** igital ** R ** estrictions ** M ** anagement) איז ניט פאָרשטעלן אין קיין פון מיין אַרבעט.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

דער סטיקער איז געשטיצט דורך Free Software Foundation. איך קיינמאָל האָבן בדעה צו אַרייַננעמען DRM אין מיין אַרבעט.

איך נוצן די אַבריווייישאַן "דיגיטאַל ריסטריקשאַנז מאַנאַגעמענט" אַנשטאָט פון די מער באַוווסט "דיגיטאַל הזכויות מאַנאַגעמענט" ווי דער פּראָסט וועג פון אַדרעסינג עס איז פאַלש. עס זענען קיין רעכט מיט DRM. די אויסלייג "דיגיטאַל ריסטריקשאַנז פאַרוואַלטונג" איז מער פּינטלעך און איז געשטיצט דורך [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) און די [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

דער אָפּטיילונג איז גענוצט צו כאַפּן וויסיקייַט פֿאַר די פּראָבלעמס מיט DRM, און אויך צו פּראָטעסטירן עס. DRM איז דעפעקטיווע דורך פּלאַן און איז אַ הויפּט סאַקאָנע פֿאַר אַלע קאָמפּיוטער ניצערס און ווייכווארג פרייהייט.

בילד קרעדיט: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## פּאַטראָן אינפֿאָרמאַציע

[SponsorButton.png] (SponsorButton.png) <- קליקט נישט אויף דעם קנעפּל, עס אַרבעט נישט, דאָס איז נאָר אַ בילד. די פאַקטיש קנעפּל איז אין די שפּיץ פון די בלאַט אין די רעכט (<- L ** R ** ->) ווינקל

איר קענען פּאַטראָן דעם פּרויעקט אויב איר ווילט, אָבער ביטע ספּעציפיצירן צו וואָס איר ווילט געבן. [זען די געלט איר קענען דאָונע צו דאָ] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

איר קענט זען אנדערע פּאַטראָן אינפֿאָרמאַציע [דאָ] (https://github.com/seanpm2001/Sponsor-info/)

פרובירט עס אויס! דער פּאַטראָן קנעפּל איז רעכט אַרויף צו די וואַך / ווואַטטש קנעפּל.

***

## טעקע געשיכטע



 * סטאַרטעד דער טעקע

> * צוגעגעבן דעם טיטל אָפּטיילונג

> * אַדדעד דער אינדעקס

> * צוגעגעבן די וועגן אָפּטיילונג

> * צוגעגעבן די Wiki אָפּטיילונג

> * אַדדעד די ווערסיע געשיכטע אָפּטיילונג

> * צוגעגעבן די ישוז אָפּטיילונג.

> * צוגעגעבן די אָפּטיילונג פֿאַר פאַרגאַנגענהייט

> * אַדדעד די אָפּטיילונג פֿאַר פאַרגאַנגענהייט ציען ריקוועס

> * אַדדעד די אָפּטיילונג פֿאַר אַקטיוו ציען ריקוועס

> * אַדדעד די קאָנטריבוטאָרס אָפּטיילונג

> * צוגעגעבן די קאַנטריביוטינג אָפּטיילונג

> * צוגעגעבן די וועגן README אָפּטיילונג

> * אַדדעד די README ווערסיע געשיכטע אָפּטיילונג

> * אַדדעד די אָפּטיילונג פֿאַר ריסאָרסיז

> * אַדדעד אַ ווייכווארג סטאַטוס אָפּטיילונג מיט אַ DRM פריי סטיקער און אָנזאָג

> *צוגעגעבן די אָפּטיילונג פֿאַר די פּאַטראָן אינפֿאָרמאַציע

> * קיין אנדערע ענדערונגען אין ווערסיע 0.1

ווערסיע 1 (פרייטיק, 19 פעברואר 2021, 17:20 אַם)

> ענדערונגען:

> * סטאַרטעד די טעקע

> * צוגעגעבן די אָפּטיילונג פֿאַר יקערדיק באַשרייַבונג

> * צוגעגעבן די אָפּטיילונג פֿאַר ריפּאַזאַטאָרי באַשרייַבונג

> * אַדדעד די אַרטיקל רשימה מיט 14 ערטער

>> * אַדדעד אַ אָפּטיילונג `שייכותדיקע אַרטיקלען`

>> * צוגעגעבן אַ אָפּטיילונג `זען אויך`

> * אַדדעד די טעקע אינפֿאָרמאַציע אָפּטיילונג

> * אַדדעד די טעקע געשיכטע אָפּטיילונג

> * אַדדעד די פוטער

> * קיין אנדערע ענדערונגען אין ווערסיע 1

ווערסיע 2 (פרייטיק, פעברואר 19, 2021, 5:26 נאָכמיטאָג)

> ענדערונגען:

> * צוגעגעבן די אָפּטיילונג פֿאַר איבערזעצונג סטאַטוס

> * צוגעגעבן די אָפּטיילונג פֿאַר אנדערע טינגז

> * צוגעגעבן די פּריוואַטקייט אָפּטיילונג

> * אַדדעד אַן אינדעקס

> * אַדדעד די ווייכווארג סטאַטוס סאַבסעקשאַן

> * אַדדעד די אנדערע אַנטי-Google קאַמפּיינז אָפּטיילונג

>> * אַדדעד די דעפאַנגקט סאַבסעקשאַן

>> * צוגעגעבן די אָנגאָינג סאַבסעקשאַן

> * צוגעגעבן די מקורים אָפּטיילונג

> * צוגעגעבן די אָפּטיילונג פֿאַר אראפקאפיע לינקס

> * דערהייַנטיקט דער טעקע אינפֿאָרמאַציע אָפּטיילונג

> * דערהייַנטיקט דער טעקע געשיכטע אָפּטיילונג

> * קיין אנדערע ענדערונגען אין ווערסיע 2

ווערסיע 3 (מיטוואך 24 פעברואר 2021 19:56)

> ענדערונגען:

> * דערהייַנטיקט דער אינדעקס

> * רעפערענעד די דעגאָאָגלע ייקאַן און די נייַ גיטהוב אָרגאַניזאַציע

> * אַדדעד לינקס צו נייַער אַרטיקלען

> * אַדדעד די אָפּטיילונג פון קאַונטערינג אנדערע טענות

>> * צוגעגעבן די קאַנוויניאַנס סאַבסעקשאַן

>> * אַדדעד די פארוואס אפילו אַרן סאַבסעקשאַן

>> * צוגעגעבן די אנדערע סאַבסעקשאַן

> * דערהייַנטיקט עטלעכע דאַטן

> * דערהייַנטיקט דער טעקע אינפֿאָרמאַציע אָפּטיילונג

> * דערהייַנטיקט דער טעקע געשיכטע אָפּטיילונג

> * קיין אנדערע ענדערונגען אין ווערסיע 3

ווערסיע 4 (דאנערשטאג, 25 פעברואר 2021, 21:31)

> ענדערונגען:

> * אַדדעד לינקס צו 10 נייַע אַרטיקלען

> * אַדדעד אַ אָפּטיילונג וועגן מיין דערפאַרונג דעגאָאָגלינג

> * דערהייַנטיקט דער אינדעקס

> * דערהייַנטיקט דער טעקע אינפֿאָרמאַציע אָפּטיילונג

> * דערהייַנטיקט דער טעקע געשיכטע אָפּטיילונג

> * קיין אנדערע ענדערונגען אין ווערסיע 4

ווערסיע 5 (פרייטאג 9 אפריל 2021, 18:02)

_ עס איז לעצטנס געווען אַ פעלן פון דערהייַנטיקונגען צו די אַנטי-גוגל באַוועגונג. איך אַרבעט אויף צוריקקומען צו אים נאָך אַ יבערהאַלטונג פון 1+ חודש ._

> ענדערונגען:

> * דערהייַנטיקט די טיטל אָפּטיילונג

> * דערהייַנטיקט דער אינדעקס

> * דערהייַנטיקט די שפּראַך רשימה: פאַרפעסטיקט לינקס, און צוגעגעבן מער שטיצט שפּראַכן

> * דערהייַנטיקט די אָפּטיילונג פון די אַרטיקל סטאַטוס, אַדינג 4 פאָרק לינקס

> * ופּדאַטעד די ווייכווארג סטאַטוס אָפּטיילונג

> * צוגעגעבן די אָפּטיילונג גייט איז בייז

> * אַדדעד די באַניץ פון דרם אָפּטיילונג

> * אַדדעד די אָפּטיילונג Common misconception

>> * דער Google איז נישט דער אינטערנעץ סאַבסעקשאַן

> * צוגעגעבן Internet Explorer 6 און Chrome אָפּטיילונג

>> * צוגעגעבן די די פּראָבלעם מיט העלדיש סאַבסעקשאַן

> * אַדדעד די Faux פּריוואַטקייט באַזייַטיקונג

> * אַדדעד די עפֿן מקור קענען ניט זיין פּאַרטיייש סאַבסעקשאַן

> * צוגעגעבן די אָקסימאָראָן סאַבסעקשאַן

> * אַדדעד די אָפּטיילונג פֿאַר שלעכט פאָרשטעלונג

> * צוגעגעבן די אָפּטיילונג פֿאַר שלעכט פּרויעקט פאַרוואַלטונג

> * צוגעגעבן די אָפּטיילונג שרעקלעך אָדער קיין מאַדעריישאַן פון באַדינונגס

> * צוגעגעבן די אַסטראָטורפינג אָפּטיילונג

> * צוגעגעבן די אָפּטיילונג פֿאַר ומלעגאַל און אַנעטיקאַל געשעפט פּראַקטיסיז

> * אַדדעד די אין אייראָפּע סאַבסעקשאַן

>> * צוגעגעבן די סאַב-אָפּטיילונג אין צפון אַמעריקע

>> * צוגעגעבן די סובסעקטיאָן פון קאָנטראָווערסיעס

> * אַדדעד די Google איז אָטאַמייטיד אָפּטיילונג

> * צוגעגעבן די אַנדרויד אָפּטיילונג

> * אַדדעד די קליינע אַקשאַנז צו הילף אָפּטיילונג

> * צוגעגעבן די ונטרוסטאַבלע אָפּטיילונג

> * אַדדעד די אָפּטיילונג פֿאַר פּאַטראָן אינפֿאָרמאַציע

> * דערהייַנטיקט די פוטער

> * דערהייַנטיקט דער טעקע אינפֿאָרמאַציע אָפּטיילונג

> * דערהייַנטיקט דער טעקע געשיכטע אָפּטיילונג

> * קיין אנדערע ענדערונגען אין ווערסיע 5

ווערסיע 6 (זונטיק 18 אפריל 2021, 16:18)

> ענדערונגען:

> * דערהייַנטיקט דער אינדעקס

> * צוגעגעבן אַ נייַע איבערבליק באַשרייַבונג

> * דערהייַנטיקט אינפֿאָרמאַציע אויף אַרטיקל סטאַטוס

> * צוגעגעבן אַ לינק צו די נייַע Google FLoC אַרטיקל

> * צוגעגעבן אַ לינק צו Wuest 3n Fuchs Degoogle אַרטיקל און אַלגעמיין אינפֿאָרמאַציע אויף עס

> * דערהייַנטיקט דער טעקע אינפֿאָרמאַציע אָפּטיילונג

> * דערהייַנטיקט דער טעקע געשיכטע אָפּטיילונג

> * קיין אנדערע ענדערונגען אין ווערסיע 6

ווערסיע 7 (קומענדיק באַלד)

> ענדערונגען:

> * קומענדיק באַלד

> * קיין אנדערע ענדערונגען אין ווערסיע 7

ווערסיע 8 (קומענדיק באַלד)

> ענדערונגען:

> * קומענדיק באַלד

> * קיין אנדערע ענדערונגען אין ווערסיע 8

ווערסיע 9 (קומענדיק באַלד)

> ענדערונגען:

> * קומענדיק באַלד

> * קיין אנדערע ענדערונגען אין ווערסיע 9

ווערסיע 10 (קומענדיק באַלד)

> ענדערונגען:

> * קומענדיק באַלד

> * קיין אנדערע ענדערונגען אין ווערסיע 10

ווערסיע 11 (קומענדיק באַלד)

> ענדערונגען:

> * קומענדיק באַלד

> * קיין אנדערע ענדערונגען אין ווערסיע 11

ווערסיע 12 (קומענדיק באַלד)

> ענדערונגען:

> * קומענדיק באַלד

> * קיין אנדערע ענדערונגען אין ווערסיע 12

***

## פוטער

איר האָט דערגרייכט דעם סוף פון דער טעקע

([צוריק צו שפּיץ] (# שפּיץ) | [צוריק צו GitHub] (https://github.com))

### EOF

***
