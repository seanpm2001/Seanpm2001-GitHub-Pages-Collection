***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle cuộc sống của bạn

Đây là bài viết degoogling chính để biết thông tin chung về degoogling và một liên kết đến các bài viết khác.

[Xem danh sách dưới dạng tổ chức GitHub] (https://github.com/Degoogle-your-life)

***

_Đọc bài viết này bằng một ngôn ngữ khác: _

** Ngôn ngữ hiện tại là: ** `English (US)` _ (có thể cần sửa bản dịch để sửa tiếng Anh thay thế ngôn ngữ chính xác) _

_🌐 Danh sách các ngôn ngữ_

** Sắp xếp theo: ** `A-Z`

[Không có tùy chọn sắp xếp] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albania | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) Tiếng Ả Rập | [hy հայերեն] (/. github / README_HY.md) Tiếng Armenia | [az Azərbaycan dili] (/. github / README_AZ.md) Tiếng Azerbaijani | [eu Euskara] (/. github /README_EU.md) Tiếng Basque | [be Беларуская] (/. Github / README_BE.md) Tiếng Belarus | [bn বাংলা] (/. Github / README_BN.md) Tiếng Bengali | [bs Bosanski] (/. Github / README_BS.md) Tiếng Bosnia | [bg български] (/. Github / README_BG.md) Tiếng Bungary | [ca Català] (/. Github / README_CA.md) Tiếng Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Tiếng Trung (Giản thể) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Tiếng Trung (Phồn thể) | [co Corsu] (/. Github / README_CO.md) Tiếng Corsican | [hr Hrvatski] (/. Github / README_HR.md) Tiếng Croatia | [cs čeština] (/. Github / README_CS .md) Tiếng Séc | [da dansk] (README_DA.md) Tiếng Đan Mạch | [nl Nederlands] (/. github / README_ NL.md) Tiếng Hà Lan | [** en-us English **] (/. github / README.md) Tiếng Anh | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Tiếng Estonia | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Tiếng Phần Lan | [fr français] (/. github / README_FR.md) Tiếng Pháp | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galician | [ka ქართველი] (/. github / README_KA) Tiếng Georgia | [de Deutsch] (/. github / README_DE.md) Tiếng Đức | [el Ελληνικά] (/. github / README_EL.md) Tiếng Hy Lạp | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Tiếng Creole của Haiti | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Tiếng Hawaii | [he עִברִית] (/. github / README_HE.md) Tiếng Do Thái | [xin chào हिन्दी] (/. github / README_HI.md) Tiếng Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Tiếng Hungary | [is Íslenska] (/. github / README_IS.md) Tiếng Iceland | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Tiếng Iceland | [ga Gaeilge] (/. github / README_GA.md) Tiếng Ireland | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Tiếng Nhật | [jw Wong functiona] (/. github / README_JW.md) Tiếng Java | [kn ಕನ್ನಡ] (/. github / README_KN.md) Tiếng Kannada | [kk Қазақ] (/. github / README_KK.md) Tiếng Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Tiếng Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Tiếng Hàn (Nam) | [ko-north 문화어] (README_KO_NORTH.md) Korean (North) (CHƯA ĐƯỢC DỊCH) | [ku Kurdî] (/. github / README_KU.md) Người Kurd (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kyrgyz | [lo ລາວ] (/. github / README_LO.md) Tiếng Lào | [la Latine] (/. github / README_LA.md) Tiếng Latinh | [lt Liệtuvis] (/. github / README_LT.md) Tiếng Litva | [lb Lëtzebuergesch] (/. github / README_LB.md) Tiếng Luxembourg | [mk Македонски] (/. github / README_MK.md) Tiếng Macedonian | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) Tiếng Malay | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Tiếng Malta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Tiếng Mông Cổ | [my မြန်မာ] (/. github / README_MY.md) Myanmar (tiếng Miến Điện) | [ne नेपाली] (/. github / README_NE.md) Tiếng Nepal | [no norsk] (/. github / README_NO.md) Tiếng Na Uy | [hoặc ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Tiếng Ba Tư [pl polski] (/. github / README_PL.md) Tiếng Ba Lan | [pt português] (/. github / README_PT.md) Tiếng Bồ Đào Nha | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Tiếng Punjabi | Không có ngôn ngữ nào bắt đầu bằng chữ cái Q | [ro Română] (/. github / README_RO.md) Tiếng Rumani | [ru русский] (/. github / README_RU.md) Tiếng Nga | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scots Gaelic | [sr Српски] (/. github / README_SR.md) Tiếng Serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Tiếng Slovak | [sl Slovenščina] (/. github / README_SL.md) Tiếng Slovenia | [so Soomaali] (/. github / README_SO.md) Tiếng Somali | [[es en español] (/. github / README_ES.md) Tiếng Tây Ban Nha | [su Sundanis] (/. github / README_SU.md) Tiếng Sundan | [sw Kiswahili] (/. github / README_SW.md) Tiếng Swahili | [sv Svenska] (/. github / README_SV.md) Tiếng Thụy Điển | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tiếng Tamil | [tt Татар] (/. github / README_TT.md) Tiếng Tatar | [te తెలుగు] (/. github / README_TE.md) Tiếng Telugu | [th ไทย] (/. github / README_TH.md) Tiếng Thái | [tr Türk] (/. github / README_TR.md) Tiếng Thổ Nhĩ Kỳ | [tk Türkmenler] (/. github / README_TK.md) Người Thổ Nhĩ Kỳ | [uk Український] (/. github / README_UK.md) Tiếng Ukraina | [ur اردو] (/. github / README_UR.md) Tiếng Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Tiếng Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Tiếng Việt | [cy Cymraeg] (/. github / README_CY.md) Tiếng Wales | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Có sẵn bằng 110 ngôn ngữ (108 khi không tính tiếng Anh và tiếng Bắc Triều Tiên, vì tiếng Bắc Triều Tiên chưa được dịch [Đọc về nó tại đây] (/ OldVersions / Korean (tiếng Bắc ) /README.md))

Bản dịch bằng các ngôn ngữ không phải tiếng Anh được dịch bằng máy và chưa chính xác. Chưa có lỗi nào được sửa kể từ ngày 5 tháng 2 năm 2021. Vui lòng báo cáo lỗi dịch [tại đây] (https://github.com/seanpm2001/Degoogle-your-life/issues/) đảm bảo sao lưu sửa lỗi của bạn với các nguồn và hướng dẫn tôi , vì tôi không biết các ngôn ngữ khác ngoài tiếng Anh (cuối cùng tôi cũng định nhờ người phiên dịch), vui lòng trích dẫn [wiktionary] (https://en.wiktionary.org) và các nguồn khác trong báo cáo của bạn. Không làm như vậy sẽ dẫn đến việc từ chối việc sửa chữa được xuất bản.

Lưu ý: do những hạn chế với cách diễn giải đánh dấu của GitHub (và hầu hết mọi cách diễn giải dựa trên web khác về đánh dấu), việc nhấp vào các liên kết này sẽ chuyển hướng bạn đến một tệp riêng biệt trên một trang riêng biệt không phải là trang tiểu sử GitHub của tôi. Bạn sẽ được chuyển hướng đến [kho lưu trữ seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), nơi lưu trữ README.

Các bản dịch được thực hiện bằng Google Dịch do hạn chế hoặc không hỗ trợ các ngôn ngữ tôi cần trong các dịch vụ dịch thuật khác như DeepL và Bing Translate (khá mỉa mai cho một chiến dịch chống Google). Tôi đang tìm kiếm một giải pháp thay thế. Vì một số lý do, định dạng (liên kết, dấu phân cách, in đậm, in nghiêng, v.v.) bị lộn xộn trong các bản dịch khác nhau. Thật là tẻ nhạt để khắc phục và tôi không biết cách khắc phục những sự cố này bằng các ngôn ngữ có ký tự không phải latin và cần thêm trợ giúp để khắc phục những sự cố này

Do sự cố bảo trì, nhiều bản dịch đã lỗi thời và đang sử dụng phiên bản lỗi thời của tệp bài viết `README` này. Một người phiên dịch là cần thiết. Ngoài ra, kể từ ngày 9 tháng 4 năm 2021, tôi sẽ mất một thời gian để làm cho tất cả các liên kết mới hoạt động.

***

## Mục lục

[00.0 - Title] (# Degoogling --- Degoogle-your-life)

> [00.1 - Chỉ mục] (# Chỉ mục)

[01.0 - Mô tả cơ bản] (# Mô tả cơ bản)

> [01.1 - Tiêu đề kho lưu trữ] (# Degoogle-your-life)

> [01.2 - Tổng quan về mô tả Wuest3NFuchs] (# Overview-by-Wuest3nFuchs)

>> [01.2.1 - Nó có nghĩa là gì?] (# What-does-it-mean - by-Wuest3nFuchs)

>> [01.2.2 - Why Degoogle?] (# Why-Degoogle - by-Wuest3nFuchs)

[02.0 - Bài báo] (# Bài báo)

[03.0 - Quyền riêng tư] (# Quyền riêng tư)

[04.0 - Các chiến dịch chống Google khác] (# Chiến dịch chống Google khác)

> [04.0.1 - Không còn tồn tại] (# Không còn tồn tại)

> [04.0.2 - Đang diễn ra] (# Đang diễn ra)

[05.0 - Phản đối các đối số khác] (# Đối số-khác-đối số)

> [05.0.1 - Tiện lợi] (# Tiện lợi)

> [05.0.2 - Tại sao nó quan trọng? Dù sao thì cũng quá muộn] (# Why-does-it-matter, -its-too-late-anyways)

> [05.0.3 - Khác] (# Khác)

[06.0 - Nguồn] (# Nguồn)

[07.0 - Liên kết tải xuống] (# Liên kết tải xuống)

[08.0 - Trải nghiệm degoogling của tôi] (# My-degoogling-experience)

> [08.1 - Tôi đã chuyển từ gì] (# Tôi đã chuyển từ nào)

> [08.2 - Những sản phẩm tôi vẫn chưa thể mua được] (# Sản phẩm-tôi-vẫn-chưa-thể-bỏ-qua)

[09.0 - Những thứ khác cần thanh toán] (# Những thứ khác cần thanh toán)

[10.0 - Thông tin tệp] (# Thông tin tệp)

> [10.1 - Trạng thái phần mềm] (# Trạng thái phần mềm)

> [10.2 - Thông tin nhà tài trợ] (# Thông tin nhà tài trợ)

[11.0 - Lịch sử tệp] (# Lịch sử tệp)

[12.0 - Chân trang] (# Chân trang)

***

## Mô tả cơ bản

[Từ Wikipedia: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

Phong trào DeGoogle (còn được gọi là phong trào hủy bỏ Google) là một chiến dịch cấp cơ sở đã phát sinh khi các nhà hoạt động quyền riêng tư kêu gọi người dùng ngừng sử dụng các sản phẩm của Google hoàn toàn do lo ngại về quyền riêng tư ngày càng tăng liên quan đến công ty. Thuật ngữ này đề cập đến hành động xóa Google khỏi cuộc sống của một người. Khi thị phần ngày càng tăng của gã khổng lồ internet tạo ra quyền lực độc quyền cho công ty trong không gian kỹ thuật số, ngày càng nhiều nhà báo nhận thấy khó khăn trong việc tìm kiếm các giải pháp thay thế cho các sản phẩm của công ty.

**Lịch sử**

Vào năm 2013, John Koetsier của Venturebeat cho biết máy tính bảng chạy hệ điều hành Android Kindle Fire của Amazon là "một phiên bản Android được Google loại bỏ". Năm 2014, John Simpson của US News đã viết về “quyền được lãng quên” của Google và các công cụ tìm kiếm khác. Vào năm 2015, Derek Scally của Thời báo Ireland đã viết một bài báo về cách "Hủy bỏ Google cuộc sống của bạn." Vào năm 2016 Kris Carlon của Android Cơ quan chức năng đề xuất rằng người dùng CyanogenMod 14 có thể “xóa Google” điện thoại của họ, vì CyanogenMod cũng hoạt động tốt mà không cần ứng dụng Google. Vào năm 2018, Nick Lucchesi của Inverse đã viết về cách ProtonMail quảng bá cách “có thể loại bỏ hoàn toàn Google-fy cuộc sống của bạn”. Brendan Hesse của Lifehacker đã viết một bài hướng dẫn chi tiết về cách "từ bỏ Google". Nhà báo Kashmir Hill của Gizmodo tuyên bố rằng cô ấy đã bỏ lỡ các cuộc họp và gặp khó khăn khi tổ chức các buổi gặp mặt mà không sử dụng Lịch Google. Vào năm 2019, Huawei đã hoàn lại tiền cho các chủ sở hữu điện thoại ở Philippines, những người đã bị hạn chế sử dụng các dịch vụ do Google cung cấp vì tồn tại rất ít lựa chọn thay thế khiến việc không có sản phẩm của công ty khiến việc sử dụng internet bình thường trở nên khó khả thi.

***

# Degoogle-your-life
Một kho lưu trữ thông tin gỡ bỏ chung và các liên kết đến các kho lưu trữ gỡ bỏ khác của tôi.

***

## Tổng quan bởi Wuest3nFuchs

Mô tả tốt hơn, được cung cấp bởi [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - nguồn: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Nó có nghĩa là gì? bởi Wuest3nFuchs

Degoogling có nghĩa là ngừng sử dụng bất kỳ thứ gì thuộc về Google, bất kỳ thứ gì do Google tạo ra. Tôi đang nói về công cụ tìm kiếm của họ, dịch vụ thư của họ (Gmail), Youtube, v.v.

### Tại sao lại là Degoogle? bởi Wuest3nFuchs

Google hiện là một trong những công ty mạnh nhất trên thế giới. Họ đã lưu trữ một lượng lớn thông tin về tất cả chúng ta. Một số người cho rằng thông tin của chúng tôi an toàn với họ vì họ biết cách bảo vệ thông tin đó. Nhưng điều này không đúng. Google đã bị thâm nhập trước đây và nó sẽ bị thâm nhập trong tương lai. Có thể không phải bởi một đứa trẻ viết kịch bản nào đó nhưng nó sẽ được thực hiện bởi một quốc gia. Google lưu trữ thông tin cá nhân của tất cả chúng ta vì đây là cách họ kiếm tiền.

Họ quét email của chúng tôi, lưu trữ những gì chúng tôi tìm kiếm khi sử dụng công cụ tìm kiếm của họ, những video chúng tôi xem trên Youtube. Đây là cách họ nhắm mục tiêu chúng tôi và xây dựng một hồ sơ về chúng tôi để hiển thị cho chúng tôi một số quảng cáo dựa trên những gì chúng tôi đã nói với người bạn thân nhất của mình để họ có thể hiển thị cho chúng tôi một quảng cáo cho thứ chúng tôi cần, nhưng điều này quá kinh dị. Cảm ơn ông Snowden, giờ đây chúng tôi biết rằng Google đã chia sẻ thông tin cá nhân của chúng tôi với NSA theo một chương trình có tên ** "PRISM" **.


Trong tương lai, ai đó sẽ có khả năng truy cập tất cả thông tin đó và tôi đảm bảo với bạn rằng điều gì đó thực sự tồi tệ sẽ xảy ra. Để ngăn điều đó xảy ra, bạn nên bắt đầu Degoogling ngay bây giờ. Ngoài ra, bạn không nên sử dụng các sản phẩm của một công ty chia sẻ dữ liệu của bạn với ** NSA **. Bạn nên dừng tất cả những điều này bằng cách degoogling.

** Nếu người khác làm được, bạn cũng có thể làm được. **

[Đọc thêm tại đây] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Một liên kết đến fork hiện không được liệt kê, vì tôi không sở hữu hoàn toàn kho lưu trữ này và muốn quảng bá các nguồn khác. Sẽ là ích kỷ nếu liên kết đến https://github.com/Degoogle-your-life/Degoogle của tôi! ->

***

## Bài viết

### Trạng thái bài viết

_Tất cả các bài báo hiện đang trong quá trình hoàn thiện và cần được cải tiến lớn. Đề xuất và sửa lỗi được cho phép._

_ Kể từ ngày 18 tháng 4 năm 2021 lúc 4:09 chiều, hầu hết các bài viết vẫn chưa được bắt đầu. Tôi đang nỗ lực tìm kiếm thời gian và nỗ lực để bắt đầu chúng._

[Tại sao bạn nên ngừng sử dụng Google Chrome] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Ngừng sử dụng ChromeBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Ngừng sử dụng WideVine DRM / Đã đến lúc cắt WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Tại sao bạn nên ngừng sử dụng ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Xen kẽ từ YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Ngừng sử dụng Google, tại sao bạn nên ngừng sử dụng Google Tìm kiếm] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[Tại sao bạn nên ngừng sử dụng Gmail] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Tại sao bạn nên ngừng sử dụng Android] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Tại sao bạn nên tránh Google Amp] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Tại sao bạn nên ngừng sử dụng Google Drive] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Tại sao bạn nên ngừng sử dụng Google Maps và Google Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Này Google, dừng lại] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Ngừng đọc sách trên Google / Play] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Ngừng sử dụng Google Lớp học] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Tại sao bạn nên ngừng sử dụng Google Dịch] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Tại sao bạn nên ngừng sử dụng (các) Tài khoản Google của mình] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Accounts) <! - 16! ->

** Bài mới sẽ sớm được viết: **

[Tại sao bạn nên ngừng sử dụng Gerrit] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Tại sao bạn nên ngừng sử dụng Google Analytics (kho lưu trữ của tôi đã bị hỏng kể từ Thứ Tư, ngày 24 tháng 2 năm 2021 lúc 4:13 chiều)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics) <! - 18! ->

<! - Vách ngăn công việc! ->

[Tại sao bạn nên ngừng sử dụng Google AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Tại sao bạn nên ngừng sử dụng Google One] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Tại sao bạn nên ngừng sử dụng Google+ (không còn tồn tại)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Tại sao bạn nên ngừng sử dụng Cửa hàng Google Play] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Tại sao bạn nên ngừng sử dụng Google Tài liệu] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Tại sao bạn nên ngừng sử dụng Google Trang trình bày] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Tại sao bạn nên ngừng sử dụng Google Trang tính] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Tại sao bạn nên ngừng sử dụng Google Biểu mẫu] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Tại sao bạn nên ngừng sử dụng Google Cardboard] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Tại sao bạn nên ngừng sử dụng Google Messages] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Tại sao bạn nên ngừng sử dụng Google Material Design] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Tại sao bạn nên ngừng sử dụng Google Glass / Glasses] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Tại sao bạn nên ngừng sử dụng Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Tại sao bạn nên ngừng sử dụng GBoard] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Tại sao bạn nên ngừng sử dụng Google Home] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Tại sao bạn nên ngừng sử dụng Google Nest] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Tại sao bạn nên ngừng sử dụng Google Hangouts (không còn tồn tại)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Tại sao bạn nên ngừng sử dụng Google Duo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Tại sao bạn nên ngừng sử dụng Google Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Tại sao bạn nên ngừng sử dụng Google Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Tại sao bạn nên ngừng sử dụng Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Tại sao bạn nên ngừng sử dụng ngôn ngữ lập trình Googles Go] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Tại sao bạn nên ngừng sử dụng ngôn ngữ lập trình Googles Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Tại sao bạn nên ngừng sử dụng định dạng hình ảnh WebP của Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Tại sao bạn nên ngừng sử dụng định dạng video WebM của Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Tại sao bạn nên ngừng sử dụng Google Video] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Tại sao bạn nên ngừng sử dụng Google Sites (cổ điển)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Tại sao bạn nên ngừng sử dụng Google Sites ("Mới")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Tại sao bạn nên ngừng sử dụng Google Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Tại sao bạn nên ngừng sử dụng Android Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Tại sao bạn nên ngừng sử dụng Google VPN (oxymoron)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Tại sao bạn nên ngừng sử dụng Google Photos] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[Tại sao bạn nên ngừng sử dụng Lịch Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Tại sao bạn nên ngừng sử dụng VirusTotal (vì nó đã thuộc quyền sở hữu của Google từ tháng 9 năm 2012] (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Tại sao bạn nên ngừng sử dụng Google Fi] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi) <! - 53! ->

[Tại sao bạn nên ngừng sử dụng Google Stadia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Tại sao bạn nên ngừng sử dụng Google Keep] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Tại sao bạn nên ngừng sử dụng Google Base] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Tại sao bạn nên ngừng tham gia Google Summer of Code] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Tại sao bạn nên ngừng sử dụng Google Máy ảnh] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Tại sao bạn nên ngừng sử dụng Google Calculator (có vẻ cực đoan, nhưng bạn nên loại bỏ mọi thứ, cực kỳ dễ dàng để thay thế từ)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Máy tính) <! - 59! ->

[Tại sao bạn nên ngừng sử dụng Google Survey + phần thưởng] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Tại sao bạn nên ngừng sử dụng Google Bản vẽ] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Tại sao bạn nên ngừng sử dụng Tenor (trang GIF, do Google sở hữu từ năm 2019)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[FLoC là gì - Tại sao bạn nên tránh vấn đề FLoCing lớn của Google (ngừng sử dụng Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Tổng số bài: ** `63 '

** Bài viết [lộ trình AB] (DegoogleCampaign_2021Roadmap_Part1.md) (đến ngày 12 tháng 3 năm 2021) 2 ngày nghỉ **

** Bài viết [lộ trình BB] (DegoogleCampaign_2021Roadmao_Part2.md) (đến năm 2021) nghỉ 2 ngày **

Trạng thái bài viết

Tất cả các bài báo hiện đang trong quá trình hoàn thiện và cần được cải tiến lớn. Đề xuất và sửa chữa được cho phép.

** Nĩa **

Mở rộng mạng Degoogle của tôi và thêm một số tiện ích truy cập cũng như lời cảm ơn của cộng đồng.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Được chuyển từ: [https://github.com/wacko1805/Fossapps](https://github.com/wacko1805/Fossapps) (tiếng Anh)

2. [Liên kết bảo mật] (https://github.com/Degoogle-your-life/Privacy-links) | Được chuyển từ: [https://github.com/Arturro43/privacy-links](https://github.com/Arturro43/privacy-links) (Tiếng Ba Lan)

3. [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Được chuyển từ: [https://github.com/LinuxCafeFederation/Delightful-Privacy](https://github.com/LinuxCafeFederation/Delightful-Privacy) (Tiếng Anh)

4. [Danh sách chặn] (https://github.com/Degoogle-your-life/blocklists) | Được phân tách từ: [https://github.com/jmdugan/blocklists](https://github.com/jmdugan/blocklists) (tiếng Anh)

5. [Degoogle, bởi Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Được phân tách từ: [https://github.com/Wuest3nFuchs/Degoogle](https://github.com/Wuest3nFuchs/Degoogle) (tiếng Anh)

** Liên quan **

[Nghiên cứu Máy ảo trên điện thoại Android được gỡ bỏ] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Xem thêm:**

[Chỉ trích Google tại Wikipedia] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[Nghĩa địa của Google (killbygoogle.com) - danh sách được sắp xếp gồm hơn 224 sản phẩm mà Google đã loại bỏ] (https://killedbygoogle.com/)

> [Liên kết GitHub] (https://github.com/codyogden/killedbygoogle)

[Alphabet worker union - Liên minh công nhân mới tại Google với hơn 800 thành viên] (https://alphabetworkersunion.org/people/our-union/)

[Không muốn chia tay với quả trứng phục sinh khủng long? Trang web này đã bảo vệ bạn] (https://chromedino.com/)

***

## Riêng tư

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (tracking_program)) [o] (https://www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https://www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https://protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument # Criticism) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -essay-samples / nothing-to-hide-reason-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- of-data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -your-personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -monetizes-and) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- collection-Saving.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ health-fitness-data-privacy /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https://www.engadget .com / australian-Government-google-data-collection-Kiện-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/osystem-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https://moz.com /blog/where-does-google-draw-the-data-collection-line)[e](https://mashable.com/article/google-android-data-collection-study/)[s](https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)[o](https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -tuyên bố-thay-mặt-của-5-m illion-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https:// topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/)[r](https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/)[i](https://www.cbsnews.com/news/google-education-spies-on-collects- data-on-million-of-kids-alleges-sue-new-mexico-attorney-general /) [v] (https://www.nationalreview.com/2018/04/the-student-data-fining-scandal -under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / tech / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : //medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Tôi có thể tiếp tục với bằng chứng về điều này, nhưng đã mất nhiều thời gian để tìm và xem qua tất cả những điều này bài viết)

Quyền riêng tư trên các sản phẩm của Google luôn kém, do tất cả các sản phẩm của Google đều chứa phần mềm gián điệp.

Bất kể bạn làm gì, khi bạn đang sử dụng Google, tất cả dữ liệu cá nhân nhạy cảm của bạn sẽ được gửi tới Google và những người khác. Google cũng đã được phát hiện thông qua các chương trình mở. Ví dụ: từ trải nghiệm cá nhân (trên Firefox) với một tab YouTube đang mở mà tôi không truy cập, tôi đã xem một số video ngoại tuyến (VLC Media Player) Sau đó, khi tôi kiểm tra các đề xuất, đó là gần như tất cả mọi thứ mà tôi đã xem. Không nghi ngờ gì nữa, họ cũng đang theo dõi các chương trình khác.

Trong Chrome (và nhiều trình duyệt khác) có chế độ ẩn danh. Trong Chrome, chế độ này là vô nghĩa vì Google vẫn sẽ khai thác dữ liệu của bạn. Ngay cả khi bạn tắt tính năng khai thác / theo dõi dữ liệu và bật tín hiệu "không theo dõi", hãy bất ngờ thay, Google vẫn đang khai thác dữ liệu của bạn.

Nếu bạn nghĩ rằng bạn không có gì để che giấu, ** bạn đã hoàn toàn sai lầm **. Lập luận này đã được lật tẩy nhiều lần:

[Qua Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden nhận xét "Lập luận rằng bạn không quan tâm đến quyền riêng tư vì bạn không có gì phải che giấu thì chẳng khác nào nói rằng bạn không quan tâm đến quyền tự do ngôn luận bởi vì bạn không có gì để nói." Tôi không có gì phải giấu, bạn đang nói, “Tôi không quan tâm đến quyền này.” Bạn đang nói, “Tôi không có quyền này, bởi vì tôi đã đến mức phải biện minh "Cách thức hoạt động của các quyền là, chính phủ phải biện minh cho sự xâm phạm quyền của bạn."

2. Daniel J. Solove đã tuyên bố trong một bài báo cho The Chronicle of Higher Education rằng ông phản đối lập luận này; ông tuyên bố rằng một chính phủ có thể phá vỡk thông tin về một người và gây ra thiệt hại cho người đó, hoặc sử dụng thông tin về một người để từ chối quyền truy cập vào các dịch vụ ngay cả khi một người không thực sự tham gia vào hành vi sai trái và rằng chính phủ có thể gây thiệt hại cho cuộc sống cá nhân của người đó thông qua việc mắc lỗi. Solove đã viết "Khi tham gia trực tiếp, lập luận không có gì để che giấu có thể bị bắt giữ, vì nó buộc cuộc tranh luận tập trung vào hiểu biết hạn hẹp của mình về quyền riêng tư. Nhưng khi đối mặt với nhiều vấn đề về quyền riêng tư liên quan đến việc thu thập và sử dụng dữ liệu của chính phủ ngoài sự giám sát tiết lộ, lý lẽ không có gì để che giấu, cuối cùng, không có gì để nói. "

3. Adam D. Moore, tác giả của Quyền riêng tư: Nền tảng đạo đức và pháp lý, lập luận, "đó là quan điểm cho rằng các quyền chống lại chi phí / lợi ích hoặc các lập luận theo chủ nghĩa hậu quả. Ở đây chúng tôi bác bỏ quan điểm cho rằng lợi ích riêng tư là loại những thứ có thể được trao đổi để bảo mật. " Ông cũng tuyên bố rằng hoạt động giám sát có thể ảnh hưởng không tương xứng đến một số nhóm nhất định trong xã hội dựa trên ngoại hình, sắc tộc, giới tính và tôn giáo.

4. Bruce Schneier, một chuyên gia bảo mật máy tính và mật mã, bày tỏ sự phản đối, trích dẫn tuyên bố của Hồng y Richelieu "Nếu ai đó cho tôi sáu dòng được viết bởi bàn tay của người trung thực nhất, tôi sẽ tìm thấy thứ gì đó trong đó để treo cổ anh ta", đề cập về cách chính quyền tiểu bang có thể tìm thấy các khía cạnh trong cuộc sống của một người để truy tố hoặc tống tiền cá nhân đó. Schneier cũng lập luận rằng "Quá nhiều mô tả sai trong cuộc tranh luận là 'bảo mật so với quyền riêng tư.' Sự lựa chọn thực sự là tự do so với kiểm soát. "

5. Harvey A. Silverglate ước tính rằng một người bình thường, trung bình, vô tình phạm ba trọng tội mỗi ngày ở Hoa Kỳ.

6. Emilio Mordini, triết gia và nhà phân tâm học, cho rằng lập luận "không có gì phải che giấu" vốn là nghịch lý. Người ta không cần phải có "một cái gì đó để che giấu" để che giấu "một cái gì đó". Những gì bị che giấu không nhất thiết phải có liên quan, Mordini khẳng định. Thay vào đó, ông lập luận rằng một khu vực thân mật có thể được che giấu và bị hạn chế truy cập là cần thiết vì nói về mặt tâm lý, chúng ta trở thành những cá nhân thông qua việc phát hiện ra rằng chúng ta có thể giấu điều gì đó với người khác.

7. Julian Assange tuyên bố "Vẫn chưa có câu trả lời về kẻ giết người. Jacob Appelbaum (@ioerror) đã có một câu trả lời thông minh, yêu cầu những người nói điều này sau đó đưa cho anh ta điện thoại của họ mở khóa và kéo quần xuống. Phiên bản của tôi là, 'Chà, nếu bạn quá nhàm chán thì chúng ta không nên nói chuyện với bạn, và cũng không nên nói chuyện với ai khác', nhưng về mặt triết học, câu trả lời thực sự là thế này: Giám sát hàng loạt là một sự thay đổi cấu trúc hàng loạt. Khi xã hội trở nên tồi tệ, nó sẽ để mang bạn theo, ngay cả khi bạn là người nhạt nhẽo nhất trên trái đất. "

8. Giáo sư luật Ignacio Cofone cho rằng lập luận này là sai lầm trong các thuật ngữ của nó bởi vì, bất cứ khi nào người ta tiết lộ thông tin liên quan cho người khác, họ cũng tiết lộ thông tin không liên quan. Thông tin không liên quan này có chi phí bảo mật và có thể dẫn đến các tác hại khác, chẳng hạn như phân biệt đối xử.

***

## Các chiến dịch chống Google khác

Đây là danh sách các chiến dịch chống Google đáng chú ý khác. Danh sách này không đầy đủ. Bạn có thể giúp bằng cách mở rộng nó.

### Không còn tồn tại

[Scroogled - Bởi Microsoft (tháng 11 năm 2012 đến năm 2014)] (https://en.wikipedia.org/wiki/Scroogled)

_Không có mục nào khác vào lúc này._

### Đang diễn ra

_Danh sách này hiện đang trống ._

***

## Phản đối các đối số khác

Có một số lập luận mọi người đưa ra để biện minh cho Google. Một trong những cái chính đầu tiên đã được gỡ rối [tại đây] (# Quyền riêng tư) nhưng đây là một số cái khác:

### Tiện

Có, các sản phẩm của Google có vẻ tiện lợi. Tuy nhiên, bạn đang giao dịch mọi thứ tốt để thuận tiện, bao gồm bảo mật, quyền riêng tư và độ tin cậy. Google đã trở nên lười biếng hơn trong những năm qua và các máy chủ của họ ngày càng bị hỏng hóc. Hiện tại, các máy chủ của Google hoạt động gần một giờ, 1-2 lần mỗi tháng (đáng chú ý nhất là YouTube)

Thật không may, do xã hội phụ thuộc vào Google, Google đã trở nên thống trị Internet và đang tìm cách kiểm soát ngày càng nhiều hơn. Vào năm 2012, khi Google ngừng hoạt động trong 5 phút, có báo cáo rằng ** lưu lượng truy cập Internet ** toàn cầu ** đã giảm 40% ** Google thường xuyên gặp sự cố trong 1-2 giờ và với việc [sa thải nhóm đạo đức của họ] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) trong số những thứ khác, chúng sẽ ngày càng trở nên kém tiện lợi hơn.

Sự tiện lợi không phải lúc nào cũng là một điều tốt. Bạn nên biết những gì đang diễn ra và chuẩn bị cho khi chúng gặp sự cố, vì không có cách nào để máy chủ không bị sập liên tục.

Google cũng không thuận tiện như bạn nghĩ. Có nhiều trang khác thuận tiện hơn. Google không có gì thuận tiện, khi bạn tài khoản của họ ngẫu nhiên bị đình chỉ và chấm dứt tài khoản mà không có phản hồi (trừ khi bạn thu hút đủ sự chú ý đến tài khoản twitter của Google hoặc kiện họ với số tiền 100.000.000 đô la trở lên) thì họ đã lợi dụng bạn, bắt bạn và buộc bạn phải hét vào một cái gối, nơi không ai có thể nghe thấy tiếng hét của bạnđể được giúp đỡ.

### Tại sao nó lại quan trọng, dù sao thì cũng quá muộn rồi

Đây là một lập luận ít phổ biến hơn, nhưng nó cần được giải thích. Với tình hình hiện tại, hầu hết các chính phủ trên thế giới, cùng với một số tập đoàn hùng mạnh dường như biết mọi động thái của bạn, vậy tại sao bạn lại bận tâm tránh xa nó? Câu trả lời rất đơn giản: ** bạn xứng đáng tốt hơn **. Nếu bạn xoay sở để tránh xa họ vào thời điểm này, họ sẽ khó theo dõi động thái của bạn hơn và bạn có thể xây dựng một cuộc sống riêng tư mới hơn.

[1 nguồn] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Nhân tiện, tôi đã trao giải thưởng Reddit miễn phí của mình cho bài đăng này mỗi khi tôi nhận được nó trong hơn một tuần bây giờ (cùng với tất cả 500 xu miễn phí của tôi) để thúc đẩy chủ đề này lên hơn nữa. Cho đến nay, tôi đã trao cho bài viết này hơn 14 giải thưởng miễn phí. Nó không nhiều, nhưng những điều nhỏ nhặt có thể tạo ra tác động lớn, tùy thuộc vào cách nó được nhìn nhận và bởi ai.

### Khác

Tôi không có bất kỳ lập luận nào khác vào lúc này.

_Danh sách này không đầy đủ_

***

## Nguồn

Sao chép:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (tracking_program)) [o] (https://www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https://www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https://protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Phê bình) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-objects-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -and) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-sue-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-go Government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/osystem-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.facebook.com/ cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- tuyên bố-thay-mặt-5-triệu-người-dùng-iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https:// arstechnica .com / Information-technology / 2014/01 / what-google-can-really-do-with-nest-or-really-nests-data /) [i] (https://www.cbsnews.com/news/google-education -spies-on-collects-data-on-million-of-kids-alleges-sue-new-mexico-attorney-general /) [v] (https://www.nationalreview.com/2018/04/the- student-data-mining-scandal-under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https:// www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did -have-something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Những nguồn khác:

[Liên minh năm mắt] (https://en.wikipedia.org/wiki/Five_Eyes) [Mười chín tám mươi tư] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Tải xuống liên kết

[Tải xuống Firefox] (https://www.mozilla.org/en-US/firefox/new/) [Tải trình duyệt Tor] (https://www.torproject.org/download/) [Khác / không khả dụng] (https : //www.example.com)

***

## Trải nghiệm degoogling của tôi

Cuối cùng, tôi đã bắt đầu thấy các vấn đề với công nghệ lớn vào năm 2018 và tôi bắt đầu gỡ bỏ. Trong vài tháng đầu tiên, tôi đã tiến bộ đáng kể. Nó chậm lại vô cùng kể từ đó.


### Những gì tôi đã chuyển từ

Google Chrome -> Firefox / Tor

Google Tìm kiếm -> DuckDuckGo (mặc định) / Ecosia (khi tôi cảm thấy thích) / Bing (hiếm khi)

GMail - ProtonMail (chưa được chuyển đổi hoàn toàn)

Google Sites -> Tự lưu trữ (chưa được chuyển đổi hoàn toàn)

Google+ -> Hầu như chưa từng được sử dụng, đã tự xóa do ngừng hoạt động

Google Documents -> Chưa bao giờ được sử dụng, tôi chỉ sử dụng Microsoft Word 2013 (trước năm 2019) và LibreOffice (2019 trở đi).

Google Trang tính -> Chưa bao giờ được sử dụng, tôi chỉ sử dụng Microsoft Excel 2013 (trước năm 2019) và LibreOffice (2019 trở đi).

Google Trang trình bày -> Chưa bao giờ được sử dụng, tôi chỉ sử dụng Microsoft PowerPoint 2013 (trước 2019) và LibreOffice (2019 trở đi).

Google Bản vẽ -> Chưa bao giờ được sử dụng, thay vào đó tôi chỉ sử dụng LibreOffice (2019 trở đi).

Gerrit -> Chưa bao giờ sử dụng, tôi chỉ sử dụng GitHub (mặc định hiện tại), GitLab, BitBucket và SourceForge để thay thế.

Google Photos -> Chưa bao giờ được sử dụng

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-nay)

Google Maps -> OpenStreetMaps / Apple Maps

Go - Tạo một ngoại lệ đặc biệt, nhưng không sử dụng làm ngôn ngữ lập trình chức năng

Dart - Tạo một ngoại lệ đặc biệt, nhưng không sử dụng làm ngôn ngữ lập trình chức năng

Flutter - Tạo một ngoại lệ đặc biệt, nhưng không sử dụng làm ngôn ngữ lập trình chức năng

Google Earth -> OpenStreetMaps / Apple Maps

Chế độ xem phố của Google -> Chưa bao giờ được sử dụng, tôi thấy nó cực kỳ rùng rợn

Google Fi -> Chưa bao giờ được sử dụng

Lịch Google -> Chưa bao giờ được sử dụng

Máy tính của Google -> Theo nghĩa đen là bất kỳ ứng dụng máy tính nào khác, ngay cả một thiết bị đầu cuối Linux đang chạy ở chế độ Python nếu tôi cảm thấy thích nó

Google Nest -> Chưa bao giờ được sử dụng

Google AMP -> Chưa bao giờ được sử dụng

Google VPN -> Chưa bao giờ được sử dụng, cũng là một oxymoron

Google Pay -> Chưa bao giờ sử dụng

Google Summer of Code -> Chưa bao giờ tham gia

Tenor -> Các trang GIF khác, mặc dù GIF không quá quan trọng đối với tôi. Tôi thường nhận các tệp GIF từ hình ảnh DuckDuckGo, Imgur, Reddit hoặc các trang web khác.

Blockly -> Không dùng nữa, không chắc chắn là Scratch có chạy trực tiếp block hay không. Tôi đã trở thành một lập trình viên chức năng vào năm 2017 trở đi, và phát triển từ Scratch.

GBoard -> Được sử dụng một lần, nhưng bị bỏ rơi

Google Glass -> Chưa bao giờ sử dụng, được coi là trẻ nhỏ nhưng quyết định không mua / sử dụng một cái nếu tôi có tùy chọn

_Danh sách có thể không đầy đủ._

### Các sản phẩm tôi vẫn chưa thể mua được

Kể từ ngày 25 tháng 2 năm 2021, đây là những sản phẩm của Google ngăn tôi gỡ bỏ hoàn toàn:

1. YouTube

2. Android

3. Cửa hàng Google Play

4. Gmail (chỉ dành cho trường học và một số trang web)

5. Google Lớp học (chỉ dành cho trường học)

6. Google Dịch

7. Tài khoản Google

8. Google Sites (vì Google đang vi phạm luật của GDPR (và có thể phải đối mặt với khoản tiền phạt € 5.000.000,00 khác cho đến khi chúng được khắc phục) và cấm tải xuống sản phẩm này)

Tôi đã gỡ bỏ mọi thứ khác.

***

## Đi là xấu

Google đã thử nghiệm ngôn ngữ lập trình dựa trên Tác nhân năm 2003 `` Go! '' Với ngôn ngữ lập trình `Go 'của họ (từ năm 2009, 6 năm sau) và tuyên bố rằng ngôn ngữ của họ hoàn toàn không ảnh hưởng đến ngôn ngữ khác. Google đã bị chỉ trích nặng nề vì điều này, vì phương châm `` Đừng xấu xa '' của họ vẫn còn hoạt động vào thời điểm đó và đây là một trong nhiều sự cố khiến Phương châm không xấu xa bị loại bỏ.

Cuối cùng, sự phát triển của `` Go! '' Đã ngừng phát triển, trong khi `` Go` ngày càng trở nên phổ biến hơn. Google tuyên bố họ sẽ không bỏ qua `` Go! '' Nhưng cuối cùng, họ đã làm vậy và họ đã bỏ qua nó (kể từ ngày 9 tháng 4 năm 2021)

[Đọc thêm về cờ vây và cách thay thế tại đây] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Sử dụng DRM

Google sử dụng DRM (Quản lý các hạn chế kỹ thuật số) thông qua "dịch vụ" WideVine DRM của họ và các hình thức khác. Mục tiêu của DRM là phá hủy mạng Internet mở và trao cho các công ty quyền độc quyền đối với người dùng. Bạn nên loại bỏ WideVine hoàn toàn, bất kể giá nào.

[Đọc thêm về WideVine và các vấn đề của nó tại đây] (https://github.com/Degoogle-your-life/Its-time-to-cut-WideVine-DRM)

***

## Quan niệm sai lầm phổ biến

Đây là danh sách một số quan niệm sai lầm phổ biến với các sản phẩm của Google.

### Google không phải là Internet

Tìm kiếm của Google / Google không phải là Internet, tìm kiếm của Google chỉ là một công cụ tìm kiếm, đại loại như cách không phải mọi trò chơi dành cho nền tảng Nintendo đều do Nintendo sản xuất, mà được Nintendo cấp phép, nhưng ở mức độ lớn hơn nhiều. Nếu tất cả các máy chủ của Googles bị phá hủy đồng thời ngay bây giờ, chỉ các Trang web của Google như YouTube, Gmail, Google Tài liệu, Google tìm kiếm, v.v. sẽ không còn nữa, nhưng phần lớn Internet vẫn ở đó (Wikipedia, Stackoverflow, GitHub, tất cả các trang web của Microsofts, NYTimes, Samsung, TikTok, v.v.) chúng có thể mất chức năng đăng nhập và phân tích của Google, nhưng chúng sẽ vẫn hoạt động (trừ khi chúng được lập trình kém và phụ thuộc trực tiếp vào Google)

***

## Internet Explorer 6 và Chrome

Google Chrome đang trở thành Internet Explorer mới 6. Khi Google Chrome ban đầu ra mắt, Firefox là trình duyệt thống trị và hầu hết đã giết chết thị phần của Internet Explorers (đã vượt qua 96% trước khi hàng triệu người chuyển sang Firefox và các trình duyệt khác) khi Google Chrome ra mắt, mọi người chuyển sang do tốc độ của nó và nó là do Google (vốn không được coi là xấu vào thời điểm đó, vì hầu hết các vấn đề về quyền riêng tư vẫn chưa được đưa ra ánh sáng) Google Chrome ban đầu tôn trọng các tiêu chuẩn web (đó là những gì Firefox đã làm đã giết chết 96% thị phần trình duyệt của Internet Explorers) tuy nhiên, khi thị phần của Google Chromes tăng lên, Google bắt đầu loại bỏ ngày càng nhiều tính năng, thêm nhiều phần mềm gián điệp và ngừng chấp nhận các tiêu chuẩn web, Google Chrome đã trở thành Internet Explorer 6 mới.

Vấn đề chính hiện nay là các trang web chỉ dành cho Chrome và sẽ không hoạt động trên các trình duyệt khác, vì các nhà phát triển của họ quyết định rằng họ không muốn 30-40% người dùng Internet khác không sử dụng Chrome sử dụng trang web của họ.

Ngay cả bản thân Google cũng đang làm cho các trang web của họ chỉ dành cho Chrome. Ví dụ: tìm kiếm của Google sẽ nhắc bạn tải xuống Chrome 3 lần cứ sau 10 giây nếu nó phát hiện bạn không sử dụng Google Chrome (ngay cả các trình duyệt dựa trên Chromium khác như Brave cũng bị ảnh hưởng) và các trang web như Google Earth không cho phép người dùng Firefox sử dụng trang web của họ (kể từ năm 2020) cộng với Google Dịch không hỗ trợ nhập liệu bằng giọng nói trên Firefox và các trình duyệt không phải của Google Chrome.

### Sự cố với Brave

Các trình duyệt khác dựa trên Chromium, chẳng hạn như Brave và Microsoft Edge không hoàn toàn không có phần mềm gián điệp của Google. Brave thường được phía sai của cộng đồng quyền riêng tư đề xuất, nhưng Brave vẫn là một vấn đề, vì nó sử dụng Chromium. Internet không nên chỉ bao gồm các trình duyệt Chromium, nên có nhiều sự lựa chọn. Dũng cảm là con đường sai lầm để đi.

[Đọc thêm về degoogling khỏi Google Chrome / Chromium tại đây] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Đọc thêm về cách hủy đăng ký khỏi ChromeOS / ChromiumOS (Chromebook / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) tại đây] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Gia hạn quyền riêng tư giả

Google đã cố gắng nói với thế giới rằng họ quan tâm đến quyền riêng tư, sau khi mọi chuyện đã quá muộn. Họ tiếp tục tuyên bố họ tôn trọng quyền riêng tư của người dùng, nhưng họ vẫn không khắc phục tất cả các vấn đề về quyền riêng tư của mình.

### Mã nguồn mở không thể là một phần

Mã nguồn mở không thể là một phần. Google là bằng chứng về điều này. Mọi bit và byte của mã nguồn phải được hiển thị công khai, thậm chí không được ẩn một phần 8 của byte.

Các dự án như Android và ChromeOS là một phần mã nguồn mở, nhưng chứa phần lớn các phần mềm gián điệp, độc quyền.

### Nghịch lý

Google VPN là một oxymoron. Google không quan tâm đến quyền riêng tư và Mạng riêng ảo (VPN) từ một công ty như họ sẽ là một trong những lựa chọn tồi tệ nhất có thể cho dịch vụ VPN.

***

## Phần trình bày tệ

Google không quan tâm đến hiệu suất của các sản phẩm của họ ít nhất là vào năm 2017, vì phần mềm đo điểm chuẩn cuối cùng của họ (Google Octane) đã ngừng hoạt động vào năm 2017.

***

## Quản lý dự án tồi

Google có một hệ thống quản lý dự án nội bộ rất tệ. Một số ví dụ phổ biến về các chương trình ngày càng bị hạ cấp bao gồm Google Duo và YouTube music (trước đây là Google Play Âm nhạc)

Trong hệ thống phát triển nội bộ của Google, 1 ứng dụng dẫn đến một ứng dụng khác có một nửa chức năng, sau đó ứng dụng gốc sẽ bị xóa. Một vài năm sau, một ứng dụng mới với 75% chức năng được tạo ra và sau đó ứng dụng có 50% chức năng bị xóa, tiếp theo là một ứng dụng mới với 87,5% chức năng được tạo, sau đó ứng dụng có 75% chức năng sẽ bị ngừng hoạt động. , và như thế.

***

## Kinh khủng hoặc không kiểm duyệt dịch vụ

YouTube là ví dụ phổ biến nhất trong thế giới kiểm duyệt tồi tạo ra nền tảng tồi tệ nhất tồn tại. Google dường như cũng không hiểu rằng YouTube không phải là YouTube dành cho trẻ em.

Đối với YouTube, nội dung ủng hộ Đức Quốc xã và Người theo chủ nghĩa cực đoan da trắng căm thù được phân phát cho người dùng nhằm mục đích có nhiều thời gian tương tác hơn và kiếm được nhiều tiền hơn. Google cũng đã thực hiện một sốnhững điều ngu ngốc trong sự kiểm duyệt của họ, chẳng hạn như phê duyệt một video Tình dục qua đường hậu môn của Cơ đốc nhân là nội dung `` dành cho trẻ em` trong khi đồng thời giới hạn độ tuổi của video. Cũng không quá hiếm khi thấy các quảng cáo khiêu dâm hoặc máu me xuất hiện ngay bên dưới video Baby Shark, cùng với nhiều nội dung `` dành cho trẻ em 'khác.

Người dùng YouTube thường xuyên phàn nàn về việc YouTube kiểm duyệt nội dung xấu (như các ví dụ được liệt kê ở trên) trong khi người dùng có thể xóa video của họ một cách ngẫu nhiên mà không có lý do gì mà không có khả năng bãi bỏ, cùng với việc người dùng bị trừng phạt vì bất kỳ hình thức chửi thề nào, ngay cả những trường hợp rất nhỏ như nói rằng người dùng `` tào lao`` thường so sánh YouTube với [Liên Xô] (https://en.wikipedia.org/wiki/Soviet_Union) vào thời Stalin, do những hình phạt bất bình đẳng này.

Vào năm 2021, Google thông báo rằng họ sẽ đặt quảng cáo trên tất cả các video, mặc dù video đó đã được demo (để Google kiếm tiền, nhưng người sáng tạo thì không), điều này không liên quan quá nhiều đến việc kiểm duyệt, nhưng điều quan trọng cần lưu ý.

YouTube được kiểm duyệt (mặc dù rất kém) nhưng dịch vụ quảng cáo của Google giúp họ kiếm được hầu hết tiền dường như có rất ít hoặc không được kiểm duyệt.

[Đọc thêm về các vấn đề kiểm duyệt YouTube và cách thay thế từ YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Quảng cáo cho Google Play được tạo từ các trang trại bot, bạn có thể biết được các tình huống quảng cáo giống nhau đang được hàng trăm công ty sử dụng với một số thay đổi nhỏ và không liên quan đến sản phẩm (ví dụ phổ biến: Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City và hàng nghìn người khác) cùng với xu hướng quảng cáo độc hại đang bùng nổ tuyên bố rằng người dùng có thể kiếm tiền bằng cách chơi trò chơi, nghe nhạc, v.v. PayPal đã không bình luận về điều này, nhưng rõ ràng đây là một trò lừa đảo, như thể bạn có thể làm hơn 10.000 đô la trong vòng chưa đầy 20 giây bằng cách chơi một trò chơi được đảm bảo, không ai sẽ làm việc và thay vào đó sẽ làm điều này, điều này là không thể và một doanh nghiệp không thể hoạt động như thế này. Trò lừa đảo rõ ràng này đã phát triển mạnh mẽ kể từ năm 2019 và giờ đây, các trang trại bot sản xuất các quảng cáo này đang chiến đấu với nhau trong các quảng cáo của chính họ.

Một số quảng cáo cũng rất dâm dục và cố gắng lôi kéo người dùng (phần lớn trong số họ là người dùng dưới 13 tuổi hoặc bot) nhấp vào thông qua thao tác tình dục.

Nhiều ứng dụng sử dụng bot và xem xét các sản phẩm của họ, vì vậy bất cứ khi nào nhận xét xấu được đưa ra, các tài khoản bot của con rối sẽ bắt đầu đăng đánh giá 5 sao và cố gắng phủ nhận lời chỉ trích của bạn. [Google cũng đang làm điều này] (# Astroturfing)

[Đọc thêm về các vấn đề với Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

Định nghĩa chung [(từ Wikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

``
Astroturfing là hoạt động che giấu các nhà tài trợ của một thông điệp hoặc tổ chức (ví dụ: chính trị, quảng cáo, tôn giáo hoặc quan hệ công chúng) để làm cho thông điệp đó xuất hiện và được những người tham gia cấp cơ sở ủng hộ. Đây là một hoạt động nhằm cung cấp cho các báo cáo hoặc tổ chức sự tin cậy bằng cách giữ lại thông tin về mối liên hệ tài chính của nguồn. Thuật ngữ astroturfing có nguồn gốc từ AstroTurf, một thương hiệu thảm tổng hợp được thiết kế giống với cỏ tự nhiên, như một cách chơi chữ "sân cỏ". Hàm ý đằng sau việc sử dụng thuật ngữ này là thay vì một nỗ lực cấp cơ sở "thực sự" hoặc "tự nhiên" đằng sau hoạt động được đề cập, có một sự hỗ trợ "giả" hoặc "nhân tạo".
``

Google có lịch sử về lướt ván buồm để khiến họ có vẻ như không làm điều gì xấu xa (trong quá trình này, lướt ván buồm là điều xấu xa), ví dụ: đăng bài chỉ trích Google trên một nền tảng như Twitter (mà họ có tài khoản) sẽ dẫn đến một số tài khoản đã tồn tại một thời gian nhưng chưa bao giờ đăng trước khi xuất hiện và tuyên bố rằng những gì bạn đã nói là sai, sau đó tuyên bố rằng Google là công ty tốt nhất, nhưng lại thực hiện theo cách mà hầu hết mọi người đều không thể nhận ra đây là bot. Mọi người.

***

## Các hoạt động kinh doanh bất hợp pháp và phi đạo đức

Google sử dụng các hoạt động kinh doanh bất hợp pháp và phi đạo đức để tiếp tục độc quyền của họ, chẳng hạn như sử dụng các thiên đường thuế, công việc thuê ngoài và tiếp tục thực hiện các hoạt động xâm phạm bất hợp pháp như một chi phí kinh doanh.

### Ở châu Âu

Châu Âu thường xuyên kiện Google, vụ kiện lớn nhất là chống lại hành vi bất hợp pháp trong Android, dẫn đến việc Google nhận được 5.000.000.000 € (tương đương với $ 5.947.083.703,68 vào ngày 9 tháng 4 năm 2021)

### Ở Bắc Mỹ

Hoa Kỳ vẫn chưa đưa ra số tiền phạt gần như đủ đối với Google, so với mức phạt € 5.000.000.000 €.

### Tranh cãi

Google không quan tâm đến một vấn đề cho đến khi nó tạo ra một cuộc tranh cãi, sau đó họ sẽ cố gắng khắc phục nó một cách tồi tệ, chỉ đủ để cuộc tranh cãi tạm thời qua đi và vấn đề sau đó trở nên tồi tệ hơn theo cấp số nhân cho đến khi nó tạo ra một cuộc tranh cãi khác, và chu kỳ tiếp tục. Đơn giản là họ không đủ quan tâm để làm bất cứ điều gì nghiêm trọng về nó.

***

## Google được tự động hóa

Như một company, Google chủ yếu là tự động, với ít sự kiểm duyệt hơn so với tự động hóa.

Một công ty không nên được tự động hóa hoàn toàn. Google là một ví dụ về điều này. Việc kiểm duyệt là rất kinh khủng khi chỉ được thực hiện bởi AI, YouTube là một ví dụ điển hình, ngay cả khi có thêm vài (hàng trăm, hoặc có thể cả nghìn) người kiểm duyệt trang web, nơi dường như tệ đến mức hầu hết họ phải điều trị khi làm việc.

***

## Android

Android thuộc sở hữu của Google. Một phần của Liên minh thiết bị cầm tay mở (chưa được mở kể từ Android) Android đã trở thành một điểm độc quyền khác của Google và rất khó thoát khỏi.

Android đã được báo cáo để điện thoại về nhà cho Google ít nhất 10 lần mỗi ngày và mặc dù là mã nguồn mở một phần, nó vẫn hoạt động như một phần mềm gián điệp.

Một số dự án đã được tạo để thay thế từ Android, nhưng yêu cầu root thiết bị của bạn. Điều này đơn giản là không thể thực hiện được nữa đối với các điện thoại Samsung cụ thể ở Hoa Kỳ, do Knox DRM. Các lựa chọn thay thế phổ biến cho Android bao gồm iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch và PiPhone (Pi Phone là thương hiệu điện thoại chạy các hệ thống Linux khác nhau trên thiết bị di động, chẳng hạn như Fedora, Ubuntu, Arch, v.v.)

[Xem nghiên cứu của tôi về cách sử dụng chức năng của máy ảo Android được gỡ bỏ] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Xem cách gỡ bỏ từ Android] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Hành động nhỏ để trợ giúp

Truyền bá nhận thức bằng mọi cách bạn có thể là điều quan trọng. Đối với tôi, tôi không chỉ thường xuyên nói về degoogling và viết bài, mà tôi còn có một thói quen nhỏ, đó là tôi trao giải thưởng Reddit miễn phí hàng ngày cho bài đăng được ghim trên r / degoogle để nâng cao nhận thức. Cho đến nay, tôi đã trao gần 30 giải thưởng cho bài đăng được ghim (tôi cũng đã dành 500 xu miễn phí của mình cho 10 giải thưởng cho bài đăng đó)

***

## Không đáng tin cậy

Google không thể được tin cậy và không bao giờ có thể tin cậy được nữa. Họ đã hoàn toàn đi từ "đừng ác" (họ luôn luôn xấu xa) để trở thành hoàn toàn xấu xa và không cố gắng che giấu điều đó.

***

## Những thứ khác cần kiểm tra

[Nghĩa địa của Google (killbygoogle.com) - danh sách được sắp xếp gồm hơn 224 sản phẩm mà Google đã loại bỏ] (https://killedbygoogle.com/)

> [Liên kết GitHub] (https://github.com/codyogden/killedbygoogle)

[Alphabet worker union - Liên minh công nhân mới tại Google với hơn 800 thành viên] (https://alphabetworkersunion.org/people/our-union/)

[Không muốn chia tay với quả trứng phục sinh khủng long? Trang web này đã bảo vệ bạn] (https://chromedino.com/)

Có những thay thế khác, chỉ cần tìm kiếm chúng.

***

Một số kiểm tra thực tế là cần thiết cho bài viết này

***

## Nộp thông tin

Loại tệp: `Markdown (* .md)`

Số dòng (bao gồm cả dòng trống và dòng trình biên dịch): `968 '

Phiên bản tệp: `` 6 (Chủ nhật, ngày 18 tháng 4 năm 2021 lúc 4:18 chiều) '

***

### Trạng thái phần mềm

Tất cả các tác phẩm của tôi là miễn phí một số hạn chế. DRM (** D ** igital ** R ** estrictions ** M ** anagement) không có trong bất kỳ tác phẩm nào của tôi.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Hình dán này được hỗ trợ bởi Tổ chức Phần mềm Miễn phí. Tôi không bao giờ có ý định đưa DRM vào các tác phẩm của mình.

Tôi đang sử dụng từ viết tắt "Digital Restrictions Management" thay vì "Digital Rights Management" được biết đến nhiều hơn vì cách giải quyết thông thường là sai, không có quyền nào với DRM. Cách viết "Digital Restrictions Management" chính xác hơn và được hỗ trợ bởi [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) và [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Phần này được sử dụng để nâng cao nhận thức về các vấn đề với DRM và cũng để phản đối nó. DRM bị lỗi do thiết kế và là mối đe dọa lớn đối với tất cả người dùng máy tính và quyền tự do phần mềm.

Tín dụng hình ảnh: [failedbydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Thông tin nhà tài trợ

! [SponsorButton.png] (SponsorButton.png) <- Đừng nhấp vào nút này, nó không hoạt động, nó chỉ là một hình ảnh. Nút thực ở đầu trang ở góc phải (<- L ** R ** ->)

Bạn có thể tài trợ cho dự án này nếu bạn thích, nhưng hãy nêu rõ bạn muốn quyên góp cho cái gì. [Xem số tiền bạn có thể đóng góp tại đây] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Bạn có thể xem thông tin nhà tài trợ khác [tại đây] (https://github.com/seanpm2001/Sponsor-info/)

Hãy thử nó ra! Nút nhà tài trợ nằm ngay bên cạnh nút xem / mở đồng hồ.

***

## Lịch sử tệp



 * Đã khởi động tệp

> * Đã thêm phần tiêu đề

> * Đã thêm chỉ mục

> * Đã thêm phần giới thiệu

> * Đã thêm phần Wiki

> * Đã thêm phần lịch sử phiên bản

> * Đã thêm phần vấn đề.

> * Đã thêm phần các vấn đề trước đây

> * Đã thêm phần yêu cầu kéo trong quá khứ

> * Đã thêm phần yêu cầu kéo hoạt động

> * Đã thêm phần cộng tác viên

> * Đã thêm phần đóng góp

> * Đã thêm phần about README

> * Đã thêm phần lịch sử phiên bản README

> * Đã thêm phần tài nguyên

> * Đã thêm phần trạng thái phần mềm, với nhãn dán và thông báo DRM miễn phí

> *Đã thêm phần thông tin nhà tài trợ

> * Không có thay đổi nào khác trong phiên bản 0.1

Phiên bản 1 (Thứ Sáu, ngày 19 tháng 2 năm 2021 lúc 5:20 chiều)

> Thay đổi:

> * Đã khởi động tệp

> * Đã thêm phần mô tả cơ bản

> * Đã thêm phần mô tả kho lưu trữ

> * Đã thêm danh sách bài báo, với 14 mục

>> * Đã thêm phần `bài viết liên quan`

>> * Đã thêm phần `xem thêm`

> * Đã thêm phần thông tin tệp

> * Đã thêm phần lịch sử tệp

> * Đã thêm chân trang

> * Không có thay đổi nào khác trong phiên bản 1

Phiên bản 2 (Thứ Sáu, ngày 19 tháng 2 năm 2021 lúc 5:26 chiều)

> Thay đổi:

> * Đã thêm phần trạng thái dịch

> * Đã thêm phần Những thứ khác để kiểm tra

> * Đã thêm phần bảo mật

> * Đã thêm một chỉ mục

> * Đã thêm tiểu mục trạng thái phần mềm

> * Đã thêm phần các chiến dịch chống Google khác

>> * Đã thêm tiểu mục không còn tồn tại

>> * Đã thêm tiểu mục đang diễn ra

> * Đã thêm phần nguồn

> * Đã thêm phần liên kết tải xuống

> * Đã cập nhật phần thông tin tệp

> * Đã cập nhật phần lịch sử tệp

> * Không có thay đổi nào khác trong phiên bản 2

Phiên bản 3 (Thứ 4, ngày 24 tháng 2 năm 2021 lúc 7:56 tối)

> Thay đổi:

> * Đã cập nhật chỉ mục

> * Đã tham chiếu đến biểu tượng degoogle và tổ chức GitHub mới

> * Đã thêm liên kết đến các bài viết mới hơn

> * Đã thêm phần chống đối số khác

>> * Đã thêm tiểu mục tiện lợi

>> * Đã thêm tiểu mục Tại sao thậm chí còn bận tâm

>> * Đã thêm tiểu mục khác

> * Đã cập nhật một số dữ liệu

> * Đã cập nhật phần thông tin tệp

> * Đã cập nhật phần lịch sử tệp

> * Không có thay đổi nào khác trong phiên bản 3

Phiên bản 4 (Thứ bảy, ngày 25 tháng 2 năm 2021 lúc 9:31 tối)

> Thay đổi:

> * Đã thêm liên kết đến 10 bài viết mới

> * Đã thêm một phần về trải nghiệm của tôi khi gỡ bỏ

> * Đã cập nhật chỉ mục

> * Đã cập nhật phần thông tin tệp

> * Đã cập nhật phần lịch sử tệp

> * Không có thay đổi nào khác trong phiên bản 4

Phiên bản 5 (Thứ sáu, ngày 9 tháng 4 năm 2021 lúc 6:02 chiều)

_ Gần đây, phong trào chống Google của tôi còn thiếu các bản cập nhật, tôi đang nỗ lực trở lại với phong trào này sau hơn 1 tháng gián đoạn._

> Thay đổi:

> * Đã cập nhật phần tiêu đề

> * Đã cập nhật chỉ mục

> * Đã cập nhật danh sách ngôn ngữ: liên kết cố định và thêm nhiều ngôn ngữ được hỗ trợ hơn

> * Đã cập nhật phần trạng thái bài viết, thêm 4 liên kết ngã ba

> * Đã cập nhật phần trạng thái phần mềm

> * Đã thêm phần Go is evil

> * Đã thêm phần Sử dụng DRM

> * Đã thêm phần Các quan niệm sai lầm phổ biến

>> * Đã thêm Google không phải là tiểu mục Internet

> * Đã thêm phần Internet Explorer 6 và Chrome

>> * Đã thêm vấn đề với tiểu mục Brave

> * Đã thêm loại bỏ quyền riêng tư Faux

> * Đã thêm Nguồn mở không thể là một phần phụ

> * Đã thêm tiểu mục Oxymoron

> * Đã thêm phần Hiệu suất kém

> * Đã thêm phần Quản lý dự án xấu

> * Đã thêm phần Kinh khủng hoặc không kiểm duyệt dịch vụ

> * Đã thêm phần Astroturfing

> * Đã thêm phần Thực hành kinh doanh bất hợp pháp và phi đạo đức

> * Đã thêm tiểu mục Ở Châu Âu

>> * Đã thêm tiểu mục Ở Bắc Mỹ

>> * Đã thêm tiểu mục Tranh cãi

> * Đã thêm phần Google là tự động

> * Đã thêm phần Android

> * Đã thêm phần Hành động nhỏ để trợ giúp

> * Đã thêm phần Không tin cậy

> * Đã thêm phần thông tin nhà tài trợ

> * Đã cập nhật phần chân trang

> * Đã cập nhật phần thông tin tệp

> * Đã cập nhật phần lịch sử tệp

> * Không có thay đổi nào khác trong phiên bản 5

Phiên bản 6 (Chủ nhật, ngày 18 tháng 4 năm 2021 lúc 4:18 chiều)

> Thay đổi:

> * Đã cập nhật chỉ mục

> * Đã thêm một mô tả tổng quan mới

> * Thông tin trạng thái bài viết cập nhật

> * Đã thêm một liên kết đến bài viết Google FLoC mới

> * Đã thêm một liên kết đến bài báo Wuest 3n Fuchs Degoogle và thông tin chung về nó

> * Đã cập nhật phần thông tin tệp

> * Đã cập nhật phần lịch sử tệp

> * Không có thay đổi nào khác trong phiên bản 6

Phiên bản 7 (Sắp có)

> Thay đổi:

> * Sắp có

> * Không có thay đổi nào khác trong phiên bản 7

Phiên bản 8 (Sắp có)

> Thay đổi:

> * Sắp có

> * Không có thay đổi nào khác trong phiên bản 8

Phiên bản 9 (Sắp có)

> Thay đổi:

> * Sắp có

> * Không có thay đổi nào khác trong phiên bản 9

Phiên bản 10 (Sắp có)

> Thay đổi:

> * Sắp có

> * Không có thay đổi nào khác trong phiên bản 10

Phiên bản 11 (Sắp có)

> Thay đổi:

> * Sắp có

> * Không có thay đổi nào khác trong phiên bản 11

Phiên bản 12 (Sắp có)

> Thay đổi:

> * Sắp có

> * Không có thay đổi nào khác trong phiên bản 12

***

## Chân trang

Bạn đã đến phần cuối của tệp này

([Quay lại đầu trang] (# Đầu trang) | [Quay lại GitHub] (https://github.com))

### EOF

***
