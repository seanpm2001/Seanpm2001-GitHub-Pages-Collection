***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Jiyana xwe degoogle bikin

Ev gotara degooglingê ya sereke ji bo agahdariya degooglingiya giştî û girêdana gotarên din e.

[Navnîşê wekî rêxistinek GitHub bibînin] (https://github.com/Degoogle-your-life)

***

_ Vê gotarê bi zimanek cûda bixwînin: _

** Zimanê heyî ev e: ** `Englishngilîzî (DY)` _ (dibe ku werger hewce be werin rast kirin ku Englishngilîzî li şûna zimanê rast were rastkirin) _

_🌐 Navnîşa zimanan_

** Bi rêzkirin: ** `A-Z`

[Vebijarkên Rêzkirinê çênabe] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanî | [am አማርኛ] (/. github / README_AM.md) Amharî | [ar عربى] (/.github/README_AR.md) Erebî | [hy Kurdî] (/. github / README_HY.md) Ermenî | [az Azərbaycan dili] (/. github / README_AZ.md) Azerî | [eu Euskara] (/. github /README_EU.md) Baskî | [Be Беларуская] (/. Github / README_BE.md) Belarusî | [bn বাংলা] (/. Github / README_BN.md) Bengalî | [bs Bosanski] (/. Github / README_BS.md) Bosnî | [bg български] (/. Github / README_BG.md) Bulgarî | [ca Català] (/. Github / README_CA.md) Katalanî | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Çînî (Hêsankirî) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Çînî (Kevneşopî) | [co Corsu] (/. Github / README_CO.md) Korsîkî | [hr Hrvatski] (/. Github / README_HR.md) Croatian | [cs čeština] (/. Github / README_CS .md) Çekî | [da dansk] (README_DA.md) Danîmarkî | [nl Nederlands] (/. github / README_ NL.md) Hollandî | [** en-us **ngilîzî **] (/. github / README.md) Englishngilîzî | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonî | [tl Pîlîpînî] (/. github / README_TL.md) Filîpînî | [fi Suomalainen] (/. github / README_FI.md) Fînî | [fr français] (/. github / README_FR.md) Fransî | [frysk] (/. github / README_FY.md) frîsî | [gl Galego] (/. github / README_GL.md) Galîkî | [ka Kurd] (/. github / README_KA) Gurcî | [de Deutsch] (/. github / README_DE.md) Almanî | [el Ελληνικά] (/. github / README_EL.md) Grekî | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Creole Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawayî | [ew] (/. github / README_HE.md) Hebrewbranî | [silav हिन्दी] (/. github / README_HI.md) Hindî | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Macarîstan | [islenska ye] (/. github / README_IS.md) Icelandiczlandî | [ig Igbo] (/. github / README_IG.md) Igbo | [id Indonesia Indonesia] (/. github / README_ID.md) Icelandiczlandî | [ga Gaeilge] (/. github / README_GA.md) îrlandî | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japonî | [jw Wong jawa] (/. github / README_JW.md) Javayî | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kanada | [kk Қазақ] (/. github / README_KK.md) Kazakî | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-başûr 韓國 語] (/. github / README_KO_SOUTH.md) Koreyî (Başûr) | [ko-bakûr 문화어] (README_KO_NORTH.md) Koreyî (Bakur) (H YN NN WERGERAND) | [ku Kurdî] (/. github / README_KU.md) Kurdî (Kurmancî) | [ky Keys] (/. github / README_KY.md) Kirgizîstan | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latînî] (/. github / README_LA.md) Latînî | [lt Lietuvis] (/. github / README_LT.md) Lîtvanî | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksembûrg | [mk Македонски] (/. github / README_MK.md) Makedonî | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Melayu Bahasa] (/. github / README_MS.md) Malayî | [ml മലയാളം] (/. github / README_ML.md) Malayî | [mt Malti] (/. github / README_MT.md) Maltese | [mi Maorî] (/. github / README_MI.md) Maorî | [mr मराठी] (/. github / README_MR.md) Maratî | [mn Mongol] (/. github / README_MN.md) Mongolî | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Burmese) | [ne नेपाली] (/. github / README_NE.md) Nepalî | [no norsk] (/. github / README_NO.md) Norwêcî | [an ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Paştî | [fa فارسی] (/. github / README_FA.md) | Farisî [pl polski] (/. github / README_PL.md) Polonî | [pt português] (/. github / README_PT.md) Portekîzî | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Pencabî | Zimanên ku bi herfa Q | dest pê dikin tune [ro Română] (/. github / README_RO.md) Romanî | [ru руский] (/. github / README_RU.md) Rûsî | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scottish Gaelic | [sr Српски] (/. github / README_SR.md) Sirbî | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindî | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovakî | [sl Slovenščina] (/. github / README_SL.md) Slovenî | [so Soomaali] (/. github / README_SO.md) Somalî | [[es en español] (/. github / README_ES.md) Spanishspanî | [su Sundanis] (/. github / README_SU.md) Sundanî | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) swêdî | [tg Тоҷикӣ] (/. github / README_TG.md) Tacîkî | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Tirkî | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukranî | [ur اردو] (/. github / README_UR.md) urdû | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Viyetnamî | [cy Cymraeg] (/. github / README_CY.md) Welşî | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Di 110 zimanan de heye (108 dema ku whenngilîzî û Koreya Bakur nayê hesibandin, ji ber ku Koreya Bakur hîn nehatiye wergerandin [Li ser vê yekê bixwînin] (/ OldVersions / Koreyî (Bakur ) /README.md))

Wergerên bi zimanên din ji bilî Englishngilîzî bi makîneyê têne wergerandin û hêj ne rast in. Ji 5-ê Sibata 2021.-an û vir ve tu xelet nehatine rast kirin. Ji kerema xwe xeletiyên wergerandinê ragihînin [li vir] (https://github.com/seanpm2001/Degoogle-your-life/issues/) rast bikin ku hûn rasterasta xwe ji çavkaniyan re hilanîn û rêber bikin , ji ber ku ez ji bilî Englishngilîzî bi zimanên din baş nizanim (ez di dawiya xwe de wergêrekî werdigirim) ji kerema xwe [wiktionary] (https://en.wiktionary.org) û çavkaniyên din di rapora xwe de bi nav bikin. Ku wiya neke dê encama redkirina rastkirina ku hatî weşandin encam bide.

Nîşe: ji ber hûrgelan bi şîrovekirina nîşankirinê ya GitHub (û hema hema her şiroveya tevnavkirina nîşana nîşankirinê) bi tikandina van lînkan dê we ber bi pelê veqetandî ve vegerîne ser rûpelek cûda ku ne rûpelê profîla min a GitHub e. Hûn ê werin veguhastin [embara] seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), ku README lê tê mêvan kirin.

Werger ji hêla Google Translate ve têne kirin ji ber ku ji zimanên ku di karûbarên wergêra yên din ên mîna DeepL û Bing Translate de ji min re hewce ne hewceyê piştgiriyê ne ji bo zimanên ku ez hewce dikim (ji bo kampanyayek dij-Google xweşik îronîk e) Ez li ser dîtina alternatîfek dixebitim. Ji ber hin sedeman, formatkirin (girêdan, dabeşker, qelew, pît, û hwd.) Di wergerandinên cûrbecûr de tevlihev dibe. Çareserkirin westiyayî ye, û ez nizanim çawa van mijaran di zimanên bi tîpên ne-latînî de sererast bikim, û ji zimanên rastê çepê (mîna Erebî) ji bo sererastkirina van pirsgirêkan arîkariyek zêde hewce ye

Ji ber pirsgirêkên parastinê, gelek werger mêjû ne û guhertoyek kevn a vê pelê gotara `README` bikar tînin. Wergêr pêdivî ye. Di heman demê de, ji 9-ê Nîsana 2021-an, ew ê demekê bikişîne da ku ez hemî girêdanên nû bixebitînim.

***

## Indexndeks

[00.0 - Sernav] (# Degoogling --- Degoogle-your-life)

> [00.1 - Endeks] (# Endeks)

[01.0 - Danasîna bingehîn] (# Binavkirina bingehîn)

> [01.1 - Sernavê depoyê] (# Degoogle-your-life)

> [01.2 - Nerîna Danasîna Wuest3NFuchs] (# Dîtin-ji-Wuest3nFuchs)

>> [01.2.1 - Wateya wê çi ye?] (# Wateya wê çi ye - bi-Wuest3nFuchs)

>> [01.2.2 - Çima Degoogle?] (# Çima-Degoogle - ji hêla-Wuest3nFuchs)

[02.0 - Gotar] (# Gotar)

[03.0 - Taybetmendî] (# Taybetmendî)

[04.0 - Kampanyayên dij-Google ên din] (# Kampanyayên din-dijî-Google)

> [04.0.1 - Bişkojk] (# Bêbandor)

> [04.0.2 - Berdewam] (# Berdewam)

[05.0 - Li dijî argumentên din] (# Countering-other-argumentên)

> [05.0.1 - Kêrhatî] (# Kêrhatî)

> [05.0.2 - Çima girîng e? Bi her awayî pir dereng e] (# Çima-ew-girîng-dibe, -ewê-pir-dereng-her-dem)

> [05.0.3 - Yên din] (# Yên din)

[06.0 - Çavkanî] (# Çavkanî)

[07.0 - Zencîreyên dakêşandinê] (# Girêdanên dakêşanê)

[08.0 - Tecrubeya min a degoogling] (# Tecrubeya min-degoogling)

> [08.1 - Tiştê ku ez jê vedigerim] (# Tiştê-ya-ez-ji-veguhiştim)

> [08.2 - Berhemên ku ez hîn jî nikarim ji wan dûr bigerim] (# Berhemên-Ez-hê jî-nikarim-ji-birevim)

[09.0 - Tiştên din ên ku werin kontrol kirin] (# Other-things-to-check-out)

[10.0 - Agahdariya Pelê] (# Pel-agahî)

> [10.1 - Rewşa nermalavê] (# Status-nermalav)

> [10.2 - Agahdariya sponsor] (# agahdariya sponsor)

[11.0 - Dîroka Dosyayê] (# Dîroka Dosyayê)

[12.0 - Footer] (# Footer)

***

## Danasîna bingehîn

[Ji Wîkîpediya: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

Tevgera DeGoogle (wekî tevgera de-Google jî tê gotin) kampanyayek bingehîn e ku derket holê ku çalakvanên nepenîtiyê ji bikarhêneran dixwazin ku ji ber zêdebûna fikarên nepenîtiyê yên di derbarê pargîdanî de hilberên Google-ê bi tevahî rawestînin. Têgeh wateya çalakiya rakirina Google-ê ji jiyana yekê ye. Ji ber ku zêdebûna pişka bazara mezin a înternetê ji bo pargîdaniyê di qadên dijîtal de hêza yekdestdar diafirîne, hejmarek zêde rojnamevan zehmetiya dîtina alternatîfên ji bo hilberên pargîdaniyê diyar kirin.

**Dîrok**

Di 2013 de, John Koetsier ji Venturebeat got ku tablet-based Android Kindle Fire ya Amazon "guhertoyek Android-ji-Google-ized" bû. Di 2014-an de John Simpson ji Nûçeyên DYE di derbarê "mafê ji bîr kirinê" de ji hêla Google û motorên lêgerînê yên din ve nivîsand. Di 2015 de, Derek Scally ji Irish Times gotarek nivîsand ku meriv çawa "Jiyana xwe ji-Google-bike." Di 2016 de Kris Carlon ji Android Desthilatê pêşniyar kir ku bikarhênerên CyanogenMod 14 dikarin têlefonên xwe "de-Google" bikin, ji ber ku CyanogenMod bêyî sepanên Google jî baş dixebite. Di 2018-an de Nick Lucchesi ji Inverse nivîsand ku ProtonMail çawa pêşve diçû ku "hûn dikarin jiyana xwe bi tevahî de-Google-fy bikin." Brendan Hesse ya Lifehacker li ser "devjêberdana ji Google" tutoriyek berfireh nivîsand. "Rojnamevan Gizmodo Kashmir Hill îdia dike ku wê civîn ji dest dane û bêyî bikaranîna Salnameya Google zehmetiyên rêxistinê çêdikin. Di 2019 de, Huawei vegerand xwedan têlefonên li Filîpîn qedexe ye ku karûbarên ku ji hêla Google ve têne peyda kirin bikar bîne ji ber ku çend alternatîf hene ku tunebûna hilberên pargîdaniyê karanîna înterneta normal ne gengaz kir.

***

# Degoogle-jiyana-xwe
Depoyek ji bo agahdariya degooglingkirina giştî û girêdanên bi embarên degoogling ên min ên din.

***

## Overview ji hêla Wuest3nFuchs

Danasînek çêtir, ku ji hêla [Wuest3nFuchs] ve hatî peyda kirin (https://github.com/Wuest3nFuchs) - çavkanî: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Poldayî? by Wuest3nFuchs

Wateya degoogling ev e ku hûn tiştek ku ya Google-ê ye, ya ku ji hêla Google-ê ve hatî çêkirin bikar neynin. Ez qala motora lêgerîna wan, karûbarê nameya wan (Gmail), Youtube, û hwd dikim.

### Çima Degoogle? by Wuest3nFuchs

Google niha yek ji pargîdaniyên herî bihêz ên cîhanê ye. Wan gelek agahdarî li ser me hemiyan tomar kirine. Hin kes wê arguman bikin ku agahdariya me bi wan re ewledar e ji ber ku ew dizanin ka wê çawa biparêzin. Lê ev ne rast e. Google berê hate hundur kirin û ew ê di pêşerojê de jî bikeve. Dibe ku ne bi hin kiddie nivîsandinê be lê ew ê ji hêla dewletek netewe ve were kirin. Google agahdariya kesane li ser me hemiyan tomar dike ji ber ku bi vî rengî ew drav didin.

Ew e-nameyên me şeh dikin, tiştê ku em lê digerin dema ku em motora wan a lêgerînê bikar tînin, tomar dikin û kîjan vîdyoyan em li Youtube temaşe dikin. Bi vî rengî ew me dikin hedef û li ser me profîlek çêdikin ku li ser bingeha ku me bi hevalê xweyê çêtirîn re li ser axiviye hin reklamê nîşanî me bidin da ku ew ji bo tiştê ku ji me re lazim e reklamek nîşanî me bidin, lê ev pir dirinde ye. Bi saya birêz Snowden em êdî dizanin ku Google di bin bernameya bi navê ** "PRISM" ** de agahdariya kesane ya me bi NSA re parve kiriye.


Di pêşerojê de dê kesek bikaribe xwe bigihîne hemî agahiyan û ez ji we re piştrast dikim ku tiştek bi rastî xerab dê çêbibe. Ji bo ku pêşî lê bigire, divê hûn Degoogling-ê niha dest pê bikin. Her weha divê hûn hilberên pargîdaniyek ku daneyên we bi ** NSA ** re parve dike bikar neynin. Pêdivî ye ku hûn bi degooglêkirinê li hember vana hemî rawestin.

** Ger mirovên din karibin wê bikin, hûn jî dikarin wê bikin. **

[Li vir bêtir bixwînin] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Zencîreyek bi forkê ve naha di lîsteyê de nine, ji ber ku ez bi tevahî xwediyê vê depoyê ne, û dixwazim çavkaniyên din jî pêşve bibim. Ew ê xweperest be ku ez bi https://github.com/Degoogle-your-life/Degoogle-a xwe ve girêbidim! ->

***

## Gotarên

### Rewşa gotarê

_Hemû gotar naha xebatek li pêş in û pêdivî bi sererastkirinên mezin hene. Pêşniyar û sererastkirin destûr hene._

_Ji 18-ê Nîsana 2021-an di 4:09 danê êvarê de, pir gotar hêj nehatine dest pê kirin. Ez li ser dîtina dem û hewildana destpêkirina wan dixebitim._

[Çima divê hûn dev ji bikaranîna Google Chrome bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Bikaranîna ChromeBooks rawestînin] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Bikaranîna WideVine DRM rawestînin / Dem dema birrîna WideVine DRM ye] (https://github.com/seanpm2001/Its-time-to-cut-VideVine-DRM) <! - 3! ->

[Çima divê hûn dev ji karanîna ReCaptcha bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) -!! - 4! ->

[Alternatîf ji YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Googling Rawestînin, çima divê hûn Lêgerîna Google-ê rawestînin] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >>

[Çima divê hûn Gmail bikar neynin] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Çima divê hûn karanîna Android-ê rawestînin] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Çima divê hûn xwe ji Google Amp dûr bigirin] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Çima divê hûn dev ji Google Drive-ê bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive-stop) <! - 10! ->

[Çima divê hûn dev ji Nexşeyên Google û Google Earth berdin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Hey Google, bisekine] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Xwendina ji pirtûkên Google / Play rawestînin] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Bikaranîna Google Classroom-ê rawestînin] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Çima divê hûn dev ji Google Wergerê bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate- rawestînin) <! - 15! ->

[Çima hûn neçar in ku Hesabê Google-an bikar bînin] (https://github.com/seanpm2001/Hhy-you-should-sTop-Bikaranîna-Google-Accounts) <! - 16! ->

** Gotarên nû yên ku di nêzîk de werin nivîsandin: **

[Çima divê hûn dest bi karanîna Gerrit nekin] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Çima divê hûn dev ji karanîna Google Analytics berdin (depo ji Çarşemî, 24ê Sibatê 2021 di demjimêr 4:13 danê êvarê de li dawiya min e.) -Google-Analytics) <! - 18! ->

<! - Dabeşkerê kar! ->

[Çima divê hûn dev ji karanîna Google AdSense berdin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) - <! - 19! ->

[Çima divê hûn dev ji bikaranîna Google One berdin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) -!! - 20! ->

[Çima divê hûn dev ji bikaranîna Google+ berdin (betal nabe)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Çima divê hûn dev ji karanîna Google Play Store bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Çima divê hûn dest ji Google Docs bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Çima divê hûn dev ji Google Slides bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Çima divê hûn Berdên Google-ê rawestînin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Çima divê hûn Formên Google-ê rawestînin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Çima divê hûn dest ji Google Cardboard-ê bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Çima divê hûn peyamên Google bikar neynin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Çima divê hûn dev ji Bikaranîna Materyalê Google bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Çima divê hûn dev ji bikaranîna Glass / Glassên Google bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Çima divê hûn dev ji bikaranîna Google Fuchsia berdin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Çima divê hûn dev ji GBoard-ê bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) - <! - 32! ->

[Çima divê hûn dev ji Google Home-ê bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Çima divê hûn dev ji bikaranîna Google Nest bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Çima divê hûn dev ji bikaranîna Google Hangouts bernedin (betal kirin)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Çima divê hûn dev ji bikaranîna Google Duo berdin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Çima divê hûn dev ji bikaranîna Google Tensorflow berdin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Çima divê hûn dev ji bikaranîna Google Blockly bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) -step!)!! - 38! ->

[Çima divê hûn dev ji Google Flutter berdin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Çima divê hûn dev ji zimanê bernameya Googles Go bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Çima divê hûn dev ji zimanê bernameya Googles Dart bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Çima divê hûn dev ji karanîna wêneya Googles WebP berdin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Çima divê hûn dev ji formata vîdyoya Googles WebM bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Çima hûn neçar in ku Google Video-yê rawestînin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video))!! - 44! ->

[Çima divê hûn dev ji Malperên Google (klasîk) bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Çima pêdivî ye ku hûn Sîteyên Google-ê ("Nû") rawestînin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Çima divê hûn dev ji Google Pay berdin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Çima divê hûn karanîna Android Pay rawestînin] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Çima divê hûn dev ji bikaranîna Google VPN (oxymoron) bernedin]] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Çima divê hûn dev ji bikaranîna Google Photos berdin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos- rawestînin) <! - 50! ->

[Çima divê hûn bikaranîna Salnameya Google rawestînin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Çima divê hûn dev ji karanîna VirusTotal berdin (ji ber ku ew ji Septemberlona 2012 ve ji hêla Google ve tê xwedîkirin]) (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Çima divê hûn dev ji bikaranîna Google Fi berdin] (https://github.com/seanpm2001/Why-you-should-sekinîn-karanîna-Google-Fi) <! - 53! ->

[Çima divê hûn dev ji Google Stadia bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Çima divê hûn dev ji bikaranîna Google Keep bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) -!! - 55! ->

[Çima divê hûn dev ji Google Base berdin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Çima divê hûn dev ji beşdarî Havîna Koda Google-ê berdin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >>

[Çima divê hûn karanîna Kameraya Google rawestînin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Çima divê hûn dev ji karanîna Google Calculator bernedin (dibe ku extreme xuya bike, lê divê hûn ji her tiştî degoogle bikin, ku hûn jê biguherin pir hêsan e)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Hesabker) <! - 59! ->

[Çima divê hûn dev ji bikaranîna Google Survey + xelatan bernedin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Çima hûn neçar in ku Nexşeyên Google bikar bînin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Çima divê hûn dev ji karanîna Tenor bernedin (Malpera GIF, ku ji sala 2019 ve xwedan Google e)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[FLoC çi ye - Çima divê hûn ji pirsgirêka mezin Googles FLoCing dûr bisekinin (karanîna Google Chrome rawestînin)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Gotarên tevahî: ** `63`

** Gotar [nexşeya rê AB] (DegoogleCampaign_2021Roadmap_Part1.md) (heya 12-ê Adarê 2021) 2 rojên betal **

** Gotar [nexşeya rê BB] (DegoogleCampaign_2021Roadmao_Part2.md) (heya? 2021) 2 rojên betal **

Rewşa gotarê

Hemî gotar niha xebatek pêşve diçin û hewceyê sererastkirinên mezin in. Pêşniyar û sererastkirin destûr hene.

** Forks **

Torgiloka min a Degoogle-ê fireh dikin, û hinekî hêsanî gihiştinê, û hawara civakê zêde dikin.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Forked from: [https://github.com/wacko1805/Fossapps favor(https://github.com/wacko1805/Fossapps) (Englishngilîzî)

2. [Zencîreyên nepenîtiyê] (https://github.com/Degoogle-your-life/Privacy-links) | Forked from: [https://github.com/Arturro43/privacy-links favor(https://github.com/Arturro43/privacy-links) (Polonî)

3. [Taybetmendiya Dilşewat] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Forked from: [https://github.com/LinuxCafeFederation/Delightful-Privacy favor(https://github.com/LinuxCafeFederation/Delightful-Privacy) (Englishngilîzî)

4. [Blocklists] (https://github.com/Degoogle-your-life/blocklists) | Forked from: [https://github.com/jmdugan/blocklists ](https://github.com/jmdugan/blocklists) (Englishngilîzî)

5. [Degoogle, ji hêla Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Forked ji: [https://github.com/Wuest3nFuchs/Degoogle ](https://github.com/Wuest3nFuchs/Degoogle) (Englishngilîzî)

** Girêdayî **

[Lêkolîna Mezina Virtual a têlefonê Android-ê Degoogled] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

** Her weha bibînin: **

[Rexneya Google li Wikipedia] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[Google Graveyard (kuştinbygoogle.com) - navnîşek dabeşkirî ya 224+ hilberên ku Google kuştîye] (https://killedbygoogle.com/)

> [Girêdana GitHub] (https://github.com/codyogden/killedbygoogle)

[Sendîkaya karkerên alfabeyê - Sendîkaya karkerên nû li Google bi zêdeyî 800 endamên xwe] (https://alphabetworkersunion.org/people/our-union/)

[Ma hûn naxwazin ji hêka rojhilatê dînozorê par bibin? Vê malperê we nixamandiye] (https://chromedino.com/)

***

## Taybetmendî

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (Bernameya Çavdêriyê)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-y-privacy-your//) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-heye-li-we-nepenîtiyê heye) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) Counsludes(https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / têketin / çima-googles-sîxurî-bikar-b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he daneya alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument # Rexne) [b] (https://spreadprivacy.com/thre-reasons-why-the-nothing-to-hide-ar-ument-is-flawed/) [a] (https://eduzaurus.com/free -vekirina-nimûneyan / tiştek-ku-ve-veşêrin-nîqaş-tune-tiştek-ku-bêje /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- ya-dane-di derheqê-hûn-de-hûn dikarin-bibînin-û-jê-bikin-ew-aniha /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -bi-daneyên-kesane-te-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-y---data-heres-how-company-shareses- -monetizes dike-û) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / hemî-daneyên-facebook-google-li-we-nepenîtiyê heye) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- berhevkirin-eşkerekirin.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ tenduristî-fîtnes-dane-nepenî /) [h] (https://www.pcmag.com/news/google-sued-ov Er-zarok-kromebookên-li-perwerdehiyê-berhevkirina-daneyê] [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-government-google-data-berhevkirina-doz-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)rejnews((https://en.wikipedia.org/wiki/2018_Google_data_breach))mml(https://moz.com /blog/ Where-does-google-draw-the-data-collection-line))e [] https://mashable.com/article/google-android-data-collection-study/)-] naveroka] [https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)rejnewso(https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -ji-navê-5-m îdîa dike bikarhênerên ilyon-iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-y-y-phone-isnt-in-use/ [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) برگزirin(https://arstechnica.com/inform-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/) Navendên pêşniyar kirin(https://www.cbsnews.com/news/google-education-spies-on-collects- dane-li-bi-mîlyonan-zarok-doz-dozên-nû-mexico-parêzerê-giştî /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -di-bin-pozên me de /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / teknolojî / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-here-to-hide-40689565c550) [.] (https : //medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Ez dikarim bi delîlên vê yekê her û her berdewam bikim, lê dîtin û derbaskirina van vana pir dirêj dom kir gotar)

Taybetmendiya li ser hilberên Google her dem xirab e, ji ber ku hemî hilberên Google ên ku spyware vedigirin.

Hûn çi bikin jî, gava ku hûn Google-ê bikar tînin, hemî daneyên kesane yên weyên hesas ji Google û yên din re têne şandin. Di heman demê de Google hatiye dîtin ku di nav bernameyên vekirî de derbas dibe. Mînakî, ji ezmûna kesane (li ser Firefox) ku teberek YouTube-ê vekiriye ku ez neçûm serdana wê, min gelek vîdyoyên offline (VLC Media Player) temaşe kir. Piştre gava ku ez çûm pêşniyaran kontrol dikim, ew hema hema her tiştê ku min temaşe kiribû bû. Bê guman ew li ser bernameyên din jî casûsiyê dikin.

Di Chrome (û gelek rûgerên din) de modek nenas heye. Di Chrome-ê de, ev mod bêwate ye, ji ber ku Google dê hîn jî daneyên we bide min. Hergê hûn mînekirin / şopandina daneyê vegerînin, û nîşana "şopandinê neke" bikarbînin, surprîzek surprîz, Google hîn jî daneyên we mîn dike.

Heke hûn difikirin ku tiştek we tune ku hûn veşêrin, ** hûn bi tevahî xelet in **. Ev nîqaş gelek caran hate pûç kirin:

[Bi Wîkîpediya] (https://en.wikipedia.org/wiki/Tiştek_ji_vekirina_argument# rexne)

1. Edward Snowden got "Nîqaşkirina ku hûn ji mafê nepenîtiyê nafikirin ji ber ku tiştek we tune ku hûn veşêrin ji gotina ku hûn ji axaftina azad re naxwazin ji ber ku we tiştek tune ku bibêjin ne cuda ye." Gava ku hûn dibêjin, ' Tiştek min tune ku ez veşêrim, 'tu dibêjî,' Ez ji vî mafî nafikirim. 'Tu dibêjî,' vî mafê min tune, ji ber ku ez gihîştim nuqteya ku divê ez rastdar bikim ew. 'Awayê xebata mafan, hukûmet neçar ma ku destdirêjiya xwe ya nav mafên we bike. "

2. Daniel J. Solove di gotarek xwe de ji bo The Chronicle of Higher Perwerde diyar kir ku ew dijberiya argumanê dike; wî diyar kir ku hukûmetek dikare lea bikek agahî di derheqê kesekî de û zirarê dide wî mirovî, an jî agahdariya li ser kesek bikar tîne da ku destûra karûbarê înkar bike heke kesek rastî neheqiyê nebûbe, û ku hikûmetek dikare bi çêkirina xeletiyan ziyanê bigihîne jiyana kesane ya yekê. Solove nivîsand "Gava ku rasterast mijûl dibe, niqaşa tiştek ku were veşartin dikare bikeve bin daviyê, çimkî ew nîqaşê neçar dike ku li ser têgihiştina xweya teng a nepeniyê bisekine. Lê gava ku bi pirjimariya pirsgirêkên nepenîtiyê re têkildar be ku ji hêla berhevkirina daneyên hikûmetê ve girêdayî ye û ji çavdêriyê û bikar tîne eşkerekirin, nîqaşa ku tiştek neyê veşartin, di dawiyê de, tiştek tune ku bêje. "

3. Adam D. Moore, nivîskarê Mafên Nehfiyê: Bingehên Moralî û Hiqûqî, nîqaş kir, "ew nerîn e ku maf li hember lêçûn / sûd an nîqaşên celebîparêz ên bergirî ne. Li vir em nerîna ku berjewendiyên nepenîtiyê cûre ne red dikin. tiştên ku ji bo ewlehiyê dikarin werin bazirganîkirin. " Wî her weha diyar kir ku çavdêrî dikare li ser bingeha xuyangî, etnîsîte, zayendîtî û olî li ser hin komên civakê bêserûber bandor bike.

4. Bruce Schneier, pisporê ewlehiya komputerê û kriptograf, dijberiya xwe anî ziman, gotina Cardinal Richelieu "Ger yek şeş rêzên ku bi destê zilamê herî rast nivîsandî bide min, ez ê tiştek di wan de bibînim ku wî bidarve bikim", ji bo ku çawa hukûmetek eyalet dikare alîyan di jîyana kesek de bibîne da ku ew kes were darizandin an şantaj bike. Schneier her wiha got "Pir pir bi xeletî nîqaşê wekî 'ewlehî li hember nepenîtiyê' vedibêjin. Hilbijartina rastîn azadî li hember kontrolê ye. "

5. Harvey A. Silverglate texmîn kir ku kesê hevpar, navînî, bi nezanî rojê sê felonî li DY dike.

6. Emilio Mordini, fîlozof û psîkoanalîzm, digot ku nîqaşa "tiştek ku were veşartin" bi xwezayî paradoksal e. Ji bo ku "tiştek" veşêrin ne hewce ye ku mirov "tiştek veşêrin". Ya ku veşartî ne pêdivî ye têkildar e, îdîa dike Mordini. Di şûna wî de, ew nîqaş dike ku qadek nezîkî ya ku hem dikare were veşartin û hem jî sînorkirina gihîştinê pêdivî ye ji ber ku, ji hêla derûnî ve, em bi saya vedîtina ku em dikarin tiştek ji yên din re veşêrin dibin kes.

7. Julian Assange got "Hîn bersivek kuştî tune. Jacob Appelbaum (@ioerror) bersivek jêhatî ye, ji kesên ku vê dibêjin re dipirsin ku paşê wî têlefona xwe venebû û pantikên xwe bikişînin. Guhertoya min a wiya ye ku bêje, 'baş e, heke hûn ew qas bêzar in wê hingê divê em ne bi we re bipeyivin, û ne jî divê kesek din jî', lê bi felsefî, bersiva rast ev e: Çavdêriya girseyî guherînek pêkhatî ya girseyî ye. Dema ku civak xirab bibe, ew ê da ku tu bi xwe re bibî, heke tu kesê herî şermok ê li ser rûyê erdê bî. "

8. Ignacio Cofone, profesorê hiqûqê, dibêje ku nîqaş di warê xwe de çewt e ji ber ku, her ku mirov agahdariya pêwendîdar ji yên din re eşkere dike, ew jî agahdariya bêbandor eşkere dikin. Vê agahdariya bêserûber lêçûnên nepenîtiyê hene û dikare bibe sedema zirarên din, wekî cûdakariyê.

***

## Kampanyayên din ên dij-Google

Ev navnîşek kampanyayên dij-Google ên din ên berbiçav e. Ev navnîş ne temam e. Hûn dikarin bi firehkirina wê bibin alîkar.

### Hilweşîn

[Scroogled - Ji hêla Microsoft ve (Mijdar 2012 heya 2014)] (https://en.wikipedia.org/wiki/Scroogled)

_Nê gavê navnîşên din tune._

### Berdewam

_Ev lîste naha vala ye._

***

## Li dijî argumentên din

Hin nîqaş hene ku mirov ji bo rastdarîkirina Google dikin. Yek ji wanên yekem ên yekem jixwe hate xera kirin [li vir] (# Taybetmendî) lê li vir hinên din jî hene:

### Kêrhatî

Erê, hilberên Google hêsan xuya dikin. Lêbelê, hûn her tiştê ku ji bo hêsanî baş e, ewlehî, nepenî û pêbawerî bazirganî dikin. Google bi salan laltir dibe, û serveratên wan her ku diçin zêde dibin. Vêga, pêşkêşkerên Google mehê hema hema 1-2 demjimêran (bi taybetî YouTube)

Mixabin, ji ber baweriya civakan bi Google-ê, Google li thenternetê serdest e, û dixwaze bêtir û bêtir kontrol bike. Di 2012-an de, gava Google 5 hûrdeman daket, hate ragihandin ku ** gerdûnî ** seyrûsefera Internetnternetê **% 40 daket ** Google gelek caran 1-2 demjimêran dadikeve, û digel [şewitandina tîmê etîka wan] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) di nav tiştên din de, ew ê kêmtir û kêmtir hêsan bibin.

Kêrhatî her dem ne tiştek baş e. Pêdivî ye ku hûn hay ji tiştê ku diqewime hebe û dema ku ew diçin ji xwe re amade bin, ji ber ku çu carî nabe ku serverek her carê hilweşe.

Google jî wekî ku hûn difikirin ne hêsan e. Malperên din ên pir guncan ên din jî hene. Google ji hêsantir e, dema ku hûn ragirtin û bidawîbûna hesabê wanê bêhemdî bêyî bersivê dihesibînin (heya ku hûn têra xwe balê bikişînin ser hesabê twitter-a Google-ê an ji bo 100,000,000 $ an bêtir doz li wan neynin) wê hingê wan sûd ji we girtiye, we qelandiye, û mecbûr kir ku hûn qîrînek li balşikek deynin, ku çu kes qîrînên we nabihîzeji bo alîkariyê.

### Çima girîng e, her dem pir dereng e

Ev nîqaşek kêmtir hevpar e, lê ew hewceyê ravekirinê ye. Bi dewleta heyî re, piraniya hikûmetên cîhanê, digel çend pargîdaniyên bihêz dixuye ku bi her tevgera we dizanin, ji ber vê yekê çima hûn jî xwe jê dûr digirin? Bersiv hêsan e: ** hûn çêtir heq dikin **. Heke hûn di vê nuqteyê de karibin ji wan dûr bikevin, ji wan re dijwartir e ku hûn gavên we bêtir bişopînin, û hûn dikarin jiyanek nû ya bêtir taybet ava bikin.

[1 çavkanî] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Bi awayê, ez xelata xweya Reddit-a belaş didim vê posteyê her ku zêdetirî hefteyekê ye ku distînim naha (digel hemî 500 qozeyên minên belaş) ku vê mijarê hêj zêdetir zêde bikim. Heya nuha, min ev post şand ser 14 xelatên belaş. Ew ne pir e, lê tiştên piçûk dikarin bandorek mezin çêbikin, bi awayê ku ew tête pejirandin, û ji hêla kê ve girêdayî ye.

### Din

Vê gavê ti argumentên min ên din nînin.

_Ev lîste ne temam e_

***

## Çavkaniyên

Kopî:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (Bernameya Çavdêriyê)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-y-privacy-your//) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-heye-li-we-nepenîtiyê heye) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) Counsludes(https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / têketin / çima-googles-sîxurî-bikar-b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he daneyên alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Rexne) [b] (https://spreadprivacy.com/thre-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -mînak / tiştek-ku-ve-veşêrin-nîqaş-tune-tiştek-bêje /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-di derheqê-hûn-de-hûn dikarin-bibînin-û-jê-bikin-wê-an / / [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your- -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-y-bata-data-heres-how-company-shares-monetizes -û) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html))dd((https://www.reuters.com/article/us-alphabet- google-nepenîti-doz-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -bi-ser-li-zarokan-berhevkirina-danasîn-li-perwerdehiyê-krombotan) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)rejnewso((https://en.wikipedia.org/wiki/2018_Google_data_breach))mml(https:// moz.com/bl og / ku-google-ê-xeta-berhevkirina-rêzê-xêz dike) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / teknolojî / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- îdîa-li ser navê-5-mîlyon-bikarhênerên iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) pêşniyar dikin -fon-nayê-bikar anîn /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / agahdarîon-technology / 2014/01 / what-google-dikare-bi-hêlînê-an-bi rastî-hêlînê-bike-bike /] [ez] (https://www.cbsnews.com/news/google-education -sporên-li-berhev-dane-li-bi-mîlyonan-zarok-doz-doz-nû-mexico-parêzerê-giştî /) [v] (https://www.nationalreview.com/2018/04/the- Skandal-di-bin-çav-kirina-me-de-xwendekar-ê /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)rengêwerdan(https://medium.com/@hansdezwart/during-world-war-ii-we-idid -biç-tiştek-ve-veşêrin-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Çavkaniyên din:

[Hevpeymaniya Pênc çavan] (https://en.wikipedia.org/wiki/Five_Eyes) [Nehdeh û heştê û çar] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Zencîreyan dakêşin

[Firefox-ê bigirin] (https://www.mozilla.org/en-US/firefox/new/) [Geroka Tor bigirin] (https://www.torproject.org/download/) [Yên din / nediyar] (https : //www.example.com)

***

## Tecrubeya degoogling a min

Di dawiyê de min dest bi dîtina pirsgirêkên bi teknolojiya mezin a di 2018-an de kir, û min dest bi degooglîngê kir. Di çend mehên pêşîn de, min pêşveçûnek girîng çêkir. Ji hingî ve ew bêserûber hêdî bû.


### Tiştê ku min jê vekir

Google Chrome -> Firefox / Tor

Google Search -> DuckDuckGo (default) / Ecosia (gava ku ez jê hez dikim) / Bing (kêm caran)

GMail - ProtonMail (hîn bi tevahî nevekirî ye)

Malperên Google -> Xwe mêvandarî (hêj bi tevahî nehatiye guhertin)

Google+ -> Bi zor carî nayê bikar anîn, ji ber girtina xwe ya xwe xwe jêbir

Google Docs -> Qet nehatiye bikar anîn, ez li şûna wê Microsoft Word 2013 (berî 2019) û LibreOffice (2019-şûnda) bikar tînim.

Google Sheets -> Qet nayê bikar anîn, ez li şûna wê Microsoft Excel 2013 (berî 2019) û LibreOffice (2019-şûnda) bikar tînim.

Google Slides -> Qet nayê bikar anîn, ez li şûna wê Microsoft PowerPoint 2013 (berî 2019) û LibreOffice (2019-bihur) bikar tînim.

Nexşeyên Google -> Qet nayê bikar anîn, ez li şûna wê LibreOffice (2019-û pê ve) bikar tînim.

Gerrit -> Qet me bikar neaniye, ez li şûna wan tenê GitHub (default default), GitLab, BitBucket, û SourceForge bikar tînim.

Google Photos -> Qet nayê bikar anîn

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-aniha)

Google Maps -> OpenStreetMaps / Nexşeyên Sêvê

Biçe - Veqetandek taybetî çêbikin, lê wekî zimanê bernameyek fonksîyonel bikar naynin

Dart - Çêkirina veqetandek taybetî, lê ne wekî zimanê bernameyek fonksîyonel bikar tîne

Flutter - Çêkirina veqetandek taybetî, lê ne wekî zimanê bernameyek fonksiyonel bikar tîne

Google Earth -> OpenStreetMaps / Nexşeyên Sêvê

Google Streetview -> Qet nayên bikar anîn, ez wiya zêde xef dibînim

Google Fi -> Qet nayê bikar anîn

Salnameya Google -> Qet nayê bikar anîn

Google calculator -> Bi rastî her sepana hesabkerê din, heke ez jê hez bikim termînalek Linux-ê jî di moda Python de dixebite

Google Nest -> Qet nayê bikar anîn

Google AMP -> Qet nayê bikar anîn

Google VPN -> Qet nayê bikar anîn, di heman demê de oxymoron

Google Pay -> Qet nayê bikar anîn

Havîna Koda Google -> Qet beşdar nebû

Tenor -> Malperên GIF-ên din, her çend GIF ji bo min zêde girîng nebin. Ez bi gelemperî pelên GIF ji wêneyên DuckDuckGo, Imgur, Reddit, an malperên din digirim.

Blockly -> useddî nayê bikar anîn, ne bawer e ku Scratch rasterast bi blokî dimeşe. Ez di 2017-an de bûm bernamegerekî fonksiyonel, û ji Scratch mezin bûm.

GBoard -> Carekê tê bikar anîn, lê terikandin

Google Glass -> Qet nayên bikar anîn, wekî zarokek piçûk tête hesibandin lê biryar da ku yek / yek bikar neyne heke vebijarka min hebe

_List dibe ku ne temam be._

### Berhemên ku ez hîn jî nikarim ji wan dûr bikevim

Ji 25-ê Sibatê 2021-an ve, ev hilberên Google-ê ne ku min ji degooglkirina bi tevahî dûr digirin:

1. YouTube

2. Android

3. Google Play Store

4. GMail (tenê ji bo dibistan û hin malperan)

5. Klasa Google (tenê ji bo dibistanê)

6. Google Wergerê

7. Hesabê Google

8. Malperên Google (ji ber ku Google zagonên GDPR binpê dike (û dikare 5,000,000.00 € cezayê din jî bibîne heya ku ew sabît nekin) û dakêşanên vê hilberê qedexe dike)

Min ji her tiştê din degoogl kiriye.

***

## Here xirab e

Google bi zimanê xweyê bernameyê `Go` (ji 2009, 6 sal şûnda) li ser zimanê bernameyên` Go! `Bingeha Agent based 2003 geriya û îdîa kir ku zimanê wan dê bandorê li zimanê din neke. Google ji ber vê yekê bi tundî hate rexne kirin, ji ber ku dirûşma wan `Xirab meke 'hîn di wê demê de çalak bû, û ev yek ji wan gelek bûyeran e ku Motto xerab nekişand.

Di dawiyê de, geşepêdana `Go !` sekinî, dema ku` Go` bêtir û bêtir hevpar bû. Google îdîa kir ku ew ê neçin ser `Go !` lê di dawiyê de, wan kir, û ew jê dûr ketin (ji 9-ê Nîsana 2021-an)

[Li ser Go û awayê alternatîfbûnê li vir bêtir bixwînin] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Bikaranîna DRM

Google bi rêya "karûbarê" WideVine DRM û formên din DRM (Birêvebirina Qedexeyên Dîjîtal) bikar tîne. Armanca DRM ew e ku Internetnterneta vekirî tune bike û pargîdaniyan li ser bikarhêneran hêza yekdestdar bide. Mesrefa wê çi dibe bila bibe divê hûn bi tevahî ji WideVine xilas bibin.

[Li ser WideVine û pirsgirêkên wê li vir bêtir bixwînin] (https://github.com/Degoogle-your-life/Its-time-birrîn-WideVine-DRM)

***

## Baweriyên çewt ên hevpar

Ev navnîşek hin çewtiyên hevpar ên bi hilberên Google re ye.

### Google ne Internetnternet e

Google / Lêgerîna Google ne Internetnternet e, Lêgerîna Google-ê tenê motorek lêgerînê ye, celebek mîna çawa her lîstikek ji bo platformek Nintendo ji hêla Nintendo ve nayê çêkirin, lê ji hêla Nintendo ve hatî destûrdayîn, lê pir zêde. Ger hemî servera Googles-ê niha bi hevdemî bêne hilweşandin, tenê Malperên Google-ê wekî YouTube, Gmail, Google Docs, lêgerîna Google, û hwd dê tune bibin, lê pirraniya Internetnternetê dê hîn jî hebe (Wikipedia, Stackoverflow, GitHub, hemî malperên Microsofts, NYTimes, Samsung, TikTok, û hwd.) dibe ku ew têketina-Google û karbidestiya analîtîk a xwe winda bikin, lê ew ê hîn jî fonksiyonel bin (heya ku ew nebaş hatibin bername kirin û rasterast li ser Google nebin)

***

## Internet Explorer 6 û Chrome

Google Chrome dibe Explorenternet Explorer-a nû 6. Gava ku Google Chrome di destpêkê de derket, Firefox geroka serdest bû, û dema ku Google Chrome Chrome-ê ji ber ku bi mîlyonan mirov neçûbûn ser Firefox-ê û gerokên din% 96% derbas kirî ji% 96 derbas kir) derket, mirov ji ber leza wê zivirî û ew ji hêla Google ve ye (ku wê demê ew xirab nedihat hesibandin, ji ber ku hîn pir mijarên nepenîtiyê derneket holê) Google Chrome di destpêkê de ji pîvanên tevnê re rêzdar bû (ku Firefox çi kir ku (ji% 96-ê bazarên gerokê Internetnternet Explorer kuştin)), lê digel ku Google Chromes-ê bazara rabû, Google-ê dest bi rakirina taybetmendiyên bêtir kir, spyware zêde kir, û pejirandina standardên tevnê rawestand, Google Chrome bûye Internetnterneta nû ya Explorer 6.

Pirsgirêka sereke ya nuha malperên ku tenê Chrome in, û dê li ser rûgerên din nexebitin, ji ber ku pêşdebirên wan biryar da ku ew naxwazin 30-40% bikarhênerên din ên Internetnternetê yên ku Chrome bikar naynin malpera xwe bikar bînin.

Heya Google bixwe jî malperên xwe tenê Chrome dike. Mînakî, lêgerîna Google-ê dê ji we bixwaze ku her 10 çirkeyan 3 carî dakêşîne heke ev bibîne ku hûn Google Chrome-ê bikar naynin (gerokên din ên bingeha Chromium-ê wekî Brave bandor dibin) û malperên mîna Google Earth nahêlin bikarhênerên Firefox malpera xwe bikar bînin (ji sala 2020-an ve) plus Google Translate piştgirî nade têketina deng li Firefox, û rûgerên din ên ne-Google Chrome.

### Pirsgirêka Brave

Gerokên din ên ku li ser bingeha Chromium têne damezirandin, wekî Brave û Microsoft Edge bi tevahî ji spywareya Google-ê ne azad in. Brave bi gelemperî ji hêla çewt a civaka nepenîtiyê ve tê pêşniyar kirin, lê Brave hîn jî pirsgirêkek e, ji ber ku ew Chromium bikar tîne. Pêdivî ye ku Internetnternet ji gerokên tenê Chromium pêk nayê, divê hilbijartinek cûrbecûr hebe. Brave riya çewt e ku meriv biçe.

[Li ser degooglinga ji Google Chrome / Chromium-ê li vir bêtir bixwînin] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Li ser degooglingkirina ji ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) li vir bêtir bixwînin] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Nûkirina nepeniya Faux

Google hewl da ku ji cîhanê re bibêje ew ji nepenîtiyê xema wan in, piştî ku ew êdî pir dereng bû. Ew berdewam dikin ku ew ji nepenîtiya bikarhêner re rêzdar in, lê dîsa jî ew hemî pirsgirêkên nepenîtiya xwe sererast nakin.

### Çavkaniya vekirî nikare qismî be

Çavkaniya vekirî nikare qismî be. Google delîla vê yekê ye. Pêdivî ye ku her bit û bayt-a koda çavkaniyê ji raya giştî re xuya be, tewra 8-an bajarek jî neyê veşartin.

Projeyên mîna Android û ChromeOS bi qismî jêderka vekirî ne, lê pirraniya hêmanên xwedan, spyware vedigirin.

### Oxymoron

Google VPN oxymoron e. Google ji nepenîtiyê xemsar nabe, û Tora Taybet a Rastîn (VPN) ji pargîdaniyek mîna wan dê ji bo karûbarek VPN yek ji hilbijartinên gengaz ên herî xirab be.

***

## Performansa xirab

Google li ser performansa hilberên wan ne kêmî 2017 ne xema ye, ji ber ku nermalava wan a pîvanê ya dawîn (Google Octane) di 2017 de hate rawestandin.

***

## Rêveberiya projeya xirab

Google pergala pergala rêveberiya projeya navxweyî ya pir xirab heye. Hin nimûneyên hevpar ên bernameyên ku bêtir û bêtir hatine daxistin hene Google Duo û muzîka YouTube (berê Google Play Music)

Di pergala geşepêdana navxweyî ya Googles de, 1 sepandin dibe sedema sepana din a bi nîv karbidestî, hingê sepana orjînal tê jêbirin. Du sal şûnda, sepanek nû ya bi% 75 karîgerî kêmtir tê çêkirin, û dûv re sepana bi 50% karîgerî tê rakirin, li pey wê sepanek nû ya ku bi 87,5% fonksiyonel tê afirandin, dûv re jî sepana bi kêrhatîbûna% 75 tê qut kirin , wate ya vê çîye.

***

## Karûbarên tirsnak an tune

YouTube di cîhana moderatoriya xerab de mînaka herî hevpar e ku di hebûna xwe de platforma herî xirab çêdike. Google jî wusa nabîne ku YouTube ne zarokên YouTube in.

Ji bo YouTube, naveroka nefretparêz a pro-Nazî û Supremacîsta Spî ji bo bikarhêneran ji bo mebest ji dema tevlêbûnê û drav bêtir tête kirin. Google jî hin pir kiriyetiştên bêaqil di moderatoriya wan de, wekî pejirandina vîdyoyek Christian Anal Sex Sex wekî naverok `ji bo zarokan hatî çêkirin 'di heman demê de temen vîdyoyê bi sînor dike. Di heman demê de ne hindik e ku meriv bibîne ku reklamên pornografîk an gore di bin vîdyoya Baby Shark de, digel gelek naverokên `ji bo zarokan hatine çêkirin`, rast in.

Bikarhênerên YouTube-ê ji ber naveroka xirab a li ser YouTube-ê pir kêm gilî dikin (wekî mînakên li jor hatine rêz kirin) dema ku bikarhêner dikarin vîdyoyên xwe bê sedem û bêyî şiyana rakirina wan bêserûber werin jêbirin, digel ku bikarhêner ji ber her cûre sondxwarinê têne cezakirin, bûyerên pir hindik ên mîna bêje bikarhênerên `crap` bi gelemperî YouTube-ê bi [Yekîtiya Soviyetê] (https://en.wikipedia.org/wiki/Soviet_Union) re di serdema Stalîn de, ji ber van cezayên nehevsan, didin ber hev.

Di 2021-an de, Google ragihand ku ew ê li ser hemî vîdyoyan reklaman deynin, digel ku vîdyo tê demonîzekirin (ji ber ku Google drav dide, lê afirîner na) ev bi moderatoriyê re zêde têkildar nabe, lê girîng e ku were nişankirin.

YouTube moderator e (her çend pir kêm be jî) lê servîsa reklaman a Google-ê ya ku wan piraniya dravê wan dike dixuye ku hindik be jî moderatoriyek tune.

[Li ser pirsgirêkên moderatoriya YouTube û awayê ku hûn ji YouTube biguherin bêtir bixwînin] (https://github.com/seanpm2001/Alternating-from-YouTube)

Reklamên ji bo Google Play ji çandiniyên bot têne çêkirin, hûn dikarin ji hêla heman senaryoyên reklamê ve werin vegotin ku ji hêla bi sedan pargîdanî ve bi guhertinên piçûk ve têne bikar anîn, û têkiliyek bi hilberê re tune (nimûneyên gelemperî: Playrix (Malper, Gardenscapes) Fishdom, Mafia City, û bi hezaran zêdetir) digel pêşerojek xirab a reklamên ku îdîa dikin ku bikarhêner dikarin bi lîstin, guhdarî kirina muzîkê û hwd. drav qezenc bikin PayPal li ser vê yekê şîrove nekiriye, lê diyar e ku ev xapînok e, wekî ku hûn çêbikin li ser 10,000 $ di bin 20 saniye de bi lîstina lîstikek misogerkirî, dê kes nexebite û dê li şûna vê yekê bike, ku ne gengaz e, û karsaziyek nekare bi vî rengî bixebite. Ev scam eşkere ji sala 2019 ve xurt dibe, û naha cotgehên botên ku van reklaman çêdikin di reklamên xwe de bi hev re şer dikin.

Gelek reklaman jî pir rûreş in, û hewl didin ku bikarhêneran (pirraniya wan bikarhênerên di bin 13 saliyê de ne, an jî botî ne) bikişînin ser manipulasyona zayendî.

Pir sepan botan bikar tînin û hilberên xwe astroturf dikin, ji ber vê yekê her ku pêdaçûnek nebaş tê kirin, hesabên botê yên kulekên sockê dê dest bi şandina nirxandinên 5 stêrkî bikin û hewil bidin ku rexneya we pûç bikin. [Google bi xwe jî vê dike] (# Astroturfing)

[Li ser pirsgirêkên Google AdSense bêtir bixwînin] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

Danasîna giştî [(ji Wikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

""
Astroturf pratîka rûspîkirina sponsorên peyamek an rêxistinekê ye (mînakî, têkiliyên siyasî, reklamgerî, olî an giştî) da ku wiya xuya bike ku ew ji beşdaranên gelêrî pêk tê û piştgirî lê tê kirin. Ew pratîkek e ku armanc dike ku bi ragirtina agahdariya li ser pêwendiya darayî ya çavkaniyê pêbaweriyê bide daxuyaniyan an rêxistinan. Têgeha astroturfing ji AstroTurf, marqeyek xalîçeyên sentetîk ku ji bo dişibiya giya xwezayî hatî çêkirin, wekî lîstikek li ser peyva "gelî" hatîye stendin. Wateya li paş karanîna têgîn ev e ku li şûna hewildanek bingehîn a "rast" an "xwezayî" ya li pişt çalakiya tê pirsîn, xuyanga piştgiriyek "sexte" an "çêkirî" heye.
""

Google xwedan dîrokek astroturfing e ku ew xuya dike ku ew tiştek xirab nakin (di pêvajoyê de, astroturf xirab e) ji bo nimûne, şandina rexneya Google li ser platformek mîna Twitter (ku ew li ser wan hesabek heye) dê encam bide çend hesabên ku demek heye lê berî derketinê îdîa nakin ku ya ku we got derewîn e, û dûv re jî îdia dikin ku Google pargîdaniya çêtirîn e, lê bi rengek tête kirin ku ew ne diyar be ku ev bot ji pir gel.

***

## Karûbarên karsaziyê yên neqanûnî û bêehlaqî

Google pratîkên karsaziyê yên neqanûnî û bêehlaqî bikar tîne da ku yekdestdariya xwe pêşve bixe, wek mînak bihuştên bacê bikar tîne, karên derveyî çavkaniyê dide, û wekî lêçûnek kirina karsaziyê berdewam dike ku çalakiyên dagirkerî yên neqanûnî bike.

### Li Ewropa

Ewrûpa gelek caran doz li Google vekiriye, doza herî mezin li dijî tevgera neqanûnî ya di Android de ye, ku di encamê de Google 5,000,000,000 € (di heman demê de 5,947,083,703.68 $ di 9-ê Nîsana 2021-ê de drav)

### Li Amerîkaya Bakur

Dewletên Yekbûyî hema hema têr ceza nedaye Google, li gorî Europes 5,000,000,000 € ceza.

### Nakokî

Google ji pirsgirêkek re girîng nîn e heya ku ew gengeşiyekê biafirîne, wê hingê ew ê hewl bidin ku wê sererast bikin, tenê ji bo ku nakokî bi rengek demkî dûr bikeve, û pirsgirêk hingê bi rengek xirabtir dibe heya ku ew gengeşiyek din çêbike, û çerx berdewam dike. Ew bi tenê têr nakin ku tiştek giran li ser bikin.

***

## Google otomatîk e

Wekî company, Google bi piranî otomatîk e, ji otomasyonê kêmtir moderatorî heye.

Pêdivî ye ku pargîdaniyek bi tevahî otomatîkî nebe. Google mînakek vê yekê ye. Moderasyon gava ku tenê ji hêla AI-yê ve tê kirin tirsnak e, YouTube mînakek baş e, tevî ku çend kesên zêde (bi sedan, an jî dibe ku hezar) kes malperê moderator bikin, ku ew eşkere xerab e ku piraniya wan neçar in ku tedawî bibin dema ku dixebitin.

***

## Android

Android xwedan Google e. Beşek ji Hevpeymaniya Open Handset (ku ji Android-ê ve nehatiye vekirin) Android ji bo Google bûye xaleke din a yekdestdar, û revînek pir dijwar.

Android hate ragihandin ku her roj kêmî caran 10 caran bi têlefonê ji Google re tê malê, û tevî ku bi qismî jêderk vekirî ye jî, ew dîsa jî wekî spyware bi giranî tevdigere.

Gelek projeyên hatine afirandin ku ji Androidê diguherin, lê hewce dike ku cîhazê we root bike. Ev bi tenê ji ber Knox DRM êdî ji bo têlefonên taybetî yên Samsung ên li DYA ne gengaz e. Vebijarkên hevpar ên Android-ê iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch, û PiPhone (Pi Phone marqeyek têlefonan e ku pergalên cîhêreng ên Linux-ê li ser cîhaza mobîl, wekî Fedora, Ubuntu, Arch, û hwd.) Dimeşînin

[Li ser lêgerîna fonksîyonel a makîneya nîgaşî ya Android-a degoogledî binihêrin] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Bibînin ka meriv çawa ji Android-ê degoogle dike] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Çalakiyên piçûk ên alîkariyê

Bi her awayî hûn dikarin hişyariyê belav bikin girîng e. Ji bo min, ez ne tenê timûtim li ser degoogling diaxivim, û gotaran dinivîsim, lê di heman demê de adetek piçûk a piçûk jî heye, ku ez xelata xweya Reddit a belaş rojane didim ser postê pinned li r / degoogle da ku hişmendiyê zêde bikim. Heya nuha, min nêzîkê 30 xelat dane posta pînekirî (min ji bo wê postê 500 zîvên xweyên belaş jî li ser 10 xelatan xerc kir)

***

## Bêbawer

Bi Google nayê bawer kirin, û carek din jî nayê bawer kirin. Ew bi tevahî ji "xirab nebin" (ew her gav xerab bûn) derbas bûn ku tenê bi tevahî xerab bin û hewl nedin ku veşêrin.

***

## Tiştên din ên ku derketin

[Google Graveyard (kuştinbygoogle.com) - navnîşek dabeşkirî ya 224+ hilberên ku Google kuştîye] (https://killedbygoogle.com/)

> [Girêdana GitHub] (https://github.com/codyogden/killedbygoogle)

[Sendîkaya karkerên alfabeyê - Sendîkaya karkerên nû li Google bi zêdeyî 800 endamên xwe] (https://alphabetworkersunion.org/people/our-union/)

[Ma hûn naxwazin ji hêka rojhilatê dînozorê par bibin? Vê malperê we nixamandiye] (https://chromedino.com/)

Alternatîfên din hene, tenê li wan bigerin.

***

Ji bo vê gotarê hin kontrolkirina rastiyê hewce ye

***

## Agahdariya pelê

Pelê pelê: `Markdown (* .md)`

Hejmara rêzikan (xetên vala û rêza berhevkar jî tê de): `968`

Guhertoya pelê: `6 (Yekşem, Avrêl 18th 2021 li 4:18 danê êvarê)`

***

### Rewşa nermalavê

Hemî xebatên min belaş hin qedexe ne. DRM (** D ** igital ** R ** vegotin ** M ** tevger) di tu xebatên min de tune.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ev sticker ji hêla Weqfa Nermalava Azad ve tê piştgirî kirin. Ez qet naxwazim ku DRM têxim nav karên xwe.

Ez kurteya "Birêvebirina Qedexeyên Dîjîtal" li şûna ya ku bêtir tê zanîn "Birêvebiriya Mafên Dîjîtal" bikar tîne ji ber ku awayê hevpar ê xîtabê wê derew e, tu mafên DRM tune. Nivîsîna "Birêvebirina Qedexeyên Dîjîtal" rasttir e, û ji hêla [Richard M. Stallman (RMS)]] (https://en.wikipedia.org/wiki/Richard_Stallman) û [Weqfa Nermalava Azad (FSF)] ve tê piştgirî kirin () https://en.wikipedia.org/wiki/Found_Software_Foundation_Free)

Ev beş tête bikar anîn ku ji bo pirsgirêkên bi DRM re hişyar bikin, û her weha protesto bikin. DRM ji hêla sêwiranê ve kêmas e û ji bo hemî bikarhênerên computer û azadiya nermalavê xeterek mezin e.

Baweriya wêneyê: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Agahdariya sponsor

! [SponsorButton.png] (SponsorButton.png) <- Vê bişkokê bitikînin, ew naxebite, ew tenê wêneyek e. Bişkojka rastîn li jorê rûpelê li goşeyê rastê (<- L ** R ** ->) ye

Ger hûn bixwazin hûn dikarin sponsoriya vê projeyê bikin, lê ji kerema xwe tiştê ku hûn dixwazin bexş bikin diyar bikin. [Darayên ku hûn dikarin bexş bikin li vir bibînin] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Hûn dikarin agahdariyên sponsor ên din jî bibînin [li vir] (https://github.com/seanpm2001/Sponsor-info/)

Biceribînin! Bişkoka sponsor li tenişta bişkoja temaşekirinê / nehiştinê rast e.

***

## Dîroka pelê



 * Pelê dest pê kir

> * Beşa sernavê zêde kir

> * Sermaseyê zêde kir

> * Beşa derbarê zêde kir

> * Beşa Wiki-yê zêde kir

> * Beşa dîroka guhertoya zêde kir

> * Beşa pirsgirêkan zêde kir.

> * Beşa hejmarên borî zêde kir

> * Beşa daxwazên kişandina borî zêde kir

> * Beşa daxwazên kişandina çalak lê zêde kir

> * Beşa beşdaran zêde kir

> * Beşa tevkariyê zêde kir

> * Derheqê beşa README de zêde kir

> * Beşa dîroka guhertoya README zêde kir

> * Beşa çavkaniyan zêde kir

> * Beşa statûya nermalavê, bi diruşmeyek û peyamek belaş a DRM, lê zêde kir

> *Beşa agahdariya sponsor zêde kir

> * Di guhertoya 0.1 de guherînek din çênebû

Guhertoya 1 (Fridayn, Sibat 1921 2021 li 5:20 danê êvarê)

> Guherandin:

> * Pelê dest pê kir

> * Beşa ravekirina bingehîn zêde kir

> * Beşa ravekirina depoyê zêde kir

> * Navnîşa gotaran, bi 14 navnîşan ve zêde kir

>> * Beşa `gotarên têkildar` zêde kir

>> * Beşa `binihêrin` jî zêde kir

> * Beşa agahdariya pelê zêde kir

> * Beşa dîroka pelê lê zêde kir

> * Pêpelok zêde kir

> * Di guhertoya 1 de guhertinên din çênabin

Guhertoya 2 (Fridayn, Sibat 1921 2021 li 5:26 danê êvarê)

> Guherandin:

> * Beşa rewşa wergerandinê zêde kir

> * Tiştên din li beşa kontrolê zêde kir

> * Beşa nepenîtiyê zêde kir

> * Anndekeyek zêde kir

> * Dabeşa rewşa nermalavê zêde kir

> * Dabeşa kampanyayên dij-Google ên din jî zêde kir

>> * Binbeşa hilweşandî zêde kir

>> * Binbeşa domdar lê zêde kir

> * Beşa çavkaniyan zêde kir

> * Beşa girêdanên dakêşanê zêde kir

> * Beşa agahdariya pelê nûve kir

> * Beşa dîroka pelê nûve kir

> * Di guhertoya 2-an de guherînek din çênebû

Guhertoya 3 (Çarşemî, 24ê Sibatê 2021 li 7:56 danê êvarê)

> Guherandin:

> * Indeksa nû kir

> * Îkona degoogle û rêxistina nû ya GitHub referans kir

> * Zencîreyên gotarên nûtir zêde kirin

> * Beşa dijberên nîqaşên din zêde kir

>> * Binbeşa rehetiyê zêde kir

>> * Zencîreyê Çima jî aciz dike

>> * Dabeşa din zêde kir

> * Hin dane dane nûve kirin

> * Beşa agahdariya pelê nûve kir

> * Beşa dîroka pelê nûve kir

> * Di guhertoya 3-an de guherînek din çênebû

Guhertoya 4 (urdayemî, 25ê Sibatê 2021 li 9:31 danê êvarê)

> Guherandin:

> * Zencîreyên 10 gotarên nû zêde kirin

> * Di derbarê degooglîna ezmûna min de beşek zêde kir

> * Indeksa nû kir

> * Beşa agahdariya pelê nûve kir

> * Beşa dîroka pelê nûve kir

> * Di guhertoya 4-an de guherînek din çênebû

Guhertoya 5 (Fridayn, Nîsan 9th 2021 li 6:02 danê êvarê)

_Vê paşîn kêmasiya nûkirina tevgera dijî-Google ji min re heye, ez dixebitim ku piştî navberek 1+ meh vegerim wê._

> Guherandin:

> * Beşa sernavê nûve kir

> * Indeksa nû kir

> * Navnîşa ziman nûve kir: girêdanên sabît, û zimanên bêtir piştgirî lê zêde kirin

> * Beşa rewşa gotarê nûve kir, 4 girêdanên fork zêde kir

> * Beşa rewşa nermalavê nûve kir

> * Zêdekirin Go beşa xerab e

> * Bikaranîna beşa DRM zêde kir

> * Beşa ramanên çewt ên hevpar zêde kir

>> * Zêdekirî Google ne beşa Internetnternetê ye

> * Explorenternet Explorer 6 û beşa Chrome zêde kir

>> * Pirsgirêka bi beşê Brave zêde kir

> * Rakirina nepeniya Faux zêde kir

> * Çavkaniya vekirî zêde nabe bibe beşek qismî

> * Zencîreya Oxymoron zêde kir

> * Beşa performansa xirab zêde kir

> * Beşa rêveberiya projeya Xirab zêde kir

> * Dabeşa moderatoriya karûbarên Xedar an tune

> * Beşa Astroturfing zêde kir

> * Beşa pratîkên neqanûnî û ne ehlaqî lê zêde kir

> * Dabeşa Li Ewropa Zêde kir

>> * Binbeşa Li Amerîkaya Bakur zêde kir

>> * Dabeşa Pevçûnan zêde kir

> * Zêdekirin Google beşa otomatîk e

> * Beşa Android-ê zêde kir

> * Çalakiyên Piçûk ji bo alîkariyê zêde kirin

> * Beşa Bêbawer zêde kir

> * Beşa agahdariya sponsor zêde kir

> * Footer nûve kir

> * Beşa agahdariya pelê nûve kir

> * Beşa dîroka pelê nûve kir

> * Di guhertoya 5-an de guherînek din çênebû

Guhertoya 6 (Yekşem, Avrêl 18th 2021 li 4:18 danê êvarê)

> Guherandin:

> * Indeksa nû kir

> * Danasînek nêrînek nû lê zêde kir

> * Agahdariya rewşa gotarê nûve kir

> * Zencîreyek li gotara nû ya Google FLoC zêde kir

> * Zencîreyek li gotara Wuest 3n Fuchs Degoogle û agahdariya giştî ya li ser wê zêde kir

> * Beşa agahdariya pelê nûve kir

> * Beşa dîroka pelê nûve kir

> * Di guhertoya 6-an de tu guhertinek din tune

Guhertoya 7 (Di nêzîk de tê)

> Guherandin:

> * Zûtir tê

> * Di guhertoya 7-an de tu guherînek din tune

Guhertoya 8 (Di nêzîk de tê)

> Guherandin:

> * Zûtir tê

> * Di guhertoya 8-an de guherînek din çênebû

Guhertoya 9 (Di nêzîk de tê)

> Guherandin:

> * Zûtir tê

> * Di guhertoya 9-an de guherînek din çênebû

Guhertoya 10 (Di nêzîk de tê)

> Guherandin:

> * Zûtir tê

> * Di guhertoya 10-an de guherînek din çênebû

Guhertoya 11 (Di nêzîk de tê)

> Guherandin:

> * Zûtir tê

> * Di guhertoya 11-an de guherînek din çênebû

Guhertoya 12 (Di nêzîk de tê)

> Guherandin:

> * Zûtir tê

> * Di guhertoya 12-an de guherînek din çênebû

***

## Footer

Hûn gihîştine dawiya vê pelê

([Vegere jor] (# Top) | [Vegere GitHub] (https://github.com))

### EOF

***
