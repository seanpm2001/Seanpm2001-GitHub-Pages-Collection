***

！[DEGOOGLE1.jpeg]（DEGOOGLE1.jpeg）

＃Degoogling-あなたの人生をDegoogle

これは、一般的なデグーグル情報のメインのデグーグル記事であり、他の記事へのリンクです。

[GitHub組織としてリストを参照してください]（https://github.com/Degoogle-your-life）

***

_この記事を別の言語で読む：_

**現在の言語は次のとおりです：** `英語（米国）` _（正しい言語を置き換える英語を修正するには、翻訳を修正する必要がある場合があります）_

_🌐言語のリスト_

**並べ替え：** `A-Z`

[並べ替えオプションは利用できません]（https://github.com/Degoogle-your-Life）

（[af Afrikaans]（/。github / README_AF.md）Afrikaans | [sq Shqiptare]（/。github / README_SQ.md）アルバニア語| [amአርኛ]（/。github / README_AM.md）アルメニア語| [arعربى] （/.github/README_AR.md）アラビア語| [hyհայերեն]（/。github / README_HY.md）アルメニア語| [azAzərbaycandili]（/。github / README_AZ.md）アゼルバイジャニ| [eu Euskara]（/。github /README_EU.md）バスク語| [beБеларуская]（/。github / README_BE.md）ベラルーシ語| [bnবাংলা]（/。github / README_BN.md）ベンガリ語| [bsボスニア語]（/。github / README_BSボスニア語| [bgбългарски]（/。github / README_BG.md）ブルガリア語| [caCatalà]（/。github / README_CA.md）カタロニア語| [ceb Sugbuanon]（/。github / README_CEB.md）Cebuano | [ny Chichewa ]（/。github / README_NY.md）Chichewa | [zh-CN简体中文]（/。github / README_ZH-CN.md）中国語（簡略化）| [zh-t中國傳統的）]（/。github / README_ZH -T.md）中国語（従来）| [co Corsu]（/。github / README_CO.md）コルシカ語| [hr Hrvatski]（/。github / README_HR.md）クロアチア語| [csčeština]（/。github / README_CS .md）チェコ語| [da dansk]（README_DA.md）デンマーク語| [nl Nederlands]（/。github / README_ NL.md）オランダ語| [** en-us英語**]（/。github / README.md）英語| [EOエスペラント]（/。github / README_EO.md）エスペラント| [et Eestlane]（/。github / README_ET.md）エストニア語| [tl Pilipino]（/。github / README_TL.md）フィリピン人| [fi Suomalainen]（/。github / README_FI.md）フィンランド語| [frfrançais]（/。github / README_FR.md）フランス語| [fy Frysk]（/。github / README_FY.md）フリジア語| [gl Galego]（/。github / README_GL.md）ガリシア語| [kaქართველი]（/。github / README_KA）グルジア語| [de Deutsch]（/。github / README_DE.md）ドイツ語| [elΕλληνικά]（/。github / README_EL.md）ギリシャ語| [guગુજરાતી]（/。github / README_GU.md）グジャラート語| [htKreyòlayisyen]（/。github / README_HT.md）ハイチ語クレオール語| [haハウサ語]（/。github / README_HA.md）ハウサ語| [hawŌleloHawaiʻi]（/。github / README_HAW.md）ハワイ語| [彼はעִברִית]（/。github / README_HE.md）ヘブライ語| [こんにちはहिन्दी]（/。github / README_HI.md）ヒンディー語| [hmn Hmong]（/。github / README_HMN.md）モン族| [hu Magyar]（/。github / README_HU.md）ハンガリー語| [isÍslenska]（/。github / README_IS.md）アイスランド語| [ig Igbo]（/。github / README_IG.md）Igbo | [id bahasa Indonesia]（/。github / README_ID.md）アイスランド語| [ga Gaeilge]（/。github / README_GA.md）アイルランド語| [イタリア語/イタリア語]（/。github / README_IT.md）| [ja日本語]（/。github / README_JA.md）日本語| [jw Wongjawa]（/。github / README_JW.md）ジャワ語| [knಕನ್ನಡ]（/。github / README_KN.md）カンナダ語| [kkҚазақ]（/。github / README_KK.md）カザフ語| [kmខ្មែរ]（/。github / README_KM.md）クメール語| [rw Kinyarwanda]（/。github / README_RW.md）Kinyarwanda | [ko-south韓國語]（/。github / README_KO_SOUTH.md）韓国語（南）| [ko-north문화어]（README_KO_NORTH.md）韓国語（北）（まだ翻訳されていません）| [kuKurdî]（/。github / README_KU.md）クルド語（クルマンジー）| [kyКыргызча]（/。github / README_KY.md）キルギス語| [loລາວ]（/。github / README_LO.md）ラオス| [la Latine]（/。github / README_LA.md）ラテン語| [lt Lietuvis]（/。github / README_LT.md）リトアニア語| [lbLëtzebuergesch]（/。github / README_LB.md）ルクセンブルク語| [mkМакедонски]（/。github / README_MK.md）マケドニア語| [mgマダガスカル]（/。github / README_MG.md）マダガスカル| [ms Bahasa Melayu]（/。github / README_MS.md）マレー語| [mlമലയാളം]（/。github / README_ML.md）マラヤーラム語| [mt Malti]（/。github / README_MT.md）マルタ語| [miマオリ]（/。github / README_MI.md）マオリ| [mrमराठी]（/。github / README_MR.md）マラーティー語| [mnМонгол]（/。github / README_MN.md）モンゴル語| [myမြန်မာ]（/。github / README_MY.md）ミャンマー（ビルマ語）| [neनेपाली]（/。github / README_NE.md）ネパール語| [norskなし]（/。github / README_NO.md）ノルウェー語| [またはଓଡିଆ（ଓଡିଆ）]（/。github / README_OR.md）オディア語（オリヤー語）| [psپښتو]（/。github / README_PS.md）パシュトゥー語| [faفارسی]（/。github / README_FA.md）|ペルシア語[pl polski]（/。github / README_PL.md）ポーランド語| [ptportuguês]（/。github / README_PT.md）ポルトガル語| [paਪੰਜਾਬੀ]（/。github / README_PA.md）パンジャブ語|文字Qで始まる言語はありません| [roRomână]（/。github / README_RO.md）ルーマニア語| [ruрусский]（/。github / README_RU.md）ロシア語| [sm Faasamoa]（/。github / README_SM.md）サモア語| [gdGàidhlignah-Alba]（/。github / README_GD.md）スコットランドゲール語| [srСрпски]（/。github / README_SR.md）セルビア語| [st Sesotho]（/。github / README_ST.md）セソト語| [snショナ語]（/。github / README_SN.md）ショナ語| [sdسنڌي]（/。github / README_SD.md）シンド語| [siසිංහල]（/。github / README_SI.md）シンハラ語| [skスロバキア語]（/。github / README_SK.md）スロバキア語| [slSlovenščina]（/。github / README_SL.md）スロベニア語| [so Soomaali]（/。github / README_SO.md）ソマリア語| [[esenespañol]（/。github / README_ES.md）スペイン語| [su Sundanis]（/。github / README_SU.md）スンダ語| [sw Kiswahili]（/。github / README_SW.md）スワヒリ語| [sv Svenska]（/。github / README_SV。md）スウェーデン語| [tgТоҷикӣ]（/。github / README_TG.md）タジク語| [taதமிழ்]（/。github / README_TA.md）タミル語| [ttТатар]（/。github / README_TT.md）タタール| [teతెలుగు]（/。github / README_TE.md）テルグ語| [thไทย]（/。github / README_TH.md）タイ語| [trTürk]（/。github / README_TR.md）トルコ語| [tkTürkmenler]（/。github / README_TK.md）トルクメン語| [ukУкраїнський]（/。github / README_UK.md）ウクライナ語| [urاردو]（/。github / README_UR.md）ウルドゥー語| [ugئۇيغۇر]（/。github / README_UG.md）ウイグル| [uz O'zbek]（/。github / README_UZ.md）ウズベク語| [viTiếngViệt]（/。github / README_VI.md）ベトナム語| [cy Cymraeg]（/。github / README_CY.md）ウェールズ語| [xh isiXhosa]（/。github / README_XH.md）コサ語| [yiיידיש]（/。github / README_YI.md）イディッシュ語| [ヨルバ語]（/。github / README_YO.md）ヨルバ語| [zu Zulu]（/。github / README_ZU.md）Zulu）110言語で利用可能（北朝鮮語はまだ翻訳されていないため、英語と北朝鮮語を除いた場合は108言語[ここで読む]（/ OldVersions / Korean（North ）/README.md））

英語以外の言語での翻訳は機械翻訳されており、まだ正確ではありません。 2021年2月5日の時点で、エラーはまだ修正されていません。翻訳エラーを報告してください[ここ]（https://github.com/seanpm2001/Degoogle-your-life/issues/）必ずソースを使用して修正をバックアップし、ガイドしてください、英語以外の言語はよくわからないので（最終的には翻訳者を雇う予定です）、レポートで[wiktionary]（https://en.wiktionary.org）やその他の情報源を引用してください。そうしないと、公開されている修正が拒否されます。

注：GitHubのマークダウンの解釈（および他のほとんどすべてのWebベースのマークダウンの解釈）の制限により、これらのリンクをクリックすると、GitHubプロファイルページではない別のページの別のファイルにリダイレクトされます。 READMEがホストされている[seanpm2001 / seanpm2001リポジトリ]（https://github.com/seanpm2001/seanpm2001）にリダイレクトされます。

DeepLやBingTranslate（反Googleキャンペーンにとってはかなり皮肉なことです）のような他の翻訳サービスで必要な言語のサポートが制限されているか、まったくサポートされていないため、翻訳はGoogle翻訳で行われます。何らかの理由で、フォーマット（リンク、仕切り、太字、斜体など）がさまざまな翻訳で混乱しています。修正するのは面倒で、ラテン文字以外の言語でこれらの問題を修正する方法がわかりません。これらの問題を修正するには、右から左への言語（アラビア語など）で追加のヘルプが必要です。

メンテナンスの問題により、多くの翻訳は古く、この「README」記事ファイルの古いバージョンを使用しています。翻訳者が必要です。また、2021年4月9日の時点で、すべての新しいリンクが機能するようになるまでしばらく時間がかかります。

***

##インデックス

[00.0-タイトル]（＃Degoogling --- Degoogle-your-life）

> [00.1-インデックス]（＃インデックス）

[01.0-基本的な説明]（＃Basic-説明）

> [01.1-リポジトリヘッダー]（＃Degoogle-your-life）

> [01.2-Wuest3NFuchsの説明の概要]（＃Overview-by-Wuest3nFuchs）

>> [01.2.1-それはどういう意味ですか？]（＃What-does-it-mean--by-Wuest3nFuchs）

>> [01.2.2-なぜDegoogle？]（＃Why-Degoogle--by-Wuest3nFuchs）

[02.0-記事]（＃Articles）

[03.0-プライバシー]（＃プライバシー）

[04.0-その他の反Googleキャンペーン]（＃Other-anti-Google-campaigns）

> [04.0.1-廃止]（＃Defunct）

> [04.0.2-進行中]（＃進行中）

[05.0-他の引数に対抗する]（＃Countering-other-arguments）

> [05.0.1-コンビニエンス]（＃コンビニエンス）

> [05.0.2-なぜそれが重要なのですか？とにかく手遅れです]（＃Why-does-it-matter、-its-too-late-anyways）

> [05.0.3-その他]（＃その他）

[06.0-ソース]（＃ソース）

[07.0-ダウンロードリンク]（＃Download-links）

[08.0-私のデグーグル体験]（＃My-degoogling-experience）

> [08.1-私が切り替えたもの]（＃What-I-switched-from）

> [08.2-まだ逃げられない製品]（＃Products-I-still-cannot-get-away-from）

[09.0-その他のチェックアウト]（＃Other-things-to-check-out）

[10.0-ファイル情報]（＃File-info）

> [10.1-ソフトウェアステータス]（＃Software-status）

> [10.2-スポンサー情報]（＃Sponsor-info）

[11.0-ファイル履歴]（＃File-history）

[12.0-フッター]（＃フッター）

***

##基本的な説明

[ウィキペディアから：Degoogle]（https://en.wikipedia.org/wiki/DeGoogle）

DeGoogle運動（de-Google運動とも呼ばれる）は草の根運動であり、プライバシー活動家が、会社に関するプライバシーの懸念が高まっているために、ユーザーにGoogle製品の使用を完全にやめるように促しています。この用語は、Googleを自分の生活から取り除く行為を指します。インターネットの巨人の市場シェアの拡大がデジタル空間で会社に独占的な力を生み出すにつれて、ますます多くのジャーナリストが会社の製品に代わるものを見つけるのが難しいことに気づきました。

**歴史**

2013年、VenturebeatのJohn Koetsierは、AmazonのKindle FireAndroidベースのタブレットは「Androidの非Google化バージョン」であると述べました。 2014年、USNewsのJohnSimpsonは、Googleや他の検索エンジンによる「忘れられる権利」について書いています。 2015年、IrishTimesのDerekScallyが、「De-Googleyourlife」の方法に関する記事を書きました。 2016年にアンドロイのクリスカルロンd当局は、CyanogenMod 14のユーザーは、Googleアプリがなくても正常に機能するため、電話を「de-Google」できると提案しました。 2018年、InverseのNick Lucchesiは、ProtonMailが「あなたの人生を完全にグーグルから外すことができる」方法をどのように推進していたかについて書いています。 LifehackerのBrendanHesseは、「Googleを辞める」ことに関する詳細なチュートリアルを作成しました。GizmodoのジャーナリストであるKashmir Hillは、Googleカレンダーを使用せずに会議に出席できず、会議を開催するのに苦労したと主張しています。 Googleが提供するサービスの使用を禁止されたのは、同社の製品がないために通常のインターネットの使用が不可能になるほどの選択肢がほとんどないためです。

***

＃Degoogle-your-life
一般的なデグーグル情報のリポジトリと、他のデグーグルリポジトリへのリンク。

***

## Wuest3nFuchsによる概要

[Wuest3nFuchs]（https://github.com/Wuest3nFuchs）によって提供されるより良い説明-ソース：[Wuest3nFuchs / Degoogle]（https://github.com/Wuest3nFuchs/Degoogle）

＃＃＃ どういう意味ですか？ Wuest3nFuchsによる

デグーグルとは、グーグルに属するもの、グーグルによって作られたものの使用をやめることを意味します。私は彼らの検索エンジン、彼らのメールサービス（Gmail）、Youtubeなどについて話している。

###なぜDegoogle？ Wuest3nFuchsによる

グーグルは現在、世界で最も強力な企業の1つです。彼らは私たち全員に関する膨大な量の情報を保存してきました。彼らはそれを保護する方法を知っているので、私たちの情報は彼らにとって安全であると主張する人もいます。しかし、これは真実ではありません。グーグルは以前に浸透しており、将来浸透するでしょう。スクリプトキディではないかもしれませんが、国民国家によって行われます。これが彼らがお金を稼ぐ方法であるため、Googleは私たち全員に個人情報を保存します。

彼らは私たちの電子メールをスキャンし、私たちが彼らの検索エンジンを使用しているときに私たちが検索したもの、私たちがYoutubeで見たビデオを保存します。これは彼らが私たちをターゲットにし、私たちの親友と話したことに基づいて私たちにいくつかの広告を表示するために私たちにプロファイルを構築する方法です。 Snowden氏のおかげで、Googleが** "PRISM" **というプログラムの下でNSAと個人情報を共有していることがわかりました。


将来、誰かがそのすべての情報にアクセスできるようになり、本当に悪いことが起こることを保証します。これを防ぐには、今すぐDegooglingを開始する必要があります。また、** NSA **とデータを共有している会社の製品を使用しないでください。グーグルを解除して、これらすべてを停止する必要があります。

**他の人がそれを行うことができれば、あなたもそれを行うことができます。**

[詳細はこちら]（https://github.com/Wuest3nFuchs/Degoogle）

<！-私はこのリポジトリを完全に所有しておらず、他のソースを宣伝したいので、フォークへのリンクは現在リストされていません。私自身のhttps://github.com/Degoogle-your-life/Degoogleにリンクするのは利己的です！->

***

##記事

###記事のステータス

_すべての記事は現在進行中の作業であり、大幅な改善が必要です。提案と修正は許可されています。_

_ 2021年4月18日午後4時9分現在、ほとんどの記事はまだ開始されていません。私はそれらを始めるための時間と労力を見つけることに取り組んでいます。_

[Google Chromeの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Chrome）<！-1！->

[ChromeBookの使用をやめる]（https://github.com/seanpm2001/Stop-using-Chromebooks）<！-2！->

[WideVineDRMの使用をやめる/ WideVineDRMをカットする時が来ました]（https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM）<！-3！->

[ReCaptchaの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha）<！-4！->

[YouTubeからの代替]（https://github.com/seanpm2001/Alternating-from-YouTube）<！-5！->

[グーグルをやめなさい、なぜグーグル検索の使用をやめるべきなのか]（https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search）<！-6！- >>

[Gmailの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-GMail）<！-7！->

[Androidの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Android）<！-8！->

[Google Ampを避けるべき理由]（https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP）<！-9！->

[Googleドライブの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive）<！-10！->

[GoogleマップとGoogleEarthの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth）<！-11！- ->

[ねぇGoogle、やめて]（https://github.com/seanpm2001/Hey-Google-Stop）<！-12！​​->

[Google / Playブックスからの読書をやめる]（https://github.com/seanpm2001/Stop-reading-from-Google-Books）<！-13！->

[Google Classroomの使用を停止]（https://github.com/seanpm2001/Stop-using-Google-Classroom）<！-14！->

[Google翻訳の使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate）<！-15！->

[Googleアカウントの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Accounts）<！-16！->

**まもなく書かれる新しい記事：**

[Gerritの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit）<！-17！->

[Google Analyticsの使用を停止する必要がある理由（2021年2月24日水曜日の午後4時13分にリポジトリが壊れています）]（https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics）<！-18！->

<！-ワークディバイダー！->

[Google AdSenseの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense）<！-19！->

[Google Oneの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-One）<！-20！->

[Google+の使用をやめるべき理由（廃止）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus）<！-21！->

[Google Playストアの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store）<！-22！->

[Googleドキュメントの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs）<！-23！->

[Googleスライドの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides）<！-24！->

[Googleスプレッドシートの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets）<！-25！->

[Googleフォームの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms）<！-26！->

[Google Cardboardの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard）<！-27！->

[Googleメッセージの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages）<！-28！->

[Googleマテリアルデザインの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design）<！-29！->

[Google Glass / Glassesの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass）<！-30！->

[Google Fuchsiaの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia）<！-31！->

[GBoardの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-GBoard）<！-32！->

[Google Homeの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home）<！-33！->

[Google Nestの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest）<！-34！->

[Googleハングアウトの使用をやめるべき理由（廃止）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts）<！-35！->

[Google Duoの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo）<！-36！->

[Google Tensorflowの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow）<！-37！->

[Google Blocklyの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly）<！-38！->

[Google Flutterの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter）<！-39！->

[Googles Goプログラミング言語の使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go）<！-40！->

[GoogleのDartプログラミング言語の使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart）<！-41！->

[GoogleのWebP画像形式の使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP）<！-42！->

[GoogleのWebMビデオ形式の使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM）<！-43！->

[Googleビデオの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video）<！-44！->

[Googleサイトの使用をやめるべき理由（クラシック）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic）<！-45！->

[Googleサイトの使用をやめるべき理由（「新規」）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New）<！-46！->

[Google Payの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay）<！-47！->

[Android Payの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay）<！-48！->

[Google VPN（oxymoron）の使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN）<！-49！->

[Googleフォトの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos）<！-50！->

[Googleカレンダーの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar）<！-51！->

[VirusTotalの使用をやめるべき理由（2012年9月からGoogleが所有しているため）（https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal）<！-52！- >>

[Google Fiの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi）<！-53！->

[Google Stadiaの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia）<！-54！->

[Google Keepの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep）<！-55！->

[Google Baseの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base）<！-56！->

[Google Summer of Codeへの参加をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code）<！-57！- >>

[Googleカメラの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera）<！-58！->

[Google Calculatorの使用をやめるべき理由（極端に見えるかもしれませんが、すべてからdegoogleする必要があり、非常に簡単に切り替えることができます）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-電卓）<！-59！->

[Googleサーベイ+リワードの使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards）<！-60！->

[Google描画の使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings）<！-61！->

[Tenor（GIFサイト、2019年からGoogleが所有）の使用をやめるべき理由]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor）<！-62！- ->

[FLoCとは-Googleの大きなFLoCingの問題を回避する必要がある理由（Google Chromeの使用をやめる）]（https://github.com/seanpm2001/What-the-FLoC）<！-63！->

**記事の総数：** `63`

**記事[ロードマップAB]（DegoogleCampaign_2021Roadmap_Part1.md）（2021年3月12日まで）2日間の休暇**

**記事[ロードマップBB]（DegoogleCampaign_2021Roadmao_Part2.md）（最大？2021）2日間の休暇**

記事のステータス

すべての記事は現在進行中の作業であり、大幅な改善が必要です。提案と修正は許可されています。

**フォーク**

私のDegoogleネットワークを拡張し、アクセスのしやすさを追加し、コミュニティの叫び声を上げます。

1. [Fossapps]（https://github.com/Degoogle-your-life/Fossapps）|フォーク元：[https://github.com/wacko1805/Fossapps]（https://github.com/wacko1805/Fossapps）（英語）

2. [プライバシーリンク]（https://github.com/Degoogle-your-life/Privacy-links）|フォーク元：[https://github.com/Arturro43/privacy-links]（https://github.com/Arturro43/privacy-links）（ポーランド語）

3. [Delightful-Privacy]（https://github.com/Degoogle-your-life/Delightful-Privacy）|フォーク元：[https://github.com/LinuxCafeFederation/Delightful-Privacy]（https://github.com/LinuxCafeFederation/Delightful-Privacy）（英語）

4. [ブロックリスト]（https://github.com/Degoogle-your-life/blocklists）|フォーク元：[https://github.com/jmdugan/blocklists]（https://github.com/jmdugan/blocklists）（英語）

5. [Degoogle、Wuest3nFuchsによる]（https://github.com/Degoogle-your-life/Degoogle）|フォーク元：[https://github.com/Wuest3nFuchs/Degoogle]（https://github.com/Wuest3nFuchs/Degoogle）（英語）

**関連**

[Degoogled Androidフォン仮想マシンの調査]（https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research）

**参照：**

[ウィキペディアでのGoogleの批評]（https://en.wikipedia.org/wiki/Criticism_of_Google）

[Google Graveyard（killedbygoogle.com）-Googleが殺した224以上の製品のソートされたリスト]（https://killedbygoogle.com/）

> [GitHubリンク]（https://github.com/codyogden/killedbygoogle）

[アルファベット労働者組合-800人以上のメンバーを擁するGoogleの新しい労働者組合]（https://alphabetworkersunion.org/people/our-union/）

[恐竜のイースターエッグを手放したくないですか？このウェブサイトはあなたをカバーしています]（https://chromedino.com/）

***

##プライバシー

[G]（https://en.wikipedia.org/wiki/Criticism_of_Google）[o]（https://en.wikipedia.org/wiki/PRISM_（surveillance_program））[o]（https：//www.reddit .com / r / degoogle /）[g]（https://www.wired.com/2012/06/opinion-google-is-evil/）[l]（https://securitygladiators.com/chrome-privacy -bad /）[e]（https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/）[h]（https：// www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy）[a]（https://www.vox.com/recode/2020/2 / 21/21146998 / google-new-mexico-children-privacy-school-chromebook-lawsuit）[s]（https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1）[a]（https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html）[v]（https：//www.huffpost .com / entry / why-googles-spying-on-use_b_3530296）[e]（https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ）[r]（https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data）[y]（https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html）[v]（https：// protonmail。 com / blog / google-privacy-problem /）[e]（https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -ブラウザ/）[r]（https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy)[y](https://en.wikipedia.org/wiki/Nothing_to_hide_argument＃Criticism）[b]（https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/）[a]（https://eduzaurus.com/free -essay-samples / nothing-to-hide-argument-has-nothing-to-say /）[d]（https://www.cnet.com/how-to/google-collects-a-frightening-amount- of-data-about-you-you-can-find-and-delete-it-now /）[r]（https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -your-personal-data-n870501）[e]（https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -monetizes-and）[c]（https://www.wired.com/story/google-tracks-you-privacy/）[o]（https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy）[r]（https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- collection-revealed.html）[d]（https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H）[w]（https://www.wired.com/story/ health-fitness-data-privacy /）[h]（https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks）[e]（https://mashable.com/article/google-android-data-collection-study/）[n]（https：//www.engadget .com / australian-government-google-data-collection-lawsuit-182043643.html）[i]（https://www.maketecheasier.com/studyandroid-data-google-ios-apple/）[t]（https： //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/）[c]（https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https://moz.com / blog / where-does-google-draw-the-data-collection-line）[e]（https://mashable.com/article/google-android-data-collection-study/）[s]（https： //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/）[t]（https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)[o](https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -5-mに代わって請求illion-iphone-users）[u]（https://time.com/23782/google-flu-trends-big-data-problems/）[s]（https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W）[e]（https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/） [r]（https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html）[p]（https：// topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/)[r](https://arstechnica.com/information-technology/2014/01 / what-google-can-really-do-with-nest-or-really-nests-data /）[i]（https://www.cbsnews.com/news/google-education-spies-on-collects- data-on-millions-of-kids-alleges-lawsuit-new-mexico-attorney-general /）[v]（https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -under-our-noses /）[a]（https://www.wired.com/insights/2012/10/google-opt-out/)[c](https://www.nytimes.com/2019 / 09/04 / technology / google-yout ube-fine-ftc.html）[y]（https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550）[。]（https ：//medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c）（私はこれの証拠を続けていくことができましたが、これらすべてを見つけて通過するのに長い時間がかかりました記事）

すべてのGoogle製品にはスパイウェアが含まれているため、Google製品のプライバシーは常に悪いものです。

あなたが何をしようとも、あなたがグーグルを使用しているとき、あなたの機密の個人データはすべてグーグルや他の人に送られます。グーグルはまた、オープンプログラムを通過しているのが発見されました。たとえば、私がアクセスしなかったYouTubeタブを開いた状態での個人的な経験（Firefoxで）から、オフラインでいくつかのビデオを視聴しました（VLC Media Player）後で推奨事項を確認したとき、それは私が見たほとんどすべてでした。彼らが他のプログラムもスパイしていることは間違いありません。

Chrome（および他の多くのブラウザ）では、シークレットモードが存在します。 Chromeでは、Googleが引き続きデータをマイニングするため、このモードは無意味です。データマイニング/トラッキングをオフにし、「トラッキングしない」信号を有効にしても、驚いたことに、Googleは引き続きデータをマイニングしています。

隠すものがないと思うなら、**あなたは絶対に間違っています**。この議論は何度も暴かれてきました：

[ウィキペディア経由]（https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism）

1.エドワード・スノーデンは、「隠すものがないのでプライバシーの権利を気にしないと主張することは、言うことがないので言論の自由を気にしないと言うことと同じです。私には隠すものは何もない」とあなたは言っている、「私はこの権利を気にしない」とあなたは言っている、「私は正当化する必要があるところまで来ているので、私はこの権利を持っていない。 「権利が機能する方法は、政府があなたの権利への侵入を正当化する必要があるということです。」

2. Daniel J. Soloveは、The Chronicle of Higher Educationの記事で、この議論に反対していると述べました。彼は政府がリーすることができると述べたk個人に関する情報を使用してその個人に損害を与える、または個人が実際に不正行為を行っていない場合でもサービスへのアクセスを拒否するために個人に関する情報を使用し、政府が過ちを犯して個人の生活に損害を与える可能性があること。 Soloveは次のように書いています。「直接関与する場合、プライバシーの狭い理解に焦点を当てる議論を余儀なくされるため、隠すことのない議論を巻き込むことができます。しかし、政府のデータ収集と監視を超えた使用に関係する複数のプライバシー問題に直面した場合、開示、隠すべきことのない議論は、結局、何も言うことはありません。」

3. Privacy Rights：Moral and LegalFoundationsの著者であるAdamD。Mooreは、「権利は費用便益または結果主義的な種類の議論に抵抗するという見解です。ここでは、プライバシーの利益が一種であるという見解を拒否しています。セキュリティと交換できるものの」彼はまた、監視は外見、民族性、性別、宗教に基づいて社会の特定のグループに不釣り合いに影響を与える可能性があると述べた。

4.コンピューターセキュリティの専門家で暗号学者のブルース・シュナイアーは、リシュリュー枢機卿の「最も正直な人の手によって書かれた6行を私に渡せば、彼を絞首刑にする何かを見つけるだろう」と述べ、反対を表明した。州政府がその個人を起訴またはブラックメールするためにその個人の生活の側面をどのように見つけることができるかについて。シュナイアーはまた、「あまりにも多くの人が、議論を「セキュリティ対プライバシー」として誤って特徴付けている」と主張した。本当の選択は自由対支配です。」

5.ハーベイ・A・シルバーグラートは、一般人が平均して、米国で1日に3人のフェロニーを無意識のうちに犯していると推定しました。

6.哲学者で精神分析医のエミリオ・モルディーニは、「隠すものは何もない」という議論は本質的に逆説的であると主張した。人々は「何か」を隠すために「隠すもの」を持っている必要はありません。隠されているものは必ずしも関連性があるとは限らない、とMordiniは主張します。代わりに、彼は、心理的に言えば、私たちは他人に何かを隠すことができるという発見を通して個人になるので、隠され、アクセスが制限されることができる親密な領域が必要であると主張します。

7.ジュリアン・アサンジは、「まだキラーな答えはありません。ジェイコブ・アッペルバウム（@ioerror）は巧妙な反応を示し、これを言う人々に、電話のロックを解除してズボンを下ろすように頼みます。私のバージョンでは、 「まあ、あなたがとても退屈なら、私たちはあなたと話すべきではありませんし、他の誰も話すべきではありません」が、哲学的には、本当の答えはこれです：大量監視は大規模な構造変化です。社会が悪くなると、それは起こりますたとえあなたが地球上で最も素朴な人であったとしても、それを持って行くために。」

8.法学教授のIgnacioCofoneは、人々が関連情報を他人に開示するときはいつでも、無関係な情報も開示するため、議論はそれ自体の用語で誤っていると主張します。この無関係な情報にはプライバシーコストがかかり、差別などの他の危害につながる可能性があります。

***

##その他の反Googleキャンペーン

これは他の注目すべき反グーグルキャンペーンのリストです。このリストは不完全です。あなたはそれを拡大することによって助けることができます。

###廃止

[Scroogled-Microsoftによる（2012年11月から2014年）]（https://en.wikipedia.org/wiki/Scroogled）

_現時点では他のエントリはありません。_

###進行中

_このリストは現在空です。_

***

##他の議論に対抗する

グーグルを正当化するために人々がするいくつかの議論があります。最初の主要なものの1つはすでに[ここ]（＃プライバシー）で明らかにされていますが、他のいくつかのものがあります：

###利便性

はい、Googleの製品は便利なようです。ただし、セキュリティ、プライバシー、信頼性など、利便性のためにすべてを取引しています。グーグルは何年にもわたって怠惰になっていて、彼らのサーバーはますますダウンしています。現在、Googleサーバーは月に1〜2回、ほぼ1時間ダウンしています（特にYouTube）

残念ながら、社会がグーグルに依存しているため、グーグルはインターネットを支配するようになり、ますます制御しようとしています。 2012年にGoogleが5分間ダウンしたとき、**グローバル**インターネットトラフィック**が40％減少**したと報告されました。Googleは頻繁に1〜2時間ダウンし、[倫理チームの解雇] （https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/）とりわけ、それらはますます便利ではなくなります。

利便性は必ずしも良いことではありません。サーバーが時々ダウンしないようにする方法はないので、何が起こっているのかを認識し、それらがダウンしたときに備えておく必要があります。

グーグルもあなたが思っているほど便利ではありません。他にももっと便利なサイトがあります。グーグルは、あなたが彼らのランダムなアカウントの停止と終了を応答なしで説明するとき（あなたがグーグルのツイッターアカウントに十分な注意を引くか、1億ドル以上で彼らを訴えない限り）、あなたを利用し、あなたを台無しにし、そして誰もあなたの悲鳴を聞くことができなかった枕にあなたを悲鳴を上げることを強制しました助けを求めて。

###なぜそれが重要なのか、とにかく遅すぎる

これはあまり一般的ではありませんが、説明が必要です。現在の状態では、ほとんどの世界政府といくつかの強力な企業があなたのあらゆる動きを知っているようですが、なぜそれから逃れることさえわざわざするのですか？答えは簡単です：**あなたはより良い価値があります**。この時点でなんとか彼らから逃げることができれば、彼らがあなたの動きをさらに追跡することは難しくなり、あなたは新しいよりプライベートな生活を築くことができます。

[1つのソース]（https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/）ちなみに、私は1週間以上取得するたびに、この投稿に無料のReddit賞を与えています今（私の無料コイン500個すべてと一緒に）このトピックをさらに盛り上げるために。これまでに、私はこの投稿に14以上の無料の賞を与えました。それほど多くはありませんが、それがどのように認識され、誰によって認識されるかによっては、小さなことが大きな影響を与える可能性があります。

###その他

現在、他に議論はありません。

_このリストは不完全です_

***

##出典

コピー：

[G]（https://en.wikipedia.org/wiki/Criticism_of_Google）[o]（https://en.wikipedia.org/wiki/PRISM_（surveillance_program））[o]（https：//www.reddit .com / r / degoogle /）[g]（https://www.wired.com/2012/06/opinion-google-is-evil/）[l]（https://securitygladiators.com/chrome-privacy -bad /）[e]（https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/）[h]（https：// www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy）[a]（https://www.vox.com/recode/2020/2 / 21/21146998 / google-new-mexico-children-privacy-school-chromebook-lawsuit）[s]（https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1）[a]（https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html）[v]（https：//www.huffpost .com / entry / why-googles-spying-on-use_b_3530296）[e]（https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ）[r]（https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data）[y]（https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html）[v]（https：// protonmail。 com / blog / google-privacy-problem /）[e]（https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -ブラウザ/）[r]（https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy)[y](https://en.wikipedia.org/wiki/Nothing_to_hide_argument#批判）[b]（https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/）[a]（https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /）[d]（https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-about-you-you-can-find-and-delete-it-now /）[r]（https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501）[e]（https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -および）[c]（https://www.wired.com/story/google-tracks-you -privacy /）[o]（https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy)[r](https： //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H）[w]（https://www.wired.com/story/health-fitness-data-privacy/）[h]（https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks）[e]（https://mashable.com/article/google-android-data-collection-study/）[n]（https：// www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html）[i]（https://www.maketecheasier.com/studyandroid-data-google-ios-apple/)[t] （https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/）[c]（https：//www。 cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line）[e]（https://mashable.com/article/google-android-data-collection-study/）[s]（https：/ /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/）[t]（https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html）[o]（https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- Claims-on-behalf-of-5-million-iphone-users）[u]（https://time.com/23782/google-flu-trends-big-data-problems/）[s]（https：/ /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /）[r]（https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you。 html）[p]（https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/）[r]（https：// arstechnica .com / information-technology / 2014/01 / what-google-can-really-do-with-nest-or-really-nests-data /）[i]（https://www.cbsnews.com/news/google-education -spies-on-collects-data-on-millions-of-kids-alleges-lawsuit-new-mexico-attorney-general /）[v]（https://www.nationalreview.com/2018/04/the- student-data-mining-scandal-under-our-noses /）[a]（https://www.wired.com/insights/2012/10/google-opt-out/）[c]（https：// www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did -have-something-to-hide-40689565c550）[。]（https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c）

その他の情報源：

[ファイブアイズアライアンス]（https://en.wikipedia.org/wiki/Five_Eyes）[19 84]（https://en.wikipedia.org/wiki/Nineteen_Eighty-Four）

***

##ダウンロードリンク

[Firefoxを入手]（https://www.mozilla.org/en-US/firefox/new/）[Torブラウザを入手]（https://www.torproject.org/download/）[その他/利用不可]（https ：//www.example.com）

***

##私のデグーグル体験

私はついに2018年にビッグテックの問題に気づき始め、グーグルを始めました。最初の数ヶ月で、私は大きな進歩を遂げました。それ以来、それは非常に遅くなりました。


###私が切り替えたもの

Google Chrome-> Firefox / Tor

Google検索-> DuckDuckGo（デフォルト）/ Ecosia（気になるとき）/ Bing（まれに）

GMail-ProtonMail（まだ完全に切り替えられていません）

Googleサイト->セルフホスティング（まだ完全に切り替えられていません）

Google +->ほとんど使用されていません。独自のシャットダウンのために自分自身を削除しました

Google Docs->使用したことはありません。代わりに、Microsoft Word 2013（2019より前）とLibreOffice（2019以降）を使用しています。

Googleスプレッドシート->使用したことはありません。代わりに、Microsoft Excel 2013（2019年以前）とLibreOffice（2019年以降）を使用しています。

Googleスライド->使用したことはありません。代わりにMicrosoftPowerPoint 2013（2019より前）とLibreOffice（2019以降）を使用しています。

Google図形描画->使用したことはありません。代わりにLibreOffice（2019以降）を使用しています。

Gerrit->使用することはありません。代わりに、GitHub（現在のデフォルト）、GitLab、BitBucket、SourceForgeを使用しています。

Googleフォト->使用したことがない

Googleドライブ-> OneDrive（2019-2020）Degoo（2020-2020）pCloud（2020-現在）

Googleマップ-> OpenStreetMaps / Apple Maps

Go-特別な例外を作成しますが、関数型プログラミング言語としては使用しません

Dart-特別な例外を作成しますが、関数型プログラミング言語としては使用しません

Flutter-特別な例外を作成しますが、関数型プログラミング言語としては使用しません

Google Earth-> OpenStreetMaps / Apple Maps

グーグルストリートビュー->使用したことがない、私はそれが非常に不気味だと思う

GoogleFi->使用したことがない

Googleカレンダー->使用したことがない

Google電卓->文字通り他の電卓アプリ、Pythonモードで実行されているLinux端末でも

GoogleNest->使用したことがない

GoogleAMP->使用したことがない

グーグルVPN->使用されたことがない、また撞着語

GooglePay->使用したことがない

Google Summer ofCode->参加したことはありません

テナー->他のGIFサイト。ただし、GIFは私にとってそれほど重要ではありません。私は通常、DuckDuckGo画像、Imgur、Reddit、またはその他のサイトからGIFファイルを取得します。

ブロック状->使用されなくなりました。スクラッチが直接ブロック状に実行されたかどうかはわかりません。私は2017年以降に関数型プログラマーになり、Scratchから成長しました。

GBoard-> 1回使用されましたが、放棄されました

Google Glass->使用したことがなく、幼い子供と見なされましたが、オプションがある場合は取得しない/使用することにしました

_リストが不完全な可能性があります。_

###まだ逃げられない商品

2021年2月25日の時点で、これらは私が完全にグーグルを解除するのを妨げているGoogle製品です。

1. YouTube

2.Android

3. GooglePlayストア

4. Gmail（学校と一部のサイトのみ）

5. Google Classroom（学校のみ）

6.グーグル翻訳

7.Googleアカウント

8. Googleサイト（GoogleはGDPRの法律に違反しているため（修正されるまでさらに5,000,000.00ユーロの罰金が科せられる可能性があります）、この製品のダウンロードを禁止しています）

私は他のすべてからdegoogleしました。

***

##行くのは邪悪

グーグルは2003年のエージェントベースのプログラミング言語「Go！」をプログラミング言語「Go」（2009年から6年後）でスチームロールし、彼らの言語は他の言語にまったく影響を与えないと主張した。グーグルは、「邪悪になるな」のモットーが当時まだ有効であったため、これについて強く批判されました。これは、「邪悪になるな」のモットーが引退した多くの事件の1つです。

結局、「Go！」の開発は終わり、「Go」はますます一般的になりました。グーグルは彼らが「Go！」をめちゃくちゃにしないと主張したが、結局彼らはそうし、彼らはそれをやめた（2021年4月9日現在）

[Goの詳細と代替方法については、こちらをご覧ください]（https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go）

***

## DRMの使用

Googleは、WideVine DRM「サービス」およびその他の形式を通じてDRM（デジタル制限管理）を使用しています。 DRMの目標は、オープンインターネットを破壊し、企業にユーザーに対する独占的な権力を与えることです。コストに関係なく、WideVineを完全に取り除く必要があります。

[WideVineとその問題について詳しくはこちらをご覧ください]（https://github.com/Degoogle-your-life/Its-time-to-cut-WideVine-DRM）

***

##よくある誤解

これは、Google製品に関するいくつかの一般的な誤解のリストです。

### Googleはインターネットではありません

グーグル/グーグル検索はインターネットではありません。グーグル検索は単なる検索エンジンです。任天堂プラットフォームのすべてのゲームが任天堂によって作られているわけではなく、任天堂によってライセンスされているのと同じですが、はるかに広い範囲です。すべてのGoogleサーバーが同時に破壊された場合、YouTube、Gmail、Googleドキュメント、Google検索などのGoogleサイトのみが失われますが、インターネットの大部分は引き続き存在します（Wikipedia、Stackoverflow、GitHub、すべてのMicrosoftWebサイト、NYTimes、Samsung、TikTokなど）は、Googleサインインと分析機能を失う可能性がありますが、それでも機能します（プログラミングが不十分で、Googleに直接依存していない限り）

***

## Internet Explorer6とChrome

GoogleChromeは新しいInternetExplorer 6になりつつあります。GoogleChromeが最初に登場したとき、Firefoxが主要なブラウザであり、Google ChromeのときにInternetExplorerの市場シェア（何百万人もの人々がFirefoxや他のブラウザに切り替える前に96％を超えていました）をほとんど殺していました。出てきて、人々はその速度とそれがグーグルによるものであるために切り替えました（ほとんどのプライバシー問題がまだ明らかにされていなかったので、当時は悪とは見なされていませんでした）それはInternetExplorerの96％のブラウザ市場シェアを殺しました）しかし、Google Chromeの市場シェアが上昇するにつれて、Googleはますます多くの機能を削除し、スパイウェアを追加し始め、Web標準の受け入れを停止し、GoogleChromeは新しいInternetExplorer6になりました。

現在の主な問題は、Chromeのみであり、他のブラウザでは機能しないWebサイトです。開発者は、Chromeを使用しない他の30〜40％のインターネットユーザーにサイトを使用させたくないと判断したためです。

グーグル自身でさえ彼らのサイトをクロームだけにしている。たとえば、Google検索では、Google Chromeを使用していないことが検出され（Braveなどの他のChromiumベースのブラウザでも影響を受ける）、FirefoxユーザーがFirefoxユーザーに許可されていない場合、Chromeを10秒ごとに3回ダウンロードするように求められます。彼らのサイトを使用してください（2020年現在）。さらに、Google Translateは、Firefoxやその他のGoogleChrome以外のブラウザでの音声入力をサポートしていません。

###ブレイブの問題

BraveやMicrosoftEdgeなど、Chromiumをベースにした他のブラウザには、Googleスパイウェアが完全に含まれているわけではありません。ブレイブは一般的にプライバシーコミュニティの反対側から推奨されていますが、ブレイブはChromiumを使用しているため、依然として問題があります。インターネットはChromiumのみのブラウザで構成されるべきではなく、さまざまな選択肢があるはずです。ブレイブは間違った道です。

[Google Chrome / Chromiumからのデグーグルについて詳しくはこちらをご覧ください]（https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome）

[ChromeOS / ChromiumOS（Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC）からのデグーグルについて詳しくはこちらをご覧ください]（https://github.com/Degoogle-your-life/Stop-using-Chromebooks）

***

##偽のプライバシーの更新

グーグルは、すでに手遅れになった後、彼らがプライバシーを気にかけていることを世界に伝えようとしてきました。彼らはユーザーのプライバシーを尊重していると主張し続けていますが、それでもすべてのプライバシー問題を解決しているわけではありません。

###オープンソースを部分的にすることはできません

オープンソースを部分的にすることはできません。グーグルはこれの証拠です。ソースコードのすべてのビットとバイトは、8分の1バイトも隠さずに、一般に公開されている必要があります。

AndroidやChromeOSのようなプロジェクトは部分的にオープンソースですが、プロプライエタリなスパイウェア要素の大部分が含まれています。

###撞着語

GoogleVPNは撞着語です。グーグルはプライバシーを気にかけていません、そして彼らのような会社からの仮想プライベートネットワーク（VPN）はVPNサービスのための可能な最悪の選択の1つでしょう。

***

##パフォーマンスが悪い

Googleは、最後のベンチマークソフトウェア（Google Octane）が2017年に廃止されたため、少なくとも2017年の時点で製品のパフォーマンスを気にしません。

***

##悪いプロジェクト管理

グーグルは非常に悪い内部プロジェクト管理システムを持っています。ますますダウングレードされているプログラムのいくつかの一般的な例には、Google DuoやYouTube Music（以前のGoogle Play Music）が含まれます。

Googleの内部開発システムでは、1つのアプリが半分の機能を持つ別のアプリにつながり、元のアプリが削除されます。数年後、機能が75％少ない新しいアプリが作成され、機能が50％のアプリが削除され、次に機能の87.5％が作成された新しいアプリが作成され、機能が75％のアプリが廃止されます。 、 等々。

***

##サービスの恐ろしいまたはモデレートなし

YouTubeは、モデレーションが悪い世界で最も一般的な例であり、存在する中で最悪のプラットフォームを作成しています。グーグルはまた、YouTubeがYouTubeの子供ではないことを理解していないようです。

YouTubeの場合、より多くのエンゲージメント時間とより多くのお金を目的として、嫌な親ナチと白人至上主義者のコンテンツがユーザーに提供されます。グーグルもいくつかの非常にやったクリスチャンアナルセックスビデオを「子供向け」のコンテンツとして承認すると同時に、年齢を制限するなど、彼らの節度のある愚かなこと。また、ポルノやゴアの広告が、他のさまざまな「子供向け」コンテンツとともに、ベイビーシャークのビデオのすぐ下に表示されることも珍しくありません。

YouTubeユーザーは、YouTubeでの不適切なコンテンツ（上記の例など）のモデレートが不十分であると非常に頻繁に不満を述べていますが、ユーザーは理由もなくランダムに動画を削除することができます。 「がらくた」ユーザーがスターリン時代の[ソビエト連邦]（https://en.wikipedia.org/wiki/Soviet_Union）とYouTubeを比較するようなごくわずかなケースでさえ、これらの不平等な罰のために。

2021年に、Googleは、動画が収益化されているにもかかわらず（Googleは収益を上げていますが、作成者は収益を上げていません）、すべての動画に広告を掲載することを発表しました。これはモデレートとはあまり関係ありませんが、注意することが重要です。

YouTubeはモデレートされていますが（非常に貧弱ですが）、彼らのお金の大部分を稼ぐGoogle広告サービスにはモデレートがほとんどまたはまったくないようです。

[YouTubeのモデレートの問題とYouTubeからの代替方法の詳細を読む]（https://github.com/seanpm2001/Alternating-from-YouTube）

Google Playの広告はボットファームから生成されます。同じ広告シナリオが何百もの企業で使用されており、ほとんど変更がなく、製品とは関係ありません（一般的な例：Playrix（Homescapes、Gardenscapes）Fishdom、Mafia City、ユーザーがゲームをしたり、音楽を聴いたりすることでお金を稼ぐことができると主張する広告の急成長する悪意のある傾向とともに。PayPalはこれについてコメントしていませんが、これは詐欺であることが明らかです。保証されたゲームをプレイすることにより、20秒以内に10,000ドルを超えると、誰も仕事をせず、代わりにこれを行うことになります。これは不可能であり、ビジネスはこのように機能できませんでした。この明らかな詐欺は2019年以来強力に成長しており、現在、これらの広告を作成するボットファームは、独自の広告で互いに争っています。

いくつかの広告も非常にスケベで、ユーザー（その大部分は13歳未満のユーザー、またはボット）に性的操作を介してクリックさせようとします。

多くのアプリはボットを使用して製品をアストロターフしているため、悪いレビューが行われると、ソックパペットボットアカウントは5つ星のレビューを投稿し始め、批判を否定しようとします。 [Googleもこれを行っています]（＃Astroturfing）

[Google AdSenseの問題の詳細を読む]（https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense）

***

##アストロターフィング

一般的な定義[（ウィキペディアから）]（https://en.wikipedia.org/wiki/Astroturfing）

`` `
アストロターフィングとは、メッセージや組織（政治、広告、宗教、広報など）のスポンサーをマスクして、草の根の参加者から発信され、サポートされているかのように見せかけることです。これは、情報源の金銭的関係に関する情報を差し控えることにより、声明または組織に信頼性を与えることを目的とした慣行です。アストロターフィングという用語は、「草の根」という言葉の遊びとして、天然の草に似せて設計された合成カーペットのブランドであるAstroTurfに由来しています。この用語の使用の背後にある意味は、問題の活動の背後にある「真の」または「自然な」草の根の努力の代わりに、サポートの「偽の」または「人工的な」外観があるということです。
`` `

Googleには、アストロターフィングの歴史があり、悪を行っていないように見せかけています（その過程で、アストロターフィングは悪です）。たとえば、Twitter（アカウントを持っている）などのプラットフォームにGoogleの批判を投稿すると、しばらくの間存在していたが、出てくる前に投稿されなかったいくつかのアカウントは、あなたが言ったことは間違っていると主張し、次にGoogleが最高の会社であると主張しますが、これらがほとんどのボットであることは明らかではないかもしれません人。

***

##違法で非倫理的な商慣行

Googleは、タックスヘイブンの利用、仕事のアウトソーシング、ビジネスのコストとして違法な侵入活動を継続するなど、違法で非倫理的なビジネス慣行を使用して独占を促進しています。

＃＃＃ ヨーロッパで

ヨーロッパは頻繁にGoogleを訴え、Androidでの違法行為に対する最大の訴訟であり、その結果、Googleは5,000,000,000ユーロ（2021年4月9日の5,947,083,703.68ドルに相当）を受け取りました。

###北米では

米国は、ヨーロッパの5,000,000,000ユーロの罰金と比較して、まだGoogleに十分な罰金を科していません。

###論争

グーグルはそれが論争を引き起こすまで問題を気にしません、そして彼らはそれを修正するための貧弱な試みをします、論争が一時的に消えるのにちょうど十分です、そしてそれが別の論争を引き起こすまで問題は指数関数的に悪化します、そしてサイクルが続きます。彼らは単にそれについて深刻なことをするのに十分気にしません。

***

## Googleは自動化されています

comとしてパニー、グーグルはほとんど自動化されており、自動化よりもモデレートが少ない。

会社は完全に自動化されるべきではありません。グーグルはその一例です。 AIだけでモデレートを行うと、モデレートはひどいものになります。YouTubeは良い例です。サイトをモデレートする人が数百人（数百人、場合によっては数千人）いる場合でも、明らかに非常に悪いため、ほとんどの人が仕事中に治療を受けなければなりません。

***

## Android

AndroidはGoogleが所有しています。オープンハンドセットアライアンス（Android以来オープンされていない）の一部であるAndroidは、Googleのもう一つの独占ポイントになり、逃れるのは非常に困難です。

Androidは1日に少なくとも10回Googleに電話をかけると報告されており、部分的にオープンソースであるにもかかわらず、スパイウェアとしての役割を果たしています。

Androidから代替するためにいくつかのプロジェクトが作成されていますが、デバイスをルート化する必要があります。 Knox DRMが原因で、これは米国の特定のSamsung電話ではもはや不可能です。 Androidの一般的な代替品には、iOS、iPadOS、LineageOS、Android x86、Ubuntu Touch、およびPiPhoneがあります（Pi Phoneは、Fedora、Ubuntu、ArchなどのモバイルデバイスでさまざまなLinuxシステムを実行する電話のブランドです）

[degoogled Android仮想マシンを機能させるための私の調査を参照してください]（https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research）

[Androidからdegoogleする方法をご覧ください]（https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android）

***

##役立つ小さなアクション

できる限りの方法で意識を広めることが重要です。私にとって、私は頻繁にデグーグルについて話したり、記事を書いたりするだけでなく、r / degoogleのピン留めされた投稿に毎日無料のReddit賞を与えて意識を高めるという小さな習慣もあります。これまでに、固定された投稿に30近くの賞を与えました（その投稿の10の賞に500枚の無料コインも費やしました）

***

##信頼できない

Googleは信頼できず、二度と信頼できません。彼らは完全に「邪悪になるな」（彼らは常に悪でした）から完全に悪であり、それを隠そうとしないようになりました。

***

##その他のチェックアウト

[Google Graveyard（killedbygoogle.com）-Googleが殺した224以上の製品のソートされたリスト]（https://killedbygoogle.com/）

> [GitHubリンク]（https://github.com/codyogden/killedbygoogle）

[アルファベット労働者組合-800人以上のメンバーを擁するGoogleの新しい労働者組合]（https://alphabetworkersunion.org/people/our-union/）

[恐竜のイースターエッグを手放したくないですか？このウェブサイトはあなたをカバーしています]（https://chromedino.com/）

他にも選択肢があります。それらを検索してください。

***

この記事にはいくつかのファクトチェックが必要です

***

##ファイル情報

ファイルタイプ： `Markdown（* .md）`

行数（空白行とコンパイラ行を含む）： `968`

ファイルバージョン： `6（2021年4月18日日曜日午後4時18分）`

***

###ソフトウェアステータス

私の作品はすべて無料ですが、いくつかの制限があります。 DRM（** D ** igital ** R ** estrictions ** M ** anagement）は私の作品のいずれにも存在しません。

！[DRM-free_label.en.svg]（DRM-free_label.en.svg）

このステッカーは、フリーソフトウェアファウンデーションによってサポートされています。私は自分の作品にDRMを含めるつもりはありません。

よく知られている「デジタル著作権管理」の代わりに「デジタル制限管理」という略語を使用しています。これは、DRMには権利がないという一般的な対処方法です。 「デジタル制限管理」のスペルはより正確であり、[Richard M. Stallman（RMS）]（https://en.wikipedia.org/wiki/Richard_Stallman）および[Free Software Foundation（FSF）]（ https://en.wikipedia.org/wiki/Free_Software_Foundation）

このセクションは、DRMの問題に対する認識を高め、それに抗議するために使用されます。 DRMは設計上欠陥があり、すべてのコンピューターユーザーとソフトウェアの自由に対する大きな脅威です。

画像クレジット：[defectivebydesign.org/drm-free /...]（https://www.defectivebydesign.org/drm-free/how-to-use-label）

***

##スポンサー情報

！[SponsorButton.png]（SponsorButton.png）<-このボタンをクリックしないでください。機能しません。単なる画像です。実際のボタンは、ページ上部の右側（<-L ** R **->）コーナーにあります。

必要に応じてこのプロジェクトを後援することができますが、寄付したいものを指定してください。 [ここに寄付できる資金を参照してください]（https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors）

他のスポンサー情報を表示できます[ここ]（https://github.com/seanpm2001/Sponsor-info/）

やってみて！スポンサーボタンは、ウォッチ/アンウォッチボタンのすぐ隣にあります。

***

##ファイル履歴



 *ファイルを開始しました

> *タイトルセクションを追加しました

> *インデックスを追加しました

> * aboutセクションを追加しました

> * Wikiセクションを追加しました

> *バージョン履歴セクションを追加しました

> *問題のセクションを追加しました。

> *過去の問題のセクションを追加しました

> *過去のプルリクエストセクションを追加しました

> *アクティブなプルリクエストセクションを追加しました

> *寄稿者セクションを追加しました

> *寄稿セクションを追加しました

> * READMEについてのセクションを追加しました

> * READMEバージョン履歴セクションを追加しました

> *リソースセクションを追加しました

> * DRMフリーのステッカーとメッセージを含むソフトウェアステータスセクションを追加しました

> *スポンサー情報セクションを追加しました

> *バージョン0.1で他の変更はありません

バージョン1（2021年2月19日金曜日午後5時20分）

>変更：

> *ファイルを開始しました

> *基本的な説明セクションを追加しました

> *リポジトリの説明セクションを追加しました

> * 14エントリの記事リストを追加しました

>> * `関連記事`セクションを追加しました

>> *「関連項目」セクションを追加

> *ファイル情報セクションを追加しました

> *ファイル履歴セクションを追加しました

> *フッターを追加しました

> *バージョン1で他の変更はありません

バージョン2（2021年2月19日金曜日午後5時26分）

>変更：

> *翻訳ステータスセクションを追加しました

> *その他のチェックアウトセクションを追加

> *プライバシーセクションを追加しました

> *インデックスを追加しました

> *ソフトウェアステータスサブセクションを追加しました

> *他の反Googleキャンペーンセクションを追加しました

>> *廃止されたサブセクションを追加しました

>> *進行中のサブセクションを追加しました

> *ソースセクションを追加しました

> *ダウンロードリンクセクションを追加しました

> *ファイル情報セクションを更新しました

> *ファイル履歴セクションを更新しました

> *バージョン2で他の変更はありません

バージョン3（2021年2月24日水曜日午後7時56分）

>変更：

> *インデックスを更新しました

> * degoogleアイコンと新しいGitHub組織を参照しました

> *新しい記事へのリンクを追加しました

> *他の引数に対抗するセクションを追加しました

>> *便利なサブセクションを追加しました

>> *なぜわざわざサブセクションを追加しました

>> *他のサブセクションを追加しました

> *一部のデータを更新しました

> *ファイル情報セクションを更新しました

> *ファイル履歴セクションを更新しました

> *バージョン3で他の変更はありません

バージョン4（2021年2月25日木曜日午後9時31分）

>変更：

> * 10の新しい記事へのリンクを追加しました

> *デグーグルの経験についてのセクションを追加しました

> *インデックスを更新しました

> *ファイル情報セクションを更新しました

> *ファイル履歴セクションを更新しました

> *バージョン4で他の変更はありません

バージョン5（2021年4月9日金曜日午後6時2分）

_最近、私からの反Google運動に対する更新が不足しています。私は、1か月以上の休止の後にそれに戻るよう取り組んでいます。_

>変更：

> *タイトルセクションを更新しました

> *インデックスを更新しました

> *言語リストを更新しました：リンクを修正し、サポートされる言語を追加しました

> *記事のステータスセクションを更新し、4つのフォークリンクを追加しました

> *ソフトウェアステータスセクションを更新しました

> * Go isevilセクションを追加しました

> * DRMの使用法セクションを追加しました

> *一般的な誤解のセクションを追加しました

>> * Googleはインターネットのサブセクションではないことを追加しました

> * Internet Explorer6とChromeのセクションを追加しました

>> *ブレイブサブセクションの問題を追加しました

> *偽のプライバシーの削除を追加しました

> *オープンソースを部分的なサブセクションにすることはできませんを追加しました

> * Oxymoronサブセクションを追加しました

> *パフォーマンスの悪いセクションを追加しました

> *悪いプロジェクト管理セクションを追加しました

> *サービスの恐ろしいまたはモデレートなしのセクションを追加しました

> * Astroturfingセクションを追加しました

> *違法で非倫理的な商慣行のセクションを追加しました

> *ヨーロッパ内サブセクションを追加

>> *北米のサブセクションを追加

>> *論争のサブセクションを追加しました

> * Googleは自動化されたセクションを追加しました

> * Androidセクションを追加しました

> *ヘルプセクションに小さなアクションを追加しました

> * Untrustableセクションを追加しました

> *スポンサー情報セクションを追加しました

> *フッターを更新しました

> *ファイル情報セクションを更新しました

> *ファイル履歴セクションを更新しました

> *バージョン5で他の変更はありません

バージョン6（2021年4月18日日曜日午後4時18分）

>変更：

> *インデックスを更新しました

> *新しい概要の説明を追加しました

> *記事のステータス情報を更新しました

> *新しいGoogleFLoC記事へのリンクを追加しました

> * Wuest 3n FuchsDegoogleの記事とその一般情報へのリンクを追加しました

> *ファイル情報セクションを更新しました

> *ファイル履歴セクションを更新しました

> *バージョン6で他の変更はありません

バージョン7（近日公開）

>変更：

> *近日公開

> *バージョン7で他の変更はありません

バージョン8（近日公開）

>変更：

> *近日公開

> *バージョン8で他の変更はありません

バージョン9（近日公開）

>変更：

> *近日公開

> *バージョン9で他の変更はありません

バージョン10（近日公開）

>変更：

> *近日公開

> *バージョン10で他の変更はありません

バージョン11（近日公開）

>変更：

> *近日公開

> *バージョン11で他の変更はありません

バージョン12（近日公開）

>変更：

> *近日公開

> *バージョン12で他の変更はありません

***

##フッター

このファイルの終わりに達しました

（[トップに戻る]（＃Top）| [GitHubに戻る]（https://github.com））

### EOF

***
