***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle ang iyong buhay

Ito ang pangunahing artikulo ng degoogling para sa pangkalahatang impormasyon ng degoogling at isang link sa iba pang mga artikulo.

[Tingnan ang listahan bilang isang samahan ng GitHub] (https://github.com/Degoogle-your-life)

***

_ Basahin ang artikulong ito sa ibang wika: _

** Kasalukuyang wika ay: ** `English (US)` _ (maaaring kailanganing iwasto ang mga salin upang ayusin ang Ingles na papalit sa tamang wika) _

_🌐 Listahan ng mga wika_

** Pinagsunod-sunod ni: ** `A-Z`

[Hindi magagamit ang mga pagpipilian sa pag-uuri] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanian | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) Arabe | [hy հայերեն] (/. github / README_HY.md) Armenian | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijani | [eu Euskara] (/. github /README_EU.md) Basque | [be Беларуская] (/. Github / README_BE.md) Belarusian | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnian | [bg български] (/. Github / README_BG.md) Bulgarian | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chinese (Pinasimple) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chinese (Tradisyunal) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Croatian | [cs čeština] (/. Github / README_CS .md) Czech | [da dansk] (README_DA.md) Danish | [nl Nederlands] (/. github / README_ NL.md) Dutch | [** en-us English **] (/. github / README.md) English | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonian | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finnish | [fr français] (/. github / README_FR.md) Pranses | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galician | [ka ქართველი] (/. github / README_KA) Georgian | [de Deutsch] (/. github / README_DE.md) Aleman | [el Ελληνικά] (/. github / README_EL.md) Greek | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [siya ay nagsulat] (/. github / README_HE.md) Hebrew | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hungarian | [ay Íslenska] (/. github / README_IS.md) Icelandic | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Icelandic | [ga Gaeilge] (/. github / README_GA.md) Irish | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japanese | [jw Wong jawa] (/. github / README_JW.md) Java | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-southern 韓國 語] (/. github / README_KO_SOUTH.md) Koreano (Timog) | [ko-hilaga 문화어] (README_KO_NORTH.md) Koreano (Hilaga) (HINDI PA NAKASALIN) | [ku Kurdî] (/. github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kyrgyz | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lithuanian | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxembourgish | [mk Македонски] (/. github / README_MK.md) Macedonian | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltese | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolian | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Burmese) | [ne नेेपल]] (/. github / README_NE.md) Nepali | [walang norsk] (/. github / README_NO.md) Norwegian | [o ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persian [pl polski] (/. github / README_PL.md) Polish | [pt português] (/. github / README_PT.md) Portuguese | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Walang mga magagamit na wika na nagsisimula sa titik Q | [ro Română] (/. github / README_RO.md) Romanian | [ru русский] (/. github / README_RU.md) Russian | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scots Gaelic | [sr Српски] (/. github / README_SR.md) Serbiano | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovak | [sl Slovenščina] (/. github / README_SL.md) Slovenian | [so Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spanish | [su Sundanis] (/. github / README_SU.md) Sundan | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Suweko | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Turkish | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukrainian | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamese | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi י:05]] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Magagamit sa 110 mga wika (108 kung hindi binibilang ang Ingles at Hilagang Korea, dahil ang Hilagang Korea ay hindi pa naisasalin [Basahin ang tungkol dito] (/ OldVersions / Korean (North ) /README.md))

Ang mga pagsasalin sa mga wika maliban sa Ingles ay isinalin sa makina at hindi pa tumpak. Walang mga error na naayos pa noong Pebrero 5 2021. Mangyaring iulat ang mga error sa pagsasalin [dito] (https://github.com/seanpm2001/Degoogle-your-life/issues/) tiyaking i-backup ang iyong pagwawasto sa mga mapagkukunan at gabayan ako , dahil hindi ko alam ang mga wika maliban sa Ingles na mabuti (balak kong makakuha ng tagasalin sa kalaunan) mangyaring banggitin [wikipedia] (https://en.wiktionary.org) at iba pang mga mapagkukunan sa iyong ulat. Ang kabiguang gawin ito ay magreresulta sa isang pagtanggi sa pagwawasto ng pagwawasto.

Tandaan: dahil sa mga limitasyon sa interpretasyon ng GitHub ng markdown (at halos lahat ng iba pang pagbibigay-kahulugan sa markdown na batay sa web) i-redirect ka sa isang magkahiwalay na file sa isang hiwalay na pahina na hindi ang aking pahina sa profile na GitHub. Ire-redirect ka sa [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), kung saan naka-host ang README.

Ang mga pagsasalin ay tapos na sa Google Translate dahil sa limitado o walang suporta para sa mga wikang kailangan ko sa ibang mga serbisyo sa pagsasalin tulad ng DeepL at Bing Translate (medyo nakakatawa para sa isang kampanya laban sa Google) Nagsusumikap ako sa paghahanap ng isang kahalili. Sa ilang kadahilanan, ang pag-format (mga link, divider, bolding, italics, atbp.) Ay ginulo sa iba't ibang mga pagsasalin. Nakakapagod na ayusin, at hindi ko alam kung paano ayusin ang mga isyung ito sa mga wikang may mga character na hindi pang-latin, at kanan sa kaliwang wika (tulad ng Arabe) na kailangan ng dagdag na tulong sa pag-aayos ng mga isyung ito

Dahil sa mga isyu sa pagpapanatili, maraming mga pagsasalin ang wala sa panahon at gumagamit ng isang hindi napapanahong bersyon ng 'README` na file ng artikulo. Kailangan ng tagasalin. Gayundin, hanggang Abril 9, 2021, tatagal ako ng ilang sandali upang gumana ang lahat ng mga bagong link.

***

## Index

[00.0 - Pamagat] (# Degoogling --- Degoogle-your-life)

> [00.1 - Index] (# Index)

[01.0 - Pangunahing paglalarawan] (# Pangunahing-paglalarawan)

> [01.1 - Repository header] (# Degoogle-your-life)

> [01.2 - Pangkalahatang-ideya ng paglalarawan ng Wuest3NFuchs] (# Pangkalahatang-ideya ng Wuest3nFuchs)

>> [01.2.1 - Ano ang ibig sabihin nito?] (# What-does-it-mean - by-Wuest3nFuchs)

>> [01.2.2 - Bakit Degoogle?] (# Bakit-Degoogle - ni-Wuest3nFuchs)

[02.0 - Mga Artikulo] (# Mga Artikulo)

[03.0 - Privacy] (# Privacy)

[04.0 - Iba pang mga kampanya laban sa Google] (# Iba pang-kontra-Google-kampanya)

> [04.0.1 - Natapos] (# Natapos)

> [04.0.2 - Nagpapatuloy] (# Nagpapatuloy)

[05.0 - Pagtutol sa iba pang mga argumento] (# Counter-other-arguments)

> [05.0.1 - Convenience] (# Convenience)

> [05.0.2 - Bakit ito mahalaga? Huli na ang lahat] (# Bakit-ba't-bagay, -its-too-late-anyways)

> [05.0.3 - Iba pa] (# Iba pa)

[06.0 - Mga Pinagmulan] (# Mga Pinagmulan)

[07.0 - Mga link sa pag-download] (# Mga download-link)

[08.0 - Ang aking degoogling karanasan] (# Aking-degoogling-karanasan)

> [08.1 - Ano ang inilipat ko mula sa] (# Ano-I-lumipat-mula sa)

> [08.2 - Mga Produkto na hindi pa rin ako makakalayo] (# Mga Produkto-I-hindi pa rin-makaka-malayo)

[09.0 - Iba pang mga bagay na dapat suriin] (# Iba pang-mga bagay-upang-mag-check-out)

[10.0 - Impormasyon ng file] (# File-info)

> [10.1 - Katayuan ng software] (# Software-status)

> [10.2 - Impormasyon ng sponsor] (# Impormasyon sa Sponsor)

[11.0 - Kasaysayan ng file] (# Kasaysayan ng file)

[12.0 - Footer] (# Footer)

***

## Pangunahing paglalarawan

[Mula sa Wikipedia: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

Ang kilusang DeGoogle (tinatawag ding kilusang de-Google) ay isang kampanya sa katuturan na nagsimula habang hinihimok ng mga aktibista sa privacy ang mga gumagamit na ihinto nang buong paggamit ng mga produkto ng Google dahil sa lumalaking pag-aalala tungkol sa privacy tungkol sa kumpanya. Ang termino ay tumutukoy sa pagkilos na aalisin ang Google sa buhay ng isang tao. Tulad ng lumalaking bahagi ng merkado ng higanteng internet ay lumilikha ng kapangyarihan ng monopolistik para sa kumpanya sa mga digital na puwang, ang pagtaas ng bilang ng mga mamamahayag ay napansin ang kahirapan upang makahanap ng mga kahalili sa mga produkto ng kumpanya.

** Kasaysayan **

Noong 2013, sinabi ni John Koetsier ng Venturebeat na ang tablet na batay sa Kindle Fire sa Amazon ay "isang de-Google-ized na bersyon ng Android." Noong 2014 si John Simpson ng US News ay nagsulat tungkol sa "karapatang kalimutan" ng Google at iba pang mga search engine. Noong 2015, nagsulat si Derek Scally ng Irish Times ng isang artikulo tungkol sa kung paano "De-Google ang iyong buhay." Noong 2016 si Kris Carlon ng Android Iminungkahi ng awtoridad na ang mga gumagamit ng CyanogenMod 14 ay maaaring "de-Google" ng kanilang mga telepono, dahil ang CyanogenMod ay gumagana nang maayos nang wala rin ang mga Google app. Noong 2018 si Nick Lucchesi ng Inverse ay nagsulat tungkol sa kung paano isinusulong ng ProtonMail kung paano "ma-ganap na ma-de-Google-fy ang iyong buhay." Sumulat si Brendan Hesse ng Lifehacker ng isang detalyadong tutorial tungkol sa "pag-quit sa Google." Sinabi ng mamamahayag ng Gizmodo na si Kashmir Hill na na-miss niya ang mga pagpupulong at nahihirapang mag-organisa ng mga meet up nang hindi ginagamit ang Google Calendar. Noong 2019, nagbigay ang Huawei ng isang refund sa mga may-ari ng telepono sa Pilipinas na pinigilan ang paggamit ng mga serbisyong ipinagkakaloob ng Google dahil kakaunti ang mga kahalili na umiiral na ang kawalan ng mga produkto ng kumpanya na ginawang normal na gamitin ang normal na internet.

***

# Degoogle-iyong-buhay
Isang repository para sa pangkalahatang impormasyon ng degoogling at mga link sa aking iba pang mga degoogling repository.

***

## Pangkalahatang-ideya ng Wuest3nFuchs

Isang mas mahusay na paglalarawan, na ibinigay ng [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - pinagmulan: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Ano ang ibig sabihin nito? ni Wuest3nFuchs

Ang ibig sabihin ng Degoogling ay ihinto ang paggamit ng anumang bagay na pag-aari ng Google, anumang ginawa ng Google. Pinag-uusapan ko ang tungkol sa kanilang search engine, kanilang serbisyo sa mail (Gmail), Youtube, atbp.

### Bakit Degoogle? ni Wuest3nFuchs

Ang Google ay isa sa pinakamakapangyarihang kumpanya sa mundo ngayon. Nag-imbak sila ng isang malaking halaga ng impormasyon sa ating lahat. Ang ilan ay magtatalo na ang aming impormasyon ay ligtas sa kanila dahil alam nila kung paano ito protektahan. Ngunit hindi ito totoo. Ang Google ay na-penetrate dati at malalampasan ito sa hinaharap. Siguro hindi ng ilang script kiddie ngunit magagawa ito ng isang state ng bansa. Nag-iimbak ang Google ng personal na impormasyon sa ating lahat sapagkat ito ang paraan upang kumita sila.

Sine-scan nila ang aming mga email, iniimbak ang hinahanap namin kapag ginagamit namin ang kanilang search engine, kung anong mga video ang pinapanood namin sa Youtube. Ganito nila kami tina-target at bumuo ng isang profile sa amin upang maipakita sa amin ang ilang ad batay sa pinag-usapan namin sa aming matalik na kaibigan upang maipakita nila sa amin ang isang ad para sa isang bagay na kailangan namin, ngunit ito ay masyadong katakut-takot. Salamat kay G. Snowden alam namin ngayon na ibinahagi ng Google ang aming personal na impormasyon sa NSA sa ilalim ng program na tinatawag na ** "PRISM" **.


Sa hinaharap may isang taong may kakayahang mag-access sa lahat ng impormasyong iyon at sinisiguro ko sa iyo na may talagang masamang magaganap. Upang maiwasan na mangyari iyon, dapat mong simulan ang Degoogling ngayon din. Gayundin hindi ka dapat gumamit ng mga produkto ng isang kumpanya na nagbabahagi ng iyong data sa ** NSA **. Dapat mong itigil ang lahat ng ito sa pamamagitan ng pag-degoogle.

** Kung magagawa ito ng ibang tao, magagawa mo rin ito. **

[Magbasa nang higit pa dito] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Ang isang link sa tinidor ay kasalukuyang hindi nakalista, dahil hindi ko pagmamay-ari ang lalagyan na ito nang buo, at nais na itaguyod ang iba pang mga mapagkukunan. Makakasarili na mag-link sa sarili kong https://github.com/Degoogle-your-life/Degoogle! ->

***

## Mga Artikulo

### Katayuan ng artikulo

_Lahat ng mga artikulo ay kasalukuyang gumaganap at nangangailangan ng napakalaking pagpapabuti. Pinapayagan ang mga mungkahi at pag-aayos._

_Sang Abril 18th 2021 ng 4:09 ng hapon, karamihan sa mga artikulo ay hindi pa nasisimulan. Nagtatrabaho ako sa paghahanap ng oras at pagsisikap upang simulan ang mga ito._

[Bakit mo dapat itigil ang paggamit ng Google Chrome] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Chrome) <! - 1! ->

[Itigil ang paggamit ng ChromeBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Itigil ang paggamit ng WideVine DRM / Oras na upang i-cut ang WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Bakit mo dapat itigil ang paggamit ng ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Alternating mula sa YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Ihinto ang Googling, bakit dapat mong ihinto ang paggamit sa Google Search] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[Bakit mo dapat itigil ang paggamit ng Gmail] (https://github.com/seanpm2001/Bakit-you-should-stop-using-GMail) <! - 7! ->

[Bakit mo dapat itigil ang paggamit ng Android] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Android) <! - 8! ->

[Bakit mo maiiwasan ang Google Amp] (https://github.com/seanpm2001/Bakit-you-should-avoid-Google-AMP) <! - 9! ->

[Bakit mo dapat itigil ang paggamit ng Google Drive] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Drive) <! - 10! ->

[Bakit mo dapat itigil ang paggamit ng Google Maps at Google Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Hey Google, stop] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Itigil ang pagbabasa mula sa mga libro ng Google / Play] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Ihinto ang paggamit sa Google Classroom] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Bakit mo dapat itigil ang paggamit ng Google Translate] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Translate) <! - 15! ->

[Bakit mo dapat itigil ang paggamit ng iyong (mga) Google Account] (https://github.com/seanpm2001/Why-you-should-snangungunang paggamit ng Google-Mga Account) <! - 16! ->

** Mga bagong artikulo na isusulat sa lalong madaling panahon: **

[Bakit mo dapat itigil ang paggamit ng Gerrit] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Gerrit) <! - 17! ->

[Bakit mo dapat itigil ang paggamit ng Google Analytics (ang imbakan ay nasira sa aking pagtatapos ng Miyerkules, Pebrero 242121 ng 4:13 pm)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics) <! - 18! ->

<! - Work divider! ->

[Bakit mo dapat itigil ang paggamit ng Google AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Bakit mo dapat itigil ang paggamit ng Google One] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-One) <! - 20! ->

[Bakit mo dapat itigil ang paggamit ng Google+ (hindi na ginagamit)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Bakit mo dapat itigil ang paggamit ng Google Play Store] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Bakit mo dapat itigil ang paggamit ng Google Docs] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Docs) <! - 23! ->

[Bakit mo dapat itigil ang paggamit ng Google Slides] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Slides) <! - 24! ->

[Bakit mo dapat itigil ang paggamit ng Google Sheets] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Sheets) <! - 25! ->

[Bakit mo dapat itigil ang paggamit ng Google Forms] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Forms) <! - 26! ->

[Bakit mo dapat itigil ang paggamit ng Google Cardboard] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Bakit mo dapat itigil ang paggamit ng Google Messages] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Bakit mo dapat itigil ang paggamit ng Google Material Design] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Bakit mo dapat itigil ang paggamit ng Google Glass / Salamin] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Bakit mo dapat itigil ang paggamit ng Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Bakit mo dapat itigil ang paggamit ng GBoard] (https://github.com/seanpm2001/Bakit-you-should-stop-using-GBoard) <! - 32! ->

[Bakit mo dapat itigil ang paggamit ng Google Home] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Home) <! - 33! ->

[Bakit mo dapat itigil ang paggamit ng Google Nest] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Nest) <! - 34! ->

[Bakit mo dapat itigil ang paggamit ng Google Hangouts (hindi na ginagamit)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Bakit mo dapat itigil ang paggamit ng Google Duo] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Duo) <! - 36! ->

[Bakit mo dapat itigil ang paggamit ng Google Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Bakit mo dapat itigil ang paggamit ng Google Blockly] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Blockly) <! - 38! ->

[Bakit mo dapat itigil ang paggamit ng Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Bakit mo dapat itigil ang paggamit ng Googles Go programming language] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Bakit mo dapat itigil ang paggamit ng wika ng programa ng Googles Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Bakit mo dapat itigil ang paggamit ng format ng imahe ng Googles WebP] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Bakit mo dapat itigil ang paggamit ng format ng video ng Googles WebM] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Bakit mo dapat itigil ang paggamit ng Google Video] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Video) <! - 44! ->

[Bakit mo dapat itigil ang paggamit ng Google Sites (klasiko)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Bakit mo dapat itigil ang paggamit ng Google Sites ("Bago")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Bakit mo dapat itigil ang paggamit ng Google Pay] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Pay) <! - 47! ->

[Bakit mo dapat itigil ang paggamit ng Android Pay] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Android-Pay) <! - 48! ->

[Bakit mo dapat itigil ang paggamit ng Google VPN (oxymoron)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Bakit mo dapat itigil ang paggamit ng Google Photos] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Photos) <! - 50! ->

[Bakit mo dapat itigil ang paggamit ng Google Calendar] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Calendar) <! - 51! ->

[Bakit mo dapat itigil ang paggamit ng VirusTotal (dahil pag-aari ito ng Google mula noong Setyembre 2012] (https://github.com/seanpm2001/Bakit-you-should-stop-using-VirusTotal) <! - 52! - >

[Bakit mo dapat itigil ang paggamit ng Google Fi] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Fi) <! - 53! ->

[Bakit mo dapat itigil ang paggamit ng Google Stadia] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Stadia) <! - 54! ->

[Bakit mo dapat itigil ang paggamit ng Google Keep] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Keep) <! - 55! ->

[Bakit mo dapat itigil ang paggamit ng Google Base] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Base) <! - 56! ->

[Bakit mo dapat itigil ang pakikilahok sa Google Summer of Code] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Bakit mo dapat itigil ang paggamit ng Google Camera] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Camera) <! - 58! ->

[Bakit mo dapat itigil ang paggamit ng Google Calculator (maaaring mukhang matindi, ngunit dapat mong degoogle mula sa lahat, napakadali na kahalili)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Calculator) <! - 59! ->

[Bakit mo dapat itigil ang paggamit ng mga Google Survey + gantimpala] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Bakit mo dapat itigil ang paggamit ng Google Drawings] (https://github.com/seanpm2001/Bakit-you-should-stop-using-Google-Drawings) <! - 61! ->

[Bakit mo dapat itigil ang paggamit ng Tenor (site ng GIF, pagmamay-ari ng Google mula pa noong 2019)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Ano ang FLoC - Bakit mo maiiwasan ang Googles malaking problema sa FLoCing (ihinto ang paggamit sa Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Kabuuang mga artikulo: ** `63`

** Artikulo [roadmap AB] (DegoogleCampaign_2021Roadmap_Part1.md) (hanggang Marso 12th 2021) 2 araw na pahinga **

** Artikulo [roadmap BB] (DegoogleCampaign_2021Roadmao_Part2.md) (hanggang sa? 2021) 2 araw na pahinga **

Katayuan ng artikulo

Ang lahat ng mga artikulo ay kasalukuyang gumaganap at nangangailangan ng napakalaking pagpapabuti. Pinapayagan ang mga mungkahi at pag-aayos.

** Forks **

Pagpapalawak ng aking network ng Degoogle, at pagdaragdag ng ilang kadalian sa pag-access, at mga pagsigaw sa komunidad.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Forked mula sa: [https://github.com/wacko1805/Fossapps Ingles(https://github.com/wacko1805/Fossapps) (English)

2. [Mga link sa Privacy] (https://github.com/Degoogle-your-life/Privacy-links) | Forked mula sa: [https://github.com/Arturro43/privacy-linksopito(https://github.com/Arturro43/privacy-links) (Polish)

3. [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Forked mula sa: [https://github.com/LinuxCafeFederation/Delightful-Privacy Ingles(https://github.com/LinuxCafeFederation/Delightful-Privacy) (English)

4. [Mga Blocklist] (https://github.com/Degoogle-your-life/blocklists) | Forked mula sa: [https://github.com/jmdugan/blocklists Ingles(https://github.com/jmdugan/blocklists) (English)

5. [Degoogle, ni Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Forked mula sa: [https://github.com/Wuest3nFuchs/Degoogle Ingles(https://github.com/Wuest3nFuchs/Degoogle) (English)

** Kaugnay **

[Degoogled Android phone Virtual Machine research] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Tingnan din:**

[Kritika ng Google sa Wikipedia] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[The Google Graveyard (slaybygoogle.com) - isang pinagsunod-sunod na listahan ng 224+ na mga produkto na pumatay sa Google] (https://killedbygoogle.com/)

> [Link ng GitHub] (https://github.com/codyogden/killedbygoogle)

[Alphabet worker union - Ang bagong unyon ng mga manggagawa sa Google na may higit sa 800 mga miyembro] (https://alphabetworkersunion.org/people/our-union/)

[Ayaw mong makihati sa itlog ng dinosaur easter? Saklaw ka ng website na ito] (https://chromedino.com/)

***

## Pagkapribado

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico- Children-privacy-school-chromebook-lawsuit)[sopito(https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https:// Medium.com/digiprivacy/i-stopping-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acqu acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/site/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument # Critikismo) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -essay-sample / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- of-data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -your-personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -monetizes-and) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- koleksyon-nagsiwalat.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ health-fitness-data-privacy /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-koleksyon-sa-edukasyon-chromebooks [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-government-google-data-collection-demanda-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)[o Ingles(https://en.wikipedia.org/wiki/2018_Google_data_breach)[mopito(https://moz.com /blog/where-does-google-draw-the-data-collection-line)[eiwan(https://mashable.com/article/google-android-data-collection-study/)[sopito(https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)[o Ingles(https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -claims-on-ngalan-ng-5-m illion-iphone-gumagamit) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/)[ropito(https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/)[iopito(https://www.cbsnews.com/news/google-edukasyon-spies-on-collects- data-on-milyon-milyong-bata-alegasyon-demanda-bagong-mexico-abogado-heneral /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / teknolohiya / google-yout ube-fine-ftc.html) [y] (https:// Medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : // Medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Maaari akong magpatuloy na may katibayan ng ito, ngunit ito ay tumagal ng mahabang oras upang hanapin at mapunta sa lahat ng mga ito mga artikulo)

Ang privacy sa mga produkto ng Google ay palaging masama, dahil sa lahat ng mga produkto ng Google na naglalaman ng spyware.

Hindi mahalaga kung ano ang gagawin mo, kapag gumagamit ka ng Google, lahat ng iyong sensitibong personal na data ay ipinapadala sa Google at sa iba pa. Nakita rin ang Google na dumaan sa mga bukas na programa. Halimbawa, mula sa personal na karanasan (sa Firefox) na may bukas na tab na YouTube na hindi ko binisita, nanuod ako ng maraming mga video offline (VLC Media Player) Nang maglaon nang suriin ko ang mga rekomendasyon, halos lahat ng napanood ko. Walang duda na sila rin ay tiktik sa iba pang mga programa.

Sa Chrome (at maraming iba pang mga browser) isang mode na incognito ay naroroon. Sa Chrome, ang mode na ito ay walang saysay, dahil ang Google ay magmimina pa rin ng iyong data. Kahit na patayin mo ang data mining / pagsubaybay, at paganahin ang signal na "huwag subaybayan", sorpresa ang sorpresa, minimimim pa rin ng Google ang iyong data.

Kung sa palagay mo wala kang maitago, ** ikaw ay ganap na mali **. Ang argument na ito ay na-debunk ng maraming beses:

[Sa pamamagitan ng Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Sinabi ni Edward Snowden na "Ang pagtatalo na wala kang pakialam sa karapatan sa privacy dahil wala kang maitatago ay hindi naiiba kaysa sabihin na wala kang pakialam sa malayang pagsasalita sapagkat wala kang sasabihin." Kapag sinabi mong, ' Wala akong maitago, 'sinasabi mo,' Wala akong pakialam sa karapatang ito. 'Sinasabi mo,' Wala akong karapatang ito, dahil umabot sa puntong kailangan kong bigyang katwiran Ito. 'Kung paano gumana ang mga karapatan, dapat bigyang katwiran ng gobyerno ang pagpasok sa iyong mga karapatan. "

2. Inilahad ni Daniel J. Solove sa isang artikulo para sa The Chronicle of Higher Education na tinututulan niya ang argumento; sinabi niya na ang isang gobyerno ay maaaring leak impormasyon tungkol sa isang tao at maging sanhi ng pinsala sa taong iyon, o gumamit ng impormasyon tungkol sa isang tao upang tanggihan ang pag-access sa mga serbisyo kahit na ang isang tao ay hindi aktwal na gumawa ng maling gawain, at ang isang gobyerno ay maaaring maging sanhi ng pinsala sa personal na buhay ng isang tao sa pamamagitan ng paggawa ng mga pagkakamali. Isinulat ni Solove na "Kapag direktang nakikipag-ugnayan, maaaring makulong ang walang-pagtatago na argumento, sapagkat pinipilit nito ang debate na ituon ang pansin sa makitid nitong pag-unawa sa privacy. Ngunit nang harapin ang kasaganaan ng mga problema sa privacy na isinangkot ng pagkolekta ng data ng gobyerno at paggamit nang lampas sa pagsubaybay at ang pagsisiwalat, ang hindi pagtatago na pagtatalo, sa huli, ay walang masabi. "

3. Si Adam D. Moore, may-akda ng Mga Karapatan sa Pagkapribado: Moral at Ligal na Mga Pundasyon, pinagtatalunan, "ito ang pananaw na ang mga karapatan ay lumalaban sa gastos / benepisyo o pang-uri na uri ng mga argumento. Dito tinatanggihan namin ang pananaw na ang mga interes sa privacy ay ang mga uri ng mga bagay na maaaring ipagpalit para sa seguridad. " Inilahad din niya na ang pagsubaybay ay maaaring makaapekto sa ilang mga pangkat sa lipunan batay sa hitsura, lahi, sekswalidad, at relihiyon.

4. Si Bruce Schneier, isang dalubhasa sa computer security at cryptographer, ay nagpahayag ng pagtutol, na binanggit ang pahayag ni Cardinal Richelieu na "Kung bibigyan ako ng anim na linya na sinulat ng kamay ng pinaka matapat na tao, mahahanap ko ang isang bagay sa kanila upang mabitay siya", na tumutukoy sa kung paano makahanap ang isang gobyerno ng estado ng mga aspeto sa buhay ng isang tao upang mausig o ma-blackmail ang indibidwal na iyon. Nagtalo rin si Schneier na "Napakaraming maling nailalarawan sa debate bilang 'seguridad kumpara sa privacy.' Ang totoong pagpipilian ay ang kalayaan laban sa kontrol. "

5. Tinantya ni Harvey A. Silverglate na ang karaniwang tao, sa average, na hindi namamalayan ay gumagawa ng tatlong mga felonies sa isang araw sa US.

6. Si Emilio Mordini, pilosopo at psychoanalyst, ay nagtalo na ang argumento na "walang maitatago" ay likas na kabalintunaan. Ang mga tao ay hindi kailangang magkaroon ng "isang bagay upang maitago" upang maitago ang "isang bagay". Ang nakatago ay hindi kinakailangang nauugnay, inaangkin ni Mordini. Sa halip, pinagtatalunan niya ang isang malapit na lugar na maaaring parehong nakatago at limitado sa pag-access ay kinakailangan dahil, sa pagsasalita ng sikolohikal, tayo ay naging indibidwal sa pamamagitan ng pagtuklas na maaari nating maitago ang isang bagay sa iba.

7. Inilahad ni Julian Assange na "Wala pang sagot sa mamamatay. Si Jacob Appelbaum (@ioerror) ay may matalinong tugon, na tinatanong sa mga taong nagsabi nito upang maibigay sa kanya ang kanilang telepono na naka-unlock at hilahin ang kanilang pantalon. 'well, if you're so boring then we cannot be pakikipag-usap sa iyo, at hindi dapat ang iba pa', ngunit sa pilosopiya, ang totoong sagot ay ito: Mass surveillance is a mass struktural pagbabago. Kapag ang lipunan ay naging masama, ito ay pagpunta sa upang isama ka, kahit na ikaw ang pinaka masungit na tao sa mundo. "

8. Si Ignacio Cofone, propesor ng batas, ay nagtatalo na ang pagtatalo ay nagkakamali sa sarili nitong mga termino sapagkat, tuwing isiwalat ng mga tao ang nauugnay na impormasyon sa iba, isiniwalat din nila ang hindi kaugnay na impormasyon. Ang hindi kaugnay na impormasyon na ito ay may mga gastos sa privacy at maaaring humantong sa iba pang mga pinsala, tulad ng diskriminasyon.

***

## Iba pang mga kampanya laban sa Google

Ito ay isang listahan ng iba pang mga kilalang kampanya laban sa Google. Hindi kumpleto ang listahang ito. Maaari kang tumulong sa pamamagitan ng pagpapalawak nito.

### Patay na

[Scroogled - Ni Microsoft (Nobyembre 2012 hanggang 2014)] (https://en.wikipedia.org/wiki/Scroogled)

_Wala pang ibang mga entry sa ngayon._

### Nagpapatuloy

_ Ang listahang ito ay kasalukuyang walang laman._

***

## Pagtutol sa iba pang mga argumento

Mayroong ilang mga argumento na ginagawa ng mga tao upang bigyang-katwiran ang Google. Ang isa sa unang pangunahing isa ay na-debunk na [dito] (# Privacy) ngunit narito ang ilang iba pa:

### Kaginhawaan

Oo, mukhang maginhawa ang mga produkto ng Google. Gayunpaman, ipinagpapalit mo ang lahat ng mabuti para sa kaginhawaan, kabilang ang seguridad, privacy, at pagiging maaasahan. Ang Google ay naging tamad sa paglipas ng mga taon, at ang kanilang mga server ay mas lalo na bumababa. Sa ngayon, ang mga server ng Google ay bumaba nang halos isang oras na 1-2 beses bawat buwan (higit na kapansin-pansin ang YouTube)

Sa kasamaang palad, dahil sa mga lipunan na umaasa sa Google, ang Google ay dumating upang mangibabaw sa Internet, at naghahangad na kontrolin ang higit pa at higit pa. Noong 2012, nang bumaba ang Google ng 5 minuto, naiulat na ** pandaigdigan ** Trapiko sa Internet ** ay bumaba ng 40% ** Ang Google ay madalas na bumaba sa loob ng 1-2 oras, at sa [pagpapaputok ng kanilang pangkat sa etika] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) bukod sa iba pang mga bagay, magiging mas mababa at hindi gaanong maginhawa.

Ang kaginhawaan ay hindi palaging isang magandang bagay. Dapat mong magkaroon ng kamalayan sa kung ano ang nangyayari at maging handa para sa kanilang pagbaba, dahil walang isang paraan upang ang isang server ay hindi bumaba bawat minsan sa isang sandali.

Ang Google ay hindi rin kasing maginhawa tulad ng iniisip mo. Mayroong iba pang mas maginhawang mga site. Ang Google ay malayo sa maginhawa, kapag isinasaalang-alang mo ang kanilang mga random na suspensyon ng account at mga pagwawakas nang walang tugon (maliban kung iguhit mo ang sapat na pansin sa Google twitter account o idemanda sila sa halagang $ 100,000,000 o higit pa) pagkatapos ay sinamantala ka nila, kinulit, pinilit kang sumigaw sa isang unan, kung saan walang makakarinig ng iyong hiyawanpara sa tulong.

### Bakit ito mahalaga, huli na ang lahat

Ito ay isang hindi gaanong karaniwang argumento, ngunit kailangan nito ng paliwanag. Sa kasalukuyang estado, ang karamihan sa mga gobyerno ng daigdig, kasama ang maraming makapangyarihang mga korporasyon ay tila alam ang bawat galaw mo, kaya bakit ka pa mag-abalang lumayo dito? Ang sagot ay simple: ** Karapat-dapat kang mas mahusay **. Kung namamahala ka upang makalayo sa kanila sa puntong ito, mas mahirap para sa kanila na mas subaybayan ang iyong mga paglipat, at makakagawa ka ng isang bagong mas pribadong buhay.

[1 pinagmulan] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Sa pamamagitan ng paraan, binibigyan ko ang aking libreng Reddit award sa post na ito tuwing nakuha ko ito nang higit sa isang linggo ngayon (kasama ang lahat ng 500 ng aking mga libreng barya) upang mas mapalakas ang paksang ito. Sa ngayon, nabigyan ko ang post na ito ng higit sa 14 libreng mga parangal. Hindi ito gaanong malaki, ngunit ang maliliit na bagay ay maaaring gumawa ng malaking epekto, depende sa kung paano ito nakikita, at kanino.

### Iba pa

Wala akong ibang mga argumento sa ngayon.

_Ang listahang ito ay hindi kumpleto_

***

## Mga Pinagmulan

Kopya:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico- Children-privacy-school-chromebook-lawsuit)[sopito(https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https:// Medium.com/digiprivacy/i-stopping-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acqu acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/site/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritika) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -and) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[dopito(https://www.reuters.com/article/us-alphabet- google-privacy-demanda-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks] [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o Ingles(https://en.wikipedia.org/wiki/2018_Google_data_breach)[mopito(https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / teknolohiya / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- claims-on-ngalan-ng-5-milyong-mga-iphone-user) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[eiwan(https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technology / 2014/01 / what-google-can-really-do-with-Nest-or-really-nests-data /) [i] (https://www.cbsnews.com/news/google-edukasyon -spies-on-collects-data-on-milyon-milyong-bata-alegasyon-demanda-bagong-mexico-abogado-heneral /) [v] (https://www.nationalreview.com/2018/04/the- student-data-mining-scandal-under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[yopito(https:// Medium.com/@hansdezwart/during-world-war-ii-we-did -have-something-to-hide-40689565c550) [.] (https:// Medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Iba pang mga mapagkukunan:

[Limang mata Alliance] (https://en.wikipedia.org/wiki/Five_Eyes) [Labing siyam na walumpu't apat] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Mga link sa pag-download

[Kumuha ng Firefox] (https://www.mozilla.org/en-US/fireoks/new/) [Kumuha ng Tor browser] (https://www.torproject.org/download/) [Iba / hindi magagamit] (https : //www.example.com)

***

## Ang aking degoogling na karanasan

Sa wakas nagsimula akong makita ang mga problema sa big tech noong 2018, at nagsimula akong mag-degoogle. Sa mga unang buwan, nakagawa ako ng makabuluhang pag-unlad. Napabagal ito ng sobra mula noon.


### Kung ano ang pinalit ko

Google Chrome -> Firefox / Tor

Paghahanap sa Google -> DuckDuckGo (default) / Ecosia (kapag gusto ko ito) / Bing (bihira)

GMail - ProtonMail (hindi pa ganap na lumilipat)

Google Site -> Pag-host sa sarili (hindi pa ganap na lumilipat)

Google+ -> Hindi gaanong ginamit, tinanggal ang sarili dahil sa sarili nitong pag-shutdown

Google Docs -> Hindi kailanman nagamit, ginagamit ko lang ang Microsoft Word 2013 (bago ang 2019) at LibreOffice (2019-onward) sa halip.

Google Sheets -> Hindi kailanman nagamit, ginagamit ko lang ang Microsoft Excel 2013 (bago ang 2019) at LibreOffice (2019-onward) sa halip.

Google Slides -> Hindi kailanman nagamit, ginagamit ko lang ang Microsoft PowerPoint 2013 (bago ang 2019) at LibreOffice (2019-onward) sa halip.

Mga Guhit ng Google -> Hindi nagamit, Ginagamit ko lang ang LibreOffice (2019-onward) sa halip.

Gerrit -> Hindi kailanman nagamit, gumagamit na lang ako ng GitHub (kasalukuyang default), sa halip ang GitLab, BitBucket, at SourceForge.

Google Photos -> Hindi nagamit

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-kasalukuyan)

Google Maps -> OpenStreetMaps / Apple Maps

Pumunta - Gumagawa ng isang espesyal na pagbubukod, ngunit hindi ginagamit bilang isang functional na wika ng programa

Dart - Gumagawa ng isang espesyal na pagbubukod, ngunit hindi ginagamit bilang isang functional na wika ng programa

Flutter - Gumagawa ng isang espesyal na pagbubukod, ngunit hindi ginagamit bilang isang functional na wika ng pagprograma

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> Hindi kailanman nagamit, nakikita ko itong sobrang katakut-takot

Google Fi -> Hindi kailanman nagamit

Google Calendar -> Hindi kailanman nagamit

Google calculator -> Literal na anumang iba pang calculator app, kahit na isang terminal ng Linux na tumatakbo sa Python mode kung gusto ko ito

Google Nest -> Hindi kailanman nagamit

Google AMP -> Hindi kailanman nagamit

Google VPN -> Hindi kailanman nagamit, isang oxymoron din

Google Pay -> Hindi pa nagamit

Google Summer of Code -> Hindi kailanman lumahok

Tenor -> Iba pang mga site ng GIF, kahit na ang mga GIF ay hindi masyadong mahalaga sa akin. Karaniwan akong nakakakuha ng mga file ng GIF mula sa mga imahe ng DuckDuckGo, Imgur, Reddit, o iba pang mga site.

Blockly -> Hindi na ginagamit, hindi sigurado kung ang Scratch direktang tumakbo nang blockly. Naging isang functional programmer ako noong 2017 pataas, at lumaki sa Scratch.

GBoard -> Ginamit nang isang beses, ngunit inabandona

Google Glass -> Hindi kailanman nagamit, isinasaalang-alang bilang isang bata ngunit nagpasyang huwag makakuha ng isa / gumamit ng isa kung mayroon akong pagpipilian

_Lista ay maaaring hindi kumpleto._

### Mga produktong hindi pa rin ako makakalayo

Hanggang noong ika-25 ng Pebrero 2021, ito ang mga produkto ng Google na pinipigilan ako mula sa ganap na pag-degoogle:

1. YouTube

2. Android

3. Google Play Store

4. GMail (para lamang sa paaralan at ilang mga site)

5. Google Classroom (para lamang sa paaralan)

6. Google Translate

7. Google Account

8. Mga Google Site (dahil lumalabag ang Google sa mga batas ng GDPR (at maaaring harapin ang isa pang € 5,000,000.00 multa hanggang sa maayos nila ito) at pagbawalan ang mga pag-download ng produktong ito)

Nag degoogle ako mula sa lahat ng iba pa.

***

## Go ay masama

Nag-steamroll ang Google sa wika ng programang "Agent!" Na Nakabatay sa 2003 na kasama ang kanilang programang pang-programang `Go` (mula 2009, 6 na taon na ang lumipas) at inangkin na ang kanilang wika ay hindi makakaapekto sa ibang wika. Malubhang pinintasan ang Google para dito, dahil ang kanilang motto na `Huwag maging masama` ay aktibo pa rin sa oras na iyon, at ito ang isa sa maraming mga insidente na nag-retire ng masamang Motto.

Sa huli, ang pag-unlad ng 'Go !` ay tumigil, habang ang `Go` ay naging mas at mas karaniwan. Inangkin ng Google na hindi sila mag-stramroll sa `Go! 'Ngunit sa huli, ginawa nila ito, at nakawala sila dito (mula Abril 9 2021)

[Magbasa nang higit pa tungkol sa Pumunta at kung paano magpalitan dito] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Paggamit ng DRM

Gumagamit ang Google ng DRM (Digital Restrictions Management) sa pamamagitan ng kanilang "serbisyo" na WideVine DRM at iba pang mga form. Ang layunin ng DRM ay upang sirain ang bukas na Internet at bigyan ang mga kumpanya ng monopolistic na kapangyarihan sa mga gumagamit. Dapat mong alisin ang WideVine nang buo, hindi mahalaga ang gastos.

[Magbasa nang higit pa tungkol sa WideVine at mga problema dito] (https://github.com/Degoogle-your-life/Its-time-to-cut-WideVine-DRM)

***

## Karaniwang maling kuru-kuro

Ito ay isang listahan ng ilang mga karaniwang maling kuru-kuro sa mga produkto ng Google.

### Ang Google ay hindi ang Internet

Ang paghahanap sa Google / Google ay hindi ang Internet, ang paghahanap sa Google ay isang search engine lamang, tulad ng kung paano hindi bawat laro para sa isang Nintendo platform ay ginawa ng Nintendo, ngunit lisensyado ng Nintendo, ngunit sa mas malawak na lawak. Kung ang lahat ng mga server ng Googles ay dapat na sabay na winawasak ngayon, ang mga Google Site lamang tulad ng YouTube, Gmail, Google Docs, paghahanap sa Google, atbp ang mawawala, ngunit ang karamihan ng Internet ay nandiyan pa rin (Wikipedia, Stackoverflow, GitHub, lahat ng mga website ng mikropono, NYTimes, Samsung, TikTok, atbp.) maaaring mawala sa kanila ang pag-sign in at pag-andar ng panteknikal ng Google, ngunit gagana pa rin sila (maliban kung hindi sila nai-program na mahina at nakasalalay nang direkta sa Google)

***

## Internet Explorer 6 at Chrome

Ang Google Chrome ay magiging bagong Internet Explorer 6. Nang orihinal na lumabas ang Google Chrome, ang Firefox ang nangingibabaw na browser, at pinatay ang karamihan sa mga marketer ng Internet Explorers (na lumagpas sa 96% bago ang milyon-milyong mga tao ay lumipat sa Firefox at iba pang mga browser) nang Google Chrome lumabas, ang mga tao ay lumipat dahil sa bilis nito at ito ay sa pamamagitan ng Google (na hindi itinuturing na masama sa oras na iyon, dahil ang karamihan sa mga isyu sa privacy ay hindi pa napapansin) Orihinal na iginagalang ng Google Chrome ang mga pamantayan sa web (na kung saan ang ginawa ng Firefox na pumatay sa Internet Explorers na 96% browser markethare) subalit, sa pagtaas ng markethare ng Google Chromes, nagsimulang mag-alis ang Google ng maraming mga tampok, pagdaragdag ng higit pang mga spyware, at tumigil sa pagtanggap ng mga pamantayan sa web, ang Google Chrome ay naging bagong Internet Explorer 6.

Ang pangunahing problema sa ngayon ay ang mga website na Chrome lamang, at hindi gagana sa ibang mga browser, dahil napagpasyahan ng kanilang mga developer na ayaw nila ang ibang 30-40% ng mga gumagamit ng Internet na hindi gumagamit ng Chrome na gumamit ng kanilang site.

Kahit na ang Google mismo ay ginagawa lamang ang kanilang mga site na Chrome. Halimbawa, hihingin ka ng paghahanap sa Google na mag-download ng Chrome ng 3 beses bawat 10 segundo kung nakita mong hindi ka gumagamit ng Google Chrome (kahit na ang iba pang mga browser na batay sa Chromium tulad ng Matapang ay apektado) at ang mga site tulad ng Google Earth ay hindi pinapayagan ang mga gumagamit ng Firefox na gamitin ang kanilang site (hanggang sa 2020) kasama ang Google Translate ay hindi sumusuporta sa pag-input ng boses sa Firefox, at iba pang mga browser na hindi Google Chrome.

### Ang problema sa Matapang

Ang iba pang mga browser na batay sa Chromium, tulad ng Brave at Microsoft Edge ay hindi ganap na malaya sa Google spyware. Karaniwang inirekomenda ng matapang na panig ng komunidad ng privacy, ngunit ang Brave ay isang problema pa rin, dahil gumagamit ito ng Chromium. Ang Internet ay hindi dapat binubuo ng mga browser lamang ng Chromium, dapat mayroong iba't ibang pagpipilian. Matapang ang maling paraan upang pumunta.

[Magbasa nang higit pa tungkol sa degoogling mula sa Google Chrome / Chromium dito] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Magbasa nang higit pa tungkol sa degoogling mula sa ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) dito] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Pag-renew ng privacy ng Faux

Sinusubukan ng Google na sabihin sa mundo na nagmamalasakit sila sa privacy, pagkatapos na huli na. Patuloy nilang inaangkin na nirerespeto nila ang privacy ng gumagamit, ngunit hindi pa rin nila naaayos ang lahat ng kanilang mga problema sa privacy.

### Ang bukas na mapagkukunan ay hindi maaaring maging bahagyang

Ang open source ay hindi maaaring maging bahagyang. Patunay ito ng Google. Ang bawat piraso at byte ng source code ay dapat na nakikita ng publiko, na hindi nakatago kahit isang ika-8 ng isang byte.

Ang mga proyekto tulad ng Android at ChromeOS ay bahagyang bukas na mapagkukunan, ngunit naglalaman ng karamihan ng pagmamay-ari, mga elemento ng spyware.

### Oxymoron

Ang Google VPN ay isang oxymoron. Walang pakialam ang Google tungkol sa privacy, at ang isang Virtual Private Network (VPN) mula sa isang kumpanyang katulad nila ay magiging isa sa pinakamasamang posibleng pagpipilian para sa isang serbisyo sa VPN.

***

## Hindi magandang pagganap

Walang pakialam ang Google tungkol sa pagganap ng kanilang mga produkto ng hindi bababa sa 2017, dahil ang kanilang huling benchmarking software (Google Octane) ay hindi na ipinagpatuloy noong 2017.

***

## Hindi magandang pamamahala ng proyekto

Ang Google ay may isang napaka masamang panloob na system ng pamamahala ng proyekto. Ang ilang mga karaniwang halimbawa ng mga programa na nakakuha ng mas maraming downgrade ay kasama ang Google Duo at YouTube music (dating Google Play Music)

Sa panloob na system ng pag-unlad ng Googles, humantong ang 1 app sa isa pang app na may kalahati ng pag-andar, pagkatapos tatanggalin ang orihinal na app. Pagkalipas ng ilang taon, isang bagong app na may 75% mas kaunting pag-andar ang nagawa, at pagkatapos ang app na may 50% na pag-andar ay tinanggal, na sinusundan ng isang bagong app na may 87.5% ng pagpapaandar na nilikha, pagkatapos ay ang app na may 75% na pagpapaandar ay hindi na ipinagpatuloy , at iba pa.

***

## Kakila-kilabot o walang pagmo-moderate ng mga serbisyo

Ang YouTube ay ang pinakakaraniwang halimbawa sa mundo ng hindi magandang pagmo-moderate na lumilikha ng pinakamasamang platform na mayroon. Tila hindi nakuha ng Google na ang YouTube ay hindi mga bata sa YouTube.

Para sa YouTube, ang nakakainis na pro-Nazi at White Supremacist na nilalaman ay inihatid sa mga gumagamit para sa layunin ng mas maraming oras ng pakikipag-ugnayan at mas maraming pera. Ang Google ay may nagawa rinmga hangal na bagay sa kanilang katamtaman, tulad ng pag-apruba ng isang video ng Christian Anal Sex bilang nilalamang `ginawa para sa mga bata` habang kasabay ng paghihigpit ng edad sa video. Hindi rin gaanong bihirang makakita ng mga ad na pornograpiko o gore na nasa ilalim mismo ng video ng Baby Shark, kasama ang iba`t ibang `ginawa para sa nilalaman ng mga bata.

Ang mga gumagamit ng YouTube ay madalas na nagreklamo tungkol sa hindi magandang pagmo-moderate sa YouTube para sa masamang nilalaman (tulad ng mga halimbawang nakalista sa itaas) habang ang mga gumagamit ay maaaring tanggalin ang kanilang mga video nang walang kadahilanan na walang kakayahang pawalang-bisa, kasama ang mga gumagamit na pinarusahan para sa anumang uri ng pagmumura, kahit na napakaliit na mga kaso tulad ng pagsasabi ng mga `crap` na mga gumagamit ay karaniwang ihinahambing ang YouTube sa [Soviet Union] (https://en.wikipedia.org/wiki/Soviet_Union) sa panahon ng Stalin, dahil sa hindi pantay na mga parusa na ito.

Noong 2021, inihayag ng Google na maglalagay sila ng mga ad sa lahat ng mga video, sa kabila ng pagiging demonyo ng video (upang kumita ang Google, ngunit hindi nilikha ng lumikha) hindi ito masyadong nauugnay sa pagmo-moderate, ngunit mahalagang tandaan.

Ang YouTube ay na-moderate (kahit na napakahirap) ngunit ang serbisyo ng Google ad na ginagawang mas malaki ang kanilang pera ay tila wala sa moderation.

[Magbasa nang higit pa tungkol sa mga isyu sa pagmo-moderate ng YouTube at kung paano humalili mula sa YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Ang mga ad para sa Google Play ay nabuo mula sa mga bukid ng bot, masasabi mo sa parehong mga senaryo ng ad na ginagamit ng daan-daang mga kumpanya na may maliit na pagbabago, at walang kaugnayan sa produkto (karaniwang mga halimbawa: Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City, at libu-libo pa) kasama ang isang booming nakakahamak na kalakaran ng mga ad na nag-aangkin na ang mga gumagamit ay maaaring kumita ng pera sa pamamagitan ng paglalaro ng mga laro, pakikinig ng musika, atbp. Hindi pa nagkomento dito ang PayPal, ngunit halata na ito ay isang scam, na parang makakagawa ka higit sa $ 10,000 sa mas mababa sa 20 segundo sa pamamagitan ng paglalaro ng isang garantisadong laro, walang gagawa ng trabaho at gagawin ito sa halip, na imposible, at ang isang negosyo ay hindi maaaring gumana tulad nito. Ang halatang scam na ito ay lumalakas mula pa noong 2019, at ngayon ang mga bot ng bukid na gumagawa ng mga ad na ito ay nakikipaglaban sa bawat isa sa kanilang sariling mga ad.

Maraming mga anunsiyo ay kahalayan din, at pagtatangka upang makuha ang mga gumagamit (karamihan sa kanila ay mga gumagamit na wala pang 13 taong gulang, o mga bot) na mag-click sa pamamagitan ng pagmamanipula sa sekswal.

Maraming mga app ang gumagamit ng mga bot at astroturf ng kanilang mga produkto, kaya't tuwing isang masamang pagsusuri ang ginawa, magsisimulang mag-post ng 5 star na mga review ang mga medyas na puppet bot account at tatangkaing bawalin ang iyong pintas. [Ginagawa din ito ng Google] (# Astroturfing)

[Magbasa nang higit pa tungkol sa mga isyu sa Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

Pangkalahatang kahulugan [(mula sa Wikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

""
Ang Astroturfing ay isang kasanayan sa pagmamarka ng mga sponsor ng isang mensahe o samahan (hal., Pampulitika, advertising, relihiyoso o mga relasyon sa publiko) upang ito ay magmula na nagmula at sinusuportahan ng mga kalahok sa katuturan. Ito ay isang kasanayan na inilaan upang magbigay ng kredibilidad ng mga pahayag o samahan sa pamamagitan ng paghawak ng impormasyon tungkol sa koneksyon sa pananalapi ng mapagkukunan. Ang term na astroturfing ay nagmula sa AstroTurf, isang tatak ng synthetic carpeting na idinisenyo upang matulad sa natural na damo, bilang isang dula sa salitang "grassroots". Ang implikasyon sa likod ng paggamit ng term na ito ay sa halip na isang "totoo" o "natural" na pagsisikap sa katutubo sa likod ng aktibidad na pinag-uusapan, mayroong isang "pekeng" o "artipisyal" na hitsura ng suporta.
""

Ang Google ay may isang kasaysayan ng astroturfing upang gawin itong tila wala silang ginagawang masama (sa proseso, ang astroturfing ay masama) halimbawa, ang pag-post ng pagpuna sa Google sa isang platform tulad ng Twitter (kung saan mayroon silang account) ay magreresulta sa maraming mga account na mayroon nang ilang sandali ngunit hindi kailanman nai-post bago lumabas at inaangkin na ang sinabi mo ay hindi totoo, at pagkatapos ay inaangkin na ang Google ay ang pinakamahusay na kumpanya, ngunit nagawa sa isang paraan na maaaring hindi halata na ang mga ito ay karamihan sa mga mga tao

***

## Ilegal at hindi etikal na kasanayan sa negosyo

Gumagamit ang Google ng mga iligal at hindi etikal na kasanayan sa negosyo upang mapalawak ang kanilang monopolyo, tulad ng paggamit ng mga haven ng buwis, pag-outsource ng mga trabaho, at pagpapatuloy na gumawa ng mga iligal na aktibidad na nagsasalakay bilang isang gastos sa pagnenegosyo.

### Sa Europa

Madalas na dinemanda ng Europa ang Google, ang pinakamalaking demanda laban sa iligal na pag-uugali sa Android, na nagresulta sa pagtanggap ng Google ng € 5,000,000,000 (katumbas ng $ 5,947,083,703.68 noong Abril 9th ​​2021 pera)

### Sa Hilagang Amerika

Ang Estados Unidos ay hindi pa nakapagbigay ng halos sapat na multa sa Google, kumpara sa Europe € 5,000,000,000 na multa.

### Mga Kontrobersya

Walang pakialam ang Google tungkol sa isang problema hanggang sa lumilikha ito ng isang kontrobersya, pagkatapos ay gagawa sila ng isang hindi magandang pagtatangka upang ayusin ito, sapat lamang para sa kontrobersya na pansamantalang mawala, at ang problema pagkatapos ay lumala nang mas mabilis hanggang sa lumilikha ito ng isa pang kontrobersya, at ang nagpapatuloy ang siklo. Wala lamang silang pakialam sapat upang gumawa ng anumang seryoso tungkol dito.

***

## Ang Google ay awtomatiko

Bilang isang comAng Google ay kadalasang naka-automate, na may mas kaunting moderation kaysa sa automation.

Ang isang kumpanya ay hindi dapat na ganap na awtomatiko. Ang Google ay isang halimbawa nito. Ang katamtaman ay kakila-kilabot kapag ginawa lamang ng AI, ang YouTube ay isang mabuting halimbawa, kahit na sa sobrang ilan (daan-daang, o marahil isang libo) na mga tao na nag-e-moderate sa site, kung saan ito ay tila napakasama na ang karamihan sa kanila ay kailangang makakuha ng therapy habang nagtatrabaho.

***

## Android

Ang Android ay pagmamay-ari ng Google. Bahagi ng Open Handset Alliance (na hindi pa bukas mula sa Android) Ang Android ay naging isa pang monopolyo point para sa Google, at isang napakahirap makatakas.

Ang Android ay naiulat sa home sa Google sa telepono ng hindi bababa sa 10 beses bawat araw, at sa kabila ng pagiging bahagyang bukas na mapagkukunan, kumikilos pa rin ito bilang isang spyware.

Maraming mga proyekto ang nilikha upang kahalili mula sa Android, ngunit nangangailangan ng pag-rooting ng iyong aparato. Hindi na posible ito para sa mga tukoy na teleponong Samsung sa US, dahil sa Knox DRM. Kasama sa mga karaniwang kahalili sa Android ang iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch, at PiPhone (ang Pi Phone ay isang tatak ng mga telepono na nagpapatakbo ng iba't ibang mga system ng Linux sa isang mobile device, tulad ng Fedora, Ubuntu, Arch, atbp.)

[Tingnan ang aking pagsasaliksik sa pagkuha ng degoogled Android virtual machine na ginagamit] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Tingnan kung paano mag-degoogle mula sa Android] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Maliit na mga pagkilos upang makatulong

Ang pagkalat ng kamalayan sa lahat ng paraan na maaari mong ay mahalaga. Para sa akin, hindi lamang ako madalas na nagsasalita tungkol sa degoogling, at nagsusulat ng mga artikulo, ngunit mayroon din akong isang maliit na maliit na ugali, kung saan binibigyan ko ang aking pang-araw-araw na libreng Reddit award sa naka-pin na post sa r / degoogle upang mapataas ang kamalayan. Sa ngayon, nabigyan ko ng halos 30 mga parangal ang naka-pin na post (gumastos din ako ng 500 ng aking libreng mga barya sa 10 mga parangal para sa post na iyon)

***

## Hindi mapagkakatiwalaan

Hindi mapagkakatiwalaan ang Google, at hindi na muling mapagkakatiwalaan. Sila ay ganap na nawala mula sa "huwag maging masama" (palagi silang masasama) sa pagiging ganap na kasamaan at hindi sinusubukang itago ito.

***

## Iba pang mga bagay upang suriin

[The Google Graveyard (slaybygoogle.com) - isang pinagsunod-sunod na listahan ng 224+ na mga produkto na pumatay sa Google] (https://killedbygoogle.com/)

> [Link ng GitHub] (https://github.com/codyogden/killedbygoogle)

[Alphabet worker union - Ang bagong unyon ng mga manggagawa sa Google na may higit sa 800 mga miyembro] (https://alphabetworkersunion.org/people/our-union/)

[Ayaw mong makihati sa itlog ng dinosaur easter? Saklaw ka ng website na ito] (https://chromedino.com/)

Mayroong iba pang mga kahalili, hanapin lamang ang mga ito.

***

Ang ilang pagsusuri sa katotohanan ay kinakailangan para sa artikulong ito

***

## Impormasyon ng file

Uri ng file: `Markdown (* .md)`

Bilang ng linya (kabilang ang mga blangko na linya at linya ng tagatala): `968`

Bersyon ng file: `6 (Linggo, Abril 18th 2021 ng 4:18 pm)`

***

### Katayuan ng software

Ang lahat ng aking mga gawa ay libre ng ilang mga paghihigpit. Ang DRM (** D ** igital ** R ** mga paghihigpit ** M ** anagement) ay wala sa alinman sa aking mga gawa.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ang sticker na ito ay suportado ng Free Software Foundation. Hindi ko balak na isama ang DRM sa aking mga gawa.

Gumagamit ako ng pagdadaglat na "Pamamahala sa Mga Paghihigpit sa Digital" sa halip na ang mas kilala na "Digital Rights Management" bilang karaniwang paraan ng pagtugon dito ay mali, walang mga karapatan sa DRM. Ang spelling na "Digital Restrictions Management" ay mas tumpak, at sinusuportahan ng [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) at ng [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Ang seksyon na ito ay ginagamit upang taasan ang kamalayan para sa mga problema sa DRM, at upang protesta rin ito. Ang DRM ay may sira sa pamamagitan ng disenyo at isang pangunahing banta sa lahat ng mga gumagamit ng computer at kalayaan sa software.

Kredito sa imahe: [defectivebydesign.org/drm-free/...<<(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Impormasyon ng sponsor

! [Sponsor Button.png] (Sponsor Button.png) <- Huwag i-click ang pindutang ito, hindi ito gumagana, ito ay isang imahe lamang. Ang totoong pindutan ay nasa tuktok ng pahina sa kanang (<- L ** R ** ->) sulok

Maaari mong i-sponsor ang proyektong ito kung nais mo, ngunit mangyaring tukuyin kung ano ang gusto mong ibigay. [Tingnan ang mga pondo na maaari mong ibigay dito] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Maaari mong tingnan ang iba pang impormasyon sa sponsor [dito] (https://github.com/seanpm2001/Sponsor-info/)

Subukan! Ang pindutan ng sponsor ay nasa tabi mismo ng pindutan ng relo / pag-unsatch.

***

## Kasaysayan ng file



 * Sinimulan ang file

> * Idinagdag ang seksyon ng pamagat

> * Idinagdag ang index

> * Idinagdag ang tungkol sa seksyon

> * Idinagdag ang seksyon ng Wiki

> * Idinagdag ang seksyon ng kasaysayan ng bersyon

> * Idinagdag ang seksyon ng mga isyu.

> * Idinagdag ang nakaraang seksyon ng mga isyu

> * Idinagdag ang nakaraang seksyon ng mga kahilingan sa paghila

> * Idinagdag ang seksyon ng mga aktibong kahilingan sa paghila

> * Idinagdag ang seksyon ng mga nag-aambag

> * Idinagdag ang seksyon ng nag-aambag

> * Idinagdag ang tungkol sa seksyong README

> * Idinagdag ang seksyon ng kasaysayan ng README bersyon

> * Idinagdag ang seksyon ng mga mapagkukunan

> * Nagdagdag ng isang seksyon ng katayuan ng software, na may isang libreng sticker at mensahe ng DRM

> *Idinagdag ang seksyon ng impormasyon ng sponsor

> * Walang ibang mga pagbabago sa bersyon 0.1

Bersyon 1 (Biyernes, Pebrero 19 2021 ng 5:20 pm)

> Mga pagbabago:

> * Sinimulan ang file

> * Idinagdag ang pangunahing seksyon ng paglalarawan

> * Idinagdag ang seksyon ng paglalarawan ng repository

> * Idinagdag ang listahan ng mga artikulo, na may 14 na mga entry

>> * Nagdagdag ng seksyong `mga nauugnay na artikulo`

>> * Nagdagdag ng seksyong `tingnan din`

> * Idinagdag ang seksyon ng impormasyon ng file

> * Idinagdag ang seksyon ng kasaysayan ng file

> * Idinagdag ang footer

> * Walang ibang mga pagbabago sa bersyon 1

Bersyon 2 (Biyernes, Pebrero 19 2021 ng 5:26 ng hapon)

> Mga pagbabago:

> * Idinagdag ang seksyon ng katayuan ng pagsasalin

> * Idinagdag ang Iba pang mga bagay upang suriin ang seksyon

> * Idinagdag ang seksyon ng privacy

> * Nagdagdag ng isang index

> * Idinagdag ang subseksyon ng katayuan ng software

> * Idinagdag ang iba pang seksyon ng mga kampanya laban sa Google

>> * Idinagdag ang hindi na ginagamit na subseksyon

>> * Idinagdag ang patuloy na subseksyon

> * Idinagdag ang seksyon ng mga mapagkukunan

> * Idinagdag ang seksyon ng mga link sa pag-download

> * Nai-update ang seksyon ng impormasyon ng file

> * Nai-update ang seksyon ng kasaysayan ng file

> * Walang ibang mga pagbabago sa bersyon 2

Bersyon 3 (Miyerkules, ika-24 ng Pebrero 2021 ng 7:56 ng gabi)

> Mga pagbabago:

> * Nai-update ang index

> * Sinangguni ang icon ng degoogle at ang bagong samahang GitHub

> * Nagdagdag ng mga link sa mga mas bagong artikulo

> * Idinagdag ang countering ibang seksyon ng mga argumento

>> * Idinagdag ang subseksyon ng kaginhawaan

>> * Idinagdag ang Bakit kahit abala sa subseksyon

>> * Idinagdag ang iba pang mga subseksyon

> * Nai-update ang ilang data

> * Nai-update ang seksyon ng impormasyon ng file

> * Nai-update ang seksyon ng kasaysayan ng file

> * Walang ibang mga pagbabago sa bersyon 3

Bersyon 4 (Thurday, Pebrero 25th 2021 ng 9:31 pm)

> Mga pagbabago:

> * Nagdagdag ng mga link sa 10 bagong mga artikulo

> * Nagdagdag ng isang seksyon tungkol sa aking degoogling na karanasan

> * Nai-update ang index

> * Nai-update ang seksyon ng impormasyon ng file

> * Nai-update ang seksyon ng kasaysayan ng file

> * Walang ibang mga pagbabago sa bersyon 4

Bersyon 5 (Biyernes, Abril 9th ​​2021 ng 6:02 pm)

_Nakulangan ng mga pag-update sa kilusang kontra-Google mula sa akin nitong mga nagdaang araw, nagtatrabaho ako upang makabalik dito pagkatapos ng isang 1+ buwan na hiatus._

> Mga pagbabago:

> * Nai-update ang seksyon ng pamagat

> * Nai-update ang index

> * Nai-update ang listahan ng wika: mga nakapirming link, at nagdagdag ng higit pang mga sinusuportahang wika

> * Nai-update ang seksyon ng katayuan ng artikulo, pagdaragdag ng 4 na mga link ng tinidor

> * Nai-update ang seksyon ng katayuan ng software

> * Idinagdag ang Go ay masasamang seksyon

> * Idinagdag ang seksyon ng Paggamit ng DRM

> * Nagdagdag ng seksyon ng Karaniwang mga maling kuru-kuro

>> * Idinagdag ang Google ay hindi ang subseksyon sa Internet

> * Idinagdag ang seksyon ng Internet Explorer 6 at Chrome

>> * Idinagdag ang Ang problema sa matapang na subseksyon

> * Idinagdag ang pagtanggal sa privacy ng Faux

> * Idinagdag ang Buksan na mapagkukunan ay hindi maaaring maging bahagyang subseksyon

> * Idinagdag ang subseksyon ng Oxymoron

> * Idinagdag ang seksyon ng Hindi magandang pagganap

> * Idinagdag ang seksyon ng Hindi magandang pamamahala ng proyekto

> * Idinagdag ang Kahindik-hindik o walang pagmo-moderate ng seksyon ng mga serbisyo

> * Idinagdag ang seksyong Astroturfing

> * Nagdagdag ng iligal at hindi etikal na seksyon ng mga kasanayan sa negosyo

> * Idinagdag ang subseksyon ng Sa Europa

>> * Idinagdag ang subseksyon ng Sa Hilagang Amerika

>> * Idinagdag ang subseksyon ng Mga Kontrobersya

> * Idinagdag na ang Google ay awtomatikong seksyon

> * Idinagdag ang seksyon ng Android

> * Idinagdag ang Mga maliliit na pagkilos upang matulungan ang seksyon

> * Idinagdag ang seksyong Hindi Mapagkakatiwalaan

> * Idinagdag ang seksyon ng impormasyon ng sponsor

> * Nai-update ang footer

> * Nai-update ang seksyon ng impormasyon ng file

> * Nai-update ang seksyon ng kasaysayan ng file

> * Walang ibang mga pagbabago sa bersyon 5

Bersyon 6 (Linggo, Abril 18th 2021 ng 4:18 pm)

> Mga pagbabago:

> * Nai-update ang index

> * Nagdagdag ng isang bagong paglalarawan ng pangkalahatang ideya

> * Nai-update na impormasyon sa katayuan ng artikulo

> * Nagdagdag ng isang link sa bagong artikulo ng Google FLoC

> * Nagdagdag ng isang link sa artikulo ng Wuest 3n Fuchs Degoogle at pangkalahatang impormasyon dito

> * Nai-update ang seksyon ng impormasyon ng file

> * Nai-update ang seksyon ng kasaysayan ng file

> * Walang ibang mga pagbabago sa bersyon 6

Bersyon 7 (Malapit na)

> Mga pagbabago:

> * Malapit na

> * Walang ibang mga pagbabago sa bersyon 7

Bersyon 8 (Malapit na)

> Mga pagbabago:

> * Malapit na

> * Walang ibang mga pagbabago sa bersyon 8

Bersyon 9 (Malapit na)

> Mga pagbabago:

> * Malapit na

> * Walang ibang mga pagbabago sa bersyon 9

Bersyon 10 (Malapit na)

> Mga pagbabago:

> * Malapit na

> * Walang ibang mga pagbabago sa bersyon 10

Bersyon 11 (Malapit na)

> Mga pagbabago:

> * Malapit na

> * Walang ibang mga pagbabago sa bersyon 11

Bersyon 12 (Malapit na)

> Mga pagbabago:

> * Malapit na

> * Walang ibang mga pagbabago sa bersyon 12

***

## Footer

Naabot mo na ang dulo ng file na ito

([Bumalik sa tuktok] (# Nangungunang) | [Bumalik sa GitHub] (https://github.com))

### EOF

***
