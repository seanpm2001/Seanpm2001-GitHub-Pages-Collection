***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - дэгаглістуйце сваё жыццё

Гэта асноўны артыкул пра дэгуглінг для агульнай інфармацыі пра дэгуглінг і спасылка на іншыя артыкулы.

[Глядзіце спіс як арганізацыю GitHub] (https://github.com/Degoogle-your-life)

***

_Прачытайце гэты артыкул на іншай мове: _

** Цяперашняя мова: ** `Англійская (ЗША)` _ (пераклады, магчыма, спатрэбіцца выправіць, каб выправіць англійскую, замяніўшы правільную мову) _

_🌐 Спіс моў_

** Сартаванне паводле: ** `A-Z`

[Параметры сартавання недаступныя] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Афрыкаанс | [sq Shqiptare] (/. github / README_SQ.md) албанскі | [am አማርኛ] (/. github / README_AM.md) амхарскі | [ar عربى] (/.github/README_AR.md) арабская | [hy հայերեն] (/. github / README_HY.md) армянская | [az Azərbaycan dili] (/. github / README_AZ.md) азербайджанская | [eu Euskara] (/. github /README_EU.md) баскская | [be Беларуская] (/. Github / README_BE.md) беларуская | [bn বাংলা] (/. Github / README_BN.md) бенгальская | [bs Bosanski] (/. Github / README_BS.md) Баснійская | [bg беларускі] (/. Github / README_BG.md) балгарская | [ca Català] (/. Github / README_CA.md) каталонская | [ceb Sugbuanon] (/. Github / README_CEB.md) себуанская | [новая Чычэва ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) кітайскі (спрошчаны) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) кітайскі (традыцыйны) | [co Corsu] (/. Github / README_CO.md) корсіканскі | [hr харвацкая] (/. Github / README_HR.md) харвацкі | [cs čeština] (/. Github / README_CS .md) чэшская | [так данск] (README_DA.md) дацкая | [nl Nederlands] (/. github / README_ NL.md) галандская | [** en-us English **] (/. github / README.md) англійская | [EO Эсперанта] (/. Github / README_EO.md) Эсперанта | [et Eestlane] (/. github / README_ET.md) эстонскі | [tl Pilipino] (/. github / README_TL.md) філіпінская | [fi Suomalainen] (/. github / README_FI.md) фінская | [fr français] (/. github / README_FR.md) французская | [fy Frysk] (/. github / README_FY.md) фрызская | [gl Galego] (/. github / README_GL.md) галісійская | [ka ქართველი] (/. github / README_KA) грузінскі | [de Deutsch] (/. github / README_DE.md) Нямецкая | [el Ελληνικά] (/. github / README_EL.md) грэчаская | [gu ગુજરાતી] (/. github / README_GU.md) гуджараці | [ht Kreyòl ayisyen] (/. github / README_HT.md) Гаіцянскі крэольскі | [ха хаўса] (/. github / README_HA.md) хаўса | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) гавайская | [ён іўрыт] (/. github / README_HE.md) іўрыт | [прывітанне हिन्दी] (/. github / README_HI.md) хіндзі | [hmn Hmong] (/. github / README_HMN.md) Хмонг | [hu Magyar] (/. github / README_HU.md) Венгерская | [is Íslenska] (/. github / README_IS.md) ісландская | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) ісландская | [ga Gaeilge] (/. github / README_GA.md) ірландскі | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) японскі | [jw Wong jawa] (/. github / README_JW.md) яванскі | [kn ಕನ್ನಡ] (/. github / README_KN.md) каннада | [kk Қазақ] (/. github / README_KK.md) казахская | [км ខ្មែរ] (/. github / README_KM.md) кхмерская | [rw кіньяруанда] (/. github / README_RW.md) кіньяруанда | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) карэйская (паўднёвая) | [ko-north 문화어] (README_KO_NORTH.md) карэйская (паўночная) (яшчэ НЕ ПЕРАКЛАДАНА) | [ку курд] [/. github / README_KU.md) курд (курманджы) | [ky Кыргызча] (/. github / README_KY.md) кіргізская | [вось ລາວ] (/. github / README_LO.md) лаоская | [la Latine] (/. github / README_LA.md) Лацінская | [lt Lietuvis] (/. github / README_LT.md) літоўскі | [lb Lëtzebuergesch] (/. github / README_LB.md) люксембургскі | [mk Македонски] (/. github / README_MK.md) македонская | [мг малагасійскай] (/. github / README_MG.md) малагасійская | [ms Bahasa Melayu] (/. github / README_MS.md) малайская | [мл മലയാളം] (/. github / README_ML.md) малаялам | [mt Мальты] (/. github / README_MT.md) Мальтыйская | [мі маоры] (/. github / README_MI.md) маоры | [містэр मराठी] (/. github / README_MR.md) маратхі | [mn Мангол] (/. github / README_MN.md) мангольская | [мой မြန်မာ] (/. github / README_MY.md) М'янма (бірманская) | [не नेपाली] (/. github / README_NE.md) непальская | [no norsk] (/. github / README_NO.md) нарвежская | [альбо ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Одыя (Орыя) | [ps پښتو] (/. github / README_PS.md) пушту | [fa فارسی] (/. github / README_FA.md) | фарсі [pl polski] (/. github / README_PL.md) польская | [pt português] (/. github / README_PT.md) партугальская | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) панджабі | Няма даступных моў, якія пачынаюцца на літару Q | [ro Română] (/. github / README_RO.md) румынскі | [ru русский] (/. github / README_RU.md) руская | [sm Faasamoa] (/. github / README_SM.md) Самоа | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) шатландская гэльская | [sr Српски] (/. github / README_SR.md) сербская | [st. Сесота] (/. github / README_ST.md) Сесота | [sn Шона] (/. github / README_SN.md) Шона | [sd سنڌي] (/. github / README_SD.md) Сіндхі | [si සිංහල] (/. github / README_SI.md) сінгальская | [sk Slovák] (/. github / README_SK.md) славацкая | [sl Slovenščina] (/. github / README_SL.md) Славенская | [so Soaliali] (/. github / README_SO.md) Самалі | [[es en español] (/. github / README_ES.md) іспанскі | [su Sundanis] (/. github / README_SU.md) суданскі | [sw кісвахілі] (/. github / README_SW.md) суахілі | [sv Svenska] (/. github / README_SV.md) шведская | [tg Тоҷикӣ] (/. github / README_TG.md) таджыкская | [ta தமிழ்] (/. github / README_TA.md) тамільская | [tt Татар] (/. github / README_TT.md) Татарская | [te తెలుగు] (/. github / README_TE.md) тэлугу | [th ไทย] (/. github / README_TH.md) тайская | [tr Türk] (/. github / README_TR.md) Турэцкая | [tk Türkmenler] (/. github / README_TK.md) Туркменская | [uk Український] (/. github / README_UK.md) украінскі | [ur اردو] (/. github / README_UR.md) урду | [ug ئۇيغۇر] (/. github / README_UG.md) уйгурскі | [uz O'zbek] (/. github / README_UZ.md) узбекская | [vi Tiếng Việt] (/. github / README_VI.md) в'етнамская | [cy Cymraeg] (/. github / README_CY.md) валійская | [xh isiXhosa] (/. github / README_XH.md) Хоса | [yi יידיש] (/. github / README_YI.md) Ідыш | [ё ёруба] (/. github / README_YO.md) ёруба | [зу зулу] (/. github / README_ZU.md) зулу) Даступна на 110 мовах (108, калі не ўлічваць англійскую і паўночнакарэйскую, бо паўночнакарэйская яшчэ не перакладзена [Чытаць пра гэта тут] (/ OldVersions / карэйская (паўночная ) /README.md))

Пераклады на іншыя мовы, акрамя англійскай, пераводзяцца машынным шляхам і яшчэ не дакладныя. Па стане на 5 лютага 2021 г. памылак пакуль не выпраўлена. Паведаміце пра памылкі перакладу [тут] (https://github.com/seanpm2001/Degoogle-your-life/issues/), абавязкова зрабіце рэзервовую копію выпраўленняў крыніцамі і накіруйце мяне , паколькі я дрэнна ведаю іншыя мовы, акрамя англійскай (у рэшце рэшт я планую атрымаць перакладчыка), калі ласка, прывядзіце [wiktionary] (https://en.wiktionary.org) і іншыя крыніцы ў вашай справаздачы. Калі гэтага не зрабіць, прывядзе да адмовы ад публікацыі выпраўлення.

Заўвага: з-за абмежаванняў інтэрпрэтацыі ўцэнкі GitHub (і практычна любой іншай інтэрпрэтацыі ўцэнкі ў Інтэрнэце) націск гэтых спасылак перанакіруе вас у асобны файл на асобнай старонцы, якая не з'яўляецца маёй старонкай профілю GitHub. Вы будзеце перанакіраваны ў [сховішча seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), дзе размешчаны README.

Пераклады ажыццяўляюцца з дапамогай Google Translate з-за абмежаванай альбо адсутнасці падтрымкі моў, якія мне патрэбныя ў іншых перакладчыцкіх службах, такіх як DeepL і Bing Translate (даволі іранічна для кампаніі супраць Google). Я працую над пошукам альтэрнатывы. Чамусьці фарматаванне (спасылкі, раздзяляльнікі, паўтлусты шрыфт, курсіў і г.д.) сапсавана ў розных перакладах. Выпраўляць гэта нудна, і я не ведаю, як выправіць гэтыя праблемы на мовах з нелацінскімі сімваламі, і для выпраўлення гэтых праблем патрэбна дадатковая дапамога (напрыклад, арабская).

З-за праблем з тэхнічным абслугоўваннем многія пераклады састарэлі і выкарыстоўваюць састарэлую версію гэтага файла артыкула `README`. Патрэбны перакладчык. Акрамя таго, з 9 красавіка 2021 года мне спатрэбіцца час, каб усе новыя спасылкі запрацавалі.

***

## Індэкс

[00.0 - Загаловак] (# Degoogling --- Degoogle-тваё жыццё)

> [00.1 - Індэкс] (# Індэкс)

[01.0 - Асноўнае апісанне] (# Асноўнае апісанне)

> [01.1 - Загаловак сховішча] (# Degoogle-your-life)

> [01.2 - Агляд апісання Wuest3NFuchs] (# Агляд-by-Wuest3nFuchs)

>> [01.2.1 - Што гэта значыць?] (# Што-гэта-значыць-by-Wuest3nFuchs)

>> [01.2.2 - Чаму Degoogle?] (# Чаму-Degoogle - by-Wuest3nFuchs)

[02.0 - Артыкулы] (# Артыкулы)

[03.0 - Канфідэнцыяльнасць] (# Канфідэнцыяльнасць)

[04.0 - Іншыя кампаніі супраць Google] (# Іншыя кампаніі супраць Google)

> [04.0.1 - Несапраўдны] (# Несапраўдны)

> [04.0.2 - Пастаянна] (# Пастаянна)

[05.0 - Супрацьдзеянне іншым аргументам] (# Counter-other-аргументы)

> [05.0.1 - Зручнасць] (# Зручнасць)

> [05.0.2 - Чаму гэта важна? У любым выпадку занадта позна] (# Чаму-ўсё-гэта важна, -яго-занадта позна-усё роўна)

> [05.0.3 - Іншае] (# Іншае)

[06.0 - Крыніцы] (# Крыніцы)

[07.0 - Спасылкі для загрузкі] (# спасылкі для загрузкі)

[08.0 - Мой досвед дэгаглявання] (# Мой вопыт дэгаглявання)

> [08.1 - з чаго я перайшоў] (# з чаго я перайшоў)

> [08.2 - Прадукты, ад якіх да гэтага часу не магу сысці] (# Прадукты, ад якіх я ўсё яшчэ не магу адысці)

[09.0 - Іншыя рэчы, якія трэба праверыць] (# Іншыя рэчы для выезду)

[10.0 - Інфармацыя пра файл] (# Інфармацыя пра файл)

> [10.1 - Статус праграмнага забеспячэння] (# Статус праграмнага забеспячэння)

> [10.2 - Інфармацыя пра спонсара] (# Інфармацыя пра спонсара)

[11.0 - Гісторыя файла] (# Гісторыя файла)

[12.0 - Калонтытул] (# Калонтытул)

***

## Асноўнае апісанне

[З Вікіпедыі: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

Рух DeGoogle (які таксама называюць рухам Google) - гэта нізавая кампанія, якая спарадзілася, калі актывісты заклікаюць карыстальнікаў спыніць выкарыстанне прадуктаў Google цалкам з-за росту праблем, звязаных з прыватнасцю ў дачыненні да кампаніі. Тэрмін абазначае акт выдалення Google са свайго жыцця. Паколькі якая расце доля Інтэрнэт-гіганта на рынку стварае манапалістычную сілу для кампаніі ў лічбавых прасторах, усё большая колькасць журналістаў адзначае цяжкасці ў пошуку альтэрнатывы прадукцыі кампаніі.

** Гісторыя **

У 2013 годзе Джон Koetsier з Venturebeat заявіў, што планшэт на базе Kindle Fire ад Android ад Amazon з'яўляецца "версіяй Android, якую Google абясточвае". У 2014 годзе Джон Сімпсан з US News напісаў пра "права быць забытым" Google і іншымі пошукавымі сістэмамі. У 2015 годзе Дэрэк Скалі з Irish Times напісаў артыкул пра тое, як "вычысціць Google з жыцця". У 2016 годзе Крыс Карлон з Андруаd Адміністрацыя выказала здагадку, што карыстальнікі CyanogenMod 14 могуць "адключыць Google" свае тэлефоны, таму што CyanogenMod выдатна працуе і без дадаткаў Google. У 2018 годзе Нік Лукезі з Inverse напісаў пра тое, як ProtonMail прасоўвае, як "мець магчымасць цалкам пазбавіць Google ад жыцця". Брэндан Гесэ Lifehacker напісаў падрабязны падручнік па "выхадзе з Google". Журналістка Gizmodo Кашмір Хіл сцвярджае, што прапускала сустрэчы і адчувала цяжкасці ў арганізацыі сустрэч без выкарыстання Google Calendar. У 2019 годзе Huawei вярнула грошы ўладальнікам тэлефонаў на Філіпінах забаронена карыстацца паслугамі, якія прадстаўляюцца Google, таму што існуе так мала альтэрнатыў, што адсутнасць прадуктаў кампаніі зрабіла звычайнае карыстанне Інтэрнэтам немагчымым.

***

# Degoogle-тваё жыццё
Сховішча для агульнай інфармацыі пра дэгагляванне і спасылкі на іншыя мае сховішчы для дэгаглявання.

***

## Агляд Wuest3nFuchs

Лепшае апісанне, прадастаўлена [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - крыніца: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Што гэта значыць? ад Wuest3nFuchs

Дэгаглінг азначае спыненне выкарыстання ўсяго, што належыць Google, усяго, што было зроблена Google. Я кажу пра іх пошукавую сістэму, іх паштовую службу (Gmail), Youtube і г.д.

### Чаму Degoogle? ад Wuest3nFuchs

На дадзены момант Google з'яўляецца адной з самых магутных кампаній у свеце. Яны захавалі велізарную колькасць інфармацыі пра ўсіх нас. Некаторыя будуць сцвярджаць, што наша інфармацыя ў бяспецы, бо яны ведаюць, як яе абараніць. Але гэта няпраўда. У Google ужо пранікалі і ў будучыні. Можа, не якім-небудзь сцэнарыстам, але гэта зробіць нацыянальная дзяржава. Google захоўвае асабістую інфармацыю пра ўсіх нас, бо менавіта так яны зарабляюць грошы.

Яны скануюць нашы электронныя лісты, захоўваюць тое, што мы шукаем, калі выкарыстоўваем іх пошукавую сістэму, якія відэа мы глядзім на Youtube. Вось як яны арыентуюцца на нас і ствараюць на нас профіль, каб паказаць нам нейкую рэкламу на аснове таго, пра што мы гаварылі з лепшым сябрам, каб яны маглі паказаць нам рэкламу таго, што нам трэба, але гэта занадта жудасна. Дзякуючы спадару Сноўдэну мы цяпер ведаем, што Google падзяліўся нашай асабістай інфармацыяй з АНБ у рамках праграмы пад назвай ** "PRISM" **.


У будучыні хтосьці зможа атрымаць доступ да ўсёй гэтай інфармацыі, і я запэўніваю вас, што адбудзецца нешта вельмі дрэннае. Каб гэтага не адбылося, вы павінны пачаць дэгаглінг прама зараз. Акрамя таго, вы не павінны выкарыстоўваць прадукты кампаніі, якая дзеліцца вашымі дадзенымі з ** NSA **. Вы павінны спыніць усё гэта шляхам дэгагліравання.

** Калі іншыя людзі могуць гэта зрабіць, вы можаце зрабіць гэта таксама. **

[Больш падрабязна тут] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Спасылка на відэлец у цяперашні час адсутнічае ў спісе, бо я не валодаю гэтым сховішчам цалкам і хачу прасоўваць іншыя крыніцы. Было б эгаістычна спасылацца на свой https://github.com/Degoogle-your-life/Degoogle! ->

***

## Артыкулы

### Статус артыкула

_У цяперашні час усе артыкулы знаходзяцца ў стадыі распрацоўкі і патрабуюць значных удасканаленняў. Прапановы і выпраўленні дазволены._

_ Па стане на 18 красавіка 2021 г. у 16:09 большасць артыкулаў яшчэ не пачата. Я працую над тым, каб знайсці час і намаганні, каб пачаць іх.

[Чаму вы павінны спыніць выкарыстанне Google Chrome] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Спыніць карыстацца ChromeBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Спыніце выкарыстоўваць WideVine DRM / Час скараціць WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Чаму вы павінны спыніць выкарыстанне ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Перамяшчаючыся з YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Спыніце гугліць, чаму вы павінны спыніць выкарыстанне пошуку Google] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[Чаму вы павінны спыніць карыстацца Gmail] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Чаму вы павінны спыніць выкарыстанне Android] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Чаму варта пазбягаць Google Amp] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Чаму вы павінны спыніць выкарыстанне Google Drive] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Чаму варта спыніць выкарыстанне Google Maps і Google Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Гэй, Google, спыніся] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Спыніць чытанне з кніг Google / Play] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Спыніць выкарыстанне Google Classroom] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Чаму вы павінны спыніць выкарыстанне Google Translate] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Чаму вы павінны перастаць выкарыстоўваць свае ўліковыя запісы Google] (https://github.com/seanpm2001/Why-you-should-sуліковыя запісы Google, якія найбольш часта выкарыстоўваюцца) <! - 16! ->

** Новыя артыкулы будуць напісаны ў бліжэйшы час: **

[Чаму вы павінны спыніць выкарыстанне Gerrit] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Чаму вы павінны спыніць выкарыстанне Google Analytics (сховішча сапсавана з майго канца па стане на сераду, 24 лютага 2021 г. у 16:13)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics) <! - 18! ->

<! - Раздзяляльнік працы! ->

[Чаму вам варта спыніць выкарыстанне Google AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Чаму вы павінны спыніць выкарыстанне Google One] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Чаму вы павінны спыніць выкарыстанне Google+ (неіснуючы)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Чаму вы павінны спыніць карыстацца крамай Google Play] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Чаму вы павінны спыніць выкарыстанне Google Docs] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Чаму вы павінны спыніць карыстацца Google Slides] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Чаму вы павінны спыніць выкарыстанне Google Sheets] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Чаму вы павінны спыніць выкарыстанне Google Forms] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Чаму варта перастаць выкарыстоўваць Google Cardboard] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Чаму вы павінны спыніць выкарыстанне паведамленняў Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Чаму варта спыніць выкарыстанне Google Material Design] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Чаму варта спыніць выкарыстанне Google Glass / Glasses] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Чаму варта спыніць выкарыстанне Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Чаму вам варта спыніць выкарыстанне GBoard] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Чаму вы павінны спыніць выкарыстанне Google Home] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Чаму варта спыніць выкарыстанне Google Nest] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Чаму вы павінны спыніць выкарыстанне Google Hangouts (неіснуючы)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Чаму варта спыніць выкарыстанне Google Duo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Чаму вам варта спыніць выкарыстанне Google Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Чаму варта спыніць выкарыстанне Google Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Чаму вы павінны спыніць выкарыстанне Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Чаму варта спыніць выкарыстанне мовы праграмавання Googles Go] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Чаму вам варта спыніць выкарыстанне мовы праграмавання Googles Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Чаму варта перастаць выкарыстоўваць фармат выявы Googles WebP] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Чаму варта перастаць выкарыстоўваць фармат відэа Googles WebM] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Чаму вы павінны спыніць выкарыстанне Google Video] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Чаму вы павінны спыніць выкарыстанне сайтаў Google (класічны)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Чаму вы павінны спыніць выкарыстанне сайтаў Google ("Новы")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Чаму вы павінны спыніць выкарыстанне Google Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Чаму вы павінны спыніць выкарыстанне Android Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Чаму варта спыніць выкарыстанне Google VPN (оксюмарон)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Чаму вы павінны спыніць выкарыстанне Google Photos] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[Чаму варта перастаць выкарыстоўваць Google Calendar] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Чаму вам варта спыніць выкарыстанне VirusTotal (бо ён належыць Google з верасня 2012 года) (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Чаму вы павінны спыніць выкарыстанне Google Fi] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi) <! - 53! ->

[Чаму вы павінны спыніць выкарыстанне Google Stadia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Чаму вы павінны спыніць выкарыстанне Google Keep] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Чаму вам варта спыніць выкарыстанне Google Base] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Чаму вы павінны спыніць удзел у Google Summer of Code] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Чаму варта спыніць выкарыстанне Google Camera] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Чаму вы павінны спыніць выкарыстанне калькулятара Google (можа здацца экстрэмальным, але вам варта зняць з Google усё, надзвычай лёгка перамяшчаць)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Калькулятар) <! - 59! ->

[Чаму вы павінны спыніць выкарыстоўваць Google Survey + бонусы] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Чаму вы павінны спыніць выкарыстанне Google Drawings] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Чаму вы павінны спыніць выкарыстанне Tenor (сайт GIF, які належыць Google з 2019 года)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Што такое FLoC - Чаму варта пазбягаць вялікай праблемы FLoCing у Googles (спыніць выкарыстанне Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63!

** Усяго артыкулаў: ** `63`

** Артыкул [дарожная карта AB] (DegoogleCampaign_2021Roadmap_Part1.md) (да 12 сакавіка 2021 г.) 2 выходныя **

** Артыкул [дарожная карта BB] (DegoogleCampaign_2021Roadmao_Part2.md) (да? 2021) 2 выходныя **

Статус артыкула

Усе артыкулы ў цяперашні час знаходзяцца ў стадыі распрацоўкі і патрабуюць значных удасканаленняў. Прапановы і выпраўленні дапускаюцца.

** Відэльцы **

Пашырэнне маёй сеткі Degoogle і даданне зручнасці доступу і крыкаў супольнасці.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Вымаўляецца з: [https://github.com/wacko1805/Fossapps](https://github.com/wacko1805/Fossapps) (англійская)

2. [Спасылкі на прыватнасць] (https://github.com/Degoogle-your-life/Privacy-links) | Вымаўляецца з: [https://github.com/Arturro43/privacy-links](https://github.com/Arturro43/privacy-links) (польская)

3. [Цудоўная прыватнасць] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Вымаўляецца з: [https://github.com/LinuxCafeFederation/Delightful-Privacy](https://github.com/LinuxCafeFederation/Delightful-Privacy) (англійская)

4. [Блакіраваныя спісы] (https://github.com/Degoogle-your-life/blocklists) | Вылучана з: [https://github.com/jmdugan/blocklists](https://github.com/jmdugan/blocklists) (англійская)

5. [Degoogle, аўтар Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Выпраўлена з: [https://github.com/Wuest3nFuchs/Degoogle](https://github.com/Wuest3nFuchs/Degoogle) (англійская)

** Звязаныя **

[Даследаванне віртуальнай машыны для Android-тэлефонаў] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

** Глядзіце таксама: **

[Крытыка Google у Вікіпедыі] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[Google Graveyard (killbygoogle.com) - адсартаваны спіс з 224+ прадуктаў, якія Google забіў] (https://killedbygoogle.com/)

> [Спасылка на GitHub] (https://github.com/codyogden/killedbygoogle)

[Прафсаюз работнікаў алфавіту - новы прафсаюз работнікаў Google, які налічвае больш за 800 членаў] (https://alphabetworkersunion.org/people/our-union/)

[Не хочаце расставацца з велікодным яйкам дыназаўра? Вы ахапілі гэты сайт] (https://chromedino.com/)

***

## Прыватнасць

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (nadzor_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / сакавік / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument # Крытыка) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -эсэ-ўзоры / няма-чаго-хаваць-аргумент-няма-чаго-сказаць /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- of-data-about-you-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -your-personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -монетизирует-і) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- зборнік-выяўлены.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ здароўе-фітнес-дадзеныя-прыватнасць /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks] [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-government-google-data-collection-iск-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https://moz.com /blog/where-does-google-draw-the-data-collection-line)[e](https://mashable.com/article/google-android-data-collection-study/)[s](https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)[o](https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -патрабаванні ад імя-5-м карыстальнікі illion-iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/)[r](https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/)[i](https://www.cbsnews.com/news/google-education-spies-on-collects- дадзеныя-пра-мільёны-дзяцей-заявах-пазове-новай-Мексіцы-генеральным пракуроры /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -пад-нашымі носамі /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / technology / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : //medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (я мог бы працягваць і працягваць доказы гэтага, але шмат часу трэба было знайсці і прайсці праз усё гэта артыкулы)

Канфідэнцыяльнасць у прадуктах Google заўсёды дрэнная з-за ўсіх прадуктаў Google, якія змяшчаюць шпіёнскае праграмнае забеспячэнне.

Незалежна ад таго, што вы робіце, калі вы карыстаецеся Google, усе вашы канфідэнцыйныя асабістыя дадзеныя адпраўляюцца ў Google і іншыя. Google таксама быў заўважаны пры праходжанні адкрытых праграм. Напрыклад, з асабістага досведу (у Firefox) з адкрытай укладкай YouTube, якую я не наведваў, я паглядзеў некалькі відэа ў аўтаномным рэжыме (VLC Media Player). Пазней, калі я пайшоў праверыць рэкамендацыі, я паглядзеў амаль усё. Несумненна, што яны таксама падглядаюць іншыя праграмы.

У Chrome (і многіх іншых аглядальніках) прысутнічае рэжым інкогніта. У Chrome гэты рэжым бессэнсоўны, бо Google усё роўна будзе здабываць вашы дадзеныя. Нават калі вы адключыце здабычу / адсочванне дадзеных і ўключыце сігнал "не адсочваць", сюрпрыз здзівіць, Google усё роўна здабывае вашы дадзеныя.

Калі вы лічыце, што вам няма чаго хаваць, ** вы абсалютна памыляецеся **. Гэты аргумент шмат разоў абвяргаўся:

[Праз Вікіпедыю] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Эдвард Сноўдэн адзначыў: "Сцвярджаючы, што вам напляваць на права на недатыкальнасць прыватнага жыцця, бо вам няма чаго хаваць, нічым не адрозніваецца ад таго, што вы не клапоціцеся пра свабоду слова, таму што вам няма чаго сказаць". Мне няма чаго хаваць, - вы кажаце, - мне ўсё роўна, што вы маеце на ўвазе. "Прынцып працы правоў заключаецца ў тым, што ўрад павінен апраўдаць сваё парушэнне вашых правоў".

2. Даніэль Дж. Салаў заявіў у артыкуле для "Хронікі вышэйшай адукацыі", што выступае супраць гэтай аргументацыі; ён заявіў, што ўрад можа сысціk інфармацыя пра чалавека і прычыненне шкоды гэтаму чалавеку альбо выкарыстанне інфармацыі пра чалавека для адмовы ў доступе да паслуг, нават калі чалавек на самой справе не ўчыняў супрацьпраўных дзеянняў, і што ўрад можа прычыніць шкоду асабістаму жыццю, дапусціўшы памылкі. Салаў пісаў: "Пры непасрэдным удзеле аргумент, які можна схаваць, можа пацягнуць за сабой, бо ён прымушае дэбаты сканцэнтравацца на сваім вузкім разуменні прыватнасці. Але сутыкаючыся з мноствам праблем прыватнасці, звязаных з зборам і выкарыстаннем дзяржаўных дадзеных за межамі назірання і раскрыццё інфармацыі, аргумент, у якім няма чаго хаваць, у рэшце рэшт, няма чаго сказаць ".

3. Адам Д. Мур, аўтар часопіса "Правы на прыватнасць: маральныя і юрыдычныя асновы", сцвярджаў: "Гэта меркаванне, паводле якога правы ўстойлівыя да суадносін кошту і выгады альбо паслядоўных аргументаў. Тут мы адмаўляемся ад меркавання, што інтарэсы прыватнасці з'яўляюцца тыпамі. рэчаў, якімі можна гандляваць дзеля бяспекі ". Ён таксама заявіў, што назіранне можа непрапарцыйна ўплываць на некаторыя групы грамадства ў залежнасці ад знешняга выгляду, этнічнай прыналежнасці, сэксуальнасці і рэлігіі.

4. Брус Шнайер, эксперт у галіне камп'ютэрнай бяспекі і крыптаграф, выказаў сваю апазіцыю, спасылаючыся на заяву кардынала Рышэлье "Калі б хто-небудзь даў мне шэсць радкоў, напісаных рукой самага сумленнага чалавека, я б знайшоў у іх нешта, каб ён павесіўся", спасылаючыся пра тое, як урад штата можа знайсці аспекты ў жыцці чалавека, каб прыцягнуць да адказнасці альбо шантажаваць гэтага чалавека. Шнайер таксама сцвярджаў, што "занадта шмат няправільна характарызуюць дэбаты як" бяспеку супраць прыватнасці ". Сапраўдны выбар - свабода супраць кантролю ".

5. Харві А. Сілверглат падлічыў, што звычайны чалавек у сярэднім несвядома здзяйсняе тры злачынствы ў дзень у ЗША.

6. Эміліё Мардзіні, філосаф і псіхааналітык, сцвярджаў, што аргумент "няма чаго хаваць" па сваёй сутнасці парадаксальны. Людзям не трэба мець "што-небудзь хаваць", каб "нешта" хаваць. Схаванае не абавязкова мае дачыненне, сцвярджае Мардзіні. Замест гэтага ён сцвярджае, што неабходна мець інтымную сферу, якая можа быць як схаванай, так і абмежаванай, паколькі, псіхалагічна кажучы, мы становімся асобамі дзякуючы адкрыццю, што мы можам нешта хаваць іншым.

7. Джуліян Асанж заявіў: "Пакуль няма адказу на забойства. Якаб Апельбаўм (@ioerror) мае разумны адказ, просячы людзей, якія кажуць гэта, потым перадаць яму разблакаваны тэлефон і сцягнуць штаны. Мая версія гэта сказаць, "ну, калі вы такія сумныя, мы не павінны з вамі размаўляць, і ніхто не павінен", але па-філасофску сапраўдны адказ такі: масавае назіранне - гэта масавыя структурныя змены. Калі грамадства ідзе дрэнна, гэта ідзе каб узяць вас з сабой, нават калі вы самы мяккі чалавек на зямлі ".

8. Ігнацыё Кофане, прафесар права, сцвярджае, што аргумент памылкова прыняты, паколькі, калі людзі раскрываюць іншым адпаведную інфармацыю, яны раскрываюць і недарэчную інфармацыю. Гэтая недарэчная інфармацыя мае выдаткі на прыватнасць і можа прывесці да іншай шкоды, напрыклад, дыскрымінацыі.

***

## Іншыя кампаніі супраць Google

Гэта спіс іншых прыкметных кампаній супраць Google. Гэты спіс няпоўны. Вы можаце дапамагчы, пашырыўшы яго.

### Неіснуючы

[Scroogled - ад Microsoft (з лістапада 2012 па 2014)] (https://en.wikipedia.org/wiki/Scroogled)

_ На дадзены момант іншых запісаў няма ._

### Пастаянна

_ Гэты спіс зараз пусты._

***

## Процідзеянне іншым аргументам

Ёсць некалькі аргументаў, якія людзі прыводзяць у апраўданне Google. Адзін з першых буйных ужо развенчаны [тут] (# Канфідэнцыяльнасць), але вось некаторыя іншыя:

### Зручнасць

Так, прадукты Google падаюцца зручнымі. Аднак вы гандлюеце ўсім зручным для зручнасці, уключаючы бяспеку, прыватнасць і надзейнасць. З цягам гадоў Google становіцца больш лянівым, і іх серверы ўсё больш і больш пагаршаюцца. Зараз серверы Google паніжаюцца амаль на гадзіну 1-2 разы на месяц (асабліва YouTube)

На жаль, дзякуючы залежнасці грамадства ад Google, Google стаў дамінаваць у Інтэрнэце і імкнецца кантраляваць усё больш і больш. У 2012 годзе, калі Google панізіўся на 5 хвілін, паведамлялася, што ** глабальны ** Інтэрнэт-трафік ** скараціўся на 40% ** Google часта падае на 1-2 гадзіны і з [звальненне іх этычнай групы] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/), сярод іншага, яны будуць станавіцца ўсё менш і менш зручнымі.

Зручнасць не заўсёды добра. Вы павінны быць у курсе таго, што адбываецца, і быць гатовымі да іх падзення, бо няма спосабу, каб сервер не падаў раз-пораз.

Google таксама не такі зручны, як вы думаеце. Ёсць і іншыя значна больш зручныя сайты. Google далёка не зручны, калі вы ўлічваеце іх выпадковыя прыпыненні і спыненне дзеяння ўліковага запісу без адказу (калі вы не прыцягваеце дастаткова ўвагі да ўліковага запісу Google Twitter або не прад'яўляеце іск на іх на суму 100 000 000 долараў і больш), яны скарысталіся вамі, сапсавалі вам і прымусіў вас крычаць у падушку, дзе ніхто не мог чуць вашых крыкаўза дапамогай.

### Чаму гэта важна, усё роўна занадта позна

Гэта менш распаўсюджаны аргумент, але ён патрабуе тлумачэння. З улікам цяперашняга стану большасць сусветных урадаў, разам з некалькімі магутнымі карпарацыямі, здаецца, ведаюць кожны ваш крок, дык навошта нават намагацца ад гэтага сысці? Адказ просты: ** вы заслугоўваеце лепшага **. Калі вам удаецца сысці ад іх у гэты момант, ім складаней адсочваць вашыя крокі далей, і вы можаце пабудаваць новае, больш асабістае жыццё.

[1 крыніца] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Дарэчы, я бяру сваю бясплатную прэмію Reddit кожны раз, калі атрымліваю яе больш за тыдзень зараз (разам з усімі 500 маімі бясплатнымі манетамі), каб яшчэ больш падняць гэтую тэму. Да гэтага часу я даў гэтай пасадзе больш за 14 бясплатных узнагарод. Гэта не шмат, але дробныя рэчы могуць аказаць вялікі ўплыў у залежнасці ад таго, як гэта ўспрымаецца і кім.

### Іншае

На гэты момант іншых аргументаў у мяне няма.

_Спіс няпоўны_

***

## Крыніцы

Капіяваць:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (nadzor_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / сакавік / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Крытыка) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -узоры / няма-чаго-хаваць-аргумент-няма-чаго-сказаць /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- дадзеныя-пра-вас-вы-можаце-знайсці-і-выдаліць-зараз /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -і) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-parnica-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-collection-data-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/01 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- прэтэнзіі ад імя 5-мільёнаў карыстальнікаў iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-не выкарыстоўваецца /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technology / 2014/01 / what-google-can-really-do-with-nest-or-really-nests-data /) [i] (https://www.cbsnews.com/news/google-education -spies-on-збирае дадзеныя-на-мільёны-дзяцей-сцвярджае-пазоў-новы-Мексіка-генеральны пракурор /) [v] (https://www.nationalreview.com/2018/04/the- студэнт-здабыча дадзеных-скандал-пад-нашымі насамі /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did -have-something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Іншыя крыніцы:

[Альянс пяці вачэй] (https://en.wikipedia.org/wiki/Five_Eyes) [Дзевятнаццаць восемдзесят чатыры] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Спасылкі для загрузкі

[Атрымаць Firefox] (https://www.mozilla.org/en-US/firefox/new/) [Атрымаць браўзэр Tor] (https://www.torproject.org/download/) [Іншае / недаступна] (https : //www.example.com)

***

## Мой досвед дэгаглінгу

Нарэшце я пачаў бачыць праблемы з вялікімі тэхналогіямі ў 2018 годзе і пачаў дэгагліраваць. У першыя некалькі месяцаў я дасягнуў значнага прагрэсу. З тых часоў гэта надзвычай замарудзілася.


### З чаго я перайшоў

Google Chrome -> Firefox / Tor

Пошук Google -> DuckDuckGo (па змаўчанні) / Ecosia (калі мне хочацца) / Bing (рэдка)

GMail - ProtonMail (яшчэ не цалкам пераключаны)

Сайты Google -> Самастойнае размяшчэнне (яшчэ не цалкам пераключана)

Google+ -> Наўрад ці выкарыстоўваўся, выдаліўся з-за ўласнага адключэння

Дакументы Google -> Ніколі не выкарыстоўваліся, я проста выкарыстоўваю Microsoft Word 2013 (да 2019 г.) і LibreOffice (ад 2019 г.).

Табліцы Google -> Ніколі не выкарыстоўваліся, я проста выкарыстоўваю Microsoft Excel 2013 (да 2019 г.) і LibreOffice (ад 2019 г.).

Слайды Google -> Ніколі не выкарыстоўваліся, я проста выкарыстоўваю Microsoft PowerPoint 2013 (да 2019 г.) і LibreOffice (ад 2019 г.).

Google Drawings -> Ніколі не выкарыстоўвалася, я проста выкарыстоўваю LibreOffice (2019 і далей).

Gerrit -> Ніколі не выкарыстоўвалася, я проста выкарыстоўваю GitHub (бягучы стандарт), GitLab, BitBucket і SourceForge.

Google Фота -> Ніколі не выкарыстоўвалася

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-цяперашні час)

Google Maps -> OpenStreetMaps / Apple Maps

Перайсці - зрабіць асаблівае выключэнне, але не выкарыстоўваць як функцыянальную мову праграмавання

Dart - робіць асаблівае выключэнне, але не выкарыстоўвае як функцыянальную мову праграмавання

Flutter - робячы асаблівае выключэнне, але не выкарыстоўваючы ў якасці функцыянальнай мовы праграмавання

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> Ніколі не выкарыстоўваўся, я лічу гэта вельмі жудасным

Google Fi -> Ніколі не выкарыстоўваўся

Каляндар Google -> Ніколі не выкарыстоўваўся

Калькулятар Google -> Літаральна любое іншае прыкладанне для калькулятара, нават тэрмінал Linux, які працуе ў рэжыме Python, калі мне падабаецца

Google Nest -> Ніколі не выкарыстоўвалася

Google AMP -> Ніколі не выкарыстоўваўся

Google VPN -> Ніколі не выкарыстоўваўся, таксама аксюмарон

Google Pay -> Ніколі не выкарыстоўвалася

Google Summer of Code -> Ніколі не ўдзельнічаў

Тэнар -> Іншыя сайты GIF, хоць GIF для мяне не надта важныя. Я звычайна атрымліваю GIF-файлы з малюнкаў DuckDuckGo, Imgur, Reddit альбо іншых сайтаў.

Blockly -> Больш не выкарыстоўваецца, не ўпэўнены, што Scratch прама запушчаны. Я стаў функцыянальным праграмістам у 2017 годзе і вырас з Scratch.

GBoard -> Выкарыстоўваўся адзін раз, але закінуты

Google Glass -> Ніколі не выкарыстоўваўся, лічыўся маленькім дзіцем, але вырашыў не атрымліваць яго / выкарыстоўваць, калі ў мяне ёсць магчымасць

_Спіс можа быць няпоўным._

### Прадукты, ад якіх я да гэтага часу не магу пазбегнуць

Па стане на 25 лютага 2021 года, вось прадукты Google, якія перашкаджаюць мне цалкам разладжвацца:

1. YouTube

2. Android

3. Крама Google Play

4. GMail (толькі для школы і некаторых сайтаў)

5. Google Classroom (толькі для школы)

6. Google Translate

7. Уліковы запіс Google

8. Сайты Google (паколькі Google парушае заканадаўства GDPR (і можа пагражаць штрафам у памеры 5 000 000,00 еўра, пакуль яны не выправяцца) і забараняе загружаць гэты прадукт)

Я адключыўся ад усяго астатняга.

***

## Go - гэта зло

Google пракаціўся над мовай праграмавання "Go!", Заснаванай на агентах 2003 года, з іх мовай праграмавання "Go" (з 2009 года праз 6 гадоў) і сцвярджаў, што іх мова зусім не паўплывае на іншую мову. За гэта Google падвергнуўся жорсткай крытыцы, бо ў гэты час іх дэвіз "Не будзь злым" усё яшчэ дзейнічаў, і гэта адзін з многіх выпадкаў, калі дэвіз "Не будзь злым" выйшаў на пенсію.

У рэшце рэшт, развіццё "Go!" Спынілася, а "Go" станавілася ўсё больш і больш распаўсюджаным. Google сцвярджаў, што не будзе забаўляцца над "Go!", Але, у рэшце рэшт, так і атрымалася, і ім гэта ўдалося (па стане на 9 красавіка 2021 г.)

[Больш падрабязна пра Go і пра тое, як перамяшчаць, чытайце тут] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Выкарыстанне DRM

Google выкарыстоўвае DRM (кіраванне лічбавымі абмежаваннямі) праз іх "паслугу" WideVine DRM і іншыя формы. Мэта DRM - знішчыць адкрыты Інтэрнэт і надаць кампаніям манапалістычную ўладу над карыстальнікамі. Вы павінны пазбавіцца ад WideVine цалкам, незалежна ад кошту.

[Больш падрабязна пра WideVine і яго праблемы чытайце тут] (https://github.com/Degoogle-your-life/Its-time-для выразання WideVine-DRM)

***

## Тыповыя памылкі

Гэта спіс некаторых распаўсюджаных памылак з прадуктамі Google.

### Google - гэта не Інтэрнэт

Google / пошук Google - гэта не Інтэрнэт, пошук Google - гэта проста пошукавая машына, накшталт таго, як не кожная гульня для платформы Nintendo зроблена Nintendo, але ліцэнзавана Nintendo, але ў значна большай ступені. Калі б усе серверы Googles адначасова былі знішчаны адначасова, зніклі б толькі Сайты Google, такія як YouTube, Gmail, Дакументы Google, пошук Google і г.д., але большасць Інтэрнэту па-ранейшаму заставалася б там (Wikipedia, Stackoverflow, GitHub, усе вэб-сайты Microsofts, NYTimes, Samsung, TikTok і г.д.), яны могуць страціць сваю функцыю ўваходу ў Google і аналітычную функцыянальнасць, але яны па-ранейшаму будуць функцыянальнымі (калі яны не былі дрэнна запраграмаваны і не спадзяваліся непасрэдна на Google)

***

## Internet Explorer 6 і Chrome

Google Chrome становіцца новым Internet Explorer 6. Калі Google Chrome першапачаткова выйшаў, Firefox быў дамінуючым браўзэрам і ў асноўным забіў Internet Explorer на рынку (які перавысіў 96% да таго, як мільёны людзей перайшлі на Firefox і іншыя браўзэры), калі Google Chrome людзі выйшлі з-за яго хуткасці і таго, што Google (што ў той час не лічылася злом, бо большасць пытанняў прыватнасці яшчэ не выяўлялася) Google Chrome першапачаткова паважаў вэб-стандарты (што і зрабіў Firefox што згубіла Internet Explorer на 96% ад агульнай долі рынкаў браўзэраў), аднак, па меры росту агульнай долі рынку Google Chromes, Google пачаў выдаляць усё новыя і новыя функцыі, дадаваць новыя шпіёнскія праграмы і перастаў прымаць вэб-стандарты, Google Chrome стаў новым Internet Explorer 6.

Асноўная праблема зараз - гэта вэб-сайты толькі з Chrome, якія не будуць працаваць у іншых аглядальніках, бо іх распрацоўшчыкі вырашылі, што не хочуць, каб астатнія 30-40% карыстальнікаў Інтэрнэту, якія не выкарыстоўваюць Chrome, выкарыстоўвалі іх сайт.

Нават Google сам робіць на сваіх сайтах толькі Chrome. Напрыклад, пошук Google прапануе вам загружаць Chrome 3 разы кожныя 10 секунд, калі выяўляе, што вы не карыстаецеся Google Chrome (закранаюцца нават іншыя браўзэры на аснове Chromium, такія як Brave), а такія сайты, як Google Earth, не дазваляюць карыстальнікам Firefox выкарыстоўваць іх сайт (па стане на 2020 г.), а Google Translate не падтрымлівае галасавы ўвод у Firefox і іншых браўзэрах Chrome, якія не ўваходзяць у Google.

### Праблема са Адважным

Іншыя браўзэры, заснаваныя на Chromium, такія як Brave і Microsoft Edge, не цалкам вызвалены ад шпіёнскіх праграм Google. Brave звычайна рэкамендуецца няправільным бокам супольнасці, але Brave па-ранейшаму з'яўляецца праблемай, бо ён выкарыстоўвае Chromium. Інтэрнэт не павінен складацца з браўзэраў толькі Chromium, выбар павінен быць мноствам. Адважны - няправільны шлях.

[Больш падрабязна пра дэгаглінг з Google Chrome / Chromium чытайце тут] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Больш падрабязна пра адключэнне ад ChromeOS / ChromiumOS (Chromebook / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) чытайце тут] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Памылка абнаўлення прыватнасці

Google спрабуе сказаць усяму свету, што яны клапоцяцца аб прыватнасці, бо было ўжо занадта позна. Яны па-ранейшаму заяўляюць, што паважаюць прыватнасць карыстальнікаў, але ўсё яшчэ не вырашаюць усе праблемы з прыватнасцю.

### Адкрыты зыходны код не можа быць частковым

Адкрыты зыходны код не можа быць частковым. Google - таму доказ. Кожны біт і байт зыходнага кода павінны быць бачныя для грамадскасці, нават 8 байта не схаваны.

Такія праекты, як Android і ChromeOS, збольшага з адкрытым зыходным кодам, але ўтрымліваюць большасць уласных шпіёнскіх праграм.

### Аксімарон

Google VPN - гэта аксюмарон. Google не клапоціцца аб прыватнасці, і віртуальная прыватная сетка (VPN) ад такой кампаніі, як яны, стане адным з найгоршых варыянтаў для службы VPN.

***

## Дрэнная прадукцыйнасць

Google не клапоціцца аб прадукцыйнасці сваіх прадуктаў па меншай меры 2017 года, бо іх апошняе праграмнае забеспячэнне для параўнання (Google Octane) было спынена ў 2017 годзе.

***

## Дрэннае кіраванне праектам

У Google вельмі дрэнная ўнутраная сістэма кіравання праектамі. Некаторыя распаўсюджаныя прыклады праграм, якія сталі ўсё больш і больш паніжанымі, ўключаюць Google Duo і музыку YouTube (раней Google Play Music)

Ва ўнутранай сістэме распрацоўкі Googles 1 прыкладанне прыводзіць да іншага з паловай функцыянальнасці, пасля чаго зыходнае прыкладанне выдаляецца. Праз пару гадоў робіцца новае прыкладанне з 75% функцыянальнасцю, а потым выдаляецца прыкладанне з 50% функцыянальнасцю, пасля чаго ствараецца новае прыкладанне з 87,5% стваранай функцыянальнасці, потым прыкладанне з 75% функцыянальнасцю спыняецца , і гэтак далей.

***

## Жахлівая альбо адсутнасць мадэрацыі паслуг

YouTube - самы распаўсюджаны прыклад дрэннай мадэрацыі ў свеце, які стварае найгоршую платформу. Google таксама, здаецца, не разумее, што YouTube не з'яўляецца дзецьмі YouTube.

Для YouTube карыстальнікі прадастаўляюць ненавісны змест пранацысцкага і "белага супрэматызму" з мэтай большага часу ўдзелу і большых грошай. Google таксама зрабіў некалькі вельміглупствы ў іх мадэрацыі, напрыклад, зацвярджэнне хрысціянскага анальнага відэа як змесціва, зробленага для дзяцей, у той жа час абмежаванне відэа па ўзросце. Акрамя таго, не рэдка можна ўбачыць парнаграфічную рэкламу ці рэкламу крыві, размешчаную непасрэдна пад відэаролікам "Дзіцячая акула", а таксама розны іншы кантэнт "для дзяцей".

Карыстальнікі YouTube вельмі часта скардзяцца на дрэнную мадэрацыю на YouTube за дрэнны кантэнт (напрыклад, у прыведзеных вышэй прыкладах), у той час як карыстальнікі могуць выдаляць іх відэа выпадковым чынам без прычыны без магчымасці адмены, а карыстальнікі караюцца за любую форму лаянкі, нават такія нязначныя выпадкі, як выказванні "дзярмо", звычайна параўноўваюць YouTube з [Савецкім Саюзам] (https://en.wikipedia.org/wiki/Soviet_Union) у эпоху Сталіна з-за гэтых няроўных пакаранняў.

У 2021 годзе Google абвясціў, што будзе размяшчаць рэкламу на ўсіх відэа, нягледзячы на ​​тое, што відэа дэмантызуецца (каб Google зарабляў грошы, а стваральнік - не), гэта не занадта шмат тычыцца мадэрацыі, але важна адзначыць.

YouTube мадэруецца (хай і вельмі дрэнна), але рэкламная служба Google, якая робіць ім большую частку грошай, здаецца, практычна не мадэруе.

[Больш падрабязна пра праблемы мадэрацыі YouTube і пра тое, як перайсці з YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Рэклама для Google Play ствараецца на фермах ботаў, вы можаце зразумець, па тых самых сцэнарыях рэкламы, якія выкарыстоўваюцца сотнямі кампаній з невялікімі зменамі і ніякага дачынення да прадукту (агульныя прыклады: Playrix (хатнія пейзажы, садовыя пейзажы) Fishdom, Mafia City і тысячы іншых) разам з бурнай шкоднай тэндэнцыяй рэкламы, якая сцвярджае, што карыстальнікі могуць зарабляць грошы, гуляючы ў гульні, слухаючы музыку і г. д. PayPal гэтага не каментаваў, але відавочна, што гэта афёра, быццам бы вы маглі зрабіць больш за 10 000 долараў менш чым за 20 секунд, гуляючы ў гульню, гарантавана, ніхто не будзе рабіць працу, а будзе рабіць гэта замест гэтага, што немагчыма, і бізнес не можа працаваць так. Гэта відавочная афёра ўзмацняецца з 2019 года, і цяпер фермы-боты, якія вырабляюць гэтыя аб'явы, змагаюцца паміж сабой у сваіх аб'явах.

Некалькі рэкламных аб'яў таксама вельмі распусныя і спрабуюць прымусіць карыстальнікаў (большасць з іх - карыстальнікі, якія не дасягнулі 13 гадоў, альбо ботаў) перабіраць сэксуальныя маніпуляцыі.

Шмат якія прыкладанні выкарыстоўваюць ботаў і астратурфінг сваіх прадуктаў, таму кожны раз, калі робіцца дрэнны агляд, уліковыя запісы лялечных ботаў пачнуць размяшчаць водгукі з 5 зорак і паспрабуюць адмаўляць вашу крытыку. [Google робіць гэта і самі] (# Астротурфінг)

[Даведайцеся больш пра праблемы з Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Астротурфінг

Агульнае вызначэнне [(з Вікіпедыі)] (https://en.wikipedia.org/wiki/Astroturfing)

«
Астротурфінг - гэта практыка маскіравання спонсараў паведамлення альбо арганізацыі (напрыклад, палітычных, рэкламных, рэлігійных альбо грамадскіх), каб яно выглядала так, быццам яно паходзіць ад і падтрымліваецца нізавымі ўдзельнікамі. Гэта практыка, прызначаная надаць заявам ці арганізацыям давер, утойваючы інфармацыю пра фінансавую сувязь крыніцы. Тэрмін astroturfing паходзіць ад AstroTurf, маркі сінтэтычных дываноў, распрацаваных, каб нагадваць натуральную траву, як гульню слова "нізавыя". Вынік выкарыстання гэтага тэрміна заключаецца ў тым, што замест "сапраўднага" або "натуральнага" нізавага намагання, якое стаіць за разгляданай дзейнасцю, існуе "фальшывы" альбо "штучны" выгляд падтрымкі.
«

У Google ёсць гісторыя астратурфінгу, каб здавалася, што яны не робяць нічога дрэннага (у працэсе астратурфінгу гэта зло), напрыклад, размяшчэнне крытыкі Google на такой платформе, як Twitter (у якой у іх ёсць уліковы запіс), прывядзе некалькі ўліковых запісаў, якія існавалі некаторы час, але ніколі не размяшчаліся да выхаду і сцвярджаючы, што сказанае вамі непраўдзівае, а потым сцвярджаючы, што Google - лепшая кампанія, але зробленае такім чынам, што можа быць не відавочна, што гэта боты для большасці людзей.

***

## Незаконная і неэтычная практыка вядзення бізнесу

Google выкарыстоўвае незаконную і неэтычную дзелавую практыку для садзейнічання іх манаполіі, напрыклад, выкарыстанне падатковых сховішчаў, перавод працоўных месцаў на іншае месца і працягванне незаконнай інвазіўнай дзейнасці ў якасці кошту вядзення бізнесу.

### У Еўропе

Еўропа часта падавала ў суд на Google, самы буйны судовы працэс супраць незаконных паводзін у Android, у выніку чаго Google атрымаў 5 000 000 000 еўра (што эквівалентна 5 947 083 703,68 долараў ЗША за грошы 9 красавіка 2021 г.)

### У Паўночнай Амерыцы

Злучаныя Штаты яшчэ не далі амаль дастаткова штрафу Google, у параўнанні са штрафам у 5 000 000 000 еўрапейцаў.

### Супярэчнасці

Google не клапоціцца пра праблему, пакуль не стварае супярэчнасць, тады яны зробяць дрэнную спробу яе выправіць, роўна столькі, каб спрэчка часова сышла, а потым праблема пагаршаецца ў геаметрычнай прагрэсе, пакуль не ствараецца новая спрэчка. цыкл працягваецца. Ім проста недастаткова, каб зрабіць што-небудзь сур'ёзнае.

***

## Google аўтаматызаваны

Як камПані, Google у асноўным аўтаматызаваны, з меншай умеранасцю, чым аўтаматызацыя.

Кампанія не павінна быць поўнасцю аўтаматызавана. Прыклад таму - Google. Мадэрацыя жудасная, калі гэта робіцца толькі з дапамогай ІІ, YouTube з'яўляецца добрым прыкладам, нават калі лішнія некалькі (сотні, а можа, і тысяча) людзей мадэруюць сайт, дзе, відаць, так дрэнна, што большасць з іх павінны атрымліваць тэрапію падчас працы.

***

## Android

Android належыць Google. Частка альянсу Open Handset Alliance (які не быў адкрыты з часоў Android) Android стала яшчэ адным манапольным пунктам для Google і вельмі складана пазбегнуць.

Паведамляецца, што Android тэлефануе дадому па меншай меры 10 разоў на дзень, і, нягледзячы на ​​частковую адкрытую крыніцу, ён усё яшчэ дзейнічае як шпіёнскае праграмнае забеспячэнне.

Было створана некалькі праектаў для альтэрнатывы з Android, але патрабуецца ўкараненне прылады. Гэта проста немагчыма для канкрэтных тэлефонаў Samsung у ЗША з-за DRM Knox. Агульныя альтэрнатывы Android - iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch і PiPhone (Pi Phone - гэта брэнд тэлефонаў, якія працуюць на розных сістэмах Linux на мабільных прыладах, такіх як Fedora, Ubuntu, Arch і г.д.).

[Глядзіце маё даследаванне па атрыманні функцыянальнай магчымасці віртуальнай машыны Android з адключэннем] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Паглядзіце, як адключыць Google ад Android] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Невялікія дзеянні ў дапамогу

Важна распаўсюджваць інфармаванасць усімі спосабамі. Для мяне я не толькі часта размаўляю пра дэгуглінг і пішу артыкулы, але ў мяне таксама ёсць невялікая звычка: я штодня даю бясплатную ўзнагароду Reddit у замацаваным паведамленні на r / degoogle для павышэння дасведчанасці. Да гэтага часу я даў амаль 30 узнагарод замацаванаму допісу (я таксама выдаткаваў 500 сваіх бясплатных манет на 10 узнагарод за гэты пост)

***

## Недаверлівы

Google нельга давяраць і ніколі больш не давяраць. Яны цалкам перайшлі ад "не будзь злым" (яны заўсёды былі злымі) да таго, каб быць зусім злымі і не спрабаваць гэтага схаваць.

***

## Іншыя рэчы, якія трэба праверыць

[Google Graveyard (killbygoogle.com) - адсартаваны спіс з 224+ прадуктаў, якія Google забіў] (https://killedbygoogle.com/)

> [Спасылка на GitHub] (https://github.com/codyogden/killedbygoogle)

[Прафсаюз работнікаў алфавіту - новы прафсаюз работнікаў Google, які налічвае больш за 800 членаў] (https://alphabetworkersunion.org/people/our-union/)

[Не хочаце расставацца з велікодным яйкам дыназаўра? Вы ахапілі гэты сайт] (https://chromedino.com/)

Ёсць і іншыя альтэрнатывы, проста пашукайце іх.

***

Для гэтага артыкула неабходна праверыць некаторыя факты

***

## Інфармацыя пра файл

Тып файла: `Разметка (* .md)`

Колькасць радкоў (уключаючы пустыя радкі і радок кампілятара): `968`

Версія файла: `6 (нядзеля, 18 красавіка 2021 г., 16:18)`

***

### Статус праграмнага забеспячэння

Усе мае працы - гэта бясплатныя некаторыя абмежаванні. DRM (** D ** igital ** R ** абмежаванні ** M ** кіраванне) адсутнічае ні ў адной з маіх работ.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Гэты стыкер падтрымліваецца Фондам свабоднага праграмнага забеспячэння. Я ніколі не маю намеру ўключаць DRM у свае творы.

Я выкарыстоўваю абрэвіятуру "Кіраванне лічбавымі абмежаваннямі" замест больш вядомай "Кіраванне лічбавымі правамі", паколькі распаўсюджаны спосаб вырашэння праблемы з'яўляецца ілжывым, правы на DRM не існуюць. Арфаграфія "Кіраванне лічбавымі абмежаваннямі" больш дакладная і падтрымліваецца [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) і [Фондам свабоднага праграмнага забеспячэння (FSF)] https://en.wikipedia.org/wiki/Free_Software_Foundation)

Гэты раздзел выкарыстоўваецца для павышэння дасведчанасці аб праблемах з DRM, а таксама для пратэсту. DRM дэфектны па дызайне і з'яўляецца асноўнай пагрозай для ўсіх карыстальнікаў кампутараў і свабоды праграмнага забеспячэння.

Крэдыт выявы: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Інфармацыя пра спонсара

! [SponsorButton.png] (SponsorButton.png) <- Не націскайце гэтую кнопку, гэта не працуе, гэта проста выява. Сапраўдная кнопка знаходзіцца ўверсе старонкі ў правым куце (<- L ** R ** ->)

Вы можаце спансіраваць гэты праект, калі хочаце, але, калі ласка, пазначце, на што вы хочаце ахвяраваць. [Глядзіце сродкі, якія вы можаце ахвяраваць тут] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Іншую інфармацыю пра спонсара можна паглядзець [тут] (https://github.com/seanpm2001/Sponsor-info/)

Паспрабуйце! Кнопка спонсара знаходзіцца побач з кнопкай "Глядзець / не глядзець".

***

## Гісторыя файла



 * Пачаў файл

> * Дададзены раздзел загалоўка

> * Дададзены індэкс

> * Дададзены раздзел пра

> * Дададзены раздзел Вікі

> * Дададзены раздзел гісторыі версій

> * Дададзены раздзел праблем.

> * Дададзены раздзел мінулых выпускаў

> * Дададзены раздзел мінулых запытаў на выцягванне

> * Дададзены раздзел актыўных запытаў на выцягванне

> * Дададзены раздзел удзельнікаў

> * Дададзены раздзел

> * Дададзены раздзел пра README

> * Дададзены раздзел гісторыі версій README

> * Дададзены раздзел рэсурсаў

> * Дададзены раздзел статусу праграмнага забеспячэння з налепкай і паведамленнем без DRM

> *Дададзены раздзел з інфармацыяй пра спонсара

> * Іншых змен у версіі 0.1 няма

Версія 1 (пятніца, 19 лютага 2021 г., 17:20)

> Змены:

> * Пачаў файл

> * Дададзены раздзел асноўнага апісання

> * Дададзены раздзел апісання сховішча

> * Дададзены спіс артыкулаў з 14 запісамі

>> * Дададзены раздзел "звязаныя артыкулы"

>> * Дададзены раздзел `гл. Таксама`

> * Дададзены раздзел інфармацыі пра файл

> * Дададзены раздзел гісторыі файлаў

> * Дададзены ніжні калонтытул

> * Ніякіх іншых змен у версіі 1 няма

Версія 2 (пятніца, 19 лютага 2021 г., 17:26)

> Змены:

> * Дададзены раздзел стану перакладу

> * Дададзены іншыя рэчы, каб праверыць раздзел

> * Дададзены раздзел прыватнасці

> * Дададзены індэкс

> * Дададзены падраздзел статусу праграмнага забеспячэння

> * Дададзены іншы раздзел кампаній па барацьбе з Google

>> * Дададзены несанкцыянаваны падраздзел

>> * Дададзены пастаянны падраздзел

> * Дададзены раздзел крыніц

> * Дададзены раздзел спасылак для загрузкі

> * Абноўлены раздзел інфармацыі пра файл

> * Абноўлены раздзел гісторыі файлаў

> * Ніякіх іншых змен у версіі 2 няма

Версія 3 (серада, 24 лютага 2021 г., 19:56)

> Змены:

> * Абноўлены індэкс

> * Згаданы значок degoogle і новая арганізацыя GitHub

> * Дададзены спасылкі на новыя артыкулы

> * Дададзены раздзел процідзеяння іншым аргументам

>> * Дададзены падраздзел зручнасці

>> * Дададзены падраздзел "Чаму нават турбаваць"

>> * Дададзены іншы падраздзел

> * Абноўлены некаторыя дадзеныя

> * Абноўлены раздзел інфармацыі пра файл

> * Абноўлены раздзел гісторыі файлаў

> * Ніякіх іншых змен у версіі 3 няма

Версія 4 (чацвер, 25 лютага 2021 г., 21:31)

> Змены:

> * Дададзены спасылкі на 10 новых артыкулаў

> * Дададзены раздзел пра мой вопыт дэгаглявання

> * Абноўлены індэкс

> * Абноўлены раздзел інфармацыі пра файл

> * Абноўлены раздзел гісторыі файлаў

> * Ніякіх іншых змен у версіі 4 няма

Версія 5 (пятніца, 9 красавіка 2021 г., 18:02)

_У апошні час у мяне не хапае абнаўленняў у руху супраць Google, я працую над тым, каб вярнуцца да яго пасля больш чым месячнага перапынку._

> Змены:

> * Абноўлены раздзел загалоўка

> * Абноўлены індэкс

> * Абноўлены спіс моў: фіксаваныя спасылкі і дададзены больш падтрымоўваных моў

> * Абноўлены раздзел стану артыкула, дадаўшы 4 відэльцы

> * Абноўлены раздзел стану праграмнага забеспячэння

> * Дададзены раздзел Go is evil

> * Дададзена раздзел DRM

> * Дададзены раздзел Агульныя памылкі

>> * Дададзена, што Google не з'яўляецца падраздзелам Інтэрнэт

> * Дададзены раздзел Internet Explorer 6 і Chrome

>> * Дададзена праблема з падраздзелам "Адважны"

> * Дададзена выдаленне прыватнасці Faux

> * Дададзены Open source не можа быць частковым падраздзелам

> * Дададзены падраздзел Oxymoron

> * Дададзены раздзел "Дрэнная прадукцыйнасць"

> * Дададзены раздзел дрэннага кіравання праектамі

> * Дададзены раздзел Жудаснае альбо адсутнасць мадэрацыі паслуг

> * Дададзены раздзел Астротурфінг

> * Дададзены раздзел Незаконная і неэтычная дзелавая практыка

> * Дададзены падраздзел In Europe

>> * Дададзены падраздзел "У Паўночнай Амерыцы"

>> * Дададзены падраздзел Супярэчнасці

> * Дададзены аўтаматызаваны раздзел Google

> * Дададзены раздзел Android

> * Дададзены раздзел "Маленькія дзеянні"

> * Дададзены раздзел "Недакладныя"

> * Дададзены раздзел пра спонсара

> * Абноўлены калонтытул

> * Абноўлены раздзел інфармацыі пра файл

> * Абноўлены раздзел гісторыі файлаў

> * Ніякіх іншых змен у версіі 5 няма

Версія 6 (нядзеля, 18 красавіка 2021 г., 16:18)

> Змены:

> * Абноўлены індэкс

> * Дададзена новае агляднае апісанне

> * Абноўлена інфармацыя пра стан артыкула

> * Дададзеная спасылка на новы артыкул Google FLoC

> * Дададзеная спасылка на артыкул Wuest 3n Fuchs Degoogle і агульная інфармацыя пра яго

> * Абноўлены раздзел інфармацыі пра файл

> * Абноўлены раздзел гісторыі файлаў

> * Іншых змен у версіі 6 няма

Версія 7 (Хутка)

> Змены:

> * Хутка

> * Ніякіх іншых змен у версіі 7 няма

Версія 8 (Хутка)

> Змены:

> * Хутка

> * У версіі 8 ніякіх іншых змен няма

Версія 9 (Хутка)

> Змены:

> * Хутка

> * У версіі 9 ніякіх іншых змен няма

Версія 10 (Хутка)

> Змены:

> * Хутка

> * Ніякіх іншых змен у версіі 10 няма

Версія 11 (Хутка)

> Змены:

> * Хутка

> * Ніякіх іншых змен у версіі 11 няма

Версія 12 (Хутка)

> Змены:

> * Хутка

> * Ніякіх іншых змен у версіі 12

***

## Калонтытул

Вы дасягнулі канца гэтага файла

([Вярнуцца да пачатку] (# Уверсе) | [Вярнуцца да GitHub] (https://github.com))

### EOF

***
