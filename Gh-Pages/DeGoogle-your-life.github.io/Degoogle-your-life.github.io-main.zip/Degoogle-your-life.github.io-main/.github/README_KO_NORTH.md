***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling-Degoogle your life

이것은 일반적인 디 구글링 정보와 다른 글에 대한 링크에 대한 주요 디 구글링 문서입니다.

[GitHub 조직 목록보기] (https://github.com/Degoogle-your-life)

***

_ 다른 언어로이 기사 읽기 : _

** 현재 언어 : **`영어 (미국)`_ (정확한 언어를 영어로 바꾸려면 번역을 수정해야 할 수 있음) _

_🌐 언어 목록 _

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanian | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) 아랍어 | [hy հայերեն] (/. github / README_HY.md) 아르메니아어 | [az Azərbaycan dili] (/. github / README_AZ.md) 아제르바이잔 어 | [eu Euskara] (/. github /README_EU.md) 바스크어 | [be Беларуская] (/. github / README_BE.md) 벨로루시 어 | [bn বাংলা] (/. github / README_BN.md) 벵골어 | [bs Bosanski] (/. github / README_BS.md) 보스니아 어 | [bg български] (/. github / README_BG.md) 불가리아어 | [ca Català] (/. github / README_CA.md) 카탈로니아 어 | [ceb Sugbuanon] (/. github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) 중국어 (간체) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) 중국어 (번체) | [co Corsu] (/. github / README_CO.md) 코르시카 어 | [hr Hrvatski] (/. github / README_HR.md) 크로아티아어 | [cs čeština] (/. github / README_CS .md) 체코 어 | [da dansk] (README_DA.md) 덴마크어 | [nl Nederlands] (/. github / README_ NL.md) 네덜란드어 | [** en-us 영어 **] (/. github / README.md) 영어 | [EO 에스페란토] (/. github / README_EO.md) 에스페란토 | [et Eestlane] (/. github / README_ET.md) 에스토니아어 | [tl Pilipino] (/. github / README_TL.md) 필리핀어 | [fi Suomalainen] (/. github / README_FI.md) 핀란드어 | [fr français] (/. github / README_FR.md) 프랑스어 | [fy Frysk] (/. github / README_FY.md) 프리지아 어 | [gl Galego] (/. github / README_GL.md) 갈리시아어 | [ka ქართველი] (/. github / README_KA) 그루지야 어 | [de Deutsch] (/. github / README_DE.md) 독일어 | [el Ελληνικά] (/. github / README_EL.md) 그리스어 | [gu ગુજરાતી] (/. github / README_GU.md) 구자라트 어 | [ht Kreyòl ayisyen] (/. github / README_HT.md) 아이티 크리올 어 | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) 하 와이어 | [he עִברִית] (/. github / README_HE.md) 히브리어 | [hi हिन्दी] (/. github / README_HI.md) 힌디어 | [hmn 흐몽] (/. github / README_HMN.md) 흐몽 | [hu Magyar] (/. github / README_HU.md) 헝가리어 | [is Íslenska] (/. github / README_IS.md) 아이슬란드 어 | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) 아이슬란드 어 | [ga Gaeilge] (/. github / README_GA.md) 아일랜드어 | [It Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) 일본어 | [jw Wong jawa] (/. github / README_JW.md) 자바어 | [kn ಕನ್ನಡ] (/. github / README_KN.md) 칸나다어 | [kk Қазақ] (/. github / README_KK.md) 카자흐어 | [km ខ្មែរ] (/. github / README_KM.md) 크메르어 | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) 한국어 (대한민국) | [ko-north 문화어] (README_KO_NORTH.md) 한국어 (북부) (아직 번역되지 않음) | [ku Kurdî] (/. github / README_KU.md) 쿠르드어 (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) 키르기스 어 | [lo ລາວ] (/. github / README_LO.md) 라오 어 | [la Latine] (/. github / README_LA.md) 라틴어 | [lt Lietuvis] (/. github / README_LT.md) 리투아니아어 | [lb Lëtzebuergesch] (/. github / README_LB.md) 룩셈부르크 어 | [mk Македонски] (/. github / README_MK.md) 마케도니아 어 | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) 말레이어 | [ml മലയാളം] (/. github / README_ML.md) 말라 얄 람어 | [mt Malti] (/. github / README_MT.md) 몰타어 | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) 마라 티어 | [mn Монгол] (/. github / README_MN.md) 몽골어 | [my မြန်မာ] (/. github / README_MY.md) 미얀마 (버마어) | [ne नेपाली] (/. github / README_NE.md) 네팔어 | [no norsk] (/. github / README_NO.md) 노르웨이어 | [또는 ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (오리 야어) | [ps پښتو] (/. github / README_PS.md) 파슈토어 | [fa فارسی] (/. github / README_FA.md) | 페르시아어 [pl polski] (/. github / README_PL.md) 폴란드어 | [pt português] (/. github / README_PT.md) 포르투갈어 | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Q로 시작하는 언어가 없습니다. | [ro Română] (/. github / README_RO.md) 루마니아어 | [ru русский] (/. github / README_RU.md) 러시아어 | [sm Faasamoa] (/. github / README_SM.md) 사모아 어 | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) 스코틀랜드 게 일어 | [sr Српски] (/. github / README_SR.md) 세르비아어 | [세소 토어] (/. github / README_ST.md) 세소 토어 | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) 신 디어 | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) 슬로바키아어 | [sl Slovenščina] (/. github / README_SL.md) 슬로베니아어 | [so Soomaali] (/. github / README_SO.md) 소말 리어 | [[es en español] (/. github / README_ES.md) 스페인어 | [su Sundanis] (/. github / README_SU.md) 순 다어 | [sw Kiswahili] (/. github / README_SW.md) 스와힐리어 | [sv Svenska] (/. github / README_SV.md) 스웨덴어 | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) 텔루구 어 | [th ไทย] (/. github / README_TH.md) 태국어 | [tr Türk] (/. github / README_TR.md) 터키어 | [tk Türkmenler] (/. github / README_TK.md) 투르크멘 어 | [uk Український] (/. github / README_UK.md) 우크라이나어 | [ur اردو] (/. github / README_UR.md) 우르두어 | [ug ئۇيغۇر] (/. github / README_UG.md) 위구르어 | [uz O'zbek] (/. github / README_UZ.md) 우즈베크 어 | [vi Tiếng Việt] (/. github / README_VI.md) 베트남어 | [cy Cymraeg] (/. github / README_CY.md) 웨일스 어 | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) 이디시어 | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) 110 개 언어로 제공 (북한이 아직 번역되지 않았기 때문에 영어와 북한어를 계산하지 않는 경우 108 개 [여기에서 읽어보기] (/ OldVersions / 한국어 (North ) /README.md))

영어 이외의 언어로 된 번역은 기계 번역이며 아직 정확하지 않습니다. 2021 년 2 월 5 일 현재 오류가 수정되지 않았습니다. [여기] (https://github.com/seanpm2001/Degoogle-your-life/issues/)에서 번역 오류를 신고하세요. 소스와 함께 수정 사항을 백업하고 안내해주세요. , 저는 영어 이외의 언어를 잘 모르기 때문에 (결국 번역가를 구할 예정입니다) 보고서에 [wiktionary] (https://en.wiktionary.org) 및 기타 출처를 인용 해주세요. 그렇게하지 않으면 게시 된 수정 사항이 거부됩니다.

참고 : GitHub의 마크 다운 해석 (및 거의 모든 다른 웹 기반 마크 다운 해석)의 제한으로 인해 이러한 링크를 클릭하면 내 GitHub 프로필 페이지가 아닌 별도의 페이지에있는 별도의 파일로 리디렉션됩니다. README가 호스팅되는 [seanpm2001 / seanpm2001 저장소] (https://github.com/seanpm2001/seanpm2001)로 리디렉션됩니다.

DeepL 및 Bing Translate와 같은 다른 번역 서비스에서 필요한 언어에 대한 지원이 제한되거나 지원되지 않기 때문에 Google 번역으로 번역이 수행됩니다 (Google 번역 반대 캠페인의 경우 매우 아이러니). 대안을 찾고 있습니다. 어떤 이유로 다양한 번역에서 서식 (링크, 구분선, 굵게, 기울임 꼴 등)이 엉망이됩니다. 수정하는 것은 지루하고 비 라틴어 문자가있는 언어에서 이러한 문제를 해결하는 방법을 모르겠습니다. 이러한 문제를 해결하려면 오른쪽에서 왼쪽으로 쓰는 언어 (예 : 아랍어)의 추가 도움이 필요합니다.

유지 관리 문제로 인해 많은 번역이 구버전이며이`README` 기사 파일의 오래된 버전을 사용하고 있습니다. 번역가가 필요합니다. 또한 2021 년 4 월 9 일부로 모든 새 링크가 작동하는 데 시간이 걸릴 것입니다.

***

## 인덱스

[00.0-제목] (# Degoogling --- Degoogle-your-life)

> [00.5-색인] (# 색인)

[01.0-기본 설명] (# Basic-description)

> [01.5-저장소 헤더] (# Degoogle-your-life)

[02.0-기사] (# Articles)

[03.0-개인 정보 보호] (# Privacy)

[04.0-기타 안티 Google 캠페인] (# Other-anti-Google-campaigns)

> [04.0.1-소멸] (# Defunct)

> [04.0.2-진행 중] (# Ongoing)

[05.0-다른 인수 반박] (# Countering-other-arguments)

> [05.0.1-편의] (# 편의)

> [05.0.2-왜 중요한가요? 어차피 너무 늦었 어] (# 왜 중요해, 너무 늦었 어)

> [05.0.3-기타] (# 기타)

[06.0-소스] (# 소스)

[07.0-다운로드 링크] (# Download-links)

[08.0-My degoogling experience] (# My-degoogling-experience)

> [08.0.1-전환 대상] (# What-I-switched-from)

> [08.0.2-여전히 벗어날 수없는 제품] (# Products-I-still-cannot-get-away-from)

[09.0-기타 체크 아웃 항목] (# 기타 체크 아웃 항목)

[10.0-파일 정보] (# File-info)

> [10.0.1-소프트웨어 상태] (# Software-status)

[11.0-파일 기록] (# File-history)

[12.0-바닥 글] (# Footer)

***

## 기본 설명

[위키 백과 : Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

DeGoogle 운동 (de-Google 운동이라고도 함)은 개인 정보 보호 활동가가 회사에 대한 개인 정보 보호 문제가 증가함에 따라 사용자에게 Google 제품 사용을 완전히 중단 할 것을 촉구하면서 생겨난 풀뿌리 캠페인입니다. 이 용어는 삶에서 Google을 제거하는 행위를 의미합니다. 인터넷 거인의 시장 점유율이 증가함에 따라 디지털 공간에서 회사에 대한 독점적 힘이 생겨나면서 점점 더 많은 언론인들이 회사 제품에 대한 대안을 찾는 데 어려움을 겪고 있습니다.

**역사**

2013 년 Venturebeat의 John Koetsier는 Amazon의 Kindle Fire Android 기반 태블릿이 "구글에서 벗어난 Android 버전"이라고 말했습니다. 2014 년 US News의 John Simpson은 Google 및 기타 검색 엔진의 "잊혀 질 권리"에 대해 썼습니다. 2015 년 Irish Times의 Derek Scally는 "De-Google your life"방법에 대한 기사를 썼습니다. 2016 년 Android Authority의 Kris Carlon은 CyanogenMod 14 사용자가 휴대 전화를 "de-Google"할 수 있다고 제안했습니다. CyanogenMod는 Google 앱 없이도 잘 작동하기 때문입니다. 2018 년 Inverse의 Nick Lucchesi는 ProtonMail이 "당신의 삶을 완전히 탈구 할 수있는 방법"을 홍보하는 방법에 대해 썼습니다. Lifehacker의 Brendan Hesse는 "종료Google. "Gizmodo 기자 Kashmir Hill은 자신이 회의를 놓치고 Google 캘린더를 사용하지 않고 모임을 조직하는 데 어려움을 겪었다 고 주장합니다. 2019 년 Huawei는 Google에서 제공하는 서비스를 사용하지 못했던 필리핀의 전화 소유자에게 환불을했습니다. 회사 제품이 없어 정상적인 인터넷 사용이 불가능하다는 대안이 있습니다.

***

# Degoogle-your-life
일반 디 구글링 정보와 다른 디 구글링 저장소에 대한 링크를위한 저장소입니다.

***

## 기사

### 기사 상태

_ 모든 기사는 현재 진행 중이며 대대적 인 개선이 필요합니다. 제안 및 수정이 허용됩니다 ._

[Chrome 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <!-1!->

[ChromeBook 사용 중지] (https://github.com/seanpm2001/Stop-using-Chromebooks) <!-2!->

[WideVine DRM 사용 중지 / WideVine DRM을자를 시간입니다] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <!-3!->

[ReCaptcha 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <!-4!->

[YouTube에서 대체] (https://github.com/seanpm2001/Alternating-from-YouTube) <!-5!->

[인터넷 검색 중지, Google 검색 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <!-6!- >

[Gmail 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <!-7!->

[Android 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <!-8!->

[Google Amp를 피해야하는 이유] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <!-9!->

[Google 드라이브 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <!-10!->

[Google지도 및 Google 어스 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <!-11!- ->

[Hey Google, 중지] (https://github.com/seanpm2001/Hey-Google-Stop) <!-12!->

[Google / Play 북 읽기 중지] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <!-13!->

[Google 클래스 룸 사용 중지] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <!-14!->

[Google 번역 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <!-15!->

[Google 계정 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Accounts) <!-16!->

** 곧 작성 될 새로운 기사 : **

[Gerrit 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <!-17!->

[Google Analytics 사용을 중지해야하는 이유 (저장소는 2021 년 2 월 24 일 수요일 오후 4시 13 분 현재 중단됨)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics) <!-18!->

<!-작업 분할기!->

[Google 애드 센스 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <!-19!->

[Google One 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <!-20!->

[Google+ 사용을 중지해야하는 이유 (존재하지 않음)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <!-21!->

[Google Play 스토어 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <!-22!->

[Google 문서 도구 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <!-23!->

[Google 프레젠테이션 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <!-24!->

[Google 스프레드 시트 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <!-25!->

[Google 설문지 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <!-26!->

[Google Cardboard 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <!-27!->

[Google 메시지 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <!-28!->

[Google Material Design 사용을 중단해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <!-29!->

[Google Glass / Glasses 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <!-30!->

[Google Fuchsia 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <!-31!->

[GBoard 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <!-32!->

[Google Home 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <!-33!->

[Google Nest 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <!-34!->

[Why Google 행 아웃 사용을 중지해야 함 (사용 중지됨)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <!-35!->

[Google Duo 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <!-36!->

[Google Tensorflow 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <!-37!->

[Google Blockly 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <!-38!->

[Google Flutter 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <!-39!->

[Googles Go 프로그래밍 언어 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <!-40!->

[Google Dart 프로그래밍 언어 사용을 중단해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <!-41!->

[Google WebP 이미지 형식 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <!-42!->

[Google WebM 동영상 형식 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <!-43!->

[Google 비디오 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <!-44!->

[Google 사이트 도구 (클래식) 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <!-45!->

[Google 사이트 도구 사용을 중지해야하는 이유 ( "New")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <!-46!->

[Google Pay 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <!-47!->

[Android Pay 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <!-48!->

[Google VPN (모순) 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <!-49!->

[Google 포토 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <!-50!->

[Google 캘린더 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <!-51!->

[VirusTotal 사용을 중단해야하는 이유 (2012 년 9 월부터 Google 소유이므로] (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal)) <!-52!- >

[Google Fi 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi) <!-53!->

[Google Stadia 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <!-54!->

[Google Keep 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <!-55!->

[Google Base 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <!-56!->

[Google Summer of Code 참여를 중단해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <!-57!- >

[Google 카메라 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <!-58!->

[Google 계산기 사용을 중단해야하는 이유 (극단적으로 보일 수 있지만 모든 것에서 degoogle을 사용해야하며 대체하기 매우 쉽습니다)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- 계산기) <!-59!->

[Google Survey + 보상 사용을 중단해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <!-60!->

[Google 드로잉 사용을 중지해야하는 이유] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <!-61!->

[Tenor (GIF 사이트, 2019 년부터 Google 소유) 사용을 중단해야하는 이유] (Https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <!-62!- ->

** 기사 [로드맵 AB] (DegoogleCampaign_2021Roadmap_Part1.md) (최대 2021 년 3 월 12 일) 2 일 휴무 **

** 기사 [로드맵 BB] (DegoogleCampaign_2021Roadmao_Part2.md) (최대? 2021) 2 일 휴무 **

기사 상태

모든 기사는 현재 진행 중이며 대대적 인 개선이 필요합니다. 제안 및 수정이 허용됩니다.

** 포크 **

내 Degoogle 네트워크를 확장하고 액세스의 용이성을 추가하고 커뮤니티를 외칩니다.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | 분기 위치 : [https://github.com/wacko1805/Fossapps] (https://github.com/wacko1805/Fossapps) (영어)

2. [개인 정보 링크] (https://github.com/Degoogle-your-life/Privacy-links) | 분기 위치 : [https://github.com/Arturro43/privacy-links] (https://github.com/Arturro43/privacy-links) (폴란드어)

3. [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | 출처 : [https://github.com/LinuxCafeFederation/Delightful-Privacy] (https://github.com/LinuxCafeFederation/Delightful-Privacy) (영어)

4. [차단 목록] (https://github.com/Degoogle-your-life/blocklists) | 출처 : [https://github.com/jmdugan/blocklists](https://github.com/jmdugan/blocklists) (영어)

** 관련 **

[Degoogled Android 폰 가상 머신 연구] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**또한보십시오:**

[Wikipedia에서 Google에 대한 비판] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[Google Graveyard (killedbygoogle.com)-Google이 죽인 224 개 이상의 제품 목록] (https://killedbygoogle.com/)

> [GitHub 링크] (https://github.com/codyogden/killedbygoogle)

[알파벳 노동자 노조-800 명 이상의 회원이있는 Google의 새로운 노조] (https://alphabetworkersunion.org/people/our-union/)

[공룡 부활절 달걀과 헤어지고 싶지 않나요? 이 웹 사이트에서 다루었습니다] (https://chromedino.com/)

***

## 프라이버시

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https : //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https : // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https : //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https : // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# 비평) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -및) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https : //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https : // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https : // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https : / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019 / 01 / 21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- 5 백만 명의 iPhone 사용자를 대신하여 청구) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https : / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https : // arstechnica .com / information-technolo gy / 2014 / 01 / what-google-can-really-do-with-nest-or-really-nests-data /) [i] (https://www.cbsnews.com/news/google-education-spies -on-collects-data-on-millions-of-kids-alleges-lawsuit-new-mexico-attorney-general /) [v] (https://www.nationalreview.com/2018/04/the-student- 데이터 마이닝 스캔dal-under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/ 2019 / 09 / 04 / technology / google-youtube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to -hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (이 증거를 가지고 계속할 수는 있었지만 이 모든 기사를 찾고 검토하는 데 오랜 시간이 걸렸습니다)

스파이웨어가 포함 된 모든 Google 제품으로 인해 Google 제품의 개인 정보는 항상 나쁩니다.

무엇을하든 Google을 사용하면 모든 민감한 개인 데이터가 Google 및 다른 사람에게 전송됩니다. 구글도 공개 프로그램을 진행하고있는 것으로 나타났다. 예를 들어, 내가 방문하지 않은 유튜브 탭이 열린 개인 경험 (파이어 폭스)에서 오프라인으로 여러 동영상을 보았습니다 (VLC 미디어 플레이어) 나중에 추천 항목을 확인하러 갔을 때 제가 본 거의 모든 동영상이었습니다. 그들이 다른 프로그램을 염탐하고 있다는 것은 의심의 여지가 없습니다.

Chrome (및 기타 여러 브라우저)에는 시크릿 모드가 있습니다. Chrome에서는 Google이 여전히 데이터를 마이닝하므로이 모드는 무의미합니다. 데이터 마이닝 / 추적을 끄고 "추적하지 않음"신호를 활성화하더라도 놀랍게도 Google은 여전히 ​​데이터를 마이닝하고 있습니다.

숨길 것이 없다고 생각한다면 ** 당신은 절대적으로 틀 렸습니다 **. 이 주장은 여러 번 반박되었습니다.

[위키 백과를 통해] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden은 "숨길 것이 없기 때문에 프라이버시 권리에 관심이 없다고 주장하는 것은 말할 것이 없기 때문에 언론의 자유에 관심이 없다고 말하는 것과 다를 바가 없습니다. 나는 숨길 것이 없습니다. '당신은'나는이 권리에 대해 신경 쓰지 않는다 '고 말한다. 당신은'나는이 권리가 없다. 내가 정당화해야 할 지점에 도달했기 때문이다. 권리가 작동하는 방식은 정부가 귀하의 권리에 대한 침해를 정당화해야합니다. "

2. Daniel J. Solove는 The Chronicle of Higher Education의 기사에서이 주장에 반대한다고 말했습니다. 그는 정부가 개인에 대한 정보를 유출하여 그 사람에게 피해를 입힐 수 있으며, 개인이 실제로 잘못을 저 지르지 않았더라도 서비스에 대한 접근을 거부하기 위해 개인에 대한 정보를 사용할 수 있으며, 정부가 개인에게 피해를 줄 수 있다고 말했습니다. 실수를 통한 삶. Solove는 "직접적으로 관여 할 때 숨길 수없는 주장은 논쟁을 사생활에 대한 좁은 이해에 초점을 맞추도록 강요 할 수 있습니다. 그러나 정부 데이터 수집 및 감시를 넘어서는 사용과 관련된 여러 개인 정보 문제에 직면 할 때 공개, 숨길 수없는 주장은 결국 할 말이 없습니다. "

3. Privacy Rights : Moral and Legal Foundations의 저자 인 Adam D. Moore는 "권리가 비용 / 이익 또는 결과 론적 주장에 저항한다는 견해입니다. 여기서 우리는 개인 정보 보호 이익이 일종의 유형이라는 견해를 거부하고 있습니다. 보안을 위해 거래 할 수있는 것들의. " 그는 또한 감시가 외모, 인종, 성, 종교에 따라 사회의 특정 그룹에 불균형 적으로 영향을 미칠 수 있다고 말했습니다.

4. 컴퓨터 보안 전문가이자 암호 학자 인 Bruce Schneier는 "가장 정직한 사람의 손으로 쓴 여섯 줄을 줄 수 있다면 그를 교수형에 처하게 할 것"이라는 리슐리외 추기경의 발언을 인용하면서 반대를 표명했습니다. 주 정부가 개인을 기소하거나 협박하기 위해 개인의 삶에서 측면을 찾을 수있는 방법에 대해 설명합니다. Schneier는 또한 "너무 많은 사람들이 토론을 '보안 대 개인 정보 보호'로 잘못 인식하고 있습니다. 진정한 선택은 자유 대 통제입니다. "

5. Harvey A. Silverglate는 평범한 사람이 평균적으로 미국에서 무의식적으로 하루에 세 번의 중죄를 저지르는 것으로 추정했습니다.

6. 철학자이자 정신 분석가 인 Emilio Mordini는 "숨길 것이 없다"는 주장은 본질적으로 역설적이라고 주장했다. 사람들은 "무언가"를 숨기기 위해 "무언가"를 가질 필요가 없습니다. 숨겨진 것이 반드시 관련이있는 것은 아니라고 Mordini는 주장합니다. 대신 그는 은밀하고 접근이 제한 될 수있는 친밀한 영역이 필요하다고 주장한다. 심리적으로 말하면 우리는 다른 사람에게 무언가를 숨길 수 있다는 발견을 통해 개인이되기 때문이다.

7. Julian Assange는 "아직 킬러 대답이 없습니다. Jacob Appelbaum (@ioerror)은이 말을하는 사람들에게 잠금 해제 된 휴대 전화를 건네고 바지를 내리라고 요청하는 영리한 응답을 받았습니다. 내 버전은 다음과 같습니다. '글쎄, 당신이 너무 지루하다면 우리는 당신과 이야기해서는 안되며, 다른 누구도 말하지 말아야합니다.'하지만 철학적으로 진짜 대답은 이것입니다 : 대중 감시는 대규모 구조적 변화입니다. 사회가 나빠지면 당신이 지구상에서 가장 칙칙한 사람이라 할지라도 당신을 데려 갈 수 있습니다. "

8. 법학 교수 Ignacio Cofone은 사람들이 다른 사람에게 관련 정보를 공개 할 때마다 그들은 또한관련없는 정보를 닫습니다. 이 무관 한 정보는 개인 정보 보호 비용이 발생하며 차별과 같은 다른 피해로 이어질 수 있습니다.

***

## 기타 Google 반대 캠페인

다른 주목할만한 반 Google 캠페인 목록입니다. 이 목록은 불완전합니다. 확장하여 도움을 줄 수 있습니다.

### 소멸

[Scroogled-Microsoft (2012 년 11 월 ~ 2014 년 11 월)] (https://en.wikipedia.org/wiki/Scroogled)

_ 현재 다른 항목이 없습니다 ._

### 진행 중

_이 목록은 현재 비어 있습니다 ._

***

## 다른 주장에 반대하기

사람들이 구글을 정당화하기 위해 주장하는 몇 가지 주장이 있습니다. 첫 번째 주요 항목 중 하나는 [여기] (# Privacy)에서 이미 밝혀졌지만 다른 항목은 다음과 같습니다.

### 편의성

예, Google 제품은 편리해 보입니다. 그러나 보안, 개인 정보 및 신뢰성을 포함하여 편의를 위해 모든 것을 거래하고 있습니다. Google은 수년에 걸쳐 느려졌 고 서버는 점점 더 다운되었습니다. 현재 Google 서버는 한 달에 1 ~ 2 회 거의 1 시간 동안 다운됩니다 (특히 YouTube).

안타깝게도 사회가 Google에 의존하기 때문에 Google은 인터넷을 장악하게되었고 점점 더 많은 것을 통제하려고합니다. 2012 년 Google이 5 분 동안 중단되었을 때 ** 글로벌 ** 인터넷 트래픽이 ** 40 % ** 감소 ** 한 것으로보고되었습니다. Google은 자주 1 ~ 2 시간 동안 중단되고 [윤리 팀 해고] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) 무엇보다도 편리해 질 것입니다.

편리함이 항상 좋은 것은 아닙니다. 가끔씩 서버가 다운되지 않도록 할 방법이 없기 때문에 무슨 일이 일어나고 있는지 인식하고 다운 될 때 대비해야합니다.

Google은 또한 생각만큼 편리하지 않습니다. 훨씬 더 편리한 사이트가 있습니다. Google은 사용자가 임의의 계정 정지 및 해지를 응답없이 처리하면 (Google 트위터 계정에 충분한주의를 기울이거나 $ 100,000,000 이상에 대해 고소하지 않는 한) 편리하지 않습니다. 아무도 당신의 비명 소리를들을 수없는 베개에 비명을 지르도록 강요했습니다.

### 왜 중요해, 어쨌든 너무 늦었 어

이것은 덜 일반적인 주장이지만 설명이 필요합니다. 현재 상태에서는 대부분의 세계 정부와 여러 강력한 기업이 당신의 모든 움직임을 알고있는 것 같습니다. 그런데 왜 그것에서 벗어나려고 애쓰는가? 답은 간단합니다. ** 당신은 더 나은 자격이 있습니다 **. 이 시점에서 그들로부터 벗어날 수 있다면, 그들이 당신의 움직임을 더 추적하기가 더 어려워지고 당신은 새로운 사생활을 만들 수 있습니다.

[1 출처] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) 그런데 일주일 이상이 게시물을받을 때마다 무료 Reddit 어워드를이 게시물에주고 있습니다. 지금 (무료 코인 500 개와 함께)이 주제를 더욱 강화할 수 있습니다. 지금까지 14 개 이상의 무료 상을이 게시물에 제공했습니다. 그다지 많지는 않지만, 그것이 누구에 의해 어떻게 인식되는지에 따라 작은 것이 큰 영향을 미칠 수 있습니다.

### 기타

지금은 다른 논쟁이 없습니다.

_이 목록은 불완전합니다 _

***

## 출처

부:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https : //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https : // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https : //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https : // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# 비평) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https : // www.eff.org / deeplinks / 2020 / 03 / google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes-and) [c] (https://www.wired.com /story/google-tracks-you-privacy/)[o](https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you- 개인 정보 보호) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html) [d] (https : //www.reuters. com / article / us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https : // www .pcmag.com / news / google-sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https://www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google- ios-apple /) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c ] (https : //www.cnn. com / 2019 / 11 / 12 / business / google-project-nightingale-ascension / index.html) [o] (https://en.wikipedia.org/wiki/2018_Google_data_breach) [m] (https : // moz. com / blog / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https : //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https : //www.nytimes. com / 2019 / 01 / 21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over- 5 백만 명의 아이폰 사용자 중 데이터 소유권 주장) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https : //www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when -your-phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about- you.html) [p] (https://topclassactions.co m / lawsuit-settlements / privacy / google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection /) [r] (https://arstechnica.com/information-technology/2014/01/what -google-can-really-do-with-nest-or-really-nests-data /) [i] (https://www.cbsnews.com/news/google-education-spies-on-collects-data- on-millions-of-kids-alleges-lawsuit-new-mexico-attorney-general /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal-under -our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019/09 /04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide- 40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

기타 출처 :

[다섯 눈 동맹] (https://en.wikipedia.org/wiki/Five_Eyes) [1984] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## 다운로드 링크

[Firefox 다운로드] (https://www.mozilla.org/en-US/firefox/new/) [Tor 브라우저 다운로드] (https://www.torproject.org/download/) [Other / unavailable] (https : //www.example.com)

***

## 내 디 구글링 경험

마침내 2018 년에 빅 테크의 문제를보기 시작했고 디 구글링을 시작했습니다. 처음 몇 달 동안 나는 상당한 진전을 이루었습니다. 그 이후로 엄청나게 느려졌습니다.


### 전환 대상

Google 크롬-> Firefox / Tor

Google 검색-> DuckDuckGo (기본값) / Ecosia (내가 좋아할 때) / Bing (드물게)

GMail-ProtonMail (아직 완전히 전환되지 않음)

Google 사이트-> 자체 호스팅 (아직 완전히 전환되지 않음)

Google+-> 거의 사용하지 않음, 자체 종료로 인해 삭제됨

Google 문서-> 한 번도 사용하지 않았습니다. 대신 Microsoft Word 2013 (2019 년 이전)과 LibreOffice (2019 년 이후)를 사용합니다.

Google 스프레드 시트-> 한 번도 사용하지 않았습니다. 대신 Microsoft Excel 2013 (2019 년 이전)과 LibreOffice (2019 년 이후)를 사용합니다.

Google 프레젠테이션-> 한 번도 사용하지 않았습니다. 대신 Microsoft PowerPoint 2013 (2019 년 이전)과 LibreOffice (2019 년 이후)를 사용합니다.

Google 드로잉-> 한 번도 사용하지 않았으며 대신 LibreOffice (2019 이후)를 사용합니다.

Gerrit-> 절대 사용하지 않았습니다. 대신 GitHub (현재 기본값), GitLab, BitBucket 및 SourceForge를 사용합니다.

Google 포토-> 사용하지 않음

Google 드라이브-> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020- 현재)

Google지도-> OpenStreetMaps / Apple지도

Go-특별한 예외를 만들지 만 함수형 프로그래밍 언어로 사용하지 않음

Dart-특별한 예외를 만들지 만 함수형 프로그래밍 언어로 사용하지 않음

Flutter-특별한 예외를 만들지 만 함수형 프로그래밍 언어로 사용하지 않음

Google 어스-> OpenStreetMaps / Apple Maps

Google Streetview-> 한 번도 사용하지 않았습니다.

Google Fi-> 사용하지 않음

Google 캘린더-> 사용하지 않음

Google 계산기-> 말 그대로 다른 모든 계산기 앱, 심지어 내가 원한다면 Python 모드로 실행되는 Linux 터미널

Google Nest-> 사용하지 않음

Google AMP-> 사용하지 않음

Google VPN-> 전혀 사용하지 않음, 모순

Google Pay-> 사용하지 않음

Google Summer of Code-> 참여하지 않음

Tenor-> 다른 GIF 사이트, GIF는 나에게 너무 중요하지는 않습니다. 일반적으로 DuckDuckGo 이미지, Imgur, Reddit 또는 기타 사이트에서 GIF 파일을 얻습니다.

Blockly-> 더 이상 사용되지 않으며 스크래치가 직접 블록으로 실행되었는지 확실하지 않습니다. 저는 2017 년부터 기능적인 프로그래머가되었고 스크래치에서 성장했습니다.

GBoard-> 한 번 사용했지만 버려짐

Google Glass-> 한 번도 사용하지 않았으며 어린 아이로 간주되었지만 옵션이있는 경우 구입 / 사용하지 않기로 결정했습니다.

_ 목록이 불완전 할 수 있습니다 ._

### 여전히 벗어날 수없는 제품

2021 년 2 월 25 일 현재 다음은 완전히 디 구글링되지 않도록하는 Google 제품입니다.

1. 유튜브

2. 안드로이드

3. Google Play 스토어

4. Gmail (학교 및 일부 사이트에만 해당)

5. Google 클래스 룸 (학교 전용)

6. Google 번역

7. Google 계정

8. Google 사이트 도구 (Google이 GDPR의 법률을 위반하고 (고정 될 때까지 추가로 € 5,000,000.00의 벌금을 부과 할 수 있으므로)이 제품의 다운로드를 금지합니다.

나는 다른 모든 것에서 탈구했다.

***

## Go는 악

구글은 2003 년 에이전트 기반 프로그래밍 언어 인 'Go!'를 그들의 프로그래밍 언어 인 'Go'(2009 년부터 6 년 후)로 넘겨서 그들의 언어가 다른 언어에 전혀 영향을 미치지 않을 것이라고 주장했다. 구글은 '악하지 말라'라는 모토가 당시 여전히 활성화되어 있었기 때문에 이에 대해 큰 비판을 받았으며, 이것은 사악하지 말라 모토가 은퇴 한 많은 사건 중 하나입니다.

결국 'Go!'의 개발은 중단되었고, 'Go'는 점점 더 보편화되었습니다. 구글은 그들이`Go!`를 넘어 가지 않을 것이라고 주장했지만, 결국 그들은 그렇게했고 그들은 그것을 떠났다 (2021 년 4 월 9 일 현재)

[여기에서 Go 및 대체 방법에 대해 자세히 알아보세요.] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## DRM 사용

Google은 WideVine DRM "서비스"및 기타 양식을 통해 DRM (디지털 제한 관리)을 사용합니다. DRM의 목표는 개방형 인터넷을 파괴하고 기업에 사용자에 대한 독점권을 부여하는 것입니다. 비용에 관계없이 WideVine을 완전히 제거해야합니다.

[WideVine과 그 문제에 대한 자세한 내용은 여기에서 확인하세요.] (https://github.com/Degoogle-your-life/Its-time-to-cut-WideVine-DRM)

***

## 일반적인 오해

다음은 Google 제품에 대한 몇 가지 일반적인 오해 목록입니다.

### Google은 인터넷이 아닙니다

Google / Google 검색은 인터넷이 아닙니다. Google 검색은 검색 엔진 일뿐입니다. Nintendo 플랫폼의 모든 게임이 Nintendo에서 만든 것은 아니지만 Nintendo에서 라이선스를받은 것과 비슷합니다. 지금 당장 모든 Google 서버를 동시에 파괴해야한다면 YouTube, Gmail, Google 문서, Google 검색 등과 같은 Google 사이트 만 사라지지만 인터넷의 대부분은 여전히 ​​존재합니다 (Wikipedia, Stackoverflow, GitHub, 모든 Microsoft 웹 사이트, NYTimes, Samsung, TikTok 등) Google 로그인 및 분석 기능을 잃을 수 있지만 여전히 작동합니다 (프로그램이 제대로 프로그래밍되지 않았고 Google에 직접 의존하지 않는 한).

***

## Internet Explorer 6 및 Chrome

Google 크롬은 새로운 Internet Explorer 6이되고 있습니다. Google 크롬이 처음 출시되었을 때 Firefox는 지배적 인 브라우저였으며 Google 크롬을 사용했을 때 수백만 명의 사람들이 Firefox 및 기타 브라우저로 전환하기 전에 96 %를 넘어 섰던 Internet Explorer 시장 점유율을 대부분 죽였습니다. 나왔을 때 사람들은 속도와 Google에 의해 전환되었습니다 (대부분의 개인 정보 문제가 아직 밝혀지지 않았기 때문에 당시에는 악으로 ​​간주되지 않았습니다) Google 크롬은 원래 웹 표준을 존중했습니다 (파이어 폭스가 한 일입니다) 인터넷 익스플로러 96 %의 브라우저 시장 점유율을 떨어 뜨림) 그러나 Google 크롬 시장 점유율이 상승함에 따라 Google은 점점 더 많은 기능을 제거하고 스파이웨어를 추가하고 웹 표준을 받아들이지 않게되면서 새로운 Internet Explorer 6이되었습니다.

현재 가장 큰 문제는 Chrome 전용 웹 사이트이며 다른 브라우저에서는 작동하지 않습니다. 개발자가 Chrome을 사용하지 않는 다른 30 ~ 40 %의 인터넷 사용자가 자신의 사이트를 사용하는 것을 원하지 않기 때문입니다.

Google 자체도 사이트를 Chrome으로 만 만들고 있습니다. 예를 들어 Google 검색은 Google Chrome을 사용하지 않는다는 것을 감지하고 (Brave와 같은 다른 Chromium 기반 브라우저도 영향을 받음) Google 어스와 같은 사이트에서 Firefox 사용자가 허용하지 않는 경우 10 초마다 3 번 Chrome을 다운로드하라는 메시지를 표시합니다. 해당 사이트 (2020 년 기준)를 사용하고 Google 번역은 Firefox 및 기타 비 Google Chrome 브라우저에서 음성 입력을 지원하지 않습니다.

### Brave의 문제

Brave 및 Microsoft Edge와 같이 Chromium을 기반으로하는 다른 브라우저에는 Google 스파이웨어가 완전히없는 것은 아닙니다. Brave는 일반적으로 개인 정보 보호 커뮤니티의 잘못된 쪽에서 권장되지만 Brave는 Chromium을 사용하기 때문에 여전히 문제입니다. 인터넷은 Chromium 전용 브라우저로 구성되어서는 안되며 다양한 선택이 있어야합니다. Brave는 잘못된 길입니다.

[여기에서 Chrome / Chromium에서 디 구글링에 대해 자세히 알아보세요] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC)에서 디 구글링하는 방법에 대해 자세히 알아보세요.] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## 가짜 프라이버시 갱신

구글은 이미 너무 늦었 기 때문에 그들이 프라이버시를 중요시하는 세상에 알리려고 노력해 왔습니다. 그들은 사용자 개인 정보를 존중한다고 계속 주장하지만 여전히 모든 개인 정보 문제를 해결하지는 않습니다.

### 오픈 소스는 부분적 일 수 없습니다.

오픈 소스는 부분적 일 수 없습니다. Google이 이에 대한 증거입니다. 소스 코드의 모든 비트와 바이트는 대중에게 공개되어야하며 8 분의 1 바이트도 숨겨져 있지 않아야합니다.

Android 및 ChromeOS와 같은 프로젝트는 부분적으로 오픈 소스이지만 대부분의 독점 스파이웨어 요소를 포함합니다.

### 옥시 모론

Google VPN은 모순입니다. Google은 개인 정보 보호에 대해 신경 쓰지 않으며 VPN 서비스에 대해 최악의 선택 중 하나가 될 수있는 VPN (Virtual Private Network)과 같은 회사의 VPN입니다.

***

## 나쁜 성능

Google은 마지막 벤치마킹 소프트웨어 (Google Octane)가 2017 년에 중단 되었기 때문에 적어도 2017 년에는 제품의 성능에 관심이 없습니다.

***

## 나쁜 프로젝트 관리

구글은 매우 나쁜 내부 프로젝트 관리 시스템을 가지고 있습니다. 점점 더 다운 그레이드되는 프로그램의 일반적인 예로는 Google Duo 및 YouTube 음악 (이전의 Google Play 뮤직)이 있습니다.

Google의 내부 개발 시스템에서 하나의 앱이 절반의 기능을 가진 다른 앱으로 연결되고 원래 앱이 삭제됩니다. 2 년 후 기능이 75 % 적은 새 앱이 만들어지고 50 % 기능이있는 앱이 제거되고 87.5 %의 기능이있는 새 앱이 생성되고 75 % 기능이있는 앱이 중단됩니다. , 등등.

***

## 서비스의 끔찍하거나 중재 없음

YouTube는 현존하는 최악의 플랫폼을 만드는 나쁜 중재의 세계에서 가장 흔한 예입니다. Google은 또한 YouTube가 YouTube 어린이가 아니라는 것을 인식하지 못하는 것 같습니다.

YouTube의 경우 더 많은 참여 시간과 더 많은 돈을 목적으로 혐오스러운 친 나치 및 백인 우월 주의자 콘텐츠가 사용자에게 제공됩니다. 구글은 또한 기독교 애널 섹스 비디오를 '아동용'콘텐츠로 승인하는 동시에 연령을 제한하는 등 매우 어리석은 행동을했다. 또한 Baby Shark 비디오 바로 아래에 포르노 또는 유혈 광고가 다양한 '아동용'콘텐츠와 함께 표시되는 것도 드문 일이 아닙니다.

YouTube 사용자는 위의 예와 같이 나쁜 콘텐츠에 대한 YouTube의 부적절한 조정에 대해 매우 자주 불평하는 반면 사용자는 철회 할 능력이없는 이유없이 무작위로 동영상을 삭제할 수 있으며, 사용자는 어떤 형태의 욕설에 대해서도 처벌을받을 수 있습니다. '쓰레기'사용자가 스탈린 시대의 [소비에트 연방] (https://en.wikipedia.org/wiki/Soviet_Union)과 일반적으로 비교하는 것과 같은 아주 사소한 경우조차도 이러한 불평등 한 처벌로 인해 발생합니다.

2021 년 Google은 동영상이 악마 화 되었음에도 불구하고 (Google이 돈을 벌지 만 제작자는 그렇지 않음) 모든 동영상에 광고를 게재 할 것이라고 발표했습니다. 이는 중재와 너무 관련이 없지만 유의해야합니다.

유튜브는 (매우 형편 없긴하지만) 조정되고 있지만, 그들에게 대부분의 돈을주는 구글 광고 서비스는 조정이 거의 없거나 전혀없는 것 같습니다.

[YouTube 중재 문제 및 YouTube에서 대체하는 방법에 대해 자세히 알아보기] (https://github.com/seanpm2001/Alternating-from-YouTube)

Google Play 광고는 봇 팜에서 생성됩니다. 수백 개의 회사에서 사용하는 것과 동일한 광고 시나리오를 통해 제품과 거의 변경이없고 제품과 관련이 없음을 알 수 있습니다 (일반적인 예 : Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City 및 사용자가 게임, 음악 등을 통해 돈을 벌 수 있다고 주장하는 악의적 인 광고 추세와 함께 수천 개 이상) PayPal은 이에 대해 언급하지 않았지만 이것이 사기라는 것이 분명합니다. 보장 된 게임을함으로써 20 초도 안되는 시간에 $ 10,000가 넘으면 아무도 일을하지 않고 대신이 일을하게 될 것입니다. 이것은 불가능하며 비즈니스는 이와 같이 일할 수 없습니다. 이 명백한 사기는 2019 년 이후로 강력 해져 왔으며 이제 이러한 광고를 생성하는 봇 팜은 자체 광고에서 서로 싸우고 있습니다.

여러 광고도 매우 음란하며 사용자 (대부분 13 세 미만의 사용자 또는 봇)가 성적 조작을 통해 클릭하도록 유도합니다.

많은 앱이 봇을 사용하고 제품을 astroturf하기 때문에 잘못된 리뷰가있을 때마다 양말 인형 봇 계정은 별 5 개 리뷰를 게시하기 시작하고 비판을 무효화합니다. [Google도이 작업을 수행합니다] (# Astroturfing)

[Google 애드 센스 문제에 대해 자세히 알아보기] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## 천체

일반 정의 [(Wikipedia에서)] (https://en.wikipedia.org/wiki/Astroturfing)

```
Astroturfing은 메시지 또는 조직 (예 : 정치적,광고, 종교 또는 홍보)를 통해 마치 풀뿌리 참가자로부터 시작되고 지원되는 것처럼 보이게합니다. 출처의 재정적 연결에 대한 정보를 보류하여 진술 또는 조직에 신뢰성을 부여하기위한 관행입니다. astroturfing이라는 용어는 "풀뿌리"라는 단어를 사용하여 천연 잔디를 닮도록 설계된 합성 카펫 브랜드 인 AstroTurf에서 파생되었습니다. 이 용어 사용의 의미는 문제의 활동 뒤에 "진정한"또는 "자연적인"풀뿌리 노력 대신에 "가짜"또는 "인공적인"지원 모양이 있다는 것입니다.
```

구글은 그들이 악한 일을하지 않는 것처럼 보이게 만드는 천체 잔디의 역사를 가지고있다. 예를 들어, 구글에 대한 비판을 트위터와 같은 플랫폼 (계정이있는)에 게시하면 한동안 존재했지만 게시되지 않은 여러 계정이 나와서 귀하가 말한 내용이 거짓이라고 주장한 다음 Google이 최고의 회사라고 주장하지만 대부분의 사람들에게 봇이라는 것이 분명하지 않을 수있는 방식으로 수행되었습니다. 사람들.

***

## 불법적이고 비 윤리적 인 비즈니스 관행

Google은 조세 피난처를 사용하고 작업을 아웃소싱하고 사업 비용으로 불법 침입 활동을 계속하는 등 불법적이고 비 윤리적 인 비즈니스 관행을 사용하여 독점을 강화합니다.

### 유럽에서

유럽은 Google을 자주 고소했습니다. 가장 큰 소송은 Android의 불법 행위에 대한 것입니다. 그 결과 Google은 € 5,000,000,000 (2021 년 4 월 9 일에 $ 5,947,083,703.68에 해당)을 받았습니다.

### 북미 지역

미국은 유럽의 € 5,000,000,000 벌금에 비해 아직 Google에 벌금을 거의 부과하지 않았습니다.

### 논란

Google은 논란을 일으킬 때까지 문제에 대해 신경 쓰지 않습니다. 그러면 문제를 해결하려는 시도가 부실 할 것입니다. 논란이 일시적으로 사라지고 문제는 또 다른 논란을 일으킬 때까지 기하 급수적으로 악화됩니다. 사이클이 계속됩니다. 그들은 단순히 그것에 대해 진지한 일을 할만큼 충분히 신경 쓰지 않습니다.

***

## Google은 자동화되어 있습니다.

회사로서 Google은 대부분 자동화되어 있으며 자동화보다 중재가 적습니다.

회사는 완전히 자동화되어서는 안됩니다. Google이 그 예입니다. 중재는 AI에 의해서만 수행 될 때 끔찍합니다. YouTube는 사이트를 중재하는 추가 소수 (수백 또는 천명)의 사람들이 있어도 좋은 예입니다. 사이트를 중재하는 것이 너무 나빠서 대부분이 일하는 동안 치료를 받아야합니다.

***

## 안드로이드

Android는 Google 소유입니다. 오픈 핸드셋 얼라이언스 (안드로이드 이후로 개방되지 않은)의 일부 안드로이드는 구글의 또 다른 독점 지점이되었으며 탈출하기 매우 어려운 곳이되었습니다.

Android는 하루에 10 번 이상 Google에 전화를 거는 것으로보고되었으며 부분적으로 오픈 소스 임에도 불구하고 여전히 스파이웨어 역할을합니다.

Android에서 대체하기 위해 여러 프로젝트가 생성되었지만 기기를 루팅해야합니다. 이것은 Knox DRM으로 인해 더 이상 미국의 특정 삼성 휴대폰에서는 불가능합니다. Android의 일반적인 대안에는 iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch 및 PiPhone이 포함됩니다 (Pi Phone은 Fedora, Ubuntu, Arch 등과 같은 모바일 장치에서 다양한 Linux 시스템을 실행하는 전화 브랜드입니다.)

[degoogled Android 가상 머신 기능에 대한 내 연구보기] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Android에서 degoogle하는 방법보기] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## 도움이되는 작은 조치

가능한 모든 방법으로 인식을 전파하는 것이 중요합니다. 저에게는 디 구글링에 대해 자주 이야기하고 기사를 작성하는 것뿐만 아니라 작은 습관도 있습니다. r / degoogle에 고정 된 게시물에 매일 ​​무료 Reddit 상을 주어 인지도를 높이고 있습니다. 지금까지 고정 된 게시물에 거의 30 개의 상을주었습니다 (또한 해당 게시물에 대한 10 개의 상에 500 개의 무료 코인을 썼습니다).

***

## 신뢰할 수 없음

Google은 신뢰할 수 없으며 다시는 신뢰할 수 없습니다. 그들은 "악하지 말라"(항상 악했다)에서 완전히 악하고 그것을 숨기려고하지 않는 상태로 완전히 갔다.

***

## 확인해야 할 기타 사항

[Google Graveyard (killedbygoogle.com)-Google이 죽인 224 개 이상의 제품 목록] (https://killedbygoogle.com/)

> [GitHub 링크] (https://github.com/codyogden/killedbygoogle)

[알파벳 노동자 노조-800 명 이상의 회원이있는 Google의 새로운 노조] (https://alphabetworkersunion.org/people/our-union/)

[공룡 부활절 달걀과 헤어지고 싶지 않나요? 이 웹 사이트에서 다루었습니다] (https://chromedino.com/)

다른 대안이 있습니다. 검색 만하면됩니다.

***

이 기사에는 몇 가지 사실 확인이 필요합니다.

***

## 파일 정보

파일 유형 :`마크 다운 (* .md)`

줄 수 (빈 줄 및 컴파일러 줄 포함) :`895`

파일 버전 :`5 (2021 년 4 월 9 일 금요일 오후 6:02)`

***

### 소프트웨어 상태

제 작품은 모두 자유 롭습니다. DRM (** D ** igital ** R** 제한 ** 관리 **)가 내 작품에 없습니다.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

이 스티커는 Free Software Foundation에서 지원합니다. 내 작업에 DRM을 포함시킬 생각은 없습니다.

나는 그것을 다루는 일반적인 방법이 거짓이고 DRM에 대한 권리가 없기 때문에 더 잘 알려진 "디지털 권한 관리"대신 "디지털 제한 관리"라는 약어를 사용하고 있습니다. "Digital Restrictions Management"철자가 더 정확하며 [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) 및 [FSF (Free Software Foundation)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

이 섹션은 DRM의 문제에 대한 인식을 높이고 항의하는 데 사용됩니다. DRM은 설계 상 결함이 있으며 모든 컴퓨터 사용자와 소프트웨어 자유에 대한 주요 위협입니다.

이미지 크레딧 : [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## 스폰서 정보

! [SponsorButton.png] (SponsorButton.png) <-이 버튼을 클릭하지 마세요. 작동하지 않습니다. 이미지 일뿐입니다. 실제 버튼은 페이지 상단의 오른쪽 (<-L ** R **->) 모서리에 있습니다.

원하는 경우이 프로젝트를 후원 할 수 있지만 기부 할 대상을 지정하십시오. [기부 할 수있는 기금보기] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

다른 스폰서 정보는 [여기] (https://github.com/seanpm2001/Sponsor-info/)에서 확인할 수 있습니다.

그것을 시도하십시오! 스폰서 버튼은 시청 / 감시 해제 버튼 바로 옆에 있습니다.

***

## 파일 기록

버전 1 (2021 년 2 월 19 일 금요일 오후 5시 20 분)

> 변경 사항 :

> * 파일 시작

> * 기본 설명 섹션 추가

> * 저장소 설명 섹션 추가

> * 기사 목록 추가, 14 개 항목

>> * '관련 기사'섹션 추가

>> * '참조'섹션 추가

> * 파일 정보 섹션 추가

> * 파일 히스토리 섹션 추가

> * 바닥 글 추가

> * 버전 1에는 다른 변경 사항이 없습니다.

버전 2 (2021 년 2 월 19 일 금요일 오후 5:26)

> 변경 사항 :

> * 번역 상태 섹션 추가

> * 기타 체크 아웃 섹션 추가

> * 개인 정보 보호 섹션 추가

> * 색인 추가

> * 소프트웨어 상태 하위 섹션 추가

> * 기타 안티 Google 캠페인 섹션 추가

>> * 없어진 하위 섹션 추가

>> * 진행중인 하위 섹션 추가

> * 소스 섹션 추가

> * 다운로드 링크 섹션 추가

> * 파일 정보 섹션 업데이트

> * 파일 히스토리 섹션 업데이트

> * 버전 2에는 다른 변경 사항이 없습니다.

버전 3 (2021 년 2 월 24 일 수요일 오후 7:56)

> 변경 사항 :

> * 색인 업데이트

> * degoogle 아이콘 및 새로운 GitHub 조직 참조

> * 최신 기사에 대한 링크 추가

> * 다른 주장에 대한 반박 섹션 추가

>> * 편의 서브 섹션 추가

>> * 왜 귀찮게 하는가 하위 섹션 추가

>> * 기타 하위 섹션 추가

> * 일부 데이터 업데이트

> * 파일 정보 섹션 업데이트

> * 파일 히스토리 섹션 업데이트

> * 버전 3에는 다른 변경 사항이 없습니다.

버전 4 (2021 년 2 월 25 일 목요일 오후 9:31)

> 변경 사항 :

> * 10 개의 새 기사에 대한 링크 추가

> * 내 경험 디 구글링에 대한 섹션 추가

> * 색인 업데이트

> * 파일 정보 섹션 업데이트

> * 파일 히스토리 섹션 업데이트

> * 버전 4에는 다른 변경 사항이 없습니다.

버전 5 (2021 년 4 월 9 일 금요일 오후 6:02)

_ 최근 저에게 반 구글 운동에 대한 업데이트가 부족하여 1 개월 이상의 휴지기 후에 다시 복구하려고 노력하고 있습니다 ._

> 변경 사항 :

> * 제목 섹션 업데이트

> * 색인 업데이트

> * 언어 목록 업데이트 : 링크 수정, 지원 언어 추가

> * 4 개의 포크 링크를 추가하여 기사 상태 섹션 업데이트

> * 소프트웨어 상태 섹션 업데이트

> * Go is evil 섹션 추가

> * DRM 사용 섹션 추가

> * 일반적인 오해 섹션 추가

>> * Google은 인터넷 하위 섹션이 아닙니다 추가

> * Internet Explorer 6 및 Chrome 섹션 추가

>> * The problem with Brave 하위 섹션 추가

> * 가짜 프라이버시 제거 추가

> * 오픈 소스는 일부 하위 섹션이 될 수 없음 추가

> * Oxymoron 하위 섹션 추가

> * 나쁜 성능 섹션 추가

> * 나쁜 프로젝트 관리 섹션 추가

> * 서비스 섹션의 끔찍하거나 중재 없음 추가

> * Astroturfing 섹션 추가

> * 불법 및 비 윤리적 인 비즈니스 관행 섹션 추가

> * 유럽 내 하위 섹션 추가

>> * 북미 내 하위 섹션 추가

>> * 논란 하위 섹션 추가

> * Google은 자동화 섹션 추가

> * Android 섹션 추가

> * 도움말 섹션에 작은 작업 추가

> * 신뢰할 수없는 섹션 추가

> * 스폰서 정보 섹션 추가

> * 바닥 글 업데이트

> * 파일 정보 섹션 업데이트

> * 파일 히스토리 섹션 업데이트

> * 버전 5에서 다른 변경 사항 없음

버전 6 (출시 예정)

> 변경 사항 :

> * 출시 예정

> * 버전 6에서 다른 변경 사항 없음

버전 7 (출시 예정)

> 변경 사항 :

> * 출시 예정

> * 버전 7에서 다른 변경 사항 없음버전 8 (출시 예정)

> 변경 사항 :

> * 출시 예정

> * 버전 8에서 다른 변경 사항 없음

버전 9 (출시 예정)

> 변경 사항 :

> * 출시 예정

> * 버전 9에서 다른 변경 사항 없음

버전 10 (출시 예정)

> 변경 사항 :

> * 출시 예정

> * 버전 10에는 다른 변경 사항이 없습니다.

***

## 바닥 글

이 파일의 끝에 도달했습니다.

([맨위로] (# Top) | [GitHub로 돌아 가기] (https://github.com))

### EOF

***
