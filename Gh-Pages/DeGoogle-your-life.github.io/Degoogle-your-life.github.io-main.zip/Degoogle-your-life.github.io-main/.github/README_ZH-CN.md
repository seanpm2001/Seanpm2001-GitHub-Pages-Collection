***

！[DEGOOGLE1.jpeg]（DEGOOGLE1.jpeg）

＃Degoogling-让您的生活失去谷歌

这是有关常规去胶信息的主要去胶文章，以及指向其他文章的链接。

[查看列表作为GitHub组织]（https://github.com/Degoogle-your-life）

***

_以另一种语言阅读本文：_

**当前语言是：**`英语（美国）`_（翻译可能需要更正以修复英语以替换正确的语言）_

_🌐语言列表_

**排序：**`A-Z`

[排序选项不可用]（https://github.com/Degoogle-your-Life）

（[af Afrikaans]（/。github / README_AF.md）Afrikaans | [sq Shqiptare]（/。github / README_SQ.md）阿尔巴尼亚语| [amአማርኛ]（/。github / README_AM.md）Amharic | [arعربى] （/.github/README_AR.md）阿拉伯语| [hyհայերեն]（/。github / README_HY.md）亚美尼亚语| [azAzərbaycandili]（/。github / README_AZ.md）阿塞拜疆| [eu Euskara]（/。github /README_EU.md）巴斯克语| [beБеларуская]（/。github / README_BE.md）白俄罗斯语| [bnবাংলা]（/。github / README_BN.md）孟加拉语| [bs Bosanski]（/。github / README_BS.md）波斯尼亚语| [bgбългарски]（/。github / README_BG.md）保加利亚语| [caCatalà]（/。github / README_CA.md）加泰罗尼亚语| [ceb Sugbuanon]（/ .. github / README_CEB.md）Cebuano | [ny Chichewa ]（/。github / README_NY.md）Chichewa | [zh-CN简体中文]（/。github / README_ZH-CN.md）简体中文| [zh-t中国传统的）]（/。github / README_ZH -T.md）中文（繁体）| [co Corsu]（/。github / README_CO.md）科西嘉语| [hr Hrvatski]（/。github / README_HR.md）克罗地亚语| [csčeština]（/。github / README_CS .md）捷克语| [da dansk]（README_DA.md）丹麦语| [nl Nederlands]（/。github / README_ NL.md）荷兰语| [** zh-cn英语**]（/。github / README.md）英语| [EO世界语]（/。github / README_EO.md）世界语| [et Eestlane]（/。github / README_ET.md）爱沙尼亚语| [tl Pilipino]（/。github / README_TL.md）菲律宾| [fi Suomalainen]（/。github / README_FI.md）芬兰语| [frfrançais]（/。github / README_FR.md）法语| [fy Frysk]（/。github / README_FY.md）弗里斯兰语| [gl Galego]（/。github / README_GL.md）加利西亚语| [kaქართველი]（/。github / README_KA）格鲁吉亚语| [de Deutsch]（/。github / README_DE.md）德语| [elΕλληνικά]（/。github / README_EL.md）希腊语| [guગુજરાતી]（/。github / README_GU.md）古吉拉特语| [htKreyòlayisyen]（/。github / README_HT.md）海地克里奥尔语| [ha Hausa]（/。github / README_HA.md）Hausa | [hawŌleloHawaiʻi]（/。github / README_HAW.md）夏威夷语| [heעִברִית]（/。github / README_HE.md）希伯来语| [hiहिन्दी]（/。github / README_HI.md）印地语| [hmn Hmong]（/。github / README_HMN.md）Hmong | [hu Magyar]（/。github / README_HU.md）匈牙利语| [是Íslenska]（/。github / README_IS.md）冰岛语| [ig Igbo]（/。github / README_IG.md）Igbo | [id bahasa Indonesia]（/。github / README_ID.md）冰岛语| [ga Gaeilge]（/。github / README_GA.md）爱尔兰语| [it Italiana / Italiano]（/。github / README_IT.md）| [ja日本语]（/。github / README_JA.md）日语| [jw Wong颌骨]（/。github / README_JW.md）Javanese | [knಕನ್ನಡ]（/。github / README_KN.md）卡纳达语| [kkҚазақ]（/。github / README_KK.md）哈萨克语| [kmខ្មែរ]（/。github / README_KM.md）高棉语| [rw Kinyarwanda]（/。github / README_RW.md）Kinyarwanda | [ko-south韩国语]（/。github / README_KO_SOUTH.md）韩语（南）| [ko-north문화어]（README_KO_NORTH.md）朝鲜语（北部）（尚未翻译）| [kuKurdî]（/。github / README_KU.md）库尔德语（Kurmanji）| [kyКыргызча]（/。github / README_KY.md）吉尔吉斯语| [loລາວ]（/。github / README_LO.md）老挝| [la Latine]（/。github / README_LA.md）拉丁语| [lt Lietuvis]（/。github / README_LT.md）立陶宛语| [lbLëtzebuergesch]（/。github / README_LB.md）卢森堡语| [mkМакедонски]（/。github / README_MK.md）马其顿语| [mg马达加斯加语]（/。github / README_MG.md）马达加斯加语| [ms Bahasa Melayu]（/。github / README_MS.md）马来语| [mlമലയാളം]（/。github / README_ML.md）马拉雅拉姆语| [mt Malti]（/。github / README_MT.md）马耳他语| [mi Maori]（/。github / README_MI.md）毛利人| [mrमराठी]（/。github / README_MR.md）马拉地语| [mnМонгол]（/。github / README_MN.md）蒙古语| [myမြန်မာ]（/。github / README_MY.md）缅甸（缅甸）| [neनेपाली]（/。github / README_NE.md）尼泊尔语| [no norsk]（/。github / README_NO.md）挪威文| [或ଓଡିଆ（ଓଡିଆ）]（/。github / README_OR.md）Odia（奥里亚语）| [psپښتو]（/。github / README_PS.md）普什图语| [faفارسی]（/。github / README_FA.md）|波斯语[pl polski]（/。github / README_PL.md）波兰语| [ptportuguês]（/。github / README_PT.md）葡萄牙语| [paਪੰਜਾਬੀ]（/。github / README_PA.md）旁遮普语|没有可用字母Q |开头的语言。 [roRomână]（/。github / README_RO.md）罗马尼亚语| [ruрусский]（/。github / README_RU.md）俄语| [sm Faasamoa]（/。github / README_SM.md）萨摩亚语| [gdGàidhligna h-Alba]（/。github / README_GD.md）Scots Gaelic | [srСрпски]（/。github / README_SR.md）塞尔维亚语| [st Sesotho]（/。github / README_ST.md）Sesotho | [sn Shona]（/。github / README_SN.md）Shona | [sdسنڌي]（/。github / README_SD.md）信德语| [siසිංහල]（/。github / README_SI.md）僧伽罗语| [sk斯洛伐克语]（/。github / README_SK.md）斯洛伐克语| [slSlovenščina]（/。github / README_SL.md）斯洛文尼亚语| [so Soomaali]（/。github / README_SO.md）索马里文| [[es enespañol]（/。github / README_ES.md）西班牙语| [su Sundanis]（/。github / README_SU.md）Sundanese | [sw Kiswahili]（/。github / README_SW.md）斯瓦希里语| [sv Svenska]（/。github / README_SV。md）瑞典语| [tgТоҷикӣ]（/。github / README_TG.md）塔吉克语| [taதமிழ்]（/。github / README_TA.md）泰米尔语| [ttТатар]（/。github / README_TT.md）塔塔尔语| [teతెలుగు]（/。github / README_TE.md）泰卢固语| [thไทย]（/。github / README_TH.md）泰国语| [trTürk]（/。github / README_TR.md）土耳其语| [tkTürkmenler]（/。github / README_TK.md）土库曼人| [ukУкраїнський]（/。github / README_UK.md）乌克兰语| [urاردو]（/。github / README_UR.md）乌尔都语| [ugئۇيغۇر]（/。github / README_UG.md）维吾尔语| [uz O'zbek]（/。github / README_UZ.md）乌兹别克语| [viTiếngViệt]（/。github / README_VI.md）越南语| [cy Cymraeg]（/。github / README_CY.md）威尔士语| [xh isiXhosa]（/。github / README_XH.md）Xhosa | [yiיידיש]（/。github / README_YI.md）意第绪语| [yo Yoruba]（/。github / README_YO.md）Yoruba | [zu Zulu]（/。github / README_ZU.md）Zulu）有110种语言版本（不算英语和朝鲜语时为108种语言，因为朝鲜语尚未翻译。 ）/README.md））

除英语以外的其他语言的翻译是机器翻译的，尚不准确。截至2021年2月5日，尚未修复错误。请在此处报告翻译错误[https://github.com/seanpm2001/Degoogle-your-life/issues/）确保备份您的更正并提供指导，因为我不太了解英语（我打算最终聘请翻译）以外的语言，所以请在报告中引用[wiktionary]（https://en.wiktionary.org）和其他来源。否则，将拒绝发布更正。

注意：由于GitHub对markdown的解释（以及几乎所有其他基于Web的markdown解释）的限制，单击这些链接会将您重定向到单独页面上的单独文件，该页面不是我的GitHub个人资料页面。您将被重定向到托管README的[seanpm2001 / seanpm2001存储库]（https://github.com/seanpm2001/seanpm2001）。

由于我在其他翻译服务（例如DeepL和Bing Translate（对于反Google广告系列而言颇具讽刺意味））中需要的语言有限或不提供支持，因此使用Google Translate进行翻译。我正在寻找替代方案。由于某种原因，格式（链接，分隔符，粗体，斜体等）在各种翻译中都被弄乱了。解决起来很繁琐，而且我不知道如何使用非拉丁字符的语言来解决这些问题，从右到左的语言（例如阿拉伯语）需要额外的帮助来解决这些问题。

由于维护问题，许多翻译版本已经过时，并且使用的是本“ README”文章文件的过时版本。需要翻译器。另外，从2021年4月9日开始，要使所有新链接正常工作还需要一段时间。

***

＃＃ 指数

[00.0-标题]（＃Degoogling --- Degoogle-your-life）

> [00.1-索引]（＃Index）

[01.0-基本描述]（＃Basic-description）

> [01.1-存储库标题]（＃Degoogle-your-life）

> [01.2-Wuest3NFuchs描述概述]（＃Overview-by-Wuest3nFuchs）

>> [01.2.1-这是什么意思？]（＃Wuest3nFuchs的意思是什么？）

>> [01.2.2-为什么要使用Google？]（＃Why-Degoogle--by-Wuest3nFuchs）

[02.0-文章]（＃Articles）

[03.0-隐私]（＃Privacy）

[04.0-其他反Google广告系列]（＃Other-anti-Google-campaigns）

> [04.0.1-已终止]（＃已终止）

> [04.0.2-进行中]（＃Ongoing）

[05.0-反其他参数]（＃Countering-other-arguments）

> [05.0.1-便利]（＃便利）

> [05.0.2-为什么重要？无论如何都为时已晚]（＃为什么会如此，但它也太迟了）

> [05.0.3-其他]（＃Other）

[06.0-来源]（＃Sources）

[07.0-下载链接]（＃Download-links）

[08.0-我的Degoogling经验]（＃My-degoogling-experience）

> [08.1-我切换的内容]（＃What-I-switched-from）

> [08.2-我仍然无法摆脱的产品]（＃Products-我仍然无法摆脱-）

[09.0-其他要签出的东西]（＃Other-things-things）

[10.0-文件信息]（＃File-info）

> [10.1-软件状态]（＃Software-status）

> [10.2-赞助商信息]（＃Sponsor-info）

[11.0-文件历史记录]（＃File-history）

[12.0-页脚]（＃Footer）

***

##基本描述

[摘自Wikipedia：Degoogle]（https://en.wikipedia.org/wiki/DeGoogle）

DeGoogle运动（也称为de Google运动）是一个草根运动，它是由隐私权活动家敦促用户完全停止使用Google产品（由于对该公司的隐私问题日益关注）而发起的。该术语是指将Google从自己的生活中删除的行为。随着互联网巨头不断增长的市场份额为公司在数字空间中创造了垄断力量，越来越多的记者注意到难以找到公司产品的替代品。

**历史**

2013年，Venturebeat的John Koetsier表示，亚马逊基于Android的Kindle Fire平板电脑是“经过Google谷歌化的Android版本。” 2014年，《美国新闻》的约翰·辛普森（John Simpson）发表了有关Google和其他搜索引擎的“被遗忘权”。 2015年，爱尔兰时报的Derek Scally撰写了一篇文章，介绍了如何“去Google化您的生活”。 2016年，Androi的克里斯·卡洛恩（Kris Carlon）d Authority建议CyanogenMod 14的用户可以将其手机“去Google化”，因为CyanogenMod在没有Google应用的情况下也可以正常工作。 Inverse的Nick Nickcheschesi在2018年发表了一篇关于ProtonMail如何促进“完全摆脱Google-fy您的生活”的文章。 Lifehacker的Brendan Hesse写了一篇关于“退出Google”的详细教程。Gizmodo记者Kashmir Hill声称她错过了会议，并且在不使用Google Calendar的情况下组织聚会很困难。2019年，华为向菲律宾的手机所有者退款，这些人当时是之所以禁止使用Google提供的服务，是因为很少有其他选择，以至于缺少公司产品会导致无法正常使用互联网。

***

＃Degoogle-您的生活
一个常规的Degoogling信息的存储库，并链接到其他Degoogling的存储库。

***

## Wuest3nFuchs概述

由[Wuest3nFuchs]（https://github.com/Wuest3nFuchs）提供的更好的描述-来源：[Wuest3nFuchs / Degoogle]（https://github.com/Wuest3nFuchs/Degoogle）

＃＃＃ 这是什么意思？通过Wuest3nFuchs

消隐手段是指停止使用属于Google的任何产品（由Google制造的任何产品）。我说的是他们的搜索引擎，他们的邮件服务（Gmail），Youtube等。

###为什么要使用Google？通过Wuest3nFuchs

Google是目前世界上最强大的公司之一。他们为我们所有人存储了大量信息。有人会说我们的信息对他们是安全的，因为他们知道如何保护它。但这不是真的。 Google之前已经被渗透，并且将来会被渗透。也许不是由某个脚本小子来完成，而是由一个民族国家来完成。 Google会在我们所有人中存储个人信息，因为这是他们赚钱的方式。

他们扫描我们的电子邮件，存储我们在使用他们的搜索引擎时搜索的内容，以及我们在Youtube上观看的视频。他们以此为目标，并在我们的个人资料上建立我们的形象，以便根据我们与最好的朋友的交谈向我们展示一些广告，以便他们可以向我们展示我们需要的广告，但这太令人毛骨悚然。多亏了斯诺登先生，我们现在知道Google通过名为“ PRISM” **的程序与NSA共享了我们的个人信息。


将来，某个人将能够访问所有这些信息，我向您保证，确实会发生一些非常糟糕的事情。为防止这种情况的发生，您应该立即开始Degoogling。同样，您不应该使用与** NSA **共享数据的公司的产品。您应该通过取消搜索来阻止所有这一切。

**如果其他人可以做到，您也可以做到。

[在这里阅读更多]（https://github.com/Wuest3nFuchs/Degoogle）

<！-当前未列出到fork的链接，因为我并不完全拥有此存储库，并且想推广其他资源。链接到我自己的https://github.com/Degoogle-your-life/Degoogle会很自私！->

***

##文章

###文章状态

_所有文章目前仍在进行中，需要大量改进。提出建议和修正。_

_截至2021年4月18日下午4:09，大多数文章尚未开始。我正在努力寻找时间和精力来启动它们。_

[为什么您应该停止使用Google Chrome]（https://github.com/seanpm2001/Why-you-should-stop-using-Chrome）<！-1！->

[停止使用ChromeBooks]（https://github.com/seanpm2001/Stop-using-Chromebooks）<！-2！->

[停止使用WideVine DRM /是时候切割WideVine DRM]（https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM）<！-3！->

[为什么您应该停止使用ReCaptcha]（https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha）<！-4！->

[从YouTube替代]（https://github.com/seanpm2001/Alternating-from-YouTube）<！-5！->

[停止谷歌搜索，为什么您应该停止使用Google搜索]（https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search）<！-6！- >

[为什么您应该停止使用Gmail]（https://github.com/seanpm2001/Why-you-should-stop-using-GMail）<！-7！->

[为什么你应该停止使用Android]（https://github.com/seanpm2001/Why-you-should-stop-using-Android）<！-8！->

[为什么您应该避免使用Google Amp]（https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP）<！-9！->

[为什么您应该停止使用Google云端硬盘]（https://github.com/seanpm2001/为什么-您-应该-停止使用Google-云端硬盘）<！-10！->

[为什么您应该停止使用Google Maps和Google Earth]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth）<！-11！- ->

[嘿Google，停止]（https://github.com/seanpm2001/Hey-Google-Stop）<！-12！​​->

[停止从Google / Play图书中阅读]（https://github.com/seanpm2001/Stop-reading-from-Google-Books）<！-13！->

[停止使用Google课堂]（https://github.com/seanpm2001/Stop-using-Google-Classroom）<！-14！->

[为什么您应该停止使用Google Translate]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate）<！-15！->

[为什么您应该停止使用您的Google帐户]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Accounts）<！-16！->

**即将撰写的新文章：**

[为什么您应该停止使用Gerrit]（https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit）<！-17！->

[为什么您应该停止使用Google Analytics（分析，该存储库在2021年2月24日，星期三，4：13 pm截止，我的头就坏了）]] -Google-Analytics）<！-18！->

<！-工作分隔线！->

[为什么您应该停止使用Google AdSense]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense）<！-19！->

[为什么您应该停止使用Google One]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-One）<！-20！->

[为什么您应该停止使用Google+（已停用）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus）<！-21！->

[为什么您应该停止使用Google Play商店]（https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store）<！-22！->

[为什么您应该停止使用Google文档]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs）<！-23！->

[为什么您应该停止使用Google幻灯片]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides）<！-24！->

[为什么您应该停止使用Google表格]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets）<！-25！->

[为什么您应该停止使用Google表单]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms）<！-26！->

[为什么您应该停止使用Google Cardboard]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard）<！-27！->

[为什么您应该停止使用Google Messages]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages）<！-28！->

[为什么您应该停止使用Google Material Design]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design）<！-29！->

[为什么您应该停止使用Google Glass / Glasses]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass）<！-30！->

[为什么您应该停止使用Google紫红色]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia）<！-31！->

[为什么您应该停止使用GBoard]（https://github.com/seanpm2001/Why-you-should-stop-using-GBoard）<！-32！->

[为什么您应该停止使用Google Home]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home）<！-33！->

[为什么您应该停止使用Google Nest]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest）<！-34！->

[为什么您应该停止使用Google Hangouts（已终止）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts）<！-35！->

[为什么您应该停止使用Google Duo]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo）<！-36！->

[为什么您应该停止使用Google Tensorflow]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow）<！-37！->

[为什么您应该停止使用Google Blockly]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly）<！-38！->

[为什么您应该停止使用Google Flutter]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter）<！-39！->

[为什么您应该停止使用Google Go语言编程语言]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go）<！-40！->

[为什么您应该停止使用Google Dart编程语言]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart）<！-41！->

[为什么您应该停止使用Google WebP图像格式]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP）<！-42！->

[为什么您应该停止使用Google WebM视频格式]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM）<！-43！->

[为什么您应该停止使用Google Video]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video）<！-44！->

[为什么您应该停止使用Google网站（经典）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic）<！-45！->

[为什么您应该停止使用Google协作平台（“新”）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New）<！-46！->

[为什么您应该停止使用Google Pay]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay）<！-47！->

[为什么您应该停止使用Android Pay]（https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay）<！-48！->

[为什么您应该停止使用Google VPN（oxymoron）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN）<！-49！->

[为什么您应该停止使用Google相簿]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos）<！-50！->

[为什么您应该停止使用Google日历]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar）<！-51！->

[为什么您应该停止使用VirusTotal（因为自2012年9月以来它已由Google拥有）（https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal）<！-52！- >

[为什么您应该停止使用Google Fi]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi）<！-53！->

[为什么您应该停止使用Google Stadia]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia）<！-54！->

[为什么您应该停止使用Google Keep]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep）<！-55！->

[为什么您应该停止使用Google Base]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base）<！-56！->

[为什么您应该停止参加Google Summer of Code]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code）<！-57！- >

[为什么您应该停止使用Google Camera]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera）<！-58！->

[为什么您应该停止使用Google计算器（可能看起来很极端，但是您应该从所有内容中删除Google，非常容易替代）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-计算器）<！-59！->

[为什么您应该停止使用Google调查+奖励]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards）<！-60！->

[为什么您应该停止使用Google绘图]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings）<！-61！->

[为什么您应该停止使用Tenor（GIF网站，自2019年起由Google拥有）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor）<！-62！- ->

[什么是FLoC-为什么您应该避免Google的大FLoCing问题（停止使用Google Chrome）]（https://github.com/seanpm2001/What-the-FLoC）<！-63！->

**总文章数：**`63`

**第[路线图AB]（DegoogleCampaign_2021Roadmap_Part1.md）（截至2021年3月12日）休假2天**

**第[路线图BB]（DegoogleCampaign_2021Roadmao_Part2.md）（最晚2021年）关闭2天**

文章状态

所有文章目前仍在进行中，需要大量改进。建议和修正是允许的。

**叉**

扩展我的Degoogle网络，并增加访问便利性和社区呼声。

1. [Fossapps]（https://github.com/Degoogle-your-life/Fossapps）|派生自：[https://github.com/wacko1805/Fossapps]（https://github.com/wacko1805/Fossapps）（英语）

2. [隐私链接]（https://github.com/Degoogle-your-life/Privacy-links）|派生自：[https://github.com/Arturro43/privacy-links](https://github.com/Arturro43/privacy-links）（波兰语）

3. [令人愉快的隐私]（https://github.com/Degoogle-your-life/Delightful-Privacy）|派生自：[https://github.com/LinuxCafeFederation/Delightful-Privacy]（https://github.com/LinuxCafeFederation/Delightful-Privacy）（英语）

4. [阻止列表]（https://github.com/Degoogle-your-life/blocklists）|派生自：[https://github.com/jmdugan/blocklists]（https://github.com/jmdugan/blocklists）（英语）

5. [Degoogle，作者：Wuest3nFuchs]（https://github.com/Degoogle-your-life/Degoogle）|派生自：[https://github.com/Wuest3nFuchs/Degoogle]（https://github.com/Wuest3nFuchs/Degoogle）（英语）

**有关的**

[已删除Android手机虚拟机的研究]（https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research）

**也可以看看：**

[Google在Wikipedia上的批评]（https://en.wikipedia.org/wiki/Criticism_of_Google）

[Google Graveyard（killedbygoogle.com）-Google杀死了224种以上产品的排序列表]（https://killedbygoogle.com/）

> [GitHub链接]（https://github.com/codyogden/killedbygoogle）

[字母工会-Google的新工会有800多名成员]（https://alphabetworkersunion.org/people/our-union/）

[不想与恐龙复活节彩蛋分开吗？该网站覆盖了您] [https://chromedino.com/）

***

＃＃ 隐私

[G]（https://en.wikipedia.org/wiki/Criticism_of_Google）[o]（https://en.wikipedia.org/wiki/PRISM_（surveillance_program））[o]（https：//www.reddit .com / r / degoogle /）[g]（https://www.wired.com/2012/06/opinion-google-is-evil/）[l]（https://securitygladiators.com/chrome-privacy -bad /）[e]（https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/）[h]（https：// www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy）[a]（https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1）[a]（https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html）[v]（https：//www.huffpost .com / entry / why-googles-spying-on-use_b_3530296）[e]（https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ）[r]（https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data）[y]（https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html）[v]（https：// protonmail。 com / blog / google-privacy-problem /）[e]（https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /）[r]（https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy）[y]（https://en.wikipedia.org/wiki/Nothing_to_hide_argument＃Criticism）[b]（https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/）[a]（https://eduzaurus.com/free -essay-samples / nothing-to-hide-argument-has-nothing-to-say /）[d]（https://www.cnet.com/how-to/google-collects-a-frightening-amount-关于您的数据可以找到并删除的信息，现在/）[r]（https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -your-personal-data-n870501）[e]（https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -monetizes-and）[c]（https://www.wired.com/story/google-tracks-you-privacy/）[o]（https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy）[r]（https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- collection-revealed.html）[d]（https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H）[w]（https://www.wired.com/story/ health-fitness-data-privacy /）[h]（https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks）[e]（https://mashable.com/article/google-android-data-collection-study/）[n]（https：//www.engadget .com / australian-government-google-data-collection-lawsuit-182043643.html）[i]（https://www.maketecheasier.com/studyandroid-data-google-ios-apple/）[t]（https： //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/）[c]（https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https://moz.com /blog/where-does-google-draw-the-data-collection-line)[e](https://mashable.com/article/google-android-data-collection-study/)[s](https： //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/）[t]（https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)[o](https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data代表5m索赔百万用户（iphone）用户[u]（https://time.com/23782/google-flu-trends-big-data-problems/）[s]（https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W）[e]（https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/） [r]（https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html）[p]（https：// topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/)[r](https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/)[i](https://www.cbsnews.com/news/google-education-spies-on-collects-数以百万计的孩子-指控-诉讼-新墨西哥州律师总署/)[v](https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -under-our-noses /）[a]（https://www.wired.com/insights/2012/10/google-opt-out/）[c]（https://www.nytimes.com/2019 / 09/04 / technology / google-yout ube-fine-ftc.html）[y]（https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550）[。]（https ：//medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c）（我可以不断地证明这一点，但是花了很长时间才能找到并仔细研究所有这些文章）

由于所有Google产品都包含间谍软件，因此Google产品的隐私始终很糟糕。

无论您做什么，使用Google时，所有敏感个人数据都会发送给Google和其他人。谷歌也被发现正在经历开放程序。例如，根据我的个人经验（在Firefox上），打开了我未曾访问过的YouTube标签，我离线观看了多个视频（VLC Media Player）。后来，当我查看建议时，几乎就是我所观看的一切。毫无疑问，他们也在监视其他程序。

在Chrome（和许多其他浏览器）中，存在隐身模式。在Chrome中，此模式毫无意义，因为Google仍会挖掘您的数据。即使您关闭了数据挖掘/跟踪功能，并启用了“请勿跟踪”信号，这也令人惊讶，Google仍在挖掘您的数据。

如果您认为自己没有什么可隐藏的，那么**您绝对是错误的**。这个论点被多次揭穿：

[通过维基百科]（https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism）

1.爱德华·斯诺登（Edward Snowden）说：“争辩说您不关心隐私权是因为您没有什么可隐瞒的，这与说您不在乎言论自由是因为您无话可说。”我没什么可隐瞒的，”您说，“我不在乎这项权利。”您是在说，“我没有这项权利，因为我必须要证明自己的理由。权利的运作方式是，政府必须证明其侵犯您权利的合理性。”

2. Daniel J. Solove在《高等教育纪事》的一篇文章中说，他反对这一论点。他说，政府可以让k有关某人的信息并对该人造成损害，或使用有关某人的信息来拒绝获得服务，即使该人实际上并未从事不当行为，并且政府也可能因犯错误而对个人的生命造成损害。索洛夫（Solove）写道：“直接参与时，无所不包的论点可能会令人反感，因为它迫使辩论集中在对隐私的狭understanding理解上。但是，当面对由政府数据收集和使用所带来的众多隐私问题时，就超出了监视和监视的范围。披露，最后无话可说的说法无话可说。”

3.隐私权：道德和法律基金会的作者亚当·D·摩尔认为：“这是权利抗拒成本/收益或后果论点之类的观点。在这里，我们拒绝认为隐私利益属于这种观点。可以交易以换取安全性的东西。”他还指出，监视可以基于外观，种族，性取向和宗教对社会中的某些群体产生不成比例的影响。

4.计算机安全专家和密码学家布鲁斯·施耐尔（Bruce Schneier）表示反对，他援引了黎塞留枢机主教的说法：“如果给我六句由最诚实的人手写的文字，我会发现其中有些东西使他被绞死”州政府如何起诉或勒索该人的生活。施耐尔还指出：“太多人错误地将辩论描述为'安全与隐私'。真正的选择是自由与控制。”

5. Harvey A. Silverglate估计，普通百姓平均每天在美国不知情的情况下犯下三项重罪。

6.哲学家和心理分析家埃米利奥·莫迪尼（Emilio Mordini）认为，“无可掩盖”的论点本质上是自相矛盾的。人们不需要具有“隐藏的东西”即可隐藏“某些东西”。莫迪尼说，隐藏的东西不一定是相关的。相反，他认为必须同时隐藏和限制访问的私密区域是必要的，因为从心理上讲，我们通过发现可以向他人隐藏某些东西而成为个人。

7.朱利安·阿桑奇（Julian Assange）表示：“尚无杀手.。雅各布·阿佩尔鲍姆（@ioerror）做出了明智的回应，要求说这话的人将手机解锁并放下裤子，我的意思是， “好吧，如果你是如此无聊，那么我们不应该和你说话，其他任何人也不要说话。”但从哲学上讲，真正的答案是：大规模监视是一种大规模的结构性变化。即使你是地球上最卑鄙的人，也要接受它。”

8.法学教授伊格纳西奥·科丰（Ignacio Cofone）辩称，该论点本身是错误的，因为每当人们向他人披露相关信息时，他们也会披露无关的信息。这些不相关的信息会增加隐私成本，并可能导致其他危害，例如歧视。

***

##其他反Google广告系列

这是其他一些著名的反Google广告系列的列表。此列表不完整。你可以帮助扩展它。

###已终止

[Scroogled-Microsoft（2012年11月至2014年11月）]（https://en.wikipedia.org/wiki/Scroogled）

_目前没有其他条目。

###进行中

_此列表当前为空。

***

##反击其他参数

人们提出一些论据来证明Google的正当性。第一个主要的对象之一已经被揭穿了[here]（＃Privacy），但这里还有一些其他的：

＃＃＃ 方便

是的，Google产品似乎很方便。但是，为了方便起见，您正在交易所有有益的东西，包括安全性，隐私和可靠性。多年来，Google变得越来越懒惰，其服务器的故障越来越多。目前，Google服务器每月会中断近1-2个小时的一个小时（最著名的是YouTube）

不幸的是，由于社会对Google的依赖，Google已成为互联网的主导者，并且正在寻求控制越来越多的东西。 2012年，当Google下降5分钟时，据报道，“全球**互联网流量”下降了40％**谷歌经常下降了1-2小时，并且[解雇了道德团队] （https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/）等，它们将变得越来越不方便。

便利并不总是一件好事。您应该知道发生了什么情况，并为它们出现故障做好准备，因为没有一种方法可以使服务器偶尔不间断。

Google也不如您想象的那样方便。还有其他更方便的站点。 Google远非如此，当您对他们的随机帐户被暂停和终止而无任何响应（除非您对Google Twitter帐户给予足够的关注或以1亿美元或更高的价格起诉他们）时，他们就利用了您，将您搞砸了，并且强迫你尖叫到枕头上，没人能听到你的尖叫声求助。

###为什么重要，反正为时已晚

这是一个不太常见的论点，但需要解释。在目前的状态下，大多数世界各国政府以及几家实力雄厚的公司似乎都知道您的一举一动，那么，为什么还要为此而烦恼呢？答案很简单：**您应该得到更好的**。如果此时您设法远离他们，那么他们很难进一步追踪您的举动，并且您可以建立一种新的更加私密的生活。

[1个来源]（https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/）顺便说一句，每当我获得这个帖子超过一周的时间，我都会给我免费的Reddit奖。现在（连同我所有的500个免费硬币）进一步推动这个话题。到目前为止，我已为该帖子提供了14多个免费奖项。数量不多，但细小的事情会产生很大的影响，这取决于它的感知方式和对象。

＃＃＃ 其他

我目前没有其他论点。

_此列表不完整_

***

##来源

复制：

[G]（https://en.wikipedia.org/wiki/Criticism_of_Google）[o]（https://en.wikipedia.org/wiki/PRISM_（surveillance_program））[o]（https：//www.reddit .com / r / degoogle /）[g]（https://www.wired.com/2012/06/opinion-google-is-evil/）[l]（https://securitygladiators.com/chrome-privacy -bad /）[e]（https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/）[h]（https：// www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy）[a]（https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1）[a]（https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html）[v]（https：//www.huffpost .com / entry / why-googles-spying-on-use_b_3530296）[e]（https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ）[r]（https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data）[y]（https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html）[v]（https：// protonmail。 com / blog / google-privacy-problem /）[e]（https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /）[r]（https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy）[y]（https://en.wikipedia.org/wiki/Nothing_to_hide_argument#批评）[b]（https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/）[a]（https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /）[d]（https://www.cnet.com/how-to/google-collects-a-frightening-amount-of-关于您的数据可以找到并删除，现在/）[r]（https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501）[e]（https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -and）[c]（https://www.wired.com/story/google-tracks-you -privacy /）[o]（https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy）[r]（https： //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H）[w]（https://www.wired.com/story/health-fitness-data-privacy/）[h]（https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks）[e]（https://mashable.com/article/google-android-data-collection-study/）[n]（https：// www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html）[i]（https://www.maketecheasier.com/studyandroid-data-google-ios-apple/）[t] （https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/）[c]（https：// www。 cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line）[e]（https://mashable.com/article/google-android-data-collection-study/）[s]（https：/ /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/）[t]（https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html）[o]（https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data-代表5百万名iPhone用户代表）[u]（https://time.com/23782/google-flu-trends-big-data-problems/）[s]（https：/ /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /）[r]（https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you。 html）[p]（https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/）[r]（https：// arstechnica .com / information-technology / 2014/01 / what-google-can-really-do-with-nest-or-really-nests-data /）[i]（https://www.cbsnews.com/news/google-education -spies-on-collects-data-on-millions-kids-alleges-aleges-lawsuit-new-mexico-attorney-general /）[v]（https://www.nationalreview.com/2018/04/the- Student-data-mining-scandal-under-our-noses /）[a]（https://www.wired.com/insights/2012/10/google-opt-out/）[c]（https：// www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did -have-something-to-hide-40689565c550）[。]（https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c）

其他来源：

[五只眼睛联盟]（https://en.wikipedia.org/wiki/Five_Eyes）[十九四十四]（https://en.wikipedia.org/wiki/十九四十四）

***

##下载链接

[获取Firefox]（https://www.mozilla.org/zh-CN/firefox/new/）[获取Tor浏览器]（https://www.torproject.org/download/）[其他/不可用]（https ：//www.example.com）

***

##我的脱胶经验

我终于在2018年开始看到大型技术存在的问题，并且我开始取消定位。在最初的几个月中，我取得了长足的进步。从那以后，它大大放慢了速度。


###我从何而来

Google Chrome-> Firefox / Tor

Google搜索-> DuckDuckGo（默认）/ Ecosia（我感觉到）/ Bing（很少）

GMail-ProtonMail（尚未完全切换）

Google协作平台->自托管（尚未完全切换）

Google+->很少使用，由于自身关闭而被删除

Google文档->从未使用过，我只使用Microsoft Word 2013（在2019年之前）和LibreOffice（从2019年开始）。

Google表格->从未使用过，我只使用Microsoft Excel 2013（在2019年之前）和LibreOffice（从2019年开始）。

Google幻灯片->从未使用过，我只使用Microsoft PowerPoint 2013（在2019年之前）和LibreOffice（从2019年开始）。

Google绘图->从未使用过，我只是使用LibreOffice（从2019年开始）。

Gerrit->从来没有用过，我只使用GitHub（当前默认设置），GitLab，BitBucket和SourceForge。

Google相册->从未使用

Google云端硬盘-> OneDrive（2019-2020）Degoo（2020-2020）pCloud（2020年至今）

Google Maps-> OpenStreetMaps / Apple Maps

Go-进行特殊处理，但不用作功能性编程语言

Dart-产生特殊异常，但不用作功能性编程语言

Flutter-产生特殊异常，但不用作功能编程语言

Google地球-> OpenStreetMaps / Apple Maps

Google Streetview->从未使用过，我觉得它特别令人毛骨悚然

Google Fi->从未使用

Google日历->从未使用

Google计算器->从字面上看，其他任何计算器应用程序，甚至我认为都可以在Python模式下运行的Linux终端

Google Nest->从未使用

Google AMP->从未使用

Google VPN->从未使用过，也是矛盾的

Google Pay->从未使用

Google Summer of Code->从未参加

Tenor->其他GIF站点，尽管GIF对我来说不太重要。我通常从DuckDuckGo图像，Imgur，Reddit或其他站点获取GIF文件。

块状->不再使用，不确定是否Scratch直接块状运行。我从2017年开始成为函数程序员，从Scratch成长而来。

GBoard->使用一次，但被废弃

Google眼镜->从未使用过，被认为是一个小孩子，但是如果我可以选择的话，决定不买一个

_列表可能不完整。

###我仍然无法摆脱的产品

自2021年2月25日起，以下这些Google产品使我无法完全取消使用Google搜索：

1. YouTube

2. Android

3. Google Play商店

4. GMail（仅适用于学校和某些网站）

5. Google课堂（仅适用于学校）

6. Google翻译

7. Google帐户

8. Google协作平台（由于Google违反了GDPR的法律（在将其解决之前，可能会面临另外的5,000,000.00欧元的罚款），并禁止下载该产品）

我已经从其他一切中脱颖而出。

***

##走是邪恶的

Google用其编程语言“ Go”（从6年后的2009年开始）改用了2003年基于Agent的编程语言“ Go！”，并声称他们的语言完全不会影响其他语言。谷歌为此受到了严厉的批评，因为当时他们的“不要作恶”的座右铭仍然很活跃，这是使“不要作恶”的座右铭退休的众多事件之一。

最后，“ Go！”的开发停止了，而“ Go”变得越来越普遍。 Google声称他们不会涉足Go !，但最终他们做到了，他们就放弃了（截至2021年4月9日）

[在此处详细了解Go以及如何进行替换]（https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go）

***

## DRM的用法

Google通过其WideVine DRM“服务”和其他形式使用DRM（数字限制管理）。 DRM的目标是破坏开放的Internet，并赋予公司对用户的垄断权。无论成本如何，您都应该完全摆脱WideVine。

[在此处阅读有关WideVine及其问题的更多信息]（https://github.com/Degoogle-your-life/Its-time-to-cut-WideVine-DRM）

***

##常见误解

这是对Google产品的一些常见误解的列表。

### Google不是互联网

Google / Google搜索不是互联网，Google搜索只是一个搜索引擎，有点像不是Nintendo平台上的每个游戏都是由Nintendo制造的，而是由Nintendo许可的，但程度更大。如果现在要同时销毁所有Google服务器，那么只有YouTube，Gmail，Google Docs，Google搜索等Google站点会消失，但是大部分Internet仍然存在（Wikipedia，Stackoverflow，GitHub， Microsoft的所有网站，NYTimes，三星，TikTok等），它们可能会失去其Google登录和分析功能，但它们仍然可以正常工作（除非它们的程序设计不佳且直接依赖于Google）

***

## Internet Explorer 6和Chrome

谷歌浏览器正在成为新的Internet Explorer6。当谷歌浏览器最初问世时，Firefox是占主导地位的浏览器，当谷歌浏览器出现时，它主要扼杀了Internet Explorer的市场份额（在数以百万计的人切换到Firefox和其他浏览器之前，该市场份额已超过96％）。出来之后，人们由于它的速度和它的速度而被Google所取代（当时还不认为它是邪恶的，因为大多数隐私问题尚未揭晓），谷歌浏览器最初尊重网络标准（这是Firefox所做的）导致Internet Explorer失去了96％的浏览器市场份额），但是，随着Google Chrome浏览器市场份额的上升，Google开始删除越来越多的功能，添加了更多的间谍软件，并停止接受网络标准，Google Chrome已成为新的Internet Explorer 6。

目前的主要问题是仅使用Chrome的网站，并且无法在其他浏览器上运行，因为开发人员认为他们不希望其他30-40％的不使用Chrome的互联网用户使用他们的网站。

甚至Google本身也只将自己的网站设置为Chrome。例如，如果Google搜索检测到您未使用Google Chrome（即使其他基于Chromium的浏览器，例如Br​​ave，也会受到影响）并且Google Earth不允许Firefox用户访问，则每10秒会提示您下载Chrome 3次。使用他们的网站（截至2020年），并且Google Translate不支持Firefox和其他非Google Chrome浏览器上的语音输入。

###勇敢的问题

其他基于Chromium的浏览器（例如Brave和Microsoft Edge）并非完全没有Google间谍软件。隐私社区的另一端通常建议使用“勇敢”，但“勇敢”仍是一个问题，因为它使用Chromium。互联网不应仅由Chromium浏览器组成，应该有多种选择。勇敢是错误的路要走。

[在此处阅读有关从Google Chrome / Chromium进行信息删除的更多信息]（https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome）

[在此处详细了解有关从ChromeOS / ChromiumOS（Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC）取消搜索的信息]（https://github.com/Degoogle-your-life/Stop-using-Chromebooks）

***

##伪造的隐私续约

在为时已晚之后，Google一直在试图向世界表明他们关心隐私。他们继续声称自己尊重用户隐私，但仍未解决所有隐私问题。

###开源不能部分

开源不能是局部的。 Google证明了这一点。源代码的每一位和每一字节都必须是公众可见的，甚至不能隐藏八分之一字节。

像Android和ChromeOS这样的项目是部分开源的，但是包含大多数专有的间谍软件元素。

### Oxymoron

Google VPN是矛盾的。 Google并不关心隐私，像这样的公司提供的虚拟专用网（VPN）将是VPN服务最糟糕的选择之一。

***

##表现不佳

Google不在乎产品至少在2017年之前的性能，因为其最新的基准测试软件（Google Octane）已于2017年停产。

***

##错误的项目管理

Google的内部项目管理系统非常糟糕。越来越被降级的程序的一些常见示例包括Google Duo和YouTube音乐（以前称为Google Play音乐）

在Google的内部开发系统中，一个应用程序引向另一个具有一半功能的应用程序，然后原始应用程序被删除。几年后，制作了功能减少了75％的新应用，然后删除了功能减少了50％的应用，随后又创建了具有87.5％的功能的新应用，然后停用了功能减少了75％的应用， 等等。

***

##糟糕或无节制的服务

YouTube是不良节制世界中最常见的示例，它创造了最糟糕的平台。 Google似乎也没有发现YouTube不是YouTube的孩子。

对于YouTube，向用户投放可憎的亲纳粹和白人至上主义者的内容是为了给用户更多的参与时间和更多的钱。谷歌也做了一些非常适度的愚蠢行为，例如批准将“基督教肛交”视频作为“为孩子制作的内容”，同时对视频进行年龄限制。在“小鲨鱼”视频下面以及在为儿童制作的其他各种内容旁边出现色情或血腥广告的情况并不少见。

YouTube用户经常抱怨YouTube对不良内容的管理不善（例如上面列出的示例），而用户却可以无缘无故地无缘无故地删除自己的视频，并且会因任何形式的咒骂而受到惩罚，由于这些不平等的惩罚，即使是很小的情况，例如说“废话”的用户，通常在斯大林时代也将YouTube与[Soviet Union]（https://en.wikipedia.org/wiki/Soviet_Union）进行比较。

2021年，Google宣布尽管视频已被取消（尽管Google赚钱，但创作者没有），但他们仍将在所有视频上投放广告，这与节制并不过分，但这很重要。

YouTube处于受监管的状态（尽管效果很差），但是，使他们赚钱最多的Google广告服务似乎很少或没有节制。

[阅读有关YouTube审核问题以及如何从YouTube替代的更多信息]（https://github.com/seanpm2001/Alternating-from-YouTube）

Google Play的广告是从漫游器农场中产生的，您可以通过数百家公司使用相同的广告场景进行几乎没有变化但与产品没有任何关系的广告来判断（常见示例：Playrix（居家风光，Gardenscapes）Fishdom，黑手党城和数以千计的广告）以及日益猖malicious的恶意广告趋势，声称用户可以通过玩游戏，听音乐等来赚钱。PayPal没有对此发表评论，但是很明显，这是一个骗局，就好像您可以赚钱一样。在保证的时间内，在不到20秒的时间内超过10,000美元，没有人会做工作，而是会做这件事，这是不可能的，并且企业也无法像这样工作。自2019年以来，这种明显的骗局一直在变得越来越强大，现在制作这些广告的机器人农场正在各自的广告中相互搏斗。

几则广告也非常诱人，试图吸引用户（其中​​大多数是13岁以下的用户或漫游器）通过性操作进行点击。

许多应用使用机器人并对其产品进行草皮处理，因此，每当进行不良评论时，袜子木偶机器人帐户就会开始发布5星评论，并试图消除您的批评。 [Google也在自己做这件事]（＃Astroturfing）

[阅读有关Google AdSense问题的更多信息]（https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense）

***

##草皮

通用定义[（来自Wikipedia）]（https://en.wikipedia.org/wiki/Astroturfing）

```
涂草皮是一种掩盖消息或组织（例如政治，广告，宗教或公共关系）赞助者的做法，以使其看起来好像是来自基层参与者并受到其支持。这种做法旨在通过隐瞒有关来源的财务联系的信息来使声明或组织具有信誉。术语“草皮草料”源自AstroTurf，这是一种合成地毯的品牌，旨在模仿天然草，用作“草根”一词的玩法。使用该术语的含义是，所支持的活动不是“真实的”或“自然的”草根努力，而是“假的”或“人为的”支持。
```

Google过去一直在进行草率处理，以使其看起来好像没有做任何坏事（在此过程中，进行草率处理是有害的），例如，在诸如Twitter之类的平台（他们拥有帐户）上发布Google的犯罪行为会导致有几个已经存在了一段时间但从未发布过的帐户，然后才出来，声称您所说的是假的，然后声称Google是最好的公司，但这样做的方式可能对大多数人来说似乎不是机器人人们。

***

##非法和不道德的商业行为

Google使用非法和不道德的商业惯例来进一步扩大其垄断地位，例如利用避税天堂，外包工作以及继续从事非法侵入性活动作为经营成本。

＃＃＃ 在欧洲

欧洲经常起诉Google，最大的诉讼是针对Android中的非法行为，这导致Google收到5,000,000,000欧元（相当于2021年4月9日的5,947,083,703.68美元）

###在北美

与欧洲的50亿欧元罚款相比，美国尚未向Google支付足够的罚款。

###争议

Google只会在引发争议之前才关心问题，然后他们会努力地解决该问题，足以使争议暂时消失，然后问题成倍地恶化，直到引发另一个争议为止，周期继续。他们根本不在乎做任何严肃的事情。

***

## Google是自动化的

作为一个com恐慌的是，Google大多是自动化的，比自动化程度要低。

公司不应该完全自动化。谷歌就是一个例子。仅由AI进行审核是很可怕的，YouTube就是一个很好的例子，即使有很少（数百甚至一千）的人对网站进行审核，这显然很糟糕，以至于大多数人在工作时都必须接受治疗。

***

＃＃ 安卓

Android由Google拥有。开放手机联盟（自Android以来一直未开放）的一部分，Android已成为Google的另一个垄断点，并且是一个很难摆脱的垄断点。

据报道，Android每天至少会向Google打电话10次，尽管它是部分开源的，但它仍在充当间谍软件。

已经创建了多个项目来替代Android，但需要使您的设备生根。由于Knox DRM，对于美国的特定三星手机而言，这根本不可能了。 Android的常见替代产品包括iOS，iPadOS，LineageOS，Android x86，Ubuntu Touch和PiPhone（Pi Phone是在移动设备上运行各种Linux系统的手机，例如Fedora，Ubuntu，Arch等）。

[请参阅我对获得脱谷歌的Android虚拟机功能的研究]（https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research）

[查看如何从Android解Google]（https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android）

***

##可以帮助的小动作

尽一切可能传播意识很重要。对我来说，我不仅经常谈论脱胶和写文章，而且还有一个小习惯，我每天都会将免费的Reddit奖授予r / degoogle上的固定帖子，以提高知名度。到目前为止，我已将近30个奖项授予了该固定帖子（为此帖子我还花了500枚免费硬币用于10个奖项）

***

##不可信

Google无法被信任，也永远不会再被信任。他们已经完全从“别作恶”（他们总是作恶）转变为完全作恶而不是试图隐藏它。

***

##其他要检查的东西

[Google Graveyard（killedbygoogle.com）-Google杀死了224种以上产品的排序列表]（https://killedbygoogle.com/）

> [GitHub链接]（https://github.com/codyogden/killedbygoogle）

[字母工会-Google的新工会有800多名成员]（https://alphabetworkersunion.org/people/our-union/）

[不想与恐龙复活节彩蛋分开吗？该网站覆盖了您] [https://chromedino.com/）

还有其他替代品，只需搜索它们即可。

***

本文需要进行一些事实检查

***

##文件信息

文件类型：`Markdown（* .md）`

行数（包括空行和编译器行）：968

档案版本：`6（2021年4月18日，星期日，下午4:18）`

***

###软件状态

我所有的作品都是免费的，有一些限制。我的任何作品中都没有DRM（** D **原始** R **限制** M **管理）。

！[DRM-free_label.en.svg]（DRM-free_label.en.svg）

此标签由自由软件基金会支持。我从不打算在自己的作品中加入DRM。

我使用的缩写是“数字限制管理”，而不是更广为人知的“数字权限管理”，因为解决它的常见方法是错误的，DRM没有权限。 [Richard M. Stallman（RMS）]（https://en.wikipedia.org/wiki/Richard_Stallman）和[Free Software Foundation（FSF）]支持拼写“数字限制管理”， https://zh.wikipedia.org/wiki/Free_Software_Foundation）

本部分用于提高对DRM问题的认识，并进行抗议。 DRM在设计上是有缺陷的，并且是对所有计算机用户和软件自由的重大威胁。

图片来源：[defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label）

***

##赞助商信息

！[SponsorButton.png]（SponsorButton.png）<-不要单击此按钮，它不起作用，它只是一张图像。实按钮位于页面右上角（<-L ** R **->）的顶部

您可以根据需要赞助此项目，但请指定您要捐赠的内容。 [在这里查看您可以捐赠的资金]（https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors）

您可以在此处查看其他赞助商信息（https://github.com/seanpm2001/Sponsor-info/）

试试看！赞助商按钮在观看/取消观看按钮旁边。

***

##文件历史



 *开始文件

> *添加了标题部分

> *添加索引

> *添加了关于部分

> *添加了Wiki部分

> *添加了版本历史记录部分

> *添加了问题部分。

> *添加了“过去的问题”部分

> *添加了过去的拉取请求部分

> *添加了活动拉取请求部分

> *添加了贡献者部分

> *添加了贡献部分

> *添加了关于README部分

> *添加了自述版本历史记录部分

> *添加了资源部分

> *添加了软件状态部分，带有免费的DRM标签和消息

> *添加了赞助商信息部分

> *版本0.1中没有其他更改

版本1（2021年2月19日，星期五，下午5:20）

>变更：

> *开始文件

> *添加了基本描述部分

> *添加了存储库描述部分

> *添加了文章列表，其中有14个条目

>> *添加了“相关文章”部分

>> *添加了“另请参见”部分

> *添加了文件信息部分

> *添加了文件历史记录部分

> *添加了页脚

> *版本1中没有其他更改

版本2（2021年2月19日，星期五，下午5:26）

>变更：

> *添加了翻译状态部分

> *添加了“其他要检查的内容”部分

> *添加了“隐私”部分

> *添加了索引

> *添加了软件状态小节

> *添加了其他反Google广告系列部分

>> *添加了已失效的小节

>> *添加了正在进行的小节

> *添加了源代码部分

> *添加了下载链接部分

> *更新了文件信息部分

> *更新了文件历史记录部分

> *版本2中没有其他更改

版本3（2021年2月24日，星期三，晚上7:56）

>变更：

> *更新了索引

> *引用了degoogle图标和新的GitHub组织

> *添加了指向较新文章的链接

> *添加了反其他参数部分

>> *添加了便利性小节

>> *添加了“为什么还要打扰”小节

>> *添加了其他小节

> *更新了一些数据

> *更新了文件信息部分

> *更新了文件历史记录部分

> *版本3中没有其他更改

版本4（2021年2月25日，星期四，9：31 pm）

>变更：

> *添加了10篇新文章的链接

> *添加了有关我的经验消除的部分

> *更新了索引

> *更新了文件信息部分

> *更新了文件历史记录部分

> *版本4中没有其他更改

第5版（2021年4月9日，星期五，下午6:02）

_最近我一直缺乏反Google运动的更新，我正努力在中断1个月后恢复使用它。_

>变更：

> *更新了标题部分

> *更新了索引

> *更新了语言列表：修复了链接，并添加了更多受支持的语言

> *更新了文章状态部分，添加了4个fork链接

> *更新了软件状态部分

> *添加了围棋是邪恶的部分

> *添加了“ DRM的用法”部分

> *添加了常见的误解部分

>> * *添加了Google不是Internet小节

> *添加了Internet Explorer 6和Chrome部分

>> *添加了“勇敢的问题”小节

> *添加了伪造的隐私删除

> *添加了“开源不能部分划分”部分

> *添加了Oxymoron小节

> *添加了不良表现部分

> *添加了不良项目管理部分

> *添加了可怕或无节制的服务部分

> *添加了Astroturfing部分

> *添加了非法和不道德的商业行为部分

> *添加了“欧洲”小节

>> *添加了“北美地区”小节

>> *添加了“争议”小节

> *添加了Google自动化部分

> *添加了Android部分

> *添加了“小操作帮助”部分

> *添加了“不可信任”部分

> *添加了赞助商信息部分

> *更新了页脚

> *更新了文件信息部分

> *更新了文件历史记录部分

> *版本5中没有其他更改

版本6（2021年4月18日，星期日，下午4:18）

>变更：

> *更新了索引

> *添加了新的概述说明

> *更新了文章状态信息

> *为新的Google FLoC文章添加了链接

> *为Wuest 3n Fuchs Degoogle文章及其一般信息添加了链接

> *更新了文件信息部分

> *更新了文件历史记录部分

> *版本6中没有其他更改

版本7（即将推出）

>变更：

> *即将推出

> *版本7中没有其他更改

版本8（即将推出）

>变更：

> *即将推出

> *版本8中没有其他更改

版本9（即将推出）

>变更：

> *即将推出

> *版本9中没有其他更改

版本10（即将推出）

>变更：

> *即将推出

> *版本10中没有其他更改

版本11（即将推出）

>变更：

> *即将推出

> *版本11中没有其他更改

版本12（即将推出）

>变更：

> *即将推出

> *版本12中没有其他更改

***

##页脚

您已到达此文件的末尾

（[返回页首]（＃Top）| [返回GitHub]（https://github.com））

### EOF

***
