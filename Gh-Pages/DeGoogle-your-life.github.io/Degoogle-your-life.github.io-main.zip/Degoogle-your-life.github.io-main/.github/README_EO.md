***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle vian vivon

Ĉi tiu estas la ĉefa artikolo pri degoogling por ĝeneralaj informoj pri degoogling kaj ligo al la aliaj artikoloj.

[Vidu la liston kiel organizo de GitHub] (https://github.com/Degoogle-your-life)

***

_Legu ĉi tiun artikolon en alia lingvo: _

** Nuna lingvo estas: ** `Angla (Usono)` _ (tradukoj eble devas esti korektitaj por ripari la anglan anstataŭigante la ĝustan lingvon) _

_🌐 Listo de lingvoj_

([af Afrikansa] (/. github / README_AF.md) Afrikansa | [sq Shqiptare] (/. github / README_SQ.md) Albana | [am አማርኛ] (/. github / README_AM.md) Amhara | [ar عربى] (/.github/README_AR.md) Araba | [hy հայերեն] (/. github / README_HY.md) Armena | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbajĝana | [eu Euskara] (/. github /README_EU.md) Eŭska | [estu Беларуская] (/. Github / README_BE.md) Belorusa | [bn বাংলা] (/. Github / README_BN.md) Bengala | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) Bulgarian | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Ĉina (Simpligita) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Ĉina (Tradicia) | [co Corsu] (/. Github / README_CO.md) Korsika | [hr Hrvatski] (/. Github / README_HR.md) Kroata | [cs čeština] (/. Github / README_CS .md) ĉe Czecha | [da dansk] (README_DA.md) dana | [nl Nederlands] (/. github / README_ NL.md) Nederlanda | [** en-us English **] (/. github / README.md) English | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) estona | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finna | [fr français] (/. github / README_FR.md) franca | [fy Frysk] (/. github / README_FY.md) Frisa | [gl Galego] (/. github / README_GL.md) Galician | [ka ქართველი] (/. github / README_KA) kartvela | [de Deutsch] (/. github / README_DE.md) germana | [el Ελληνικά] (/. github / README_EL.md) Greka | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) havaja | [li Hebreo] (/. github / README_HE.md) Hebrea | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) hungara | [estas Íslenska] (/. github / README_IS.md) Islanda | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonezio] (/. github / README_ID.md) islanda | [ga Gaeilge] (/. github / README_GA.md) irlanda | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) japana | [jw Wong jawa] (/. github / README_JW.md) java | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) mermeroj | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Korea (Suda) | [ko-norda 문화어] (README_KO_NORTH.md) Korea (Norda) (NE TRADUTA) | [ku Kurdî] (/. github / README_KU.md) Kurda (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgizo | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latina | [lt Lietuvis] (/. github / README_LT.md) Litova | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksemburgia | [mk Македонски] (/. github / README_MK.md) Makedona | [mg madagaskarano] (/. github / README_MG.md) madagaskarano | [ms Bahasa Melayu] (/. github / README_MS.md) Malaja | [ml മലയാളം] (/. github / README_ML.md) Malajala | [mt Malti] (/. github / README_MT.md) Maltese | [mi maora] (/. github / README_MI.md) maora | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) mongola | [mia မြန်မာ] (/. github / README_MY.md) Mjanmao (birmano) | [ne नेपाली] (/. github / README_NE.md) Nepali | [neniu norsk] (/. github / README_NO.md) norvega | [aŭ ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Paŝto | [fa فارسی] (/. github / README_FA.md) | Persa [pl polski] (/. github / README_PL.md) Pola | [pt português] (/. github / README_PT.md) Portugala | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Panĝaba | Neniuj lingvoj disponeblaj, kiuj komenciĝas per la litero Q | [ro Română] (/. github / README_RO.md) Rumana | [ru русский] (/. github / README_RU.md) rusa | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) skota gaela | [sr Српски] (/. github / README_SR.md) Serba | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovaka | [sl Slovenščina] (/. github / README_SL.md) Slovena | [do Soomaali] (/. github / README_SO.md) Somalo | [[es en español] (/. github / README_ES.md) Hispana | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kisŭahili] (/. github / README_SW.md) Svahila | [sv Svenska] (/. github / README_SV.md) sveda | [tg Тоҷикӣ] (/. github / README_TG.md) Taĝika | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) tataro | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) taja | [tr Türk] (/. github / README_TR.md) Turka | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) ukraina | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vjetnama | [cy Cymraeg] (/. github / README_CY.md) kimra | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jida | [yo Jorubo] (/. github / README_YO.md) Jorubo | [zu Zulu] (/. github / README_ZU.md) Zulu) Havebla en 110 lingvoj (108 se oni ne kalkulas la anglan kaj nordkorean, ĉar nordkorea ankoraŭ ne estis tradukita [Legu pri ĝi ĉi tie]) / / OldVersions / Korean (North ) /README.md))

Tradukoj en aliaj lingvoj krom la angla estas aŭtomate tradukitaj kaj ankoraŭ ne estas ĝustaj. Ankoraŭ neniuj eraroj estis riparitaj ekde la 5a de februaro 2021. Bonvolu raporti tradukajn erarojn [ĉi tie] (https://github.com/seanpm2001/Degoogle-your-life/issues/) certigu rezervi vian korektadon per fontoj kaj gvidi min , ĉar mi ne bone scias aliajn lingvojn krom la angla (mi planas akiri tradukiston eventuale) bonvolu citi [vikivortaron] (https://eo.wiktionary.org) kaj aliajn fontojn en via raporto. Malsukceso fari tion rezultigos malakcepton de la korekto publikigita.

Noto: pro limigoj kun la interpreto de markado de GitHub (kaj preskaŭ ĉiu alia interreta interpretado de markado) alklakante ĉi tiujn ligojn redirektos vin al aparta dosiero sur aparta paĝo, kiu ne estas mia profilpaĝo de GitHub. Vi estos redirektita al la deponejo [seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), kie la README estas gastigita.

Tradukoj estas faritaj per Google Translate pro limigita aŭ neniu subteno por la lingvoj, kiujn mi bezonas en aliaj tradukaj servoj kiel DeepL kaj Bing Translate (sufiĉe ironia por kontraŭ-Google-kampanjo). Mi laboras por trovi alternativon. Ial la formatado (ligoj, dividiloj, grasa, kursiva ktp) estas fuŝita en diversaj tradukoj. Estas tede ripari, kaj mi ne scias kiel solvi ĉi tiujn problemojn en lingvoj kun nelatinaj signoj, kaj dekstre al maldekstraj lingvoj (kiel la araba) kroma helpo necesas por solvi ĉi tiujn problemojn.

Pro prizorgaj problemoj, multaj tradukoj malaktualas kaj uzas malnoviĝintan version de ĉi tiu artikoldosiero "README". Tradukisto bezonas. Ankaŭ ekde la 9-a de aprilo 2021 mi bezonos iom da tempo por funkciigi ĉiujn novajn ligojn.

***

## Indekso

[00.0 - Titolo] (# Degoogling --- Degoogle-your-life)

> [00.5 - Indekso] (# Indekso)

[01.0 - Baza priskribo] (# Baza-priskribo)

> [01.5 - Deponeja kaplinio] (# Degoogle-your-life)

[02.0 - Artikoloj] (# Artikoloj)

[03.0 - Privateco] (# Privateco)

[04.0 - Aliaj kontraŭ-Google-kampanjoj] (# Other-anti-Google-kampanjoj)

> [04.0.1 - Malfunkcia] (# Malfunkcia)

> [04.0.2 - Daŭranta] (# Daŭranta)

[05.0 - Rebati aliajn argumentojn] (# Rebati-aliajn-argumentojn)

> [05.0.1 - Oportuneco] (# Oportuneco)

> [05.0.2 - Kial ĝi gravas? Estas tro malfrue ĉiuokaze] (# Kial-gravas, -ĝi-tro-malfruas-ĉiuokaze)

> [05.0.3 - Aliaj] (# Aliaj)

[06.0 - Fontoj] (# Fontoj)

[07.0 - Elŝuti ligojn] (# Elŝuti-ligiloj)

[08.0 - Mia degoogling-sperto] (# My-degoogling-experience)

> [08.0.1 - De kio mi ŝanĝis] (# Kio-mi-ŝanĝis-de)

> [08.0.2 - Produktoj, de kiuj mi ankoraŭ ne povas foriri] (# Products-I-still-can't-get-away-from)

[09.0 - Aliaj kontrolendaj aferoj] (# Other-check-out)

[10.0 - Dosiera informo] (# Dosiera informo)

> [10.0.1 - Programara stato] (# Programara-stato)

[11.0 - Dosiera historio] (# Dosiera historio)

[12.0 - Piedo] (# Piedo)

***

## Baza priskribo

[El Vikipedio: Degoogle] (https://eo.wikipedia.org/wiki/DeGoogle)

La DeGoogle-movado (ankaŭ nomita la de-Google-movado) estas popola kampanjo, kiu aperis, ĉar privatecaj aktivuloj instigas uzantojn ĉesi uzi Google-produktojn tute pro kreskantaj privatecaj zorgoj pri la kompanio. La termino rilatas al la ago forigi Guglon el ies vivo. Ĉar la kreskanta merkatparto de la interreta giganto kreas monopolan potencon por la kompanio en ciferecaj spacoj, kreskantaj nombroj da ĵurnalistoj rimarkis la malfacilecon trovi alternativojn al la produktoj de la kompanio.

**Historio**

En 2013, John Koetsier de Venturebeat diris, ke la tablojdo Amazon-bazita Kindle Fire de Android estis "versio de Android de-Google-izita." En 2014 John Simpson de US News skribis pri la "rajto esti forgesita" de Google kaj aliaj serĉiloj. En 2015, Derek Scally de Irish Times skribis artikolon pri kiel "De-Google via vivo." En 2016 Kris Carlon de Android Authority sugestis, ke uzantoj de CyanogenMod 14 povus "malgajigi" siajn telefonojn, ĉar CyanogenMod bone funkcias ankaŭ sen Google-programoj. En 2018 Nick Lucchesi de Inverse skribis pri tio, kiel ProtonMail antaŭenigis kiel "povi tute malgajigi vian vivon." Brendan Hesse de Lifehaker skribis detalan lernilon pri "ĉesiGoogle. "Journalisturnalisto de Gizmodo Kashmir Hill asertas, ke ŝi maltrafis kunvenojn kaj havis malfacilaĵojn organizi renkontiĝojn sen la uzo de Google Calendar. En 2019, Huawei donis repagon al telefonaj posedantoj en Filipinoj, kiuj estis malhelpataj uzi servojn de Google ĉar tiel malmultaj alternativoj ekzistas, ke la foresto de la produktoj de la kompanio malebligis normalan interretan uzon.

***

# Degoogle-via-vivo
Deponejo por ĝeneralaj informoj pri degoogling kaj ligoj al miaj aliaj deponejoj pri degoogling.

***

## Artikoloj

### Artikola stato

_Ĉiuj artikoloj estas nuntempe prilaborataj kaj bezonas amasajn plibonigojn. Sugestoj kaj korektoj estas permesitaj._

[Kial vi devas ĉesi uzi Google Chrome] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Ĉesu uzi ChromeBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Ĉesu uzi WideVine DRM / Estas tempo tranĉi WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Kial vi devas ĉesi uzi ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Alternante de YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Ĉesu Google, kial vi devas ĉesi uzi Google-Serĉon] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[Kial vi devas ĉesi uzi Gmail] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Kial vi devas ĉesi uzi Android] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Kial vi evitu Google Amp] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Kial vi devas ĉesi uzi Google Drive] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Kial vi devas ĉesi uzi Google Maps kaj Google Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Hey Google, haltu] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Ĉesu legi el Google / Play-libroj] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Ĉesu uzi Google Classroom] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Kial vi devas ĉesi uzi Google Translate] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Kial vi devas ĉesi uzi viajn Google-kontojn] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Accounts) <! - 16! ->

** Novaj artikoloj baldaŭ skribotaj: **

[Kial vi devas ĉesi uzi Gerrit] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Kial vi devas ĉesi uzi Google Analytics (la deponejo estas rompita ĉe mia fino merkrede la 24an de februaro 2021 je la 16:13)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics) <! - 18! ->

<! - Laborpartigilo! ->

[Kial vi devas ĉesi uzi Google AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Kial vi devas ĉesi uzi Google One] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Kial vi devas ĉesi uzi Google+ (malfunkcia)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Kial vi devas ĉesi uzi la Google Play Store] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Kial vi devas ĉesi uzi Google-Dokumentojn] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Kial vi devas ĉesi uzi Google-Bildojn] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Kial vi devas ĉesi uzi Google Sheets] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Kial vi devas ĉesi uzi Google Forms] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Kial vi devas ĉesi uzi Google Cardboard] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Kial vi devas ĉesi uzi Google Messages] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Kial vi devas ĉesi uzi Google Material Design] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Kial vi devas ĉesi uzi Google Glass / Glasses] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Kial vi devas ĉesi uzi Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Kial vi devas ĉesi uzi GBoard] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Kial vi devas ĉesi uzi Google-Hejmon] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Kial vi devas ĉesi uzi Google Nest] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Whvi devas ĉesi uzi Google Hangouts (malfunkcia)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Kial vi devas ĉesi uzi Google Duo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Kial vi devas ĉesi uzi Google Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Kial vi devas ĉesi uzi Google Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Kial vi devas ĉesi uzi Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Kial vi devas ĉesi uzi programlingvon Googles Go] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Kial vi devas ĉesi uzi programlingvon Googles Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Kial vi devas ĉesi uzi Googles-WebP-bildan formaton] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Kial vi devas ĉesi uzi video-formaton de Googles WebM] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Kial vi devas ĉesi uzi Google Video] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Kial vi devas ĉesi uzi Google Sites (klasika)] ​​(https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Kial vi devas ĉesi uzi Google Sites ("Nova")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Kial vi devas ĉesi uzi Google Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Kial vi devas ĉesi uzi Android Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Kial vi devas ĉesi uzi Google VPN (oksimoro)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Kial vi devas ĉesi uzi Google-Fotojn] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[Kial vi devas ĉesi uzi Google Calendar] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Kial vi devas ĉesi uzi VirusTotal (ĉar ĝi estas posedata de Google ekde septembro 2012) (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Kial vi devas ĉesi uzi Google Fi] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi) <! - 53! ->

[Kial vi devas ĉesi uzi Google Stadia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Kial vi devas ĉesi uzi Google Keep] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Kial vi devas ĉesi uzi Google Base] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Kial vi devas ĉesi partopreni en la Gugla Somero de Kodo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Kial vi devas ĉesi uzi Google-Fotilon] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Kial vi devas ĉesi uzi Google-Kalkulilon (povas ŝajni ekstrema, sed vi devas forigi Google de ĉio, tre facile alternebla)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Kalkulilo) <! - 59! ->

[Kial vi devas ĉesi uzi rekompencojn de Google Survey +] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Kial vi devas ĉesi uzi Guglajn Desegnojn] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Kial vi devas ĉesi uzi Tenor (GIF-retejo, posedata de Google ekde 2019)] (Https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

** Artikolo [vojmapo AB] (DegoogleCampaign_2021Roadmap_Part1.md) (ĝis la 12a de marto 2021) 2 liberaj tagoj **

** Artikolo [vojmapo BB] (DegoogleCampaign_2021Roadmao_Part2.md) (ĝis? 2021) 2 liberaj tagoj **

Artikola statuso

Ĉiuj artikoloj estas nuntempe prilaborataj kaj bezonas amasajn plibonigojn. Sugestoj kaj korektoj estas permesitaj.

** Forkoj **

Vastigante mian reton Degoogle, kaj aldonante iom da aliro kaj komunumajn kriojn.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Forkita de: [https://github.com/wacko1805/Fossapps](https://github.com/wacko1805/Fossapps) (angla)

2. [Privateco-ligoj] (https://github.com/Degoogle-your-life/Privacy-links) | Forkita de: [https://github.com/Arturro43/privacy-links](https://github.com/Arturro43/privacy-links) (pola)

3. [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Forkita de: [https://github.com/LinuxCafeFederation/Delightful-Privacy](https://github.com/LinuxCafeFederation/Delightful-Privacy) (angla)

4. [Bloklistoj] (https://github.com/Degoogle-your-life/blocklists) | Forkita de: [https://github.com/jmdugan/blocklists](https://github.com/jmdugan/blocklists) (angla)

** Rilata **

[Esplorado pri virtuala maŝino de Android-telefono Degoogled] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Vidu ankaŭ:**

[Kritiko de Google ĉe Vikipedio] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[La Google-Tombejo (killedbygoogle.com) - ordigita listo de la 224+ produktoj, kiujn Google mortigis] (https://killedbygoogle.com/)

> [GitHub-ligo] (https://github.com/codyogden/killedbygoogle)

[Sindikato de Alfabeta Laboristo - La nova laborista sindikato ĉe Google kun pli ol 800 membroj] (https://alphabetworkersunion.org/people/our-union/)

[Ĉu vi ne volas disiĝi de la dinosaŭra paska ovo? Ĉi tiu retejo kovris vin] (https://chromedino.com/)

***

## Privateco

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-google-havas-ĉe-vi-privateco) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritiko) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- datumoj-pri-vi-povas-trovi-kaj-forigi-ĝin-nun /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -kaj) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o[(https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- asertoj-je-nomo-de-5-milionoj-iphone-uzantoj) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-ne-uzu /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technolo gy / 2014/01 / what-google-can-really-do-with-nest-or-really-nest-data /) [i] (https://www.cbsnews.com/news/google-education-spies -on-kolektas-datumojn-pri-milionoj-da-infanoj-akuzoj-proceso-nova-meksika-ĝenerala-prokuroro /) [v] (https://www.nationalreview.com/2018/04/the-student- datumminado-skanadodal-under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/ 2019/09/04 / technology / google-youtube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to -hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Mi povus daŭrigi kun pruvoj pri tio, sed necesis longe trovi kaj trarigardi ĉiujn ĉi artikolojn)

Privateco pri Google-produktoj estas ĉiam malbona, pro ĉiuj Google-produktoj enhavantaj spionajn programojn.

Ne gravas, kion vi faras, kiam vi uzas Google, ĉiuj viaj sentemaj personaj datumoj estas senditaj al Google kaj aliaj. Guglo ankaŭ ekvidiĝis tra malfermitaj programoj. Ekzemple, laŭ persona sperto (ĉe Fajrovulpo) kun malfermita jutuba langeto, kiun mi ne vizitis, mi spektis plurajn filmetojn senrete (VLC Media Player) Poste kiam mi iris por kontroli la rekomendojn, ĝi estis preskaŭ ĉio, kion mi spektis. Sendube ili spionas ankaŭ aliajn programojn.

En Chrome (kaj multaj aliaj retumiloj) inkognita reĝimo ĉeestas. En Chrome, ĉi tiu reĝimo estas sencela, ĉar Google ankoraŭ minigos viajn datumojn. Eĉ se vi malŝaltas datumminadon / spuradon kaj ebligas la signalon "ne spuri", surprize surprize, Google ankoraŭ minas viajn datumojn.

Se vi pensas, ke vi havas nenion por kaŝi, ** vi absolute malpravas **. Ĉi tiu argumento estis malkaŝita multajn fojojn:

[Per Vikipedio] (https://eo.wikipedia.org/wiki/Nenio_por_kaŝi_argumenton # Kritiko)

1. Edward Snowden rimarkis "Argumenti, ke vi ne zorgas pri la rajto al privateco ĉar vi havas nenion por kaŝi, ne diferencas ol diri, ke vi ne zorgas pri libera parolado, ĉar vi havas nenion por diri." Kiam vi diras, ' Mi havas nenion por kaŝi, 'vi diras,' mi ne zorgas pri ĉi tiu rajto. 'Vi diras,' Mi ne havas ĉi tiun rajton, ĉar mi alvenis al la punkto, kiam mi devas pravigi. ĝi. 'La rajtoj funkcias, la registaro devas pravigi sian entrudiĝon en viajn rajtojn. "

2. Daniel J. Solove diris en artikolo por La Kroniko de Supera Edukado, ke li kontraŭas la argumenton; li deklaris, ke registaro povas liki informojn pri persono kaj kaŭzi damaĝon al tiu persono, aŭ uzi informojn pri persono por nei aliron al servoj eĉ se persono ne efektive faris malbonfaradon, kaj ke registaro povas kaŭzi damaĝon al sia propra vivo per farado de eraroj. Solove skribis "Kiam ĝi okupiĝas rekte, la nenio-kaŝebla argumento povas kapti, ĉar ĝi devigas la debaton fokusiĝi al sia mallarĝa kompreno pri privateco. Sed kiam ĝi alfrontas la plurecon de privatecaj problemoj implikitaj de registara datumkolekto kaj uzo preter kontrolado kaj malkaŝo, la nenion kaŝebla argumento, finfine, havas nenion por diri. "

3. Adam D. Moore, aŭtoro de Privatecaj Rajtoj: Moralaj kaj Juraj Fundamentoj, argumentis, "estas la opinio, ke rajtoj rezistas al kosto / avantaĝo aŭ konsekvencaj argumentoj. Ĉi tie ni malakceptas la opinion, ke privatecaj interesoj estas tiaj. de aferoj interŝanĝeblaj por sekureco. " Li ankaŭ deklaris, ke gvatado povas misproporcie influi iujn grupojn en la socio laŭ aspekto, etneco, sekseco kaj religio.

4. Bruce Schneier, komputila sekureca spertulo kaj kriptografisto, esprimis opozicion, citante la deklaron de kardinalo Richelieu "Se oni donus al mi ses liniojn skribitajn per la mano de la plej honesta viro, mi trovus ion en ili por pendigi lin", aludante al kiel ŝtata registaro povas trovi aspektojn en la vivo de homo por procesigi aŭ ĉantaĝi tiun individuon. Schneier ankaŭ argumentis "Tro multaj erare karakterizas la debaton kiel" sekureco kontraŭ privateco. " La vera elekto estas libereco kontraŭ rego. "

5. Harvey A. Silverglate taksis, ke la ordinara homo averaĝe senscie faras tri krimojn ĉiutage en Usono.

6. Emilio Mordini, filozofo kaj psikanalizisto, argumentis, ke la argumento pri "nenio kaŝebla" estas esence paradoksa. Homoj ne bezonas havi "ion por kaŝi" por kaŝi "ion". Kio estas kaŝita ne nepre gravas, asertas Mordini. Anstataŭe li argumentas ke intima areo, kiu povas esti kaŝita kaj alirebla, estas necesa, ĉar psikologie parolante ni fariĝas individuoj per la malkovro, ke ni povus kaŝi ion al aliaj.

7. Julian Assange diris "Ankoraŭ ne ekzistas mortiga respondo. Jacob Appelbaum (@ioerror) havas lertan respondon, petante homojn, kiuj diras ĉi tion, ke ili transdonu al li sian telefonon malŝlositan kaj mallevu sian pantalonon. Mia versio de tio estas, 'nu, se vi tiel enuigas, ni ne parolu kun vi, kaj ankaŭ neniu alia', sed filozofie, la vera respondo estas jena: Amasa gvatado estas amasa struktura ŝanĝo. Kiam la socio malbonas, ĝi iras. kunporti vin, eĉ se vi estas la plej banala homo sur la tero. "

8. Ignacio Cofone, jura profesoro, argumentas, ke la argumento eraras laŭ siaj propraj terminoj ĉar, kiam homoj malkaŝas koncernajn informojn al aliaj, ili ankaŭ destas proksime senrilataj informoj. Ĉi tiuj senrilataj informoj havas privatajn kostojn kaj povas kaŭzi aliajn malutilojn, kiel diskriminacio.

***

## Aliaj kontraŭ-Google-kampanjoj

Jen listo de aliaj rimarkindaj kontraŭ-Google-kampanjoj. Ĉi tiu listo estas nekompleta. Vi povas helpi vastigante ĝin.

### Malaperinta

[Scroogled - De Microsoft (novembro 2012 ĝis 2014)] (https://en.wikipedia.org/wiki/Scroogled)

_Neniu alia eniro nuntempe._

### Daŭranta

_Ĉi tiu listo estas nuntempe malplena._

***

## Kontraŭstari aliajn argumentojn

Estas iuj argumentoj, kiujn homoj faras por pravigi Guglon. Unu el la unuaj gravaj jam estas malkaŝita [ĉi tie] (# Privateco) sed jen iuj aliaj:

### Oportuno

Jes, Google-produktoj ŝajnas konvenaj. Tamen vi komercas ĉion bonan por facileco, inkluzive sekurecon, privatecon kaj fidindecon. Guglo fariĝis pli pigra dum la jaroj, kaj iliaj serviloj malpliiĝis pli kaj pli. Ĝuste nun, la Google-serviloj falas preskaŭ unu horon 1-2 fojojn monate (precipe YouTube)

Bedaŭrinde, pro la dependeco de societoj al Google, Google regis la interreton kaj klopodas regi pli kaj pli. En 2012, kiam Google malaltiĝis dum 5 minutoj, oni raportis, ke ** tutmonda ** Interreta trafiko ** malpliiĝis je 40% ** Google ofte malaltiĝas dum 1-2 horoj, kaj kun la [maldungado de ilia etika teamo] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) interalie ili fariĝos malpli kaj pli konvenaj.

Komforto ne ĉiam estas bona afero. Vi devas esti konscia pri tio, kio okazas kaj esti preta por kiam ili falos, ĉar ne ekzistas maniero, ke servilo ne malaltiĝu de tempo al tempo.

Google ankaŭ ne estas tiel oportuna kiel vi pensas. Estas aliaj multe pli oportunaj retejoj. Google estas malproksime de oportuna, kiam vi kalkulas iliajn hazardajn kontajn ĉesigojn kaj ĉesigojn sen respondo (krom se vi atentigas sufiĉe pri la konto de Google en twitter aŭ demandas ilin kontraŭ $ 100,000,000 aŭ pli) tiam ili ekspluatis vin, frapis vin kaj devigis vin krii en kusenon, kie neniu povis aŭdi viajn kriojn por helpo.

### Kial gravas, estas tro malfrue ĉiuokaze

Ĉi tio estas malpli ofta argumento, sed ĝi bezonas klarigon. Kun la nuna ŝtato, plej multaj mondaj registaroj, kune kun pluraj potencaj kompanioj, ŝajnas koni vian movon, do kial eĉ ĝeni foriri de ĝi? La respondo estas simpla: ** vi meritas pli bonan **. Se vi sukcesas foriri de ili ĉe ĉi tiu punkto, estas pli malfacile por ili spuri viajn movojn plu, kaj vi povas konstrui novan pli privatan vivon.

[1 fonto] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Cetere, mi donas mian senpagan Reddit-premion al ĉi tiu afiŝo ĉiun fojon, kiam mi ricevas ĝin dum pli ol semajno nun (kune kun ĉiuj 500 miaj senpagaj moneroj) por pliigi ĉi tiun temon. Ĝis nun mi donis ĉi tiun afiŝon pli ol 14 senpagajn premiojn. Ne multe, sed malgrandaj aferoj povas efiki, depende de kiel ĝi estas perceptata, kaj de kiu.

### Alia

Mi ne havas aliajn argumentojn nuntempe.

_Ĉi tiu listo estas nekompleta_

***

## Fontoj

Kopiu:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-google-havas-ĉe-vi-privateco) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritiko) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- datumoj-pri-vi-povas-trovi-kaj-forigi-ĝin-nun /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -persona-datumo-n870501) [e] (https: // www.eff.org / deeplinks / 2020/03 / google-diras-ĝi-ne-vendas-viajn-datumojn-jen-kiel-kompanioj-dividas-monetizas-kaj) [c] (https://www.wired.com /story/google-tracks-you-privacy/)[o[(https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you- privateco) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html) [d] (https: //www.reuters. com / article / us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https: // www .pcmag.com / news / google-sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https://www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google- ios-apple /) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c ] (https: //www.cnn. com / 2019/11/12 / business / google-project-nightingale-ascension / index.html) [o] (https://en.wikipedia.org/wiki/2018_Google_data_breach) [m] (https: // moz. com / blog / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https : //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https: //www.nytimes. com / 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over- datumoj-asertoj-je-nomo-de-5-milionoj-iphone-uzantoj) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https : //www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when -via-telefono-ne-uzas /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about- vi.html) [p] (https://topclassactions.co m / lawsuit-règlements / privacy / google-says-class-action-lawsuit-plaintiffs-consentent-to-data-collection /) [r] (https://arstechnica.com/information-technology/2014/01/what -google-povas-vere-fari-kun-nesto-aŭ-vere-nest-datumoj /) [i] (https://www.cbsnews.com/news/google-education-spies-on-collects-data- pri-milionoj-da-infanoj-akuzoj-proceso-nova-meksika-prokuroro-ĝenerala /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal-under -niaj-nazoj /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019/09 /04/technology/google-youtube-fine-ftc.html)[y)(https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide- 40689565c550) [.] (Https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Aliaj fontoj:

[Kvin okuloj Alianco] (https://eo.wikipedia.org/wiki/Kvin_okuloj) [Dek naŭ okdek kvar] (https://eo.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Elŝuti ligojn

[Akiru Fajrovulpon] (https://www.mozilla.org/en-US/firefox/new/) [Akiru retumilon] (https://www.torproject.org/download/) [Alia / neatingebla] (https : //www.ekzemplo.com)

***

## Mia degooglinga sperto

Mi finfine ekvidis la problemojn kun granda te techniko en 2018, kaj mi komencis malplenumi. En la unuaj monatoj, mi multe progresis. Ĝi ege malrapidiĝis ekde tiam.


### De kio mi ŝanĝis

Google Chrome -> Firefox / Tor

Gugla Serĉo -> DuckDuckGo (defaŭlte) / Ecosia (kiam mi emas) / Bing (malofte)

GMail - ProtonMail (ankoraŭ ne tute ŝanĝita)

Google Sites -> Memgastigado (ankoraŭ ne tute ŝanĝita)

Google+ -> Apenaŭ iam uzata, forigis sin pro sia propra ĉesigo

Google-Dokumentoj -> Neniam uzata, mi nur uzas Microsoft Word 2013 (antaŭ 2019) kaj LibreOffice (2019-plu).

Google Sheets -> Neniam uzata, mi nur uzas Microsoft Excel 2013 (antaŭ 2019) kaj LibreOffice (2019-plu).

Google-Bildoj -> Neniam uzata, mi simple uzas Microsoft PowerPoint 2013 (antaŭ 2019) kaj LibreOffice (2019-plu).

Guglo-Desegnoj -> Neniam uzata, mi simple uzas LibreOffice (2019-plu).

Gerrit -> Neniam uzata, mi simple uzas GitHub (aktuala defaŭlta), GitLab, BitBucket kaj SourceForge anstataŭe.

Google Photos -> Neniam uzata

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-nuna)

Google Maps -> OpenStreetMaps / Apple Maps

Iru - Fari specialan escepton, sed ne uzi kiel funkcian programlingvon

Sageto - Fari specialan escepton, sed ne uzi kiel funkcian programlingvon

Flutter - Fari specialan escepton, sed ne uzi kiel funkcian programlingvon

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> Neniam uzata, mi trovas ĝin tre timiga

Google Fi -> Neniam uzata

Google Calendar -> Neniam uzata

Google-kalkulilo -> Laŭvorte iu ajn alia kalkulila programo, eĉ Linuksa terminalo funkcianta en Python-reĝimo se mi emas

Google Nest -> Neniam uzata

Google AMP -> Neniam uzata

Google VPN -> Neniam uzata, ankaŭ oksimoro

Google Pay -> Neniam uzata

Gugla Somero de Moruoe -> Neniam partoprenis

Tenoro -> Aliaj GIF-retejoj, kvankam GIF ne tro gravas por mi. Mi kutime ricevas GIF-dosierojn de DuckDuckGo-bildoj, Imgur, Reddit aŭ aliaj retejoj.

Bloke -> Ne plu uzata, ne certas, ĉu Scratch rekte funkciis bloke. Mi fariĝis funkcia programisto en 2017 pluen, kaj elkreskis el Scratch.

GBoard -> Uzata unufoje, sed forlasita

Google Glass -> Neniam uzata, konsiderata kiel juna infano sed decidis ne akiri unu / uzi unu se mi havus la eblon

_Listo povas esti nekompleta._

### Produktoj de kiuj mi ankoraŭ ne povas foriri

Ekde la 25a de februaro 2021, ĉi tiuj estas la produktoj de Google, kiuj malhelpas min tute malŝalti:

1. YouTube

2. Android

3. Google Play Store

4. GMail (nur por lernejo kaj iuj retejoj)

5. Google Classroom (nur por lernejo)

6. Google Translate

7. Gugla Konto

8. Google Sites (ĉar Google malobservas la leĝojn de la GDPR (kaj povas alfronti plian monpunon de 5.000.000,00 € ĝis ili riparos ĝin) kaj malpermesas elŝutojn de ĉi tiu produkto)

Mi foriris de ĉio alia.

***

## Iru estas malbona

Google ekfunkciigis la programlingvon "Go!" De 2003 kun ilia programlingvo "Go" (de 2009, 6 jarojn poste) kaj asertis, ke ilia lingvo tute ne influos la alian lingvon. Guglo estis forte kritikita pro tio, ĉar ilia moto "Ne estu malbona" ​​ankoraŭ estis aktiva tiutempe, kaj ĉi tiu estas unu el la multaj okazaĵoj, kiuj malpermesis al la malbona Moto.

En la fino, disvolviĝo de "Iru!" Ĉesis, dum "Iru" fariĝis pli kaj pli ofta. Google asertis, ke ili ne trarigardos "Iru!", Sed finfine ili faris, kaj ili sukcesis (kun la 9-a de aprilo 2021)

[Legu pli pri Go kaj kiel alterni ĉi tie] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Uzado de DRM

Google uzas DRM (Digital Restrictions Management) per sia WideVine DRM "servo" kaj aliaj formoj. La celo de DRM estas detrui la malferman Interreton kaj doni al kompanioj monopolan potencon super uzantoj. Vi devas forigi WideVine tute, negrave la kosto.

[Legu pli pri WideVine kaj ĝiaj problemoj ĉi tie] (https://github.com/Degoogle-your-life/Its-time-to-cut-WideVine-DRM)

***

## Oftaj miskomprenoj

Jen listo de iuj oftaj miskomprenoj pri Google-produktoj.

### Google ne estas interreto

Gugla / Gugla serĉado ne estas interreto, Gugla serĉado estas nur serĉilo, kiel ĉiu ludo por Nintendo-platformo ne estas farita de Nintendo, sed estas licencita de Nintendo, sed laŭ multe pli granda mezuro. Se ĉiuj Googles-serviloj estus samtempe detruitaj nun, nur Google-ejoj kiel YouTube, Gmail, Google-Dokumentoj, Google-serĉado, ktp forestus, sed la plimulto de la interreto ankoraŭ estus tie (Vikipedio, Stackoverflow, GitHub, ĉiuj retejoj de Microsofts, NYTimes, Samsung, TikTok, ktp.) ili eble perdos sian ensalutan kaj analizan funkcion de Google, sed ili tamen funkcius (krom se ili estus malbone programitaj kaj dependus rekte de Google)

***

## Interreta Esploristo 6 kaj Chrome

Google Chrome fariĝas la nova Interreta Esploristo 6. Kiam Google Chrome origine aperis, Fajrovulpo estis la reganta retumilo, kaj plejparte mortigis Interretajn Esploristojn (kiu superis 96% antaŭ ol milionoj da homoj transiris al Fajrovulpo kaj aliaj retumiloj) kiam Google Chrome aperis, homoj ŝanĝis pro ĝia rapideco kaj ĝi estis de Google (kiu tiam ne estis konsiderata kiel malbona, ĉar plej multaj privatecaj problemoj ankoraŭ ne aperis) Google Chrome origine respektis interretajn normojn (kio faris Firefox tio senvivigis Interretajn Esploristojn 96% retumila merkatparto) tamen, dum la merkatparto de Google Chromes kreskis, Google komencis forigi pli kaj pli da funkcioj, aldoni pli da spionaj programoj, kaj ĉesis akcepti interretajn normojn, Google Chrome fariĝis la nova Interreta Esploristo 6.

La ĉefa problemo nun estas retejoj, kiuj estas nur Chrome, kaj ne funkcios en aliaj retumiloj, ĉar iliaj programistoj decidis, ke ili ne volas, ke la aliaj 30-40% de interretaj uzantoj, kiuj ne uzas Chrome, uzu sian retejon.

Eĉ Google mem faras siajn retejojn nur Chrome. Ekzemple, Google-serĉo instigos vin elŝuti Chrome 3 fojojn ĉiun 10 sekundojn, se ĝi detektas, ke vi ne uzas Google Chrome (eĉ aliaj Chromium-bazitaj retumiloj kiel Brave estas trafitaj) kaj retejoj kiel Google Earth ne permesas al Firefox-uzantoj uzu ilian retejon (ĝis 2020) plus Google Translate ne subtenas voĉan enigon en Fajrovulpo kaj aliaj ne-Google Chrome-retumiloj.

### La problemo kun Brave

Aliaj retumiloj bazitaj sur Chromium, kiel Brave kaj Microsoft Edge ne estas tute liberaj de spionaj programoj de Google. Kuraĝa estas ofte rekomendata de la malĝusta flanko de la privateca komunumo, sed Kuraĝa estas ankoraŭ problemo, ĉar ĝi uzas Chromium. La interreto ne konsistu nur el retumiloj de Chromium, devas esti diversa elekto. Kuraĝa estas la malĝusta vojo.

[Legu pli pri degoogling de Google Chrome / Chromium ĉi tie] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Legu pli pri liberigado de ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) ĉi tie] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Falsa privateca renovigo

Google provis diri al la mondo, ke ili zorgas pri privateco, post kiam estis jam tro malfrue. Ili daŭre asertas, ke ili respektas la privatecon de uzanto, sed ili ankoraŭ ne riparas ĉiujn siajn privatajn problemojn.

### Malferma fonto ne povas esti parta

Malferma fonto ne povas esti parta. Google estas pruvo pri tio. Ĉiu bito kaj bajto de la fontkodo devas esti videbla al la publiko, kun eĉ ne okono de bajto kaŝita.

Projektoj kiel Android kaj ChromeOS estas parte malfermfontaj, sed enhavas plimulton de proprietaj spionaj elementoj.

### Oxymoron

Google VPN estas oksimoro. Google ne zorgas pri privateco, kaj Virtuala Privata Reto (VPN) de kompanio kiel ili estus unu el la plej malbonaj ebloj por VPN-servo.

***

## Malbona agado

Google ne zorgas pri la agado de iliaj produktoj almenaŭ 2017, ĉar ilia lasta komparnorma programaro (Google Octane) ĉesis en 2017.

***

## Malbona projekt-administrado

Google havas tre malbonan internan administradan sistemon. Iuj oftaj ekzemploj de programoj, kiuj pli kaj pli malaltiĝis, inkluzivas Google Duo kaj YouTube-muzikon (antaŭe Google Play Music)

En la sistemo de interna disvolviĝo de Google, 1 programo kondukas al alia programo kun duono de la funkcio, tiam la originala programo forviŝiĝas. Post kelkaj jaroj, nova programo kun 75% malpli da funkcieco estas kreita, kaj tiam la programo kun 50% -funkcieco estas forigita, sekvita per nova programo kun 87,5% de la funkcieco kreita, tiam la programo kun 75% -funkcieco ĉesigas. , kaj tiel plu.

***

## Terura aŭ neniu modereco de servoj

YouTube estas la plej ofta ekzemplo en la mondo de malbona modereco kreante la plej malbonan platformon ekzistantan. Ankaŭ Google ne ŝajnas atingi, ke YouTube ne estas YouTube-infanoj.

Por YouTube, malaminda por-nazia kaj Blanka Supremacisma enhavo servas al uzantoj cele al pli da engaĝiĝa tempo kaj pli da mono. Google ankaŭ faris tre stultajn aferojn per sia modereco, kiel ekzemple aprobi kristanan Anal Sex Sex-filmon kiel enhavon "kreitan por infanoj" dum samtempe aĝo limigas la filmeton. Ankaŭ ne tro maloftas vidi pornografiajn aŭ anoncajn reklamojn rekte sub la filmeto Beba Ŝarko, kune kun diversaj aliaj enhavoj por infanoj.

YouTube-uzantoj plendas ekstreme ofte pri la malbona modereco en YouTube pro malbona enhavo (kiel la supre listigitaj ekzemploj) dum uzantoj povas forigi siajn filmetojn hazarde sen kialo sen nuligo, kune kun uzantoj punataj pro ia ĵuro, eĉ tre etaj kazoj kiel diri "aĉaj" uzantoj ofte komparas YouTube kun [Sovetunio] (https://en.wikipedia.org/wiki/Soviet_Union) en la stalina epoko, pro ĉi tiuj neegalaj punoj.

En 2021, Google anoncis, ke ili metos anoncojn en ĉiujn filmetojn, malgraŭ ke la video estas demonigita (tiel ke Google gajnas monon, sed la kreinto ne faras), ĉi tio ne rilatas al modereco tro multe, sed gravas noti.

YouTube estas moderigita (kvankam tre malbone) sed la anonca servo de Google, kiu donas al ili la plej grandan parton de sia mono, ŝajnas havi malmultan aŭ nenian moderecon.

[Legu pli pri YouTube-moderaj problemoj kaj kiel alterni de YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Reklamoj por Google Play estas generitaj de bot-farm-obienoj, vi povas scii per la samaj reklamaj scenaroj uzataj de centoj da kompanioj kun malmultaj ŝanĝoj kaj sen rilato al la produkto (oftaj ekzemploj: Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City, miloj pli) kune kun kreskanta malica tendenco de anoncoj asertantaj, ke uzantoj povas gajni monon ludante ludojn, aŭskultante muzikon, ktp. PayPal ne komentis tion, sed estas evidente, ke temas pri trompo, kvazaŭ vi povus fari pli ol $ 10,000 en malpli ol 20 sekundoj ludante ludon garantiita, neniu farus laboron kaj farus tion anstataŭe, kio estas neebla, kaj kompanio ne povus funkcii tiel. Ĉi tiu evidenta trompo kreskas forta ekde 2019, kaj nun la bot-bienoj, kiuj produktas ĉi tiujn reklamojn, batalas inter si en siaj propraj reklamoj.

Pluraj reklamoj ankaŭ estas tre malĉastaj, kaj provas igi uzantojn (plimulto el ili uzantoj sub la aĝo de 13 aŭ bots) klaki per seksa manipulado.

Multaj programoj uzas robotojn kaj astroturfas siajn produktojn, do kiam ajn malbona recenzo estas farita, ŝtrumpetaj marionetoj-bot-kontoj komencos afiŝi 5-stelajn recenzojn kaj provos nei vian kritikon. [Google ankaŭ faras tion mem] (# Astroturfing)

[Legu pli pri problemoj kun Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfado

Ĝenerala difino [(de Vikipedio)] (https://eo.wikipedia.org/wiki/Astroturfing)

""
Astroturfado estas la praktiko maski la sponsorojn de mesaĝo aŭ organizo (ekz. Politika,reklamado, religiaj aŭ publikaj rilatoj) por aperigi ĝin kvazaŭ ĝi devenas de kaj estas subtenata de popolaj partoprenantoj. Ĝi estas praktiko destinita doni kredindecon al la deklaroj aŭ organizoj retenante informojn pri la financa ligo de la fonto. La termino astroturfing devenas de AstroTurf, marko de sinteza tapiŝado dizajnita por simili naturan herbon, kiel teatraĵo pri la vorto "popola". La implico malantaŭ la uzo de la termino estas, ke anstataŭ "vera" aŭ "natura" popola penado malantaŭ la koncerna agado, ekzistas "falsa" aŭ "artefarita" apero de subteno.
""

Google havas historion de astroturfado por ŝajni, ke ili faras nenion malbonan (dum la procezo, astroturfado estas malbona) ekzemple, afiŝi kritikojn pri Google en platformo kiel Twitter (sur kiu ili havas konton) rezultigos pluraj kontoj, kiuj ekzistas dum iom da tempo, sed neniam afiŝis antaŭ ol aperi kaj aserti, ke tio, kion vi diris, estas falsa, kaj poste aserti, ke Google estas la plej bona kompanio, sed farita tiel, ke eble ne evidente, ke ĉi tiuj estas robotoj por la plej multaj homoj.

***

## Kontraŭleĝaj kaj maletikaj komercaj praktikoj

Google uzas kontraŭleĝajn kaj maletikajn komercajn praktikojn por antaŭenigi ilian monopolon, kiel uzi impostajn rifuĝejojn, subkontrakti laborpostenojn kaj daŭre fari kontraŭleĝajn invadajn agadojn kiel koston de komercado.

### En Eŭropo

Eŭropo ofte jurpersekutis Google, la plej granda proceso estis kontraŭ kontraŭleĝa konduto en Android, kio rezultigis Google ricevi 5.000.000.000 € (ekvivalenta al 5.947.083.703,68 USD en la 9a de aprilo 2021 mono)

### En Nordameriko

Usono ankoraŭ ne donis sufiĉe sufiĉan monpunon al Google, kompare kun eŭropa monpuno de 5.000.000.000 €.

### Diskutadoj

Google ne zorgas pri problemo ĝis ĝi kreos diskutadon, tiam ili faros malbonan provon solvi ĝin, nur sufiĉe por ke la diskutado portempe foriru, kaj la problemo tiam eksponente plimalboniĝas ĝis ĝi kreos alian diskutadon, kaj la ciklo daŭras. Ili simple ne sufiĉe zorgas fari ion seriozan pri ĝi.

***

## Google estas aŭtomatigita

Kiel kompanio, Google estas plejparte aŭtomatigita, kun malpli da modereco ol aŭtomatigo.

Kompanio ne estu plene aŭtomatigita. Google estas ekzemplo de tio. Modereco estas terura kiam farita nur de AI, YouTube estas bona ekzemplo, eĉ kun la malmultaj (centoj, aŭ eble mil) homoj moderantaj la retejon, kie ĝi ŝajne estas tiel malbona, ke la plej multaj el ili devas ricevi terapion laborante.

***

## Android

Android estas posedata de Google. Parto de la Malferma Komputila Alianco (kiu ne malfermiĝis ekde Android) Android fariĝis alia monopolo por Google, kaj tre malfacile eskapebla.

Oni raportis, ke Android telefonas hejmen al Google almenaŭ 10 fojojn tage, kaj malgraŭ esti parte malferma fonto, ĝi tamen multe funkcias kiel spiona programaro.

Pluraj projektoj kreiĝis por alterni de Android, sed postulas enradikiĝi vian aparaton. Ĉi tio simple ne plu eblas por specifaj Samsung-telefonoj en Usono, pro la Knox DRM. Oftaj anstataŭantoj al Android inkluzivas iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch kaj PiPhone (Pi Phone estas marko de telefonoj, kiuj funkcias diversajn Linuksajn sistemojn per poŝtelefono, kiel Fedora, Ubuntu, Arch, ktp.)

[Vidu mian esploron pri funkciado de degoogled-Android-virtuala maŝino] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Vidu kiel degoogle de Android] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Malgrandaj agoj por helpi

Disvastigi konscion ĉiumaniere gravas. Por mi, mi ne nur ofte parolas pri degoogling, kaj verkas artikolojn, sed mi ankaŭ havas malgrandan kutimon, kie mi donas mian ĉiutagan senpagan Reddit-premion al la alpinglita afiŝo ĉe r / degoogle por konsciigi. Ĝis nun mi donis preskaŭ 30 premiojn al la alpinglita poŝto (mi ankaŭ elspezis 500 el miaj senpagaj moneroj por 10 premioj por tiu poŝto)

***

## Nefidinda

Guglo ne povas esti fidinda kaj neniam plu fidinda. Ili tute iris de "ne estu malbonaj" (ili ĉiam estis malbonaj) al nur esti tute malbonaj kaj ne provantaj kaŝi ĝin.

***

## Aliaj aĵoj por kontroli

[La Google-Tombejo (killedbygoogle.com) - ordigita listo de la 224+ produktoj, kiujn Google mortigis] (https://killedbygoogle.com/)

> [GitHub-ligo] (https://github.com/codyogden/killedbygoogle)

[Sindikato de Alfabeta Laboristo - La nova laborista sindikato ĉe Google kun pli ol 800 membroj] (https://alphabetworkersunion.org/people/our-union/)

[Ĉu vi ne volas disiĝi de la dinosaŭra paska ovo? Ĉi tiu retejo kovris vin] (https://chromedino.com/)

Estas aliaj anstataŭantoj, nur serĉu ilin.

***

Iu fakta kontrolado necesas por ĉi tiu artikolo

***

## Dosiera informo

Dosiera tipo: `Markdown (* .md)`

Linia kalkulo (inkluzive malplenajn liniojn kaj kompililan linion): `895`

Dosiera versio: `5 (vendredo, 9 aprilo 2021 je 18:02)`

***

### Programara stato

Ĉiuj miaj verkoj estas senpagaj iuj limigoj. DRM (** D ** igital ** R** limigoj ** M ** administrado) ne ĉeestas en iuj miaj verkoj.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ĉi tiu glumarko estas subtenata de la Free Software Foundation. Mi neniam intencas inkluzivi DRM en miaj verkoj.

Mi uzas la mallongigon "Administrado de Ciferecaj Limigoj" anstataŭ la pli konata "Administrado de Ciferecaj Rajtoj", ĉar la komuna maniero trakti ĝin estas falsa, ne ekzistas rajtoj kun DRM. La literumo "Administrado de Ciferecaj Limigoj" estas pli preciza, kaj estas subtenata de [Richard M. Stallman (RMS)] (https://eo.wikipedia.org/wiki/Richard_Stallman) kaj la [Libera Programaro-Fundamento (FSF)] ( https://eo.wikipedia.org/wiki/Free_Software_Foundation)

Ĉi tiu sekcio estas uzata por konsciigi la problemojn kun DRM, kaj ankaŭ por protesti kontraŭ ĝi. DRM estas misa pro projektado kaj estas grava minaco por ĉiuj komputilaj uzantoj kaj libereco de programaro.

Bildo-kredito: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Sponsoraj informoj

! [SponsorButton.png] (SponsorButton.png) <- Ne alklaku ĉi tiun butonon, ĝi ne funkcias, ĝi estas nur bildo. La vera butono estas ĉe la supro de la paĝo en la dekstra (<- L ** R ** ->) angulo

Vi povas sponsori ĉi tiun projekton se vi volas, sed bonvolu specifi al kio vi volas donaci. [Vidu la financojn al kiuj vi povas donaci ĉi tie] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Vi povas vidi aliajn sponsorajn informojn [ĉi tie] (https://github.com/seanpm2001/Sponsor-info/)

Provu ĝin! La butono de sponsoro estas tuj apud la butono de horloĝo / malrigardo.

***

## Dosiera historio

Versio 1 (vendrede, la 19an de februaro 2021 je la 17:20)

> Ŝanĝoj:

> * Komencis la dosieron

> * Aldonis la bazan priskriban sekcion

> * Aldonis la sekcion pri priskribo de deponejo

> * Aldonis la artikolan liston, kun 14 eniroj

>> * Aldonis sekcion `rilataj artikoloj`

>> * Aldonis sekcion `vidu ankaŭ`

> * Aldonis la sekcion pri dosieraj informoj

> * Aldonis la sekcion pri dosierhistorio

> * Aldonis la piedlinion

> * Neniuj aliaj ŝanĝoj en versio 1

Versio 2 (vendrede la 19an de februaro 2021 je la 17:26)

> Ŝanĝoj:

> * Aldonis la sekcion pri traduka stato

> * Aldonis la sekcion Aliaj aĵoj por kontroli

> * Aldonis la sekcion pri privateco

> * Aldonis indekson

> * Aldonis la subsekcion pri programara stato

> * Aldonis la alian sekcion kontraŭ Google-kampanjoj

>> * Aldonis la kadukan subsekcion

>> * Aldonis la daŭran subsekcion

> * Aldonis la sekcion pri fontoj

> * Aldonis la sekcion pri elŝutaj ligoj

> * Ĝisdatigis la sekcion pri dosieraj informoj

> * Ĝisdatigis la sekcion pri dosierhistorio

> * Neniuj aliaj ŝanĝoj en versio 2

Versio 3 (merkrede, la 24an de februaro 2021 je la 19:56)

> Ŝanĝoj:

> * Ĝisdatigis la indekson

> * Referencis la piktogramon degoogle kaj la novan GitHub-organizon

> * Aldonis ligojn al pli novaj artikoloj

> * Aldonis la sekcion kontraŭargumentaj aliaj argumentoj

>> * Aldonis la oportunan subsekcion

>> * Aldonis la subfakon Kial eĉ ĝeni

>> * Aldonis la alian subsekcion

> * Ĝisdatigis iujn datumojn

> * Ĝisdatigis la sekcion pri dosieraj informoj

> * Ĝisdatigis la sekcion pri dosierhistorio

> * Neniuj aliaj ŝanĝoj en versio 3

Versio 4 (ĵaŭde, la 25-an de februaro 2021 je 21:31)

> Ŝanĝoj:

> * Aldonis ligojn al 10 novaj artikoloj

> * Aldonis sekcion pri mia sperto degoogling

> * Ĝisdatigis la indekson

> * Ĝisdatigis la sekcion pri dosieraj informoj

> * Ĝisdatigis la sekcion pri dosierhistorio

> * Neniu alia ŝanĝo en versio 4

Versio 5 (vendredo, 9 aprilo 2021 je 18:02)

_Nuntempe mankis ĝisdatigoj de la kontraŭgugla movado de mi, mi laboras por reveni al ĝi post pli ol unu-monata paŭzo ._

> Ŝanĝoj:

> * Ĝisdatigis la titolan sekcion

> * Ĝisdatigis la indekson

> * Ĝisdatigis la lingvan liston: fiksitaj ligoj, kaj aldonis pli subtenatajn lingvojn

> * Ĝisdatigis la artikolan statan sekcion, aldonante 4 forkajn ligojn

> * Ĝisdatigis la sekcion pri stato de programaro

> * Aldonis la sekcion Go is evil

> * Aldonis la sekcion Uzado de DRM

> * Aldonis la sekcion Komuna miskompreniĝo

>> * Aldonita la Google ne estas la interreta subsekcio

> * Aldonis la sekcion Interreto Explorer 6 kaj Chrome

>> * Aldonis la subsekcion La problemo kun Brava

> * Aldonis la falsan privatan forigon

> * Aldonita la Malferma fonto ne povas esti parta subsekcio

> * Aldonis la subsekcion Oxymoron

> * Aldonis la sekcion Malbona agado

> * Aldonis la sekcion Malbona projekt-administrado

> * Aldonis la sekcion Terura aŭ neniu modereco de servoj

> * Aldonis la sekcion Astroturfado

> * Aldonis la sekcion kontraŭleĝaj kaj maletikaj komercaj praktikoj

> * Aldonis la sub-sekcion En Eŭropo

>> * Aldonis la subsekcion En Nordameriko

>> * Aldonis la subsekcion Polemikoj

> * Aldonita la sekcio Google estas aŭtomata

> * Aldonis la sekcion Android

> * Aldonis la sekcion Malgrandaj agoj por helpi

> * Aldonis la nefidindan sekcion

> * Aldonis la informan sekcion pri sponsoro

> * Ĝisdatigis la piedlinion

> * Ĝisdatigis la sekcion pri dosieraj informoj

> * Ĝisdatigis la sekcion pri dosierhistorio

> * Neniu alia ŝanĝo en versio 5

Versio 6 (Baldaŭ)

> Ŝanĝoj:

> * Baldaŭ

> * Neniuj aliaj ŝanĝoj en versio 6

Versio 7 (Baldaŭ)

> Ŝanĝoj:

> * Baldaŭ

> * Neniu alia ŝanĝo en versio 7Versio 8 (Baldaŭ)

> Ŝanĝoj:

> * Baldaŭ

> * Neniuj aliaj ŝanĝoj en versio 8

Versio 9 (Baldaŭ)

> Ŝanĝoj:

> * Baldaŭ

> * Neniuj aliaj ŝanĝoj en versio 9

Versio 10 (Baldaŭ)

> Ŝanĝoj:

> * Baldaŭ

> * Neniu alia ŝanĝo en versio 10

***

## Piedo

Vi atingis la finon de ĉi tiu dosiero

([Reen supre] (# Supra) | [Revenu al GitHub] (https://github.com))

### EOF

***
