
***

### Logo Image optimization

I currently don't have an optimized logo for this project. I currently only have a JPEG image file with a white background, which sticks out like a thorn in other color modes. I need a transparent PNG/SVG version of the following image:

![DEGOOGLE1](https://user-images.githubusercontent.com/65933340/115483816-5c7afe80-a206-11eb-9178-8de0f5eddebe.jpeg)

If anyone is able to help, send me a link to a modified PNG or SVG version of this image. No other format will be accepted.

***
