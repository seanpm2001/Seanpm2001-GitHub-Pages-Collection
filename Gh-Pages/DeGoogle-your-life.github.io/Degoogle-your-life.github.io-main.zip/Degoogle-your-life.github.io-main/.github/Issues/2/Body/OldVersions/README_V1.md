***

### Important point to make (2.22.2021)

During a discussion earlier, I noted that I have focused too heavily on the privacy argument, and that I missed out on another key argument, which is convenience and "when there is good, there has to be bad" this is an important argument that I forgot to go against, as the privacy argument won't get through to everyone, but other ones will.

***
