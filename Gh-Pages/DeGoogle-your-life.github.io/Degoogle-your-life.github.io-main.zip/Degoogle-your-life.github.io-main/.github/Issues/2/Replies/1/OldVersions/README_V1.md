### Some new notes from today (2.23.2021)

Why does it matter
Its too late anyways
