I already added this yesterday, but I forgot to close the issue. I am doing that now.
