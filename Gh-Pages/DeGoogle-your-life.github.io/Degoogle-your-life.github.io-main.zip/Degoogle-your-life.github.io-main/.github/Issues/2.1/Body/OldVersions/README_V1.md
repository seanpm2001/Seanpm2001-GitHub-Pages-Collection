***

### Need help with dropdown formatting

I need help with a dropdown formatting bug, I don't want to remove the dropdown before publishing each update to the site. The problem is that adding the dropdown works, but in the process it breaks every single link and all formatting within the dropdown. I have attempted to space out the tag and indent them, but it hasn't fixed the problem. This problem does not occur on the `README` file on the source project, I want to nail this issue with GitHub pages, and have better formatting.

If anyone who publishes to GitHub pages knows what to do, please help me with advice.

***
