***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle η ζωή σας

Αυτό είναι το κύριο άρθρο degoogling για γενικές πληροφορίες degoogling και ένας σύνδεσμος προς τα άλλα άρθρα.

[Δείτε τη λίστα ως οργανισμός GitHub] (https://github.com/Degoogle-your-life)

***

_Διαβάστε αυτό το άρθρο σε διαφορετική γλώσσα: _

** Η τρέχουσα γλώσσα είναι: ** "Αγγλικά (ΗΠΑ)" _ (οι μεταφράσεις ενδέχεται να πρέπει να διορθωθούν για να διορθωθεί η αγγλική αντικαθιστώντας τη σωστή γλώσσα) _

_🌐 Λίστα γλωσσών_

** Ταξινόμηση κατά: ** "A-Z"

[Οι επιλογές ταξινόμησης δεν είναι διαθέσιμες] (https://github.com/Degoogle-your-Life)

[[af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Αλβανικά | [am አማርኛ] (/. github / README_AM.md) Αμαρικά | [ar عربى] (/.github/README_AR.md) Αραβικά | [hy հայերեն] (/. github / README_HY.md) Αρμενικά | [az Azərbaycan dili] (/. github / README_AZ.md) Αζερμπαϊτζάν | [eu Euskara] (/. github /README_EU.md) Βασκικά | [be Беларуская] (/. Github / README_BE.md) Λευκορωσικά | [bn বাংলা] (/. Github / README_BN.md) Μπενγκάλι | [bs Bosanski] (/. Github / README_BS.md) Βοσνιακά | [bg български] (/. Github / README_BG.md) Βουλγαρικά | [ca Català] (/. Github / README_CA.md) Καταλανικά | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa | ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Κινέζικα (απλοποιημένα) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Κινέζικα (Παραδοσιακά) | [co Corsu] (/. Github / README_CO.md) Κορσικά | [hr Hrvatski] (/. Github / README_HR.md) Κροατικά | [cs čeština] (/. Github / README_CS .md) Τσεχικά | [da dansk] (README_DA.md) Δανικά | [nl Nederlands] (/. github / README_ NL.md) Ολλανδικά | [** en-us Αγγλικά **] (/. github / README.md) Αγγλικά | [EO Εσπεράντο] (/. Github / README_EO.md) Εσπεράντο | [et Eestlane] (/. github / README_ET.md) Εσθονικά | [tl Pilipino] (/. github / README_TL.md) Φιλιππινέζικα | [fi Suomalainen] (/. github / README_FI.md) Φινλανδικά | [fr français] (/. github / README_FR.md) Γαλλικά | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Γαλικιανά | [ka ქართველი] (/. github / README_KA) Γεωργιανά | [de Deutsch] (/. github / README_DE.md) Γερμανικά | [el Ελληνικά] (/. github / README_EL.md) Ελληνικά | [gu ગુજરાતી] (/. github / README_GU.md) Γκουτζαράτι | [ht Kreyòl ayisyen] (/. github / README_HT.md) Κρεολική Αϊτή | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Χαβάης | [he ians]] (/. github / README_HE.md) Εβραϊκά | [hi हिन्दी] (/. github / README_HI.md) Χίντι | [hmn Hmong] (/. github / README_HMN.md) Χμονγκ | [hu Magyar] (/. github / README_HU.md) Ουγγρικά | [is Íslenska] (/. github / README_IS.md) Ισλανδικά | [ig Igbo] (/. github / README_IG.md) Igbo | [id γλώσσα Ινδονησία] (/. github / README_ID.md) Ισλανδικά | [ga Gaeilge] (/. github / README_GA.md) Ιρλανδικά | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Ιαπωνικά | [jw Wong jawa] (/. github / README_JW.md) Ιάβας | [kn ಕನ್ನಡ] (/. github / README_KN.md) Κανάντα | [kk Қазақ] (/. github / README_KK.md) Καζακστάν | [km ខ្មែរ] (/. github / README_KM.md) Χμερ | [rw Kinyarwanda] (/. github / README_RW.md) Κινιαρβάντα | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Κορεάτικα (Νότια) | [ko-north 문화어] (README_KO_NORTH.md) Κορεάτικα (Βόρεια) (ΔΕΝ ΕΙΝΑΙ ΜΕΤΑΦΡΑΣΗ) | [ku Kurdî] (/. github / README_KU.md) Κουρδικά (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Κιργιστάν | [lo ລາວ] (/. github / README_LO.md) Λάος | [la Latine] (/. github / README_LA.md) Λατινικά | [lt Lietuvis] (/. github / README_LT.md) Λιθουανικά | [lb Lëtzebuergesch] (/. github / README_LB.md) Λουξεμβούργο | [mk Македонски] (/. github / README_MK.md) Μακεδονικά | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) Μαλαισικά | [ml മലയാളം] (/. github / README_ML.md) Μαλαγιαλάμ | [mt Malti] (/. github / README_MT.md) Μαλτέζικα | [mi Maori] (/. github / README_MI.md) Μαορί | [mr मराठी] (/. github / README_MR.md) Μαράθι | [mn Монгол] (/. github / README_MN.md) Μογγολικά | [my မြန်မာ] (/. github / README_MY.md) Μιανμάρ (Βιρμανίας) | [ne नेपाली] (/. github / README_NE.md) Νεπάλ | [no norsk] (/. github / README_NO.md) Νορβηγικά | [ή ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Περσικά [pl polski] (/. github / README_PL.md) Πολωνικά | [pt português] (/. github / README_PT.md) Πορτογαλικά | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Δεν υπάρχουν διαθέσιμες γλώσσες που ξεκινούν με το γράμμα Q | [ro Română] (/. github / README_RO.md) Ρουμανικά | [ru русский] (/. github / README_RU.md) Ρωσικά | [sm Faasamoa] (/. github / README_SM.md) Σαμαανικά | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Σκωτσέζικος Γαελικός | [sr Српски] (/. github / README_SR.md) Σερβικά | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Σίντι | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Σλοβακικά | [sl Slovenščina] (/. github / README_SL.md) Σλοβενικά | [so Soomaali] (/. github / README_SO.md) Σομαλικά | [[es en español] (/. github / README_ES.md) Ισπανικά | [su Sundanis] (/. github / README_SU.md) Σουδανικά | [sw Kiswahili] (/. github / README_SW.md) Σουαχίλι | [sv Svenska] (/. github / README_SV.md) Σουηδικά | [tg Тоҷикӣ] (/. github / README_TG.md) Τατζίκ | [ta தமிழ்] (/. github / README_TA.md) Ταμίλ | [tt Татар] (/. github / README_TT.md) Τατάρ | [te తెలుగు] (/. github / README_TE.md) Τελούγκου | [th ไทย] (/. github / README_TH.md) Ταϊλανδικά | [tr Türk] (/. github / README_TR.md) Τουρκικά | [tk Türkmenler] (/. github / README_TK.md) Τουρκμενιστάν | [uk Український] (/. github / README_UK.md) Ουκρανικά | [ur اردو] (/. github / README_UR.md) Ουρντού | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Ουζμπεκιστάν | [vi Tiếng Việt] (/. github / README_VI.md) Βιετναμέζικα | [cy Cymraeg] (/. github / README_CY.md) Ουαλικά | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Γίντις | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Διατίθεται σε 110 γλώσσες (108 όταν δεν μετράει Αγγλικά και Βόρεια Κορεάτικα, καθώς η Βόρεια Κορέα δεν έχει μεταφραστεί ακόμα [Διαβάστε για αυτό εδώ] (/ OldVersions / Κορεατικά (Βόρεια ) / README.md))

Μεταφράσεις σε άλλες γλώσσες εκτός από τα αγγλικά μεταφράζονται μηχανικά και δεν είναι ακόμη ακριβείς. Δεν έχουν διορθωθεί ακόμη σφάλματα από τις 5 Φεβρουαρίου 2021. Αναφέρετε σφάλματα μετάφρασης [εδώ] (https://github.com/seanpm2001/Degoogle-your-life/issues/) φροντίστε να δημιουργήσετε αντίγραφα ασφαλείας της διόρθωσής σας με πηγές και να με καθοδηγήσετε , καθώς δεν γνωρίζω άλλες γλώσσες εκτός από τα Αγγλικά (σκοπεύω να βρω έναν μεταφραστή τελικά) παρακαλώ αναφέρετε το [wiktionary] (https://en.wiktionary.org) και άλλες πηγές στην αναφορά σας. Σε αντίθετη περίπτωση, θα δημοσιευτεί η απόρριψη της διόρθωσης.

Σημείωση: λόγω περιορισμών με την ερμηνεία markdown του GitHub (και σχεδόν κάθε άλλη ερμηνεία markdown μέσω διαδικτύου) κάνοντας κλικ σε αυτούς τους συνδέσμους θα σας ανακατευθύνει σε ξεχωριστό αρχείο σε ξεχωριστή σελίδα που δεν είναι η σελίδα προφίλ μου στο GitHub. Θα ανακατευθυνθείτε στο [αποθετήριο seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), όπου φιλοξενείται το README.

Οι μεταφράσεις γίνονται με τη Μετάφραση Google λόγω περιορισμένης ή καθόλου υποστήριξης για τις γλώσσες που χρειάζομαι σε άλλες μεταφραστικές υπηρεσίες όπως το DeepL και το Bing Translate (αρκετά ειρωνικό για μια καμπάνια κατά του Google) Εργάζομαι για να βρω μια εναλλακτική λύση. Για κάποιο λόγο, η μορφοποίηση (σύνδεσμοι, διαχωριστικά, έντονα γράμματα, πλάγια γράμματα, κ.λπ.) είναι ακατάστατη σε διάφορες μεταφράσεις. Είναι κουραστικό να διορθώσετε και δεν ξέρω πώς να διορθώσετε αυτά τα ζητήματα σε γλώσσες με μη λατινικούς χαρακτήρες και από δεξιά προς τα αριστερά (όπως τα Αραβικά) απαιτείται επιπλέον βοήθεια για την επίλυση αυτών των προβλημάτων

Λόγω προβλημάτων συντήρησης, πολλές μεταφράσεις δεν είναι ενημερωμένες και χρησιμοποιούν μια παλιά έκδοση αυτού του αρχείου άρθρου «README». Απαιτείται μεταφραστής. Επίσης, από τις 9 Απριλίου 2021, θα με πάρει λίγο χρόνο για να λειτουργήσω όλοι οι νέοι σύνδεσμοι.

***

## Ευρετήριο

[00.0 - Τίτλος] (# Degoogling --- Degoogle-your-life)

> [00.1 - Ευρετήριο] (# Ευρετήριο)

[01.0 - Βασική περιγραφή] (# Βασική περιγραφή)

> [01.1 - Κεφαλίδα αποθετηρίου] (# Degoogle-your-life)

> [01.2 - Επισκόπηση περιγραφής Wuest3NFuchs] (# Επισκόπηση-από-Wuest3nFuchs)

>> [01.2.1 - Τι σημαίνει;] (# Τι σημαίνει αυτό - από-Wuest3nFuchs)

>> [01.2.2 - Γιατί το Degoogle;] (# Why-Degoogle - by-Wuest3nFuchs)

[02.0 - Άρθρα] (# άρθρα)

[03.0 - Απόρρητο] (# Απόρρητο)

[04.0 - Άλλες καμπάνιες κατά της Google] (# Άλλες καμπάνιες κατά της Google)

> [04.0.1 - Απενεργοποίηση] (# Απενεργοποίηση)

> [04.0.2 - Σε εξέλιξη] (# Σε εξέλιξη)

[05.0 - Αντιμετώπιση άλλων επιχειρημάτων] (# Countering-other-επιχειρήματα)

> [05.0.1 - Ευκολία] (# Ευκολία)

> [05.0.2 - Γιατί έχει σημασία; Τέλος πάντων, είναι πολύ αργά]

> [05.0.3 - Άλλο] (# Άλλο)

[06.0 - Πηγές] (# Πηγές)

[07.0 - Λήψη συνδέσμων] (# Σύνδεσμοι λήψης)

[08.0 - Η εμπειρία μου στο degoogling] (# My-degoogling-experience)

> [08.1 - Τι άλλαξα] (# What-I-switched-from)

> [08.2 - Προϊόντα από τα οποία δεν μπορώ ακόμα να ξεφύγω] (# Προϊόντα-I-still-cannot-get-away-from)

[09.0 - Άλλα πράγματα που μπορείτε να δείτε] (# Άλλα πράγματα-προς-check-out)

[10.0 - Πληροφορίες αρχείου] (# Πληροφορίες αρχείου)

> [10.1 - Κατάσταση λογισμικού] (# Κατάσταση λογισμικού)

> [10.2 - Πληροφορίες χορηγού] (# Πληροφορίες χορηγού)

[11.0 - Ιστορικό αρχείων] (# Ιστορικό αρχείων)

[12.0 - Υποσέλιδο] (# Υποσέλιδο)

***

## Βασική περιγραφή

[Από τη Wikipedia: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

Το κίνημα DeGoogle (ονομάζεται επίσης κίνημα de-Google) είναι μια λαϊκή εκστρατεία που έχει δημιουργηθεί καθώς οι ακτιβιστές απορρήτου προτρέπουν τους χρήστες να σταματήσουν να χρησιμοποιούν προϊόντα Google εντελώς λόγω των αυξανόμενων ανησυχιών σχετικά με το απόρρητο σχετικά με την εταιρεία. Ο όρος αναφέρεται στην πράξη της αφαίρεσης του Google από τη ζωή κάποιου. Καθώς το αυξανόμενο μερίδιο αγοράς του γίγαντα του Διαδικτύου δημιουργεί μονοπωλιακή δύναμη για την εταιρεία σε ψηφιακούς χώρους, αυξανόμενος αριθμός δημοσιογράφων σημείωσε τη δυσκολία να βρουν εναλλακτικές λύσεις για τα προϊόντα της εταιρείας.

**Ιστορία**

Το 2013, ο John Koetsier της Venturebeat είπε ότι το tablet που βασίζεται στο Android Kindle Fire Android ήταν "μια έκδοση Android που δεν είναι Google". Το 2014 ο Τζον Σίμπσον των ΗΠΑ News έγραψε για το «δικαίωμα να ξεχαστεί» από το Google και άλλες μηχανές αναζήτησης. Το 2015, ο Derek Scally of Irish Times έγραψε ένα άρθρο σχετικά με το πώς να "De-Google η ζωή σας". Το 2016 ο Kris Carlon του Androiδ Η Αρχή πρότεινε ότι οι χρήστες του CyanogenMod 14 θα μπορούσαν να «απενεργοποιήσουν» τα τηλέφωνά τους, επειδή το CyanogenMod λειτουργεί καλά χωρίς εφαρμογές Google. Το 2018 ο Nick Lucchesi of Inverse έγραψε για το πώς η ProtonMail προωθούσε πώς να "μπορείς να απομακρύνεις πλήρως τη ζωή σου". Ο Μπρεντάν Έσση της Lifehacker έγραψε ένα λεπτομερές σεμινάριο σχετικά με το «κλείσιμο της Google». Ο δημοσιογράφος Gizmodo, Κασμίρ Χιλ, ισχυρίζεται ότι έχασε συναντήσεις και είχε δυσκολίες στην οργάνωση συναντήσεων χωρίς τη χρήση του Ημερολογίου Google. Το 2019, η Huawei έδωσε επιστροφή χρημάτων σε κατόχους τηλεφώνων στις Φιλιππίνες εμποδίστηκε από τη χρήση υπηρεσιών που παρέχονται από την Google, επειδή υπάρχουν λίγες εναλλακτικές λύσεις που η απουσία των προϊόντων της εταιρείας έκανε την κανονική χρήση του Διαδικτύου ανέφικτη.

***

# Degoogle-η ζωή σας
Ένα αποθετήριο για γενικές πληροφορίες αποπροσανατολισμού και συνδέσμους προς τα άλλα αποθετήρια αποθηκών.

***

## Επισκόπηση από Wuest3nFuchs

Μια καλύτερη περιγραφή, που παρέχεται από το [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - πηγή: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Τι σημαίνει? από τον Wuest3nFuchs

Το Degoogling σημαίνει να σταματήσετε να χρησιμοποιείτε οτιδήποτε ανήκει στην Google, οτιδήποτε δημιουργήθηκε από την Google. Μιλώ για τη μηχανή αναζήτησης, την υπηρεσία αλληλογραφίας τους (Gmail), το Youtube κ.λπ.

### Γιατί το Degoogle; από τον Wuest3nFuchs

Η Google είναι μία από τις πιο ισχυρές εταιρείες στον κόσμο αυτή τη στιγμή. Έχουν αποθηκεύσει τεράστια ποσότητα πληροφοριών σε όλους μας. Μερικοί θα υποστήριζαν ότι οι πληροφορίες μας είναι ασφαλείς μαζί τους επειδή ξέρουν πώς να τις προστατεύουν. Αλλά αυτό δεν είναι αλήθεια. Το Google έχει διεισδύσει στο παρελθόν και θα διεισδύσει στο μέλλον. Ίσως όχι από κάποιο σενάριο παιδάκι, αλλά θα γίνει από ένα κράτος έθνους. Η Google αποθηκεύει προσωπικά στοιχεία σε όλους μας, γιατί έτσι κερδίζουν χρήματα.

Σαρώνουν τα email μας, αποθηκεύουν ό, τι ψάχνουμε όταν χρησιμοποιούμε τη μηχανή αναζήτησής τους, ποια βίντεο παρακολουθούμε στο Youtube. Έτσι μας στοχεύουν και δημιουργούν ένα προφίλ για να μας δείξουν κάποια διαφήμιση με βάση αυτό που συζητήσαμε με τον καλύτερό μας φίλο, ώστε να μπορούν να μας δείξουν μια διαφήμιση για κάτι που χρειαζόμαστε, αλλά αυτό είναι πολύ ανατριχιαστικό. Χάρη στον κ. Snowden γνωρίζουμε τώρα ότι η Google έχει μοιραστεί τα προσωπικά μας στοιχεία με την NSA σε ένα πρόγραμμα που ονομάζεται ** "PRISM" **.


Στο μέλλον κάποιος θα μπορεί να έχει πρόσβαση σε όλες αυτές τις πληροφορίες και σας διαβεβαιώνω ότι κάτι πραγματικά κακό θα συμβεί. Για να μην συμβεί αυτό, πρέπει να ξεκινήσετε το Degoogling τώρα. Επίσης, δεν πρέπει να χρησιμοποιείτε προϊόντα από μια εταιρεία που μοιράζεται τα δεδομένα σας με ** NSA **. Θα πρέπει να σταματήσετε όλα αυτά με απενεργοποίηση.

** Εάν μπορούν να το κάνουν και άλλα άτομα, μπορείτε να το κάνετε και αυτό. **

[Διαβάστε περισσότερα εδώ] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Ένας σύνδεσμος προς το πιρούνι δεν αναφέρεται προς το παρόν, καθώς δεν διαθέτω πλήρως αυτό το αποθετήριο και θέλω να προωθήσω άλλες πηγές. Θα ήταν εγωιστικό να συνδεθώ στο δικό μου https://github.com/Degoogle-your-life/Degoogle! ->

***

## Άρθρα

### Κατάσταση άρθρου

_Όλα τα άρθρα βρίσκονται επί του παρόντος σε εξέλιξη και χρειάζονται τεράστιες βελτιώσεις. Επιτρέπονται προτάσεις και διορθώσεις._

_ Από τις 18 Απριλίου 2021 στις 4:09 μ.μ., τα περισσότερα άρθρα δεν έχουν ξεκινήσει ακόμη. Εργάζομαι για να βρω χρόνο και προσπάθεια για να τα ξεκινήσω._

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Chrome] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Διακοπή χρήσης Chromebook] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Διακοπή χρήσης του WideVine DRM / Ήρθε η ώρα να κόψετε το WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Εναλλαγή από το YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Σταματήστε το Google, γιατί πρέπει να σταματήσετε να χρησιμοποιείτε την Αναζήτηση Google] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Gmail] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Android] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Γιατί πρέπει να αποφύγετε το Google Amp] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Drive] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τους Χάρτες Google και το Google Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Γεια Google, σταματήστε] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Διακοπή ανάγνωσης από βιβλία Google / Play] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Διακοπή χρήσης του Google Classroom] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τη Μετάφραση Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τους Λογαριασμούς σας Google] (https://github.com/seanpm2001/Why-you-should-sκορυφαίοι-Λογαριασμοί Google) <! - 16! ->

** Νέα άρθρα που θα γραφτούν σύντομα: **

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Gerrit] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Analytics (το αποθετήριο έχει χαθεί στο τέλος μου την Τετάρτη 24 Φεβρουαρίου 2021 στις 4:13 μ.μ.)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics) <! - 18! ->

<! - Διαχωριστικό εργασίας! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google One] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google+ (απενεργοποιημένο)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Play Store] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τα Έγγραφα Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τις Παρουσιάσεις Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τα Φύλλα Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τις Φόρμες Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Cardboard] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Messages] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Material Design] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Glass / Glasses] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το GBoard] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Home] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Nest] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Hangouts (απενεργοποιημένο)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Duo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τη γλώσσα προγραμματισμού Googles Go] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τη γλώσσα προγραμματισμού Googles Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τη μορφή εικόνας του Google Googles] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τη μορφή βίντεο του Google Googles] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Video] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τους Ιστότοπους Google (κλασικό)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τους Ιστότοπους Google ("Νέος")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Android Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google VPN (oxymoron)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τις Φωτογραφίες Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Ημερολόγιο Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το VirusTotal (δεδομένου ότι ανήκει στην Google από τον Σεπτέμβριο του 2012) (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Fi] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi) <! - 53! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Stadia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Keep] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Base] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Γιατί πρέπει να σταματήσετε να συμμετέχετε στο Google Summer of Code] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Camera] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Γιατί θα πρέπει να σταματήσετε να χρησιμοποιείτε την Αριθμομηχανή Google (μπορεί να φαίνεται ακραία, αλλά θα πρέπει να απενεργοποιήσετε το Google από τα πάντα, εξαιρετικά εύκολο να την αντικαταστήσετε)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Αριθμομηχανή) <! - 59! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Google Survey + ανταμοιβές] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε τα Σχέδια Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Γιατί πρέπει να σταματήσετε να χρησιμοποιείτε το Tenor (ιστότοπος GIF, που ανήκει στην Google από το 2019)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Τι είναι το FLoC - Γιατί πρέπει να αποφύγετε το μεγάλο πρόβλημα του Google FloCing (σταματήστε να χρησιμοποιείτε το Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Σύνολο άρθρων: ** "63"

** Άρθρο [roadmap AB] (DegoogleCampaign_2021Roadmap_Part1.md) (έως 12 Μαρτίου 2021) 2 ημέρες έκπτωση **

** Άρθρο [χάρτης πορείας BB] (DegoogleCampaign_2021Roadmao_Part2.md) (έως? 2021) 2 ημέρες έκπτωση **

Κατάσταση άρθρου

Όλα τα άρθρα βρίσκονται επί του παρόντος σε εξέλιξη και χρειάζονται τεράστιες βελτιώσεις. Επιτρέπονται προτάσεις και διορθώσεις.

** Πιρούνια **

Επέκταση του δικτύου μου στο Degoogle, και προσθήκη κάποιας ευκολίας πρόσβασης, και κραυγές κοινότητας.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Περάστε από: [https://github.com/wacko1805/Fossapps](https://github.com/wacko1805/Fossapps) (Αγγλικά)

2. [Σύνδεσμοι απορρήτου] (https://github.com/Degoogle-your-life/Privacy-links) | Διακλαδώθηκε από: [https://github.com/Arturro43/privacy-links](https://github.com/Arturro43/privacy-links) (Πολωνικά)

3. [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Περάστε από: [https://github.com/LinuxCafeFederation/Delightful-Privacy](https://github.com/LinuxCafeFederation/Delightful-Privacy) (Αγγλικά)

4. [Blocklists] (https://github.com/Degoogle-your-life/blocklists) | Περάστε από: [https://github.com/jmdugan/blocklists](https://github.com/jmdugan/blocklists] (Αγγλικά)

5. [Degoogle, by Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Περάστε από: [https://github.com/Wuest3nFuchs/Degoogle](https://github.com/Wuest3nFuchs/Degoogle) (Αγγλικά)

**Σχετιζομαι με**

[Έρευνα εικονικής μηχανής τηλεφώνου Degoogled Android] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Δείτε επίσης:**

[Κριτική του Google στη Wikipedia] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[Το Google Graveyard (killbygoogle.com) - μια ταξινομημένη λίστα με τα 224+ προϊόντα που έχει σκοτώσει η Google] (https://killedbygoogle.com/)

> [Σύνδεσμος GitHub] (https://github.com/codyogden/killedbygoogle)

[Ένωση εργαζομένων αλφάβητου - Η νέα ένωση εργαζομένων στο Google με περισσότερα από 800 μέλη] (https://alphabetworkersunion.org/people/our-union/)

[Δεν θέλετε να χωρίσετε με το Πασχαλινό αυγό του δεινοσαύρου; Αυτός ο ιστότοπος σας καλύπτει] (https://chromedino.com/)

***

## Μυστικότητα

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument # Criticism) [β] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -σελίδα-δείγματα / τίποτα-απόκρυψη-επιχείρημα-έχει-τίποτα-να πούμε /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- του-data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -το προσωπικό σας-δεδομένα-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -monetizes-και) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- συλλογή-αποκαλυφθέν.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ health-fitness-data-privacy /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks] [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / Αυστραλιανή κυβέρνηση-google-δεδομένα-συλλογή-αγωγή-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https://moz.com /blog/where-does-google-draw-the-data-collection-line)[e](https://mashable.com/article/google-android-data-collection-study/)[s](https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)[o](https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -αξιώσεις για λογαριασμό-5-μ illion-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/)[r](https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/)[i](https://www.cbsnews.com/news/google-education-spies-on-collects- δεδομένα-σε-εκατομμύρια-παιδιά-κατηγορίες-αγωγή-νέο-Μεξικό-γενικός εισαγγελέας /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / τεχνολογία / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : //medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Θα μπορούσα να συνεχίσω και να αποδείξω αυτό, αλλά χρειάστηκε πολύς χρόνος για να βρω και να περάσω από όλα αυτά άρθρα)

Το απόρρητο στα προϊόντα Google είναι πάντα κακό, λόγω όλων των προϊόντων Google που περιέχουν spyware.

Ανεξάρτητα από το τι κάνετε, όταν χρησιμοποιείτε το Google, όλα τα ευαίσθητα προσωπικά σας δεδομένα αποστέλλονται στην Google και σε άλλους. Το Google έχει επίσης εντοπίσει ανοιχτά προγράμματα. Για παράδειγμα, από προσωπική εμπειρία (στον Firefox) με ανοιχτή μια καρτέλα YouTube που δεν επισκέφτηκα, παρακολούθησα αρκετά βίντεο εκτός σύνδεσης (VLC Media Player) Αργότερα όταν πήγα να ελέγξω τις προτάσεις, ήταν σχεδόν όλα όσα είχα παρακολουθήσει. Δεν υπάρχει αμφιβολία ότι κατασκοπεύουν και άλλα προγράμματα.

Στο Chrome (και σε πολλά άλλα προγράμματα περιήγησης) υπάρχει μια κατάσταση ανώνυμης περιήγησης. Στο Chrome, αυτή η λειτουργία είναι άσκοπη, καθώς η Google θα εξακολουθήσει να χρησιμοποιεί τα δεδομένα σας. Ακόμα κι αν απενεργοποιήσετε την εξόρυξη / παρακολούθηση δεδομένων και ενεργοποιήσετε το σήμα "μην παρακολουθείτε", έκπληξη, η Google εξακολουθεί να εξορύσσει τα δεδομένα σας.

Εάν νομίζετε ότι δεν έχετε τίποτα να κρύψετε, ** έχετε απολύτως λάθος **. Αυτό το επιχείρημα έχει αφαιρεθεί πολλές φορές:

[Μέσω Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Ο Έντουαρντ Σνόουντεν παρατήρησε «Υποστηρίζοντας ότι δεν ενδιαφέρεστε για το δικαίωμα στην ιδιωτική ζωή, επειδή δεν έχετε τίποτα να κρύψετε δεν διαφέρει από το να λέτε ότι δεν σας ενδιαφέρει η ελευθερία του λόγου, επειδή δεν έχετε τίποτα να πείτε.» Όταν λέτε, « Δεν έχω τίποτα να κρύψω, "λες," δεν με νοιάζει αυτό το σωστό. "Λέτε," Δεν έχω αυτό το δικαίωμα, γιατί έχω φτάσει στο σημείο όπου πρέπει να «Ο τρόπος λειτουργίας των δικαιωμάτων, η κυβέρνηση πρέπει να δικαιολογήσει την εισβολή στα δικαιώματά σας».

2. Ο Daniel J. Solove δήλωσε σε ένα άρθρο για το The Chronicle of Higher Education ότι αντιτίθεται στο επιχείρημα. δήλωσε ότι μια κυβέρνηση μπορεί να αφήσειk πληροφορίες σχετικά με ένα άτομο και να προκαλέσουν ζημιά σε αυτό το άτομο, ή να χρησιμοποιήσουν πληροφορίες σχετικά με ένα άτομο για να αρνηθεί την πρόσβαση σε υπηρεσίες, ακόμη και αν ένα άτομο δεν είχε πράγματι διαπράξει αδίκημα και ότι μια κυβέρνηση μπορεί να προκαλέσει ζημιά στην προσωπική ζωή κάποιου μέσω λάθους. Ο Σόλοβε έγραψε: «Όταν εμπλέκονται άμεσα, το επιχείρημα τίποτα για απόκρυψη μπορεί να παγιδεύσει, γιατί αναγκάζει τη συζήτηση να επικεντρωθεί στη στενή κατανόηση της ιδιωτικής ζωής. Αλλά όταν έρχεται αντιμέτωπος με την πλειονότητα των προβλημάτων απορρήτου που συνεπάγεται η συλλογή και χρήση κυβερνητικών δεδομένων πέρα ​​από την επιτήρηση και η αποκάλυψη, το επιχείρημα χωρίς να κρύβεται, στο τέλος, δεν έχει τίποτα να πει. "

3. Ο Adam D. Moore, συγγραφέας των Δικαιωμάτων Προστασίας Προσωπικών Δεδομένων: Ηθικά και Νομικά Ιδρύματα, υποστήριξε, "είναι η άποψη ότι τα δικαιώματα είναι ανθεκτικά στο κόστος / όφελος ή σε συνακόλουθα επιχειρήματα. Εδώ απορρίπτουμε την άποψη ότι τα συμφέροντα της ιδιωτικής ζωής είναι τα είδη πραγμάτων που μπορούν να ανταλλαχθούν για ασφάλεια. " Δήλωσε επίσης ότι η παρακολούθηση μπορεί να επηρεάσει δυσανάλογα ορισμένες ομάδες της κοινωνίας με βάση την εμφάνιση, την εθνικότητα, τη σεξουαλικότητα και τη θρησκεία.

4. Ο Bruce Schneier, εμπειρογνώμονας ασφάλειας υπολογιστών και κρυπτογράφος, εξέφρασε την αντίθεσή του, επικαλούμενος τη δήλωση του Καρδινάλου Richelieu "Αν κάποιος μου έδινε έξι γραμμές γραμμένες από το χέρι του πιο ειλικρινούς άνδρα, θα έβρισκα κάτι μέσα τους για να τον κρεμάσω", αναφέροντας πώς μια κρατική κυβέρνηση μπορεί να βρει πτυχές στη ζωή ενός ατόμου προκειμένου να διώξει ή να εκβιάσει αυτό το άτομο. Ο Schneier υποστήριξε επίσης ότι «πάρα πολλοί χαρακτηρίζουν εσφαλμένα τη συζήτηση ως« ασφάλεια έναντι απορρήτου ». Η πραγματική επιλογή είναι η ελευθερία έναντι του ελέγχου. "

5. Ο Harvey A. Silverglate υπολόγισε ότι ο κοινός άνθρωπος, κατά μέσο όρο, διαπράττει κατά λάθος τρεις κακουργήματα την ημέρα στις ΗΠΑ.

6. Ο Emilio Mordini, φιλόσοφος και ψυχαναλυτής, υποστήριξε ότι το επιχείρημα «τίποτα να κρύψει» είναι εγγενώς παράδοξο. Οι άνθρωποι δεν χρειάζεται να έχουν "κάτι να κρύψουν" για να κρύψουν "κάτι". Αυτό που κρύβεται δεν είναι απαραίτητα σχετικό, ισχυρίζεται ο Μορντίνι. Αντ 'αυτού, υποστηρίζει ότι μια οικεία περιοχή που μπορεί να είναι τόσο κρυφή όσο και περιορισμένη στην πρόσβαση είναι απαραίτητη αφού, από ψυχολογική άποψη, γινόμαστε άτομα μέσω της ανακάλυψης ότι θα μπορούσαμε να κρύψουμε κάτι σε άλλους.

7. Ο Julian Assange δήλωσε: "Δεν υπάρχει ακόμη δολοφονική απάντηση. Ο Jacob Appelbaum (@ioerror) έχει μια έξυπνη απάντηση, ζητώντας από ανθρώπους που το λένε να του παραδώσουν το τηλέφωνό τους ξεκλειδωμένο και να τραβήξουν το παντελόνι τους. Η εκδοχή μου είναι να πω, «καλά, αν είσαι τόσο βαρετός, τότε δεν πρέπει να σου μιλάμε, ούτε και κανένας άλλος», αλλά φιλοσοφικά, η πραγματική απάντηση είναι αυτή: Η μαζική παρακολούθηση είναι μια μαζική διαρθρωτική αλλαγή. Όταν η κοινωνία πάει άσχημα, πηγαίνει για να σας πάει μαζί του, ακόμα κι αν είστε το πιο τρελό άτομο στη γη. "

8. Ο Ignacio Cofone, καθηγητής νομικής, υποστηρίζει ότι το επιχείρημα είναι λάθος με τους δικούς του όρους, διότι, όταν οι άνθρωποι αποκαλύπτουν σχετικές πληροφορίες σε άλλους, αποκαλύπτουν επίσης άσχετες πληροφορίες. Αυτές οι άσχετες πληροφορίες έχουν κόστος απορρήτου και μπορούν να οδηγήσουν σε άλλες βλάβες, όπως διακρίσεις.

***

## Άλλες καμπάνιες κατά της Google

Αυτή είναι μια λίστα με άλλες αξιοσημείωτες καμπάνιες κατά της Google. Αυτή η λίστα δεν είναι πλήρης. Μπορείς να βοηθήσεις επεκτείνοντας το.

### Ανεπαρκής

[Scroogled - Από τη Microsoft (Νοέμβριος 2012 έως 2014)] (https://en.wikipedia.org/wiki/Scroogled)

_Δεν υπάρχουν άλλες καταχωρήσεις αυτή τη στιγμή._

### Σε εξέλιξη

_ Αυτή η λίστα είναι προς το παρόν κενή._

***

## Αντιμετώπιση άλλων επιχειρημάτων

Υπάρχουν ορισμένα επιχειρήματα που κάνουν οι άνθρωποι για να δικαιολογήσουν το Google. Ένα από τα πρώτα μεγάλα έχει ήδη αποσυνδεθεί [εδώ] (# Απόρρητο), αλλά εδώ είναι μερικά άλλα:

### Ευκολία

Ναι, τα προϊόντα Google φαίνεται βολικά. Ωστόσο, ανταλλάσσετε ό, τι είναι καλό για ευκολία, συμπεριλαμβανομένης της ασφάλειας, του απορρήτου και της αξιοπιστίας. Η Google γίνεται πιο αργή με την πάροδο των ετών και οι διακομιστές τους έχουν μειωθεί όλο και περισσότερο. Αυτήν τη στιγμή, οι διακομιστές Google κατεβαίνουν για περίπου μία ώρα 1-2 φορές το μήνα (κυρίως YouTube)

Δυστυχώς, λόγω της εξάρτησης των κοινωνιών από το Google, η Google έχει κυριαρχήσει στο Διαδίκτυο και επιδιώκει να ελέγχει όλο και περισσότερο. Το 2012, όταν η Google έπεσε για 5 λεπτά, αναφέρθηκε ότι η ** παγκόσμια ** κίνηση στο Διαδίκτυο ** μειώθηκε κατά 40% ** Η Google μειώνεται συχνά για 1-2 ώρες και με την [απόλυση της ομάδας δεοντολογίας] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) μεταξύ άλλων, θα γίνουν όλο και λιγότερο βολικά.

Η ευκολία δεν είναι πάντα καλό πράγμα. Θα πρέπει να γνωρίζετε τι συμβαίνει και να είστε προετοιμασμένοι για το πότε θα πέσουν, καθώς δεν υπάρχει τρόπος να μην πέφτει ο διακομιστής κάθε φορά.

Το Google επίσης δεν είναι τόσο βολικό όσο νομίζετε. Υπάρχουν και άλλοι πολύ πιο βολικοί ιστότοποι. Η Google δεν είναι καθόλου βολική, όταν λαμβάνετε υπόψη τις αναστολές και τους τερματισμούς των τυχαίων λογαριασμών τους χωρίς απάντηση (εκτός αν τραβήξετε αρκετή προσοχή στον λογαριασμό στο twitter Google ή μηνύσετε τα $ 100.000.000 ή περισσότερα) τότε σας εκμεταλλεύτηκαν, σας έβγαλαν και σε ανάγκασε να ουρλιάσεις σε ένα μαξιλάρι, όπου κανείς δεν μπορούσε να ακούσει τις κραυγές σουγια βοήθεια.

### Γιατί έχει σημασία, είναι πάρα πολύ αργά

Αυτό είναι ένα λιγότερο κοινό επιχείρημα, αλλά χρειάζεται εξήγηση. Με την τρέχουσα κατάσταση, οι περισσότερες κυβερνήσεις του κόσμου, μαζί με αρκετές ισχυρές εταιρείες φαίνεται να γνωρίζουν κάθε σας κίνηση, γιατί γιατί ακόμη και να ασχοληθείτε με την απομάκρυνσή της; Η απάντηση είναι απλή: ** αξίζετε καλύτερα **. Εάν καταφέρετε να ξεφύγετε από αυτές σε αυτό το σημείο, είναι πιο δύσκολο για αυτούς να παρακολουθούν τις κινήσεις σας περαιτέρω και μπορείτε να δημιουργήσετε μια νέα πιο ιδιωτική ζωή.

[1 πηγή] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Παρεμπιπτόντως, έδωσα το δωρεάν βραβείο Reddit σε αυτήν την ανάρτηση κάθε φορά που την λαμβάνω για πάνω από μία εβδομάδα τώρα (μαζί με και τα 500 δωρεάν νομίσματά μου) για να βελτιώσω αυτό το θέμα. Μέχρι στιγμής, έχω δώσει αυτήν την ανάρτηση πάνω από 14 δωρεάν βραβεία. Δεν είναι πολλά, αλλά τα μικρά πράγματα μπορούν να έχουν μεγάλο αντίκτυπο, ανάλογα με το πώς γίνεται αντιληπτό και από ποιον.

### Αλλα

Δεν έχω άλλα επιχειρήματα αυτή τη στιγμή.

_Αυτή η λίστα δεν είναι πλήρης_

***

## Πηγές

Αντίγραφο:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Κριτική) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay - δείγματα / τίποτα-απόκρυψη-επιχείρημα-έχει-τίποτα-να πούμε /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501] [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -και) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / Where-do-google-draw-the-data-συλλογή-γραμμή) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / τεχνολογία / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- αξιώσεις-για λογαριασμό-5-εκατομμυρίων χρηστών iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / πληροφορίαon-technology / 2014/01 / what-google-can-πραγματικά-do-with-nest-or-πραγματικά-nests-data /) [i] (https://www.cbsnews.com/news/google-education -spies-on-συλλέγει-δεδομένα-σε-εκατομμύρια-παιδιά-κατηγορίες-αγωγή-νέο-Μεξικό-γενικός εισαγγελέας /) [v] (https://www.nationalreview.com/2018/04/the- student-data-mining-scandal-under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [γ] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did -have-κάτι-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Άλλες πηγές:

[Five eyes Alliance] (https://en.wikipedia.org/wiki/Five_Eyes) [δεκαεννέα ογδόντα τέσσερα] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Λήψη συνδέσμων

[Λήψη Firefox] (https://www.mozilla.org/en-US/firefox/new/) [Λήψη προγράμματος περιήγησης Tor] (https://www.torproject.org/download/) [Άλλο / μη διαθέσιμο] (https : //www.example.com)

***

## Η εμπειρία μου στο degoogling

Τελικά άρχισα να βλέπω τα προβλήματα με τη μεγάλη τεχνολογία το 2018 και άρχισα να αποκλείω. Τους πρώτους μήνες, σημείωσα σημαντική πρόοδο. Μειώθηκε πάρα πολύ από τότε.


### Από τι άλλαξα

Google Chrome -> Firefox / Tor

Αναζήτηση Google -> DuckDuckGo (προεπιλογή) / Ecosia (όταν μου αρέσει) / Bing (σπάνια)

GMail - ProtonMail (δεν έχει αλλάξει ακόμη πλήρως)

Ιστότοποι Google -> Self hosting (δεν έχει αλλάξει ακόμη πλήρως)

Google+ -> Σπάνια χρησιμοποιήθηκε, διαγράφηκε λόγω του αποκλεισμού του

Έγγραφα Google -> Ποτέ δεν χρησιμοποιήθηκε, απλώς χρησιμοποιώ το Microsoft Word 2013 (πριν από το 2019) και το LibreOffice (2019 και μετά).

Φύλλα Google -> Ποτέ δεν χρησιμοποιήθηκε, απλώς χρησιμοποιώ το Microsoft Excel 2013 (πριν από το 2019) και το LibreOffice (2019 και μετά).

Παρουσιάσεις Google -> Ποτέ δεν χρησιμοποιήθηκε, απλώς χρησιμοποιώ το Microsoft PowerPoint 2013 (πριν από το 2019) και το LibreOffice (2019 και μετά).

Σχέδια Google -> Ποτέ δεν χρησιμοποιήθηκε, απλώς χρησιμοποιώ το LibreOffice (2019 και μετά).

Gerrit -> Ποτέ δεν χρησιμοποιείται, απλώς χρησιμοποιώ το GitHub (τρέχουσα προεπιλογή), το GitLab, το BitBucket και το SourceForge.

Φωτογραφίες Google -> Δεν χρησιμοποιήθηκε ποτέ

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-σήμερα)

Χάρτες Google -> OpenStreetMaps / Apple Maps

Go - Κάνοντας μια ειδική εξαίρεση, αλλά δεν χρησιμοποιείται ως λειτουργική γλώσσα προγραμματισμού

Dart - Κάνοντας μια ειδική εξαίρεση, αλλά δεν χρησιμοποιείται ως λειτουργική γλώσσα προγραμματισμού

Flutter - Κάνοντας μια ειδική εξαίρεση, αλλά δεν χρησιμοποιείται ως λειτουργική γλώσσα προγραμματισμού

Google Earth -> OpenStreetMaps / Χάρτες Apple

Google Streetview -> Ποτέ δεν χρησιμοποιήθηκε, το βρίσκω πολύ ανατριχιαστικό

Google Fi -> Δεν χρησιμοποιήθηκε ποτέ

Ημερολόγιο Google -> Δεν χρησιμοποιήθηκε ποτέ

Αριθμομηχανή Google -> Κυριολεκτικά οποιαδήποτε άλλη εφαρμογή αριθμομηχανής, ακόμη και ένα τερματικό Linux που λειτουργεί σε λειτουργία Python, αν το θέλω

Google Nest -> Δεν χρησιμοποιήθηκε ποτέ

Google AMP -> Δεν χρησιμοποιήθηκε ποτέ

Google VPN -> Ποτέ δεν χρησιμοποιήθηκε, επίσης οξύμορρο

Google Pay -> Δεν χρησιμοποιήθηκε ποτέ

Google Summer of Code -> Ποτέ δεν συμμετείχα

Tenor -> Άλλοι ιστότοποι GIF, αν και τα GIF δεν είναι πολύ σημαντικά για μένα. Συνήθως λαμβάνω αρχεία GIF από εικόνες DuckDuckGo, Imgur, Reddit ή άλλους ιστότοπους.

Blockly -> Δεν χρησιμοποιείται πλέον, δεν είμαι σίγουρος αν το Scratch έτρεξε απευθείας μπλοκ. Έγινα λειτουργικός προγραμματιστής το 2017 και μετά και μεγάλωσα από το Scratch.

GBoard -> Χρησιμοποιήθηκε μία φορά, αλλά εγκαταλείφθηκε

Google Glass -> Ποτέ δεν χρησιμοποιήθηκε, θεωρήθηκε μικρό παιδί αλλά αποφάσισε να μην πάρει ένα / χρησιμοποιήσει ένα αν είχα την επιλογή

_Η λίστα μπορεί να είναι ελλιπής._

### Προϊόντα από τα οποία δεν μπορώ να ξεφύγω

Από τις 25 Φεβρουαρίου 2021, αυτά είναι τα προϊόντα της Google που με εμποδίζουν να απενεργοποιήσω πλήρως:

1. YouTube

2. Android

3. Google Play Store

4. GMail (μόνο για σχολείο και ορισμένους ιστότοπους)

5. Google Classroom (μόνο για σχολείο)

6. Μετάφραση Google

7. Λογαριασμός Google

8. Ιστότοποι Google (καθώς η Google παραβιάζει τους νόμους του ΓΚΠΔ (και μπορεί να επιβληθεί πρόστιμο 5.000.000,00 ευρώ έως ότου επιδιορθωθεί) και απαγορεύοντας τη λήψη αυτού του προϊόντος)

Έχω απενεργοποιήσει τα πάντα.

***

## Το Go είναι κακό

Η Google πέρασε από τη γλώσσα προγραμματισμού με βάση τους πράκτορες του 2003 "Go!" Με τη γλώσσα προγραμματισμού τους "Go" (από το 2009, 6 χρόνια αργότερα) και ισχυρίστηκε ότι η γλώσσα τους δεν θα επηρέαζε καθόλου την άλλη γλώσσα. Η Google επικρίθηκε έντονα γι 'αυτό, καθώς το σύνθημά τους «Να μην είναι κακό» ήταν ακόμα ενεργό εκείνη τη στιγμή και αυτό είναι ένα από τα πολλά περιστατικά που αποσύρθηκαν το ΜΟΤΟ.

Στο τέλος, η ανάπτυξη του "Go!" Σταμάτησε, ενώ το "Go" έγινε όλο και πιο κοινό. Η Google ισχυρίστηκε ότι δεν θα περιπλανηθεί στο "Go!", Αλλά στο τέλος το έκαναν και το έφυγαν (από τις 9 Απριλίου 2021)

[Διαβάστε περισσότερα σχετικά με το Go και τον τρόπο εναλλαγής εδώ] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Χρήση DRM

Η Google χρησιμοποιεί DRM (Διαχείριση ψηφιακών περιορισμών) μέσω της "υπηρεσίας" WideVine DRM και άλλων μορφών. Ο στόχος του DRM είναι να καταστρέψει το ανοιχτό Διαδίκτυο και να δώσει στις εταιρείες μονοπωλιακή δύναμη έναντι των χρηστών. Θα πρέπει να απαλλαγείτε εντελώς από το WideVine, ανεξάρτητα από το κόστος.

[Διαβάστε περισσότερα για το WideVine και τα προβλήματά του εδώ] (https://github.com/Degoogle-your-life/Its-time-to-cut-WideVine-DRM)

***

## Συχνές παρανοήσεις

Αυτή είναι μια λίστα με ορισμένες κοινές παρανοήσεις με τα προϊόντα Google.

### Η Google δεν είναι το Διαδίκτυο

Η αναζήτηση Google / Google δεν είναι το Διαδίκτυο, η αναζήτηση Google είναι απλώς μια μηχανή αναζήτησης, όπως πώς δεν γίνεται κάθε παιχνίδι για μια πλατφόρμα Nintendo από τη Nintendo, αλλά διαθέτει άδεια από τη Nintendo, αλλά σε πολύ μεγαλύτερο βαθμό. Εάν όλοι οι διακομιστές Googles επρόκειτο να καταστραφούν ταυτόχρονα, μόνο οι Ιστότοποι Google όπως το YouTube, το Gmail, τα Έγγραφα Google, η αναζήτηση Google κ.λπ. θα είχαν φύγει, αλλά το μεγαλύτερο μέρος του Διαδικτύου θα εξακολουθούσε να είναι εκεί (Wikipedia, Stackoverflow, GitHub, σε όλους τους ιστότοπους της Microsoft, NYTimes, Samsung, TikTok, κ.λπ.) ενδέχεται να χάσουν τη λειτουργία σύνδεσης και ανάλυσης της Google, αλλά θα εξακολουθούν να είναι λειτουργικές (εκτός εάν είχαν προγραμματιστεί κακώς και βασίζονταν απευθείας στο Google)

***

## Internet Explorer 6 και Chrome

Το Google Chrome γίνεται ο νέος Internet Explorer 6. Όταν το Google Chrome κυκλοφόρησε αρχικά, ο Firefox ήταν το κυρίαρχο πρόγραμμα περιήγησης και είχε ως επί το πλείστον σκοτώσει την κοινή χρήση αγορών του Internet Explorer (η οποία ξεπέρασε το 96% πριν από εκατομμύρια άτομα που άλλαξαν στον Firefox και σε άλλα προγράμματα περιήγησης) όταν το Google Chrome βγήκε, οι άνθρωποι άλλαξαν λόγω της ταχύτητάς του και ήταν από την Google (η οποία δεν θεωρήθηκε τόσο κακή εκείνη την εποχή, καθώς τα περισσότερα ζητήματα απορρήτου δεν είχαν ακόμη αποκαλυφθεί) το Google Chrome αρχικά σεβάστηκε τα πρότυπα ιστού (κάτι που έκανε ο Firefox που σκότωσε το Internet Explorer με 96% κοινή χρήση του προγράμματος περιήγησης), ωστόσο, καθώς το Google Chromes markethare αυξήθηκε, η Google άρχισε να αφαιρεί όλο και περισσότερες δυνατότητες, προσθέτοντας περισσότερα spyware και σταμάτησε να δέχεται πρότυπα ιστού, το Google Chrome έχει γίνει ο νέος Internet Explorer 6.

Το κύριο πρόβλημα αυτή τη στιγμή είναι οι ιστότοποι που είναι μόνο Chrome και δεν λειτουργούν σε άλλα προγράμματα περιήγησης, καθώς οι προγραμματιστές τους αποφάσισαν ότι δεν ήθελαν το 30-40% των χρηστών του Διαδικτύου που δεν χρησιμοποιούν το Chrome να χρησιμοποιούν τον ιστότοπό τους.

Ακόμη και η ίδια η Google δημιουργεί μόνο τους ιστότοπούς τους Chrome. Για παράδειγμα, η αναζήτηση Google θα σας ζητήσει να κάνετε λήψη του Chrome 3 φορές κάθε 10 δευτερόλεπτα εάν εντοπίσει ότι δεν χρησιμοποιείτε το Google Chrome (ακόμη και άλλα προγράμματα περιήγησης με βάση το Chromium όπως το Brave επηρεάζονται) και ιστότοποι όπως το Google Earth δεν επιτρέπουν στους χρήστες του Firefox να χρησιμοποιούν τον ιστότοπό τους (από το 2020) και η Μετάφραση Google δεν υποστηρίζει φωνητική είσοδο στον Firefox και σε άλλα προγράμματα περιήγησης Chrome εκτός Google.

### Το πρόβλημα με το Brave

Άλλα προγράμματα περιήγησης που βασίζονται στο Chromium, όπως το Brave και το Microsoft Edge δεν είναι εντελώς απαλλαγμένα από λογισμικό υποκλοπής Google. Το Brave συνιστάται συνήθως από τη λάθος πλευρά της κοινότητας απορρήτου, αλλά το Brave εξακολουθεί να αποτελεί πρόβλημα, καθώς χρησιμοποιεί το Chromium. Το Διαδίκτυο δεν πρέπει να αποτελείται από προγράμματα περιήγησης Chromium μόνο, θα πρέπει να υπάρχει μια ποικιλία επιλογών. Ο γενναίος είναι ο λάθος τρόπος να πάει.

[Διαβάστε περισσότερα σχετικά με την απενεργοποίηση από το Google Chrome / Chromium εδώ] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Διαβάστε περισσότερα σχετικά με την απενεργοποίηση από το ChromeOS / ChromiumOS (Chromebook / Chromebox / Chromeblets / ChromeBits / ChromeETC) εδώ] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Ανανέωση απορρήτου Faux

Η Google προσπαθεί να πει στον κόσμο ότι ενδιαφέρεται για το απόρρητο, αφού ήταν ήδη πολύ αργά. Συνεχίζουν να ισχυρίζονται ότι σέβονται το απόρρητο των χρηστών, αλλά εξακολουθούν να μην επιδιορθώνουν όλα τα προβλήματα απορρήτου τους.

### Ο ανοιχτός κώδικας δεν μπορεί να είναι μερικός

Ο ανοιχτός κώδικας δεν μπορεί να είναι μερικός. Η Google είναι απόδειξη αυτού. Κάθε bit και byte του πηγαίου κώδικα πρέπει να είναι ορατό στο κοινό, χωρίς καν να κρύβεται ούτε το 8ο του byte.

Έργα όπως το Android και το ChromeOS είναι εν μέρει ανοιχτού κώδικα, αλλά περιέχουν την πλειονότητα ιδιόκτητων στοιχείων spyware.

### Οξυμόρων

Το Google VPN είναι ένα οξύμωρο. Η Google δεν ενδιαφέρεται για το απόρρητο και ένα εικονικό ιδιωτικό δίκτυο (VPN) από μια εταιρεία όπως αυτές θα ήταν μια από τις χειρότερες δυνατές επιλογές για μια υπηρεσία VPN.

***

## Κακή απόδοση

Η Google δεν ενδιαφέρεται για την απόδοση των προϊόντων τους τουλάχιστον από το 2017, καθώς το τελευταίο λογισμικό συγκριτικής αξιολόγησης (Google Octane) διακόπηκε το 2017.

***

## Κακή διαχείριση έργου

Η Google διαθέτει ένα πολύ κακό σύστημα εσωτερικής διαχείρισης έργων. Μερικά κοινά παραδείγματα προγραμμάτων που έχουν ολοένα και πιο υποβαθμιστεί περιλαμβάνουν τη μουσική του Google Duo και του YouTube (πρώην Μουσική Google Play)

Στο σύστημα εσωτερικής ανάπτυξης του Google, 1 εφαρμογή οδηγεί σε μια άλλη εφαρμογή με τη μισή λειτουργικότητα και στη συνέχεια η αρχική εφαρμογή διαγράφεται. Λίγα χρόνια αργότερα, δημιουργείται μια νέα εφαρμογή με 75% λιγότερη λειτουργικότητα και, στη συνέχεια, καταργείται η εφαρμογή με 50% λειτουργικότητα, ακολουθούμενη από μια νέα εφαρμογή με 87,5% της λειτουργικότητας που δημιουργείται και, στη συνέχεια, η εφαρμογή με λειτουργικότητα 75% διακόπτεται , και ούτω καθεξής.

***

## Φρικτό ή καθόλου εποπτεία υπηρεσιών

Το YouTube είναι το πιο κοινό παράδειγμα στον κόσμο της κακής εποπτείας που δημιουργεί τη χειρότερη πλατφόρμα που υπάρχει. Το Google φαίνεται επίσης ότι το YouTube δεν είναι παιδιά του YouTube.

Για το YouTube, το απεχθές φιλοναζιστικό και το White Supremacist σερβίρεται στους χρήστες με σκοπό περισσότερο χρόνο αφοσίωσης και περισσότερα χρήματα. Η Google έχει επίσης κάνει πολλάανόητα πράγματα με τη μέτρησή τους, όπως η έγκριση ενός βίντεο Christian Anal Sex ως περιεχομένου «για παιδιά», ενώ ταυτόχρονα περιορίζει το βίντεο. Επίσης, δεν είναι πολύ ασυνήθιστο να βλέπει κανείς πορνογραφικές ή εντυπωσιακές διαφημίσεις κάτω από το βίντεο Baby Shark, μαζί με διάφορα άλλα περιεχόμενα για παιδιά.

Οι χρήστες του YouTube διαμαρτύρονται πολύ συχνά για την κακή εποπτεία στο YouTube για κακό περιεχόμενο (όπως τα παραδείγματα που αναφέρονται παραπάνω), ενώ οι χρήστες μπορούν να διαγράψουν τα βίντεό τους τυχαία χωρίς κανένα λόγο χωρίς δυνατότητα κατάργησης, καθώς και οι χρήστες τιμωρούνται για οποιαδήποτε μορφή ορκίσματος, Ακόμα και πολύ μικρές περιπτώσεις, όπως λένε ότι οι χρήστες "χάλια" συγκρίνουν συνήθως το YouTube με τη [Σοβιετική Ένωση] (https://en.wikipedia.org/wiki/Soviet_Union) στην εποχή του Στάλιν, λόγω αυτών των άνισων τιμωριών.

Το 2021, η Google ανακοίνωσε ότι θα τοποθετήσει διαφημίσεις σε όλα τα βίντεο, παρά το ότι το βίντεο έχει δαιμονοποιηθεί (έτσι ώστε η Google να κερδίζει χρήματα, αλλά ο δημιουργός δεν) αυτό δεν σχετίζεται με τη μετριοπάθεια πάρα πολύ, αλλά είναι σημαντικό να σημειωθεί.

Το YouTube είναι εποπτευόμενο (αν και πολύ άσχημα), αλλά η υπηρεσία διαφημίσεων Google που τους κάνει τα περισσότερα από τα χρήματά τους φαίνεται να έχει μικρή έως καθόλου μετριοπάθεια.

[Διαβάστε περισσότερα σχετικά με τα ζητήματα εποπτείας του YouTube και πώς να κάνετε εναλλαγή από το YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Διαφημίσεις για το Google Play δημιουργούνται από bot farms, μπορείτε να καταλάβετε με τα ίδια σενάρια διαφημίσεων που χρησιμοποιούνται από εκατοντάδες εταιρείες με μικρές αλλαγές και καμία σχέση με το προϊόν (κοινά παραδείγματα: Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City και χιλιάδες ακόμη) μαζί με μια ακμάζουσα κακόβουλη τάση διαφημίσεων που ισχυρίζονται ότι οι χρήστες μπορούν να κερδίσουν χρήματα παίζοντας παιχνίδια, ακούγοντας μουσική κ.λπ. Το PayPal δεν έχει σχολιάσει αυτό, αλλά είναι προφανές ότι πρόκειται για απάτη, σαν να μπορούσατε να κάνετε πάνω από 10.000 $ σε λιγότερο από 20 δευτερόλεπτα παίζοντας ένα εγγυημένο παιχνίδι, κανείς δεν θα έκανε δουλειά και θα έκανε αυτό αντ 'αυτού, κάτι που είναι αδύνατο και μια επιχείρηση δεν θα μπορούσε να λειτουργήσει έτσι. Αυτή η προφανής απάτη έχει γίνει ισχυρή από το 2019, και τώρα οι εκμεταλλεύσεις bot που παράγουν αυτές τις διαφημίσεις μάχονται μεταξύ τους στις δικές τους διαφημίσεις.

Αρκετές διαφημίσεις είναι επίσης πολύ άσεμνες και προσπαθούν να κάνουν τους χρήστες (οι περισσότεροι από αυτούς είναι χρήστες κάτω των 13 ετών ή bots) να κάνουν κλικ σε σεξουαλικό χειρισμό.

Πολλές εφαρμογές χρησιμοποιούν bots και astroturf τα προϊόντα τους, οπότε όποτε γίνεται μια κακή κριτική, οι λογαριασμοί κούκλας θα αρχίσουν να δημοσιεύουν κριτικές 5 αστέρων και θα προσπαθήσουν να αναιρέσουν την κριτική σας. [Η Google το κάνει και οι ίδιοι] (# Astroturfing)

[Διαβάστε περισσότερα σχετικά με ζητήματα με το Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

Γενικός ορισμός [(από τη Wikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

"
Το Astroturfing είναι η πρακτική της απόκρυψης των χορηγών ενός μηνύματος ή ενός οργανισμού (π.χ. πολιτικών, διαφημιστικών, θρησκευτικών ή δημοσίων σχέσεων) ώστε να φαίνεται ότι προέρχεται από και υποστηρίζεται από τους συμμετέχοντες της βάσης. Πρόκειται για μια πρακτική που αποσκοπεί στην παροχή αξιοπιστίας στις δηλώσεις ή τους οργανισμούς, αποκλείοντας πληροφορίες σχετικά με την οικονομική σύνδεση της πηγής. Ο όρος astroturfing προέρχεται από το AstroTurf, μια επωνυμία συνθετικών μοκέτων που έχει σχεδιαστεί για να μοιάζει με φυσικό γρασίδι, ως παιχνίδι στη λέξη "λαϊκή". Η επίπτωση πίσω από τη χρήση του όρου είναι ότι αντί για μια «αληθινή» ή «φυσική» λαϊκή προσπάθεια πίσω από την εν λόγω δραστηριότητα, υπάρχει μια «ψεύτικη» ή «τεχνητή» εμφάνιση υποστήριξης.
"

Η Google έχει ένα ιστορικό αστροστροφής για να φαίνεται ότι δεν κάνουν τίποτα κακό (στη διαδικασία, το αστροτρούρισμα είναι κακό) για παράδειγμα, η δημοσίευση κριτικής της Google σε μια πλατφόρμα όπως το Twitter (στην οποία έχουν λογαριασμό) θα έχει ως αποτέλεσμα πολλοί λογαριασμοί που υπήρχαν για λίγο, αλλά δεν δημοσιεύτηκαν ποτέ πριν βγουν και ισχυρίζονται ότι αυτό που είπατε είναι ψευδές, και στη συνέχεια ισχυρίζεστε ότι η Google είναι η καλύτερη εταιρεία, αλλά έγινε με τρόπο που να μην είναι προφανές ότι αυτά είναι bots για τα περισσότερα Ανθρωποι.

***

## Παράνομες και ανήθικες επιχειρηματικές πρακτικές

Η Google χρησιμοποιεί παράνομες και ανήθικες επιχειρηματικές πρακτικές για την προώθηση του μονοπωλίου τους, όπως η χρήση φορολογικών παραδείσων, η εξωτερική ανάθεση εργασιών και η συνέχιση των παράνομων επεμβατικών δραστηριοτήτων ως κόστος της επιχειρηματικής δραστηριότητας.

### Στην Ευρώπη

Η Ευρώπη έχει μηνύσει συχνά την Google, η μεγαλύτερη αγωγή κατά της παράνομης συμπεριφοράς στο Android, με αποτέλεσμα η Google να λαμβάνει 5.000.000.000 ευρώ (ισοδύναμο με 5.947.083.703,68 δολάρια στις 9 Απριλίου 2021 χρήματα)

### Στη Βόρεια Αμερική

Οι Ηνωμένες Πολιτείες δεν έχουν δώσει ακόμη αρκετά πρόστιμο στην Google, σε σύγκριση με το πρόστιμο των 5.000.000.000 ευρώ στην Ευρώπη.

### Διαμάχες

Η Google δεν νοιάζεται για ένα πρόβλημα έως ότου δημιουργήσει μια διαμάχη, τότε θα κάνουν μια κακή προσπάθεια να το επιδιορθώσει, αρκεί για να εξαφανιστεί προσωρινά η διαμάχη και το πρόβλημα στη συνέχεια χειροτερεύει εκθετικά μέχρι να δημιουργήσει μια άλλη διαμάχη και ο κύκλος συνεχίζεται. Απλά δεν ενδιαφέρονται αρκετά για να κάνουν κάτι σοβαρό γι 'αυτό.

***

## Η Google είναι αυτοματοποιημένη

Ως company, το Google είναι ως επί το πλείστον αυτοματοποιημένο, με λιγότερη συγκράτηση από τον αυτοματισμό.

Μια εταιρεία δεν πρέπει να είναι πλήρως αυτοματοποιημένη. Το Google είναι ένα παράδειγμα αυτού. Η εποπτεία είναι φρικτή όταν γίνεται μόνο από AI, το YouTube είναι ένα καλό παράδειγμα, ακόμη και με τους επιπλέον λίγους (εκατοντάδες ή ίσως χίλιους) ανθρώπους να εποπτεύουν τον ιστότοπο, όπου είναι προφανώς τόσο κακό που οι περισσότεροι από αυτούς πρέπει να κάνουν θεραπεία ενώ εργάζονται.

***

## Android

Το Android ανήκει στην Google. Μέρος του Open Handset Alliance (το οποίο δεν ήταν ανοιχτό από το Android) το Android έχει γίνει ένα άλλο μονοπώλιο για την Google και είναι πολύ δύσκολο να ξεφύγει.

Το Android έχει αναφερθεί ότι τηλεφωνεί στο Google τουλάχιστον 10 φορές την ημέρα και παρά το γεγονός ότι είναι μερικώς ανοιχτό, εξακολουθεί να λειτουργεί έντονα ως λογισμικό υποκλοπής spyware.

Αρκετά έργα έχουν δημιουργηθεί για εναλλαγή από το Android, αλλά απαιτούν ριζοβολία της συσκευής σας. Αυτό απλά δεν είναι πλέον δυνατό για συγκεκριμένα τηλέφωνα Samsung στις ΗΠΑ, λόγω του Knox DRM. Οι κοινές εναλλακτικές λύσεις για το Android περιλαμβάνουν iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch και PiPhone (Το Pi Phone είναι μια μάρκα τηλεφώνων που εκτελούν διάφορα συστήματα Linux σε μια φορητή συσκευή, όπως Fedora, Ubuntu, Arch κ.λπ.)

[Δείτε την έρευνά μου για τη λειτουργία μιας απενεργοποιημένης εικονικής μηχανής Android] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Δείτε πώς να κάνετε degoogle από Android] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Μικρές ενέργειες για βοήθεια

Η διάδοση της ευαισθητοποίησης με κάθε δυνατό τρόπο είναι σημαντική. Για μένα, δεν μιλάω συχνά συχνά για degoogling, και γράφω άρθρα, αλλά έχω επίσης μια μικρή μικρή συνήθεια, όπου δίνω το καθημερινό δωρεάν βραβείο Reddit στην καρφιτσωμένη ανάρτηση στο r / degoogle για να ευαισθητοποιήσω. Μέχρι στιγμής, έχω δώσει σχεδόν 30 βραβεία στην καρφιτσωμένη θέση (Ξόδεψα επίσης 500 από τα δωρεάν νομίσματά μου σε 10 βραβεία για αυτήν την ανάρτηση)

***

## Αξιόπιστο

Η Google δεν μπορεί να είναι αξιόπιστη και ποτέ δεν μπορεί να είναι αξιόπιστη. Έχουν περάσει εντελώς από το "μην είσαι κακός" (ήταν πάντα κακοί) στο να είσαι εντελώς κακός και να μην προσπαθείς να το κρύψεις.

***

## Άλλα πράγματα που μπορείτε να δείτε

[Το Google Graveyard (killbygoogle.com) - μια ταξινομημένη λίστα με τα 224+ προϊόντα που έχει σκοτώσει η Google] (https://killedbygoogle.com/)

> [Σύνδεσμος GitHub] (https://github.com/codyogden/killedbygoogle)

[Ένωση εργαζομένων αλφάβητου - Η νέα ένωση εργαζομένων στο Google με περισσότερα από 800 μέλη] (https://alphabetworkersunion.org/people/our-union/)

[Δεν θέλετε να χωρίσετε με το Πασχαλινό αυγό του δεινοσαύρου; Αυτός ο ιστότοπος σας καλύπτει] (https://chromedino.com/)

Υπάρχουν άλλες εναλλακτικές λύσεις, απλώς αναζητήστε τις.

***

Απαιτείται έλεγχος γεγονότων για αυτό το άρθρο

***

## Πληροφορίες αρχείου

Τύπος αρχείου: "Markdown (* .md)"

Αριθμός γραμμών (συμπεριλαμβανομένων των κενών γραμμών και της γραμμής μεταγλωττιστή): "968"

Έκδοση αρχείου: "6 (Κυριακή, 18 Απριλίου 2021 στις 4:18 μ.μ.)"

***

### Κατάσταση λογισμικού

Όλα τα έργα μου είναι δωρεάν μερικοί περιορισμοί. Το DRM (** D ** igital ** R ** estriction ** M ** anagement) δεν υπάρχει σε κανένα από τα έργα μου.

! [DRM-free_label.en.svg] (DRM-free_label.el.svg)

Αυτό το αυτοκόλλητο υποστηρίζεται από το Ίδρυμα Ελεύθερου Λογισμικού. Ποτέ δεν σκοπεύω να συμπεριλάβω το DRM στα έργα μου.

Χρησιμοποιώ τη συντομογραφία "Διαχείριση ψηφιακών περιορισμών" αντί της πιο γνωστής "Διαχείριση ψηφιακών δικαιωμάτων", καθώς ο κοινός τρόπος αντιμετώπισης είναι ψευδής, δεν υπάρχουν δικαιώματα με το DRM. Η ορθογραφία "Διαχείριση ψηφιακών περιορισμών" είναι πιο ακριβής και υποστηρίζεται από τον [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) και το [Ίδρυμα Ελεύθερου Λογισμικού (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Αυτή η ενότητα χρησιμοποιείται για την ευαισθητοποίηση σχετικά με τα προβλήματα με το DRM, καθώς και για τη διαμαρτυρία του. Το DRM είναι ελαττωματικό από τη σχεδίαση και αποτελεί μεγάλη απειλή για όλους τους χρήστες υπολογιστών και την ελευθερία του λογισμικού.

Πιστωτική εικόνα: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Πληροφορίες χορηγού

! [SponsorButton.png] (SponsorButton.png) <- Μην κάνετε κλικ σε αυτό το κουμπί, δεν λειτουργεί, είναι απλώς μια εικόνα. Το πραγματικό κουμπί βρίσκεται στο επάνω μέρος της σελίδας στη δεξιά γωνία (<- L ** R ** ->)

Μπορείτε να υποστηρίξετε αυτό το έργο αν θέλετε, αλλά προσδιορίστε σε τι θέλετε να δωρίσετε. [Δείτε τα χρήματα που μπορείτε να δωρίσετε εδώ] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Μπορείτε να δείτε άλλες πληροφορίες χορηγών [εδώ] (https://github.com/seanpm2001/Sponsor-info/)

Δοκίμασέ το! Το κουμπί χορηγού βρίσκεται ακριβώς δίπλα στο κουμπί ρολογιού / ξετυλίγματος.

***

## Ιστορικό αρχείων



 * Ξεκίνησε το αρχείο

> * Προστέθηκε η ενότητα τίτλου

> * Προστέθηκε το ευρετήριο

> * Προστέθηκε η ενότητα σχετικά

> * Προστέθηκε η ενότητα Wiki

> * Προστέθηκε η ενότητα ιστορικού εκδόσεων

> * Προστέθηκε η ενότητα ζητημάτων.

> * Προστέθηκε η ενότητα προηγούμενων ζητημάτων

> * Προστέθηκε η προηγούμενη ενότητα αιτήσεων τραβήγματος

> * Προστέθηκε η ενότητα ενεργών αιτήσεων τραβήγματος

> * Προστέθηκε η ενότητα συνεισφερόντων

> * Προστέθηκε η συνεισφορά ενότητα

> * Προστέθηκε η ενότητα σχετικά με το README

> * Προστέθηκε η ενότητα Ιστορικό εκδόσεων README

> * Προστέθηκε η ενότητα πόρων

> * Προστέθηκε μια ενότητα κατάστασης λογισμικού, με αυτοκόλλητο και μήνυμα DRM

> *Προστέθηκε η ενότητα πληροφοριών χορηγού

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 0.1

Έκδοση 1 (Παρασκευή, 19 Φεβρουαρίου 2021 στις 5:20 μ.μ.)

> Αλλαγές:

> * Ξεκίνησε το αρχείο

> * Προστέθηκε η ενότητα βασικής περιγραφής

> * Προστέθηκε η ενότητα περιγραφής αποθετηρίου

> * Προστέθηκε η λίστα άρθρων, με 14 καταχωρήσεις

>> * Προστέθηκε μια ενότητα "σχετικά άρθρα"

>> * Προστέθηκε μια ενότητα "δείτε επίσης"

> * Προστέθηκε η ενότητα πληροφοριών αρχείου

> * Προστέθηκε η ενότητα ιστορικού αρχείων

> * Προστέθηκε το υποσέλιδο

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 1

Έκδοση 2 (Παρασκευή 19 Φεβρουαρίου 2021 στις 5:26 μ.μ.)

> Αλλαγές:

> * Προστέθηκε η ενότητα κατάστασης μετάφρασης

> * Προστέθηκε η ενότητα Άλλα πράγματα για να δείτε

> * Προστέθηκε η ενότητα απορρήτου

> * Προστέθηκε ένα ευρετήριο

> * Προστέθηκε η υποενότητα κατάστασης λογισμικού

> * Προστέθηκε η άλλη ενότητα καμπανιών κατά της Google

>> * Προστέθηκε η μη λειτουργική υποενότητα

>> * Προστέθηκε η τρέχουσα υποενότητα

> * Προστέθηκε η ενότητα πηγών

> * Προστέθηκε η ενότητα συνδέσμων λήψης

> * Ενημερώθηκε η ενότητα πληροφοριών αρχείου

> * Ενημερώθηκε η ενότητα ιστορικού αρχείων

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 2

Έκδοση 3 (Τετάρτη, 24 Φεβρουαρίου 2021 στις 7:56 μ.μ.)

> Αλλαγές:

> * Ενημερώθηκε το ευρετήριο

> * Αναφέρθηκε το εικονίδιο degoogle και ο νέος οργανισμός GitHub

> * Προστέθηκαν σύνδεσμοι σε νεότερα άρθρα

> * Προστέθηκε η ενότητα "Αντίθετα άλλα επιχειρήματα"

>> * Προστέθηκε το υποτμήμα ευκολίας

>> * Προστέθηκε η ενότητα Γιατί ακόμη και ενοχλεί

>> * Προστέθηκε η άλλη υποενότητα

> * Ενημερώθηκαν ορισμένα δεδομένα

> * Ενημερώθηκε η ενότητα πληροφοριών αρχείου

> * Ενημερώθηκε η ενότητα ιστορικού αρχείων

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 3

Έκδοση 4 (Πέμπτη, 25 Φεβρουαρίου 2021 στις 9:31 μ.μ.)

> Αλλαγές:

> * Προστέθηκαν σύνδεσμοι σε 10 νέα άρθρα

> * Προστέθηκε μια ενότητα σχετικά με την απομόνωση της εμπειρίας μου

> * Ενημερώθηκε το ευρετήριο

> * Ενημερώθηκε η ενότητα πληροφοριών αρχείου

> * Ενημερώθηκε η ενότητα ιστορικού αρχείων

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 4

Έκδοση 5 (Παρασκευή, 9 Απριλίου 2021 στις 6:02 μ.μ.)

_ Υπήρξε έλλειψη ενημερώσεων για το κίνημα κατά του Google τελευταία από μένα, προσπαθώ να επιστρέψω σε αυτό μετά από ένα διάστημα 1+ μηνός ._

> Αλλαγές:

> * Ενημερώθηκε η ενότητα τίτλου

> * Ενημερώθηκε το ευρετήριο

> * Ενημερώθηκε η λίστα γλωσσών: σταθεροί σύνδεσμοι και προστέθηκαν περισσότερες υποστηριζόμενες γλώσσες

> * Ενημερώθηκε η ενότητα κατάστασης του άρθρου, προσθέτοντας 4 συνδέσμους πιρούνι

> * Ενημερώθηκε η ενότητα κατάστασης λογισμικού

> * Προστέθηκε η ενότητα Go is κακό

> * Προστέθηκε η ενότητα Χρήση DRM

> * Προστέθηκε η ενότητα Κοινές παρανοήσεις

>> * Προστέθηκε το Google δεν είναι η υποενότητα Διαδικτύου

> * Προστέθηκε η ενότητα Internet Explorer 6 και Chrome

>> * Προστέθηκε το πρόβλημα με το Brave υποενότητα

> * Προστέθηκε η αφαίρεση απορρήτου του Faux

> * Προστέθηκε το Open source δεν μπορεί να είναι μερική υποενότητα

> * Προστέθηκε η υποενότητα Oxymoron

> * Προστέθηκε η ενότητα Κακή απόδοση

> * Προστέθηκε η ενότητα διαχείρισης έργων Bad

> * Προστέθηκε η ενότητα «Φρικτό ή καθόλου εποπτεία υπηρεσιών»

> * Προστέθηκε η ενότητα Astroturfing

> * Προστέθηκε η ενότητα Παράνομες και ανήθικες επιχειρηματικές πρακτικές

> * Προστέθηκε η υποενότητα In Europe

>> * Προστέθηκε η υποενότητα στη Βόρεια Αμερική

>> * Προστέθηκε η υποενότητα Controversies

> * Προστέθηκε η αυτοματοποιημένη ενότητα της Google

> * Προστέθηκε η ενότητα Android

> * Προστέθηκε η ενότητα Μικρές ενέργειες για βοήθεια

> * Προστέθηκε η ενότητα Untrustable

> * Προστέθηκε η ενότητα πληροφοριών χορηγού

> * Ενημερώθηκε το υποσέλιδο

> * Ενημερώθηκε η ενότητα πληροφοριών αρχείου

> * Ενημερώθηκε η ενότητα ιστορικού αρχείων

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 5

Έκδοση 6 (Κυριακή, 18 Απριλίου 2021 στις 4:18 μ.μ.)

> Αλλαγές:

> * Ενημερώθηκε το ευρετήριο

> * Προστέθηκε μια νέα περιγραφή επισκόπησης

> * Ενημερωμένες πληροφορίες κατάστασης άρθρου

> * Προστέθηκε ένας σύνδεσμος για το νέο άρθρο του Google FLoC

> * Προστέθηκε ένας σύνδεσμος για το άρθρο Wuest 3n Fuchs Degoogle και γενικές πληροφορίες σχετικά με αυτό

> * Ενημερώθηκε η ενότητα πληροφοριών αρχείου

> * Ενημερώθηκε η ενότητα ιστορικού αρχείων

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 6

Έκδοση 7 (Σύντομα διαθέσιμο)

> Αλλαγές:

> * Σύντομα διαθέσιμο

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 7

Έκδοση 8 (Σύντομα διαθέσιμο)

> Αλλαγές:

> * Σύντομα διαθέσιμο

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 8

Έκδοση 9 (Σύντομα διαθέσιμο)

> Αλλαγές:

> * Σύντομα διαθέσιμο

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 9

Έκδοση 10 (Σύντομα διαθέσιμο)

> Αλλαγές:

> * Σύντομα διαθέσιμο

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 10

Έκδοση 11 (Σύντομα διαθέσιμο)

> Αλλαγές:

> * Σύντομα διαθέσιμο

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 11

Έκδοση 12 (Σύντομα διαθέσιμο)

> Αλλαγές:

> * Σύντομα διαθέσιμο

> * Δεν υπάρχουν άλλες αλλαγές στην έκδοση 12

***

## Υποσέλιδο

Φτάσατε στο τέλος αυτού του αρχείου

[[Πίσω στην κορυφή] (# Κορυφή) | [Επιστροφή στο GitHub] (https://github.com))

### EOF

***
