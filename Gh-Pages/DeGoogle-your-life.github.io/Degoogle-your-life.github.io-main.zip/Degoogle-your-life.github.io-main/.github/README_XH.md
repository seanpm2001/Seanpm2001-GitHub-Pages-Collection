***

! [IIMISEBENZI1. Jpeg] (DEGOOGLE1.jpeg)

# Degoogling-Degoogle ubomi bakho

Eli lelona nqaku liphambili lokukhupha ulwazi malunga nolwazi lokuphanda kunye nekhonkco kwamanye amanqaku.

[Jonga uluhlu njengombutho weGitHub] (https://github.com/Degoogle-your-life)

***

_Funda eli nqaku ngolwimi olwahlukileyo: _

Ulwimi lwangoku liyi: ** `IsiNgesi (i-US)` _ (iinguqulelo zinokufuna ukulungiswa ukulungisa isiNgesi endaweni yolwimi oluchanekileyo) _

Uluhlu lweelwimi_

** Kuhlelwe ngo: ** `AZ`

[Ukhetho lokuhlela alufumaneki] (https://github.com/Degoogle-your-Life)

([Afrika Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shareptare] (/. github / README_SQ.md) Albanian | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) IsiArabhu | [hy հայերեն] (/. github / README_HY.md) iArmenia | [az Azrbaycan dili] (/. github / README_AZ.md) isiAzerbaijani | [eu Euskara] (/. /README_EU.md) Basque | [be Беларуская] (/. Github / README_BE.md) Belarusian | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) IBosnia | ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) IsiTshayina (Esenziwe lula) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) IsiTshayina (Esiqhelekileyo) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) isiCroatia | [cs čeština] (/. Github / README_CS .md) Czech | [da dansk] (README_DA.md) Danish | [nl Nederlands] (/. github / README_ NL.md) IsiDatshi | [** en-us English **] (/. github / README.md) IsiNgesi | [EO Esperanto] (/. Github / README_EO.md) Isi-Esperanto | [et Eestlane] (/. github / README_ET.md) Isi-Estonia | [tl isiPhilippines] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) IsiFinnish | [fr français] (/. github / README_FR.md) IsiFrentshi | [Fy Frysk] (/. github / FUNDAE_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) IsiGalician | [ka ქართველი] (/. github / README_KA) IsiGeorgia | [de Deutsch] (/. github / README_DE.md) isiJamani | [el Ελληνικά] (/. github / README_EL.md) isiGrike | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) IsiCreole saseHaiti | [ha Hausa] (/. github / FUNDAE_HA.md) isiHausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) IsiHebhere | [molo हिन्दी] (/. github / README_HI.md) IsiHindi | [hmn Hmong] (/. github / README_HMN.md) IHmong | [hu Magyar] (/. github / README_HU.md) IsiHungary | [yi Íslenska] (/. github / README_IS.md) Isi-Icelandic | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Isi-Icelandic | [ga Gaeilge] (/. github / README_GA.md) isi-Irish | [Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) IsiJapan | [jw Wong jawa] (/. github / README_JW.md) iJavanese | [kn ಕನ್ನಡ] (/. github / FUNDAE_KN.md) IsiKannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / FUNDAE_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) isiKinyarwanda | [ko-mzantsi 韓國 語] (/. github / README_KO_SOUTH.md) IsiKorea (eMzantsi) | [ko-north 문화어] (README_KO_NORTH.md) isiKorea (eMantla) (ASIKUGUQULWA) | [ku Kurdî] (/. github / README_KU.md) isiKurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) isiKyrgyz | [jonga ລາວ] (/. github / README_LO.md) iLao | [la Latine] (/. github / README_LA.md) IsiLatin | [lt Lietuvis] (/. github / README_LT.md) IsiLithuania | [lb Lëtzebuergesch] (/. github / README_LB.md) Isingesi | [mk Македонски] (/. github / README_MK.md) IsiMacedonia | [mg Malagasy] (/. github / README_MG.md) IsiMalagasy | [ms Bahasa Melayu] (/. github / README_MS.md) IsiMalay | [ml മലയാളം] (/. github / README_ML.md) IsiMalayalam | [mt Malti] (/. github / README_MT.md) IsiMalta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) IsiMarathi | [mn Монгол] (/. github / README_MN.md) IsiMongolia | [yam မြန်မာ] (/. github / README_MY.md) iMyanmar (Burmese) | [ne नेपाली] (/. github / README_NE.md) Nepali | [akukho norsk] (/. github / README_NO.md) IsiNorway | [okanye ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (isiOriya) | [ps پښتو] (/. github / README_PS.md) IsiPashto | [fa فارسی] (/. github / README_FA.md) | isiPersi [pl polski] (/. github / README_PL.md) IsiPolish | [pt português] (/. github / README_PT.md) IsiPhuthukezi | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) isiPunjabi | Akukho lwimi lufumanekayo oluqala ngonobumba Q | [ro Română] (/. github / README_RO.md) IsiRomania | [ru русский] (/. github / README_RU.md) IsiRashiya | [sm Faasamoa] (/. github / README_SM.md) isiSamoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) iScots Gaelic | [sr Српски] (/. github / README_SR.md) IsiSerbia | [st Sesotho] (/. github / README_ST.md) IsiSuthu | [sn Shona] (/. github / README_SN.md) isiShona | [sd سنڌي] (/. github / README_SD.md) iSindhi | [si සිංහල] (/. github / README_SI.md) ISinhala | [sk Slovák] (/. github / README_SK.md) IsiSlovak | [sl Slovenščina] (/. github / README_SL.md) IsiSlovenia | [soomaali] (/. github / README_SO.md) Somali | [[es español] (/. github / README_ES.md) iSpanish | [su Sundanis] (/. github / README_SU.md) iSundanese | [sw Kiswahili] (/. github / README_SW.md) isiSwahili | [sv Svenska] (/. github / FUNDAE_SV.md) IsiSwedish | [tg Тоҷикӣ] (/. github / README_TG.md) iTajik | [ta தமிழ்] (/. github / README_TA.md) IsiTamil | [tt Татар] (/. github / README_TT.md) isiTatar | [te తెలుగు] (/. github / README_TE.md) IsiTelugu | [th ไทย] (/. github / README_TH.md) isiThai | [tr Türk] (/. github / README_TR.md) IsiTurkey | [tk Türkmenler] (/. github / README_TK.md) iTurkmen | [uk Український] (/. github / README_UK.md) IsiUkraine | [ur اردو] (/. github / README_UR.md) IsiUdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) IsiVietnam | [cy Cymraeg] (/. github / README_CY.md) IsiWales | [xh isiXhosa] (/. github / README_XH.md) isiXhosa | [yi יידיש] (/. github / README_YI.md) IsiYiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Iyafumaneka ngeelwimi ezili-110 (108 xa kungabalwa isiNgesi noMntla Korea, nanjengoko iNorth Korea ingekaguqulelwa okwangoku [Funda malunga nayo apha] (/ OldVersions / Korean (North) /README.md))

Ukuguqulelwa kwezinye iilwimi ngaphandle kwesiNgesi kuguqulwe ngomatshini kwaye akukachaneki okwangoku. Akukho zimpazamo zilungisiweyo okwangoku ukusukela nge-5 kaFebruwari 2021. Nceda uxele iimpazamo zotoliko [apha] (https://github.com/seanpm2001/Degoogle-your-life/issues/) qiniseka ukuba ulungisa ulungiso lwakho ngemithombo kwaye undikhokele , njengoko ndingazazi ezinye iilwimi ngaphandle kwesiNgesi kakuhle (ndiceba ukufumana umguquli ekugqibeleni) nceda ucacise [wiktionary] (https://en.wiktionary.org) kunye neminye imithombo kwingxelo yakho. Ukusilela ukwenza njalo kuya kubangela ukwaliwa kolungiso kupapashwe.

Qaphela: ngenxa yokusikelwa umda kutoliko lwe-GitHub yokumakisha (kwaye intle kakhulu kuyo yonke into esekwe kutoliko olusekwe kwiwebhu lokumakisha) ukucofa la makhonkco kuyakuthumela kwifayile eyahlukileyo kwiphepha elahlukileyo elingelilo iphepha leprofayile yeGitHub. Uya kuthunyelwa kwenye indawo [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), apho iREADME isingathwa khona.

Iinguqulelo zenziwa noToliko lukaGoogle ngenxa yokuncitshiswa okanye ukungabikho kwenkxaso kwiilwimi endizifunayo kwezinye iinkonzo zokuguqulela ezinje nge-DeepL kunye ne-Bing Translator (into ehlekisayo yephulo elichasene noGoogle) ndiyasebenza ukufumana enye indlela. Ngesizathu esithile, ukufomatha (amakhonkco, ukwahlulahlula, ukuqaqambisa, italics, njl.) Kuphazamisekile kwiinguqulelo ezahlukeneyo. Kuyadinisa ukulungisa, kwaye andazi ukuba ndiyilungisa njani le micimbi kwiilwimi ezinabalinganiswa abanga-latin, kwaye nasekunene kwiilwimi zasekhohlo (njengeArabhu) uncedo olongezelelekileyo luyafuneka ukulungisa le micimbi.

Ngenxa yemicimbi yolondolozo, iinguqulelo ezininzi ziphelelwe lixesha kwaye zisebenzisa uhlobo lwakudala lwale fayile yenqaku elithi `README`. Kufuneka umguquleli. Kwakhona, ukusukela nge-9 ka-Epreli ka-2021, kuzakundithatha ixesha ukufumana lonke ikhonkco elitsha lisebenza.

***

## Isalathiso

[00.0-Isihloko] (# Ukuthatha inxaxheba kumanqaku-- Degoogle-yobomi bakho)

> [00.1 - Index] (# Isalathiso)

[01.0-Inkcazo esisiseko] (# Inkcazo esisiseko)

> [01.1-Isihloko sokugcina] (# Degoogle-yobomi bakho)

> [01.2 - Wuest3NFuchs isishwankathelo senkcazo] (# Amagqabantshintshi-ngu-Wuest3nFuchs)

>> [01.2.1 - Ithetha ukuthini?] (# Ithetha ntoni- ngu-Wuest3nFuchs)

>> [01.2.2 - Kutheni uDegoogle?] (# Kutheni-Degoogle - ngu-Wuest3nFuchs)

[02.0 - Amanqaku] (# Amanqaku)

[03.0 - Ubungasese] (# Imfihlo)

[04.0-Eminye imikhankaso echasene noGoogle] (# Olunye ulwa-noGoogle-amaphulo)

> [04.0.1 - Ukuphelelwa] (# Ukususwa)

> [04.0.2-Iyaqhubeka] (# Iyaqhubeka)

[05.0-Ukubala ezinye iimpikiswano] (# Ukubala-ezinye-iimpikiswano)

> [05.0.1 - Uncedo] (# Uncedo)

> [05.0.2 - Kutheni kubalulekile nje? Kusemva kakhulu nokuba sekutheni) (# Kutheni-kubalulekile-ukuba-kubalulekile, -kude kakhulu-emva kwexesha)

> [05.0.3 - Okunye] (# Okunye)

[06.0 - Imithombo] (# Imithombo)

[07.0 - Khuphela amakhonkco] (# Umxokozelo-amakhonkco)

[08.0-Amava am okwehlisa ikhonkco] (# Amava am-okwakha amava)

> [08.1-Into endiyitshintshileyo] [# Yintoni-endiyitshintshileyo-esuka)

> [08.2-Iimveliso andikasuki kude kuzo] (# Iimveliso-ndisese-andikabikho-kude)

[09.0-Ezinye izinto oza kuzijonga] (# Ezinye izinto-zokukhangela)

[10.0 - Ulwazi lweFayile] (# Ulwazi lweFayile)

> [10.1 - Ubume besoftware] (# Ubume beSoftware)

> [10.2 - Ulwazi lomxhasi] (# Inkxaso-mali)

[11.0 - Imbali yeFayile] (# Ifayile-imbali)

[12.0-Umbhalo osezantsi ephepheni] (# Umbhalo osemazantsi)

***

## Inkcazo esisiseko

[Isuka kwiWikipedia: iDegoogle] (https://en.wikipedia.org/wiki/DeGoogle)

Intshukumo yeDeGoogle (ekwabizwa ngokuba yi-de-Google intshukumo) ngumkhankaso osisiseko oye wavela njengoko amatshantliziyo abucala ekhuthaza abasebenzisi ukuba bayeke ukusebenzisa iimveliso zikaGoogle ngokupheleleyo ngenxa yokukhula kwemicimbi yabucala malunga nenkampani. Eli gama libhekisa kwisenzo sokususa uGoogle kubomi bomntu. Njengokuba isabelo sentengiso esikhulayo se-intanethi enkulu sidala amandla e-monopolistic kwinkampani kwizithuba zedijithali, amanani anyukayo eentatheli aqaphele ubunzima bokufumana ezinye iindlela kwiimveliso zenkampani.

** Imbali **

Ngo-2013, uJohn Koetsier waseVenturebeat wathi i-Amazon Kindle Fire Android-based tablet yayingu "Android-ized version ye-Android." Ngo-2014 uJohn Simpson wase-US News wabhala malunga "nelungelo lokulityalwa" nguGoogle kunye nezinye iinjini zokukhangela. Kwi-2015, uDerek Scally weIrish Times ubhale inqaku malunga nendlela yokwenza "iDo-Google ubomi bakho." Ngo-2016 uKris Carlon waseAndroiAbasemagunyeni bacebise ukuba abasebenzisi beCyanogenMod 14 banako "ukususa uGoogle" iifowuni zabo, kuba iCyanogenMod isebenza kakuhle ngaphandle kweapp zikaGoogle. Ngo-2018 uNick Lucchesi we-Inverse ubhale malunga nendlela iProtonMail eyayikhuthaza ngayo ukuba "ungabenza njani ngokupheleleyo u-Google-fy ubomi bakho." UBrendan Hesse kaLifehacker ubhale isifundo esineenkcukacha malunga "nokuyeka uGoogle." Intatheli yeGizmodo uKashmir Hill ubanga ukuba uphoswe ziintlanganiso kwaye unengxaki yokulungiselela ukudibana ngaphandle kokusebenzisa iKhalenda kaGoogle. Ngo-2019, uHuawei wabuyisela imali kubanini beefowuni kwiiPhilippines ababe kuthintelwe ekusebenziseni iinkonzo ezinikezelwa nguGoogle kuba zimbalwa ezinye iindlela ezikhoyo zokuba ukungabikho kweemveliso zenkampani kwenza ukuba ukusetyenziswa kwe-intanethi okuqhelekileyo kungenzeki.

***

# Degoogle-ubomi bakho
Indawo yokugcina ulwazi ngokubanzi yokwahlulahlula kunye nokunxibelelana nezinye zokugcina izinto zam.

***

## Amagqabantshintshi nguWuest3nFuchs

Inkcazo engcono, enikezwe yi [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - umthombo: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Ingaba ithetha ntoni? nguWuest3nFuchs

Ukuzibandakanya kuthetha ukuyeka ukusebenzisa nantoni na eyekaGoogle, nantoni na eyenziwe nguGoogle. Ndithetha nge-injini yokukhangela, inkonzo yabo yeposi (i-Gmail), i-YouTube, njl.

### Kutheni uDegoogle? nguWuest3nFuchs

UGoogle yenye yezona nkampani zinamandla ehlabathini ngoku. Baye bagcina isixa esikhulu solwazi kuthi sonke. Abanye banokuphikisa ngelithi ulwazi lwethu lukhuselekile kubo kuba bayayazi indlela yokukhusela. Kodwa oku akuyonyani. UGoogle ungenwe ngaphambili kwaye uya kungenwa nakwixesha elizayo. Mhlawumbi hayi ngomntwana othile weskripthi kodwa uya kwenziwa ngurhulumente wesizwe. UGoogle ugcina ulwazi lomntu siqu kuthi kuba yindlela abayenza ngayo imali.

Baskena ii-imeyile zethu, bagcina esikukhangelayo xa sisebenzisa iinjinjini zokukhangela, zeziphi iividiyo esizibukayo kwiYouTube. Le yindlela abajolise kuthi kwaye bakhe iprofayili kuthi ukusibonisa intengiso ethile esekwe kwinto ebesithetha ngayo nomhlobo wethu osenyongweni ukuze basibonise intengiso yento esiyifunayo, kodwa oku kuyothusa. Enkosi kuMnu Snowden ngoku siyazi ukuba uGoogle wabelane ngeenkcukacha zethu neNSA phantsi kwenkqubo ebizwa ngokuba yi "PRISM" **.


Kwixesha elizayo umntu uya kuba nakho ukufikelela kulo lonke olo lwazi kwaye ndiyakuqinisekisa ukuba into embi iya kwenzeka. Ukuthintela ukuba kungenzeki, kuya kufuneka uqale ngokuLungisa izinto ngoku. Kananjalo akufuneki usebenzise iimveliso yinkampani ekwabelana ngedatha yakho kunye ** NSA **. Kuya kufuneka unqumame kuyo yonke le nto ngokwenza izinto ngokungakhathali.

** Ukuba abanye abantu bayakwazi ukuyenza, nawe ungayenza. **

[Funda ngakumbi apha] (https://github.com/Wuest3nFuchs/Degoogle)

<! -Ukhonkco oluya kwimfoloko aludweliswanga, njengoko ndingesiso esalo ndawo ngokupheleleyo, kwaye ndifuna ukukhuthaza eminye imithombo. Iya kuba kukuzingca ukunxibelelana nokwam https://github.com/Degoogle-your-life/Degoogle! ->

***

## Amanqaku

### Isimo senqaku

_ Onke amanqaku okwangoku ngumsebenzi oqhubekayo kwaye afuna uphuculo olukhulu. Iingcebiso kunye nokulungiswa kuyavunyelwa._

_ Ukusukela ngo-Epreli 18th 2021 nge-4: 09 pm, uninzi lwamanqaku alukaqalwa okwangoku. Ndisebenza ekufumaneni ixesha kunye nomzamo wokuziqala._

[Kutheni uyeke ukusebenzisa iGoogle Chrome] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Yeka ukusebenzisa iChannelBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Yeka ukusebenzisa i-WideVine DRM / Lixesha lokusika iWideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Kutheni uyeke ukusebenzisa iReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Ukutshintsha kwiYouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Yeka ukuGogotha, kutheni kufuneka uyeke ukusebenzisa uPhando lukaGoogle] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[Kutheni uyeke ukusebenzisa uGmail] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Kutheni uyeke ukusebenzisa i-Android] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Kutheni kufuneka uphephe iGoogle Amp] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Kutheni uyeke ukusebenzisa iGoogle Drayivu] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Kutheni uyeke ukusebenzisa iimephu zikaGoogle noGoogle Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! ->

[Hei Google, yima] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Yeka ukufunda kwiincwadi zikaGoogle / Dlala] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Yeka ukusebenzisa i-Google Classroom] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Kutheni uyeke ukusebenzisa iToliki kaGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Kutheni uyeke ukusebenzisa iiAkhawunti zakho zikaGoogle] (https://github.com/seanpm2001/Why-you-should-sukusebenzisa-Akhawunti-kuGoogle-Akhawunti) <! - 16! ->

** Amanqaku amatsha aza kubhalwa kungekudala: **

[Kutheni uyeke ukusebenzisa iGerrit] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Kutheni uyeke ukusebenzisa uGoogle Analytics (indawo yokugcina eyaphukileyo isiphelo sam ukusukela ngoLwesithathu, nge-24 kaFebruwari 2021 ngo-4: 13 ntambama)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Uhlalutyo) <! - 18! ->

- Umsebenzi wokwahlulahlula umsebenzi ->

[Kutheni uyeke ukusebenzisa iGoogle AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Kutheni uyeke ukusebenzisa uGoogle One] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Kutheni uyeke ukusebenzisa uGoogle + (defunct)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Kutheni uyeke ukusebenzisa iVenkile kaGoogle yokudlala] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Kutheni uyeke ukusebenzisa uGoogle Docs] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Kutheni uyeke ukusebenzisa iZilayidi zikaGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Kutheni uyeke ukusebenzisa iiSpredishithi zikaGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Kutheni uyeke ukusebenzisa iifomu zikaGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Kutheni uyeke ukusebenzisa ikhadibhodi kaGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Kutheni uyeke ukusebenzisa iMiyalezo kaGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Kutheni uyeke ukusebenzisa uyilo lwezixhobo zikaGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Kutheni uyeke ukusebenzisa iiglasi zikaGoogle / iiglasi] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Kutheni uyeke ukusebenzisa uGoogle Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Kutheni uyeke ukusebenzisa i-GBoard] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Kutheni uyeke ukusebenzisa iKhaya likaGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Kutheni uyeke ukusebenzisa iGoogle Nest] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Kutheni uyeke ukusebenzisa iiGoogle Hangouts (defunct)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Kutheni uyeke ukusebenzisa uGoogle Duo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Kutheni uyeke ukusebenzisa uGoogle Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Kutheni uyeke ukusebenzisa uGoogle Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Kutheni uyeke ukusebenzisa iGoogle Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Kutheni uyeke ukusebenzisa ulwimi lwenkqubo yeGoogles Go) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Kutheni uyeke ukusebenzisa ulwimi lwenkqubo yeGoogles Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Kutheni uyeke ukusebenzisa ifomathi yemifanekiso yeGoogles WebP] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Kutheni uyeke ukusebenzisa ifomathi yevidiyo yeGoogles WebM] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Kutheni uyeke ukusebenzisa iVidiyo kaGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Kutheni uyeke ukusebenzisa iiSayithi zikaGoogle (zakudala)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Kutheni uyeke ukusebenzisa iiSayithi zikaGoogle ("eNtsha")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Kutheni uyeke ukusebenzisa uGoogle Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Kutheni uyeke ukusebenzisa i-Android Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Kutheni uyeke ukusebenzisa iGoogle VPN (oxymoron)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Kutheni uyeke ukusebenzisa iiFoto zikaGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[Kutheni uyeke ukusebenzisa iKhalenda kaGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Kutheni kufuneka uyeke ukusebenzisa iVirusTotal (kuba iyeyeyekaGoogle ukusukela ngoSeptemba 2012] (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Kutheni uyeke ukusebenzisa uGoogle Fi] (https://github.com/seanpm2001/Why-you-shouI-ld-stop-using-Google-Fi) <! - 53! ->

[Kutheni uyeke ukusebenzisa uGoogle Stadia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Kutheni uyeke ukusebenzisa iGoogle Keep] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Kutheni uyeke ukusebenzisa iGoogle Base] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Kutheni uyeke ukuthatha inxaxheba kwiKhowudi yehlobo yeGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Kutheni uyeke ukusebenzisa iGoogle Camera] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Kutheni kufuneka uyeke ukusebenzisa iGoogle Calculator (isenokubonakala igqithile, kodwa kuya kufuneka uye kuyo yonke into, kulula kakhulu ukuyitshintsha)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Ikhalityhuleyitha) <! - 59! ->

[Kutheni uyeke ukusebenzisa uGoogle + kunye nemivuzo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Kutheni uyeke ukusebenzisa iMizobo kaGoogle] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Kutheni uyeke ukusebenzisa i-Tenor (indawo ye-GIF, ephethwe nguGoogle ukusukela ngo-2019)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Yintoni i-FLoC- Kutheni kufuneka uyiphephe iGoogles enkulu yeFoxCing (yeka ukusebenzisa iGoogle Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Amanqaku ewonke: ** `63`

** Inqaku [imephu yendlela AB] (DegoogleCampaign_2021Roadmap_Part1.md) (ukuya kuthi ga nge-12 kaMatshi 2021) iintsuku ezimbini zokuphuma **

** Inqaku [imephu yendlela BB] (DegoogleCampaign_2021Roadmao_Part2.md) (ukuya kuthi ga? 2021) 2 yeentsuku zokuphumla **

Isimo senqaku

Onke amanqaku okwangoku ngumsebenzi oqhubekayo kwaye afuna uphuculo olukhulu. Iingcebiso kunye nokulungiswa kuvunyelwe.

** Iifolokhwe **

Ukwandisa inethiwekhi yam yeDegoogle, kunye nokongeza ukufikelela lula, kunye nokukhwaza uluntu.

1. [IiFossapps] (https://github.com/Degoogle-your-life/Fossapps) | Ifakwe kwi: [https://github.com/wacko1805/Fossapps] (https://github.com/wacko1805/Fossapps) (isiNgesi)

2. [Amakhonkco wabucala] (https://github.com/Degoogle-your-life/Imfihlo-linki) | Ifakwe kwi: [https://github.com/Arturro43/privacy-links] (https://github.com/Arturro43/privacy-links) (Polish)

3. [Uyonwabisa-Ubumfihlo] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Ifakwe kwa: [https://github.com/LinuxCafeFederation/Delightful-Privacy) (https://github.com/LinuxCafeFederation/Delightful-Privacy) (isiNgesi)

4. [Uludwe lweebhloko] (https://github.com/Degoogle-your-life/listslists) | Ifakwe kwi: [https://github.com/jmdugan/blocklists] (https://github.com/jmdugan/blocklists) (isiNgesi)

5. [UDegoogle, nguWuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Ifakwe kwi: [https://github.com/Wuest3nFuchs/Degoogle] (https://github.com/Wuest3nFuchs/Degoogle) (isiNgesi)

** Inxulumene **

[Uphononongo olwenziwe ngomatshini olwenziwe ngefowuni lwe-Android) (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Bona kwakho:**

[Ukugxekwa kukaGoogle kwiWikipedia] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[Amangcwaba kaGoogle (killbygoogle.com) - uluhlu oluhleliweyo lweemveliso ezingama-224 + ezibulewe nguGoogle] (https://killedbygoogle.com/)

> [Ikhonkco leGitHub] (https://github.com/codyogden/killedbygoogle)

[Umanyano wabasebenzi beAlfabhethi - Umanyano wabasebenzi kuGoogle onamalungu angaphezu kwe-800] (https://alphabetworkersunion.org/people/our-union/)

[Awufuni ukwahlukana neqanda lephasika? Le webhusayithi uyigubungele] (https://chromedino.com/)

***

## Ubumfihlo

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / yonke idatha-ye-facebook-google-inayo-kuwe-ngasese) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit))ss (http://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spy-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ] [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he idatha ye-alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-yabucala-ingxaki /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_arIgalelo # Ukugxekwa) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -isampulu / into-yokufihla-impikiswano-ayinanto yokuthetha /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- ye-data-malunga nawe-ungayifumana-kwaye uyicime-ngoku /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -yakho-idatha-yobuqu-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -ukwenzela-kunye) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ I-28 / yonke-idatha-facebook-google-in-kuwe-ngasese) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- ingqokelela-ivezwe.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ impilo-yomelele-idatha-yabucala /) [h] (https://www.pcmag.com/news/google-sued-ov er-abantwana-ukuqokelelwa-kwezemfundo-ngechromebook) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / Australia-urhulumente-uqokelelo-lweenkcukacha-ityala-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)letono/https://en.wikipedia.org/wiki/2018_Google_data_breach))mimele(https://moz.com /blog/ Where-does-google-draw-the-data-collection-line))ee(https://mashable.com/article/google-android-data-collection-study/)[s)(https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)inglyoo (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -bango-egameni-le-5-m Abasebenzisi-illion-iphone-abasebenzisi) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // ii-topclassaction.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/)[r)(https://arstechnica.com/information-technology/2014/01 / what-google-can-really-do-with-nest-or-really-nests-data/) sigar- (https://www.cbsnews.com/news/google-education-spies-on-collects- idatha-kwizigidi-zabantwana-izityholo-ityala-elitsha-eMexico-igqwetha-jikelele /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -ngaphantsi kweempumlo zethu /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / iteknoloji / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https) : //medium.com/digitalprivacywise/kwakutheni- kufuneka uyeke ukusebenzisa-google-chrome-6c934c9a827c) (ndingaya phambili nobungqina boku, kodwa kuthathe ixesha elide ukuzifumana zonke ezi zinto amanqaku)

Ukuba yimfihlo kwiimveliso zikaGoogle kuhlala kukubi, ngenxa yazo zonke iimveliso zikaGoogle ezinespyware.

Nokuba wenza ntoni, xa usebenzisa uGoogle, zonke iinkcukacha zakho ezibuthathaka zithunyelwa kuGoogle nakwabanye. UGoogle uphinde wabonwa ehamba kwiinkqubo ezivulekileyo. Umzekelo, kumava obuqu (kwiFirefox) kunye ne-YouTube ithebhu evulekileyo engakhange ndiyityelele, ndibukele iividiyo ezininzi ngaphandle kweintanethi (VLC Media Player) Kamva xa ndisiya kujonga iingcebiso, yayiphantse yento yonke endandiyibukele. Alithandabuzeki elokuba bahlola ezinye iinkqubo.

Kwi-Chrome (kunye nezinye iibrawuza) imowudi ye-incognito ikhona. Kwi-Chrome, le ndlela ayinantsingiselo, njengoko uGoogle esaya kugcina idatha yakho. Nokuba ucima ukombiwa kwedatha / ukulandela umkhondo, kwaye wenze ukuba "ungalandeleli" uphawu, isimanga sokumangalisa, uGoogle usayigcina idatha yakho.

Ukuba ucinga ukuba akukho nto uyifihlayo, ** uphazamile ngokupheleleyo **. Le ngxoxo ichithwe amaxesha amaninzi ngaphezulu:

[Nge-Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. U-Edward Snowden wathi "Ukuxambulisana ukuba awukhathalelanga ilungelo labucala kuba awunanto uyifihlayo akufani nokuthi uthi awuyikhathalelanga intetho yasimahla kuba awunanto yakuthetha." Xa usithi, ' Andinanto ndiyifihlayo, utsho, 'andikhathali ngeli lungelo.' Uthi, 'andinalo eli lungelo, kuba ndiye kwinqanaba lokuba ndizithethelele Indlela esebenza ngayo amalungelo, urhulumente kufuneka azithethelele ngokungenelela kwakhe kumalungelo akho. "

2. UDaniel J. Solove uxele inqaku leThe Chronicle yeMfundo ePhakamileyo ukuba uyayichasa ingxoxo; watsho ukuba urhulumente angashiyaUlwazi malunga nomntu kwaye lubangele umonakalo kuloo mntu, okanye usebenzise ulwazi malunga nomntu ukwala ukufikelela kwiinkonzo nokuba umntu khange abandakanyeke kwisenzo esingalunganga, kwaye urhulumente angadala umonakalo kubomi bakhe ngokwenza iimpazamo. I-Solove ibhale "Xa uzibandakanya ngokuthe ngqo, impikiswano engenanto yokufihla inokubambisa, kuba inyanzela ingxoxo-mpikiswano ukuba ijolise kulwazi oluncinci lobumfihlo. Kodwa xa ujongene nobuninzi beengxaki zabucala ezichaphazeleka kukuqokelelwa kwedatha kukarhulumente kunye nokusetyenziswa ngaphaya kokugadwa kwaye ukuziveza, impikiswano engenanto yokufihla, ekugqibeleni, ayinanto yakuthetha. "

3. UAdam D. Moore, umbhali wamaLungelo aBucala: iMilinganiselo yokuZiphatha kunye nezoMthetho, wathi, "luvo lokuba amalungelo ayamelana nexabiso / isibonelelo okanye uhlobo lwempikiswano. Apha siyayikhaba imbono yokuba umdla wabucala ziluhlobo yezinto ezinokuthengiswa zikhuseleke. Uye wathi ukubekwa kweliso kunokuchaphazela ngokungafaniyo amaqela athile kuluntu ngokusekwe kwinkangeleko, ubuhlanga, isini kunye nenkolo.

4. UBruce Schneier, ingcali yezokhuseleko kwikhompyuter kunye nomlobi we-cryptographer, uvakalise inkcaso, ecaphula ingxelo kaKhadinali Richelieu "Ukuba umntu angandinika imigca emithandathu ebhalwe ngesandla yeyona ndoda inyanisekileyo, ndingafumana into kubo yokuxhonywa", ebhekisa indlela urhulumente woburhulumente anokufumana ngayo iinkalo kubomi bomntu ukuze atshutshise okanye ahlasele loo mntu. U-Schneier uphinde wathi "Zininzi kakhulu izinto ezingalunganga ezichaza ingxoxo njenge 'ukhuseleko xa kuthelekiswa nemfihlo.' Olona khetho lufanelekileyo yinkululeko nxamnye nolawulo. "

5. UHarvey A. Silverglate uqikelele ukuba umntu oqhelekileyo, ngokomndilili, ngokungazi wenza amatyala amathathu ngosuku e-US.

6. U-Emilio Mordini, ifilosofi kunye nochwephesha kwengqondo, wathi "akukho nto ifihliweyo" iyimpikiswano yendalo. Abantu akufuneki babenayo "into yokufihla" ukuze bakwazi ukufihla "into". Into efihliweyo ayisiyomfuneko, ubanga uMordini. Endaweni yoko, uphikisa indawo esondeleyo enokuthi ifihlwe kwaye ukufikelela kuthintelo kuyimfuneko kuba, xa sithetha ngokwasemphefumlweni, siba ngabantu ngokufumanisa ukuba sinokufihla okuthile kwabanye.

7. UJulian Assange wathi "Akukabikho mpendulo ibulalayo. UJacob Appelbaum (@ioerror) uphendule ngobukrelekrele, ebuza abantu abatsho oku ukuba bamnike ifowuni yabo ivulwe kwaye behlise ibhulukhwe yabo. Inguqulelo yam ithi, Kulungile, ukuba uyadika ngoko ke akufuneki ukuba sithethe nawe, kwaye akufuneki nokuba kungomnye umntu ', kodwa ngokwentanda-bulumko, eyona mpendulo yile: Ukujongwa kweMisa lutshintsho olukhulu kulwakhiwo. ukuthatha nawe, nokuba ungoyena mntu ucekisekayo emhlabeni. "

8. UIgnacio Cofone, unjingalwazi wezomthetho, uthi impikiswano iphosakele ngokwemigaqo yayo kuba, nanini na xa abantu beveza ulwazi olufanelekileyo kwabanye, bakwadiza ulwazi olungabalulekanga. Olu lwazi lungabalulekanga luneendleko zabucala kwaye lunokukhokelela kolunye ukonzakala, njengokucalulwa.

***

## Olunye ukhankaso oluchasene noGoogle

Olu luluhlu lwamanye amaphulo alwa noGoogle. Olu luhlu aluphelelanga. Unokunceda ngokwandisa.

### Akusasebenzi

[Iscroogled-Ngu-Microsoft (Novemba 2012 ukuya ku-2014)] (https://en.wikipedia.org/wiki/Scroogled)

_Alukho olunye ungeniso ngalo mzuzu._

### Iyaqhubeka

Olu luhlu alunanto._

***

## Ukubala ezinye iimpikiswano

Kukho iimpikiswano ezenziwa ngabantu zokucacisa uGoogle. Inye yeyokuqala eyintloko sele inetyala [apha] (# Ubumfihlo) kodwa nazi ezinye:

### Uncedo

Ewe iimveliso zikaGoogle zibonakala zilungile. Nangona kunjalo, uthengisa yonke into elungileyo ngokulula, kubandakanya ukhuseleko, imfihlo kunye nokuthembeka. UGoogle ebefumana ilazier ngaphezulu kweminyaka, kwaye iiseva zabo ziye zehla ngakumbi nangakumbi. Okwangoku, iiseva zikaGoogle ziyehla phantse iyure amaxesha ama-1-2 ngenyanga (ngakumbi iYouTube)

Ngelishwa, ngenxa yokuxhomekeka koluntu kuGoogle, uGoogle uza kulawula i-Intanethi, kwaye ufuna ukulawula ngakumbi nangakumbi. Ngo-2012, xa uGoogle esihla kangangemizuzu emi-5, kwaxelwa ukuba ** ukugcwala kwe-Intanethi jikelele ** kwehle ngama-40% ** uGoogle uhlala esihla ngeyure eziyi-1-2, kwaye [ngokudubula iqela labo lokuziphatha] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) phakathi kwezinye izinto, baya kuncipha ngokuncipha.

Ukunceda akusoloko kuyinto elungileyo. Kuya kufuneka uqaphele ukuba kuqhubeka ntoni kwaye uzilungiselele xa besihla, kuba akukho ndlela yokuba iseva ingahambi ezantsi kube kanye ngexeshana.

UGoogle naye akalunganga njengoko ucinga. Kukho ezinye iisayithi ezifanelekileyo ngakumbi. UGoogle akanakulungeleka, xa unika ingxelo ukumiswa kweakhawunti ngokungacwangciswanga kunye nokupheliswa ngaphandle kwempendulo (ngaphandle kokuba utsalele ingqalelo eyaneleyo kwiakhawunti ye-twitter kaGoogle okanye ubamangalele nge- $ 100,000,000 okanye nangaphezulu) emva koko bakusebenzise, ​​bakudibanisa, kwaye wanyanzelwa ukuba ukhwaze kumqamelelo, apho kungekho mntu unokuva isikhalo sakhongoncedo.

### Kutheni le nto ibalulekile, nokuba sele ihambile ixesha

Le yimpikiswano engaqhelekanga, kodwa ifuna ingcaciso. Ngorhulumente wangoku, uninzi loorhulumente behlabathi, kunye neenkampani ezininzi ezinamandla kubonakala ngathi ziyayazi yonke into oyenzayo, kungoko kutheni uzikhathaza ukusuka kuyo? Impendulo ilula: ** ufanelwe ngcono **. Ukuba uyakwazi ukuphuma kubo ngeli xesha, kunzima kubo ukuba balandelele ukuhamba kwakho, kwaye ungakha ubomi obutsha ngakumbi.

[1 umthombo] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Hi ndlela leyi, bendisoloko ndinikezela ngembasa yam yasimahla yeReddit kule post ngalo lonke ixesha ndiyifumana ngaphezulu kweveki ngoku (kunye nayo yonke i-500 yemali yam yasimahla) yokunyusa esi sihloko ngakumbi. Ukuza kuthi ga ngoku, ndinike esi sithuba ngaphezulu kwe-14 yamabhaso asimahla. Akuninzi, kodwa izinto ezincinci zingenza impembelelo enkulu, kuxhomekeke kwindlela ebonwa ngayo, kwaye ngubani.

### Enye

Andinazo ezinye iimpikiswano ngalo mzuzu.

Olu luhlu aluphelelanga_

***

Imithombo # #

Ikopi:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / yonke idatha-ye-facebook-google-inayo-kuwe-ngasese) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit))ss (http://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spy-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ] [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he idatha ye-alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-yabucala-ingxaki /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Ukugxekwa) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -iisampulu / akukho nto-yokufihla-impikiswano-ayinanto yokuthetha /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- idatha-malunga nawe-ungayifumana-kwaye uyicime-ngoku /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your idatha-yobuqu-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -and) [c] (https://www.wired.com/story/google-tracks-you -ubucala /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/I-Googles-vision-TOTAL-data-collection-revealed.html)letondhttps: //www.reuters.com/article/us-alphabet- google-ubumfihlo-ityala-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)letono-https://en.wikipedia.org/wiki/2018_Google_data_breach)[m)(https://:// moz.com/bl og / apho-ukwenza-google-ukuzoba-idatha-yokuqokelela-umgca) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / iteknoloji / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- amabango-egameni-le-5-yezigidi-ze-iphone-abasebenzisi) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) [e) (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your- -ifowuni-ayisebenziswanga /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassaction.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica) .com / ulwazikwitekhnoloji / ngo-2014/01 / yintoni-ka-google-enokwenza-inyani-okanye-iindlwana-zedatha /) [i] (https://www.cbsnews.com/news/google-education -iintlola-eziqokelela-idatha-kwizigidi-zabantwana-izityholo-ityala-elitsha-mexico-igqwetha-jikelele /) [v] (https://www.nationalreview.com/2018/04/the- idatha-yomfundi-yemigodi-yehlazo-phantsi-kweempumlo zethu /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)inglyyy (https://medium.com/@hansdezwart/during-world-war-ii-we-did- -kukho into ekufihlayo-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Eminye imithombo:

[Amehlo amahlanu oMdibaniso] (https://en.wikipedia.org/wiki/Five_Eyes) [Amashumi alithoba anesibhozo anesibhozo] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Khuphela amakhonkco

[Fumana iFirefox] (https://www.mozilla.org/en-US/firefox/new/) [Get Tor Tor browser] (https://www.torproject.org/download/) [Okunye / ayifumaneki] (https : //www.example.com)

***

## Amava am okuzithoba

Ekugqibeleni ndiye ndaqala ukubona iingxaki ngetekhnoloji enkulu kwi-2018, ndaye ndaqala ukuzenza amadolo. Kwiinyanga ezimbalwa zokuqala, ndenze inkqubela ebonakalayo. Yehlisa isantya kakhulu ukusukela ngoko.


### Into enditshintshele kuyo

Google Chrome -> Firefox / Tor

Uphendlo lukaGoogle -> DuckDuckGo (okwendalo) / Ecosia (xa ndiziva ndiyithanda) / Bing (kunqabile)

I-GMail-ProtonMail (ayikatshintshi ngokupheleleyo)

Iindawo zikaGoogle -> Ukubamba ngokwakho (okwangoku akukatshintshi ngokupheleleyo)

UGoogle + -> Kunqabile ukuba kusetyenziswe, kuzicime ngenxa yokuvalwa kwayo

Amaxwebhu kaGoogle -> Ayikaze isetyenziswe, ndisebenzisa iMicrosoft Word 2013 (ngaphambi ko-2019) kunye neLibreOffice (2019 ukuya phambili) endaweni yoko.

AmaSpredishithi eGoogle-> Ayikaze isetyenziswe, ndisebenzisa iMicrosoft Excel 2013 (ngaphambi ko-2019) kunye neLibreOffice (2019 ukuya phambili) endaweni yoko.

Izilayidi zikaGoogle -> Ayikaze isetyenziswe, ndisebenzisa iMicrosoft PowerPoint 2013 (ngaphambi ko-2019) kunye neLibreOffice (ngo-2019 ukuya phambili) endaweni yoko.

Imizobo kaGoogle-> Ayikaze isetyenziswe, ndisebenzisa nje iLibreOffice (ngo-2019 ukuya phambili) endaweni yoko.

IGerrit -> Ungaze usebenzise, ​​ndisebenzisa iGitHub (okwangoku okungagqibekanga), iGitLab, iBitBucket, kunye neSourceForge endaweni yoko.

Iifoto zikaGoogle-> Ayikaze isetyenziswe

Google Drayivu -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-yangoku)

Iimephu zikaGoogle -> I-OpenStreetMaps / iiMephu zeApple

Yiya -ukwenza okhethekileyo ngaphandle kokusebenzisa ulwimi olusebenzayo

Dart -Ukwenza okhethekileyo ngaphandle kokusebenzisa ulwimi olusebenzayo

I-Flutter -ukwenza okhethekileyo, kodwa ungasebenzisi njengolwimi olusebenzayo

Google Earth -> OpenStreetMaps / Apple Maps

Ukubonwa kwesitrato sikaGoogle-> Ayikaze isetyenziswe, ndiyifumana iyothusa ngakumbi

IGoogle Fi-> Ayikaze isetyenziswe

Ikhalenda kaGoogle-> Ayikaze isetyenziswe

Isikali sokubala sikaGoogle-> Ngokwenyani nayiphi na i-app yokubala, nokuba yeyiphi na i-Linux ebalekayo kwimowudi yePython ukuba ndiziva ndiyayithanda

Nest kaGoogle -> Ayikaze isetyenziswe

I-AMP kaGoogle-> Ayikaze isetyenziswe

Google VPN -> Ayikaze isetyenziswe, ikwakhona ioksijini

Ukubhatala kukaGoogle -> Ayikaze isetyenziswe

Ihlobo laseKhowudi likaGoogle-> Zange uthathe inxaxheba

I-Tenor -> Ezinye iisayithi ze-GIF, nangona ii-GIF zingabalulekanga kum. Ndidla ngokufumana iifayile ze-GIF kwimifanekiso yeDuckDuckGo, Imgur, Reddit, okanye ezinye iisayithi.

Ibhlokhi -> Ayisasetyenziswanga, awuqinisekanga ukuba iScratch ibaleke ngokuthe ngqo. Ndaba ngumdwelisi osebenzayo ngo-2017 ukubheka phambili, kwaye ndakhula ndiqala ekuqaleni.

I-GBoard -> Isetyenziswe kube kanye, kodwa ishiywe

Iglasi kaGoogle-> Ayikaze isetyenziswe, ithathelwa ingqalelo njengomntwana omncinci kodwa ndaye ndagqiba kwelokuba ndingayifumani / ndisebenzise enye ukuba ndinokhetho

_List isenokungapheleli._

### Iimveliso andisakwazi kude nazo

Ukusukela nge-25 kaFebruwari 2021, ezi ziimveliso zikaGoogle ezindigcina ekusebenzeni ngokupheleleyo:

1.YouTube

2. I-Android

3. Google Play Ivenkile

4. I-imeyile (yesikolo neendawo ezithile kuphela)

5. IGumbi lokufundela likaGoogle (lesikolo kuphela)

6. IToliki kaGoogle

7. Iakhawunti kaGoogle

8. IiSayithi zikaGoogle (njengoko uGoogle ephula imithetho yeGDPR (kwaye angajongana nenye isohlwayo se- € 5,000,000.00 bade bayilungise) kwaye athintele ukhuphelo lwale mveliso)

Ndizenzele yonke into.

***

## Ukuhamba kubi

UGoogle usebenze ngaphezulu kolwimi lwenkqubo olusekwe kummeli ka-2003 `` Yiya! '' Ngolwimi lwabo lwenkqubo `` Yiya '(ukusuka ngo-2009, kwiminyaka emi-6 kamva) kwaye babanga ukuba ulwimi lwabo alunakuchaphazela olunye ulwimi konke konke. UGoogle wagxekwa kanobom ngale nto, njengoko i-motto yabo ethi `` Musani ukuba mbi '' yayisasebenza ngelo xesha, kwaye esi sesinye seziganeko ezininzi ezingakhange zibangele ukuba iMotto embi ithathe umhlala-phantsi.

Ekugqibeleni, ukukhula kuka``Go! 'Kuyekile, ngelixa `Go` kwaba yinto exhaphake ngakumbi. UGoogle ubanga ukuba abayi kuhamba ngokungxama `` Yiya! '' Kodwa ekugqibeleni, bayenza, kwaye babaleka nayo (ukusukela nge-9 ka-Epreli 2021)

[Funda ngakumbi malunga nokuya kunye nendlela yokutshintsha apha] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Ukusetyenziswa kwe-DRM

UGoogle usebenzisa i-DRM (uLawulo lweZithintelo kwidijithali) ngokusebenzisa inkonzo yeWideVine DRM "yenkonzo" kunye nezinye iindlela. Injongo ye-DRM kukutshabalalisa i-Intanethi evulekileyo kwaye unike iinkampani amandla okuba wedwa kubasebenzisi. Kuya kufuneka ulahle iWideVine ngokupheleleyo, ngaphandle kwendleko.

[Funda ngakumbi malunga neWideVine kunye neengxaki zayo apha] (https://github.com/Degoogle-your-life/Its-time-ukusika-WideVine-DRM)

***

## Ukungaqondi okuqhelekileyo

Olu luluhlu lwezinye izinto ezingachananga eziqhelekileyo kunye neemveliso zikaGoogle.

### IGoogle ayisiyo i-Intanethi

Ukukhangela kuGoogle / kuGoogle ayisiyiyo i-Intanethi, ukukhangela kuGoogle kuyinjini yokukhangela, efana nokuba ayisiyiyo yonke imidlalo yeqonga leNintendo eyenziwe yiNintendo, kodwa inelayisensi yiNintendo, kodwa ubukhulu becala. Ukuba zonke iiseva zeGoogles bezinokutshatyalaliswa ngaxeshanye okwangoku, ziisayithi zikaGoogle ezinje ngeYouTube, iGmail, uGoogle amaxwebhu, ukukhangela kuGoogle, njl.njl ziya kuba zingasekho, kodwa uninzi lwe-Intanethi ngesele lukhona (iWikipedia, iStackoverflow, iGitHub, Zonke iiwebhusayithi zeMicrosofts, i-NYTimes, i-Samsung, iTikTok, njl.njl. Banokuphulukana nokungena kwabo kuGoogle kunye nokusebenza kohlalutyo, kodwa baya kuhlala besebenza (ngaphandle kokuba bengalungiswanga kakuhle kwaye bexhomekeke ngqo kuGoogle)

***

## Internet Explorer 6 kunye neChannel

UGoogle Chrome uya esiba yi-Internet Explorer entsha 6. Xa uGoogle Chrome wayephuma kwasekuqaleni, iFirefox yayiyeyona nto ibalaseleyo kwisikhangeli, kwaye wayeyibulele i-Internet Explorers markethare (eyayidlula kwi-96% ngaphambi kokuba izigidi zabantu zitshintshele kwiFirefox nakwezinye izikhangeli) xa uGoogle Chrome iphumile, abantu batshintshile ngenxa yesantya sayo kwaye ibinguGoogle (ebingathathelwa ingqalelo njengobubi ngelo xesha, njengoko uninzi lwemiba yabucala ingekakhanyi) iGoogle Chrome ekuqaleni yayihlonipha imigangatho yewebhu (yile nto yenziwa yiFirefox I-Google Chromes markethare inyukile, uGoogle waqala ukususa amanqaku nangakumbi, esongeza ispyware, kwaye wayeka ukwamkela imigangatho yewebhu, uGoogle Chrome uye waba yiInternet Explorer 6 entsha.

Ingxaki enkulu okwangoku ziiwebhusayithi ezikwiChannel kuphela, kwaye azizukusebenza kwezinye iibrawuza, njengoko abaphuhlisi babo bagqibe kwelokuba abafuni enye i-30-40% yabasebenzisi be-Intanethi abangasebenzisi iChrome ukusebenzisa indawo yabo.

Nokuba uGoogle uqobo wenza iindawo zabo ukuba zibe yiChannel kuphela. Umzekelo, ukukhangela kuGoogle kuyakucela ukuba ukhuphele iChannel kathathu qho kwimizuzwana eli-10 ukuba ikufumanisa ukuba awusebenzisi iGoogle Chrome (nezinye iibrawuza ezisekwe kwiChromium ezinjengeBrave zichaphazelekile) kunye neziza ezinje ngeGoogle Earth azivumeli abasebenzisi beFirefox Sebenzisa indawo yabo (ukusukela ngo-2020) kunye noGuqulelo lukaGoogle aluxhasi ukufakwa kwelizwi kwiFirefox, kunye nezinye izikhangeli ezingezizo zikaGoogle.

### Ingxaki ngeNkalipho

Ezinye iibrawuza ezisekwe kwiChromium, ezinjengeBrave kunye neMicrosoft Edge azinayo kwaphela i-spyware kaGoogle. Isibindi sihlala sicetyiswa licala elingalunganga loluntu lwabucala, kodwa iBrave iseseyingxaki, njengoko isebenzisa iChromium. I-Intanethi akufuneki ibe nezikhangeli zeChromium kuphela, kufanele ukuba kubekho ukhetho. Isibindi yindlela engalunganga yokuhamba.

[Funda ngakumbi malunga ne-degoogling esuka kuGoogle Chrome / iChromium apha] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Funda ngakumbi malunga nokukhangela kwi-ChromeOS / ChromiumOS (ii-Chromebook / ii-Chromebox / ii-Chromeblets / i-ChromeBits / i-ChromeETC) apha] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Faux yokuhlaziya imfihlo

UGoogle ebezama ukuxelela umhlaba ukuba ukhathalele imfihlo, emva kokuba sele kudlule ixesha. Baqhubeka nokubanga ukuba bayayihlonipha imfihlo yomsebenzisi, kodwa abakazilungisi zonke iingxaki zabo zabucala.

### Umthombo ovulekileyo awunakukhetha

Umthombo ovulekileyo awunakukhetha. Ubungqina bukaGoogle koku. Yonke into kunye ne-byte yekhowudi yemithombo kufuneka ibonakale kuluntu, kungabikho kwa-8 ye-byte efihliweyo.

Iiprojekthi ezinje nge-Android kunye ne-ChromeOS yimithombo evulekileyo, kodwa inezinto ezininzi zobunini, izinto ze-spyware.

### Ioksijini

I-VPN yeGoogle yi-oxymoron. UGoogle akabukhathalelanga ubumfihlo, kwaye iNethiwekhi yangasese yangasese (i-VPN) evela kwinkampani enjengaleyo iya kuba lolunye lolona khetho lubi kakhulu kwinkonzo yeVPN.

***

## Ukusebenza kakubi

UGoogle akakhathali malunga nokusebenza kweemveliso zabo ubuncinci ubuncinci be-2017, njengoko isoftware yabo yokugqibela yomgangatho (Google Octane) iyekile ngo-2017.

***

## Ulawulo olubi lweprojekthi

UGoogle unenkqubo embi kakhulu yolawulo lwangaphakathi. Eminye imizekelo eqhelekileyo yeenkqubo eziye zathotywa ngakumbi zibandakanya uGoogle Duo kunye nomculo weYouTube (owayesakuba nguMculo kuGoogle)

Kwinkqubo yophuhliso lwangaphakathi lweGoogles, usetyenziso olu-1 lukhokelela kolunye usetyenziso olunesiqingatha sokusebenza, emva koko usetyenziso lwantlandlolo luyacinywa. Kwiminyaka embalwa kamva, i-app entsha ene-75% yokusebenza engaphantsi iyenziwa, emva koko kususwe usetyenziso olunama-50%, lulandelwe yinkqubo entsha ene-87.5% yokusebenza eyenziweyo, emva koko usetyenziso olunama-75% lusetyenzisiwe , kwaye nangokunjalo.

***

## Iyothusa okanye akukho moderation yeenkonzo

I-YouTube ngowona mzekelo uqhelekileyo kwihlabathi lokumodareyitha okungalunganga okwenza elona qonga likhulu likhoyo. UGoogle naye akabonakali ekufumaneni ukuba iYouTube ayingobantwana beYouTube.

YeYouTube, umxholo onenzondo we-Nazi kunye ne-White Supremacist uhanjiswa kubasebenzisi ngenjongo yexesha elininzi lokuzibandakanya kunye nemali engaphezulu. UGoogle ukwenzile kakhuluIzinto eziziziyatha ngokumodareyitha kwazo, njengokuvuma iVidiyo yamaKrestu oSondo ngoBomi njengomxholo `wenzelwe abantwana` ngelixa kwangaxeshanye ubekelise ividiyo. Akuqhelekanga ukuba ubone iifoto zoononografi okanye iintengiso ze-gore zichanekile phantsi kwevidiyo ye-Baby Shark, kunye nezinye izinto `ezenzelwe umxholo wabantwana.

Abasebenzisi be-YouTube bakhalaza rhoqo malunga nokumodareyitha okungalunganga kwi-YouTube yomxholo ombi (njengemizekelo edweliswe apha ngasentla) ngelixa abasebenzisi banokususa iividiyo zabo ngaphandle kwesizathu ngaphandle kwesizathu sokungawurhoxisi, kunye nabasebenzisi bohlwaywa ngayo nayiphi na indlela yokufunga, namatyala amancinci kakhulu afana nokuthi abasebenzisi be-'crap` baqhele ukuthelekisa i-YouTube ne- [Soviet Union] (https://en.wikipedia.org/wiki/Soviet_Union) kwixesha le-Stalin, ngenxa yezi zohlwayo ezingalinganiyo.

Ngo-2021, uGoogle wabhengeza ukuba bazokubeka iintengiso kuzo zonke iividiyo, ngaphandle kokuba ividiyo yenziwa yidemon (ukuze uGoogle enze imali, kodwa umdali akayenzi) oku akuhambelani nokumodareyitha kakhulu, kodwa kubalulekile ukuba uqaphele.

I-YouTube imodareyithiwe (nangona kunjalo imbi kakhulu) kodwa inkonzo yentengiso kaGoogle ebenza ukuba uninzi lwemali yabo ibonakale ingenamodareyitha.

[Funda ngakumbi malunga nemicimbi yokumodareyitha kweYouTube nendlela yokutshintsha kwiYouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Izibhengezo zeGoogle Play ziveliswa kwiifama ze-bot, unokuxela kwimeko ezifanayo zentengiso ezisetyenziswa ngamakhulu eenkampani ezinotshintsho oluncinci, kwaye akukho buhlobo kwimveliso (imizekelo eqhelekileyo: I-Playrix (i-Homescapes, i-Gardenscapes) i-Fishdom, iMafia City, kunye amawaka angaphaya) kunye nentengiso eyandayo yentengiso ebanga ukuba abasebenzisi banokufumana imali ngokudlala imidlalo, ukumamela umculo, njl.njl. I-PayPal ayikhange ithethe nto ngale nto, kodwa kuyacaca ukuba obu bubuqhetseba, ngokungathi unokwenza ngaphezulu kwe- $ 10,000 kwimizuzwana engaphantsi kwama-20 ngokudlala umdlalo oqinisekisiweyo, akukho mntu uzakwenza umsebenzi kwaye ebeya kwenza le nto endaweni yoko, ayinakwenzeka, kwaye ishishini alinakusebenza ngoluhlobo. Obu buqhetseba obukhulayo bukhula buqina ukusukela nge-2019, kwaye ngoku iifama zebot ezivelisa ezi ntengiso ziyalwa kunye kwiintengiso zazo.

Iintengiso ezininzi ziye zaziphatha gwenxa, kwaye zizama ukufumana abasebenzisi (uninzi lwabo bengabasebenzisi abangaphantsi kweminyaka ye-13, okanye i-bots) ukucofa ngokukhohlisa ngokwesondo.

Zininzi ii -apps zisebenzisa i-bots kunye ne-astroturf iimveliso zazo, ke xa kusenziwa uphononongo olubi, iiakhawunti zebhokisi yoonopopi ziya kuqala ukuthumela uphononongo lweenkwenkwezi ezi-5 kunye nokuzama ukungahoyi ukugxeka kwakho. [UGoogle uzenzela le nto] (# Astroturfing)

[Funda ngakumbi malunga nemiba ngeGoogle AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

Inkcazo ngokubanzi [(ukusuka kwiWikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

``
I-Astroturfing yindlela yokugubungela abaxhasi bomyalezo okanye umbutho (umzekelo, ezopolitiko, ezentengiso, ezenkolo okanye ezoluntu) ukuyenza ibonakale ngathi ivela kwaye ixhaswa ngabantu abathatha inxaxheba. Yinkqubo ekujongwe ukuba inike ingxelo okanye imibutho ngokuthembeka ngokubamba ulwazi malunga nonxibelelwano lwemithombo. Igama elithi astroturfing lithatyathwe kwi-AstroTurf, uphawu lokwenziwa kwekhaphethi olwenzelwe ukufana nengca yendalo, njengomdlalo kwigama elithi "ingca". Intsingiselo yokusetyenziswa kwekota kukuba endaweni yomzamo "oyinyani" okanye "wendalo" ngasemva komsebenzi lowo kuthethwa ngawo, kukho imbonakalo yenkxaso "engeyiyo" okanye "yokufakelwa".
``

UGoogle unembali ye-astroturfing ukwenza kubonakale ngathi abenzi nto imbi (kwinkqubo, i-astroturfing imbi) umzekelo, ukuthumela ukugxekwa kukaGoogle kwiqonga elifana ne-Twitter (eneakhawunti) kuya kukhokelela iiakhawunti ezininzi esele zibekhona okwexeshana kodwa azange zithunyelwe ngaphambi kokuba ziphume kwaye zibange ukuba le nto uyithethileyo ayisiyonyani, kwaye ibango lokuba iGoogle yeyona nkampani ibalaseleyo, kodwa yenziwe ngendlela enokuthi ingabonakali ukuba ezi zibhoti uninzi abantu.

***

## Izenzo zeshishini ezingekho mthethweni nezingekho mthethweni

UGoogle usebenzisa iindlela zeshishini ezingekho mthethweni nezingekho mgaqweni ukuqhubekeka nokuzilawula, njengokusebenzisa iindawo zerhafu, ukukhuphela imisebenzi, kunye nokuqhubeka nokwenza izinto ezingekho semthethweni njengeendleko zeshishini.

### EYurophu

IYurophu ihlala imangalela uGoogle, elona tyala likhulu linxamnye nokuziphatha ngokungekho mthethweni kwi-Android, okukhokelele ekubeni uGoogle afumane i-5,000,000,000 (elingana ne- $ 5,947,083,703.68 ngo-Epreli 9th 2021 imali)

### EMntla Melika

I-United States ayinikanga phantse isohlwayo esaneleyo kuGoogle okwangoku, xa kuthelekiswa ne-Europes € 5,000,000,000.

### Iingxabano

UGoogle akayikhathalelanga ingxaki de kube kudala ingxabano, emva koko baya kwenza inzame ezimbi zokuyilungisa, ngokwaneleyo ukuba impikiswano ihambe okwethutyana, kwaye ingxaki ke iya isiba mandundu de idale enye impikiswano, kwaye Umjikelo uyaqhubeka. Abakhathali ngokwaneleyo ukuba benze nantoni na enzulu malunga nayo.

***

## UGoogle uzenzekelayo

Njenge company, uGoogle uzenzekelayo, kwaye ukumodareyitha okuncinci kune-automation.

Inkampani akufuneki yenziwe ngokuzenzekelayo. UGoogle ngumzekelo woku. Ukumodareyitha kuyothusa xa kusenziwa kuphela yi-AI, iYouTube ngumzekelo olungileyo, nkqu nabambalwa abongezelelekileyo (amakhulu, okanye mhlawumbi iwaka) abantu bemodareyitha indawo, apho kubonakala ukuba kubi kakhulu kangangokuba uninzi lwabo kufuneka lufumane unyango ngelixa lusebenza.

***

## I-Android

I-Android yeyabanini bakaGoogle. Inxalenye ye-Open Handset Alliance (engakhange ivulwe ukusukela nge-Android) i-Android iye yaba yenye indawo ye-Google, kwaye inzima kakhulu ukubaleka.

I-Android ixeliwe ukuba ifowunele ekhaya kuGoogle ubuncinci amaxesha ali-10 ngemini, kwaye nangona ingumthombo ovulekileyo, isasebenza kakhulu njenge-spyware.

Iiprojekthi ezininzi zenziwe ukuba zitshintshane kwi-Android, kodwa zifuna ukothula isixhobo sakho. Oku akunakwenzeka kwakhona kwiifowuni ezithile ze-Samsung e-US, ngenxa ye-Knox DRM. Iindlela eziqhelekileyo zokungena kwi-Android zibandakanya i-iOS, i-iPadOS, i-LineageOS, i-Android x86, Ubuntu kunye nePiPhone (iPi Ifowuni luphawu lweefowuni ezisebenzisa iinkqubo ezahlukeneyo zeLinux kwiselfowuni, ezinje ngeFedora, Ubuntu, Arch, njl.

[Jonga uphando lwam lokufumana umatshini osebenzayo we-Android osebenzayo] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Jonga indlela yokwenza igoogle kuAndroid] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

##Izenzo ezincinci zokunceda

Ukusasaza ulwazi ngayo yonke indlela onako ngayo kubalulekile. Kum, andisoloko ndithetha ngokuzikhwebula emsebenzini, kwaye ndibhala amanqaku, kodwa ndinomkhwa omncinci, apho ndinikezela ngembasa yam yasimahla yeReddit kwisithuba esikhonkxiweyo kwi-r / degoogle ukukhulisa ulwazi. Ukuza kuthi ga ngoku, ndinike phantse amabhaso angama-30 kwisithuba esikhonkxiweyo (ndikhe ndachitha imali engama-500 yeemali zam zasimahla kumabhaso ali-10 kweso sithuba)

***

## Ayinakuthenjwa

UGoogle akanakuthenjwa, kwaye akasoze athembeke kwakhona. Bemkile ngokupheleleyo "ungabi mbi" (babehlala benobubi) baye ekubeni ngabangendawo ngokupheleleyo kwaye bangazami ukukufihla.

***

## Ezinye izinto oza kuzijonga

[Amangcwaba kaGoogle (killbygoogle.com) - uluhlu oluhleliweyo lweemveliso ezingama-224 + ezibulewe nguGoogle] (https://killedbygoogle.com/)

> [Ikhonkco leGitHub] (https://github.com/codyogden/killedbygoogle)

[Umanyano wabasebenzi beAlfabhethi - Umanyano wabasebenzi kuGoogle onamalungu angaphezu kwe-800] (https://alphabetworkersunion.org/people/our-union/)

[Awufuni ukwahlukana neqanda lephasika? Le webhusayithi uyigubungele] (https://chromedino.com/)

Kukho ezinye iindlela, khangela nje.

***

Ukujonga inyani kuyafuneka kweli nqaku

***

# # Ulwazi lwefayile

Uhlobo lwefayile: `Uphawu (* .md)`

Ukubalwa kwemigca (kubandakanya imigca engenanto kunye nomgca wokuhlanganisa): `968`

Inguqulelo yefayile: `` 6 (ngeCawa, nge-18 ka-Epreli ka-2021 ngo-4: 18 ngokuhlwa) '

***

### Isimo seSoftware

Yonke imisebenzi yam isimahla kwezinye izithintelo. I-DRM (** D ** igital ** R ** izithintelo ** M ** ukulawulwa) ayikho kuyo nayiphi na imisebenzi yam.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Esi sincamatheliso sixhaswa yiFree Software Foundation. Andizimiselanga kufaka i-DRM kwimisebenzi yam.

Ndisebenzisa isifinyezo esithi "Ulawulo lweZithintelo zedijithali" endaweni yaziwa kakhulu "uLawulo lwamalungelo edijithali" njengeyona ndlela iqhelekileyo yokujongana nobuxoki, akukho malungelo nge-DRM. Upelo "Ulawulo lwezithintelo zedijithali" luchanekile, kwaye luxhaswa ngu- [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) kunye ne- [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Eli candelo lisetyenziselwa ukuphakamisa ulwazi ngeengxaki nge-DRM, kunye nokuqhankqalaza. I-DRM inesiphene kuyilo kwaye isisongelo esikhulu kubo bonke abasebenzisi bekhompyuter kunye nenkululeko yesoftware.

Ityala lemifanekiso: [defectivebydesign.org/drm-free/...] (https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Ulwazi lomxhasi

! [SponsorButton.png] (SponsorButton.png) <- Sukucofa eli qhosha, alisebenzi, ngumfanekiso nje. Iqhosha lokwenyani liphezulu kwiphepha ekunene (<- L ** R ** ->) kwikona

Ungayixhasa le projekthi ukuba uyathanda, kodwa nceda ucacise ukuba ufuna ukunikela ngantoni. [Jonga imali onokuthi unikele ngayo apha] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Ungalujonga olunye ulwazi lomxhasi [apha] (https://github.com/seanpm2001/Sponsor-info/)

Yizame! Iqhosha labaxhasi lilungile ecaleni kwewotshi / iqhosha lokungajongi.

***

# # Imbali yefayile



 * Uqale ifayile

> * Yongeze icandelo lesihloko

> * Yongeze isalathiso

> * Yongeze malunga necandelo

> * Yongeze icandelo leWiki

> * Yongeze icandelo lembali yenguqulo

> * Yongeze icandelo lemicimbi.

> * Yongeze icandelo lemicimbi edlulileyo

> * Yongeze icandelo elidlulileyo lezicelo zokutsala

> * Yongeze icandelo lezicelo ezisebenzayo zokutsala

> * Yongeze icandelo labaxhasi

> * Yongeze icandelo elinikelayo

> * Yongeze malunga necandelo leREADME

> * Wongeze icandelo lembali yenguqulo yeREADME

> * Yongeze icandelo lezixhobo

> * Yongeze icandelo lesimo sesoftware, ngesitikha sasimahla se-DRM kunye nomyalezo

> *Yongeze icandelo lolwazi lomxhasi

> * Alukho olunye utshintsho kuhlobo lwe-0.1

Inguqulelo 1 (ngolwesiHlanu, ngoFebruwari 19 2021 nge-5: 20 pm)

> Utshintsho:

> * Uqale ifayile

> * Yongeze icandelo lenkcazo esisiseko

> * Yongeze icandelo lokuchaza

> * Yongeze uluhlu lwamanqaku, kunye namangeniso ali-14

>> * Yongeze `icandelo elinamanqaku ahambelana`

>> * Yongeze `jonga kwakhona` icandelo

> * Yongeze icandelo lolwazi lwefayile

> * Yongeze icandelo lembali yefayile

> * Yongeza i-footer

> * Alukho olunye utshintsho kuhlobo 1

Inguqulelo yesi-2 (ngolwesiHlanu, ngoFebruwari 19 2021 nge-5: 26 pm)

> Utshintsho:

> * Yongeze icandelo lokuguqula imeko

> * Yongeze ezinye izinto ukujonga icandelo

> * Yongeze icandelo labucala

> * Yongeze isalathiso

> * Yongeze icandelo lesimo sesoftware

> * Yongeze elinye icandelo lokulwa neGoogle

>> * Wongeze icandelo elingasasebenziyo

>> * Yongeze isiqendwana esiqhubekayo

> * Yongeze icandelo lemithombo

> * Yongeze icandelo lokudibanisa ukhuphelo

> * Uhlaziye icandelo lolwazi lwefayile

> * Uhlaziye icandelo lembali yefayile

> * Alukho olunye utshintsho kuhlobo 2

Inguqulelo yesi-3 (ngolwesiThathu, ngoFebruwari 24 2021 ngo-7: 56 pm)

> Utshintsho:

> * Uhlaziyo lwesalathiso

> * Ebhekisa kwi icon degoogle kunye nombutho omtsha weGitHub

> * Yongeza amakhonkco kumanqaku amatsha

> * Yongeze ukuphikiswa kwamanye amacandelo

>> * Yongeze isiqendu esifanelekileyo

>> * Wongeze kutheni usokolisa necandelwana

>> * Wongeze elinye icandelo

> * Uhlaziye idatha ethile

> * Uhlaziye icandelo lolwazi lwefayile

> * Uhlaziye icandelo lembali yefayile

> * Alukho olunye utshintsho kuhlobo 3

Inguqulelo yesi-4 (ngolwesiHlanu, nge-25 kaFebruwari 2021 ngo-9: 31 ntambama)

> Utshintsho:

> * Yongeza amakhonkco kumanqaku ali-10 amatsha

> * Wongeze icandelo malunga namava am

> * Uhlaziyo lwesalathiso

> * Uhlaziye icandelo lolwazi lwefayile

> * Uhlaziye icandelo lembali yefayile

> * Alukho olunye utshintsho kuhlobo 4

Inguqulelo yesi-5 (ngolwesiHlanu, Epreli 9th 2021 nge-6: 02 pm)

_Kubekho ukunqongophala kohlaziyo kwinto elwa noGoogle ukusuka kum mva nje, ndiyasebenza ukubuyela kuyo emva kwenyanga eyi-1 + hiatus._

> Utshintsho:

> * Uhlaziye icandelo lesihloko

> * Uhlaziyo lwesalathiso

> * Uhlaziyo loluhlu lweelwimi: amakhonkco aqingqiweyo, kwaye wongeza iilwimi ezixhaswayo

> * Uhlaziye icandelo leenqaku, ukongeza ii-4 zeefolokhwe

> * Ukuhlaziywa kwecandelo lesimo sesoftware

> * Ukongezwa kweCandelo elibi

> * Yongeze ukusetyenziswa kwecandelo le-DRM

> * Yongeze icandelo eliqhelekileyo lokuqonda gwenxa

>> * Ukongezwa kweGoogle ayisiyo icandelo le-Intanethi

> * Yongeze i-Intanethi Explorer 6 kunye necandelo leChannel

>> * Yongeze ingxaki kwicandelwana elinesibindi

> * Yongeze ukususwa kwabucala kweFaux

> * Ukongezwa komthombo ovulekileyo akunakuba licandelwana elithile

> * Yongezwe icandelo le-Oxymoron

> * Yongeze icandelo lokusebenza kakubi

> * Yongeze icandelo lolawulo lweprojekthi embi

> * Yongeze ukungcolisa okanye ukungamodareyithwa kwecandelo leenkonzo

> * Yongeze icandelo le-Astroturfing

> * Yongeze icandelo lezenzo ezingekho mthethweni nezingekho mgaqweni

> * Yongeze icandelo laseYurophu

>> * Yongeze icandelo laseNyakatho Melika

>> * Wongeze icandelo leempikiswano

> * Yongezwe icandelo likaGoogle elizenzekelayo

> * Yongeze icandelo le-Android

> * Yongeze izinto ezincinci ukunceda icandelo

> * Yongeze icandelo elingenakuthenjwa

> * Yongeze icandelo lolwazi lomxhasi

> * Uhlaziyo lweenyawo

> * Uhlaziye icandelo lolwazi lwefayile

> * Uhlaziye icandelo lembali yefayile

> * Alukho olunye utshintsho kuhlobo 5

Inguqulelo yesi-6 (ngeCawa, nge-18 ka-Epreli 2021 ngo-4: 18 ntambama)

> Utshintsho:

> * Uhlaziyo lwesalathiso

> * Yongeze inkcazo yesishwankathelo esitsha

> * Ulwazi lwenqaku elihlaziyiweyo

> * Yongeze ikhonkco kwinqaku elitsha leGoogle FLoC

> * Yongeze ikhonkco kwinqaku le-Wuest 3n Fuchs Degoogle kunye nolwazi ngokubanzi kuyo

> * Uhlaziye icandelo lolwazi lwefayile

> * Uhlaziye icandelo lembali yefayile

> * Alukho olunye utshintsho kuhlobo 6

Inguqulelo 7 (Iyeza kungekudala)

> Utshintsho:

> * Iyeza kungekudala

> * Alukho olunye utshintsho kuhlobo 7

Inguqulelo 8 (Iyeza kwakamsinya)

> Utshintsho:

> * Iyeza kungekudala

> * Alukho olunye utshintsho kuhlobo 8

Inguqulelo 9 (Iyeza kwakamsinya)

> Utshintsho:

> * Iyeza kungekudala

> * Alukho olunye utshintsho kuhlobo 9

Inguqulelo 10 (iyeza kungekudala)

> Utshintsho:

> * Iyeza kungekudala

> * Alukho olunye utshintsho kuhlobo lwe-10

Inguqulelo 11 (iyeza kungekudala)

> Utshintsho:

> * Iyeza kungekudala

> * Alukho olunye utshintsho kuhlobo lwe-11

Inguqulelo 12 (iyeza kungekudala)

> Utshintsho:

> * Iyeza kungekudala

> * Alukho olunye utshintsho kuhlobo lwe-12

***

## Imibhalo engezantsi

Ufikelele esiphelweni sale fayile

([Buyela phezulu] (# Phezulu) | [Buyela kwiGitHub] (https://github.com))

### EOF

***
