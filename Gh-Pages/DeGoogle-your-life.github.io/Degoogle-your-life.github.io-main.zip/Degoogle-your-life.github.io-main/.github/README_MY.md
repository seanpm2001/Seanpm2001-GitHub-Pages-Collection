***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - သင်၏ဘ ၀ ကိုဂူဂယ်လ်သို့ပို့ပါ

ဤသည်ယေဘုယျ degoogling အချက်အလက်အတွက်အဓိက degoogling ဆောင်းပါးနှင့်အခြားဆောင်းပါးများနှင့်လင့်ခ်ဖြစ်သည်။

[စာရင်းကို GitHub အဖွဲ့အစည်းအနေဖြင့်ကြည့်ပါ] (https://github.com/Degoogle-your-life)

***

_ ဒီစာမူကိုအခြားဘာသာစကားနဲ့ဖတ်ပါ။ _

** လက်ရှိဘာသာစကားမှာ - ** `အင်္ဂလိပ် (ယူအက်စ်)` `(အင်္ဂလိပ်သည်မှန်ကန်သောဘာသာစကားနေရာတွင်အစားထိုးပြင်ဆင်ရန်ဘာသာပြန်ချက်များကိုပြုပြင်ရန်လိုအပ်နိုင်သည်) _

_🌐ဘာသာစကားစာရင်း။

** ဖြင့်စီထားသည်။ ** `A-Z`

[ရွေးချယ်မှုများကိုမရရှိနိုင်ပါ။ ] (https://github.com/Degoogle-your-Life)

([Afrikaans Afrikaans] (/ github / README_AF.md) အာဖရိကန် | [sqq Shqiptare] (/ github / README_SQ.md) အယျလျဘေးနီးယား | [am አማርኛ] (/ ။ github / README_AM.md) အမ်ဟာရစ် | [ar عربى] (/.github/README_AR.md) အာရပ်ဘာသာစကား | [hy հայերեն] (/ ။ github / README_HY.md) အာမေးနီးယား | [az Azərbaycan dili] (/ ။ github / README_AZ.md) အဇာဘိုင်ဂျန် | [EU euskara] (/ ။ github) /README_EU.md) ဘစ်စကီ | [be Беларуская] (/ ။ github / README_BE.md) ဘီလာရုစ် | [ဘီလီယံ (] (/ ။ github / README_BN.md) ဘင်္ဂါလီ | [bs Bosanski] (/ ။ github / README_BS.md) ဘော့စျနီးယား | [bg български] (/ ။ github / README_BG.md) ဘူဂေးရီးယား | [ca Català] (/ ။ github / README_CA.md) ကက်တလန် | [ceb Sugbuanon] (/ ။ github / README_CEB.md) Cebuano | [ny Chichewa | ] (။ ။ github / README_NY.md) Chichewa | [zh-CN 简体中文] (/ github / README_ZH-CN.md) တရုတ် (ရိုးရှင်း) | [zh-t 中國傳統的）] (/ ။ github / README_ZH) -T.md) တရုတ် (ရိုးရာ) | [co Corsu] (/ github / README_CO.md) Corsican | [hr Hrvatski] (/ ။ github / README_HR.md) ခရိုအေရှန် | [cs čeština] (/ ။ github / README_CS) .md) ချက် ([da dansk] (README_DA.md) ဒိန်းမတ် | [nl Nederlands] (/ github / README_ NL.md) ဒတ်ခ်ျ | [** en-us English **] (/ ။ github / README.md) အင်္ဂလိပ် | [EO Esperanto] (/ ။ github / README_EO.md) အက်စပရန်တို | [et Eestlane] (/ github / README_ET.md) အက်စ်တိုးနီးယား | [ဖိလစ်ပိုင် tl] (/ ။ github / README_TL.md) ဖိလစ်ပိုင် | [fi Suomalainen] (/ ။ github / README_FI.md) ဖင်လန် | [fr français] (။ ။ github / README_FR.md) ပြင်သစ် [fy Frysk] (/ ။ github / README_FY.md) Frisian | [gl Galego] (/ github / README_GL.md) Galician | [ka ქართველი] (/ ။ github / README_KA) ဂျော်ဂျီယာ | [က de Deutsch] (။ ။ github / README_DE.md) ဂျာမန်။ [el Ελληνικά] (/ ။ github / README_EL.md) ဂရိ | [gu ગુજરાતી] (/ ။ github / README_GU.md) ဂူဂျာရီးယား | [ht Kreyòl ayisyen] (/ ။ github / README_HT.md) Haitian Creole | [ha Hausa] (။ ။ github / README_HA.md) ဟာဟာစာ | [haw Ōlelo Hawaiʻi] (/ ။ github / README_HAW.md) ဟာဝယေံ | [သူעִברִית] (/ ။ github / README_HE.md) ဟီဘရူး | [hi हिन्दी] (/ ။ github / README_HI.md) ဟိန္ဒူ | [hmn Hmong] (။ ။ github / README_HMN.md) Hmong | [hu Magyar] (/ ။ github / README_HU.md) ဟနျဂရေီ | (/ lslenska) သည် (/ github / README_IS.md) အိုက်စလန်ဖြစ်သည် [Igbo ig] (/ ။ github / README_IG.md) အစ်ဂဘို | [id bahasa Indonesia] (/ ။ github / README_ID.md) အိုက်စလန် | [ga Gaeilge] (/ ။ github / README_GA.md) အိုငျးရစျ | [it Italiana / Italiano] (။ ။ github / README_IT.md) | [ja 日本語] (/ github / README_JA.md) ဂျပန်။ [jw Wong Jawa] (/ ။ github / README_JW.md) ဂျာဗားနီးယား | [kn ಕನ್ನಡ] ကန်နာဒါ။ (/ ။ github / README_KN.md) | [kk Қазақ] (/ ။ github / README_KK.md) Kazakh | [km ខ្មែរ] Khmer / | github / README_KM.md) ခမာ | [rw Kinyarwanda] (/ ။ github / README_RW.md) Kinyarwanda | [ko-south 韓國語] (/ ။ github / README_KO_SOUTH.md) ကိုရီးယား (တောင်ပိုင်း) | [ko-north 문화어] (README_KO_NORTH.md) ကိုရီးယား (မြောက်ပိုင်း) (ဘာသာပြန်ခြင်းမရှိ) | [ku Kurdî] (/ ။ github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/ ။ github / README_KY.md) ခရူဂ | [lo ລາວ] (/ github / README_LO.md) လာအို။ [la လက်တင်] (။ ။ github / README_LA.md) လက်တင် | [ဒု Lietuvis] (။ / github / README_LT.md) လစ်သူယေးနီးယား [lb Lëtzebuergesch] (/ ။ github / README_LB.md) လူဇင်ဘတ် | [mk Македонски] (/ ။ github / README_MK.md) Macedonian | [mg mg Malagasy] (/ ။ github / README_MG.md) အာလာဂါစီ | [ms Bahasa Melayu] (/ ။ github / README_MS.md) မလေး | [ml ml] (/ github / README_ML.md) မလေးရာလ | [mt Malti] (/ ။ github / README_MT.md) Maltese | [မိုင်ရီ] (/ ။ github / README_MI.md) Maori | [mr मराठी] (/ ။ github / README_MR.md) မာရသီ | [mn Монгол] (/ ။ github / README_MN.md) မွန်ဂို | [my မြန်မာ] (/ ။ github / README_MY.md) မြန်မာ (မြန်မာ) | [ne नेपाली] (/ ။ github / README_NE.md) နီပေါ [no norsk] (/ github / README_NO.md) နော်ဝေ | [or ଓଡିଆ (ଓଡିଆ)] (/ ။ github / README_OR.md) Odia (Oriya) | [ps پښتو] (/ ။ github / README_PS.md) ပါရှ်တို | [fa فارسی] (/ ။ github / README_FA.md) | ပါရှန်း [pl polski] (/ ။ github / README_PL.md) ပိုလန် | [pt português] (/ github / README_PT.md) ပေါ်တူဂီ | [pa ਪੰਜਾਬੀ] (/ ။ github / README_PA.md) ပနျဂြာ | Q | အက္ခရာနှင့်စတင်သောဘာသာစကားများမရှိပါ [ro Română] (/ ။ github / README_RO.md) ရိုမေးနီးယား | [ru русский] (/ ။ github / README_RU.md) ရုရှား | [sm Faasamoa] (။ ။ github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/ ။ github / README_GD.md) စကော့ [sr Српски] (/ ။ github / README_SR.md) ဆားဗီးယား | [st Sesotho] (။ ။ github / README_ST.md) Sesotho | [SN Shona] (။ ။ github / README_SN.md) Shona | [sd سنڌي] (/ ။ github / README_SD.md) စင်ဒီ | [si සිංහල] (/ ။ github / README_SI.md) ဆငျဟာလ | [sk Slovák] (/ ။ github / README_SK.md) စလိုဗက် | [sl Slovenščina] (/ ။ github / README_SL.md) ဆလိုဗေးနီးယား | [ဒါ Soomaali] (/ ။ github / README_SO.md) ဆိုမာလီ | [[es en español] စပိန် | / / github / README_ES.md) [su Sundanis] (/ github / README_SU.md) ဆူဒန် | [sw Kiswahili] (/ ။ github / README_SW.md) ဆွာဟီလီ | [SV Svenska] (/ ။ github / README_SV)md) ဆွီဒင် [tg Тоҷикӣ] (/ ။ github / README_TG.md) Tajik | [ta தமிழ்] (/ github / README_TA.md) တမီး | [tt Татар] (/ ။ github / README_TT.md) Tatar | [te తెలుగు] (/ ။ github / README_TE.md) တီလူ [ကြိမ်မြောက် Thai] (/ github / README_TH.md) ထိုင်း | [TR တူရကီ] (/ ။ github / README_TR.md) တူရကီ | [tk Türkmenler] (/ ။ github / README_TK.md) Turkmen | [uk Український] (/ ။ github / README_UK.md) ယူကရိန်း | [ur اردو] (/ ။ github / README_UR.md) အူဒူ | [ug ئۇيغۇر] (/ ။ github / README_UG.md) ဥဂါးရ် | [uz O'zbek] (/ ။ github / README_UZ.md) Uzbek | [vi TiếngViệt] (/ ။ github / README_VI.md) ဗီယက်နမ် | [cy Cymraeg] (/ ။ github / README_CY.md) ဝလေ | [။ xh isiXhosa] (/ github / README_XH.md ။ ) Xhosa | [yi יידיש] (/ ။ github / README_YI.md) Yiddish | [yo Yoruba] (/ ။ github / README_YO.md) ရိုရုဘာ | [zu Zulu] (/ ။ github / README_ZU.md) ဇူလူ) ဘာသာစကား ၁၁၀ ဖြင့်ရရှိနိုင်သည်။ မြောက်ကိုရီးယားကိုမပြန်ရသေးသောကြောင့် ၁၀၈ အင်္ဂလိပ်နှင့်မြောက်ကိုရီးယားကိုမရေတွက်လျှင် ၁၀၈ ရရှိနိုင်သည်။ (OldVersions / Korean (North) ) /README.md))

အင်္ဂလိပ် မှလွဲ၍ အခြားဘာသာဖြင့်ဘာသာပြန်ထားသောစက်များသည်စက်ဖြင့်ပြန်ဆိုထားသောကြောင့်တိကျမှုမရှိသေးပါ။ ၂၀၂၁ ခုနှစ်ဖေဖော်ဝါရီ ၅ ရက်အထိအမှားများကိုမဖြေရှင်းနိုင်ပါ။ ကျေးဇူးပြု၍ ဘာသာပြန်အမှားများကိုဤနေရာတွင်အစီရင်ခံပါ (https://github.com/seanpm2001/Degoogle-your-life/issues/) သည်သင်၏အမှားကိုရင်းမြစ်များနှင့်အရန်ကူးယူပြီးသေချာအောင်ပြုလုပ်ပါ။ ကျွန်ုပ်အင်္ဂလိပ်ဘာသာ မှလွဲ၍ အခြားဘာသာစကားများကိုမသိသောကြောင့် (နောက်ဆုံးတွင်ဘာသာပြန်ရန်စီစဉ်ထားသည်) ကျေးဇူးပြု၍ [wiktionary] (https://en.wiktionary.org) နှင့်သင်၏အစီရင်ခံစာတွင်အခြားရင်းမြစ်များကိုကိုးကားပါ။ ယင်းသို့ပြုလုပ်ရန်ပျက်ကွက်ပါကပြင်ဆင်ခြင်းကိုပယ်ချလိမ့်မည်။

မှတ်ချက် - GitHub ရဲ့ markdown အဓိပ္ပာယ်ဖွင့်ဆိုချက်နှင့် (နှင့်အခြား web-based markdown ၏တော်တော်များများ) ကန့်သတ်ချက်များကြောင့်ဒီလင့်ခ်များကိုနှိပ်ခြင်းအားဖြင့်သင့် GitHub ပရိုဖိုင်စာမျက်နှာမဟုတ်သောသီးခြားစာမျက်နှာတစ်ခုသို့သီးခြားဖိုင်တစ်ခုဆီသို့လမ်းကြောင်းပြောင်းလိမ့်မည်။ README တည်နေရာရှိ [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001) သို့သင့်အားသင်လမ်းကြောင်းပြောင်းလိမ့်မည်။

DeepL နှင့် Bing Translate (ဂူဂဲလ်ဆန့်ကျင်ရေးလှုံ့ဆော်မှုအတွက်မထင်မှတ်သောအရာ) ကဲ့သို့သောအခြားဘာသာပြန်ဝန်ဆောင်မှုများတွင်ကျွန်ုပ်လိုအပ်သောဘာသာစကားများကိုအကန့်အသတ်ဖြင့်သာအထောက်အပံ့ဖြစ်စေခြင်းဖြင့်ဘာသာပြန်မှုများကို Google Translate ဖြင့်ပြုလုပ်သည်။ ကျွန်ုပ်သည်အခြားနည်းလမ်းရှာရန်ကြိုးစားနေသည်။ အကြောင်းပြချက်အချို့အတွက် (link များ၊ dividers, bolding, စာလုံးစောင်းစသည်ဖြင့်) ကိုပုံစံအမျိုးမျိုးဖြင့်ဘာသာပြန်ထားသောဘာသာပြန်များတွင်ရှုပ်ထွေးနေသည်။ ဒါကိုပြင်ဖို့အရမ်းပင်ပန်းတယ်၊ ဒီပြissuesနာတွေကိုလက်တင်မဟုတ်တဲ့အက္ခရာတွေနဲ့ဘာသာစကားနဲ့ဘယ်လိုဖြေရှင်းရမှန်းကျွန်တော်မသိဘူး၊ ဒီပြissuesနာတွေကိုပြုပြင်ရာမှာဘယ်လက် (ဘယ်) (ဘယ်လို) လက်ဝဲဘာသာစကားတွေလိုအပ်တယ်။

ပြုပြင်ထိန်းသိမ်းမှုဆိုင်ရာပြissuesနာများကြောင့်ဘာသာပြန်များစွာသည်ခေတ်နောက်ကျနေသောဤ README ဆောင်းပါးဖိုင်၏ခေတ်မမီတော့သောဗားရှင်းကိုအသုံးပြုနေကြသည်။ ဘာသာပြန်တစ် ဦး လိုအပ်သည် ဒါ့အပြင် ၂၀၂၁ ခုနှစ်Aprilပြီလ ၉ ရက်နေ့မှာအချိတ်အဆက်တွေအားလုံးကိုအလုပ်လုပ်ဖို့ကျွန်တော့်ကိုခဏလောက်ခဏကြာတော့မယ်။

***

## ညွှန်းကိန်း

[00.0 - Title] (# Degoogling --- Degoogle-your-life)

> [00.1 - အညွှန်းကိန်း] (# အညွှန်းကိန်း)

[01.0 - အခြေခံဖော်ပြချက်] (# အခြေခံဖော်ပြချက်)

> [01.1 - Repository header] (# Degoogle-your-life)

> [01.2 - Wuest3NFuchs ဖော်ပြချက်ခြုံငုံသုံးသပ်ချက်] (# ခြုံငုံသုံးသပ်ချက် -by-Wuest3nFuchs)

>> [01.2.1 - ဘာကိုဆိုလိုတာလဲ?] (# ဘာလဲ - ဘာကိုဆိုလိုတာလဲ - by-Wuest3nFuchs)

>> [01.2.2 - ဘာကြောင့် Degoogle လဲ?] (# Why-Degoogle - by-Wuest3nFuchs)

[၂.၀ - ဆောင်းပါးများ] (# ဆောင်းပါးများ)

[03.0 - privacy] (# သီးသန့်တည်ရှိမှု)

[04.0 - အခြားဂူဂဲလ်ဆန့်ကျင်ရေးလှုပ်ရှားမှုများ] (# အခြားဂူဂဲလ်ဆန့်ကျင်ရေးလှုပ်ရှားမှုများ)

> [04.0.1 - Defunct] (# Defunct)

> [၀၄.၀.၂ - ဆက်လက်ဖြစ်ပွားနေသော] (# ဆက်လက်ဖြစ်ပွားနေသော)

[05.0 - အခြားအငြင်းပွားမှုများကိုတန်ပြန်ခြင်း] (# တန်ပြန် - အခြားအငြင်းပွားမှုများ)

> [05.0.1 - အဆင်ပြေမှု] (# အဆင်ပြေ)

> [05.0.2 - ဘာကြောင့်အရေးပါသလဲ ဘာပဲဖြစ်ဖြစ်သိပ်နောက်ကျသွားပြီ] (# ဘာကြောင့်လဲ - ဘာဖြစ်လို့လဲဆိုတော့ - ကိစ္စမရှိ၊

> [05.0.3 - Other] (# Other)

[06.0 - သတင်းရင်းမြစ်] (# ရင်းမြစ်များ)

[07.0 - လင့်ခ်များကိုဒေါင်းလုပ်ချရန်] (# ဒေါင်းလုပ်ချလင့်ခ်)

[08.0 - ကျွန်ုပ်၏ deogogling အတွေ့အကြုံ] (# My-degoogling-experience)

> [08.1 - ကျွန်ုပ်ထံမှပြောင်းလဲခြင်း] (# What-I-switched-from)

> [08.2 - ကျွန်ုပ်ထုတ်ယူနိုင်သေးသည့်ထုတ်ကုန်များ] (# Products-I-still-can-get-away-from)

[09.0 - ထွက်ရန်အခြားအရာများ] (# အခြားအရာများမှထွက်ပစ္စည်းများသို့)

[10.0 - ဖိုင်အချက်အလက်] (# ဖိုင် - အချက်အလက်)

> [10.1 - Software Status] (# Software-status)

> [10.2 - ပံ့ပိုးကူညီသူအချက်အလက်] (# စပွန်ဆာ - အချက်အလက်)

[၁၁.၀ - ဖိုင်မှတ်တမ်းမှတ်တမ်း] (# ဖိုင် - မှတ်တမ်း)

[၁၂.၀ - Footer] (# Footer)

***

## အခြေခံဖော်ပြချက်

[Wikipedia မှ: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

DeGoogle လှုပ်ရှားမှု (de-Google လှုပ်ရှားမှုဟုလည်းခေါ်သည်) သည်အောက်ခြေလူထုစည်းရုံးလှုံ့ဆော်ရေးတစ်ခုဖြစ်သည်။ privacy လှုပ်ရှားသူများကကုမ္ပဏီနှင့်ပတ်သက်သော privacy ဆိုင်ရာစိုးရိမ်ပူပန်မှုများကြီးထွားလာခြင်းကြောင့်ဂူးဂဲလ်ထုတ်ကုန်များကိုလုံး ၀ အသုံးမပြုရန်တိုက်တွန်းသည်။ ထိုအသုံးအနှုန်းသည် Google အားလူတစ် ဦး ၏ဘဝမှဖယ်ရှားခြင်းလုပ်ရပ်ကိုရည်ညွှန်းသည်။ အင်တာနက်ကုမ္ပဏီကြီး၏စျေးကွက်ဝေစုတိုးပွားလာခြင်းကြောင့်ကုမ္ပဏီအတွက်ဒစ်ဂျစ်တယ်နေရာများတွင်လက်ဝါးကြီးအုပ်နိုင်စွမ်းကိုဖန်တီးပေးသောကြောင့်ဂျာနယ်လစ်အရေအတွက်တိုးပွားလာသည်နှင့်အမျှကုမ္ပဏီ၏ထုတ်ကုန်များအတွက်အခြားရွေးချယ်စရာများရှာဖွေရန်အခက်အခဲရှိသည်။

** သမိုင်း **

၂၀၁၃ ခုနှစ်တွင် Venturebeat မှ John Koetsier က Amazon ၏ Kindle Fire Android အခြေခံ tablet သည်“ ဂူးဂဲလ်မှအသုံးပြုသော Android ဗားရှင်း” ဖြစ်သည်ဟုပြောကြားခဲ့သည်။ ၂၀၁၄ ခုနှစ်တွင် US News မှ John Simpson က Google နှင့်အခြားရှာဖွေရေးအင်ဂျင်များ၏“ မေ့ပျောက်ခံရပိုင်ခွင့်” အကြောင်းရေးသားခဲ့သည်။ ၂၀၁၅ ခုနှစ်တွင် Irish Times မှ Derek Scally မှ“ သင်၏ဘဝကိုဂူဂဲလ်မှဖယ်ရှားခြင်း” အကြောင်းဆောင်းပါးတစ်ပုဒ်ရေးခဲ့သည်။ 2016 ခုနှစ်တွင် Androi ၏ Kris Carlon ကAuthority အာဏာပိုင်များက CyanogenMod 14 အသုံးပြုသူများသည်သူတို့၏ဖုန်းများကို“ de-Google” ပြုလုပ်နိုင်သည်ဟုအကြံပြုသည်။ အဘယ်ကြောင့်ဆိုသော် CyanogenMod သည်ဂူဂဲလ်အက်ပလီကေးရှင်းများမပါဘဲကောင်းမွန်စွာအလုပ်လုပ်သောကြောင့်ဖြစ်သည်။ ၂၀၁၈ ခုနှစ်တွင် Inverse မှ Nick Lucchesi ကသင်၏ဘဝကိုလုံးဝ Google မှဖယ်ရှားပေးနိုင်ခြင်းကိုမည်သို့ ProtonMail ကမည်သို့မြှင့်တင်ခဲ့သည်ကိုရေးသားခဲ့သည်။ Lifehacker ၏ Brendan Hesse က "ဂူဂဲလ်မှထွက်ခွာခြင်း" အကြောင်းအသေးစိတ်သင်ခန်းစာကိုရေးသားခဲ့သည်။ Gizmodo သတင်းစာဆရာ Kashmir Hill ကသူမသည်အစည်းအဝေးများကိုလွဲချော်ပြီး Google Calendar ကိုအသုံးမပြုဘဲတွေ့ဆုံခြင်းအစီအစဉ်များကိုစီစဉ်ရာတွင်အခက်အခဲရှိသည်ဟုပြောကြားခဲ့သည်။ ၂၀၁၉ ခုနှစ်တွင် Huawei သည်ဖိလစ်ပိုင်ရှိဖုန်းပိုင်ရှင်များအားငွေပြန်အမ်းပေးခဲ့သည်။ Google မှပေးသော ၀ န်ဆောင်မှုများကိုအသုံးပြုခြင်းမှတားဆီးသည်မှာအဘယ်ကြောင့်ဆိုသော်ကုမ္ပဏီ၏ထုတ်ကုန်များမရှိခြင်းကြောင့်သာမန်အင်တာနက်အသုံးပြုမှုကိုမဖြစ်နိုင်သည့်နည်းလမ်းများနည်းပါးသောကြောင့်ဖြစ်သည်။

***

# Degoogle-your-life
ယေဘူယျ degoogling အချက်အလက်နှင့်ကျွန်ုပ်၏အခြား deogogling repositories နှင့်ဆက်စပ်သောလင့်များ။

***

## Wuest3nFuchs အားဖြင့်ခြုံငုံသုံးသပ်ချက်

ပိုမိုကောင်းမွန်သောဖော်ပြချက် [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - ရင်းမြစ် - [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### ဘာကိုဆိုလိုတာလဲ? Wuest3nFuchs ဖြင့်ပြုလုပ်နိုင်ပါတယ်

ဂူဂဲလ်မှပြုလုပ်သောမည်သည့်အရာကိုမဆိုအသုံးပြုခြင်းကိုရပ်တန့်ရန် [Degoogling နည်းလမ်းများ] (https://en.wikipedia.org/wiki/DeGoogle) ။ ငါသူတို့ [ရှာဖွေရေးအင်ဂျင်] (https://en.wikipedia.org/wiki/Google_Search)၊ သူတို့၏စာပို့ဝန်ဆောင်မှု ([Gmail] (https://en.wikipedia.org/wiki/Gmail)] အကြောင်းပြောနေခြင်းဖြစ်သည်။ Youtube] (https://en.wikipedia.org/wiki/Criticism_of_Google#YouTube), [etc] (https://en.wikipedia.org/wiki/List_of_Google_products)

### ဘာကြောင့် Degoogle လဲ? Wuest3nFuchs ဖြင့်ပြုလုပ်နိုင်ပါတယ်

Google သည်ကမ္ဘာပေါ်တွင်အင်အားအကြီးဆုံးကုမ္ပဏီများအနက်မှတစ်ခုဖြစ်သည်။ [သူတို့] (https://www.cnbc.com/2017/11/20/what-does-google-know-about-me.html) [ရှိသည်] (https://vulcanpost.com/636465/google-) personal-info /) သည်သတင်းအချက်အလက်အမြောက်အမြားကိုသိမ်းဆည်းထားသည် (https://www.security-faqs.com/how-many-ways-does-google-store-your-personal-information.html) [on] ( https://www.cnet.com/how-to/google-collects-a-frightening-amount-of-data-about-you-you-can-find-and-delete-it-now/) [အားလုံး] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [of] (https://www.nbcnews.com / နည်းပညာ / နည်းပညာ - သတင်း / ဂူဂဲလ် - ရောင်းချခြင်း - အနာဂတ် - စွမ်းအင် - သင့် - ကိုယ်ရေးကိုယ်တာအချက်အလက် - n870501) [us] (https://www.wired.com/story/google-tracks-you-privacy/) အချို့ကမိမိတို့၏သတင်းအချက်အလက်သည်၎င်းတို့အားမည်သို့ကာကွယ်ရမည်ကိုသိသောကြောင့်သူတို့နှင့်အတူလုံခြုံသည်ဟုဆိုကြသည်။ ဒါပေမဲ့ဒါမမှန်ပါဘူး ဂူးဂဲလ်ဟာအရင်ကထိုးဖောက်ခံထားရတဲ့အတွက်နောင်အနာဂတ်မှာထိုးဖောက်နိုင်လိမ့်မယ်။ ဒီတစ်ခါလည်းအချို့သော script kiddie မှမဟုတ်သော်လည်း၎င်းကိုနိုင်ငံတစ်နိုင်ငံမှပြုလုပ်လိမ့်မည်။ ဂူဂဲလ်သည်ကျွန်ုပ်တို့အားလုံးအပေါ်ပုဂ္ဂိုလ်ရေးဆိုင်ရာအချက်အလက်များကိုသိုလှောင်သည်။

[သူတို့သည်ကျွန်ုပ်တို့၏အီးမေးလ်များကိုစကင်ဖတ်စစ်ဆေးသည်] (https://www.forbes.com/sites/daveywinder/2020/02/28/google-confirms-new-ai-tool-scans-300-billion-gmail-attachments-every-week /), [ကျွန်ုပ်တို့၏ရှာဖွေရေးအင်ဂျင်ကိုအသုံးပြုသောအခါကျွန်ုပ်တို့ရှာဖွေသောအရာကိုသိမ်းဆည်းပါ] (https://www.wired.com/story/google-tracks-you-privacy/), [Youtube တွင်ကျွန်ုပ်တို့ကြည့်နေသောဗွီဒီယိုများ] (https) : //www.nytimes.com/2016/08/13/technology/personaltech/how-to-make-youtube-stop-watching-what-you-watch.html) ။ ဤအရာသည်ကျွန်ုပ်တို့အားသူတို့ကိုပစ်မှတ်ထားပြီးကျွန်ုပ်တို့အကောင်းဆုံးသူငယ်ချင်းနှင့်ပြောဆိုသောအရာပေါ် မူတည်၍ ကြော်ငြာအချို့ကိုပြသရန်ကျွန်ုပ်တို့အပေါ်ပရိုဖိုင်းတစ်ခုတည်ဆောက်ပုံဖြစ်သည်။ သို့မှသာ၎င်းတို့သည်ကျွန်ုပ်တို့လိုအပ်သောအရာအတွက်ကြော်ငြာကိုပြနိုင်မည်ဖြစ်သော်လည်းအလွန်ကြောက်စရာကောင်းသည်။ ကျေးဇူးတင်ပါတယ်။ Snowden] (https://en.wikipedia.org/wiki/Edward_Snowden) ဂူဂဲလ်သည် NSA အား ** ဟုခေါ်သည့်ပရိုဂရမ်တစ်ခုအောက်တွင်ကျွန်ုပ်တို့၏ကိုယ်ပိုင်အချက်အလက်များကို NSA နှင့်မျှဝေခဲ့ကြောင်းယခုကျွန်ုပ်တို့သိပြီ ဝီကီ ​​/ PRISM_ (monitoring_program)) "** ။


အနာဂတ်၌တစ်စုံတစ် ဦး သည်ထိုသတင်းအချက်အလက်အားလုံးကိုရယူနိုင်စွမ်းရှိလိမ့်မည်။ ကျွန်ုပ်သည်အမှန်တကယ် [မကောင်းသော] တစ်ခုခု (https://en.wikipedia.org/wiki/Nazi_Germany) ဖြစ်ပျက်တော့မည်ဟုသင့်အားအာမခံသည်။ ဒါကိုမဖြစ်အောင်သင် Degoogling ကိုယခုပင်စတင်သင့်သည်။ သင်၏အချက်အလက်များကို ** [NSA] (https://en.wikipedia.org/wiki/National_Security_Agency) နှင့်မျှဝေသောကုမ္ပဏီမှထုတ်ကုန်များကိုလည်းအသုံးမပြုသင့်ပါ။ ** သငျသညျ deogogling အားဖြင့်ဤအမှုအလုံးစုံတို့ကိုရပ်တန့်သင့်ပါတယ်။

အခြားလူများကလုပ်နိုင်လျှင်သင်လုပ်နိုင်သည်။ **

[ဤနေရာတွင်ဆက်လက်ဖတ်ရှုရန်] (https://github.com/Wuest3nFuchs/Degoogle)

<! - ချိတ်ဆက်ထားသောချိတ်ဆက်လိပ်စာကိုယခုစာရင်းတွင်ဖော်ပြထားသည်မဟုတ်ပါ၊ ကျွန်ုပ်သည်ဤသိုလှောင်ရုံကိုလုံးဝပိုင်ဆိုင်ခြင်းမရှိသောကြောင့်အခြားရင်းမြစ်များကိုမြှင့်တင်လိုသည်။ ကျွန်ုပ်၏ကိုယ်ပိုင် https://github.com/Degoogle-your-life/Degoogle နှင့်ချိတ်ဆက်ခြင်းသည်တစ်ကိုယ်ကောင်းဆန်လိမ့်မည်! ->

***

ဆောင်းပါးများ

### ဆောင်းပါးအခြေအနေ

_ ဆောင်းပါးအားလုံးသည်လက်ရှိတွင်တိုးတက်နေသောအလုပ်တစ်ခုဖြစ်ပြီးအကြီးအကျယ်တိုးတက်ရန်လိုအပ်သည်။ အကြံပြုချက်များနှင့်ပြင်ဆင်မှုများကိုခွင့်ပြုသည်။

_ Aprilပြီ ၁၈ ရက်၊ ၂၀၂၁ ညနေ ၄ း ၀၉ အချိန်၊ ဆောင်းပါးအများစုသည်မစတင်ရသေးပါ။ ငါသူတို့ကိုစတင်နိုင်ရန်အချိန်နှင့်ကြိုးစားအားထုတ်မှုကိုရှာဖွေနေပါတယ်။

Google Chrome ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[ChromeBooks ကိုအသုံးပြုခြင်းကိုရပ်ပါ] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[WideVine DRM အသုံးပြုခြင်းကိုရပ်တန့်ပါ။ / WideVine DRM ကိုဖြတ်တောက်ရန်အချိန်တန်ပြီ] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! -

[သင်သည် ReCaptcha ကိုအသုံးပြုခြင်းကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[ယူကျုမှပြောင်းခြင်း] (http)s ကို: //github.com/seanpm2001/Alternating-from-YouTube) <! - 5 ->

[Googling ကိုရပ်တန့်ပါ၊ အဘယ်ကြောင့် Google Search ကိုအသုံးမပြုသင့်သနည်း] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! >

[Gmail ကိုဘာကြောင့်မသုံးသင့်တာလဲ] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Android ကိုဘာကြောင့်မသုံးသင့်တာလဲ] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[သင်သည် Google Amp ကိုအဘယ်ကြောင့်ရှောင်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

Google Drive ကိုအသုံးပြုခြင်းကိုအဘယ်ကြောင့်ရပ်တန့်ရမည်နည်း (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

(Google Maps နှင့် Google Earth ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! ->

[ဟေ့ဂူးဂဲလ်၊ ရပ်ပါ] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[ဂူဂဲလ် / ဂူးဂဲလ်မှစာအုပ်များမှဖတ်ခြင်းကိုရပ်တန့်ပါ] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[ဂူဂဲလ်စာသင်ခန်းကိုအသုံးပြုခြင်းကိုရပ်ပါ။ "(https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

(Google Translate ကိုဘာကြောင့်မသုံးတော့တာလဲ) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[သင်၏ Google အကောင့်များအသုံးပြုခြင်းကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Accounts) <! - 16! ->

** မကြာမီရေးသားတော့မည့်ဆောင်းပါးအသစ်များ **

(သင် Gerrit ကိုအသုံးပြုခြင်းကိုအဘယ်ကြောင့်ရပ်ဆိုင်းသင့်သနည်း) (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

(Google Analytics ကိုဘာကြောင့်ရပ်တန့်သင့်တာလဲ (ထိုနေရာသည်ကျွန်ုပ်၏ရပ်တည်ချက်ကို ၂၀၂၁၊ ဖေဖော်ဝါရီ ၂၄ ရက်၊ ညနေ ၄ း ၁၃ အချိန်၌ပျက်စီးသွားသည်။ )] -Google-Analytics မှ) <! - 18! ->

<! - အလုပ်ခွဲဝေ! ->

[Google AdSense ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း။ (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[သင်ဘာကြောင့် Google One ကိုအသုံးမပြုသင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! -

(ဘာကြောင့်ဂူဂယ်လ် + ကိုအသုံးမပြုတော့တာလဲ) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

Google Play Store ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! -

Google Docs ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း။ (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[သင်ဘာကြောင့် Google Slides ကိုအသုံးမပြုသင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Google Sheets ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! -

[Google Forms ကိုဘာကြောင့်မသုံးသင့်တာလဲ] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[သင်ဘာကြောင့်ဂူဂဲလ်ကဒ်ပြားအသုံးပြုခြင်းကိုရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Google Messages ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း။ (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

(Google Material Design ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! -

[Google Glass / Glasses ကိုအသုံးပြုခြင်းကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Google Fuchsia ကိုအသုံးပြုခြင်းကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[GBoard ကိုဘာကြောင့်မသုံးသင့်တာလဲ] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Google Home ကိုအသုံးပြုခြင်းကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[သင်ဘာကြောင့် Google Nest ကိုအသုံးမပြုသင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Google Hangouts (အလုပ်မလုပ်ခြင်း) ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! -

[Google Duo ကိုအသုံးပြုခြင်းကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Google Tensorflow ကိုအသုံးပြုခြင်းကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! -

(Google Blockly ကိုဘာကြောင့်မသုံးသင့်တာလဲ) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Google Flutter ကိုအသုံးပြုခြင်းကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

(ဘာကြောင့်သင် Googles Go ပရိုဂရမ်ဘာသာစကားကိုအသုံးပြုခြင်းကိုရပ်တန့်သင့်သနည်း) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

Googles Dart ပရိုဂရမ်ဘာသာစကားကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

(အဘယ်ကြောင့် Googles WebP ၏ပုံသဏ္formatာန်ကိုမသုံးသင့်သနည်း) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! -

(အဘယ်ကြောင့်သင် Googles WebM ဗီဒီယိုအမျိုးအစားကိုအသုံးပြုခြင်းကိုရပ်တန့်သင့်သနည်း) (https://github.co)m / seanpm2001 / အဘယ်ကြောင့်သင် - သင့် - ရပ်သင့်သည် - အသုံးပြုခြင်း - Google-WebM) <! - 43! ->

[Google Video ကိုဘာကြောင့်မသုံးသင့်တာလဲ] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[သင်ဘာကြောင့်ဂူဂဲလ်ဆိုဒ်များကိုအသုံးပြုခြင်းကိုရပ်တန့်သင့်သနည်း (ဂန္တဝင်)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! -

[Google Sites ("New") ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း။ (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! -

[သင်ဘာကြောင့် Google Pay ကိုရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Android Pay ကိုဘာကြောင့်မသုံးသင့်တာလဲ] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Google VPN (oxymoron) ကိုအသုံးပြုခြင်းကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! -

[Google Photos ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! -

[Google Calendar ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[ဘာကြောင့် VirusTotal ကို (၂၀၁၂ စက်တင်ဘာလကတည်းက Google ကပိုင်ဆိုင်ပြီးကတည်းက) ကိုမသုံးသင့်တာလဲ (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! >

[Google Fi ကိုဘာကြောင့်မသုံးတော့တာလဲ] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi) <! - 53! -

[သင်ဘာကြောင့်ဂူဂဲလ် Stadia ကိုဆက်မသုံးသင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! - <

[Google Keep ကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[ဘာကြောင့် Google Base ကိုအသုံးပြုခြင်းကိုရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

(ဘာကြောင့် Google Summer of Code တွင်ပါ ၀ င်ခြင်းကိုရပ်တန့်သင့်သနည်း) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! >

[Google Camera ကိုအသုံးပြုခြင်းကိုအဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

(ဘာကြောင့်ဂူဂဲလ်တွက်ချက်မှုကိုအသုံးမပြုသင့်တာလဲ (အစွန်းရောက်ပုံရသော်လည်းသင်အရာအားလုံးမှဂူဂဲလ်ကိုစွန့်ခွာသင့်သည်၊ သို့ပြောင်းရန်အလွန်လွယ်ကူသည်)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- ဂဏန်းတွက်စက်) <! - 59! ->

(Google Survey + ဆုလာဘ်များကိုသင်အဘယ်ကြောင့်ရပ်တန့်သင့်သနည်း) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! -

(Google Drawings ကိုဘာကြောင့်မသုံးတော့တာလဲ) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

(ဘာကြောင့် Tenor (၂၀၁၁ ခုနှစ်မှစ၍ Google ပိုင်ဆိုင်သည့် GIF ဆိုဒ်) ကိုအသုံးမပြုသင့်သနည်း] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! ->

[FLoC - ဘာဖြစ်လို့ Googles ကြီးမားတဲ့ FLoCing ပြproblemနာကိုရှောင်ရှားသင့်သလဲ (ဂူဂဲလ်ခရုမ်းကိုမသုံးတော့ပါ)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! -

** စုစုပေါင်းဆောင်းပါးများ: ** `63`

** ဆောင်းပါး [လမ်းပြမြေပုံ AB] (DegoogleCampaign_2021Roadmap_Part1.md) (မတ်လ ၁၂ ရက်အထိ) ၂ ရက်ပိတ်ရက် **

** ဆောင်းပါး [လမ်းပြမြေပုံ BB] (DegoogleCampaign_2021Roadmao_Part2.md) (၂၀၂၁ အထိ) ၂ ရက်ပိတ်ရက် **

ဆောင်းပါးအခြေအနေ

ဆောင်းပါးအားလုံးသည်လက်ရှိတွင်တိုးတက်နေသောအလုပ်တစ်ခုဖြစ်ပြီးအကြီးအကျယ်တိုးတက်ရန်လိုအပ်သည်။ အကြံပြုချက်များနှင့်ပြင်ဆင်မှုများကိုခွင့်ပြုထားသည်။

** ချိတ်များ **

ကျွန်ုပ်၏ Degoogle ကွန်ယက်ကိုချဲ့ထွင်ခြင်း၊ လွယ်ကူစွာလွယ်ကူစွာဆက်သွယ်နိုင်ခြင်းနှင့်ရပ်ရွာလူထုမှကြွေးကြော်ခြင်းများပြုလုပ်သည်။

၁။ [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | ထံမှ: [https://github.com/wacko1805/Fossapps](https://github.com/wacko1805/Fossapps) (အင်္ဂလိပ်) မှမှချိတ်ဆက်

၂ [Privacy link များ] (https://github.com/Degoogle-your-life/Privacy-links) | မှချိတ်ဆက်ထားသည်: [https://github.com/Arturro43/privacy-links](https://github.com/Arturro43/privacy-links) (ပိုလန်)

၃။ [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | မှချိတ်ဆက်သည်: [https://github.com/LinuxCafeFederation/Delightful-Privacy](https://github.com/LinuxCafeFederation/Delightful-Privacy) (အင်္ဂလိပ်)

၄ [Blocklists] (https://github.com/Degoogle-your-life/blocklists) | ထံမှ: [https://github.com/jmdugan/blocklists](https://github.com/jmdugan/blocklists) (အင်္ဂလိပ်) မှချိတ်ဆက်

၅ [Wuest3nFuchs မှ Degoogle] (https://github.com/Degoogle-your-life/Degoogle) | မှ: [https://github.com/Wuest3nFuchs/Degoogle](https://github.com/Wuest3nFuchs/Degoogle) (အင်္ဂလိပ်) မှမှချိတ်ဆက်

ဆက်နွယ်နေသည် **

[Degoogled Android Phone Virtual Machine research] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

** ကြည့်ရှုပါ - **

[ဝီကီပီးဒီးယားမှဂူးဂဲလ်ကိုဝေဖန်မှု] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[ဂူဂဲလ်သင်္ချိုင်းဂူ (killbygoogle.com) - ဂူဂဲလ်မှသတ်ဖြတ်ခဲ့သောထုတ်ကုန် ၂၂၄ ခု၏အမျိုးအစားစာရင်း] (https://killedbygoogle.com/)

> [GitHub link] (https://github.com/codyogden/killedbygoogle)

[အက္ခရာအလုပ်သမားသမဂ္ဂ - ဂူးဂဲလ်တွင်ဝန်ထမ်း ၈၀၀ ကျော်ပါ ၀ င်သောအလုပ်သမားသမဂ္ဂအသစ်] (https://alphabetworkersunion.org/people/our-union/)

[ဒိုင်နိုဆောမျိုးစေ့ကြက်ဥနှင့်မခွဲချင်ဘူးလား? ဒီဝက်ဘ်ဆိုက်ကိုသင်ဖုံးလွှမ်းထားသည်] (https://chromedino.com/)

***

## သီးသန့်တည်ရှိမှု

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (monitoring_program)) [o] (https://www.reddit.com/r/degoogle/) [g] (https: //www.wired) .com / 2012/06 / opinion-google-is-evil /) [l] (https://securitygladiators.com/chrome-privacy-bad/) [င] (https://www.zdnet.com/article) / Goodbye-google-why-and-how-to-take-back-your-privacy /) [ဇ] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data- facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2/21/21146998/google-new-mexico-children-privacy-school-chromebook- တရားစွဲဆိုမှု) [s] (https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox-1) [a] (https://money.cnn.com/2017/ 10/11 / technology / google-home-mini-security- အားနည်းချက် / index.html) [v] (https://www.huffpost.com/entry/why-googles-spying-on-use_b_3530296) [င] ( https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81) [r](https://www.theguardian.com/technology/2019/) နိုဝင်ဘာ / ၀၅ / fitbit-google-acquisition-data အချက်အလက် [y] (https://www.computerworld.com/article/312) 8791 / how-google-homes-အမြဲ -on-will-affect-privacy.html [v] (https://protonmail.com/blog/google-privacy-problem/) [င] (https: // www) .forbes.com / sites / gordonkelly / 2020/02/23 / google-chrome-80-upgrade-deep-linking-update-chrome-browser/) [r] (https://www.wired.co.uk/) ဆောင်းပါး / duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism) [b] (https://spreadprivacy.com/three-reasons-why- the-nothing-to-hide-argument-is- ချို့ယွင်းချက် /) [a] (https://eduzaurus.com/free-essay-samples/nothing-to-hide-argument-has-nothing-to-say/) []] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of-data-about-you-you-can-find-and-delete-it-now/ ) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your-personal-data-n870501) [င] (https://www.eff.org /deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes-and)[c](https://www.wired.com/story/google -tracks-you-privacy /) [o] (https://www.theguardian.com/commentisfree) /2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r](https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision -TOTAL- ဒေတာစုဆောင်းမှု - discl.html) []] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https: //www.wired) .com / story / health-fitness-data-privacy /) [ဇ] (https://www.pcmag.com/news/google-sued-over-kids-data-collection-on-education-chromebooks) [င။ ] (https://mashable.com/article/google-android-data-collection-study/) [n] (https://www.engadget.com/australian-government-google-data-collection-lawsuit-182043643 .html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/) ဘယ်တော့မှ googlers ၀ က်ဘ်အသုံးပြုသူများကိုယူပါ - အဆုံးစွန်အဆင့် - စောင့်ကြည့်သူတို့၏အချက်အလက် /) [c] (https://www.cnn.com/2019/11/12/business/google-project-nightingale-ascension /index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https://moz.com/blog/where-does-google-draw-the-data-collection -line) [င] ( https://mashable.com/article/google-android-data-collection-study/) [s](https://eandt.theiet.org/content/articles/2020/06/google-sued-over-data\t -collection-from-users-in-incognito-mode /) [t] (https://www.nytimes.com/2019/01/21/technology/google-europe-gdpr-fine.html) [o] ( https://www.bloomberg.com/news/articles/2017-11-11/google-sued-over-data-claims-on-behalf-of-5-million-iphone-users) [u] (https: //time.com/23782/google-flu-trends-big-data-problems/) [s](https://www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https : //www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https: //www.computerworld) com / article / 2914838 / project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google- - လူတန်းစား - အရေးယူခြင်း - တရားစွဲဆိုမှု - တရားလို - သဘောတူ - သို့ - ဒေတာ - စုဆောင်းခြင်း /) [r] (https://arstechnica.com/information-technology/2014/01/what-google-can-really-do-with -nest-or-reall y-nests-data /) [i] (https://www.cbsnews.com/news/google-education-spies-on-collects-data-on-millions-of-kids-alleges-lawsuit-new-mexico - ရှေ့နေချုပ် /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal-under-our-noses/) [a] (https: // www) .wired.com / insights / 2012/10 / google-opt-out /) [c] (https://www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [။ ] (https://medium.com/digitalprivacywise) / why-you-should-stop-use-google-chrome-6c934c9a827c) (ကျွန်ုပ်သည်ဤအထောက်အထားများနှင့်အတူဆက်လုပ်နိုင်သည်၊ သို့သော်ဤဆောင်းပါးများအားလုံးကိုရှာဖွေပြီးရှာဖွေရန်အချိန်များစွာကြာခဲ့ပါသည်)

Google ထုတ်ကုန်များပေါ်ရှိ privacy သည်အမြဲတမ်းမကောင်းပါ၊ အကြောင်းမှာ spyware ပါ ၀ င်သည့် Google ထုတ်ကုန်အားလုံးကြောင့်ဖြစ်သည်။

သင်ဘာလုပ်သည်ဖြစ်စေဂူးဂဲလ်ကိုအသုံးပြုနေစဉ်သင်၏အရေးကြီးသောကိုယ်ရေးကိုယ်တာအချက်အလက်အားလုံးကိုဂူးဂဲလ်နှင့်အခြားသူများထံသို့ပို့သည် ဂူးဂဲလ်ဟာပွင့်လင်းတဲ့ပရိုဂရမ်တွေကိုဖြတ်ပြီးသွားတာကိုလည်းတွေ့ခဲ့ရတယ်။ ဥပမာအားဖြင့် - ကိုယ်ပိုင်အတွေ့အကြုံမှ (on Firefox တွင် YouTube မဖွင့်သောဖွင့်ထားသည့်ဗွီဒီယိုအမြောက်အများ (VLC Media Player) ကိုကျွန်ုပ်ကြည့်ရှုခဲ့သည်။ အကြံပြုချက်များကိုစစ်ဆေးရန်သွားသောအခါကျွန်ုပ်ကြည့်ရှုခဲ့သမျှအားလုံးနီးပါးဖြစ်ခဲ့သည်။ အခြားပရိုဂရမ်များကိုသူလျှိုလုပ်နေသည်မှာသေချာသည်။

Chrome (နှင့်အခြား browser များ) တွင် incognito mode ရှိသည်။ Chrome မှာတော့ဒီဟာဟာအဓိပ္ပာယ်မရှိဘူး။ သင်အချက်အလက်ရှာဖွေခြင်း / ခြေရာခံခြင်းကိုပိတ်ပြီး "မခြေရာခံရန်" အချက်ပြမှုကိုဖွင့်ထားလျှင်ပင်အံ့အားသင့်စရာကောင်းသည်၊ ဂူဂဲလ်သည်သင့်အချက်အလက်များကိုတူးဖော်နေဆဲဖြစ်သည်။

မင်းမှာဖုံးကွယ်စရာဘာမှမရှိဘူးလို့မင်းထင်ရင်မင်းကမှားတယ်မှားတယ်။ ဒီအငြင်းအခုံအကြိမ်ပေါင်းများစွာ debunked ခဲ့တာ:

[ဝီကီပီးဒီးယားမှတစ်ဆင့်] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

(၁) အက်ဒွပ်စနိုးဒန်က“ ကိုယ်ရေးကိုယ်တာအခွင့်အရေးကိုသင်ဂရုမစိုက်ဘူးလို့ငြင်းခုံပြောဆိုခဲ့တာကမင်းမှာလွတ်လပ်စွာပြောဆိုခွင့်ကိုဂရုမစိုက်ဘူးလို့ပြောတာနဲ့မတူပါဘူး၊ ဘာလို့လဲဆိုတော့မင်းမှာဘာမှပြောစရာမလိုတော့ဘူး” ဟုပြောခဲ့သည်။ ငါဖုံးကွယ်စရာဘာမှမရှိဘူး၊ မင်းက 'ငါဒီအခွင့်အရေးကိုဂရုမစိုက်ဘူး' လို့မင်းပြောနေတာပဲ။ လူ့အခွင့်အရေးရဲ့လုပ်ဆောင်ပုံနည်းလမ်းကအစိုးရကမင်းရဲ့အခွင့်အရေးတွေအပေါ်ကျူးကျော် ၀ င်ရောက်မှုကိုတရားမျှတစေရမည်။

၂။ ဒံယေလဂျေ Solove သည်အဆင့်မြင့်ပညာရေးရာဇ ၀ င်ဆိုင်ရာဆောင်းပါးတွင်သူအငြင်းပွားမှုကိုဆန့်ကျင်ကြောင်းဖော်ပြခဲ့သည်။ သူကအစိုးရသည်လူတစ် ဦး နှင့်ပတ်သက်သောသတင်းအချက်အလက်များကိုပေါက်ကြားစေပြီးထိုလူကိုပျက်စီးစေနိုင်သည်သို့မဟုတ်လူတစ် ဦး သည်အမှားများကိုအမှန်တကယ်မပါ ၀ င်သော်လည်း ၀ န်ဆောင်မှုများကို ၀ င်ရောက်ခွင့်ကိုငြင်းပယ်ရန်လူတစ် ဦး အကြောင်းအချက်အလက်များကိုသုံးနိုင်သည်၊ အမှားတွေလုပ်မှတဆင့်ဘဝ။ Solove မှရေးသားခဲ့သည်မှာ "တိုက်ရိုက်ထိတွေ့ဆက်ဆံတဲ့အခါ၊ ဘာမျှမဖုံးကွယ်နိုင်သောအငြင်းအခုံသည်ကျော့မိသွားနိုင်သည်။ ဘာကြောင့်လဲဆိုတော့၎င်းသည်အငြင်းပွားမှုများအားသီးသန့်တည်ရှိမှုကိုနားလည်ရန်အာရုံစူးစိုက်စေသည်။ သို့သော်အစိုးရအချက်အလက်များကိုစုဆောင်းခြင်းနှင့်စောင့်ကြည့်ခြင်းထက် ကျော်လွန်၍ အသုံးပြုခြင်းတို့ကြောင့်ဖြစ်ပေါ်လာသော privacy ပြproblemsနာများနှင့်ရင်ဆိုင်ရသောအခါ ထုတ်ဖော်ပြသခြင်း၊ ဖုံးကွယ်ထားခြင်းမရှိသောအငြင်းအခုံအဆုံးတွင်ပြောစရာမရှိချေ။

(၃) ကိုယ်ရေးကိုယ်တာအခွင့်အရေးအခွင့်အရေးရေးသားသူ Adam D. Moore က `` အခွင့်အရေးဟာကုန်ကျစရိတ်၊ အကျိုးအမြတ် (သို့) အကျိုးဆက်အငြင်းပွားမှုကိုခုခံနိုင်စွမ်းရှိသည် sort လို့ငြင်းခုန်ခဲ့သည်။ လုံခြုံရေးအတွက်ရောင်းဝယ်ဖောက်ကားနိုင်တယ်။ " စောင့်ကြည့်လေ့လာခြင်းသည်အသွင်အပြင်၊ လူမျိုးစု၊ လိင်နှင့်ဘာသာရေးအပေါ် အခြေခံ၍ လူ့အဖွဲ့အစည်းရှိအချို့သောအုပ်စုများကိုအချိုးအစားမမျှတစွာအကျိုးသက်ရောက်နိုင်သည်ဟုသူကပြောကြားခဲ့သည်။

၄။ ကွန်ပျူတာလုံခြုံရေးကျွမ်းကျင်သူနှင့်စာစီစာရိုက်သူ Bruce Schneier က Cardinal Richelieu ၏ပြောဆိုချက်ကို ကိုးကား၍ ဆန့်ကျင်ကြောင်းထုတ်ဖော်ပြောကြားခဲ့သည် -“ အကယ်၍ တစ်ယောက်ကကျွန်တော့်ကိုရိုးသားဖြောင့်မတ်သူလက်ဖြင့်ရေးထားတဲ့စာကြောင်းခြောက်ခုပေးရင်သူ့ကိုငါဆွဲထားဖို့တစ်ခုခုရှိလိမ့်မယ်။ ပြည်နယ်အစိုးရအနေဖြင့်ထိုပုဂ္ဂိုလ်အားတရားစွဲဆိုခြင်းသို့မဟုတ်အယောင်ဆောင်ခြင်းအားဖြင့်လူတစ် ဦး ၏ဘ ၀ တွင်ရှုထောင့်များကိုမည်သို့ရှာတွေ့နိုင်သည်ဆိုသည့်အချက်ဖြစ်သည်။ Schneier ကငြင်းခုံမှုသည်များသောအားဖြင့်ငြင်းခုံမှုအားမှားယွင်းစွာဖော်ပြခြင်းမှာ 'လုံခြုံရေးနှင့် privacy ကို' ဟူ၍ ဖြစ်သည်။ စစ်မှန်သောရွေးချယ်မှုသည်လွတ်လပ်မှုကိုထိန်းချုပ်ခြင်းနှင့်နှိုင်းယှဉ်ခြင်းဖြစ်သည်။ "

5. Harvey A. Silverglate မှခန့်မှန်းတွက်ချက်မှုအရသာမန်လူတစ်ယောက်သည်အမေရိကန်နိုင်ငံတွင်တစ်နေ့လျှင်လူသုံး ဦး အားတစ်နေ့လျှင် ၃ ကြိမ်ကျူးလွန်ခြင်းများကိုမသိဘဲကျူးလွန်နေသည်ဟုခန့်မှန်းခဲ့သည်။

(၆) အတွေးအခေါ်ပညာရှင်နှင့်စိတ်ပညာရှင် Emilio Mordini က "ဖုံးကွယ်ဖို့ဘာမှမရှိ" ဟူသောအငြင်းအခုံသည်မူလကပင်ဝိရောဓိဖြစ်နေသည်ဟုပြောကြားခဲ့သည်။ လူများသည် "တစ်ခုခု" ဖုံးကွယ်ရန် "ဖုံးကွယ်ရန်" တစ်ခုခုမလိုအပ်ပါ။ အဘယ်အရာကိုဝှက်ထားသောသေချာပေါက်သက်ဆိုင်သည်မဟုတ်, မော်ဒနီကဆိုပါတယ်။ ၎င်းအစားသူသည်လျှို့ဝှက်accessရိယာနှင့် ၀ င်ရောက်ခွင့်ကိုကန့်သတ်ထားသည့်နှစ် ဦး နှစ်ဖက်လိုအပ်သည်ဟုငြင်းခုံသည်။ စိတ်ပိုင်းဆိုင်ရာအရပြောရလျှင်ကျွန်ုပ်တို့သည်အခြားသူများကိုတစ်ခုခုသိုဝှက်နိုင်သည့်ရှာဖွေတွေ့ရှိမှုကြောင့်တစ် ဦး ချင်းဖြစ်လာသည်။

ဂျူလီယန်အက်ဆန်းက "လူသတ်သမားအဖြေမရှိသေးပါ။ Jacob Appelbaum (@ioerror)" သည်လိမ္မာပါးနပ်စွာတုံ့ပြန်မှုရှိသည်။ ထို့နောက်သူက၎င်းအားသူတို့၏ဖုန်းကိုသော့ဖွင့်ပေးပြီးဘောင်းဘီကိုဆွဲချရန်ပြောခဲ့သည်။ ကျွန်ုပ်၏ဗားရှင်းမှာပြောရန်ဖြစ်သည်။ “ ကောင်းပြီ၊ မင်းကပျင်းဖို့ကောင်းတယ်ဆိုရင်ငါတို့နဲ့မင်းဘယ်သူ့ကိုမှစကားမပြောသင့်ဘူး” ဒါပေမယ့်အတွေးအခေါ်ပညာအရတကယ့်အဖြေကတော့အစုလိုက်အပြုံလိုက်စောင့်ကြည့်ခြင်းဟာကြီးမားတဲ့ဖွဲ့စည်းတည်ဆောက်ပုံဆိုင်ရာအပြောင်းအလဲဖြစ်တယ်။ သငျသညျမွကွေီးပျေါမှာအရူးအမူးလူတ ဦး ဖွစျသျောလညျးသငျနှငျ့အတူယူရနျ

၈။ ဥပဒေပါမောက္ခ Ignacio Cofone ကအငြင်းပွားမှုသည်သူကိုယ်တိုင်အသုံးအနှုန်းများဖြင့်မှားယွင်းနေသည်ဟုငြင်းဆိုသည်။ ဤဆီလျှော်သောသတင်းအချက်အလက်များသည်သီးသန့်တည်ရှိမှုကုန်ကျစရိတ်များရှိပြီးခွဲခြားဆက်ဆံခြင်းကဲ့သို့သောအခြားထိခိုက်မှုများကိုဖြစ်စေနိုင်သည်။

***

## အခြား Google ဆန့်ကျင်ရေးလှုပ်ရှားမှုများ

ဤသည်မှာအခြားထင်ရှားသောဂူဂဲလ်ဆန့်ကျင်ရေးလှုပ်ရှားမှုများစာရင်းဖြစ်သည်။ ဒီစာရင်းကမပြည့်စုံဘူး သင်ကတိုးချဲ့ခြင်းဖြင့်ကူညီနိုင်သည်။

### အသုံးမဝင်တော့ဘူး

[Scroogled - Microsoft မှ (၂၀၁၂ မှ ၂၀၁၄ နိုဝင်ဘာလအထိ)] (https://en.wikipedia.org/wiki/Scroogled)

_ ယခုအချိန်တွင်အခြားအရာများမရှိပါ။

### ဆက်လက်ဖြစ်ပွားနေသော

_ ယခုစာရင်းသည်အလွတ်ဖြစ်သည်။

***

## အခြားအငြင်းပွားမှုများတန်ပြန်

ဂူဂဲလ်ကိုတရားမျှတစေရန်လူအများပြောသောအငြင်းပွားမှုများရှိသည်။ ပထမ ဦး ဆုံးအဓိကတစ်ခုမှာ [ဤနေရာတွင်] (# သီးသန့်တည်ရှိပြီး) debunked လုပ်ပြီးသော်လည်းအခြားအချို့မှာ -

### အဆင်ပြေ

ဟုတ်ပါတယ်၊ Google ထုတ်ကုန်တွေကအဆင်ပြေပါတယ်။ သို့သော်သင်အပါအဝင်အဆင်ပြေစေရန်အတွက်အရာရာကိုကုန်သွယ်နေသည်လုံခြုံရေး, privacy နဲ့ယုံကြည်စိတ်ချရ။ Google သည်နှစ်များတစ်လျှောက်ပိုမိုပျင်းရိလာပြီးသူတို့၏ဆာဗာများသည်ပိုမိုများပြားလာသည်။ ယခုအချိန်တွင်ဂူဂဲလ်ဆာဗာများသည်တစ်လလျှင် ၁-၂ ကြိမ်အကြိမ် (အထူးသဖြင့် YouTube) ကျဆင်းသွားသည်။

ကံမကောင်းစွာဖြင့်လူမှုအသိုင်းအဝိုင်းများသည်ဂူးဂဲလ်ကိုအားကိုးသောကြောင့်ဂူဂဲလ်သည်အင်တာနက်ကိုလွှမ်းမိုးလာသည်နှင့် ပို၍ ထိန်းချုပ်ရန်ကြိုးစားသည်။ ၂၀၁၂ ခုနှစ်တွင်ဂူးဂဲလ်သည် ၅ မိနစ်ကြာကျဆင်းသွားသည့်အခါ ** ကမ္ဘာလုံးဆိုင်ရာ ** အင်တာနက်အသွားအလာ ** ၄၀% သို့ကျဆင်းသွားသည်။ ဂူဂဲလ်သည်မကြာခဏ ၁-၂ နာရီအကြာတွင်ကျဆင်းသွားပြီး [ကျင့် ၀ တ်အဖွဲ့အားပစ်ခတ်ခြင်း] ဖြင့် (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) အခြားအရာများအကြား၎င်းတို့သည်အဆင်ပြေချောမွေ့စွာဖြစ်လာလိမ့်မည်။

အဆင်ပြေမှုအမြဲတမ်းကောင်းသောအရာမဟုတ်ပါ။ သင်ဘာတွေဖြစ်နေတယ်ဆိုတာသတိထားသင့်ပြီးသူတို့ပြိုလဲချိန်တွင်ကြိုတင်ပြင်ဆင်ထားသင့်ပါတယ်။ ဘာကြောင့်လဲဆိုတော့ဆာဗာတစ်ခုအားခဏခဏပြnotနာမရှိသောကြောင့်ဖြစ်သည်။

Google ကသင်ထင်သလောက်မလွယ်ကူပါဘူး။ ပိုပြီးအဆင်ပြေသောအခြားဆိုဒ်များရှိပါသည်။ ဂူဂဲလ်သည်အဆင်မပြေပါကသူတို့၏ကျပန်းအကောင့်ဆိုင်းငံ့ခြင်းနှင့်ရပ်စဲခြင်းများကိုအကောင့်ပြုလုပ်သည့်အခါ (အကယ်၍ သင်ဂူးဂဲလ် twitter အကောင့်ကိုလုံလောက်စွာအာရုံမထားပါကသို့မဟုတ်ဒေါ်လာ ၁၀၀,၀၀၀,၀၀၀ သို့မဟုတ်ထိုထက်ပိုသောတရားစွဲဆိုခြင်း မှလွဲ၍) အကုန်လုံးကသင့်ကိုအားသာချက်ယူပြီး၊ သင့်ရဲ့အော်ဟစ်သံကိုဘယ်သူမှမကြားနိုင်တဲ့ခေါင်းအုံးတစ်ချပ်ထဲခုန်ချခိုင်းတယ်။

### ဘာဖြစ်လို့လဲဆိုတော့သိပ်နောက်ကျလွန်းတယ်ဘာကြောင့်အရေးကြီးလဲ

၎င်းသည်အများအားဖြင့်အငြင်းပွားမှုဖြစ်သော်လည်းရှင်းပြရန်လိုအပ်သည်။ လက်ရှိပြည်နယ်နှင့်အတူကမ္ဘာ့အစိုးရအများစုသည်အင်အားကြီးသောကော်ပိုရေးရှင်းများနှင့်အတူသင်၏လှုပ်ရှားမှုတိုင်းကိုသိကြပုံရသည်။ အဖြေကရိုးရှင်းပါသည်။ အကယ်၍ သင်သည်ဤအချက်မှသူတို့ကိုရှောင်ရှားရန်စီမံခဲ့ပါကသင်၏ရွေ့လျားမှုကိုထပ်မံခြေရာခံရန်သူတို့အတွက်ပိုမိုခက်ခဲသည်။ ထို့အပြင် ပိုမို၍ ကိုယ်ပိုင်ဘဝသစ်ကိုသင်တည်ဆောက်နိုင်သည်။

[၁ ရင်းမြစ်] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) စကားမစပ်ဒီပို့စ်ကိုကျွန်တော်တစ်ပတ်ကျော်ကျော်ရတိုင်းအခမဲ့ပေးနေခြင်း ယခု (ကျွန်ုပ်၏အခမဲ့ဒင်္ဂါးပြား ၅၀၀ လုံးနှင့်အတူ) ယခုအကြောင်းအရာကိုထပ်မံမြှင့်တင်ရန်ဖြစ်သည်။ ယခုအထိကျွန်ုပ်သည်ဤဆုကိုအခမဲ့ဆု (၁၄) ခုကျော်ကိုပေးခဲ့ပြီးဖြစ်သည်။ ၎င်းသည်သိပ်မများလှပါ၊ သို့သော်သေးငယ်သောအရာများသည်၎င်းကိုမည်သို့ခံယူသည်၊ မည်သူ့အပေါ် မူတည်၍ ကြီးမားသောသက်ရောက်မှုကိုဖြစ်စေနိုင်သည်။

### အခြား

ငါမှာအခြားအငြင်းပွားမှုများမရှိပါ။

_ ဒီစာရင်းမပြည့်စုံပါ

***

## ရင်းမြစ်

မိတ္တူ -

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (monitoring_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [င] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [ဇ] (https: // www) .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2) /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) [s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox] -1) [က] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (http: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [င] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he al-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail) com / blog / google-privacy-problem /) [င] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# ဝေဖန်မှု [ခ] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay - နမူနာများ / ဘာမှဖုံးကွယ်ရန် - အငြင်းအခုံ - မရှိ - ဘာမှပြောရန် /) []] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-about-you-you-can-find-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your) -personal-data-n870501) [င] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -and) [c] (https://www.wired.com/story/google-tracks-you) -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google) -sued-over-kids-data-collection-on-education-chromebooks) [င] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //) www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23) / ဘယ်တော့မှ googlers- ဝက်ဘ်အသုံးပြုသူများ - အဆုံးစွန် - အဆင့် - စောင့် - သူတို့ဒေတာ /) [c] (https://www.cnn.com/2019/11/12/business/google-project-nightingale- ascension / index.html) [o] (https://en.wikipedia.org/wiki/2018_Google_data_breach) [m] (https://moz.com/blog/where-does-google-draw-the-data- စုဆောင်းခြင်းလိုင်း) [င] (https://mashable.com/article/google-android-data-collection-study/) [s] (https://eandt.theiet.org/content/articles/2020/06 / google-sued-over-data-collection-from-users-in-incognito-mode /) [t] (https://www.nytimes.com/2019/01/21/technology/google-europe-gdpr- fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-11/google-sued-over-data-claims-on-behalf-of-5-million-iphone- အသုံးပြုသူများ) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy-googleyoutube-kidsdata -idUSL1N2J306W) [င] (https://www.adweek.com/performan) ce-marketing / google-is-collecting-your-data-even-your-phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi -will-help-google-amass-even-more-data-about-you.html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs -consented-to-data-collection - / [r] (https://arstechnica.com/information-technology/2014/01/what-google-can-really-do-with-nest-or-really-nests- ဒေတာ /) [i] (https://www.cbsnews.com/news/google-education-spies-on-collects-data-on-millions-of-kids-alleges-lawsuit-new-mexico-attorney-general /)[v](https://www.nationalreview.com/2018/04/the-student-data-mining-scandal-under-our-noses/)[a](https://www.wired.com / insights / 2012/10 / google-opt-out /) [c] (https://www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) [y] ( https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.](https://medium.com/digitalprivacywise/why-you -should-stop-use-google-chrome-6c934c9 a827c)

အခြားရင်းမြစ်များ

[မျက်လုံးငါးခုမဟာမိတ်အဖွဲ့] (https://en.wikipedia.org/wiki/Five_Eyes) [ဆယ့်ကိုးဆယ့်လေးပါး] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## လင့်များကိုဒေါင်းလုပ်လုပ်ပါ

[Firefox ကိုရယူပါ] (https://www.mozilla.org/en-US/firefox/new/) [Tor browser ကိုရယူပါ] (https://www.torproject.org/download/) [အခြား / မရရှိနိုင်] (https://www.torproject.org/download/) : //www.example.com)

***

## ငါ၏အ degoogling အတွေ့အကြုံ

နောက်ဆုံးမှာတော့နည်းပညာကြီးတွေနဲ့ပြproblemsနာတွေကို ၂၀၁၈ ခုနှစ်မှာစတင်တွေ့မြင်ခဲ့ရတယ်။ ပထမလအနည်းငယ်မှာကျွန်တော်သိသာထင်ရှားတဲ့တိုးတက်မှုတွေရခဲ့တယ်။ ထိုအချိန်မှစ၍ ၎င်းသည်အလွန်နှေးကွေးခဲ့သည်။


### ငါဘယ်ကနေပြောင်းလဲ

Google Chrome -> Firefox / Tor

Google Search -> DuckDuckGo (ပုံမှန်) / Ecosia (ကျွန်ုပ်နှစ်သက်သောအချိန်) / Bing (မရှိသလောက်)

GMail - ProtonMail (အပြည့်အ ၀ မပြောင်းရသေးပါ)

ဂူဂဲလ်ဆိုဒ်များ -> ကိုယ်ပိုင် hosting (အပြည့်အဝပြောင်းလဲမရသေး)

Google+ -> ဘယ်တော့မှအသုံးမ ၀ င်ဘူး၊ သူ့ကိုယ်ပိုင်ပိတ်ခြင်းကြောင့်သူ့ဟာသူဖျက်လိုက်တယ်

Google Docs -> ဘယ်တော့မှမသုံးခဲ့ဘူး၊ ငါအစား Microsoft Word 2013 (2019 မတိုင်မီ) နှင့် LibreOffice (2019-onward) အစား။

Google Sheets -> ဘယ်တော့မှမသုံးခဲ့ဘူး၊ ငါအစား Microsoft Excel 2013 (2019 မတိုင်မီ) နှင့် LibreOffice (2019-onward) အစားသာအသုံးပြုခဲ့သည်။

Google Slides -> ဘယ်တော့မှမသုံးခဲ့ဘူး၊ ငါအစား Microsoft PowerPoint 2013 (2019 မတိုင်မီ) နှင့် LibreOffice (2019-onward) အစား။

Google Drawings -> ဘယ်တော့မှမသုံးခဲ့ဘူး။ အစား LibreOffice (2019-onward) ကိုသုံးခဲ့တယ်။

Gerrit -> ဘယ်တော့မှအသုံးမပြုပါ။ ကျွန်ုပ်အစား GitHub (လက်ရှိ default), GitLab, BitBucket နှင့် SourceForge တို့ကိုသာအသုံးပြုပါ။

Google Photos -> ဘယ်တော့မှမသုံးဘူး

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020- လက်ရှိ)

Google Maps -> OpenStreetMaps / Apple Maps

သွားပါ - အထူးခြွင်းချက်တစ်ခုပြုလုပ်ခြင်း၊ သို့သော်အလုပ်လုပ်သောပရိုဂရမ်းမင်းဘာသာစကားအဖြစ်အသုံးမပြုပါ

Dart - အထူးခြွင်းချက်တစ်ခုပြုလုပ်ခြင်း၊

Flutter - အထူးခြွင်းချက်တစ်ခုပြုလုပ်ခြင်း၊

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> တစ်ခါမှမသုံးဖူးဘူး၊

Google Fi -> ဘယ်တော့မှအသုံးမပြုပါ

ဂူဂဲလ်ပြက္ခဒိန် -> ဘယ်တော့မှအသုံးမပြုပါ

Google calculator -> Python mode မှာအလုပ်လုပ်တဲ့ Linux terminal တောင်မှစာသားအတိုင်းအခြား calculator app တစ်ခုပါ

Google Nest -> ဘယ်တော့မှမသုံးဘူး

Google AMP -> ဘယ်တော့မှမသုံးဖူးဘူး

Google VPN - ဘယ်တော့မှမသုံးဖူးဘူး၊ oxymoron လည်း

Google Pay - ဘယ်တော့မှမသုံးဘူး

Google Summer of Code -> ဘယ်တော့မှမပါဝင်ခဲ့ဘူး

Tenor -> အခြား GIF ဆိုဒ်များ၊ GIFs သည်ကျွန်ုပ်အတွက်သိပ်အရေးမကြီးပါ။ ပုံမှန်အားဖြင့်ငါ DuckDuckGo ပုံများ၊ Imgur, Reddit သို့မဟုတ်အခြား site များမှ GIF ဖိုင်များကိုရယူသည်။

ပိတ်ဆို့ခြင်း -> အသုံးပြုခြင်းမရှိတော့ပါ၊ Scratch သည်တိုက်ရိုက်ပိတ်ပင်ခြင်းရှိမရှိမသေချာပါ။ ငါနောက်ပိုင်းတွင် 2017 ခုနှစ်တွင်အလုပ်လုပ်တဲ့ပရိုဂရမ်မာဖြစ်လာခဲ့သည်နှင့်ခြစ်ရာထဲကကြီးပြင်းလာတယ်။

GBoard -> တစ်ချိန်ကအသုံးပြုခဲ့ပေမယ့်စွန့်ပစ်ခဲ့သည်

Google Glass -> ဘယ်တော့မှမသုံးဖူးဘူး၊ ငယ်ငယ်ကတည်းကထည့်သွင်းစဉ်းစားခဲ့ပေမဲ့ငါ့မှာရွေးစရာရှိရင်တစ်ယောက်ကိုမသုံးဖို့ဆုံးဖြတ်ခဲ့တယ်

_List မပြည့်စုံပါ

### ထုတ်ကုန်များကျွန်ုပ်ဝေးကွာနေသောကြောင့်

၂၀၂၁ ခုနှစ်၊ ဖေဖော်ဝါရီ ၂၅ ရက်တွင်ကျွန်ုပ်သည်ကျွန်ုပ်အားအပြည့်အဝအမှားမကင်းစေရန်ဂူဂဲလ်ထုတ်ကုန်များဖြစ်သည်။

၁။ YouTube

၂

၃။ Google Play စတိုး

၄။ GMail (ကျောင်းနှင့်အချို့ဆိုဒ်များအတွက်သာ)

၅။ Google Classroom (ကျောင်းအတွက်သာ)

၆။ Google Translate

၇ ။ ဂူဂဲလ်အကောင့်

၈။ Google Sites (ဂူဂဲလ်သည် GDPR ၏ဥပဒေများကိုချိုးဖောက်နေသောကြောင့် (၎င်းကိုသတ်မှတ်ပြီးသည်အထိနောက်ထပ်ယူရို ၅,၀၀၀,၀၀၀.00 ဒဏ်ငွေနှင့်ရင်ဆိုင်ရနိုင်ပြီး) နှင့်ဤထုတ်ကုန်အားဒေါင်းလုပ်ဆွဲခြင်းကိုတားမြစ်ထားသည်။

ငါကတခြားအရာအားလုံးကနေလမ်းလွဲသွားပြီ

***

## သွားကမကောင်းဘူး

ဂူဂဲလ်သည် ၂၀၀၃ ခုနှစ်၊ ၆ နှစ်အကြာ ၂၀၀၉ ခုနှစ် Agent Based Programming Language Go ကိုသူတို့၏ပရိုဂရမ်းမင်းဘာသာစကား Go (၂၀၀၉ ခုနှစ်မှ ၆ နှစ်အကြာ) တွင်ပျံသန်းခဲ့ပြီးသူတို့၏ဘာသာစကားသည်အခြားဘာသာစကားကိုလုံး ၀ သက်ရောက်မှုမရှိဟုပြောဆိုခဲ့သည်။ ဂူဂဲလ်ကို၎င်းအတွက် `` မကောင်းမှုမပြုကြနှင့် '' ဟူသောဆောင်ပုဒ်သည်ထိုအချိန်ကတက်တက်ကြွကြွရှိနေခြင်းကြောင့်ဤကိစ္စအတွက်အကြီးအကျယ်ဝေဖန်ခံခဲ့ရသည်။ ၎င်းသည်မော့တ်အငြိမ်းစားယူရသည့်အဖြစ်အပျက်များစွာထဲမှတစ်ခုဖြစ်သည်။

နောက်ဆုံးတွင် `Go! '၏ဖွံ့ဖြိုးတိုးတက်မှုမှာရပ်တန့်သွားပြီး၊ ` Go` သည် ပို၍ အဖြစ်များလာသည်။ ဂူးဂဲလ်က၎င်းတို့သည် `Go!” ကိုကျော်ဖြတ်သွားမည်မဟုတ်ဟုပြောသော်လည်းနောက်ဆုံးတွင်သူတို့ (၂၀၂၁ ခုနှစ်Aprilပြီလ ၉ ရက်မှစ၍) ကိုကျော်ဖြတ်နိုင်ခဲ့သည်။

[Go နှင့်ဤနေရာတွင်မည်သို့ပြောင်းရွှေ့ပုံအကြောင်းကိုပိုမိုဖတ်ပါ] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

DRM ၏ ## အသုံးပြုမှု

ဂူဂဲလ်သည် WideVine DRM "၀ န်ဆောင်မှု" နှင့်အခြားပုံစံများမှတဆင့် DRM (ဒီဂျစ်တယ်ကန့်သတ်ချက်စီမံခန့်ခွဲမှု) ကိုအသုံးပြုသည်။ DRM ၏ရည်မှန်းချက်မှာပွင့်လင်းသောအင်တာနက်အားဖျက်ဆီးခြင်းနှင့်ကုမ္ပဏီများအားသုံးစွဲသူများအပေါ်အာဏာလက်ဝါးကြီးအုပ်ရန်ဖြစ်သည်။ WideVine ကိုသင်လုံးဝကုစားသင့်သည်။

[WideVine နှင့်၎င်း၏ပြproblemsနာများကိုဤနေရာတွင်ဖတ်ရှုပါ] (https://github.com/Degoogle-your-life/Its-time-to-cut-WideVine-DRM)

***

## အဖြစ်များသောအယူအဆများ

ဤသည်မှာဂူးဂဲလ်ထုတ်ကုန်များနှင့် ပတ်သက်၍ အများထင်မြင်ယူဆချက်အချို့၏စာရင်းဖြစ်သည်။

### ဂူဂဲလ်သည်အင်တာနက်မဟုတ်ပါ

Google / Google search သည်အင်တာနက်မဟုတ်ပါ။ Google search သည်ရှာဖွေရေးအင်ဂျင်တစ်ခုမျှသာဖြစ်သည်။ Nintendo ပလက်ဖောင်းအတွက်ဂိမ်းတိုင်းကို Nintendo ကပြုလုပ်သည်မဟုတ်ဘဲ Nintendo မှလိုင်စင်ထုတ်ပေးသည်။ Googles ဆာဗာများအားလုံးကိုယခုအချိန်တွင်တစ်ပြိုင်နက်ဖျက်ဆီးပစ်မည်ဆိုပါက YouTube, Gmail, Google Docs စသည့်ဂူဂဲလ်ဆိုဒ်များသာပျောက်ကွယ်သွားမည်ဖြစ်သော်လည်းအင်တာနက်အများစုရှိနေဆဲဖြစ်သည် (Wikipedia, Stackoverflow, GitHub, Microsofts ၀ က်ဘ်ဆိုက်များအားလုံး၊ NYTimes၊ Samsung၊ TikTok စသည်ဖြင့်) သူတို့သည်သူတို့၏ဂူဂဲလ် ၀ င်ရောက်မှုနှင့်ခွဲခြမ်းစိတ်ဖြာမှုဆိုင်ရာလုပ်ဆောင်နိုင်စွမ်းကိုဆုံးရှုံးကောင်းဆုံးရှုံးနိုင်သည်။ သို့သော်သူတို့သည် (ပရိုဂရမ်များညံ့ဖျင်းခြင်းနှင့်ဂူဂဲလ်သို့တိုက်ရိုက်အားကိုးခြင်းမခံရပါက) အလုပ်လုပ်နိုင်ဆဲဖြစ်သည်

***

## Internet Explorer 6 နှင့် Chrome

Google Chrome သည် Internet Explorer အသစ်ဖြစ်လာသည်။ Google Chrome သည်မူလထွက်ပေါ်လာသောအခါ Firefox သည်အဓိက browser ဖြစ်ကာ၊ Google Chrome ရှိစဉ်ကသန်းပေါင်းများစွာသောလူများသည် Firefox နှင့်အခြား browser များသို့ကူးပြောင်းခြင်းမပြုမီ Internet Explorers စျေးကွက်ဝေစုကိုအများဆုံးအဆုံးသတ်ခဲ့သည်။ ထွက်ပေါ်လာတဲ့အခါမှာလူတွေဟာအမြန်နှုန်းကြောင့်ပြောင်းပြီးဂူဂဲလ်ကဖြစ်ခဲ့ကြတာပါ (အဲ့ဒီတုန်းကမကောင်းဘူးလို့မယူမှတ်ရသေးတဲ့အတွက် privacy ပြissuesနာအတော်များများမပေါ်လာသေးဘူး) Google Chrome ဟာ Firefox လုပ်ခဲ့တဲ့ web စံချိန်စံညွှန်းကိုမူလကလေးစားခဲ့ပါတယ်။ Internet Explorer ကို ၉၆ ရာခိုင်နှုန်းသော browser စျေးကွက်များကအဆုံးသတ်စေခဲ့သည်။ သို့သော် Google Chromes စျေးကွက်မြင့်တက်လာသည်နှင့်အမျှဂူးဂဲလ်သည်စွမ်းဆောင်ရည်များပိုမိုဖယ်ရှားခြင်း၊ စပိုင်ဝဲများထပ်တိုးခြင်းနှင့် ၀ က်ဘ်စံနှုန်းများကိုလက်ခံခြင်းကိုရပ်တန့်လိုက်ခြင်းကြောင့် Google Chrome သည် Internet Explorer 6 အသစ်ဖြစ်လာသည်။

လက်ရှိပြproblemနာမှာ Chrome တစ်ခုတည်းရှိသောဝက်ဘ်ဆိုက်များဖြစ်ပြီးအခြားဘရောင်ဇာများပေါ်တွင်အလုပ်မလုပ်ပါ။ developer များကသူတို့ Chrome ကိုမသုံးသောအခြားအင်တာနက်သုံးစွဲသူ ၃၀ မှ ၄၀ ရာခိုင်နှုန်းသည်သူတို့၏ site ကိုအသုံးပြုရန်မလိုလားကြပါ။

ဂူးဂဲလ်ကိုယ်တိုင်ပင်သူတို့၏ဆိုဒ်များ Chrome ကိုသာလုပ်နေသည်။ ဥပမာအားဖြင့်၊ Google ရှာဖွေမှုသည်သင့်အား Google Chrome ကိုအသုံးမပြုကြောင်း (Chromium အခြေပြု Brave ကဲ့သို့သောအခြားဘရောင်ဇာများတောင်မှ) တွေ့ရှိပါက ၁၀ စက္ကန့်တိုင်းတွင် ၃ ကြိမ်အကြိမ်ကြိမ် download လုပ်ရန်သတိပေးလိမ့်မည်။ Google Earth ကဲ့သို့သောဆိုဒ်များက Firefox အသုံးပြုသူများကိုခွင့်မပြုပါ သူတို့၏ site ကို (၂၀၂၀ ပြည့်နှစ်တွင်) အသုံးပြုပါက Google Translate သည် Firefox နှင့်အခြားဂူဂဲလ်မဟုတ်သောအခြား browser များတွင် voice input ကိုအထောက်အပံ့မပေးပါ။

### Brave ပြTheနာ

Brave နှင့် Microsoft Edge ကဲ့သို့သော Chromium ကိုအခြေခံသောအခြား browser များသည် Google spyware နှင့်လုံးဝမကင်းပါ။ Brave ကို privacy အသိုင်းအဝိုင်း၏မှားယွင်းသောဘက်မှအများအားဖြင့်အကြံပြုသော်လည်း Brave သည် Chromium ကိုအသုံးပြုသောကြောင့်ပြproblemနာတစ်ခုဖြစ်နေသေးသည်။ အင်တာနက်သည်ခရိုမီယမ်ဘရောင်ဇာများဖြင့်သာမထားသင့်ပါ၊ ရွေးချယ်မှုအမျိုးမျိုးရှိသင့်သည် သတ္တိသည်သွားရန်လမ်းမှားဖြစ်သည်။

[ဤနေရာတွင် Google Chrome / Chromium မှဖယ်ထုတ်ခြင်းအကြောင်းအသေးစိတ်ဖတ်ရှုပါ] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[ဤတွင် ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) မှ deogogling အကြောင်းပိုမိုဖတ်ရှုရန်] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## အတတ်ပညာဆိုင်ရာလုံခြုံမှုသက်တမ်းတိုးခြင်း

ဂူးဂဲလ်ကသူတို့နောက်ကွယ်မှာသိပ်နောက်ကျပြီးတဲ့နောက်၊ သူတို့က privacy ကိုဂရုစိုက်ကြောင်းကမ္ဘာကိုပြောပြဖို့ကြိုးစားနေသည်။ သူတို့သည်သုံးစွဲသူများ၏ privacy ကိုလေးစားကြောင်းဆက်လက်ပြောဆိုသော်လည်း၎င်းတို့သည်၎င်းတို့၏ privacy ပြallနာများကိုမဖြေရှင်းနိုင်သေးပါ။

### ပွင့်လင်းအရင်းအမြစ်တစ်စိတ်တစ်ပိုင်းဖြစ်မရပါ

ပွင့်လင်းအရင်းအမြစ်တစ်စိတ်တစ်ပိုင်းမဖွစျနိုငျသညျ။ ဂူဂဲလ်ကဒါသက်သေပြ source code ၏ bit နှင့် byte တိုင်းသည်အများပြည်သူမြင်သာအောင်မြင်ရလိမ့်မည်။

Android နှင့် ChromeOS တို့ကဲ့သို့သောစီမံကိန်းများသည်တစ်စိတ်တစ်ပိုင်းတစ်စိတ်တစ်ပိုင်းပွင့်လင်းသောအရင်းအမြစ်ဖြစ်သော်လည်းစီးပွားဖြစ်၊ စပိုင်ဝဲအများစုပါ ၀ င်သည်။

### Oxymoron

Google VPN သည်n oxymoron ။ ဂူးဂဲလ်သည် privacy ကိုဂရုမစိုက်ပါ။ ၎င်းတို့ကဲ့သို့သောကုမ္ပဏီမှ Virtual Private Network (VPN) သည် VPN ဝန်ဆောင်မှုအတွက်အဆိုးရွားဆုံးရွေးချယ်မှုတစ်ခုဖြစ်လိမ့်မည်။

***

## မကောင်းတဲ့စွမ်းဆောင်ရည်

သူတို့၏နောက်ဆုံးစံသတ်မှတ်ချက်ဆော့ဖ်ဝဲ (ဂူးဂဲလ် Octane) ကို ၂၀၁၇ ခုနှစ်တွင်ရပ်စဲလိုက်သဖြင့်ဂူးဂဲလ်သည်သူတို့၏ထုတ်ကုန်များ၏စွမ်းဆောင်ရည်ကိုအနည်းဆုံး ၂၀၁၇ အထိဂရုမစိုက်ပါ။

***

## မကောင်းတဲ့စီမံကိန်းစီမံခန့်ခွဲမှု

ဂူးဂဲလ်တွင်အလွန်ဆိုးရွားသည့်အတွင်းပိုင်းစီမံကိန်းစီမံခန့်ခွဲမှုစနစ်ရှိသည်။ ပို၍ အဆင့်မြှင့်တင်မှုပိုများလာသည့်အသုံးများသောပရိုဂရမ်များဥပမာတွင်ဂူဂဲလ် Duo နှင့် YouTube ဂီတ (ယခင် Google Play Music) တို့ပါဝင်သည်

Googles ၏ internal development system တွင်၊ 1 အက်ပလီကေးရှင်းသည်လုပ်ဆောင်နိုင်စွမ်းထက်ဝက်ရှိသောအခြားအက်ပလီကေးရှင်းတစ်ခုသို့ ဦး တည်သွားသည်၊ ထို့နောက်မူလအက်ပလီကေးရှင်းကိုဖျက်ပစ်လိမ့်မည်။ နှစ်နှစ်ခန့်ကြာပြီးနောက် ၇၅% လျော့နည်းသောအက်ပလီကေးရှင်းအသစ်တစ်ခုကိုလုပ်သည်။ ထို့နောက် ၅၀% အသုံးချနိုင်သောအက်ပလီကေးရှင်းကိုဖယ်ရှားသည်။ ၎င်းနောက်အက်ပလီကေးရှင်းသစ်ကို ၈၇.၅% ဖန်တီးထားသည်၊ ထို့နောက် ၇၅% သောအက်ပလီကေးရှင်းကိုရပ်ဆိုင်းလိုက်သည်။ , နောက် ... ပြီးတော့။

***

## စက်ဆုပ်ရွံရှာဖွယ်ကောင်းလောက်အောင် ၀ န်ဆောင်မှုများမရှိ

YouTube သည်အဆိုးရွားဆုံးသောအလယ်အလတ်အဆင့်ရှိအဆိုးရွားဆုံးသောပလက်ဖောင်းကိုဖန်တီးသည့်မကောင်းသောအလယ်အလတ်လောက၌အသုံးအများဆုံးဥပမာဖြစ်သည်။ YouTube ဟာ YouTube ရဲ့ကလေးတွေမဟုတ်သေးဘူးဆိုတာကို Google ကမထင်ထားဘူး။

ယူကျု့အတွက်မူနာဇီလိုလားသူနှင့်အဖြူရောင်စူပါမက္ကစ္စကိုမုန်းတီးခြင်းသည်အသုံးပြုသူများကိုထိတွေ့ဆက်ဆံမှုအချိန်နှင့်ငွေများများများရရန်ဖြစ်သည်။ ဂူးဂဲလ်သည်အလွန်မိုက်မဲသောအရာများပြုလုပ်ခဲ့သည်မှာ Christian Anal Sex ဗီဒီယိုအား `ကလေးများအတွက်ပြုလုပ်သောအရာများ appro အဖြစ်အတည်ပြုခြင်းကဲ့သို့ဖြစ်သည်။ ညစ်ညမ်းရုပ်ပုံစာပေနှင့် gore ကြော်ငြာများသည်ကလေးများအတွက်ပြုလုပ်ထားသောအခြား `အမျိုးမျိုးသော made Baby Shark ဗီဒီယိုအောက်တွင်ကြည့်နေသည်ကိုတွေ့ရခြင်းမှာအဆန်းမဟုတ်ချေ။

ယူကျုးဘ်သုံးစွဲသူများသည်မကောင်းသောအကြောင်းအရာများအတွက် (အပေါ်တွင်ဖော်ပြထားသောဥပမာများကဲ့သို့) YouTube ၌မကောင်းသောဖြည့်ညှင်းမှုနှင့်ပတ်သက်ပြီးမကြာခဏညည်းညူကြသည်။ သုံးစွဲသူများသည်ကျိန်ဆိုခြင်းအတွက်အပြစ်ပေးခံရခြင်းနှင့်အတူအကြောင်းပြချက်မရှိဘဲပြန်လည်ရုပ်သိမ်းခြင်းမပြုနိုင်သောအကြောင်းပြချက်မရှိဘဲဖျက်ပစ်နိုင်သည်။ `crap` အသုံးပြုသူများသည်ပြောခြင်းကဲ့သို့သောအလွန်သေးငယ်သောကိစ္စများမှာဤမျှတမှုမရှိသောပြစ်ဒဏ်များကြောင့်စတာလင်ခေတ်တွင် YouTube ကို [ဆိုဗီယက်ယူနီယံ] (https://en.wikipedia.org/wiki/Soviet_Union) နှင့်နှိုင်းယှဉ်လေ့ရှိသည်။

၂၀၂၁ ခုနှစ်တွင်ဂူးဂဲလ်က၎င်းတို့သည်ဗီဒီယိုအားလုံးတွင်ကြော်ငြာများတင်မည်ဟုကြေငြာခဲ့သည်။ (ဂူဂဲလ်သည်ငွေရှာသည်၊ သို့သော်တီထွင်သူကမူ၎င်းသည်) ၎င်းသည်အသင့်အတင့်နှင့်အလွန်မပတ်သက်ပါ၊ သို့သော်မှတ်သားရန်အရေးကြီးသည်။

YouTube အားအလယ်အလတ်အဆင့်သတ်မှတ်ထားသည် (အလွန်ညံ့ဖျင်းသော်လည်း) သို့သော်၎င်းတို့ငွေအများစုကိုရရှိစေသောဂူဂဲလ်ကြော်ငြာဝန်ဆောင်မှုသည်အနည်းငယ်မျှသာမလုံလောက်ဟုထင်ရသည်။

[YouTube ၏ဖြည့်တင်းခြင်းဆိုင်ရာပြissuesနာများနှင့် YouTube မှမည်သို့ပြောင်းနည်းကိုဖတ်ရှုရန်] (https://github.com/seanpm2001/Alternating-from-YouTube)

Google Play အတွက်ကြော်ငြာများကို bot farms မှထုတ်လုပ်သည်။ ပြောင်းလဲမှုအနည်းငယ်သာရှိသောရာနှင့်ချီသောကုမ္ပဏီများအသုံးပြုသည့်တူညီသောကြော်ငြာဇာတ်လမ်းများကိုသင်ပြောနိုင်သည်။ ထုတ်ကုန်နှင့်မပတ်သက်ပါ။ (ဥပမာ - Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City, နှင့် PayPal ကဤအချက်ကိုမှတ်ချက်မပေးသော်လည်းသင်လုပ်နိုင်သည်မှာလိမ်လည်မှုဖြစ်ကြောင်းထင်ရှားသည်။ သို့သော်ကြော်ငြာများသည်သုံးစွဲသူများသည်ဂိမ်းကစားခြင်း၊ သီချင်းနားထောင်ခြင်းဖြင့်ငွေရှာနိုင်သည်ဟုဆိုကြသည်။ ဒေါ်လာ ၂၀၀၀ ကျော်တန်ကြေးရှိတဲ့ဂိမ်းတစ်ခုကိုကစားခြင်းအားဖြင့်စက္ကန့် ၂၀ အတွင်းမှာဘယ်သူမှအလုပ်လုပ်မှာမဟုတ်ဘူး၊ ဒါကိုလုပ်မှာမဟုတ်ဘူး၊ မဖြစ်နိုင်ဘူး၊ ဒီသိသာထင်ရှားတဲ့လိမ်လည်မှုဟာ 2019 ခုနှစ်မှစပြီးကြီးထွားလာခဲ့ပြီးယခုကြော်ငြာများထုတ်လုပ်တဲ့ bot farms ကသူတို့ကိုယ်ပိုင်ကြော်ငြာတွေမှာတစ် ဦး နှင့်တစ် ဦး တိုက်ခိုက်နေကြတယ်။

ကြော်ငြာအတော်များများသည်အလွန်ဆိုးရွားသည်။ အသုံးပြုသူများကို (အများစုမှာအသက် ၁၃ နှစ်အောက်အသုံးပြုသူများသို့မဟုတ် bot များဖြစ်သည်) အားလိင်ပိုင်းဆိုင်ရာခြယ်လှယ်ခြင်းများမှတစ်ဆင့်နှိပ်ခိုင်းရန်ကြိုးစားသည်။

အက်ပလီကေးရှင်းအတော်များများသည် bot များ အသုံးပြု၍ သူတို့၏ထုတ်ကုန်များကို astroturf သုံးကြသည်။ ထို့ကြောင့်မကောင်းသောပြန်လည်သုံးသပ်မှုပြုလုပ်တိုင်း sock puppet bot အကောင့်များသည်ကြယ် ၅ ပွင့်သုံးသပ်ချက်များကိုစ တင်၍ သင်၏ဝေဖန်မှုကိုငြင်းဆန်ရန်ကြိုးစားလိမ့်မည်။ [ဂူဂဲလ်လည်းဒီအတိုင်းပဲလုပ်တယ်။ ] (# Astroturfing)

[Google AdSense နှင့် ပါတ်သက်၍ အသေးစိတ်ဖတ်ရန်] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

ယေဘူယျအဓိပ္ပါယ် [(Wikipedia မှ)] (https://en.wikipedia.org/wiki/Astroturfing)

`` `
Astroturfing ဆိုသည်မှာအောက်ဖော်ပြပါသင်တန်းသားများမှထောက်ခံအားပေးသကဲ့သို့၎င်းပေါ်လာစေရန်မက်ဆေ့ခ်ျသို့မဟုတ်အဖွဲ့အစည်းတစ်ခု (ဥပမာနိုင်ငံရေး၊ ကြော်ငြာ၊ ဘာသာရေးနှင့်လူထုဆက်ဆံရေး) ၏စပွန်ဆာများကိုဖုံးကွယ်ထားသည့်အလေ့အကျင့်ဖြစ်သည်။ ၎င်းသည်အရင်းအမြစ်၏ဘဏ္connectionာရေးဆိုင်ရာဆက်သွယ်မှုနှင့်ပတ်သက်သည့်သတင်းအချက်အလက်များကိုမသိမ်းဆည်းခြင်းအားဖြင့်ထုတ်ပြန်ကြေငြာချက်များသို့မဟုတ်အဖွဲ့အစည်းများအားယုံကြည်ကိုးစားမှုရှိစေရန်ရည်ရွယ်သည့်အလေ့အကျင့်တစ်ခုဖြစ်သည်။ astroturfing ဟူသောအသုံးအနှုန်းသည် AstroTurf မှဆင်းသက်လာပြီး၊ သဘာဝမြက်နှင့်တူအောင်ဒီဇိုင်းပြုလုပ်ထားသည့်ဒြပ်ကော်ဇောများကလည်း“ အောက်ခြေ” ဟူသောစကားလုံးတွင်ပြသထားသည်။ ဟူသောဝေါဟာရကိုအသုံးပြုမှုနောက်ကွယ်မှဆိုလိုရင်းမှာစစ်မှန်သောသို့မဟုတ်သဘာဝကျသောအောက်ခြေလူတန်းစားတို့၏ကြိုးပမ်းမှုအစားထောက်ခံမှု၏အတု (သို့) အတုပုံစံပေါ်ထွက်လာခြင်းဖြစ်သည်။
`` `

ဥပမာအားဖြင့်၊ Google တွင် astroturfing သည်မကောင်းသောအရာတစ်စုံတစ်ခုကိုမျှမပြုလုပ်သကဲ့သို့ထင်မြင်စေရန်အတွက် astroturfing သည်သမိုင်းရှိသည်။တွစ်တာကဲ့သို့သောပလက်ဖောင်းပေါ်တွင် Google အားဝေဖန်ခြင်းသည်အချိန်အတော်ကြာတည်ရှိခဲ့သော်လည်းသင်ထွက်မလာမီနှင့်သင်ပြောခဲ့သည့်အရာသည်မှားသည်ဟုပြောဆိုခြင်းမရှိသည့်အကောင့်များစွာကိုဖြစ်ပေါ်စေပြီး၊ အကောင်းဆုံးကုမ္ပဏီဖြစ်သော်လည်း၎င်းသည်လူအများစုအတွက်အစက်အပြောက်များဖြစ်ကြောင်းသိသာမည်မဟုတ်ပါ။

***

## တရားမ ၀ င်၊

အခွန်အကောက်များအသုံးပြုခြင်း၊ အလုပ်များလွှဲပြောင်းခြင်းနှင့်တရားမ ၀ င်ကျူးကျော် ၀ င်ရောက်မှုများကိုစီးပွားရေးလုပ်ရန်ကုန်ကျစရိတ်များကဲ့သို့သောသူတို့၏လက်ဝါးကြီးအုပ်မှုကိုဆက်လက်တိုးပွားစေရန်တရားမ ၀ င်နှင့်ကျင့် ၀ တ်မဲ့သောစီးပွားရေးလုပ်ထုံးလုပ်နည်းများကိုအသုံးပြုသည်။

### ဥရောပမှာ

ဥရောပသည်ဂူဂဲလ်ကိုမကြာခဏတရားစွဲလေ့ရှိပြီး Android တွင်တရားမ ၀ င်သောအပြုအမူများကိုဆန့်ကျင်သောအကြီးဆုံးတရားစွဲဆိုမှုကြောင့်ဂူးဂဲလ်ကိုယူရို ၅,၀၀၀,၀၀၀,၀၀၀ ရရှိခဲ့သည် (၂၀၂၁ moneyပြီလ ၉ ရက်တွင်ငွေဒေါ်လာ ၅,၉၄၇,၀၈၃,၇၀၃.၆၈ နှင့်ညီမျှသည်)

### မြောက်အမေရိက၌တည်၏

ယူနိုက်တက်စတိတ်သည်ဂူးဂဲလ်အားဒဏ်ငွေနီးပါးမပေးရသေးသော်လည်းယူရိုငွေ ၅,၀၀၀,၀၀၀,၀၀၀ ဒဏ်ငွေရှိသည်။

### အငြင်းပွားမှုများ

ဂူးဂဲလ်သည်အငြင်းပွားဖွယ်ရာကိုဖန်တီးသည်အထိပြcareနာကိုဂရုမစိုက်ပါ။ ထို့နောက်သူတို့ကဖြေရှင်းရန်အားနည်းချက်ရှိလိမ့်မည်။ အငြင်းပွားမှုကိုယာယီပျောက်ကွယ်သွားနိုင်ရုံသာမက၎င်းသည်အခြားအငြင်းပွားဖွယ်ရာများမဖန်တီးမချင်းပြproblemနာကိုအဆအဆပိုဆိုးစေသည်။ သံသရာဆက်ဖြစ်နေသည်။ သူတို့ကလေးလေးနက်နက်ဘာမှလုပ်ဖို့လုံလောက်တဲ့ဂရုမစိုက်ပါဘူး။

***

## Google သည်အလိုအလျောက်ဖြစ်သည်

ကုမ္ပဏီတစ်ခုအနေနှင့် Google သည်အများအားဖြင့်အလိုအလျောက်ဖြစ်သည်။

တစ် ဦး ကကုမ္ပဏီအပြည့်အဝအလိုအလျောက်မဖြစ်သင့်။ ဂူဂဲလ်သည်ဤဥပမာ၏ဥပမာတစ်ခုဖြစ်သည်။ AI မှပြုလုပ်သောအခါ YouTube သည်ကောင်းမွန်သောဥပမာတစ်ခုဖြစ်သည်။ အပိုအနည်းငယ် (ရာပေါင်းများစွာသော (သို့) တစ်ထောင်) လူအများကြည့်လျှင်တောင်မှထို site ကိုပြုပြင်ရန်အလွန်ခက်ခဲသောကြောင့်အများစုမှာအလုပ်လုပ်နေစဉ်ကုထုံးကိုခံယူရန်လိုသည်။

***

## Android

Android ကို Google ကပိုင်ဆိုင်သည်။ (Android ကတည်းကမဖွင့်သေးသော) Open Handset Alliance ၏အစိတ်အပိုင်းတစ်ခုသည် Google အတွက်နောက်ထပ်လက်ဝါးကြီးအုပ်သည့်အချက်ဖြစ်လာပြီးလွတ်မြောက်ရန်အလွန်ခက်ခဲသည်။

တစ်ရက်လျှင်အနည်းဆုံး ၁၀ ကြိမ်ဂူဂဲလ်ကို Android ဖုန်းများသို့ Android ဖုန်းများပေးပို့သည်ဟုသတင်းများထွက်ပေါ်နေပြီး၎င်းသည်တစ်စိတ်တစ်ပိုင်းပွင့်လင်းသောအရင်းအမြစ်ဖြစ်သော်လည်း၎င်းသည်စပိုင်ဝဲကဲ့သို့ကြီးမားစွာပြုမူနေဆဲဖြစ်သည်။

များစွာသောစီမံကိန်းများကို Android နှင့်ပြုလုပ်ရန်ဖန်တီးထားသည်၊ သို့သော်သင့်ဖုန်းကို root လုပ်ရန်လိုအပ်သည်။ Knox DRM ကြောင့် US ရှိတိကျသော Samsung ဖုန်းများအတွက်၎င်းသည်မဖြစ်နိုင်ပါ။ Android တွင်အများအားဖြင့် iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch နှင့် PiPhone တို့ပါ ၀ င်သည် (Pi Phone သည်မိုဘိုင်းထုတ်ကုန်များပေါ်တွင် Fedora, Ubuntu, Arch စသည်တို့ကိုမိုဘိုင်းထုတ်ကုန်များပေါ်တွင် Linux စနစ်များစွာလည်ပတ်သောဖုန်းများဖြစ်သည်)

[degoogled Android virtual machine အလုပ်လုပ်ပုံနှင့် ပတ်သက်၍ ကျွန်ုပ်၏သုတေသနကိုကြည့်ပါ] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[အန်းဒရွိုက်မှမည်သို့ဖယ်ထုတ်ရမည်ကိုကြည့်ပါ] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## ကူညီရန်အသေးစားလုပ်ဆောင်မှုများ

အသိပညာကိုတတ်နိုင်သမျှဖြန့်ဝေရန်အရေးကြီးသည်။ ကျွန်ုပ်အတွက်တော့ degoogling အကြောင်းနှင့်ဆောင်းပါးများရေးသားခြင်းအကြောင်းကိုမကြာခဏပြောရုံသာမကကျွန်ုပ်၏နေ့စဉ်အခမဲ့ Reddit ဆုကို r / degoogle တွင်ထည့်သွင်းထားသည့် post ကိုအသိပေးရန်မြှင့်တင်ပေးသည့်အလေ့အကျင့်တစ်ခုလည်းရှိသည်။ ယခုထိကျွန်ုပ်သည် (၃၀) နီးပါးခန့်သည်ခိုင်ခံ့သောပို့စ်ကိုပေးခဲ့သည် (ကျွန်ုပ်အခမဲ့ဒင်္ဂါး ၅၀၀ ကိုလည်းထို ၁၀ ခုအတွက်ဆု ၁၀ ခုကိုသုံးစွဲခဲ့သည်)

***

ယုံကြည်စိတ်ချရသော ##

ဂူဂဲလ်ကိုစိတ်မချရဘူး၊ ဘယ်တော့မှစိတ်မချရတော့ဘူး။ သူတို့သည်လုံးဝမကောင်းသောအမှုများမှရှောင်ကြဉ်။ ဖုံးကွယ်ရန်ကြိုးစားခြင်းမှ (မကောင်းမှုမဖြစ်စေရန်) လုံးဝသွားကြသည်။

***

## ထွက်စစ်ဆေးရန်အခြားအရာ

[ဂူဂဲလ်သင်္ချိုင်းဂူ (killbygoogle.com) - ဂူဂဲလ်မှသတ်ဖြတ်ခဲ့သောထုတ်ကုန် ၂၂၄ ခု၏အမျိုးအစားစာရင်း] (https://killedbygoogle.com/)

> [GitHub link] (https://github.com/codyogden/killedbygoogle)

[အက္ခရာအလုပ်သမားသမဂ္ဂ - ဂူးဂဲလ်တွင်ဝန်ထမ်း ၈၀၀ ကျော်ပါ ၀ င်သောအလုပ်သမားသမဂ္ဂအသစ်] (https://alphabetworkersunion.org/people/our-union/)

[ဒိုင်နိုဆောမျိုးစေ့ကြက်ဥနှင့်မခွဲချင်ဘူးလား? ဒီဝက်ဘ်ဆိုက်ကိုသင်ဖုံးလွှမ်းထားသည်] (https://chromedino.com/)

အခြားရွေးချယ်စရာတွေလည်းရှိသေးတယ်။

***

ဤဆောင်းပါးအတွက်အချက်အလက်များစစ်ဆေးရန်လိုအပ်သည်

***

အချက်အလက်ဖိုင် ##

ဖိုင်အမျိုးအစားအမျိုးအစား - `Markdown (* .md)`

လိုင်းအရေအတွက် (အလွတ်လိုင်းများနှင့် compiler line အပါအ ၀ င်): `968`

File version: 6 (တနင်္ဂနွေ၊ 21ပြီ ၁၈ ရက် ၂၀၂၁ တွင်ညနေ ၄ း ၂၉)

***

### software အခြေအနေ

ကျွန်ုပ်၏လုပ်ဆောင်မှုအားလုံးသည်အချို့သောကန့်သတ်ချက်များရှိသည်။ DRM (** D ** igital ** R ** estrictions ** M ** anagement) ကျွန်ုပ်၏လက်ရာများတွင်မရှိပါ။

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

ဒီစတစ်ကာကိုအခမဲ့ဆော့ဗ်ဝဲဖောင်ဒေးရှင်းကထောက်ခံသည်။ ငါသည်ငါ့အကျင့်ကိုကျင့်အတွက် DRM ထည့်သွင်းရန်ရည်ရွယ်ထားဘူး။

ငါ "ဒီဂျစ်တယ်အခွင့်အရေးစီမံခန့်ခွဲမှု" ၏အတိုကောက်မှားဒစ်ဂျစ်တယ်အခွင့်အရေးစီမံခန့်ခွဲမှုအစား "ဒစ်ဂျစ်တယ်ကန့်သတ်ချက်စီမံခန့်ခွဲမှု" ၏အတိုကောက်ကို သုံး၍ DRM နှင့်အခွင့်အရေးများမရှိပါ "Digital Restrictions Management" စာလုံးပေါင်းသည်ပိုမိုတိကျပြီး၎င်းကို [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) နှင့် [Free Software Foundation (FSF)] မှထောက်ခံသည်။ https://en.wikipedia.org/wiki/Free_Software_Foundation)

ဤအပိုင်းကို DRM နှင့်ပြproblemsနာများအတွက်အသိပညာပေးရန်နှင့်၎င်းကိုကန့်ကွက်ရန်အသုံးပြုသည်။ DRM ချွတ်ယွင်းသည်ဒီဇိုင်းနှင့်ကွန်ပျူတာအသုံးပြုသူများနှင့်ဆော့ဖ်ဝဲလွတ်လပ်ခွင့်အတွက်အဓိကခြိမ်းခြောက်မှုဖြစ်သည်။

image credit: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## ထောက်ပံ့သူအချက်အလက်

! [SponsorButton.png] (SponsorButton.png) <- ဤခလုတ်ကိုမနှိပ်ပါနှင့်၊ အလုပ်မလုပ်ပါ၊ ပုံတစ်ခုသာဖြစ်သည်။ အစစ်အမှန်ခလုတ်သည်ညာဘက်ထောင့် (<- L ** R ** ->) ၏စာမျက်နှာထိပ်ရှိဖြစ်သည်

ဤစီမံကိန်းကိုသင်ကြိုက်နှစ်သက်ပါကသင်ကမကထပြုနိုင်သည်။ သို့သော်သင်လှူဒါန်းလိုသည့်အရာများကို ကျေးဇူးပြု၍ ဖော်ပြပါ။ [ဤနေရာတွင်သင်လှူဒါန်းနိုင်သောရန်ပုံငွေများကိုကြည့်ပါ] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

အခြားစပွန်ဆာအချက်အလက် [ဒီမှာ] ကိုကြည့်နိုင်သည်။ (https://github.com/seanpm2001/Sponsor-info/)

စမ်းကြည့်ပါ ဦး ။ စပွန်ဆာခလုတ်သည်နာရီ / နာရီမဖွင့်သောခလုတ်၏ဘေးတွင်ရှိသည်။

***

## ဖိုင်မှတ်တမ်းမှတ်တမ်း

ဗားရှင်း ၁ (၂၀၂၁ ခုနှစ်၊ သောကြာနေ့၊ ဖေဖော်ဝါရီ ၁၉ ရက်ညနေ ၅ း ၂၀)

> အပြောင်းအလဲများ -

> * ဖိုင်ကိုစတင်ခဲ့သည်

> * အခြေခံဖော်ပြချက်အပိုင်းကိုထည့်သွင်းခဲ့သည်

> * repository ဖော်ပြချက်အပိုင်းကဆက်ပြောသည်

> * ဆောင်းပါးများစာရင်း ၁၄ ခုပါသောဆောင်းပါးစာရင်းကိုထည့်သွင်းခဲ့သည်

>> * `ဆက်စပ်သောဆောင်းပါးများ` ကဏ္ Added တစ်ခုကိုထပ်မံထည့်သွင်းခဲ့သည်

>> * `` also` ကြည့်သည့်အပိုင်းကိုထပ်မံထည့်သွင်းခဲ့သည်

> * ဖိုင်အချက်အလက်အပိုင်းကိုထည့်သွင်းခဲ့သည်

> * ဖိုင်သမိုင်းကြောင်းအပိုင်းကိုထည့်သွင်းခဲ့သည်

> * အောက်ခြေတွင်ထည့်သည်

> * ဗားရှင်း ၁ တွင်အခြားအပြောင်းအလဲမရှိပါ

ဗားရှင်း ၂ (၂၀၂၁ ခုနှစ်၊ သောကြာနေ့၊ ဖေဖော်ဝါရီ ၁၉ ရက်ညနေ ၅:၂၆)

> အပြောင်းအလဲများ -

> * ဘာသာပြန်ချက်အခြေအနေကိုထည့်သွင်းခဲ့သည်

> * ကဏ္ out ကိုစစ်ဆေးရန်အခြားအရာများထည့်သွင်းခဲ့သည်

> * ကိုယ်ရေးကိုယ်တာအချက်အလက်ကဏ္ Added ကိုထပ်ထည့်လိုက်သည်

> * တစ်ခုအညွှန်းကိန်းကဆက်ပြောသည်

> * ဆော့ဖ်ဝဲကို status ကိုပုဒ်မခွဲထည့်သွင်းခဲ့သည်

> * အခြားဂူဂဲလ်ဆန့်ကျင်ရေးလှုပ်ရှားမှုများကဏ္ Added ကိုထပ်ထည့်လိုက်သည်

>>> * အဆိုပါအသုံးမဝင်တော့ပုဒ်မခွဲကဆက်ပြောသည်

>>> ဆက်လက်ဖြစ်ပွားနေသောပုဒ်မခွဲကဆက်ပြောသည်

> * ရင်းမြစ်များအပိုင်းကိုထပ်ထည့်ခဲ့သည်

> * ဒေါင်းလုပ်လင့်ခ်လင့်များအပိုင်းကိုထည့်သွင်းခဲ့သည်

> * ဖိုင်အချက်အလက်များအပိုင်းကိုအဆင့်မြှင့်တင်ထားသည်

> * ဖိုင်သမိုင်းကြောင်းအပိုင်းကိုအသစ်ပြောင်းခဲ့သည်

> * ဗားရှင်း ၂ တွင်အခြားအပြောင်းအလဲမရှိပါ

ဗားရှင်း ၃ (၂၀၂၁ ခုနှစ်၊ ဗုဒ္ဓဟူးနေ့၊ ဖေဖော်ဝါရီ ၂၄ ရက်ည ၇ း ၅၆)

> အပြောင်းအလဲများ -

> * အညွှန်းကိန်း updated

ဂူဂဲလ်အိုင်ကွန်နှင့် GitHub အဖွဲ့အစည်းသစ်ကိုကိုးကားပါ

> * ဆောင်းပါးအသစ်များသို့လင့်ခ်များထပ်ထည့်သည်

> * တန်ပြန်သည်အခြားအငြင်းပွားမှုများအပိုင်းကဆက်ပြောသည်

>> * အဆင်ပြေပုဒ်မခွဲကဆက်ပြောသည်

>> * ပုဒ်မခွဲကိုပင်အနှောင့်အယှက်ပေးသည့်အဘယ်ကြောင့်ထည့်သွင်းခဲ့သည်

>> * အခြားပုဒ်မခွဲကဆက်ပြောသည်

> * အချက်အလက်အချို့ကိုအဆင့်မြှင့်တင်ထားသည်

> * ဖိုင်အချက်အလက်များအပိုင်းကိုအဆင့်မြှင့်တင်ထားသည်

> * ဖိုင်သမိုင်းကြောင်းအပိုင်းကိုအသစ်ပြောင်းခဲ့သည်

> * ဗားရှင်း ၃ တွင်အခြားအပြောင်းအလဲမရှိပါ

ဗားရှင်း ၄ (၂၀၂၁ ခုနှစ်၊ ဖေဖော်ဝါရီ ၂၅ ရက်၊ ညနေ ၉ း ၃၁) ။

> အပြောင်းအလဲများ -

ဆောင်းပါး ၁၀ ခုသို့လင့်ခ်များထပ်ထည့်သည်

> * ကျွန်ုပ်၏အတွေ့အကြုံပျက်ခြင်းအကြောင်းအပိုင်းတစ်ခုကိုထပ်ထည့်သည်

> * အညွှန်းကိန်း updated

> * ဖိုင်အချက်အလက်များအပိုင်းကိုအဆင့်မြှင့်တင်ထားသည်

> * ဖိုင်သမိုင်းကြောင်းအပိုင်းကိုအသစ်ပြောင်းခဲ့သည်

> * ဗားရှင်း ၄ တွင်အခြားပြောင်းလဲမှုမရှိပါ

ဗားရှင်း ၅ (၂၀၂၁ သောကြာနေ့၊ 21ပြီ ၉ ရက်၊ ညနေ ၆ း ၀၀)

__ ဂူဂဲလ်ဆန့်ကျင်ရေးလှုပ်ရှားမှုအားမကြာမီကမှကျွန်ုပ်မှအသစ်ပြောင်းခြင်းများမရှိခဲ့ပါ။ ၁ လကြာစစ်ဆင်ရေးပြီးနောက်၎င်းကိုပြန်လည်ရယူရန်ကျွန်ုပ်ကြိုးစားနေသည်။

> အပြောင်းအလဲများ -

> * ခေါင်းစဉ်အပိုင်း updated

> * အညွှန်းကိန်း updated

> * ဘာသာစကားစာရင်းကိုအဆင့်မြှင့်ခြင်း - ပုံသေလင့်ခ်များနှင့်ပိုမိုထောက်ခံသည့်ဘာသာစကားများကိုထည့်သွင်းခဲ့သည်

> * ဆောင်းပါးအခြေအနေအပိုင်းကိုအဆင့်မြှင့်တင်ပြီး fork လင့်ခ် ၄ ခုထည့်သွင်းခဲ့သည်

> * ဆော့ဖ်ဝဲအဆင့်အတန်းကိုအဆင့်မြှင့်တင်

> * Go သည်မကောင်းသောအပိုင်းဖြစ်သည်

> * DRM အပိုင်း၏အသုံးပြုမှုကိုထည့်သွင်းခဲ့သည်

> * အဖြစ်များသည့်အယူအဆမှားများကိုထည့်သွင်းခဲ့သည်

>> * ဂူဂဲလ်သည်အင်တာနက်ပုဒ်မခွဲမဟုတ်ပါကိုထည့်သွင်းခဲ့သည်

> * Internet Explorer 6 နှင့် Chrome အပိုင်းကိုထည့်သွင်းခဲ့သည်

>> * ပြTheနာကို Brave ပုဒ်မခွဲဖြင့်ထပ်ထည့်ခဲ့သည်

> * Faux privacy ဖယ်ရှားမှုကိုထည့်သွင်းခဲ့သည်

> * Open Source သည်တစ်စိတ်တစ်ပိုင်းပုဒ်မခွဲတစ်ခုမဖြစ်နိုင်ပါ

> * Oxymoron ပုဒ်မခွဲကိုထပ်ထည့်ခဲ့သည်

> * မကောင်းတဲ့စွမ်းဆောင်ရည်အပိုင်းကဆက်ပြောသည်

> * မကောင်းတဲ့စီမံကိန်းစီမံခန့်ခွဲမှုအပိုင်းကိုထည့်သွင်းခဲ့သည်

> * စက်ဆုပ်ရွံရှာဖွယ်ကောင်းသော ၀ န်ဆောင်မှုများကဏ္ no ကိုမထည့်သွင်းထားပါ

> * Astroturfing အပိုင်းကိုထပ်မံထည့်သွင်းခဲ့သည်

> * တရားမ ၀ င်နှင့်ကျင့် ၀ တ်တရားမ ၀ င်သည့်စီးပွားရေးလုပ်ထုံးလုပ်နည်းများကိုထည့်သွင်းခဲ့သည်

> * ဥရောပ၌ပုဒ်မခွဲထပ်ထည့်သည်

>> * မြောက်အမေရိကတွင်ပုဒ်မခွဲထပ်ထည့်သည်

>> * အငြင်းပွားဖွယ်ရာပုဒ်မများထပ်ထည့်ခဲ့သည်

> * ဂူဂဲလ်သည်အလိုအလျောက်ပြုလုပ်ထားသောအပိုင်းဖြစ်သည်

> * Android အပိုင်းကိုထည့်သွင်းခဲ့သည်

> * အကူအညီကဏ္toတွင်အသေးစားလုပ်ဆောင်မှုများထည့်သွင်းထားသည်

> * ယုံကြည်စိတ်ချရသောအပိုင်းထည့်သွင်းခဲ့သည်

> * စပွန်ဆာအချက်အလက်ကဏ္ Added ကိုထည့်သွင်းခဲ့သည်

> * အောက်ခြေရှိအဆင့်မြှင့်တင်ထားသည်

> * ဖိုင်အချက်အလက်များအပိုင်းကိုအဆင့်မြှင့်တင်ထားသည်

> * ဖိုင်သမိုင်းကြောင်းအပိုင်းကိုအသစ်ပြောင်းခဲ့သည်

> * ဗားရှင်း ၅ တွင်အခြားပြောင်းလဲမှုမရှိပါ

ဗားရှင်း ၆ (၂၀၂၁ ခုနှစ်၊ တနင်္ဂနွေနေ့၊ ညနေ ၄ း ၂၉)

> အပြောင်းအလဲများ -

> * အညွှန်းကိန်း updated

> * အသစ်တစ်ခုကိုခြုံငုံဖော်ပြချက်ထည့်သွင်းခဲ့သည်

> * ပြင်ဆင်ထားသောဆောင်းပါးအခြေအနေအချက်အလက်

> * Google FLoC ဆောင်းပါးအသစ်သို့ link တစ်ခုထပ်ထည့်ခဲ့သည်

> * Wuest 3n Fuchs Degoogle ဆောင်းပါးနှင့်၎င်းရဲ့အထွေထွေအချက်အလက်တို့မှာ link တစ်ခုထည့်ခဲ့သည်

> * ဖိုင်အချက်အလက်များအပိုင်းကိုအဆင့်မြှင့်တင်ထားသည်

> * ဖိုင်သမိုင်းကြောင်းအပိုင်းကိုအသစ်ပြောင်းခဲ့သည်

> * ဗားရှင်း ၆ တွင်အခြားပြောင်းလဲမှုမရှိပါ

ဗားရှင်း ၇ (မကြာမီလာမည်)

> အပြောင်းအလဲများ -

မကြာမီလာမည်

> * ဗားရှင်း ၇ တွင်အခြားပြောင်းလဲမှုမရှိပါ

ဗားရှင်း ၈ (မကြာမီလာမည်)

> အပြောင်းအလဲများ -

မကြာမီလာမည်

> * ဗားရှင်း ၈ တွင်အခြားပြောင်းလဲမှုမရှိပါ

ဗားရှင်း ၉ (မကြာမီလာမည်)

> အပြောင်းအလဲများ -

မကြာမီလာမည်

> * ဗားရှင်း ၉ တွင်အခြားပြောင်းလဲမှုမရှိပါ

ဗားရှင်း ၁၀ (မကြာမီလာမည်)

> အပြောင်းအလဲများ -

မကြာမီလာမည်

> * ဗားရှင်း ၁၀ တွင်အခြားပြောင်းလဲမှုမရှိပါ

ဗားရှင်း 11 (မကြာမီလာမည်)

> အပြောင်းအလဲများ -

မကြာမီလာမည်

> * ဗားရှင်း ၁၁ တွင်အခြားအပြောင်းအလဲမရှိပါ

ဗားရှင်း ၁၂ (မကြာမီလာမည်)

> အပြောင်းအလဲများ -

မကြာမီလာမည်

> * ဗားရှင်း ၁၂ တွင်အခြားပြောင်းလဲမှုမရှိပါ

***

## အောက်ခြေ

မင်းမှာ r ရှိတယ်ဤဖိုင်၏အဆုံးရောက်ပြီ

([အပေါ်သို့ပြန်သွားပါ] (# ထိပ်) | [GitHub သို့ပြန်သွားပါ] (https://github.com)

### EOF

***
