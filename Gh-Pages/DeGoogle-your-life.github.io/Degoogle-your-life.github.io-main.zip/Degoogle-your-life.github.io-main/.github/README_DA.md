***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle dit liv

Dette er den vigtigste degoogling-artikel for generel information om degoogling og et link til de andre artikler.

[Se listen som en GitHub-organisation] (https://github.com/Degoogle-your-life)

***

_Læs denne artikel på et andet sprog: _

** Aktuelt sprog er: ** `Engelsk (USA)` _ (oversættelser skal muligvis rettes for at ordne engelsk, der erstatter det korrekte sprog) _

_🌐 Liste over sprog_

** Sorteret efter: ** `A-Z`

[Sorteringsmuligheder ikke tilgængelige] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albansk | [am አማርኛ] (/. github / README_AM.md) Amharisk | [ar عربى] (/.github/README_AR.md) Arabisk | [hy հայերեն] (/. github / README_HY.md) Armensk | [az Azərbaycan dili] (/. github / README_AZ.md) Aserbajdsjansk | [eu Euskara] (/. github /README_EU.md) Baskisk | [være Беларуская] (/. Github / README_BE.md) Hviderussisk | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnisk | [bg български] (/. Github / README_BG.md) Bulgarsk | [ca Català] (/. Github / README_CA.md) Catalansk | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Kinesisk (forenklet) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Kinesisk (traditionel) | [co Corsu] (/. Github / README_CO.md) Korsikansk | [hr Hrvatski] (/. Github / README_HR.md) Kroatisk | [cs čeština] (/. Github / README_CS .md) Tjekkisk | [da dansk] (README_DA.md) Dansk | [nl Nederlands] (/. github / README_ NL.md) Hollandsk | [** en-us engelsk **] (/. github / README.md) Engelsk | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estisk | [tl Pilipino] (/. github / README_TL.md) Filippinsk | [fi Suomalainen] (/. github / README_FI.md) Finsk | [fr français] (/. github / README_FR.md) Fransk | [fy Frysk] (/. github / README_FY.md) Frisisk | [gl Galego] (/. github / README_GL.md) Galicisk | [ka ქართველი] (/. github / README_KA) Georgisk | [de Deutsch] (/. github / README_DE.md) Tysk | [el Ελληνικά] (/. github / README_EL.md) Græsk | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitisk kreolsk | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiiansk | [he עִברִית] (/. github / README_HE.md) Hebraisk | [hej हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ungarsk | [er Íslenska] (/. github / README_IS.md) Islandsk | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandsk | [ga Gaeilge] (/. github / README_GA.md) Irsk | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japansk | [jw Wong jawa] (/. github / README_JW.md) Javanesisk | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kasakhisk | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-syd 韓國 語] (/. github / README_KO_SOUTH.md) Koreansk (Syd) | [ko-nord 문화어] (README_KO_NORTH.md) Koreansk (Nord) (IKKE OVERSAT) | [ku Kurdî] (/. github / README_KU.md) Kurdisk (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgisisk | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Litauisk | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxembourgsk | [mk Македонски] (/. github / README_MK.md) Makedonsk | [mg madagaskisk] (/. github / README_MG.md) madagaskisk | [ms Bahasa Melayu] (/. github / README_MS.md) Malaysisk | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltesisk | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolsk | [min မြန်မာ] (/. github / README_MY.md) Myanmar (burmesisk) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) Norsk | [eller ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persisk [pl polski] (/. github / README_PL.md) Polsk | [pt português] (/. github / README_PT.md) Portugisisk | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Ingen tilgængelige sprog, der starter med bogstavet Q | [ro Română] (/. github / README_RO.md) Rumænsk | [ru русский] (/. github / README_RU.md) Russisk | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Skotsk gælisk | [sr Српски] (/. github / README_SR.md) Serbisk | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovakisk | [sl Slovenščina] (/. github / README_SL.md) Slovensk | [så Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spansk | [su Sundanis] (/. github / README_SU.md) Sundanesisk | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Svensk | [tg Тоҷикӣ] (/. github / README_TG.md) Tadsjikisk | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatarisk | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Tyrkisk | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukrainsk | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Usbekisk | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamesisk | [cy Cymraeg] (/. github / README_CY.md) Walisisk | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jiddisk | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Fås på 110 sprog (108 når man ikke tæller engelsk og nordkoreansk, da nordkoreansk endnu ikke er oversat [Læs om det her] (/ OldVersions / koreansk (nord ) /README.md))

Oversættelser på andre sprog end engelsk er maskinoversat og er endnu ikke korrekte. Ingen fejl er rettet endnu den 5. februar 2021. Rapporter venligst oversættelsesfejl [her] (https://github.com/seanpm2001/Degoogle-your-life/issues/) Sørg for at tage backup af din rettelse med kilder og guide mig , da jeg ikke kender andre sprog end engelsk godt (jeg planlægger at få en oversætter til sidst) skal du citere [wiktionary] (https://en.wiktionary.org) og andre kilder i din rapport. Hvis du ikke gør det, vil en afvisning af rettelsen blive offentliggjort.

Bemærk: på grund af begrænsninger med GitHubs fortolkning af markdown (og stort set alle andre webbaserede fortolkninger af markdown), klikker disse links dig til en separat fil på en separat side, der ikke er min GitHub-profilside. Du vil blive omdirigeret til [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), hvor README er hostet.

Oversættelser foretages med Google Translate på grund af begrænset eller ingen support til de sprog, jeg har brug for i andre oversættelsestjenester som DeepL og Bing Translate (ret ironisk for en anti-Google-kampagne) Jeg arbejder på at finde et alternativ. Af en eller anden grund er formateringen (links, skillevægge, fed skrift, kursiv osv.) Rodet i forskellige oversættelser. Det er kedeligt at rette, og jeg ved ikke, hvordan jeg løser disse problemer på sprog med ikke-latinske tegn, og højre til venstre sprog (som arabisk) er der brug for ekstra hjælp til at løse disse problemer

På grund af vedligeholdelsesproblemer er mange oversættelser forældede og bruger en forældet version af denne `README`-artikelfil. En oversætter er nødvendig. Fra den 9. april 2021 vil det også tage mig et stykke tid at få alle de nye links til at fungere.

***

## Indeks

[00.0 - Titel] (# Degoogling --- Degoogle-dit-liv)

> [00.1 - Indeks] (# Indeks)

[01.0 - Grundlæggende beskrivelse] (# Grundlæggende beskrivelse)

> [01.1 - Repository header] (# Degoogle-your-life)

> [01.2 - Wuest3NFuchs beskrivelse oversigt] (# Oversigt-af-Wuest3nFuchs)

>> [01.2.1 - Hvad betyder det?] (# Hvad-betyder-det-betyder - af-Wuest3nFuchs)

>> [01.2.2 - Hvorfor Degoogle?] (# Hvorfor-Degoogle - af-Wuest3nFuchs)

[02.0 - Artikler] (# artikler)

[03.0 - Privacy] (# Privacy)

[04.0 - Andre anti-Google-kampagner] (# Andre-anti-Google-kampagner)

> [04.0.1 - Defunct] (# Defunct)

> [04.0.2 - Igangværende] (# Igangværende)

[05.0 - Modvirkning af andre argumenter] (# Mod-andre-argumenter)

> [05.0.1 - Bekvemmelighed] (# Bekvemmelighed)

> [05.0.2 - Hvorfor betyder det noget? Det er alligevel for sent] (# Hvorfor-betyder det-betyder-det er for sent-alligevel)

> [05.0.3 - Andet] (# Andet)

[06.0 - Kilder] (# kilder)

[07.0 - Download links] (# Download-links)

[08.0 - Min digoogling-oplevelse] (# My-degoogling-experience)

> [08.1 - Hvad jeg skiftede fra] (# Hvad-jeg-skiftede fra)

> [08.2 - Produkter, jeg stadig ikke kan komme væk fra] (# Produkter-jeg-stadig-ikke-kan-komme-væk-fra)

[09.0 - Andre ting at tjekke ud] (# Andre-ting-at-tjekke ud)

[10.0 - File info] (# File-info)

> [10.1 - Software status] (# Software-status)

> [10.2 - Info om sponsor] (# Sponsor-info)

[11.0 - Filhistorik] (# Filhistorik)

[12.0 - Sidefod] (# sidefod)

***

## Grundlæggende beskrivelse

[Fra Wikipedia: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

DeGoogle-bevægelsen (også kaldet de-Google-bevægelsen) er en græsrodskampagne, der er skabt, da privatlivsaktivister opfordrer brugerne til helt at stoppe med at bruge Google-produkter på grund af voksende privatlivets bekymringer vedrørende virksomheden. Udtrykket henviser til handlingen med at fjerne Google fra ens liv. Da den voksende markedsandel for internetgiganten skaber monopolmagt for virksomheden i digitale rum, har et stigende antal journalister bemærket vanskelighederne med at finde alternativer til virksomhedens produkter.

**Historie**

I 2013 sagde John Koetsier fra Venturebeat, at Amazons Kindle Fire Android-baserede tablet var "en de-Google-iseret version af Android." I 2014 skrev John Simpson fra US News om “retten til at blive glemt” af Google og andre søgemaskiner. I 2015 skrev Derek Scally of Irish Times en artikel om, hvordan man "De-Google dit liv." I 2016 Kris Carlon fra Android Myndighed foreslog, at brugere af CyanogenMod 14 kunne “de-Google” deres telefoner, fordi CyanogenMod også fungerer fint uden Google-apps. I 2018 skrev Nick Lucchesi fra Inverse om, hvordan ProtonMail promoverede, hvordan man "kunne de-Google-fyre sit liv fuldstændigt." Lifehacker's Brendan Hesse skrev en detaljeret tutorial om "at afslutte Google." Gizmodo-journalisten Kashmir Hill hævder, at hun savnede møder og havde svært ved at organisere møder uden brug af Google Kalender. I 2019 gav Huawei en refusion til telefonejere i Filippinerne, der var forhindret i at bruge tjenester leveret af Google, fordi der findes så få alternativer, at fraværet af virksomhedens produkter gjorde normal internetbrug umulig.

***

# Degoogle-dit-liv
Et arkiv med generel information om degoogling og links til mine andre degoogling-arkiver.

***

## Oversigt af Wuest3nFuchs

En bedre beskrivelse leveret af [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - kilde: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Hvad betyder det? af Wuest3nFuchs

Degoogling betyder at stoppe med at bruge alt, hvad der hører til Google, alt, hvad der er lavet af Google. Jeg taler om deres søgemaskine, deres mailservice (Gmail), Youtube osv.

### Hvorfor Degoogle? af Wuest3nFuchs

Google er en af ​​de mest magtfulde virksomheder i verden lige nu. De har gemt en enorm mængde information om os alle. Nogle vil hævde, at vores oplysninger er sikre hos dem, fordi de ved, hvordan de skal beskyttes. Men dette er ikke sandt. Google er gennemtrængt før, og det vil blive gennemtrængt i fremtiden. Måske ikke af en scriptkiddie, men det bliver gjort af en nationalstat. Google gemmer personlige oplysninger om os alle, fordi det er sådan, de tjener penge.

De scanner vores e-mails, gemmer hvad vi søger, når vi bruger deres søgemaskine, hvilke videoer vi ser på Youtube. Dette er, hvordan de målretter mod os og bygger en profil på os for at vise os nogle annoncer baseret på det, vi talte om med vores bedste ven, så de kan vise os en annonce for noget, vi har brug for, men det er for uhyggeligt. Tak til Mr. Snowden ved vi nu, at Google har delt vores personlige oplysninger med NSA under et program kaldet ** "PRISM" **.


I fremtiden vil nogen være i stand til at få adgang til alle disse oplysninger, og jeg forsikrer dig om, at der virkelig vil ske noget dårligt. For at forhindre, at dette sker, skal du starte Degoogling lige nu. Du bør heller ikke bruge produkter fra et firma, der deler dine data med ** NSA **. Du bør sætte en stopper for alt dette ved at degoogling.

** Hvis andre mennesker kan gøre det, kan du også gøre det. **

[Læs mere her] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Et link til gaffelen er i øjeblikket ikke på listen, da jeg ikke ejer dette lager fuldstændigt og vil promovere andre kilder. Det ville være egoistisk at linke til min egen https://github.com/Degoogle-your-life/Degoogle! ->

***

## Artikler

### Artikelstatus

_Alle artikler er i øjeblikket et igangværende arbejde og har brug for massive forbedringer. Forslag og rettelser er tilladt.

_Fra den 18. april 2021 kl. 16.09 er de fleste artikler endnu ikke startet. Jeg arbejder på at finde tid og kræfter til at starte dem._

[Hvorfor skal du stoppe med at bruge Google Chrome] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Stop med at bruge ChromeBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Stop med at bruge WideVine DRM / Det er tid til at skære WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Hvorfor skal du stoppe med at bruge ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Skifter fra YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Stop Googling, hvorfor skal du stoppe med at bruge Google Søgning] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[Hvorfor skal du stoppe med at bruge Gmail] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Hvorfor skal du stoppe med at bruge Android] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Hvorfor skal du undgå Google Amp] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Hvorfor skal du stoppe med at bruge Google Drive] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Hvorfor skal du stoppe med at bruge Google Maps og Google Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Hej Google, stop] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Stop læsning fra Google / Play bøger] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Stop med at bruge Google Classroom] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Hvorfor skal du stoppe med at bruge Google Translate] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Hvorfor skal du stoppe med at bruge din (e) Google-konto] (https://github.com/seanpm2001/Why-you-should-stop-bruger-Google-konti) <! - 16! ->

** Nye artikler, der snart skal skrives: **

[Hvorfor skal du stoppe med at bruge Gerrit] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Hvorfor skal du stoppe med at bruge Google Analytics (lageret er brudt i min ende fra onsdag den 24. februar 2021 kl. 16:13)] (https://github.com/seanpm2001/Hvorfor-du-skal-stoppe -Google-Analytics) <! - 18! ->

<! - Arbejdsdeler! ->

[Hvorfor skal du stoppe med at bruge Google AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Hvorfor skal du stoppe med at bruge Google One] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Hvorfor skal du stoppe med at bruge Google+ (defunct)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Hvorfor skal du stoppe med at bruge Google Play Butik] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Hvorfor skal du stoppe med at bruge Google Docs] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Hvorfor skal du stoppe med at bruge Google Slides] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Hvorfor skal du stoppe med at bruge Google Sheets] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Hvorfor skal du stoppe med at bruge Google Forms] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Hvorfor skal du stoppe med at bruge Google Cardboard] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Hvorfor skal du stoppe med at bruge Google Messages] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Hvorfor skal du stoppe med at bruge Google Material Design] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Hvorfor skal du stoppe med at bruge Google Glass / Glasses] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Hvorfor skal du stoppe med at bruge Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Hvorfor skal du stoppe med at bruge GBoard] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Hvorfor skal du stoppe med at bruge Google Home] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Hvorfor skal du stoppe med at bruge Google Nest] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Hvorfor skal du stoppe med at bruge Google Hangouts (defunct)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Hvorfor skal du stoppe med at bruge Google Duo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Hvorfor skal du stoppe med at bruge Google Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Hvorfor skal du stoppe med at bruge Google Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Hvorfor skal du stoppe med at bruge Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Hvorfor skal du stoppe med at bruge Googles Go programmeringssprog] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Hvorfor skal du stoppe med at bruge Googles Dart programmeringssprog] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Hvorfor skal du stoppe med at bruge Googles WebP-billedformat] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Hvorfor skal du stoppe med at bruge Googles WebM-videoformat] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Hvorfor skal du stoppe med at bruge Google Video] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Hvorfor skal du stoppe med at bruge Google Sites (klassisk)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Hvorfor skal du stoppe med at bruge Google Sites ("Ny")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Hvorfor skal du stoppe med at bruge Google Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Hvorfor skal du stoppe med at bruge Android Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Hvorfor skal du stoppe med at bruge Google VPN (oxymoron)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Hvorfor skal du stoppe med at bruge Google Fotos] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[Hvorfor skal du stoppe med at bruge Google Kalender] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Hvorfor skal du stoppe med at bruge VirusTotal (da det har været ejet af Google siden september 2012) (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Hvorfor skal du stoppe med at bruge Google Fi] (https://github.com/seanpm2001/Why-you-should-stop-brug-Google-Fi) <! - 53! ->

[Hvorfor skal du stoppe med at bruge Google Stadia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Hvorfor skal du stoppe med at bruge Google Keep] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Hvorfor skal du stoppe med at bruge Google Base] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Hvorfor skal du stoppe med at deltage i Google Summer of Code] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Hvorfor skal du stoppe med at bruge Google Camera] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Hvorfor skal du stoppe med at bruge Google Lommeregner (kan virke ekstrem, men du skal degoogle fra alt, ekstremt let at skifte fra)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Lommeregner) <! - 59! ->

[Hvorfor skal du stoppe med at bruge Google Survey + -belønninger] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Hvorfor skal du stoppe med at bruge Google Drawings] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Hvorfor skal du stoppe med at bruge Tenor (GIF-websted, ejet af Google siden 2019)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Hvad FLoC - Hvorfor skal du undgå Googles store FLoCing-problem (stop med at bruge Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Artikler i alt: ** `63`

** Artikel [køreplan AB] (DegoogleCampaign_2021Roadmap_Part1.md) (op til 12. marts 2021) 2 fridage **

** Artikel [køreplan BB] (DegoogleCampaign_2021Roadmao_Part2.md) (op til? 2021) 2 dage fri **

Artikelstatus

Alle artikler er i øjeblikket et igangværende arbejde og har brug for massive forbedringer. Forslag og rettelser er tilladt.

** gafler **

Udvidelse af mit Degoogle-netværk og tilføjelse af let adgang og community shoutouts.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Gaffelt fra: [https://github.com/wacko1805/Fossapps ](https://github.com/wacko1805/Fossapps) (Engelsk)

2. [Privacy-links] (https://github.com/Degoogle-your-life/Privacy-links) | Gaffelt fra: [https://github.com/Arturro43/privacy-links ](https://github.com/Arturro43/privacy-links) (polsk)

3. [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Forked fra: [https://github.com/LinuxCafeFederation/Delightful-Privacy ](https://github.com/LinuxCafeFederation/Delightful-Privacy) (engelsk)

4. [Blokeringslister] (https://github.com/Degoogle-your-life/blocklists) | Gaffelt fra: [https://github.com/jmdugan/blocklists ](https://github.com/jmdugan/blocklists) (Engelsk)

5. [Degoogle, af Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Gaffelt fra: [https://github.com/Wuest3nFuchs/Degoogle ](https://github.com/Wuest3nFuchs/Degoogle) (engelsk)

**Relaterede**

[Undersøgelse af Android-telefon Virtual Machine-research] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Se også:**

[Kritik af Google på Wikipedia] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[Google Graveyard (killedbygoogle.com) - en sorteret liste over de 224+ produkter, Google har dræbt] (https://killedbygoogle.com/)

> [GitHub-link] (https://github.com/codyogden/killedbygoogle)

[Arbejderforening i alfabetet - Den nye arbejderforening hos Google med over 800 medlemmer] (https://alphabetworkersunion.org/people/our-union/)

[Vil du ikke dele med dinosaurus påskeæg? Denne webside har du dækket] (https://chromedino.com/)

***

## Privatliv

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (overvågningsprogram)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) [s ](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / hvorfor-googles-spionere-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument # Kritik) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -være eksempler / intet-at-skjule-argument-har-intet-at-sige /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- af-data-om-dig-du-kan-finde-og-slette-det-nu /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -dine-personlige-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -moniserer-og) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- samling afsløret.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ health-fitness-data-privacy /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-indsamling-på-uddannelse-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-government-google-data-collection-retssag-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html) [o ](https://en.wikipedia.org/wiki/2018_Google_data_breach) [m ](https://moz.com /blog/where-does-google-draw-the-data-collection-line) [e ](https://mashable.com/article/google-android-data-collection-study/) [s ](https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html) [o ](https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -krav-på-vegne af 5-m illion-iphone-brugere) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r ](https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/) [i ](https://www.cbsnews.com/news/google-education-spies-on-collects- data-om-millioner-af-børn-påstår-retssag-new-mexico-attorney-general /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -under vores næse /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / teknologi / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : //medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Jeg kunne fortsætte med at bevise dette, men det tog lang tid at finde og gennemgå alle disse artikler)

Privatlivets fred for Google-produkter er altid dårligt på grund af alle Google-produkter, der indeholder spyware.

Uanset hvad du laver, når du bruger Google, sendes alle dine følsomme personlige data til Google og andre. Google er også blevet set gennem åbne programmer. For eksempel fra personlig erfaring (på Firefox) med en YouTube-fane åben, som jeg ikke besøgte, så jeg adskillige videoer offline (VLC Media Player) Senere, da jeg gik for at kontrollere anbefalingerne, var det næsten alt, hvad jeg havde set. Der er ingen tvivl om, at de også spionerer på andre programmer.

I Chrome (og mange andre browsere) er der en inkognitotilstand. I Chrome er denne tilstand meningsløs, da Google stadig mine data. Selvom du deaktiverer data mining / tracking og aktiverer "følg ikke" signalet, overraskende overraskelse, er Google stadig minedrift af dine data.

Hvis du tror, ​​du ikke har noget at skjule, ** har du absolut forkert **. Dette argument er blevet debunkeret mange gange:

[Via Wikipedia] (https://en.wikipedia.org/wiki/Intet_til_hide_argument#Kritik)

1. Edward Snowden bemærkede "At argumentere for, at du ikke er ligeglad med retten til privatliv, fordi du ikke har noget at skjule, er ikke anderledes end at sige, at du ikke er ligeglad med ytringsfriheden, fordi du ikke har noget at sige." Når du siger, ' Jeg har ikke noget at skjule, 'siger du,' jeg er ligeglad med denne ret. 'Du siger,' jeg har ikke denne ret, for jeg er nået til det punkt, hvor jeg skal retfærdiggøre det. 'Sådan som rettigheder fungerer, er regeringen nødt til at retfærdiggøre sin indtrængen i dine rettigheder. "

2. Daniel J. Solove erklærede i en artikel for The Chronicle of Higher Education, at han er imod argumentet; han erklærede, at en regering kan slippek information om en person og forårsage skade på den pågældende person, eller bruge oplysninger om en person til at nægte adgang til tjenester, selvom en person ikke faktisk har begået uretfærdighed, og at en regering kan forårsage skade på ens personlige liv ved at lave fejl. Solove skrev "Når intet-til-skjul-argumentet er engageret direkte, kan det blive fængslet, for det tvinger debatten til at fokusere på dens snævre forståelse af privatlivets fred. Men når den konfronteres med de mange privatlivsproblemer, der er impliceret af regeringsdataindsamling og -brug ud over overvågning og afsløring, argumentet intet at skjule, har i sidste ende intet at sige. "

3. Adam D. Moore, forfatter af Privacy Rights: Moral and Legal Foundations, hævdede, "det er den opfattelse, at rettigheder er modstandsdygtige over for omkostninger / fordele eller konsekventistiske argumenter. Her afviser vi synspunktet om, at privatlivets interesser er de slags af ting, der kan handles for sikkerhed. " Han sagde også, at overvågning uforholdsmæssigt kan påvirke visse grupper i samfundet baseret på udseende, etnicitet, seksualitet og religion.

4. Bruce Schneier, en computersikkerhedsekspert og kryptograf, udtrykte modstand og citerede kardinal Richelieus erklæring "Hvis man ville give mig seks linjer skrevet af den ærligste mand, ville jeg finde noget i dem for at få ham hængt op", med henvisning til hvordan en statsregering kan finde aspekter i en persons liv for at retsforfølge eller afpresse vedkommende. Schneier argumenterede også for "for mange karakteriserer fejlagtigt debatten som 'sikkerhed versus privatliv.' Det virkelige valg er frihed kontra kontrol. "

5. Harvey A. Silverglate vurderede, at den almindelige person i gennemsnit uforvarende begår tre forbrydelser om dagen i USA.

6. Emilio Mordini, filosof og psykoanalytiker, argumenterede for, at argumentet om "intet at skjule" er i sagens natur paradoksalt. Folk behøver ikke at have "noget at skjule" for at skjule "noget". Det skjulte er ikke nødvendigvis relevant, hævder Mordini. I stedet argumenterer han for, at et intimt område, der både kan skjules, og adgangsbegrænset er nødvendigt, da vi psykologisk set bliver enkeltpersoner gennem opdagelsen af, at vi kunne skjule noget for andre.

7. Julian Assange sagde "Der er endnu ikke noget dræbende svar. Jacob Appelbaum (@ioerror) har et klogt svar og beder folk, der siger dette, om derefter at give ham deres telefon ulåst og trække deres bukser ned. Min version af det vil sige, 'Nå, hvis du er så kedelig, så skal vi ikke tale med dig, og heller ikke nogen anden', men filosofisk er det virkelige svar dette: Masseovervågning er en strukturel strukturændring. Når samfundet går dårligt, går det at tage dig med det, selvom du er den kedeligste person på jorden. "

8. Ignacio Cofone, professor i jura, argumenterer for, at argumentet forveksles med sine egne udtryk, fordi når folk videregiver relevant information til andre, afslører de også irrelevante oplysninger. Disse irrelevante oplysninger har privatlivets omkostninger og kan føre til andre skader, såsom diskrimination.

***

## Andre anti-Google-kampagner

Dette er en liste over andre bemærkelsesværdige anti-Google-kampagner. Denne liste er ufuldstændig. Du kan hjælpe ved at udvide den.

### Defunct

[Scroogled - Af Microsoft (november 2012 til 2014)] (https://en.wikipedia.org/wiki/Scroogled)

_Ingen andre poster i øjeblikket._

### Igangværende

_Denne liste er i øjeblikket tom.

***

## Modvirker andre argumenter

Der er nogle argumenter, som folk fremsætter for at retfærdiggøre Google. En af de første store er allerede debunked [her] (# Privacy), men her er nogle andre:

### Bekvemmelighed

Ja, Google-produkter virker bekvemme. Du handler dog alt godt for nemheds skyld, inklusive sikkerhed, privatliv og pålidelighed. Google er blevet mere doven i årenes løb, og deres servere er gået mere og mere ned. Lige nu går Google-serverne ned i næsten en time 1-2 gange om måneden (især YouTube)

Desværre er Google på grund af samfunds afhængighed af Google kommet til at dominere Internettet og søger at kontrollere mere og mere. I 2012, da Google gik ned i 5 minutter, blev det rapporteret, at ** global ** internettrafik ** faldt med 40% ** Google går ofte ned i 1-2 timer, og med [fyring af deres etiske team] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) vil de blandt andet blive mindre og mindre bekvemme.

Bekvemmelighed er ikke altid en god ting. Du skal være opmærksom på, hvad der foregår og være forberedt på, når de går ned, da der ikke er en måde at få en server til ikke at gå ned en gang imellem.

Google er heller ikke så praktisk som du tror. Der er andre meget mere bekvemme steder. Google er langt fra praktisk, når du redegør for deres tilfældige kontosuspensioner og opsigelser uden svar (medmindre du gør nok opmærksom på Google twitter-kontoen eller sagsøger dem for $ 100.000.000 eller mere), så har de udnyttet dig, skruet dig over og tvang dig til at skrige ind i en pude, hvor ingen kunne høre dine skrigfor hjælp.

### Hvorfor betyder det noget, det er alligevel for sent

Dette er et mindre almindeligt argument, men det skal forklares. Med den nuværende tilstand ser de fleste verdensregeringer sammen med flere magtfulde virksomheder ud til at kende enhver bevægelse, så hvorfor overhovedet gider at komme væk fra det? Svaret er simpelt: ** du fortjener bedre **. Hvis det lykkes dig at komme væk fra dem på dette tidspunkt, er det sværere for dem at spore dine bevægelser yderligere, og du kan opbygge et nyt mere privatliv.

[1 kilde] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Forresten har jeg givet min gratis Reddit-pris til dette indlæg hver gang jeg får det i over en uge nu (sammen med alle 500 af mine gratis mønter) for at øge dette emne yderligere. Indtil videre har jeg givet dette indlæg over 14 gratis priser. Det er ikke meget, men små ting kan få stor indflydelse, afhængigt af hvordan det opfattes, og af hvem.

### Andet

Jeg har ikke andre argumenter i øjeblikket.

_Denne liste er ufuldstændig_

***

## Kilder

Kopi:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (overvågningsprogram)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) [s ](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / hvorfor-googles-spionere-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritik) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -prøver / intet-at-skjule-argument-har-intet-at-sige /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-om-dig-du-kan-finde-og-slette-det-nu /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -og) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html) [d ](https://www.reuters.com/article/us-alphabet- google-privatliv-retssag-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-indsamling-på-uddannelse-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html) [o ](https://en.wikipedia.org/wiki/2018_Google_data_breach) [m ](https:// moz.com/bl og / hvor-gør-google-tegner-data-indsamlingslinjen) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- hævder på vegne af 5 millioner iphone-brugere) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) [e ](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -telefon-er ikke i brug /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technology / 2014/01 / hvad-google-kan-virkelig-gøre-med-rede-eller-virkelig-rede-data /) [i] (https://www.cbsnews.com/news/google-education -spioner-på-indsamler-data-på-millioner-af-børn-påstande-retssag-ny-mexico-advokat-general /) [v] (https://www.nationalreview.com/2018/04/the- student-data-mining-skandale-under-vores-næser /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) [y ](https://medium.com/@hansdezwart/during-world-war-ii-we-did -har-noget-at-skjule-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Andre kilder:

[Five eyes Alliance] (https://en.wikipedia.org/wiki/Five_Eyes) [Nineteen eighty four] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Download links

[Hent Firefox] (https://www.mozilla.org/da-DK/firefox/new/) [Hent Tor-browser] (https://www.torproject.org/download/) [Andet / utilgængeligt] (https : //www.example.com)

***

## Min digoogling-oplevelse

Jeg begyndte endelig at se problemerne med big tech i 2018, og jeg begyndte at kigge. I de første par måneder gjorde jeg betydelige fremskridt. Det sænkede enormt siden da.


### Hvad jeg skiftede fra

Google Chrome -> Firefox / Tor

Google-søgning -> DuckDuckGo (standard) / Ecosia (når jeg har lyst til det) / Bing (sjældent)

GMail - ProtonMail (endnu ikke fuldt udskiftet)

Google Sites -> Selvhosting (endnu ikke fuldt udskiftet)

Google+ -> Næppe nogensinde brugt, slettet sig selv på grund af sin egen nedlukning

Google Docs -> Brugt aldrig, jeg bruger bare Microsoft Word 2013 (før 2019) og LibreOffice (2019-frem) i stedet.

Google Sheets -> Brugt aldrig, jeg bruger bare Microsoft Excel 2013 (før 2019) og LibreOffice (2019 og frem) i stedet.

Google Slides -> Brugt aldrig, jeg bruger bare Microsoft PowerPoint 2013 (før 2019) og LibreOffice (2019-frem) i stedet.

Google Tegninger -> Brugt aldrig, jeg bruger bare LibreOffice (2019 og fremefter) i stedet.

Gerrit -> Brugt aldrig, jeg bruger bare GitHub (nuværende standard), GitLab, BitBucket og SourceForge i stedet.

Google Fotos -> Brugt aldrig

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-nu)

Google Maps -> OpenStreetMaps / Apple Maps

Go - Gør en særlig undtagelse, men bruger ikke som et funktionelt programmeringssprog

Dart - Gør en særlig undtagelse, men bruger ikke som et funktionelt programmeringssprog

Flutter - Gør en særlig undtagelse, men bruger ikke som et funktionelt programmeringssprog

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> Aldrig brugt, jeg finder det ekstra uhyggeligt

Google Fi -> Brugt aldrig

Google Kalender -> Brugt aldrig

Google-lommeregner -> Bogstaveligt talt enhver anden lommeregner-app, endda en Linux-terminal, der kører i Python-tilstand, hvis jeg har lyst til det

Google Nest -> Brugt aldrig

Google AMP -> Brugt aldrig

Google VPN -> Brugt aldrig, også en oxymoron

Google Pay -> Brugt aldrig

Google Summer of Code -> Deltog aldrig

Tenor -> Andre GIF-sider, selvom GIF'er ikke er så vigtige for mig. Jeg får normalt GIF-filer fra DuckDuckGo-billeder, Imgur, Reddit eller andre websteder.

Blockly -> Ikke længere brugt, ikke sikker på, om Scratch kørte direkte blokeret. Jeg blev en funktionel programmør i 2017 og voksede ud af Scratch.

GBoard -> Brugt en gang, men forladt

Google Glass -> Brugt aldrig, betragtes som et lille barn, men besluttede ikke at få en / brug en, hvis jeg havde mulighed for det

_Listen kan være ufuldstændig.

### Produkter jeg stadig ikke kan komme væk fra

Fra og med den 25. februar 2021 er dette de Google-produkter, der forhindrer mig i at blive fuldstændig degoogling:

1. YouTube

2. Android

3. Google Play Butik

4. Gmail (kun for skole og nogle websteder)

5. Google Classroom (kun for skole)

6. Google Oversæt

7. Google-konto

8. Google Sites (da Google overtræder GDPR-lovgivningen (og kan blive udsat for en yderligere bøde på € 5.000.000,00, indtil de får det løst) og forbyder downloads af dette produkt)

Jeg har kigget væk fra alt andet.

***

## Go er ondt

Google steamrollede over 2003-agentbaseret programmeringssprog 'Go!' Med deres programmeringssprog 'Go' (fra 2009, 6 år senere) og hævdede, at deres sprog overhovedet ikke ville påvirke det andet sprog. Google blev kritiseret stærkt for dette, da deres motto `Vær ikke ond 'stadig var aktiv på det tidspunkt, og dette er en af ​​de mange hændelser, der fik den ikke vær onde Motto pensioneret.

I sidste ende ophørte udviklingen af ​​`Go!`, Mens `Go` blev mere og mere almindelig. Google hævdede, at de ikke ville vandre over 'Gå!', Men til sidst gjorde de det, og de slap væk med det (fra 9. april 2021)

[Læs mere om Go og hvordan man skifter her] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Brug af DRM

Google bruger DRM (Digital Restrictions Management) gennem deres WideVine DRM "service" og andre former. Målet med DRM er at ødelægge det åbne internet og give virksomheder monopol over brugerne. Du skal slippe af med WideVine helt, uanset omkostningerne.

[Læs mere om WideVine og dens problemer her] (https://github.com/Degoogle-your-life/Its-time-to-cut-WideVine-DRM)

***

## Almindelige misforståelser

Dette er en liste over nogle almindelige misforståelser med Google-produkter.

### Google er ikke Internettet

Google / Google-søgning er ikke Internettet, Google-søgning er bare en søgemaskine, sådan som ikke alle spil til en Nintendo-platform er lavet af Nintendo, men er licenseret af Nintendo, men i langt større grad. Hvis alle Googles-servere skulle destrueres samtidigt lige nu, ville kun Google Sites som YouTube, Gmail, Google Docs, Google-søgning osv. Være væk, men størstedelen af ​​Internettet ville stadig være der (Wikipedia, Stackoverflow, GitHub, alle Microsofts-websteder, NYTimes, Samsung, TikTok osv.) kan de miste deres Google-login- og analytiske funktionalitet, men de ville stadig være funktionelle (medmindre de var dårligt programmerede og stole direkte på Google)

***

## Internet Explorer 6 og Chrome

Google Chrome bliver den nye Internet Explorer 6. Da Google Chrome oprindeligt kom ud, var Firefox den dominerende browser og havde for det meste dræbt markedsandelen på Internet Explorers (som overgik 96%, før millioner af mennesker skiftede til Firefox og andre browsere), da Google Chrome kom ud, folk skiftede på grund af dets hastighed, og det var af Google (hvilket ikke blev betragtet som ondt på det tidspunkt, da de fleste privatlivsproblemer ikke var kommet frem endnu) Google Chrome respekterede oprindeligt webstandarder (hvilket Firefox gjorde som dræbte Internet Explorers 96% browsermarkedsandel) men da Google Chromes markedsandel steg, begyndte Google at fjerne flere og flere funktioner, tilføjede mere spyware og stoppede med at acceptere webstandarder, Google Chrome er blevet den nye Internet Explorer 6.

Det største problem lige nu er websteder, der kun er Chrome og ikke fungerer på andre browsere, da deres udviklere besluttede, at de ikke ville have de andre 30-40% af internetbrugere, der ikke bruger Chrome til at bruge deres websted.

Selv Google gør kun deres websteder Chrome. For eksempel vil Google-søgning bede dig om at downloade Chrome 3 gange hvert 10. sekund, hvis det registrerer, at du ikke bruger Google Chrome (selv andre Chromium-baserede browsere som Brave påvirkes), og websteder som Google Earth tillader ikke Firefox-brugere at brug deres websted (fra 2020) plus Google Translate understøtter ikke stemmeinput på Firefox og andre browsere, der ikke er fra Google.

### Problemet med Brave

Andre browsere, der er baseret på Chromium, såsom Brave og Microsoft Edge, er ikke helt fri for Google spyware. Brave anbefales almindeligvis af den forkerte side af privatlivssamfundet, men Brave er stadig et problem, da det bruger Chromium. Internettet bør ikke kun bestå af Chromium-browsere, der skal være forskellige valgmuligheder. Modig er den forkerte vej at gå.

[Læs mere om degoogling fra Google Chrome / Chrom her] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Læs mere om degoogling fra ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) her] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Faux fornyelse af privatlivets fred

Google har forsøgt at fortælle verden, at de holder af privatlivets fred, efter at det allerede var for sent. De hævder fortsat, at de respekterer brugernes privatliv, men de løser stadig ikke alle deres privatlivsproblemer.

### Open source kan ikke være delvis

Open source kan ikke være delvis. Google er bevis på dette. Hver bit og byte i kildekoden skal være synlig for offentligheden, med ikke engang en 8. byte skjult.

Projekter som Android og ChromeOS er delvist open source, men indeholder et flertal af proprietære spyware-elementer.

### Oxymoron

Google VPN er en oxymoron. Google er ligeglad med privatlivets fred, og et virtuelt privat netværk (VPN) fra en virksomhed som dem ville være et af de værst mulige valg for en VPN-tjeneste.

***

## Dårlig præstation

Google er ligeglad med ydeevnen for deres produkter fra mindst 2017, da deres sidste benchmarking-software (Google Octane) blev afbrudt i 2017.

***

## Dårlig projektledelse

Google har et meget dårligt internt projektstyringssystem. Nogle almindelige eksempler på programmer, der er blevet mere og mere nedgraderet, inkluderer Google Duo og YouTube-musik (tidligere Google Play Musik)

I Googles interne udviklingssystem fører 1 app til en anden app med halv funktionalitet, så slettes den oprindelige app. Et par år senere oprettes en ny app med 75% mindre funktionalitet, og derefter fjernes appen med 50% funktionalitet, efterfulgt af en ny app med 87,5% af funktionaliteten, der oprettes, derefter afbrydes appen med 75% funktionalitet , og så videre.

***

## Frygtelig eller ingen moderering af tjenester

YouTube er det mest almindelige eksempel i en verden af ​​dårlig moderering, der skaber den værste platform, der findes. Google ser heller ikke ud til, at YouTube ikke er YouTube-børn.

For YouTube serveres hadefulde pro-nazistiske og White Supremacist-indhold til brugere med henblik på mere engagementstid og flere penge. Google har også gjort nogle megetdumme ting i deres moderation, såsom at godkende en kristen analsex-video som indhold `lavet til børn`, samtidig med at alder begrænser videoen. Det er heller ikke for ualmindeligt at se pornografiske eller gore-annoncer lige under Baby Shark-videoen sammen med forskellige andre 'lavet til børn' indhold.

YouTube-brugere klager ekstremt ofte over den dårlige moderering på YouTube for dårligt indhold (som eksemplerne nævnt ovenfor), mens brugere kan få slettet deres videoer tilfældigt uden grund uden mulighed for at ophæve det sammen med brugere, der straffes for enhver form for sværd, selv meget mindre tilfælde som at sige "crap" -brugere sammenligner ofte YouTube med [Sovjetunionen] (https://en.wikipedia.org/wiki/Soviet_Union) i Stalin-æraen på grund af disse ulige straffe.

I 2021 annoncerede Google, at de vil lægge annoncer på alle videoer, på trods af at videoen demoniseres (så Google tjener penge, men skaberen ikke), dette vedrører ikke moderering for meget, men det er vigtigt at bemærke.

YouTube er modereret (omend meget dårligt), men Googles annoncetjeneste, der gør dem til det meste af deres penge, ser ud til at have ringe eller ingen moderering.

[Læs mere om YouTube-moderationsproblemer og hvordan man skifter fra YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Annoncer til Google Play genereres fra bot-gårde, du kan se, at de samme annoncescenarier bruges af hundreder af virksomheder med små ændringer og ingen relation til produktet (almindelige eksempler: Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City og tusinder mere) sammen med en blomstrende ondsindet tendens med annoncer, der hævder, at brugerne kan tjene penge ved at spille spil, lytte til musik osv. PayPal har ikke kommenteret dette, men det er indlysende, at dette er en fidus, som om du kunne lave over $ 10.000 på mindre end 20 sekunder ved at spille et spil garanteret, ingen ville arbejde og ville gøre dette i stedet, hvilket er umuligt, og en virksomhed kunne ikke arbejde sådan. Denne åbenlyse fidus er vokset stærkt siden 2019, og nu kæmper botfarmene, der producerer disse annoncer, med hinanden i deres egne annoncer.

Flere reklamer er også meget uhyggelige og forsøger at få brugere (de fleste af dem er brugere under 13 år eller bots) til at klikke gennem seksuel manipulation.

Mange apps bruger bots og astroturf deres produkter, så når en dårlig anmeldelse foretages, vil sock marionet bot-konti begynde at sende 5-stjernede anmeldelser og forsøge at negere din kritik. [Google gør det også selv] (# Astroturfing)

[Læs mere om problemer med Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

Generel definition [(fra Wikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

`` ''
Astroturfing er den praksis at maskere sponsorerne til en besked eller organisation (fx politisk, reklame, religiøs eller public relations) for at få det til at virke som om det stammer fra og støttes af græsrodsdeltagere. Det er en praksis, der skal give erklæringerne eller organisationerne troværdighed ved at tilbageholde oplysninger om kildens økonomiske forbindelse. Udtrykket astroturfing stammer fra AstroTurf, et mærke af syntetiske tæpper designet til at ligne naturligt græs, som et spil på ordet "græsrods". Implikationen bag brugen af ​​udtrykket er, at i stedet for en "ægte" eller "naturlig" græsrodsindsats bag den pågældende aktivitet er der en "falsk" eller "kunstig" fremtoning af støtte.
`` ''

Google har en historie med astroturfing for at få det til at virke som om de ikke gør noget ondt (i processen er astroturfing ondt) for eksempel vil udstationering af kritik af Google på en platform som Twitter (som de har en konto på) resultere i adskillige konti, der har eksisteret i et stykke tid, men aldrig bogført før de kom ud og hævdede, at hvad du sagde er falsk, og derefter hævder, at Google er den bedste virksomhed, men gjort på en måde, så det måske ikke er indlysende, at disse er bots for de fleste mennesker.

***

## Ulovlig og uetisk forretningspraksis

Google bruger ulovlig og uetisk forretningspraksis for at fremme deres monopol, såsom brug af skattely, outsourcing af job og fortsat udførelse af ulovlige invasive aktiviteter som en omkostning ved at drive forretning.

### I Europa

Europa har ofte sagsøgt Google, hvor den største retssag er mod ulovlig opførsel i Android, hvilket resulterede i, at Google modtog € 5.000.000.000 (svarende til $ 5.947.083.703,68 i 9. april 2021 penge)

### I Nordamerika

De Forenede Stater har endnu ikke givet næsten nok en bøde til Google sammenlignet med europæerne € 5.000.000.000 bøde.

### Kontroverser

Google er ligeglad med et problem, før det skaber en kontrovers, så de vil gøre et dårligt forsøg på at rette det, lige nok til at kontroversen midlertidigt forsvinder, og problemet bliver derefter eksponentielt værre, indtil det skaber en anden kontrovers, og cyklus fortsætter. De er simpelthen ligeglad med at gøre noget seriøst ved det.

***

## Google er automatiseret

Som et comGoogle er for det meste automatiseret med mindre moderering end automatisering.

En virksomhed bør ikke være fuldt automatiseret. Google er et eksempel på dette. Moderering er forfærdelig, når kun udført af AI, YouTube er et godt eksempel, selv med de ekstra få (hundreder eller måske tusind) mennesker, der modererer webstedet, hvor det tilsyneladende er så dårligt, at de fleste af dem er nødt til at få behandling, mens de arbejder.

***

## Android

Android ejes af Google. En del af Open Handset Alliance (som ikke har været åben siden Android) Android er blevet et andet monopolpunkt for Google og en meget vanskelig at undslippe.

Android er blevet rapporteret at ringe hjem til Google mindst 10 gange om dagen, og på trods af at det er delvist open source fungerer det stadig stærkt som spyware.

Flere projekter er oprettet for at skifte fra Android, men kræver rooting af din enhed. Dette er simpelthen ikke muligt længere for specifikke Samsung-telefoner i USA på grund af Knox DRM. Almindelige suppleanter til Android inkluderer iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch og PiPhone (Pi Phone er et mærke af telefoner, der kører forskellige Linux-systemer på en mobilenhed, såsom Fedora, Ubuntu, Arch osv.)

[Se min forskning om at få en Android-virtuel maskine til at fungere funktionelt] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Se, hvordan du degoogle fra Android] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Små handlinger til hjælp

Det er vigtigt at sprede bevidsthed på enhver måde, du kan. For mig taler jeg ikke kun ofte om degoogling og skriver artikler, men jeg har også en lille lille vane, hvor jeg giver min daglige gratis Reddit-pris til det fastgjorte indlæg på r / degoogle for at øge bevidstheden. Indtil videre har jeg tildelt næsten 30 priser til den fastgjorte post (jeg brugte også 500 af mine gratis mønter på 10 priser for den post)

***

## Utroværdigt

Google kan ikke stole på og kan aldrig stole på igen. De er helt gået fra "vær ikke ond" (de var altid onde) til bare at være fuldstændig onde og ikke forsøge at skjule det.

***

## Andre ting at tjekke ud

[Google Graveyard (killedbygoogle.com) - en sorteret liste over de 224+ produkter, Google har dræbt] (https://killedbygoogle.com/)

> [GitHub-link] (https://github.com/codyogden/killedbygoogle)

[Arbejderforening i alfabetet - Den nye arbejderforening hos Google med over 800 medlemmer] (https://alphabetworkersunion.org/people/our-union/)

[Vil du ikke dele med dinosaurus påskeæg? Denne webside har du dækket] (https://chromedino.com/)

Der er andre suppleanter, bare søg efter dem.

***

En vis faktakontrol er nødvendig for denne artikel

***

## Filinfo

Filtype: 'Markdown (* .md)'

Linjetælling (inklusive tomme linjer og kompileringslinje): `968`

Filversion: `` 6 (søndag den 18. april 2021 kl. 16:18) '

***

### Software status

Alle mine værker er gratis nogle begrænsninger. DRM (** D ** igital ** R ** estrictions ** M ** anagement) er ikke til stede i nogen af ​​mine værker.

! [DRM-fri_label.en.svg] (DRM-fri_label.en.svg)

Dette mærkat understøttes af Free Software Foundation. Jeg har aldrig til hensigt at medtage DRM i mine værker.

Jeg bruger forkortelsen "Digital Restrictions Management" i stedet for den mere kendte "Digital Rights Management", da den almindelige måde at adressere den på er falsk, der er ingen rettigheder til DRM. Stavemåden "Digital Restrictions Management" er mere nøjagtig og understøttes af [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) og [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Dette afsnit bruges til at øge bevidstheden om problemerne med DRM og også til at protestere mod det. DRM er defekt af design og er en stor trussel mod alle computerbrugere og softwarefrihed.

Billedkredit: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Sponsorinfo

! [SponsorButton.png] (SponsorButton.png) <- Klik ikke på denne knap, det virker ikke, det er bare et billede. Den rigtige knap er øverst på siden i højre (<- L ** R ** ->) hjørne

Du kan sponsorere dette projekt, hvis du vil, men angiv venligst hvad du vil donere til. [Se de midler, du kan donere til her] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Du kan se anden sponsorinformation [her] (https://github.com/seanpm2001/Sponsor-info/)

Prøve det! Sponsorknappen er lige ved siden af ​​uret / uret-knappen.

***

## Filhistorik



 * Startede filen

> * Tilføjede titelsektionen

> * Tilføjet indekset

> * Tilføjet afsnittet om

> * Tilføjet Wiki-sektionen

> * Tilføjet sektionen til versionshistorik

> * Tilføjede afsnittet om problemer.

> * Tilføjet sektionen om tidligere udgaver

> * Tilføjet sektionen om tidligere anmodninger om træk

> * Tilføjet sektionen for aktive pullanmodninger

> * Tilføjet afsnittet om bidragydere

> * Tilføjet det bidragende afsnit

> * Tilføjet sektionen om README

> * Tilføjet sektionen README-versionshistorik

> * Tilføjede ressourceafsnittet

> * Tilføjet et softwarestatusafsnit med et DRM-frit klistermærke og en besked

> *Tilføjede sektionen om sponsorinfo

> * Ingen andre ændringer i version 0.1

Version 1 (fredag ​​den 19. februar 2021 kl. 17.20)

> Ændringer:

> * Startede filen

> * Tilføjet den grundlæggende beskrivelse

> * Tilføjet sektionen om depotbeskrivelse

> * Tilføjet artikellisten med 14 poster

>> * Tilføjet en sektion med `relaterede artikler`

>> * Tilføjet en `se også` sektion

> * Tilføjede filinfosektionen

> * Tilføjede filhistorik sektionen

> * Tilføjet sidefoden

> * Ingen andre ændringer i version 1

Version 2 (fredag ​​den 19. februar 2021 kl. 17:26)

> Ændringer:

> * Tilføjede sektionen for oversættelsesstatus

> * Tilføjede afsnittet Andre ting at tjekke ud

> * Tilføjet sektionen om beskyttelse af personlige oplysninger

> * Tilføjet et indeks

> * Tilføjet underafsnittet for softwarestatus

> * Tilføjede den anden anti-Google-kampagnesektion

>> * Tilføjede det nedlagte underafsnit

>> * Tilføjede det igangværende underafsnit

> * Tilføjede kildeafsnittet

> * Tilføjet sektionen downloadlink

> * Opdateret filinfosektionen

> * Opdateret sektionen med filhistorik

> * Ingen andre ændringer i version 2

Version 3 (onsdag 24. februar 2021 kl. 19:56)

> Ændringer:

> * Opdateret indekset

> * Der henvises til degoogle-ikonet og den nye GitHub-organisation

> * Tilføjede links til nyere artikler

> * Tilføjet afsnittet modvirkende andre argumenter

>> * Tilføjet underafsnittet om bekvemmelighed

>> * Tilføjet underafsnittet Why even

>> * Tilføjet det andet underafsnit

> * Opdateret nogle data

> * Opdateret filinfosektionen

> * Opdateret sektionen med filhistorik

> * Ingen andre ændringer i version 3

Version 4 (torsdag 25. februar 2021 kl. 21:31)

> Ændringer:

> * Tilføjede links til 10 nye artikler

> * Tilføjet et afsnit om min oplevelse af degoogling

> * Opdateret indekset

> * Opdateret filinfosektionen

> * Opdateret sektionen med filhistorik

> * Ingen andre ændringer i version 4

Version 5 (fredag ​​9. april 2021 kl. 18:02)

_Der har været mangel på opdateringer til anti-Google-bevægelsen fra mig for nylig, jeg arbejder på at komme tilbage til det efter en pause på mere end 1 måned._

> Ændringer:

> * Opdateret titelsektionen

> * Opdateret indekset

> * Opdaterede sproglisten: faste links og tilføjede flere understøttede sprog

> * Opdateret artiklens statusafsnit og tilføjet 4 fork-links

> * Opdateret softwarestatusafsnittet

> * Tilføjet sektionen Go is evil

> * Tilføjet anvendelsen af ​​DRM-sektionen

> * Tilføjede afsnittet Almindelige misforståelser

>> * Tilføjet Google er ikke Internet-underafsnittet

> * Tilføjede Internet Explorer 6 og Chrome sektionen

>> * Tilføjede problemet med Brave-underafsnit

> * Tilføjet fjernelse af privatlivets fred fra Faux

> * Tilføjet Open source kan ikke være delvis underafsnit

> * Tilføjet underafsnittet Oxymoron

> * Tilføjede afsnittet Dårlig ydeevne

> * Tilføjet afsnittet Dårlig projektstyring

> * Tilføjet sektionen Horrible eller no moderation of services

> * Tilføjede sektionen Astroturfing

> * Tilføjet afsnittet Ulovlig og uetisk forretningspraksis

> * Tilføjet underafsnittet I Europa

>> * Tilføjet underafsnittet I Nordamerika

>> * Tilføjet underafsnittet Kontroverser

> * Tilføjet sektionen Google er automatiseret

> * Tilføjet Android-sektionen

> * Tilføjet sektionen Små handlinger til hjælp

> * Tilføjede afsnittet Utroværdigt

> * Tilføjet sektionen om sponsorinfo

> * Opdateret sidefoden

> * Opdateret filinfosektionen

> * Opdateret sektionen med filhistorik

> * Ingen andre ændringer i version 5

Version 6 (søndag den 18. april 2021 kl. 16:18)

> Ændringer:

> * Opdateret indekset

> * Tilføjet en ny oversigtsbeskrivelse

> * Opdateret artikelstatusinfo

> * Tilføjet et link til den nye Google FLoC-artikel

> * Tilføjet et link til Wuest 3n Fuchs Degoogle-artiklen og generel info om den

> * Opdateret filinfosektionen

> * Opdateret sektionen med filhistorik

> * Ingen andre ændringer i version 6

Version 7 (Kommer snart)

> Ændringer:

> * Kommer snart

> * Ingen andre ændringer i version 7

Version 8 (Kommer snart)

> Ændringer:

> * Kommer snart

> * Ingen andre ændringer i version 8

Version 9 (Kommer snart)

> Ændringer:

> * Kommer snart

> * Ingen andre ændringer i version 9

Version 10 (Kommer snart)

> Ændringer:

> * Kommer snart

> * Ingen andre ændringer i version 10

Version 11 (Kommer snart)

> Ændringer:

> * Kommer snart

> * Ingen andre ændringer i version 11

Version 12 (Kommer snart)

> Ændringer:

> * Kommer snart

> * Ingen andre ændringer i version 12

***

## Sidefod

Du har nået slutningen af ​​denne fil

([Tilbage til toppen] (# Top) | [Tilbage til GitHub] (https://github.com))

### EOF

***
