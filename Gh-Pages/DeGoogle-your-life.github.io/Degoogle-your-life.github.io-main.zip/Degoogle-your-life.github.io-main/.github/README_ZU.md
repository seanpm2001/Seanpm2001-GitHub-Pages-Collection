***

! [I-DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle impilo yakho

Le yindatshana eyinhloko yokwehliswa kwemininingwane yemininingwane ejwayelekile yokwenziwa kwesivumelwano kanye nesixhumanisi sezinye izindatshana.

[Bona uhlu njengenhlangano yeGitHub] (https://github.com/Degoogle-your-life)

***

_Funda le ndatshana ngolunye ulimi: _

** Ulimi lwamanje luthi: ** `English (US)` _ (izinguqulo zingadinga ukulungiswa ukulungisa isiNgisi esikhundleni solimi olufanele) _

_🌐 Uhlu lwezilimi_

** Kuhlungwe nge: ** `A-Z`

[Izinketho zokuhlunga azitholakali] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanian | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) isi-Arabhu | [hy հայերեն] (/. github / README_HY.md) isi-Armenian | [az Azrbaycan dili] (/. github / README_AZ.md) isi-Azerbaijani | [eu Euskara] (/. github / /README_EU.md) isiBasque | [be Беларуская] (/. Github / README_BE.md) isiBelarusian | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) IsiBosnia | [bg български] (/. Github / README_BG.md) isiBulgaria | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) IsiShayina (Esenziwe Lula) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) IsiShayina (Esijwayelekile) | [co Corsu] (/. Github / README_CO.md) IsiCorsican | [hr Hrvatski] (/. Github / README_HR.md) isiCroatia | [cs čeština] (/. Github / README_CS .md) IsiCzech | [da dansk] (README_DA.md) IsiDanish | [nl Nederlands] (/. github / README_ NL.md) isiDashi | [** en-us English **] (/. github / README.md) isiZulu | [EO Esperanto] (/. Github / README_EO.md) Isi-Esperanto | [et Eestlane] (/. github / README_ET.md) Isi-Estonia | [tl Pilipino] (/. github / README_TL.md) isiFilipino | [fi Suomalainen] (/. github / README_FI.md) IsiFinnish | [fr français] (/. github / README_FR.md) IsiFulentshi | [fy Frysk] (/. github / README_FY.md) IsiFrisia | [gl Galego] (/. github / README_GL.md) IsiGalician | [ka ქართველი] (/. github / README_KA) IsiGeorgia | [de Deutsch] (/. github / README_DE.md) IsiJalimane | [el Ελληνικά] (/. github / README_EL.md) isiGreki | [gu ગુજરાતી] (/. github / README_GU.md) IsiGujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) IsiCreole SaseHaiti | [ha Hausa] (/. github / README_HA.md) IsiHausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) isiHeberu | [hi हिन्दी] (/. github / README_HI.md) isiHindi | [hmn Hmong] (/. github / README_HMN.md) iHmong | [hu Magyar] (/. github / README_HU.md) isiHungary | [is Íslenska] (/. github / README_IS.md) Isi-Icelandic | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Isi-Icelandic | [ga Gaeilge] (/. github / README_GA.md) isi-Irish | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) IsiJapane | [jw Wong jawa] (/. github / README_JW.md) isiJavanese | [kn ಕನ್ನಡ] (/. github / README_KN.md) IsiKannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw isiKinyarwanda] (/. github / README_RW.md) isiKinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) IsiKorea (eNingizimu) | [ko-north 문화어] (README_KO_NORTH.md) Isi-Korean (North) (AKAHHUNYULWA) | [ku Kurdî] (/. github / README_KU.md) isiKurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) isiKyrgyz | [bheka ລາວ] (/. github / README_LO.md) iLao | [la Latine] (/. github / README_LA.md) isiLatin | [lt Lietuvis] (/. github / README_LT.md) Isi-Lithuanian | [lb Lëtzebuergesch] (/. github / README_LB.md) Isi-Luxembourgish | [mk Македонски] (/. github / README_MK.md) IsiMacedonia | [mg Malagasy] (/. github / README_MG.md) IsiMalagasy | [ms Bahasa Melayu] (/. github / README_MS.md) IsiMalay | [ml മലയാളം] (/. github / README_ML.md) IsiMalayalam | [mt Malti] (/. github / README_MT.md) Isi-Maltese | [mi Maori] (/. github / README_MI.md) AmaMaori | [mr मराठी] (/. github / README_MR.md) IsiMarathi | [mn Монгол] (/. github / README_MN.md) IsiMongolia | [my မြန်မာ] (/. github / README_MY.md) iMyanmar (isiBurma) | [ne नेपाली] (/. github / README_NE.md) isiNepali | [ayikho i-norsk] (/. github / README_NO.md) isiNorway | [noma ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) IsiPashto | [fa فارسی] (/. github / README_FA.md) | Persian [pl polski] (/. github / README_PL.md) IsiPolish | [pt português] (/. github / README_PT.md) IsiPutukezi | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) isiPunjabi | Azikho izilimi ezitholakalayo eziqala ngohlamvu Q | [ro Română] (/. github / README_RO.md) isiRomania | [ru русский] (/. github / README_RU.md) isiRashiya | [sm Faasamoa] (/. github / README_SM.md) isiSamoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) AmaScot Gaelic | [sr Српски] (/. github / README_SR.md) IsiSerbia | [st Sesotho] (/. github / README_ST.md) isiSuthu | [sn Shona] (/. github / README_SN.md) isiShona | [sd سنڌي] (/. github / README_SD.md) isiSindhi | [si සිංහල] (/. github / README_SI.md) ISinhala | [sk Slovák] (/. github / README_SK.md) IsiSlovak | [sl Slovenščina] (/. github / README_SL.md) isiSlovenia | [so Soaliali] (/. github / README_SO.md) iSomalia | [[es es español] (/. github / README_ES.md) IsiSpanish | [su Sundanis] (/. github / README_SU.md) iSundanese | [sw Kiswahili] (/. github / README_SW.md) isiSwahili | [sv Svenska] (/. github / FUNDAE_SV.md) IsiSwidi | [tg Тоҷикӣ] (/. github / README_TG.md) IsiTajik | [ta தமிழ்] (/. github / README_TA.md) IsiTamil | [tt Татар] (/. github / README_TT.md) isiTatar | [te తెలుగు] (/. github / README_TE.md) IsiTelugu | [th ไทย] (/. github / README_TH.md) isiThai | [tr Türk] (/. github / README_TR.md) IsiTurkey | [tk Türkmenler] (/. github / README_TK.md) AmaTurkmen | [uk Український] (/. github / README_UK.md) Isi-Ukraine | [ur اردو] (/. github / README_UR.md) Isi-Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Isi-Vietnamese | [cy Cymraeg] (/. github / README_CY.md) Isi-Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) IsiYiddish | [yo Yoruba] (/. github / README_YO.md) IsiYoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Kutholakala ngezilimi eziyi-110 (108 uma singabalwa isiNgisi neNyakatho Korea, njengoba iNorth Korea ingakahunyushwa kuze kube manje [Funda ngakho lapha] (/ OldVersions / Korean (North ) /README.md))

Ukuhumusha kwezinye izilimi ngaphandle kwesiNgisi kuhunyushwe ngomshini futhi akukacaci okwamanje. Awekho amaphutha alungisiwe okwamanje kusukela ngoFebhuwari 5, 2021. Sicela ubike amaphutha wokuhumusha [lapha] (https://github.com/seanpm2001/Degoogle-your-life/issues/) qiniseka ukwenza isipele ukulungiswa kwakho ngemithombo futhi ungiqondise , ngoba angizazi kahle ezinye izilimi ngaphandle kwesiNgisi (ngihlela ukuthola umhumushi ekugcineni) ngicela usho [wiktionary] (https://en.wiktionary.org) neminye imithombo embikweni wakho. Ukwehluleka ukwenza lokho kuzoholela ekwenqabeni ukulungiswa okushicilelwa.

Qaphela: ngenxa yemikhawulo ngokuchazwa kweGitHub yokumaka (futhi kuhle kakhulu konke okunye okususelwa kuwebhu kokumakwa) ngokuchofoza lezi zixhumanisi kuzokuqondisa kabusha kufayela elihlukile ekhasini elihlukile okungelona ikhasi lami le-GitHub. Uzoqondiswa kabusha uye e- [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), lapho kubanjelwa khona i-README.

Ukuhumusha kwenziwa nge-Google Translate ngenxa yokusekelwa okulinganiselwe noma okungekho kwezilimi engizidingayo kwezinye izinsizakalo zokuhumusha njenge-DeepL ne-Bing Translate (okuhlekisayo emkhankasweni wokulwa ne-Google) ngisebenzela ukuthola enye indlela. Ngasizathu simbe, ukufomatha (izixhumanisi, ukwahlukanisa, ukugqama, ama-ithalikhi, njll.) Kudidekile ekuhumusheni okuhlukahlukene. Kuyadina ukulungisa, futhi angazi ukuthi zingalungiswa kanjani lezi zinkinga ngezilimi nezinhlamvu ezingezona ezesi-latin, futhi izilimi ezingakwesokunxele (njenge-Arabhu) kudingeka usizo olwengeziwe ekulungiseni lezi zinkinga

Ngenxa yezinkinga zokulungiswa, ukuhumusha okuningi kuphelelwe yisikhathi futhi kusetshenziswa inguqulo ephelelwe yisikhathi yaleli fayela le-athikili elithi `README`. Kudingeka umhumushi. Futhi, kusukela ngo-Ephreli 9th 2021, kuzongithatha isikhashana ukwenza zonke izixhumanisi ezintsha zisebenze.

***

# # Inkomba

[00.0 - Isihloko] (# Ukwenza i-googling --- Degoogle-your-life)

> [00.1 - Index] (# Inkomba)

[01.0 - Incazelo eyisisekelo] (# Incazelo eyisisekelo)

> [01.1 - Unhlokweni Wokugcina] (# Degoogle-your-life)

> [01.2 - Ukubuka konke kwencazelo ye-Wuest3NFuchs] (# Ukubuka konke-ngo-Wuest3nFuchs)

>> [01.2.1 - Kusho ukuthini?] (# Kusho ukuthini - nge-Wuest3nFuchs)

>> [01.2.2 - Kungani uDegoogle?] (# Why-Degoogle - by-Wuest3nFuchs)

[02.0 - Imibhalo] (# Imibhalo)

[03.0 - Ubumfihlo] (# Ubumfihlo)

[04.0 - Eminye imikhankaso elwa ne-Google] (# Eminye imikhankaso yokulwa ne-Google)

> [04.0.1 - Akasasebenzi] (# Akusasebenzi)

> [04.0.2 - Iyaqhubeka] (# Iyaqhubeka)

[05.0 - Ukuphikisa ezinye izimpikiswano] (# Ukuphikisana nezinye izimpikiswano)

> [05.0.1 - Ukukhululeka] (# Kalula)

> [05.0.2 - Kungani kunendaba? Isikhathi sesihambile kakhulu] (# Kungani-kunendaba, -kwephuze kakhulu-nganoma iyiphi indlela)

> [05.0.3 - Okunye] (# Okunye)

[06.0 - Imithombo] (# Imithombo)

[07.0 - Izixhumanisi zokulanda] (# Izixhumanisi zokulanda)

[08.0 - Okuhlangenwe nakho kwami ​​kokuyekelwa phansi] (# Isipiliyoni sokwenza umsebenzi wami)

> [08.1 - Engikushintshe kusuka] (# What-I-switched-from)

> [08.2 - Imikhiqizo engingakakwazi ukusuka kuyo] (# Imikhiqizo-engisazokwazi ukuyisusa-kude)

[09.0 - Ezinye izinto ozozihlola] (# Ezinye izinto-okufanele uhlole)

[10.0 - Imininingwane yefayela] (# Imininingwane yefayela)

> [10.1 - Isimo seSoftware] (# Isimo sesoftware)

> [10.2 - Ulwazi lomxhasi] (# Ulwazi lomxhasi)

[11.0 - Umlando wefayela] (# Umlando wefayela)

[12.0 - Unyaweni] (# Unyaweni)

***

## Incazelo eyisisekelo

[Kusuka ku-Wikipedia: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

Ukunyakaza kweDeGoogle (okubizwa nangokuthi ukunyakaza kwe-de-Google) umkhankaso ophansi osuvele njengoba izishoshovu zobumfihlo zinxusa abasebenzisi ukuthi bayeke ukusebenzisa imikhiqizo yakwaGoogle ngokuphelele ngenxa yokukhula kwemfihlo mayelana nenkampani. Leli gama lisho isenzo sokususa iGoogle empilweni yomuntu. Njengoba isabelo semakethe esikhulayo senkampani enkulu ye-intanethi sidala amandla okuzimela enkampanini ezikhaleni zedijithali, amanani andayo ezintatheli abonile ubunzima bokuthola ezinye izindlela zemikhiqizo yenkampani.

** Umlando **

Ngo-2013, uJohn Koetsier weVenturebeat wathi i-Amazon Kindle Fire Android tablet tablet "yayiyinguqulo ye-Android esuselwa kuGoogle." Ngo-2014 uJohn Simpson we-US News wabhala “ngelungelo lokukhohlwa” yi-Google nezinye izinjini zokusesha. Ngo-2015, uDerek Scally we-Irish Times wabhala i-athikili yokuthi ungayenza kanjani i- "De-Google impilo yakho." Ngo-2016 uKris Carlon waseAndroiIsiphathimandla siphakamise ukuthi abasebenzisi beCyanogenMod 14 bangakwazi “ukususa i-Google” izingcingo zabo, ngoba iCyanogenMod isebenza kahle ngaphandle kwezinhlelo zokusebenza zeGoogle. Ngo-2018 uNick Lucchesi we-Inverse wabhala ukuthi iProtonMail yayikukhuthaza kanjani ukuthi "ukwazi ukukhubaza ngokuphelele impilo yakho." UBrendan Hesse kaLifehacker ubhale okokufundisa okunemininingwane "ngokuyeka iGoogle." Intatheli yeGizmodo uKashmir Hill uthi uphuthe imihlangano futhi waba nobunzima ekuhleleni imihlangano ngaphandle kokusebenzisa i-Google Calendar. Ngo-2019, uHuawei ubuyisele imali kubanikazi bezingcingo ePhilippines kuvinjelwe ekusebenziseni amasevisi ahlinzekwa yi-Google ngoba zimbalwa ezinye izindlela ezikhona ukuthi ukungabikho kwemikhiqizo yenkampani kwenza ukusetshenziswa kwe-inthanethi okujwayelekile kungasebenzeki.

***

# Degoogle-impilo yakho
Indawo yokugcina imininingwane ejwayelekile yokwenziwa kwezigi kanye nezixhumanisi kwamanye amakhosombe ami e-degoogling.

***

# # Ukubuka konke nguWuest3nFuchs

Incazelo engcono, enikezwe yi- [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - umthombo: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Kusho ukuthini? ngu-Wuest3nFuchs

I-Degoogling isho ukuyeka ukusebenzisa noma yini okungeye-Google, noma yini eyenziwe yiGoogle. Ngikhuluma ngenjini yabo yokusesha, insizakalo yabo yeposi (i-Gmail), i-Youtube, njll.

### Kungani uDegoogle? ngu-Wuest3nFuchs

I-Google ingenye yezinkampani ezinamandla kakhulu emhlabeni njengamanje. Baye bagcina inani elikhulu lemininingwane kithi sonke. Abanye bangaphikisa ngokuthi imininingwane yethu iphephile kubo ngoba bayazi ukuthi bangavikela kanjani. Kepha lokhu akulona iqiniso. I-Google ingenile ngaphambili futhi izongenwa ngokuzayo. Mhlawumbe hhayi ngomuntu othile weskripthi kepha kuzokwenziwa izwe lesizwe. I-Google igcina imininingwane yomuntu siqu kithi sonke ngoba lena yindlela abenza ngayo imali.

Baskena ama-imeyili ethu, bagcine esikuseshayo lapho sisebenzisa injini yabo yokusesha, yimaphi amavidiyo esiwabukayo ku-Youtube. Le ndlela basikhomba ngayo futhi bakhe iphrofayili kithi ukusikhombisa isikhangiso esithile ngokususelwe kulokho esikhulume ngakho nomngani wethu omkhulu ukuze basibonise isikhangiso sento esiyidingayo, kepha lokhu kuyadida kakhulu. Sibonga uMnu. Snowden manje sesiyazi ukuthi i-Google yabelane ngemininingwane yethu neNSA ngaphansi kohlelo olubizwa ngokuthi "PRISM" **.


Ngokuzayo othile uzokwazi ukuthola lonke lolo lwazi futhi ngiyakuqinisekisa ukuthi kukhona okubi kakhulu okuzokwenzeka. Ukuvimbela lokho kungenzeki, kufanele uqale i-Degoogling khona manje. Futhi akufanele usebenzise imikhiqizo yinkampani eyabelana ngemininingwane yakho ne- ** NSA **. Kufanele umise konke lokhu ngokuzibamba phansi.

** Uma abanye abantu bekwazi ukukwenza, nawe ungakwenza.

[Funda kabanzi lapha] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Isixhumanisi semfoloko okwamanje asifakiwe kuhlu, ngoba angiyena umnikazi wale ndawo ngokuphelele, futhi ngifuna ukukhuthaza eminye imithombo. Kungaba ubugovu ukuxhumanisa nokwami ​​https://github.com/Degoogle-your-life/Degoogle! ->

***

# # Imibhalo

Isimo se-Article

_Zonke izindatshana kungumsebenzi oqhubekayo futhi zidinga ukwenziwa ngcono okukhulu. Iziphakamiso nokulungiswa kuvunyelwe._

_Kusukela ngo-Ephreli 18th 2021 ngo-4: 09 pm, izindatshana eziningi azikakaqalwa. Ngisebenza ukuthola isikhathi nomzamo wokuziqala._

[Kungani kufanele uyeke ukusebenzisa iGoogle Chrome] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Misa ukusebenzisa i-ChromeBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Yeka ukusebenzisa i-WideVine DRM / Isikhathi sokusika i-WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Kungani kufanele uyeke ukusebenzisa i-ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Kushintshana ne-YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Stop Googling, kungani kufanele uyeke ukusebenzisa i-Google Search] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[Kungani kufanele uyeke ukusebenzisa i-Gmail] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Kungani kufanele uyeke ukusebenzisa i-Android] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Kungani kufanele ugweme i-Google Amp] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Drayivu] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Kungani kufanele uyeke ukusebenzisa iGoogle Maps neGoogle Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Sawubona Google, ima] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Misa ukufunda ku-Google / Play books] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Misa ukusebenzisa i-Google Classroom] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Translate] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Kungani kufanele uyeke ukusebenzisa ama-Akhawunti wakho we-Google] (https://github.com/seanpm2001/Why-you-should-sukusebenzisa-i-Google-Akhawunti okuphezulu) <! - 16! ->

** Izindatshana ezintsha ezizobhalwa maduze: **

[Kungani kufanele uyeke ukusebenzisa iGerrit] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Kungani kufanele uyeke ukusebenzisa iGoogle Analytics (indawo yokugcina izinto iphukile ekugcineni kwami ​​ngoLwesithathu, ngoFebhuwari 24 2021 ngo-4: 13 ntambama)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics) <! - 18! ->

<! - Isihlukanisi somsebenzi! ->

[Kungani kufanele uyeke ukusebenzisa i-Google AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Kungani kufanele uyeke ukusebenzisa i-Google One] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Kungani kufanele uyeke ukusebenzisa i-Google + (engasasebenzi)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Play Isitolo] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Docs] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Amaslayidi] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Kungani kufanele uyeke ukusebenzisa i-Google AmaSpredishithi] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- AmaSpredishithi) <! - 25! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Amafomu] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Cardboard] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Messages] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Material Design] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Glass / Glasses] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Kungani kumele uyeke ukusebenzisa i-Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Kungani kufanele uyeke ukusebenzisa i-GBoard] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Home] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Nest] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Hangouts (engasasebenzi)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Duo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Kungani kufanele uyeke ukusebenzisa iGoogle Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Kungani kufanele uyeke ukusebenzisa ulimi lokuhlela lweGoogles Go] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Kungani kufanele uyeke ukusebenzisa ulimi lohlelo lweGoogles Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Kungani kufanele uyeke ukusebenzisa ifomethi yesithombe seGoogles WebP] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Kungani kufanele uyeke ukusebenzisa ifomethi yevidiyo yeGoogles WebM] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Video] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Kungani kufanele uyeke ukusebenzisa Amasayithi weGoogle (zakudala)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Kungani kufanele uyeke ukusebenzisa Amasayithi weGoogle ("Okusha")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Kungani kufanele uyeke ukusebenzisa i-Android Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Kungani kufanele uyeke ukusebenzisa i-Google VPN (oxymoron)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Kungani kufanele uyeke ukusebenzisa Izithombe ze-Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Khalenda] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Kungani kufanele uyeke ukusebenzisa i-VirusTotal (ngoba ibiphethwe yi-Google kusukela ngoSepthemba 2012] (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Kungani kufanele uyeke ukusebenzisa i-Google Fi] (https://github.com/seanpm2001/Why-you-shouI-ld-stop-using-Google-Fi) <! - 53! ->

[Kungani kufanele uyeke ukusebenzisa iGoogle Stadia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Keep] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Base] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Kungani kufanele uyeke ukubamba iqhaza ku-Google Summer of Code] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Kungani kufanele uyeke ukusebenzisa i-Google Camera] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Calculator (kungahle kubonakale kweqisile, kepha kufanele wenze i-degoogle kuyo yonke into, kulula ukuyishintsha)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Isibali) <! - 59! ->

[Kungani kufanele uyeke ukusebenzisa imivuzo ye-Google Survey +) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Kungani kufanele uyeke ukusebenzisa i-Google Drawings] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Kungani kufanele uyeke ukusebenzisa i-Tenor (isiza se-GIF, esiphethwe yi-Google kusukela ngo-2019)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Lokho i-FLoC - Kungani kufanele ugweme inkinga enkulu ye-Googles ye-FLoCing (yeka ukusebenzisa i-Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Izindatshana eziphelele: ** `63`

** I-athikili [i-roadmap AB] (DegoogleCampaign_2021Roadmap_Part1.md) (kufika ngoMashi 12th 2021) izinsuku ezimbili zokuphumula **

** I-athikili [i-roadmap BB] (DegoogleCampaign_2021Roadmao_Part2.md) (kufika ku? 2021) izinsuku ezimbili zokuphumula **

Isimo se-athikili

Yonke imibhalo okwamanje ingumsebenzi oqhubekayo futhi idinga ukwenziwa ngcono okukhulu. Iziphakamiso nokulungiswa kuvunyelwe.

** Izimfoloko **

Ukunweba inethiwekhi yami ye-Degoogle, nokungeza ukutholakala kalula, kanye nabamemezeli bomphakathi.

1. [Ama-Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Ifakwe kusuka ku: [https://github.com/wacko1805/Fossapps] (https://github.com/wacko1805/Fossapps) (English)

2. [Izixhumanisi zobumfihlo] (https://github.com/Degoogle-your-life/Privacy-links) | Ifakwe kusuka ku: [https://github.com/Arturro43/privacy-links] (https://github.com/Arturro43/privacy-links) (Polish)

3. [Okujabulisayo-Ubumfihlo] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Kwenziwe kusuka ku: [https://github.com/LinuxCafeFederation/Delightful-Privacy] (https://github.com/LinuxCafeFederation/Delightful-Privacy) (isiNgisi)

4. [Uhlu Lwamabhulokhi] (https://github.com/Degoogle-your-life/listslists) | Kwenziwe kusuka ku: [https://github.com/jmdugan/blocklists] (https://github.com/jmdugan/blocklists) (isiNgisi)

5. [UDegoogle, kaWuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Ifakwe kusuka ku: [https://github.com/Wuest3nFuchs/Degoogle] (https://github.com/Wuest3nFuchs/Degoogle) (isiNgisi)

** Okuhlobene **

[Ucwaningo lwe-Virtual Machine yocingo lwe-Android] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Bhekafuthi:**

[Ukugxekwa kwe-Google ku-Wikipedia] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[Amathuna eGoogle (killbygoogle.com) - uhlu oluhleliwe lwemikhiqizo engama-224 + i-Google eyibulele] (https://killedbygoogle.com/)

> [Isixhumanisi seGitHub] (https://github.com/codyogden/killedbygoogle)

[Inyunyana yezinhlamvu zamagama - Inyunyana entsha yabasebenzi kwaGoogle enamalungu angaphezu kuka-800] (https://alphabetworkersunion.org/people/our-union/)

[Awufuni ukuhlukana neqanda lephasika le-dinosaur? Le webhusayithi uyimbozile] (https://chromedino.com/)

***

# # Ubumfihlo

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / yonke-idatha-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit))ss (( https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spy-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he idatha ye-alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_arisisekelo # Ukugxekwa) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free amasampula -okungathembeki-lutho-lokufihla-ukuphikisana-akanalutho-lokuzisho /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- ye-data-mayelana-nawe-ongayithola futhi uyisuse-manje /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -yakho-imininingwane-yomuntu-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -wenza imali-futhi) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- iqoqo-kuvezwe.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ impilo-ukuqina-idatha-yobumfihlo /) [h] (https://www.pcmag.com/news/google-sued-ov i-er-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html))o)(https://en.wikipedia.org/wiki/2018_Google_data_breach))mimele(https://moz.com /blog/where-does-google-draw-the-data-collection-line))ee- (https://mashable.com/article/google-android-data-collection-study/)[s)(https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)letono- (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -imangalo-esikhundleni-se-5-m abasebenzisi be-illion-iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/)[r)(https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/)letonihttps: //www.cbsnews.com/news/google-education-spies-on-collects- idatha-ezigidini-zezingane-izinsolo-zokumangalelwa-okusha-mexico-ummeli-jikelele /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -ngaphansi-kwethu-amakhala /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / technology / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https) : //medium.com/digitalprivacywise/why-you-shop-stop-using-google-chrome-6c934c9a827c) (ngingaqhubeka ngibe nobufakazi balokhu, kepha kuthathe isikhathi eside ukuthola nokuhlola konke lokhu izindatshana)

Ubumfihlo kumikhiqizo yeGoogle kuhlala kubi, ngenxa yayo yonke imikhiqizo yakwa-Google equkethe ispyware

Akunandaba ukuthi wenzani, lapho usebenzisa i-Google, yonke imininingwane yakho ebucayi iyathunyelwa ku-Google nakwabanye. I-Google ibonwe futhi ihamba ngezinhlelo ezivulekile. Isibonelo, kusuka kokuhlangenwe nakho kwami ​​(kuFirefox) nethebhu ye-YouTube evulekile engingayivakashelanga, ngabuka amavidiyo amaningana ungaxhunyiwe ku-inthanethi (i-VLC Media Player) Kamuva lapho ngiyobheka izincomo, cishe konke engangikubukile. Akungabazeki ukuthi bahlola nezinye izinhlelo futhi.

Ku-Chrome (nezinye iziphequluli eziningi) imodi ye-incognito ikhona. Ku-Chrome, le modi ayisho lutho, njengoba iGoogle isazofaka idatha yakho. Noma uvala ukumba / ukulandela ngomkhondo idatha, futhi unike amandla isignali ethi "ungalandeleli", ukumangala okumangazayo, i-Google isagubha imininingwane yakho.

Uma ucabanga ukuthi awunakho okufihlayo, ** awunaphutha ngokuphelele **. Le mpikiswano ikhishwe kaningi ngaphezulu:

[Nge-Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. U-Edward Snowden uphawule "Ukuphikisana ngokuthi awunandaba nelungelo lokuba nemfihlo ngoba awunakho okufihlayo akufani nokuthi uthi awunandaba nenkululeko yokukhuluma ngoba awunalutho ongalusho." Uma uthi, ' Akukho engikufihlayo, 'usho,' Anginandaba naleli lungelo. 'Uthi,' Anginalo leli lungelo, ngoba ngifikile lapho kufanele ngikhulume khona Indlela okusebenza ngayo amalungelo, uhulumeni kufanele athethelele ukungenela kwakhe emalungelweni akho. "

2. UDaniel J. Solove usho ku-athikili yeThe Chronicle of Higher Education ukuthi uyayiphikisa le mpikiswano; wathi uhulumeni angaleyak imininingwane mayelana nomuntu futhi idale umonakalo kulowo muntu, noma usebenzise imininingwane ephathelene nomuntu ukwenqaba ukufinyelela ezinsizakalweni noma ngabe umuntu ubengazibandakanyi nokwenza okungalungile, nokuthi uhulumeni angadala umonakalo empilweni yakhe ngokwenza amaphutha. USolove ubhale ukuthi "Uma kuxoxiswana ngqo, impikiswano yokufihla okuthile ingacupha, ngoba iphoqa impikiswano ukuthi igxile ekuqondeni kwayo okuncane mayelana nobumfihlo. Kepha lapho ibhekene nobuningi bezinkinga zobumfihlo ezithintwa ukuqoqwa kwedatha kahulumeni nokusetshenziswa okungaphezu kokubhekwa futhi ukudalulwa, impikiswano yokufihla lutho, ekugcineni, ayinalutho olungakusho. "

3. U-Adam D. Moore, umbhali wamaLungelo Obumfihlo: Izisekelo Zokuziphatha Nezomthetho, wathi, "umbono wokuthi amalungelo aphikisana nezindleko / inzuzo noma uhlobo lwezimpikiswano. Lapha senqaba umbono wokuthi izintshisekelo zobumfihlo ziyizinhlobo wezinto ezingathengiselwa ukuphepha. " Ubuye wathi ukubhekwa kungathinta ngokungalingani amaqembu athile emphakathini ngokususelwa ekubukekeni, ubuhlanga, ubulili nenkolo.

4. UBruce Schneier, uchwepheshe wezokuphepha kwamakhompiyutha nomlobi we-cryptographer, uzwakalise ukuphikisa, ecaphuna isitatimende sikaKhadinali Richelieu esithi "Uma umuntu enganginika imigqa eyisithupha ebhalwe ngesandla sendoda ethembeke kakhulu, ngingathola okuthile kuyo ukuze alengiswe", ebhekisa ukuthi uhulumeni wezwe angazithola kanjani izici empilweni yomuntu ukuze ashushise noma ahlasele lowo muntu. USchneier uphinde wathi "Kuningi kakhulu okufanisa impikiswano ngokuthi 'ukuphepha kuqhathaniswa nobumfihlo.' Inketho yangempela inkululeko yokuqhathanisa nokulawula. "

5. UHarvey A. Silverglate ulinganisele ukuthi umuntu ovamile, ngokwesilinganiso, ngokungazi wenza izigilamkhuba ezintathu ngosuku e-US.

6. U-Emilio Mordini, isazi sefilosofi kanye nomqondo wezengqondo, waphikisa ngokuthi impikiswano yokuthi "akukho okufihlwayo" iyindida. Abantu abadingi ukuthi babe "nokuthile abakufihlayo" ukuze bakwazi ukufihla "okuthile". Okufihliwe akubalulekile, kusho uMordini. Esikhundleni salokho, uthi indawo esondelene kakhulu engafihlwa nokuvinjelwa ukufinyelela ayidingeki ngoba, ukukhuluma ngokwengqondo, siba ngabantu ngokutholwa ukuthi singafihla okuthile kwabanye.

7. UJulian Assange uthe "Akukabikho mpendulo ebulalayo. UJacob Appelbaum (@ioerror) unempendulo ehlakaniphile, ebuza abantu abasho lokhu ukuthi bamnikeze ifoni yabo ivuliwe bese behlisa amabhulukwe abo. Uhlobo lwami lalokho ukuthi, "Uma unesicefe ngakho-ke bekungafanele ukuthi sikhulume nawe, futhi kungafanele futhi kube omunye umuntu", kodwa ngokwefilosofi, impendulo yangempela yilena: Ukuqashwa kweMisa wushintsho olukhulu lwesakhiwo. Uma umphakathi uqhubeka kabi, kuyahamba ukuhamba nawe, noma ngabe ungumuntu oyisicefe kunabo bonke emhlabeni. "

8. U-Ignacio Cofone, uprofesa wezomthetho, uthi ingxabano iyiphutha ngokwemibandela yayo ngoba, noma nini lapho abantu bedalula imininingwane efanele kwabanye, badalula nemininingwane engabalulekile. Lolu lwazi olungabalulekile lunezindleko zobumfihlo futhi lungaholela kokunye ukulimala, njengokubandlululwa.

***

## Eminye imikhankaso elwa ne-Google

Lolu uhlu lweminye imikhankaso emelene ne-Google. Lolu hlu aluphelele. Ungasiza ngokunweba.

### Akusasebenzi

[Scroogled - NguMicrosoft (Novemba 2012 kuya ku-2014)] (https://en.wikipedia.org/wiki/Scroogled)

_Akukho okunye okufakiwe okwamanje._

### Kuyaqhubeka

_Lolu hlu okwamanje alunalutho._

***

## Ukubala ezinye izimpikiswano

Kunezimpikiswano ezithile abantu abazenzayo ukwenza i-Google isekele Enye yokuqala enkulu isivele ikhishwe [lapha] (# Ubumfihlo) kepha nansi eminye:

### Ukulula

Yebo, imikhiqizo yakwaGoogle ibonakala ilula. Kodwa-ke, uthengisa konke okuhle ukuze kube lula, kufaka phakathi ukuphepha, ubumfihlo nokuthembeka. I-Google ibilokhu iba nzima ngaphezu kweminyaka, futhi amaseva abo ehle kakhulu ngokuya. Njengamanje, amaseva weGoogle ehla cishe ihora izikhathi ezingu-1-2 ngenyanga (ikakhulukazi i-YouTube)

Ngeshwa, ngenxa yemiphakathi ethembele kuGoogle, iGoogle isizobusa i-Intanethi, futhi ifuna ukulawula kakhulu. Ngo-2012, lapho i-Google yehla imizuzu engu-5, kwabikwa ukuthi i-** global ** traffic traffic ** yehle ngo-40% ** i-Google yehla njalo amahora angu-1-2, futhi [ngokudubula kweqembu labo lokuziphatha] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) phakathi kwezinye izinto, zizoncipha.

Ukulula akuyona into enhle ngaso sonke isikhathi. Kufanele wazi ukuthi kwenzekani futhi uzilungiselele lapho zehla, ngoba ayikho indlela yokuthi isiphakeli singabi phansi njalo ngezikhathi ezithile.

I-Google nayo ayilula ngendlela ocabanga ngayo. Kunamanye amasayithi alula kakhulu. IGoogle ayikulungele neze, uma ubala ukumiswa kwe-akhawunti yabo engahleliwe nokupheliswa ngaphandle kwempendulo (ngaphandle kokuthi unake ngokwanele i-akhawunti ye-Google twitter noma ubamangalele ngo- $ 100,000,000 noma ngaphezulu) lapho-ke bakusizile, bakudlalisa, futhi ikuphoqe ukuthi umemezele emcamelweni, lapho kungekho noyedwa ongezwa ukukhala kwakhoukuthola usizo.

### Kungani kunendaba, sekwephuze kakhulu nganoma iyiphi indlela

Le mpikiswano engajwayelekile, kepha idinga incazelo. Isimo esikhona njengamanje, ohulumeni abaningi bomhlaba, kanye nezinhlangano eziningana ezinamandla kubonakala sengathi bazi konke okwenzayo, ngakho-ke kungani uzihlupha ngokusuka kuso? Impendulo ilula: ** ufanelwe okungcono **. Uma ukwazi ukusuka kubo njengamanje, kunzima kubo ukulandelela ukuhamba kwakho ngokuqhubekayo, futhi ungakha impilo entsha eyimfihlo.

[1 umthombo] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Kodwa-ke, bengilokhu nginikela umklomelo wami wamahhala we-Reddit kulokhu okuthunyelwe njalo uma ngiwuthola isikhathi esingaphezu kwesonto manje (kanye nazo zonke izinhlamvu zemali zami ezingama-500 zamahhala) ukukhulisa lesi sihloko ngokuqhubekayo. Kuze kube manje, nginike lo msebenzi ngaphezulu kwemiklomelo yamahhala engu-14. Akukuningi, kepha izinto ezincane zingenza umthelela omkhulu, kuya ngokuthi kubonwa kanjani, nokuthi ngubani.

### Okunye

Anginazo ezinye izimpikiswano okwamanje.

_Lolu hlu aluphelele_

***

## Imithombo

Kopisha:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / yonke-idatha-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit))ss (( https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spy-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he idatha ye-alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Ukugxekwa) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -izibonelo / lutho-ukufihla-ukuphikisana-akanalutho-lokuzisho /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- idatha-mayelana nawe-ungayithola futhi uyisuse-manje /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -izimele-idatha-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -futhi [c] (https://www.wired.com/story/google-tracks-you -ubumfihlo /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)letondhttps: //www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)letono-https://en.wikipedia.org/wiki/2018_Google_data_breach)inglymimele(https://:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- izimangalo-ze-ze-5-million-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)letone-https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / ulwazikwi-technology / 2014/01 / yini-i-google-engenza ngempela-nge-isidleke-noma-empeleni-izidleke-zedatha /) [i] (https://www.cbsnews.com/news/google-education -i-spy-on-eqoqa-idatha-ezigidini-zezingane-izinsolo-zokumangalelwa-okusha-mexico-ummeli-jikelele /) [v] (https://www.nationalreview.com/2018/04/the- i-Student-data-mining-scandal-under-our-nose /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)letony /(https://medium.com/@hansdezwart/during-world-war-ii- we-did -utho-okufihlekile-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Eminye imithombo:

[Amehlo amahlanu Alliance] (https://en.wikipedia.org/wiki/Five_Eyes) [Amashumi ayisishiyagalolunye nesishiyagalombili namane] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Landa izixhumanisi

[Thola iFirefox] (https://www.mozilla.org/en-US/firefox/new/) [Thola isiphequluli se-Tor] (https://www.torproject.org/download/) [Okunye / akutholakali] (https : //www.example.com)

***

## Ukuhlangenwe nakho kwami ​​kokuzithoba

Ekugcineni ngiqale ukubona izinkinga nge-tech enkulu ku-2018, futhi ngaqala ukuzithoba. Ezinyangeni ezimbalwa zokuqala, ngathuthuka kakhulu. Kwehla ijubane elikhulu kakhulu kusukela lapho.


### Engikushintshe kusuka

I-Google Chrome -> Firefox / Tor

Usesho lwe-Google -> I-DuckDuckGo (okuzenzakalelayo) / i-Ecosia (lapho ngizizwa ngiyithanda) / i-Bing (kuyaqabukela)

I-GMail - iProtonMail (ayikashintshwa ngokuphelele)

Amasayithi weGoogle -> Ukuzibamba (akukashintshwa ngokuphelele)

I-Google + -> Akukaze kusetshenziswe kangako, izisuse ngenxa yokuvalwa kwayo

I-Google Amadokhumenti -> Ayikaze isetshenziswe, ngisebenzisa iMicrosoft Word 2013 (ngaphambi kuka-2019) neLibreOffice (2019 kuya phambili) esikhundleni salokho.

I-Google AmaSpredishithi -> Ayikaze isetshenziswe, ngisebenzisa iMicrosoft Excel 2013 (ngaphambi kuka-2019) neLibreOffice (2019 kuya phambili) esikhundleni salokho.

I-Google Amaslayidi -> Ayikaze isetshenziswe, ngisebenzisa iMicrosoft PowerPoint 2013 (ngaphambi kuka-2019) neLibreOffice (2019 kuya phambili) esikhundleni salokho.

Imidwebo yeGoogle -> Ayikaze isetshenziswe, ngisebenzisa i-LibreOffice (2019-phambili) esikhundleni.

IGerrit -> Ayikaze isetshenziswe, ngisebenzisa iGitHub (okuzenzakalelayo kwamanje), iGitLab, iBitBucket, neSourceForge esikhundleni salokho.

Izithombe ze-Google -> Akukaze kusetshenziswe

I-Google Drayivu -> OneDrive (2019-2020) i-Degoo (2020-2020) pCloud (2020-present)

I-Google Amamephu -> OpenStreetMaps / Apple Maps

Iya - Ukwenza okuhlukile, kepha ungasebenzisi njengolimi olusebenzayo lokuhlela

I-Dart - Ukwenza okuhlukile, kepha kungasebenzisi njengolimi olusebenzayo lokuhlela

I-Flutter - Ukwenza okuhlukile, kepha hhayi ukusebenzisa njengolimi olusebenzayo lohlelo

I-Google Earth -> OpenStreetMaps / Apple Maps

I-Google Streetview -> Angikaze ngiyisebenzise, ​​ngiyithola ishaqa ngokwengeziwe

I-Google Fi -> Ayikaze isetshenziswe

I-Google Khalenda -> Ayikaze isetshenziswe

I-Google calculator -> Ngokwemvelo noma yiluphi olunye uhlelo lokusebenza lokubala, noma i-Linux terminal esebenza ngemodi yePython uma ngizizwa ngiyithanda

I-Google Nest -> Ayikaze isetshenziswe

I-Google AMP -> Ayikaze isetshenziswe

I-Google VPN -> Ayikaze isetshenziswe, futhi i-oxymoron

I-Google Pay -> Ayikaze isetshenziswe

I-Google Summer of Code -> Ayikaze ibambe iqhaza

I-Tenor -> Amanye amasayithi we-GIF, yize ama-GIF engabalulekile kakhulu kimi. Imvamisa ngithola amafayela we-GIF kusuka ezithombeni zeDuckDuckGo, i-Imgur, iReddit, noma amanye amasayithi.

I-Blockly -> Ayisasetshenziswa, awunasiqiniseko sokuthi i-Scratch iqale ngqo ngokuvimba. Ngaba ngumqambi wohlelo osebenzayo ngo-2017 kuya phambili, ngakhula ngeScratch.

I-GBoard -> Isetshenziswe kanye, kepha ishiywe

I-Google Glass -> Ayikaze isetshenziswe, ibhekwe njengengane encane kepha yanquma ukungayitholi / ngiyisebenzise uma nginenketho

_Uhlu kungenzeka lungaphelele._

# # # Imikhiqizo engingakwazi ukusuka kuyo

Kusukela ngoFebhuwari 25th 2021, le yimikhiqizo yakwaGoogle engivimba ukuthi ngingazibhali phansi ngokuphelele:

1. I-YouTube

2.I-Android

3. Isitolo se-Google Play

4.I-GMail (yesikole kanye namanye amasayithi)

5.I-Google Classroom (yesikole kuphela)

6.I-Google Translate

7. I-Akhawunti ye-Google

8. I-Google Sites (njengoba i-Google yephula imithetho ye-GDPR (futhi ingabhekana nenye inhlawulo engu- € 5,000,000.00 ize iyilungise) futhi ivimbela ukulandwa kwalo mkhiqizo)

Ngiyekile ekuxhumaneni nakho konke okunye.

***

## Ukuhamba kubi

IGoogle yashayela ngolimi lokuhlela olususelwe ku-2003 Agent Based `` Go! `Ngolimi lwabo lokuhlela` `Go` (kusuka ngo-2009, eminyakeni eyi-6 kamuva) futhi bathi ulimi lwabo ngeke luthinte nolunye ulimi. AbakwaGoogle bagxekwa kakhulu ngalokhu, njengoba isiqubulo sabo esithi `` Ungabi mubi '' besisasebenza ngaleso sikhathi, futhi lesi ngesinye sezigameko eziningi ezenze ukuthi i-Motto engeyona embi ithathe umhlalaphansi.

Ekugcineni, ukuthuthukiswa kwe- `Go!` Kwaphela, ngenkathi u-`Go` kwaya ngokuya kwanda. AbakwaGoogle bathi ngeke baphambuke uma bethi `` Go! `Kodwa ekugcineni, bakwenza lokho, babaleka (kusukela ngomhlaka 9 Ephreli 2021)

[Funda kabanzi ngeGo nokuthi ungashintsha kanjani lapha] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Ukusetshenziswa kwe-DRM

I-Google isebenzisa i-DRM (Digital Imikhawulo Management) ngesevisi ye-WideVine DRM "nezinye izindlela. Inhloso ye-DRM ukubhubhisa i-Intanethi evulekile nokunikeza izinkampani amandla okuzibophezela kubasebenzisi. Kufanele ulahle iWideVine ngokuphelele, noma ngabe kubiza malini.

[Funda kabanzi ngeWideVine nezinkinga zayo lapha] (https://github.com/Degoogle-your-life/Its-time-ukusika-WideVine-DRM)

***

## Imibono eyiphutha ejwayelekile

Lolu uhlu lweminye imibono evamile eyiphutha ngemikhiqizo yakwa-Google.

### I-Google akuyona i-Intanethi

Ukusesha kweGoogle / Google akuyona i-Intanethi, ukusesha kweGoogle kumane kuyinjini yokusesha, okufana nokuthi akuyona yonke imidlalo yesikhulumi seNintendo eyenziwe yiNintendo, kepha inikezwe ilayisensi yiNintendo, kepha ngezinga elikhulu kakhulu. Ukube wonke amaseva weGoogles angabhujiswa ngasikhathi sinye njengamanje, ama-Google Sites afana ne-YouTube, i-Gmail, i-Google Amadokhumenti, usesho lwe-Google, njll. Angabe engasekho, kepha iningi le-Intanethi ngabe lisekhona (Wikipedia, Stackoverflow, GitHub wonke amawebhusayithi eMicrosofts, i-NYTimes, i-Samsung, i-TikTok, njll.) angahle alahlekelwe ukungena kwawo kwe-Google nokusebenza kokuhlaziya, kepha asazosebenza (ngaphandle kokuthi ahlelwe kabi futhi athembele ngqo kuGoogle)

***

## I-Internet Explorer 6 ne-Chrome

I-Google Chrome iba yi-Internet Explorer entsha 6. Ngenkathi iGoogle Chrome iphuma ekuqaleni, iFirefox ibiyisiphequluli esivelele, futhi ibulale kakhulu i-Internet Explorers markethare (eyeqa ama-96% ngaphambi kokuba izigidi zabantu zishintshele kuFirefox nakwezinye iziphequluli) lapho iGoogle Chrome iphumile, abantu bashintshiwe ngenxa yejubane layo futhi bekuyi-Google (ebingathathwa njengokubi ngaleso sikhathi, njengoba izingqinamba eziningi zobumfihlo bezingakaveli) iGoogle Chrome ekuqaleni yayihlonipha izindinganiso zewebhu (okuyilokho okwenziwa yiFirefox eyabulala i-Internet Explorers 96% ye-browser share), kepha, njengoba i-Google Chromes markethare inyuka, iGoogle iqale ukususa izici eziningi, ifaka i-spyware eyengeziwe, futhi yeka ukwamukela izindinganiso zewebhu, iGoogle Chrome isibe yi-Internet Explorer 6 entsha.

Inkinga enkulu njengamanje amawebhusayithi ayi-Chrome kuphela, futhi angeke asebenze kwezinye iziphequluli, njengoba onjiniyela bawo benqume ukuthi abafuni abanye abasebenzisi be-Intanethi abangama-30-40% abangasebenzisi i-Chrome ukusebenzisa isayithi labo.

Ngisho neGoogle uqobo lwenza amasayithi abo abe yi-Chrome kuphela. Isibonelo, usesho lwe-Google luzokwazisa ukuthi ulande i-Chrome amahlandla ama-3 njalo ngemizuzwana eyi-10 uma ithola ukuthi awusebenzisi i-Google Chrome (nezinye iziphequluli ezisuselwa kuChromium ezifana neBrave ziyathinteka) namasayithi afana neGoogle Earth awavumeli abasebenzisi beFirefox sebenzisa isayithi labo (kusukela ngo-2020) kanye ne-Google Translate ayikusekeli ukufakwa kwezwi kuFirefox, nezinye iziphequluli ezingezona eze-Google Chrome.

### Inkinga nge-Brave

Ezinye iziphequluli ezisuselwe kuChromium, njengeBrave neMicrosoft Edge azinayo ngokuphelele i-spyware yeGoogle. I-Brave ivame ukunconywa uhlangothi olungalungile lomphakathi wobumfihlo, kepha iBrave kuseseyinkinga, njengoba isebenzisa iChromium. I-Intanethi akufanele ibe neziphequluli zeChromium kuphela, kufanele kube nezinhlobonhlobo zokuzikhethela. Isibindi kuyindlela engafanele yokuhamba.

[Funda kabanzi mayelana nokwenziwa kwe-degoogling kusuka ku-Google Chrome / i-Chromium lapha] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Funda kabanzi mayelana nokuzikhipha ku-ChromeOS / ChromiumOS (ama-Chromebook / ama-Chromebox / ama-Chromeblets / ama-ChromeBits / ama-ChromeETC) lapha] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Ukuvuselelwa kobumfihlo be-Faux

I-Google ibilokhu izama ukutshela umhlaba ukuthi iyabakhathalela ubumfihlo, ngemuva kokuthi bese kwephuzile kakhulu. Baqhubeka bethi bayayihlonipha imfihlo yabasebenzisi, kepha abalungisi zonke izinkinga zabo zobumfihlo.

### Umthombo ovulekile awunakukhetha

Umthombo ovulekile awukwazi ukukhetha. I-Google iwubufakazi balokhu. Yonke ingcosana ne-byte yekhodi yomthombo kufanele ibonakale emphakathini, kungabikho ngisho ne-8 ye-byte efihliwe.

Amaphrojekthi afana ne-Android ne-ChromeOS angumthombo ovulekile ngokwengxenye, kepha aqukethe iningi lobunikazi, ama-spyware element.

### I-Oxymoron

I-Google VPN iyi-oxymoron. I-Google ayinandaba nobumfihlo, futhi i-Virtual Private Network (i-VPN) evela enkampanini enjengalezi kungaba enye yezinqumo ezimbi kakhulu zensizakalo ye-VPN.

***

## Ukusebenza kabi

I-Google ayinandaba nokusebenza kwemikhiqizo yabo okungenani i-2017, njengoba isoftware yabo yokugcina yokwenza uphawu (i-Google Octane) inqanyulwe ngo-2017.

***

## Ukuphathwa kabi kwephrojekthi

IGoogle inohlelo olubi kakhulu lwangaphakathi lokuphathwa kwephrojekthi. Ezinye izibonelo ezijwayelekile zezinhlelo ezehliswe ngokwengeziwe zifaka i-Google Duo nomculo we-YouTube (ngaphambili i-Google Play Music)

Kuhlelo lokuthuthukiswa kwangaphakathi lweGoogles, uhlelo lokusebenza olu-1 luholela kolunye uhlelo lokusebenza olunengxenye yokusebenza, khona-ke uhlelo lokusebenza lokuqala luyasuswa. Ngemuva kweminyaka embalwa, kwenziwa uhlelo lokusebenza olusha olunokusebenza okuncane okungu-75%, bese kususwa uhlelo lokusebenza olunokusebenza okungu-50%, lulandelwe uhlelo lokusebenza olusha olunokusebenza okungu-87.5%, bese uhlelo lokusebenza olunokusebenza okungu-75% luyekile , njalo njalo.

***

## Ukulinganiswa okwethusayo noma okungekho kwezinsizakalo

I-YouTube iyisibonelo esivame kakhulu emhlabeni sokulinganisela okungalungile okudala inkundla embi kunazo zonke ezikhona. I-Google nayo kubonakala ngathi ayitholi ukuthi i-YouTube akuyona izingane ze-YouTube.

Okwe-YouTube, okuqukethwe okunenzondo kwe-pro-Nazi ne-White Supremacist kunikezelwa kubasebenzisi ngenhloso yesikhathi esengeziwe sokuzibandakanya nemali eningi. I-Google nayo yenze okuthileizinto eziwubuphukuphuku ngokulinganisela kwabo, njengokuvuma ividiyo ye-Christian Anal Sex njengokuqukethwe `okwenzelwe izingane` ngesikhathi esifanayo iminyaka ikhawulela ividiyo. Akuvamile futhi ukubona izikhangiso zocansi noma ezesabekayo zilungile ngaphansi kwevidiyo ye-Baby Shark, kanye nokunye okuhlukahlukene okwenzelwe okuqukethwe izingane.

Abasebenzisi be-YouTube bakhala kaningi ngokweqile ngokulinganiswa okungalungile ku-YouTube kokuqukethwe okungalungile (njengezibonelo ezibalwe ngenhla) ngenkathi abasebenzisi bengenza amavidiyo abo asuswe ngokungahleliwe ngaphandle kwesizathu bengenamandla okuphelisa, kanye nabasebenzisi abajeziswa nganoma iyiphi indlela yokufunga, ngisho namacala amancane kakhulu athi abasebenzisi be-crap` bavamise ukuqhathanisa i-YouTube ne- [Soviet Union] (https://en.wikipedia.org/wiki/Soviet_Union) ngesikhathi sikaStalin, ngenxa yalezi zijeziso ezingalingani.

Ngo-2021, abakwaGoogle bamemezele ukuthi bazofaka izikhangiso kuwo wonke amavidiyo, yize ividiyo isenziwa amademoni (ukuze iGoogle yenze imali, kepha umakhi akahambisani) lokhu akuhambisani nokulinganisela kakhulu, kepha kubalulekile ukuqaphela.

I-YouTube iyamodareyithwa (noma ngabe yimbi kakhulu) kepha insizakalo yezikhangiso yakwaGoogle ebenza babe nemali eningi kubonakala ingenakho ukulinganiswa okuncane.

[Funda kabanzi ngezinkinga zokulinganisela ze-YouTube nokuthi ungayishintsha kanjani i-YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Izikhangiso ze-Google Play zenziwa kusuka emapulazini e-bot, ungabona ngezimo ezifanayo zesikhangiso ezisetshenziswa amakhulukhulu ezinkampani ezinoshintsho oluncane, futhi azihlobene nomkhiqizo (izibonelo ezivamile: i-Playrix (i-Homescapes, i-Gardenscapes) i-Fishdom, i-Mafia City, ne izinkulungwane ezengeziwe) kanye nomkhuba omubi okhulayo wezikhangiso ezithi abasebenzisi bangazuza imali ngokudlala imidlalo, ngokulalela umculo, njll. I-PayPal ayikaphawuli ngalokhu, kepha kusobala ukuthi lona ngumkhonyovu, sengathi ungakwenza ngaphezulu kwama- $ 10,000 ngemizuzwana engaphansi kwengu-20 ngokudlala umdlalo oqinisekisiwe, akekho ozobe enza umsebenzi futhi ngabe wenza lokhu esikhundleni salokho, okuyinto engenakwenzeka, futhi ibhizinisi belingeke lisebenze kanjena. Lo mkhonyovu osobala ubukhula ngamandla kusukela ngo-2019, futhi manje amapulazi e-bot akhiqiza lezi zikhangiso alwa wodwa ezikhangisweni zawo.

Izikhangiso eziningana nazo zihlambalaza kakhulu, futhi zizama ukuthola abasebenzisi (iningi labo okungabasebenzisi abangaphansi kweminyaka engu-13, noma ama-bots) ukuthi bachofoze ngokukhohlisa ngokocansi.

Izinhlelo zokusebenza eziningi zisebenzisa ama-bots ne-astroturf imikhiqizo yazo, ngakho-ke noma nini lapho kwenziwa ukubuyekezwa okungalungile, ama-akhawunti we-sock puppet bot azoqala ukuthumela ukubuyekezwa kwezinkanyezi ezi-5 futhi azame ukuphikisa ukugxeka kwakho. [I-Google nayo iyakwenza lokhu] (# Astroturfing)

[Funda kabanzi ngezinkinga nge-Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Ukuhlola izinkanyezi

Ukuchazwa okujwayelekile [(kusuka ku-Wikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

``
I-Astroturfing umkhuba wokufihla abaxhasi bomlayezo noma inhlangano (isb., Ezepolitiki, ezokukhangisa, ezobudlelwano benkolo noma ezomphakathi) ukuyenza ibonakale sengathi ivela futhi isekelwa ababambiqhaza abaphansi. Kungumkhuba ohlose ukunika izitatimende noma izinhlangano ukuthembeka ngokugodla ulwazi olumayelana nokuxhumeka kwezezimali komthombo. Igama elithi astroturfing lisuselwa ku-AstroTurf, umkhiqizo wokhaphethi wokwenziwa owenzelwe ukufana notshani bemvelo, njengomdlalo egameni elithi "grassroots". Okushiwo ekusetshenzisweni kwaleli gama ukuthi esikhundleni somzamo osisekelo "weqiniso" noma "wemvelo" ngemuva kwalowo msebenzi okukhulunywa ngawo, kunokubukeka kokwesekwa "okungamanga" noma "okwenziwe".
``

I-Google inomlando we-astroturfing ukwenza kubonakale sengathi abenzi lutho olubi (ngaleyo ndlela, i-astroturfing imbi) ngokwesibonelo, ukuthumela ukugxekwa kwe-Google kungxenyekazi efana ne-Twitter (ene-akhawunti yayo) kuzoholela ama-akhawunti amaningi abekhona isikhashana kodwa angakaze afakwe ngaphambi kokuphuma futhi athi lokho okushilo kungamanga, bese uthi i-Google iyinkampani ehamba phambili, kepha kwenziwe ngendlela yokuthi kungabonakali ukuthi lawa ama-bots kakhulu abantu.

***

## Izenzo zebhizinisi ezingekho emthethweni futhi ezingekho emthethweni

I-Google isebenzisa izindlela zebhizinisi ezingekho emthethweni nezingenasimiso ukuqhubekisela phambili ukuzimela, njengokusebenzisa izindawo zokuthelisa, ukukhipha imisebenzi, nokuqhubeka nokwenza izinto ezingekho emthethweni njengezindleko zokwenza ibhizinisi.

### EYurophu

IYurophu ihlale imangalela iGoogle, icala elikhulu kakhulu liphikisana nokuziphatha okungekho emthethweni ku-Android, okuholele ekutheni iGoogle ithole i- € 5,000,000,000 (elingana ne- $ 5,947,083,703.68 ngo-Ephreli 9th 2021 imali)

### ENyakatho Melika

Izwe laseMelika alikakhokhi inhlawulo cishe eyanele kuGoogle okwamanje, uma kuqhathaniswa nenhlawulo ye-Europes € 5,000,000,000.

### Izingxabano

IGoogle ayinendaba nenkinga ize idale impikiswano, lapho-ke bazokwenza umzamo omubi wokuyilungisa, ngokwanele ukuthi impikiswano isuke okwesikhashana, bese inkinga iba yimbi ngokwedlulele ize idale enye impikiswano, bese umjikelezo uyaqhubeka. Abakhathaleli ngokwanele ukuthi benze noma yini ebucayi ngakho.

***

# # I-Google izenzakalelayo

Njenge comI-pany, iGoogle izisebenzele kakhulu, inokulinganisela okuncane kune-automation.

Inkampani akufanele ibe nemishini ezenzakalelayo ngokuphelele. IGoogle iyisibonelo salokhu. Ukulinganisela kuyesabeka uma kwenziwa yi-AI kuphela, i-YouTube iyisibonelo esihle, noma ngabe kunabantu abambalwa (abangamakhulu, noma mhlawumbe abayinkulungwane) abalinganisa isayithi, lapho kubonakala sengathi kubi kakhulu ukuthi iningi labo kumele lithole ukwelashwa ngenkathi lisebenza.

***

# # I-Android

I-Android iphethwe i-Google. Ingxenye ye-Open Handset Alliance (ebingakaze ivulwe kusukela ku-Android) i-Android isibe elinye iphuzu lokuzimela le-Google, futhi okunzima kakhulu ukubalekela.

I-Android ibikwe ukuthi ifonele ekhaya kuGoogle okungenani ama-10 ngosuku, futhi yize ingumthombo ovulekile kancane, isebenza kakhulu njenge-spyware.

Amaphrojekthi amaningi enziwe ukuze ashintshe kusuka ku-Android, kepha adinga ukhula lwenkohlakalo egcwele idivayisi yakho. Lokhu kumane nje akunakwenzeka ngocingo oluthile lwe-Samsung e-US, ngenxa yeKnox DRM. Izindlela ezivamile zokungena ku-Android zifaka phakathi i-iOS, i-iPadOS, i-LineageOS, i-Android x86, i-Ubuntu Touch, ne-PiPhone (i-Pi Phone wuhlobo lwamafoni asebenzisa izinhlelo ezahlukahlukene ze-Linux kuselula, njenge-Fedora, Ubuntu, Arch, njll.)

[Bona ucwaningo lwami ngokuthola umshini we-Android osetshenzisiwe osetshenzisiwe] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Bona ukuthi ungasusa kanjani i-google ku-Android] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Izenzo ezincane zokusiza

Ukusabalalisa ukuqwashisa ngayo yonke indlela ongakwenza ngayo kubalulekile. Kimi, angikhulumi nje kuphela ngokudonswa phansi, nokubhala izindatshana, kepha futhi nginomkhuba omncane omncane, lapho nginikeza khona umklomelo wami wansuku zonke wamahhala weReddit kokuthunyelwe okuphiniwe ku-r / degoogle ukuqwashisa. Kuze kube manje, sengikhiphe cishe imiklomelo engama-30 kokuthunyelwe okuphiniwe (ngiphinde ngachitha izinhlamvu zemali zami ezingama-500 zamahhala emiklomelweni eyi-10 yalokho okuthunyelwe)

***

## Akuthembeki

I-Google ayinakwethenjwa, futhi ngeke iphinde ithenjwe. Bayekile ngokuphelele ekutheni "ungabi mubi" (babehlala bekhohlakele) baye ekubeni babi ngokuphelele futhi bengazami ukukufihla.

***

## Ezinye izinto ozozihlola

[Amathuna eGoogle (killbygoogle.com) - uhlu oluhleliwe lwemikhiqizo engama-224 + i-Google eyibulele] (https://killedbygoogle.com/)

> [Isixhumanisi seGitHub] (https://github.com/codyogden/killedbygoogle)

[Inyunyana yezinhlamvu zamagama - Inyunyana entsha yabasebenzi kwaGoogle enamalungu angaphezu kuka-800] (https://alphabetworkersunion.org/people/our-union/)

[Awufuni ukuhlukana neqanda lephasika le-dinosaur? Le webhusayithi uyimbozile] (https://chromedino.com/)

Kukhona ezinye izindlela, vele uzifune.

***

Ukuhlola amanye amaqiniso kuyadingeka kule ndatshana

***

# # Imininingwane yefayela

Uhlobo lwefayela: `Markdown (* .md)`

Ukubalwa kolayini (kufaka phakathi imigqa engenalutho nomugqa wokuhlanganisa): `968`

Uhlobo lwefayela: `6 (NgeSonto, Ephreli 18th 2021 ngo-4: 18 ntambama)`

***

# # # Isimo sesoftware

Yonke imisebenzi yami imahhala eminye imikhawulo. I-DRM (** D ** igital ** R ** estrictions ** M ** anagement) ayikho kunoma yimuphi umsebenzi wami.

! [I-DRM-free_label.en.svg] (i-DRM-free_label.en.svg)

Lesi sitika sisekelwa yiFree Software Foundation. Angikaze ngihlose ukufaka i-DRM emisebenzini yami.

Ngisebenzisa isifinyezo esithi "Ukuphathwa Kwemikhawulo Yedijithali" esikhundleni se- "Digital Rights Management" esaziwa kakhulu njengoba indlela ejwayelekile yokubhekana nayo ingamanga, awekho amalungelo ane-DRM. Isipelingi "Ukuphathwa Kwemikhawulo Yedijithali" sinembe kakhudlwana, futhi sisekelwa ngu- [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) kanye ne- [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Lesi sigaba sisetshenziselwa ukuqwashisa ngezinkinga nge-DRM, nokuphikisana nayo. I-DRM inamaphutha ngokwakhiwa futhi iyingozi enkulu kubo bonke abasebenzisi bekhompyutha kanye nenkululeko yesoftware.

Isikweletu sesithombe: [defectivebydesign.org/drm-free/...] (https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

# # Imininingwane yomxhasi

! [SponsorButton.png] (SponsorButton.png) <- Ungachofozi le nkinobho, ayisebenzi, iyisithombe nje. Inkinobho yangempela iphezulu kwekhasi ngakwesokudla (<- L ** R ** ->) ekhoneni

Ungaxhasa le phrojekthi uma uthanda, kodwa sicela ucacise ukuthi ufuna ukunikela kuphi. [Bona izimali onganikela ngazo lapha) (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Ungabuka eminye imininingwane yabaxhasi [lapha] (https://github.com/seanpm2001/Sponsor-info/)

Izame! Inkinobho yabaxhasi ilungile eduze kwenkinobho yokubuka / yokuqaqa.

***

# # Umlando wefayela



 * Kuqale ifayili

> * Kungezwe isigaba sesihloko

> * Kungezwe inkomba

> * Kungezwe isigaba mayelana

> * Kungezwe isigaba se-Wiki

> * Kungezwe isigaba somlando wenguqulo

> * Kungezwe isigaba sezinkinga.

> * Kungezwe isigaba sezinkinga ezedlule

> * Kungezwe isigaba sezicelo zokudonsa esedlule

> * Kungezwe isigaba sezicelo sokudonsa esisebenzayo

> * Kungezwe isigaba sabanikeli

> * Kungezwe isigaba esinikelayo

> * Kungezwe isigaba mayelana ne- README

> * Kungezwe isigaba somlando wenguqulo ye-README

> * Kungezwe isigaba sezinsizakusebenza

> * Kungezwe isigaba sesimo sesoftware, nesitika samahhala se-DRM nomyalezo

> *Kungezwe isigaba semininingwane yabaxhasi

> * Azikho ezinye izinguquko enguqulweni engu-0.1

Inguqulo 1 (NgoLwesihlanu, ngoFebhuwari 19, 2021 ngo-5: 20 ntambama)

> Izinguquko:

> * Kuqale ifayili

> * Kungezwe isigaba sencazelo eyisisekelo

> * Kungezwe isigaba sencazelo yokugcina

> * Kungezwe uhlu lwama-athikili, nokufakiwe okungu-14

>> * Kungezwe isigaba `sezindatshana ezihlobene`

>> * Kungezwe isigaba esithi `see also`

> * Kungezwe isigaba semininingwane yefayela

> * Kungezwe isigaba somlando wefayela

> * Kungezwe unyaweni

> * Azikho ezinye izinguquko enguqulweni 1

I-Version 2 (NgoLwesihlanu, ngoFebhuwari 19 2021 ngo-5: 26 ntambama)

> Izinguquko:

> * Kungezwe isigaba sesimo sokuhumusha

> * Wengeze ezinye izinto ukuhlola isigaba

> * Kungezwe isigaba semfihlo

> * Kungezwe inkomba

> * Kungezwe isigatshana sesimo sesoftware

> * Kungezwe esinye isigaba semikhankaso elwa ne-Google

>> * Kungezwe isigatshana esingasebenzi

>> * Kungezwe isigatshana esiqhubekayo

> * Kungezwe isigaba semithombo

> * Kungezwe isigaba sezixhumanisi zokulanda

> * Kubuyekezwe isigaba semininingwane yefayela

> * Kubuyekezwe isigaba somlando wefayela

> * Azikho ezinye izinguquko enguqulweni 2

Uhlobo 3 (NgoLwesithathu, Februwari 24th 2021 ngo-7: 56 pm)

> Izinguquko:

> * Kubuyekezwe inkomba

> * Ikhombe isithonjana se-degoogle nenhlangano entsha ye-GitHub

> * Kungezwe izixhumanisi kuma-athikili amasha

> * Kungezwe isigaba esiphikisayo sezinye izimpikiswano

>> * Kungezwe isigatshana esilula

>> * Kungezwe isigatshana esithi Kungani ngisho nokukhathazeka

>> * Kungezwe esinye isigatshana

> * Kubuyekezwe eminye imininingwane

> * Kubuyekezwe isigaba semininingwane yefayela

> * Kubuyekezwe isigaba somlando wefayela

> * Azikho ezinye izinguquko enguqulweni 3

Inguqulo 4 (ngolwesibili, ngoFebhuwari 25, 2021 ngo-9: 31 ntambama)

> Izinguquko:

> * Kungezwe izixhumanisi kuma-athikili amasha ayi-10

> * Kungezwe isigaba mayelana nokuhlangenwe nakho kwami ​​kokuzilolonga

> * Kubuyekezwe inkomba

> * Kubuyekezwe isigaba semininingwane yefayela

> * Kubuyekezwe isigaba somlando wefayela

> * Azikho ezinye izinguquko kunguqulo 4

Inguqulo 5 (NgoLwesihlanu, Ephreli 9th 2021 ngo-6: 02 pm)

_Kube nokushoda kokuvuselelwa kwenhlangano elwa neGoogle kusuka kimi muva nje, ngisebenzela ukubuyela kuyo ngemuva kwenyanga engu-1 + hiatus._

> Izinguquko:

> * Kubuyekezwe isigaba sesihloko

> * Kubuyekezwe inkomba

> * Kubuyekezwe uhlu lwezilimi: izixhumanisi ezihleliwe, futhi kungezwe izilimi eziningi ezisekelwayo

> * Kubuyekezwe isigaba sesimo se-athikili, singeza izixhumanisi ezi-4 zemfoloko

> * Kubuyekezwe isigaba sesimo sesoftware

> * Kungezwe isigaba Go esibi

> * Kungezwe Ukusetshenziswa kwesigaba se-DRM

> * Kungezwe isigaba semibono ejwayelekile eyiphutha

>> * Kungezwe iGoogle akuyona isigatshana se-Intanethi

> * Kungezwe isigaba se-Internet Explorer 6 ne-Chrome

>> * Kungezwe inkinga ngesigatshana seBrave

> * Kungezwe ukususwa kobumfihlo kweFaux

> * Kungezwe umthombo ovulekile awukwazi ukuba yisigatshana esinqunyelwe

> * Kungezwe isigatshana se-Oxymoron

> * Kungezwe isigaba sokusebenza Okubi

> * Kungezwe isigaba sokuphathwa kwephrojekthi esibi

> * Kungezwe isigaba esethusayo noma esingesihle sezinsizakalo

> * Kungezwe isigaba se-Astroturfing

> * Wengeze isigaba semikhuba yebhizinisi engekho emthethweni futhi engekho emthethweni

> * Kungezwe isigatshana sase-Europe

>> * Kungezwe isigatshana EsiseNyakatho Melika

>> * Kungezwe isigatshana sezingxabano

> * Kungezwe isigaba esizenzakalelayo seGoogle

> * Kungezwe isigaba se-Android

> * Kungezwe izenzo ezincane ukusiza isigaba

> * Kungezwe isigaba Esingathembeki

> * Kungezwe isigaba semininingwane yomxhasi

> * Kubuyekezwe unyaweni

> * Kubuyekezwe isigaba semininingwane yefayela

> * Kubuyekezwe isigaba somlando wefayela

> * Azikho ezinye izinguquko enguqulweni 5

I-Version 6 (ngeSonto, Ephreli 18th 2021 ngo-4: 18 pm)

> Izinguquko:

> * Kubuyekezwe inkomba

> * Kungezwe incazelo yokubuka konke

> * Imininingwane yesimo sendatshana ebuyekeziwe

> * Kungezwe isixhumanisi ku-athikili entsha ye-Google FLoC

> * Wengeze isixhumanisi ku-athikili ye-Wuest 3n Fuchs Degoogle nemininingwane ejwayelekile kuso

> * Kubuyekezwe isigaba semininingwane yefayela

> * Kubuyekezwe isigaba somlando wefayela

> * Azikho ezinye izinguquko enguqulweni 6

Inguqulo 7 (Iyeza maduze)

> Izinguquko:

> * Iyeza maduze

> * Azikho ezinye izinguquko enguqulweni 7

Inguqulo 8 (Iyeza maduze)

> Izinguquko:

> * Iyeza maduze

> * Azikho ezinye izinguquko enguqulweni 8

Inguqulo 9 (Iyeza maduze)

> Izinguquko:

> * Iyeza maduze

> * Azikho ezinye izinguquko enguqulweni 9

Inguqulo 10 (Iyeza maduze)

> Izinguquko:

> * Iyeza maduze

> * Azikho ezinye izinguquko enguqulweni 10

Inguqulo 11 (Iyeza maduze)

> Izinguquko:

> * Iyeza maduze

> * Azikho ezinye izinguquko enguqulweni 11

Inguqulo 12 (Iyeza maduze)

> Izinguquko:

> * Iyeza maduze

> * Azikho ezinye izinguquko enguqulweni 12

***

## Unyaweni

Usufike ekugcineni kwaleli fayela

([Buyela phezulu] (# Phezulu) | [Buyela ku-GitHub] (https://github.com))

### EOF

***
