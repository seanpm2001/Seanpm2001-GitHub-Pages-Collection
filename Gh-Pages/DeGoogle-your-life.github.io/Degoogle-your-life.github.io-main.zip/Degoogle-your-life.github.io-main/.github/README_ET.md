***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle'ige oma elu

See on peamine degooglinguteave üldise degooglinguteabe jaoks ja link teistele artiklitele.

[Vaadake loendit GitHubi organisatsioonina] (https://github.com/Degoogle-your-life)

***

_Lugege seda artiklit muus keeles: _

** Praegune keel on: ** "inglise (USA)" _ (tõlkimine võib osutuda vajalikuks parandada inglise keelt, asendades õige keele) _

_🌐 keelte loend_

** Sorteeritud: ** "A-Z"

[Sorteerimisvalikud pole saadaval] (https://github.com/Degoogle-your-Life)

([af afrikaans] (/. github / README_AF.md) afrikaani | [sq Shqiptare] (/. github / README_SQ.md) albaania | [am አማርኛ] (/. github / README_AM.md) amhari keel | [ar عربى] (/.github/README_AR.md) araabia | [hy հայերեն] (/. github / README_HY.md) armeenia | [az Azərbaycan dili] (/. github / README_AZ.md) aserbaidžaani | [eu Euskara] (/. github /README_EU.md) baski keel | [be Беларуская] (/. Github / README_BE.md) valgevene keel [[bn বাংলা] (/. Github / README_BN.md) bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) bulgaaria | [ca Català] (/. Github / README_CA.md) katalaani | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichich ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) hiina (lihtsustatud) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) hiina (traditsiooniline) | [co Corsu] (/. Github / README_CO.md) Korsika | [hr Hrvatski] (/. Github / README_HR.md) horvaadi | [cs čeština] (/. Github / README_CS .md) tšehhi | [da dansk] (README_DA.md) taani | [nl Nederlands] (/. github / README_ NL.md) hollandi | [** et et eesti keel **] (/. github / README.md) inglise keel [EO esperanto] (/. Github / README_EO.md) esperanto | [et Eestlane] (/. github / README_ET.md) eesti keel [tl Pilipino] (/. github / README_TL.md) filipiinlane | [fi Suomalainen] (/. github / README_FI.md) soome keel [fr français] (/. github / README_FR.md) prantsuse | [fy Frysk] (/. github / README_FY.md) friisi | [gl Galego] (/. github / README_GL.md) galeegi keel [ka ქართველი] (/. github / README_KA) gruusia | [de Deutsch] (/. github / README_DE.md) saksa keel [el Ελληνικά] (/. github / README_EL.md) kreeka | [gu ગુજરાતી] (/. github / README_GU.md) gudžarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haiti kreool | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) havai | [ta עִברִית] (/. github / README_HE.md) heebrea | [tere हिन्दी] (/. github / README_HI.md) hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) ungari keel [on Íslenska] (/. github / README_IS.md) islandi keel | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) islandi | [ga Gaeilge] (/. github / README_GA.md) iiri keel [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) jaapani keel [jw Wong jawa] (/. github / README_JW.md) jaava keel | [kn ಕನ್ನಡ] (/. github / README_KN.md) kannada | [kk Қазақ] (/. github / README_KK.md) kasahhi keel | [km ខ្មែរ] (/. github / README_KM.md) khmeeri | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-lõuna 韓國 語] (/. github / README_KO_SOUTH.md) Korea (lõuna) | [ko-põhja 문화어] (README_KO_NORTH.md) korea (põhi) (EI VEEL TÕLKETUD) | [ku Kurdî] (/. github / README_KU.md) kurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kõrgõzstani | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) ladina keel [lt Lietuvis] (/. github / README_LT.md) leedu | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksemburgi keel | [mk Македонски] (/. github / README_MK.md) makedoonia | [mg Madagaskari] (/. github / README_MG.md) Madagaskari | [ms Bahasa Melayu] (/. github / README_MS.md) malai | [ml മലയാളം] (/. github / README_ML.md) malajalami | [mt Malti] (/. github / README_MT.md) malta keel [mi maoori] (/. github / README_MI.md) maoori | [hr मराठी] (/. github / README_MR.md) marathi | [mn Монгол] (/. github / README_MN.md) mongoli keel | [minu မြန်မာ] (/. github / README_MY.md) Myanmar (Birma) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) norra keel [või ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) pastu | [fa فارسی] (/. github / README_FA.md) | pärsia [pl polski] (/. github / README_PL.md) poola keel | [pt português] (/. github / README_PT.md) portugali keel [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) pandžabi | Q-tähega algavaid keeli pole [ro Română] (/. github / README_RO.md) rumeenia keel [ru русский] (/. github / README_RU.md) vene keel [sm Faasamoa] (/. github / README_SM.md) Samoa keel | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) šoti gaeli keel | [sr Српски] (/. github / README_SR.md) serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) slovaki | [sl Slovenščina] (/. github / README_SL.md) sloveeni | [nii Soomaali] (/. github / README_SO.md) somaali | [[es en español] (/. github / README_ES.md) hispaania keel [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) suahiili | [sv Svenska] (/. github / README_SV.md) rootsi keel [tg Тоҷикӣ] (/. github / README_TG.md) tadžiki keel | [ta தமிழ்] (/. github / README_TA.md) tamili | [tt Татар] (/. github / README_TT.md) tatari | [te తెలుగు] (/. github / README_TE.md) telugu | [th ไทย] (/. github / README_TH.md) tai | [tr Türk] (/. github / README_TR.md) türgi keel [tk Türkmenler] (/. github / README_TK.md) turkmeeni | [uk Український] (/. github / README_UK.md) ukrainlane | [ur اردو] (/. github / README_UR.md) urdu | [ug ئۇيغۇر] (/. github / README_UG.md) uiguuri | [uz O'zbek] (/. github / README_UZ.md) usbeki keel | [vi Tiếng Việt] (/. github / README_VI.md) vietnami keel [cy Cymraeg] (/. github / README_CY.md) kõmri | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jidiši | [yo joruba] (/. github / README_YO.md) joruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Saadaval 110 keeles (108, kui mitte arvestada inglise ja põhja-korea keelt, kuna põhja-korea keelt pole veel tõlgitud [Loe selle kohta siit] (/ OldVersions / Korea (North ) /README.md))

Tõlked muudesse keeltesse kui inglise keelde tõlgitakse masinaga ja pole veel täpsed. 5. veebruari 2021. aasta seisuga pole veel ühtegi viga parandatud. Palun teatage tõlkevigadest [siin] (https://github.com/seanpm2001/Degoogle-your-life/issues/). Varundage oma parandus allikatega ja juhendage mind , kuna ma ei oska muid keeli peale inglise keele (kavatsen lõpuks tõlgi hankida), siis palun märkige oma aruandes [vikisõnastik] (https://et.wiktionary.org) ja muud allikad. Kui seda ei tehta, lükatakse parandus tagasi.

Märkus. GitHubi märgistuse tõlgendamise piirangute tõttu (ja peaaegu kõigi muude veebipõhiste märgistuste tõlgenduste korral) suunab nende linkide klõpsamine teid eraldi lehele eraldi faili, mis pole minu GitHubi profiilileht. Teid suunatakse [seanpm2001 / seanpm2001 hoidlasse] (https://github.com/seanpm2001/seanpm2001), kus hostitakse README-d.

Tõlked tehakse Google'i tõlkega, kuna muudes tõlketeenustes, nagu näiteks DeepL ja Bing Translate, vajaminevate keelte tugi on piiratud või puudub üldse (Google'i-vastase kampaania puhul on see üsna irooniline), töötan alternatiivi leidmise nimel. Millegipärast on vormindus (lingid, eraldajad, painutamine, kursiiv jne) segatud erinevates tõlgetes. Selle parandamine on tüütu ja ma ei tea, kuidas neid probleeme lahendada keeltes, kus pole ladina tähemärki ja paremalt vasakule (nagu araabia) kasutatavates keeltes on nende probleemide lahendamiseks vaja täiendavat abi

Hooldusprobleemide tõttu on paljud tõlked ajale jalgu jäänud ja kasutavad selle artikli „README“ vananenud versiooni. Vaja on tõlki. Alates 9. aprillist 2021 võtab mul ka aega, et kõik uued lingid tööle saada.

***

## register

[00.0 - Pealkiri] (# Degoogling --- Degoogle-your-life)

> [00.1 - register] (# register)

[01.0 - põhikirjeldus] (# põhikirjeldus)

> [01.1 - hoidla päis] (# Degoogle-your-life)

> [01.2 - Wuest3NFuchsi kirjelduse ülevaade] (# Overview-by-Wuest3nFuchs)

>> [01.2.1 - mida see tähendab?] (# Mida-see-tähendab - Wuest3nFuchsi poolt)

>> [01.2.2 - Miks Degoogle?] (# Miks-Degoogle - by-Wuest3nFuchs)

[02.0 - artiklid] (# artiklit)

[03.0 - Privaatsus] (# Privaatsus)

[04.0 - muud Google'i-vastased kampaaniad] (# muud-Google'i-vastased kampaaniad)

> [04.0.1 - kadunud] (# kadunud)

> [04.0.2 - pooleli] (# käimas)

[05.0 - muude argumentide vastulöök] (# Countering-other-arguments)

> [05.0.1 - mugavus] (# mugavus)

> [05.0.2 - Miks see on oluline? On igatahes liiga hilja]

> [05.0.3 - muu] (# muu)

[06.0 - allikad] (# allikat)

[07.0 - linkide allalaadimine] (# allalaadimislingi)

[08.0 - minu degooglingu kogemus] (# My-degoogling-experience)

> [08.1 - mida ma ümber lülitasin] (# mida-ma-lülitasin välja)

> [08.2 - tooted, millest ma ikka veel ei pääse] (# toodet-ma-ikka-ei-pääse-eest)

[09.0 - muud asjad, mida tasub kontrollida] (# muud-asjad-väljaregistreerimine)

[10.0 - faili teave] (# faili teave)

> [10.1 - Tarkvara olek] (# Tarkvara olek)

> [10.2 - sponsori teave] (# sponsori teave)

[11.0 - faili ajalugu] (# faili ajalugu)

[12.0 - jalus] (# jalus)

***

## Põhikirjeldus

[Vikipeediast: Degoogle] (https://et.wikipedia.org/wiki/DeGoogle)

DeGoogle liikumine (nimetatakse ka de-Google liikumiseks) on rohujuuretasandi kampaania, mis on ellu kutsutud, kuna privaatsusaktivistid kutsuvad kasutajaid üles lõpetama Google'i toodete kasutamine ettevõtte kasvavate privaatsusprobleemide tõttu. See termin viitab Google'i eemaldamisele oma elust. Kuna Interneti-hiiglase kasvav turuosa loob ettevõttele digitaalsetes ruumides monopoolse jõu, on üha suurem arv ajakirjanikke märkinud, et ettevõtte toodetele on keeruline alternatiive leida.

** Ajalugu **

John Koetsier ettevõttest Venturebeat ütles 2013. aastal, et Amazoni Kindle Fire Android-põhine tahvelarvuti oli "Androidi Google'ist eemaldatud versioon". 2014. aastal kirjutas John Simpson USA uudistest Google'i ja teiste otsingumootorite õigusest olla unustatud. 2015. aastal kirjutas Irish Timesi esindaja Derek Scally artikli selle kohta, kuidas "oma elu Google'ist lahti võtta". Aastal 2016 Kris Carlon Androistd Amet soovitas, et CyanogenMod 14 kasutajad saaksid oma telefonid Google'ist lahti võtta, kuna CyanogenMod töötab suurepäraselt ka ilma Google'i rakendusteta. 2018. aastal kirjutas Nick Lucchesi Inverse'ist, kuidas ProtonMail propageeris, kuidas "oma elu Google'ist täielikult lahti saada". Lifehackeri Brendan Hesse kirjutas üksikasjaliku õpetuse Google'ist väljumise kohta. Gizmodo ajakirjanik Kashmir Hill väidab, et tal puudusid koosolekud ja tal oli raskusi kohtumiste korraldamisega ilma Google'i kalendrit kasutamata. 2019. aastal andis Huawei raha tagasi Filipiinide telefoniomanikele, kes olid Google'i pakutavaid teenuseid kasutada, kuna alternatiive on nii vähe, et ettevõtte toodete puudumine muutis Interneti tavapärase kasutamise võimatuks.

***

# Degoogle-sinu-elu
Üldise degooglinguteabe hoidla ja lingid minu teistele degooglinguhoidlatele.

***

## Ülevaade autor Wuest3nFuchs

Parema kirjelduse pakub [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - allikas: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Mida see tähendab? autor Wuest3nFuchs

Degoogling tähendab lõpetada mis tahes Google'ile kuuluva kasutamise, kõik, mis Google on teinud. Ma räägin nende otsingumootorist, nende postiteenusest (Gmail), Youtube'ist jne.

### Miks Degoogle? autor Wuest3nFuchs

Google on praegu üks võimsamaid ettevõtteid maailmas. Nad on meie kõigi kohta salvestanud tohutul hulgal teavet. Mõned väidavad, et meie teave on nende jaoks turvaline, sest nad teavad, kuidas seda kaitsta. Kuid see pole tõsi. Google'isse on tungitud juba varem ja see tungib ka tulevikus. Võib-olla mitte mõne stsenaariumi lapsega, kuid seda teeb rahvusriik. Google salvestab isikliku teabe meile kõigile, sest nii saavad nad raha teenida.

Nad skannivad meie e-kirju, salvestavad seda, mida otsime, kui kasutame nende otsingumootorit, milliseid videoid vaatame Youtube'is. Nii nad sihivad meid ja loovad meile profiili, et näidata meile reklaami selle põhjal, millest me oma parima sõbraga rääkisime, et nad saaksid meile näidata midagi vajalikku, kuid see on liiga jube. Tänu hr Snowdenile teame nüüd, et Google on jaganud meie isiklikke andmeid NSA-ga programmi ** "PRISM" ** raames.


Tulevikus on kellelgi juurdepääs kogu sellele teabele ja ma kinnitan teile, et juhtub midagi väga halba. Selle vältimiseks peaksite Degooglingut alustama kohe. Samuti ei tohiks te kasutada ettevõtte andmeid, mis jagab teie andmeid ** NSA-ga **. Kõigele sellele peaksite lõpu tegema degoogeldades.

** Kui teised inimesed saavad sellega hakkama, saate ka teie seda teha. **

[Loe lähemalt siit] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Hargi linki pole praegu loetletud, kuna ma ei oma seda hoidlat täielikult ja tahan teisi allikaid reklaamida. Isekas oleks linkida minu enda lehele https://github.com/Degoogle-your-life/Degoogle! ->

***

## Artiklid

### Artikli olek

_Kõik artiklid on praegu pooleli ja vajavad ulatuslikke täiendusi. Soovitused ja parandused on lubatud._

_ 18. aprillist 2021 kell 16.09 pole enamikku artikleid veel alustatud. Püüan leida aega ja vaeva nende käivitamiseks.

[Miks peaksite Google Chrome'i kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Lõpeta Chrome'i raamatute kasutamine] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Lõpeta WideVine DRM-i kasutamine / on aeg WideVine DRM-i kärpida] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Miks peaksite ReCaptcha kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Vaheldub YouTube'ist] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Lõpeta Google'i otsing, miks peaksite Google'i otsingu kasutamise lõpetama] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[Miks peaksite Gmaili kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Miks peaksite Androidi kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Miks peaksite Google Ampi vältima] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Miks peaksite Google Drive'i kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Miks peaksite lõpetama Google Mapsi ja Google Earthi kasutamise] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Hei Google, lõpetage] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Lõpeta Google'i / Play raamatute lugemine] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Lõpetage Google Classroomi kasutamine] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Miks peaksite Google'i tõlke kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Miks peaksite oma Google'i konto (d) lõpetama]] (https://github.com/seanpm2001/Why-you-should-spopulaarseimaid Google'i kontosid) <! - 16! ->

** Peagi kirjutatavad uued artiklid: **

[Miks peaksite Gerrit'i kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Miks peaksite lõpetama Google Analyticsi kasutamise (hoidla on minu otsas katki alates kolmapäevast, 24. veebruarist 2021 kell 16:13)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics) <! - 18! ->

<! - tööjagaja! ->

[Miks peaksite Google AdSense'i kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Miks peaksite Google One'i kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Miks peaksite Google+ kasutamise lõpetama (kadunud)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Miks peaksite Google Play poe kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Miks peaksite Google'i dokumentide kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Miks peaksite Google'i esitluste kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Miks peaksite Google'i arvutustabelite kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Miks peaksite Google'i vormide kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Miks peaksite Google'i papi kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Miks peaksite teenuse Google Messages kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Miks peaksite loobuma Google'i materjalidisaini kasutamisest] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Miks peaksite Google Glassi / Prillide kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Miks peaksite lõpetama Google Fuchsia kasutamise] [https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Miks peaksite GBoardi kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Miks peaksite Google Home'i kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Miks peaksite Google Nesti kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Miks peaksite lõpetama Google Hangoutsi kasutamise (kadunud)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Miks peaksite Google Duo kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Miks peaksite Google Tensorflow kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Miks peaksite Google Blockly kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Miks peaksite Google Flutteri kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Miks peaksite loobuma Google'i Go programmeerimiskeele kasutamisest] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Miks peaksite lõpetama Google'i Dart programmeerimiskeele kasutamise] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Miks peaksite lõpetama Google'i WebP-pildivormingu kasutamise] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Miks peaksite lõpetama Google'i WebM-i videovormingu kasutamise] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Miks peaksite Google Video kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Miks peaksite lõpetama teenuse Google Sites (klassikaline) kasutamise]] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Miks peaksite lõpetama Google Sitesi ("Uus") kasutamise]] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Miks peaksite Google Pay kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Miks peaksite Android Pay kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Miks peaksite lõpetama Google VPN-i (oxymoron) kasutamise]] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Miks peaksite teenuse Google Photos kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[Miks peaksite Google'i kalendri kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Miks peaksite lõpetama VirusTotal'i kasutamise (kuna see kuulub Google'ile alates 2012. aasta septembrist] (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Miks peaksite Google Fi kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi) <! - 53! ->

[Miks peaksite Google Stadia kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Miks peaksite Google Keepi kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Miks peaksite Google Base'i kasutamise lõpetama] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Miks peaksite lõpetama osalemise Google Summer of Code'is] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Miks peaksite lõpetama Google'i kaamera kasutamise] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Miks peaksite lõpetama Google'i kalkulaatori kasutamise (võib tunduda äärmuslik, kuid peaksite kõigest degoogleerima, äärmiselt lihtne vaheldumisi kasutada)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Kalkulaator) <! - 59! ->

[Miks peaksite lõpetama Google Survey + preemiate kasutamise] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Miks peaksite loobuma Google'i jooniste kasutamisest] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Miks peaksite lõpetama Tenori (GIF-sait, mis on Google'ile alates 2019. aastast) kasutamise]] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Mis FLoC - miks peaksite vältima Google'i suurt FLoCing-probleemi (lõpetage Google Chrome'i kasutamine)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Artikleid kokku: ** "63"

** Artikkel [teekaart AB] (DegoogleCampaign_2021Roadmap_Part1.md) (kuni 12. märtsini 2021) 2 puhkepäeva **

** Artikkel [teekaart BB] (DegoogleCampaign_2021Roadmao_Part2.md) (kuni? 2021) 2 puhkepäeva **

Artikli olek

Kõik artiklid on praegu pooleli ja vajavad ulatuslikke täiendusi. Soovitused ja parandused on lubatud.

** kahvlid **

Laiendan oma Degoogle'i võrku ja lisan juurde juurdepääsu lihtsustamist ning kogukonna häälitsusi.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Hargnenud: [https://github.com/wacko1805/Fossapps](https://github.com/wacko1805/Fossapps) (inglise keeles)

2. [Privaatsuslingid] (https://github.com/Degoogle-your-life/Privacy-linkid) | Hargnenud: [https://github.com/Arturro43/privacy-links](https://github.com/Arturro43/privacy-links) (poola)

3. [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Hargnenud: [https://github.com/LinuxCafeFederation/Delightful-Privacy](https://github.com/LinuxCafeFederation/Delightful-Privacy) (inglise keeles)

4. [Blocklists] (https://github.com/Degoogle-your-life/blocklists) | Hargnenud: [https://github.com/jmdugan/blocklists]((https://github.com/jmdugan/blocklists) (inglise keeles)

5. [Degoogle, autor Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Hargnenud: [https://github.com/Wuest3nFuchs/Degoogle](https://github.com/Wuest3nFuchs/Degoogle) (inglise keeles)

** Seotud **

[Degoogled Android-telefoni virtuaalse masina uurimine] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Vaata ka:**

[Google'i kriitika Vikipeedias] (https://et.wikipedia.org/wiki/Criticism_of_Google)

[Google'i surnuaed (killbygoogle.com) - järjestatud loend 224-st Google'i tapetud tootest] (https://killedbygoogle.com/)

> [GitHubi link] (https://github.com/codyogden/killedbygoogle)

[Tähestiku töötajate ametiühing - uus Google'i töötajate ametiühing, millel on üle 800 liikme] (https://alphabetworkersunion.org/people/our-union/)

[Kas te ei soovi dinosauruse lihavõttemunast lahku minna? Sellel veebisaidil olete teid kajastanud] (https://chromedino.com/)

***

## Privaatsus

[G] (https://et.wikipedia.org/wiki/Criticism_of_Google) [o] (https://et.wikipedia.org/wiki/PRISM_ (valve_programm)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -halb /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-on-teie-privaatsus) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://et.wikipedia.org/wiki/Nothing_to_hide_ardokument # kriitika) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -essay-sample / midagi-peita-argument-pole-pole midagi öelda /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- andmed-teie-kohta-saate-leida-ja-kustutada-kohe /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -your-personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -monetiseerib ja) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / kõik-andmed-facebook-google-on-teie-privaatsus) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- collection -ealed.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ tervis-sobivus-andmed-privaatsus /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https://moz.com /blog/where-does-google-draw-the-data-collection-line)[e](https://mashable.com/article/google-android-data-collection-study/)[s](https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)[o](https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -nõudeid-5-m nimel illion-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaengerss-consented-to-data-collection/)[r](https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/)[i](https://www.cbsnews.com/news/google-education-spies-on-collects- andmed miljonite laste kohta väidavad, et kohtumenetlus-uus-Mehhiko-peaprokurör /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -meie-nina alt /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / tehnoloogia / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : //medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Ma võiksin selle tõenditega jätkata, kuid nende kõigi leidmine ja läbimine võttis kaua aega artiklid)

Privaatsus Google'i toodetes on alati halb, seda kõigi nuhkvara sisaldavate Google'i toodete tõttu.

Ükskõik, mida teete, saadetakse Google'i kasutamisel kõik teie tundlikud isikuandmed Google'ile ja teistele. Google'i on märgatud ka avatud programmide kaudu. Näiteks isikliku kogemuse põhjal (Firefoxis), kui YouTube'i vahekaart oli avatud ja mida ma ei külastanud, vaatasin ma mitu videot võrguühenduseta (VLC Media Player). Hiljem, kui läksin soovitusi kontrollima, oli see peaaegu kõik, mida ma vaatasin. Pole kahtlust, et nad luuravad ka teisi programme.

Chrome'is (ja paljudes muudes brauserites) on inkognito režiim. Chrome'is pole see režiim mõttetu, kuna Google ikkagi kaevandab teie andmed. Isegi kui lülitate andmekaevamise / jälgimise välja ja lubate signaali "ei jälgi", üllatus üllatus, Google kaevandab teie andmeid ikkagi.

Kui arvate, et teil pole midagi varjata, siis ** eksite absoluutselt. Seda argumenti on mitu korda ümber lükatud:

[Vikipeedia kaudu] (https://et.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden märkis: "Väites, et te ei hooli privaatsuse õigusest, sest teil pole midagi varjata, ei erine see, kui öelda, et te ei hooli sõnavabadusest, sest teil pole midagi öelda." Kui ütlete: Mul pole midagi varjata, "ütlete sa:" mind ei huvita see õigus. "Sa ütled:" Mul pole seda õigust, sest ma olen jõudnud punkti, kus ma pean õigustama "Kuidas õigused töötavad, peab valitsus õigustama oma õiguste rikkumist."

2. Daniel J. Solove teatas ajakirja The kõrghariduse kroonika artiklis, et ta on argumendi vastu; ta teatas, et valitsus võib lahkudak teavet isiku kohta ja sellele isikule kahju tekitamist või kasutage teavet isiku kohta teenuste keelamiseks, isegi kui inimene tegelikult ei eksinud, ja et valitsus võib vigade tegemisega tekitada kahju isiklikule elule. Solove kirjutas: "Otseselt kaasates võib varjata miski, mida varjata, sest see sunnib arutelu keskenduma oma kitsale arusaamale privaatsusest. Kuid kui puutuda kokku paljude privaatsusprobleemidega, mis on seotud valitsuse andmete kogumise ja kasutamisega väljaspool järelevalvet ja avalikustamine, mille varjamiseks pole midagi varjata, pole lõpuks midagi öelda. "

3. Adam D. Moore, raamatu „Privaatsusõigused: moraalsed ja õiguslikud sihtasutused” autor, väitis, et „see on seisukoht, et õigused on vastupidavad kulude / tulude või tagajärjepõhiste argumentide vastu. Siinkohal lükkame tagasi arvamuse, et privaatsuse huvid on sellised asjadest, mida saab turvalisuse nimel kaubelda. " Ta märkis ka, et jälgimine võib ebaproportsionaalselt mõjutada teatud ühiskonnagruppe, mis põhinevad välimusel, rahvusel, seksuaalsusel ja usul.

4. Arvutiturbeekspert ja krüptograaf Bruce Schneier avaldas vastuseisu, tuues välja kardinal Richelieu väite "Kui keegi annaks mulle kuus ausama mehe käega kirjutatud rida, leiaksin neist midagi, mis teda üles pooks", viidates sellele. kuidas riigivalitsus võib leida inimese elus aspekte, et seda inimest süüdistada või väljapressida. Schneier väitis ka, et "liiga paljud iseloomustavad arutelu valesti kui" turvalisus versus privaatsus ". Tegelik valik on vabadus versus kontroll. "

5. Harvey A. Silverglate hinnangul paneb tavaline inimene USA-s toime keskmiselt teadmatult kolm süütegu päevas.

6. Filosoof ja psühhoanalüütik Emilio Mordini väitis, et argument "midagi varjata" on oma olemuselt paradoksaalne. Inimestel ei pea olema midagi varjata, et midagi peita. Varjatud pole tingimata asjakohane, väidab Mordini. Selle asemel väidab ta, et vajalik on intiimne ala, mis võib olla nii varjatud kui ka juurdepääsupiiranguga, sest psühholoogiliselt võttes saame me inimesteks avastuse kaudu, et võime midagi teistele varjata.

7. Julian Assange ütles: "Mõrvarile pole veel vastust. Jacob Appelbaum (@ioerror) reageerib nutikalt, paludes seda ütlevatel inimestel anda talle telefon lukust lahti ja tõmmata püksid alla. Minu versioon sellest on öelda: "noh, kui sa oled nii igav, siis me ei peaks teiega rääkima ega peaks ka kedagi teist", kuid filosoofiliselt on tõeline vastus järgmine: massiline järelevalve on massiline struktuurimuutus. Kui ühiskond läheb halvaks, siis see läheb teid kaasa võtma, isegi kui olete kõige õrnem inimene maa peal. "

8. Õigusprofessor Ignacio Cofone väidab, et see argument on ekslik omaette, kuna alati, kui inimesed avaldavad teistele asjakohast teavet, avaldavad nad ka ebaolulist teavet. Sellel ebaolulisel teabel on privaatsuskulud ja see võib põhjustada muid kahjustusi, näiteks diskrimineerimist.

***

## Muud Google'i-vastased kampaaniad

See on loetelu teistest märkimisväärsetest Google'i-vastastest kampaaniatest. See loetelu on puudulik. Saate aidata seda laiendades.

### kadunud

[Scroogled - Microsofti poolt (november 2012 kuni 2014)] (https://et.wikipedia.org/wiki/Scroogled)

_ Praegu pole muid kirjeid ._

### Jätkuv

_See loend on praegu tühi._

***

## Muudele argumentidele vastu astumine

Inimesed esitavad Google'i õigustamiseks mõned argumendid. Üks esimesi suuremaid on juba [siin] (# Privaatsus) lahti lükatud, kuid siin on mõned muud

### Mugavus

Jah, Google'i tooted tunduvad mugavad. Siiski kauplete mugavuse huvides kõigega, sealhulgas turvalisuse, privaatsuse ja usaldusväärsusega. Google on aastate jooksul muutunud laisemaks ja nende serverid on järjest rohkem langenud. Praegu töötavad Google'i serverid peaaegu tund aega 1-2 korda kuus (eriti YouTube)

Kahjuks on tänu ühiskondade Google'ile toetumisele hakanud Google domineerima Internetis ja püüab seda üha enam kontrollida. 2012. aastal, kui Google langes 5 minutiks, teatati, et ** ülemaailmne ** Interneti-liiklus ** vähenes 40% ** Google langeb sageli 1-2 tunniks ja [oma eetikameeskonna vallandamise] korral (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) muu hulgas muutuvad need järjest mugavamaks.

Mugavus pole alati hea. Peaksite olema teadlik toimuvast ja olema valmis, kui see langeb, kuna pole võimalust, et server ei läheks iga natukese aja tagant alla.

Google pole ka nii mugav, kui arvate. On ka teisi palju mugavamaid saite. Google pole kaugeltki mugav, kui arvestate nende juhusliku konto peatamise ja lõpetamise vastuseta (välja arvatud juhul, kui juhtite piisavalt tähelepanu Google twitteri kontole või kaebate neile kohtusse 100 000 000 dollarit või rohkem), siis on nad teid ära kasutanud, teid alt vedanud ja sundis teid karjuma padja, kus keegi ei kuulnud teie kisaabi saamiseks.

### Miks see oluline on, see on igal juhul liiga hilja

See on vähem levinud argument, kuid vajab selgitamist. Praeguses seisus näib, et enamik maailma valitsusi koos mitme võimsa korporatsiooniga teavad teie igat sammu, miks peaksite sellest üldse lahti saama? Vastus on lihtne: ** väärite paremat **. Kui teil õnnestub sel hetkel neist eemale pääseda, on neil raskem teie käike veelgi jälgida ja saate luua uue privaatsema elu.

[1 allikas] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Muide, olen sellele postitusele andnud tasuta Redditi auhinna iga kord, kui saan selle üle nädala nüüd (koos kõigi minu 500 tasuta mündiga), et seda teemat veelgi tõsta. Siiani olen andnud sellele postitusele üle 14 tasuta auhinna. Seda pole palju, kuid väikestel asjadel võib olla suur mõju, olenevalt sellest, kuidas seda tajutakse ja kelle poolt.

### Muu

Muid argumente mul hetkel pole.

_See loend on puudulik

***

## Allikad

Kopeeri:

[G] (https://et.wikipedia.org/wiki/Criticism_of_Google) [o] (https://et.wikipedia.org/wiki/PRISM_ (valve_programm)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -halb /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-on-teie-privaatsus) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://et.wikipedia.org/wiki/Nothing_to_hide_argument# Kriitika) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -näidised / mitte midagi peita-argumendil pole midagi öelda /) [d] (https://www.cnet.com/how-to/google-collects-a-hirmutav-amount-of- andmed-teie-kohta-saate-leida-ja-kustutada-kohe /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes ja [c] (https://www.wired.com/story/google-tracks-you -privaatsus /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / kus-google-joonistab-andmekogu-joont) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / tehnoloogia / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- nõuded 5 miljoni iphone-kasutaja nimel) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -telefon-pole-kasutusel /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaengerss-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technology / 2014/01 / what-google-can-do-do-with-pesa-või-tõesti-pesad-andmed /) [i] (https://www.cbsnews.com/news/google-education -spies-on-kogub-andmeid-miljonite-laste kohta-väidab kohtuasja-uus-Mehhiko-peaprokurör /) [v] (https://www.nationalreview.com/2018/04/the- õpilasandmete kaevandamise skandaal-meie nina all /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did on-midagi-peita-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Muud allikad:

[Viie silma liit] (https://et.wikipedia.org/wiki/Five_Eyes) [Üheksateist kaheksakümmend neli] (https://et.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Linkide allalaadimine

[Hankige Firefox] (https://www.mozilla.org/en-US/firefox/new/) [Get Tori brauser] (https://www.torproject.org/download/) [Muu / pole saadaval] (https : //www.example.com)

***

## Minu degooglingu kogemus

Lõpuks hakkasin 2018. aastal nägema probleeme suurte tehnoloogiatega ja hakkasin degoogeldama. Esimeste kuude jooksul tegin märkimisväärseid edusamme. Pärast seda aeglustus see tohutult.


### Mida ma ümber lülitasin

Google Chrome -> Firefox / Tor

Google'i otsing -> DuckDuckGo (vaikimisi) / Ecosia (kui mulle meeldib) / Bing (harva)

GMail - ProtonMail (pole veel täielikult sisse lülitatud)

Google Sites -> isemajutus (pole veel täielikult sisse lülitatud)

Google+ -> vaevalt kunagi kasutatud, kustutas ise oma seiskamise tõttu

Google Docs -> pole kunagi kasutatud, ma kasutan selle asemel lihtsalt Microsoft Word 2013 (enne 2019) ja LibreOffice (alates 2019).

Google'i arvutustabelid -> pole kunagi kasutatud, kasutan nende asemel lihtsalt Microsoft Excel 2013 (enne 2019) ja LibreOffice (alates 2019).

Google'i slaidid -> pole kunagi kasutatud, kasutan selle asemel lihtsalt Microsoft PowerPoint 2013 (enne 2019) ja LibreOffice'i (alates 2019).

Google'i joonised -> pole kunagi kasutatud, kasutan selle asemel lihtsalt LibreOffice'i (alates 2019).

Gerrit -> pole kunagi kasutanud, kasutan nende asemel lihtsalt GitHubi (praegune vaikeseade), GitLabi, BitBucketit ja SourceForge'i.

Google Photos -> pole kunagi kasutatud

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-praegune)

Google Maps -> OpenStreetMaps / Apple Maps

Go - spetsiaalse erandi tegemine, kuid mitte funktsionaalse programmeerimiskeelena kasutamine

Dart - erilise erandi tegemine, kuid mitte funktsionaalse programmeerimiskeelena kasutamine

Flutter - erilise erandi tegemine, kuid mitte funktsionaalse programmeerimiskeelena kasutamine

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> pole kunagi kasutatud, pean seda eriti jube

Google Fi -> pole kunagi kasutatud

Google'i kalender -> pole kunagi kasutatud

Google'i kalkulaator -> sõna otseses mõttes ükskõik milline muu kalkulaatori rakendus, isegi Pythoni režiimis töötav Linuxi terminal, kui see mulle meeldib

Google Nest -> pole kunagi kasutatud

Google AMP -> pole kunagi kasutatud

Google VPN -> pole kunagi kasutatud, ka oksümoroon

Google Pay -> pole kunagi kasutatud

Google Summer of Code -> pole kunagi osalenud

Tenor -> muud GIF-saidid, kuigi GIF-id pole minu jaoks liiga olulised. Tavaliselt saan GIF-faile DuckDuckGo piltidelt, Imgurilt, Redditilt või muudelt saitidelt.

Blokeeritud -> pole enam kasutatud, pole kindel, kas Scratch jooksis otse blokeeritult. Minust sai funktsionaalne programmeerija alates 2017. aastast ja kasvasin välja Scratchist.

GBoard -> kasutatud üks kord, kuid hüljatud

Google Glass -> pole kunagi kasutatud, peetakse väikeseks lapseks, kuid otsustasin seda mitte hankida / kasutada, kui mul oleks võimalus

_Loend võib olla puudulik ._

### Tooted, millest ma ikkagi ei pääse

Alates 25. veebruarist 2021 hoiavad need Google'i tooted mind täielikult guugeldamast:

1. YouTube

2. Android

3. Google Play pood

4. GMail (ainult kooli ja mõne saidi jaoks)

5. Google Classroom (ainult kooli jaoks)

6. Google'i tõlge

7. Google'i konto

8. Google'i saidid (kuna Google rikub GDPR-i seadusi (ja teda võidakse veel trahvida 5 000 000,00 euroni, kuni see parandatakse) ja keelatakse selle toote allalaadimine)

Olen kõigest muust lahti rääkinud.

***

## Go on kuri

Google tutvus 2003. aasta agendipõhise programmeerimiskeelega Go! Koos oma programmeerimiskeelega Go (alates 2009. aastast, 6 aastat hiljem) ja väitis, et nende keel ei mõjuta teist keelt üldse. Google'it kritiseeriti selle eest tugevalt, kuna nende moto "Ära ole kuri" oli tol ajal veel aktiivne ja see on üks paljudest juhtumitest, mille tõttu ära ole kurja moto jäi pensionile.

Lõpuks lakkas `Go !` arendamine, samas kui` Go` muutus üha tavalisemaks. Google väitis, et nad ei käi üle "Go!" Üle, kuid lõpuks siiski said ja said sellest lahti (9. aprilli 2021 seisuga)

[Lisateavet Go ja vaheldumise kohta leiate siit] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## DRM-i kasutamine

Google kasutab DRM-i (Digital Restrictions Management) WideVine DRM-i "teenuse" ja muude vormide kaudu. DRM-i eesmärk on hävitada avatud Internet ja anda ettevõtetele monopoolne võim kasutajate üle. WideVine'ist peaksite täielikult lahti saama, olenemata kuludest.

[Lisateavet WideVine'i ja selle probleemide kohta leiate siit] (https://github.com/Degoogle-your-life/Its-time-lõigata-WideVine-DRM)

***

## Levinud väärarusaamad

See on loetelu mõnedest levinud väärarusaamadest Google'i toodetega.

### Google pole Internet

Google'i / Google'i otsing ei ole Internet, Google'i otsing on lihtsalt otsingumootor, umbes selline, nagu mitte iga Nintendo platvormi jaoks mõeldud mängu pole Nintendo tehtud, vaid Nintendo litsentsitud, kuid palju suuremal määral. Kui praegu tuleks kõik Google'i serverid samaaegselt hävitada, oleks kadunud ainult sellised Google'i saidid nagu YouTube, Gmail, Google Docs, Google'i otsing jne, kuid suurem osa Internetist oleks endiselt olemas (Wikipedia, Stackoverflow, GitHub, kõik Microsofti veebisaidid, NYTimes, Samsung, TikTok jt) võivad nad kaotada oma Google'i sisselogimise ja analüütilise funktsionaalsuse, kuid oleksid siiski funktsionaalsed (välja arvatud juhul, kui need olid halvasti programmeeritud ja tuginesid otse Google'is)

***

## Internet Explorer 6 ja Chrome

Google Chrome on muutumas uueks Internet Explorer 6. Kui Google Chrome algselt välja tuli, oli Firefox domineeriv brauser ja tappis enamasti Internet Exploreri turuosa (mis ületas 96% enne, kui miljonid inimesed Firefoxile ja muudele brauseritele üle läksid), kui Google Chrome tuli välja, inimesed vahetasid selle kiiruse ja Google'i poolt (mida toona ei peetud kurjaks, kuna enamik privaatsusküsimusi polnud veel päevavalgele tulnud) vahetasid Google Chrome algselt veebistandardeid (mida Firefox tegi mis tappis Internet Exploreri 96% brauseri turu jagamise), kuid kui Google Chromesi turuosa kasvas, hakkas Google üha uusi funktsioone eemaldama, lisama rohkem nuhkvara ja lõpetama veebistandardite aktsepteerimise, on Google Chrome muutunud uueks Internet Explorer 6-ks.

Praegu on suurim probleem veebisaidid, mis on ainult Chrome ja mis ei tööta teistes brauserites, kuna nende arendajad otsustasid, et nad ei soovi, et ülejäänud 30–40% Interneti-kasutajatest, kes Chrome'i ei kasuta, oma saiti kasutaksid.

Isegi Google ise muudab oma saidid ainult Chrome'iks. Näiteks palub Google'i otsing teil Chrome'i alla laadida 3 korda iga 10 sekundi järel, kui tuvastatakse, et te ei kasuta Google Chrome'i (see mõjutab isegi teisi Chromiumi põhiseid brausereid, näiteks Brave) ja saidid nagu Google Earth ei luba Firefoxi kasutajatel kasutada oma saiti (alates 2020. aastast), lisaks ei toeta Google Translate Firefoxi ja muude Google Chrome'i mittekuuluvate brauserite häälsisestust.

### Probleem vapraga

Teised Chromiumi baasil olevad brauserid, näiteks Brave ja Microsoft Edge, pole Google'i nuhkvarast täiesti vabad. Julget soovitab tavaliselt privaatsuse kogukonna vale pool, kuid vapper on endiselt probleem, kuna see kasutab Chromiumi. Internet ei tohiks koosneda ainult Chromiumi brauseritest, valikuvõimalusi peaks olema palju. Vapper on vale tee.

[Lisateavet Google Chrome'i / Chromiumi degooglingu kohta leiate siit] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Lisateavet ChromeOS-i / ChromiumOS-i (Chromebookid / Chromeboxid / Chromebletid / ChromeBits / ChromeETC) degooglingu kohta leiate siit] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Faux privaatsuse uuendamine

Google on püüdnud öelda maailmale, mis neile privaatsusest hoolib, pärast seda, kui oli juba liiga hilja. Nad väidavad jätkuvalt, et nad austavad kasutajate privaatsust, kuid ei lahenda siiski kõiki oma privaatsusega seotud probleeme.

### Avatud lähtekood ei saa olla osaline

Avatud lähtekood ei saa olla osaline. Google on selle tõestuseks. Lähtekoodi iga bitt ja bait peab olema avalikkusele nähtav, isegi 8. bait pole peidetud.

Sellised projektid nagu Android ja ChromeOS on osaliselt avatud lähtekoodiga, kuid sisaldavad enamikku patenteeritud nuhkvara elemente.

### Oxymoron

Google VPN on oksümoroon. Google ei hooli privaatsusest ja temasuguse ettevõtte virtuaalne privaatvõrk (VPN) oleks VPN-teenuse jaoks üks halvemaid võimalikke valikuid.

***

## Kehv jõudlus

Google ei hooli oma toodete toimivusest vähemalt 2017. aasta seisuga, kuna nende viimane võrdlusuuringute tarkvara (Google Octane) lõpetati 2017. aastal.

***

## Halb projektijuhtimine

Google'il on väga halb sisemine projektijuhtimissüsteem. Mõned levinumad näited programmidest, mida on üha enam alandatud, hõlmavad Google Duo ja YouTube'i muusikat (endine Google Play muusika)

Google'i siseses arendussüsteemis viib üks rakendus teise rakenduse juurde, millel on pool funktsionaalsust, seejärel kustutatakse algne rakendus. Paar aastat hiljem tehakse uus rakendus 75% vähem funktsionaalsusega ja seejärel eemaldatakse 50% funktsionaalsusega rakendus, millele järgneb uus 87,5% loodava funktsionaalsusega rakendus, seejärel lõpetatakse 75% funktsionaalsusega rakendus , ja nii edasi.

***

## Kohutav või mõõdukas teenuste puudumine

YouTube on halva mõõdukuse maailmas kõige levinum näide, mis loob olemasoleva halvima platvormi. Näib, et ka Google ei saa aru, et YouTube pole YouTube'i lapsed.

YouTube'is pakutakse kasutajatele vihkavat natsimeelset ja valget suprematistlikku sisu, et saada rohkem aega ja rohkem raha. Google on ka mõned väga teinudrumalusi nende mõõdukuses, näiteks kristliku anaalseksi video heakskiitmine sisuks, mis on lastele mõeldud, samal ajal vanust piirates. Samuti pole liiga haruldane näha, et pornograafilised või gore-reklaamid on Baby Sharki video all koos muu muu lastele mõeldud sisuga.

YouTube'i kasutajad kurdavad YouTube'is halva mõõdukuse pärast halva sisu (nt ülaltoodud näited) üle väga sageli, samas kui kasutajad saavad oma videod ilma põhjuseta juhuslikult kustutada ja neid ei saa tühistada ning kasutajaid karistatakse igasuguse vandumise eest. isegi ebavõrdsete karistuste tõttu võrreldakse Stalini ajastul isegi väga väikseid juhtumeid, nagu näiteks "jama" kasutajate ütlemine YouTube'i [Nõukogude Liiduga] (https://et.wikipedia.org/wiki/Soviet_Union).

2021. aastal teatas Google, et vaatamata video demoniseerimisele (nii et Google teenib raha, kuid looja seda ei tee) panevad kõikidele videotele reklaamid, kuid see ei ole seotud mõõdukusega, kuid on oluline märkida.

YouTube on modereeritud (ehkki väga halvasti), kuid näib, et Google'i reklaamiteenusel, mis teenib neile suurema osa oma rahast, on vähe või üldse mitte modereerida.

[Lisateave YouTube'i modereerimise probleemide ja YouTube'ist vaheldumise kohta] (https://github.com/seanpm2001/Alternating-from-YouTube)

Google Play reklaamid genereeritakse botifarmidest. Võite öelda samade reklaamistsenaariumide järgi, mida kasutavad sajad ettevõtted, millel on vähe muudatusi ja mis pole tootega seotud (levinud näited: Playrix (kodumaastikud, aiamaastikud) Fishdom, Mafia City ja veel tuhandeid) koos õitsva pahatahtliku reklaamitrendiga, mis väidavad, et kasutajad saavad raha teenida mängides, muusikat kuulates jne. PayPal pole seda kommenteerinud, kuid on ilmne, et see on pettus, justkui saaksite teha üle 10 000 dollari vähem kui 20 sekundiga garanteeritud mängu mängides, keegi ei teeks tööd ja teeks seda hoopis, mis on võimatu ja ettevõte ei saaks niimoodi töötada. See ilmne kelmus on alates 2019. aastast üha tugevamaks muutunud ja nüüd võitlevad neid reklaame tootvad botifarmid omavahel oma reklaamides.

Mitmed reklaamid on samuti väga labased ja üritavad kasutajaid (enamik neist on alla 13-aastased või robotid) klõpsama seksuaalse manipuleerimise kaudu.

Paljud rakendused kasutavad oma tooteid roboteid ja astroturfi, nii et kui halb ülevaade tehakse, hakkavad sokinukkude botide kontod postitama 5 tärni arvustusi ja üritavad teie kriitikat ümber lükata. [Google teeb seda ka ise] (# Astroturfing)

[Lisateave Google AdSense'i probleemide kohta] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturf

Üldine määratlus [(Vikipeediast)] (https://et.wikipedia.org/wiki/Astroturfing)

""
Astroturf on tavaks maskeerida sõnumi või organisatsiooni sponsoreid (nt poliitilisi, reklaami-, religioosseid või avalikke suhteid), et see paistaks justkui pärinevat rohujuuretasandil osalejatelt. See on tava, mille eesmärk on anda avaldustele või organisatsioonidele usaldusväärsus, hoides ära teavet allika rahalise seose kohta. Termin astroturf on tuletatud sõnast "rohujuuretasandil" mänguna sünteetiliste vaipade tootemargist AstroTurf, mis on loodud sarnanema loodusliku rohuga. Mõiste kasutamise taga on see, et "tõelise" või "loodusliku" rohujuuretasandi pingutuse asemel on kõnealuse tegevuse taga "võlts" või "kunstlik" toetuse välimus.
""

Google'il on astroturfide ajalugu olnud nii, et tundub, nagu nad ei teeks midagi kurja (selle käigus on astroturfimine kuri), näiteks Google'i kriitika postitamine sellisele platvormile nagu Twitter (millel neil on konto) mitu kontot, mis on mõnda aega eksisteerinud, kuid pole kunagi enne postitamist postitanud ja väitnud, et see, mida te ütlesite, on vale, ja seejärel väita, et Google on parim ettevõte, kuid tehtud nii, et pole ilmselt ilmne, et need on enamiku robotid inimesed.

***

## Ebaseaduslikud ja ebaeetilised äritavad

Google kasutab ebaseaduslikke ja ebaeetilisi äritavasid oma monopoli edendamiseks, näiteks maksuparadiiside kasutamine, töökohtade sisseostmine ja ebaseadusliku invasiivse tegevuse jätkamine äritegevuse kuluna.

### Euroopas

Euroopa on Google'it sageli kohtusse kaevanud, kusjuures suurim kohtuasi on Androidis ebaseadusliku käitumise vastu, mille tulemusel sai Google 5 000 000 000 eurot (mis vastab 5. aprillil 2021. aastal 5 947 083 703,68 dollarile)

### Põhja-Ameerikas

USA pole Google'ile veel peaaegu piisavalt trahvi määranud, võrreldes Europesi trahviga 5 000 000 000 eurot.

### Vaidlused

Google ei hooli probleemist enne, kui see tekitab poleemikat, siis teevad nad halva katse seda parandada, piisab vaid sellest, et vaidlus ajutiselt kaoks, ja probleem süveneb seejärel eksponentsiaalselt, kuni see tekitab veel ühe poleemika ja tsükkel jätkub. Nad lihtsalt ei hooli piisavalt, et midagi tõsist ette võtta.

***

## Google on automatiseeritud

KominaGoogle on enamasti automatiseeritud, vähem modereeritav kui automatiseerimine.

Ettevõte ei tohiks olla täielikult automatiseeritud. Google on selle näide. Mõõdukus on kohutav, kui seda teeb ainult tehisintellekt, YouTube on hea näide isegi siis, kui üleliigsed (sajad või võib-olla tuhat) inimest modereerivad saiti, kus see on ilmselt nii halb, et enamik neist peab töötamise ajal ravi saama.

***

## Android

Android kuulub Google'ile. Osa Open Handset Alliance'ist (mis pole olnud avatud Androidist alates) on Android muutunud Google'i jaoks veel üheks monopoolseks punktiks ja sellest on väga raske pääseda.

Androidi kohta on teatatud, et ta helistab Google'ile koju vähemalt 10 korda päevas ja vaatamata osaliselt avatud lähtekoodile toimib see endiselt nuhkvarana.

Androidist vaheldumisi on loodud mitu projekti, kuid need nõuavad seadme juurdumist. Knox DRM-i tõttu pole see USA-s konkreetsete Samsungi telefonide jaoks lihtsalt enam võimalik. Androidi levinumate alternatiivide hulka kuuluvad iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch ja PiPhone (Pi Phone on telefonimark, mis töötab mobiilseadmes mitmesuguseid Linuxi süsteeme, näiteks Fedora, Ubuntu, Arch jne).

[Vaadake minu uuringut degoogleeritud Androidi virtuaalmasina funktsioneerimise kohta] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Vaadake, kuidas Androidist degoogle'i teha] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Väikesed tegevused abiks

Tähtis on teadlikkuse levitamine igal võimalusel. Minu jaoks ei räägi ma mitte ainult sageli degooglingust ja kirjutan artikleid, vaid mul on ka väike väike harjumus, kus ma annan oma igapäevase Redditi auhinna r / degoogle'is kinnitatud postitusele teadlikkuse tõstmiseks. Siiani olen kinnitanud kinnitatud postitusele ligi 30 auhinda (kulutasin selle postituse jaoks 10 auhinnale ka 500 oma tasuta münti)

***

## ebausaldusväärne

Google'i ei saa usaldada ega saa kunagi enam usaldada. Nad on täielikult läinud "ära ole kuri" (nad olid alati kurjad) asemel lihtsalt täiesti kurjadeks ja ei püüdnud seda varjata.

***

## Muud asjad, mida vaadata

[Google'i surnuaed (killbygoogle.com) - järjestatud loend 224-st Google'i tapetud tootest] (https://killedbygoogle.com/)

> [GitHubi link] (https://github.com/codyogden/killedbygoogle)

[Tähestiku töötajate ametiühing - uus Google'i töötajate ametiühing, millel on üle 800 liikme] (https://alphabetworkersunion.org/people/our-union/)

[Kas te ei soovi dinosauruse lihavõttemunast lahku minna? Sellel veebisaidil olete teid kajastanud] (https://chromedino.com/)

On ka teisi asendajaid, lihtsalt otsige neid.

***

Selle artikli jaoks on vaja teatud faktide kontrollimist

***

## Failiteave

Failitüüp: "Markdown (* .md)"

Ridade arv (sh tühjad read ja koostaja rida): "968"

Failiversioon: "6 (pühapäev, 18. aprill 2021 kell 16:18)"

***

### Tarkvara olek

Kõik minu teosed on teatud piiranguteta. DRM-i (** D ** igital ** R ** ehted ** M ** anagement) ei esine üheski minu teoses.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Seda kleebist toetab Free Software Foundation. Ma ei kavatse kunagi DRM-i oma töödesse kaasata.

Ma kasutan lühendit "Digitaalsete piirangute haldamine" tuntuma "Digitaalse õiguste halduse" asemel, kuna levinud viis selle lahendamiseks on vale, DRM-iga pole õigusi. Õigekiri "Digitaalsete piirangute haldamine" on täpsem ja seda toetavad [Richard M. Stallman (RMS)] (https://et.wikipedia.org/wiki/Richard_Stallman) ja [Vaba tarkvara sihtasutus (FSF)] ( https://et.wikipedia.org/wiki/Free_Software_Foundation)

Seda jaotist kasutatakse DRM-i probleemide teadvustamiseks ja ka selle vastu protestimiseks. DRM on oma konstruktsioonilt defektne ja ohustab oluliselt kõiki arvutikasutajaid ning tarkvaravabadust.

Pildikrediit: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Sponsorite teave

! [SponsorButton.png] (SponsorButton.png) <- ärge klõpsake seda nuppu, see ei tööta, see on lihtsalt pilt. Päris nupp asub lehe ülaosas paremas nurgas (<- L ** R ** ->)

Soovi korral saate seda projekti sponsoreerida, kuid palun täpsustage, millele soovite annetada. [Vaadake vahendeid, millele saate annetada, siit] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Sponsorite muud teavet saate vaadata [siit] (https://github.com/seanpm2001/Sponsor-info/)

Proovi! Sponsori nupp asub otse vaatamis- / vaatamisnupu kõrval.

***

## Faili ajalugu



 * Alustas faili

> * Lisatud pealkirjaosa

> * Lisas indeksi

> * Lisatud jaotis umbes

> * Lisas Wiki jaotise

> * Lisatud versiooniajaloo jaotis

> * Lisas jaotise Probleemid.

> * Lisas eelmiste väljaannete jaotise

> * Lisas jaotise eelmised tõmbetaotlused

> * Lisati aktiivsete tõmbetaotluste jaotis

> * Lisatud kaastöötajate jaotis

> * Lisatud kaastöö jaotis

> * Lisas jaotise umbes README

> * Lisatud jaotis README versiooniajalugu

> * Lisatud ressursside jaotis

> * Lisatud tarkvara oleku jaotis koos DRM-i tasuta kleebise ja sõnumiga

> *Lisati sponsorite teabe jaotis

> * Versioonis 0.1 muud muudatused puuduvad

Versioon 1 (reede, 19. veebruar 2021 kell 17.20)

> Muudatused:

> * Alustas faili

> * Lisatud põhikirjelduse jaotis

> * Lisatud hoidla kirjelduse jaotis

> * Lisatud artiklite loend, kus on 14 kirjet

>> * Lisas jaotise `seotud artiklid`

>> * Lisatud jaotis `vaata ka`

> * Lisas failiteabe jaotise

> * Lisatud on failiajaloo jaotis

> * Lisati jalus

> * Versioonis 1 muid muudatusi pole

Versioon 2 (reede, 19. veebruar 2021 kell 17:26)

> Muudatused:

> * Lisatud on tõlke oleku jaotis

> * Lisas jaotise Muud vaatamiseks asjad

> * Lisas privaatsuse jaotise

> * Lisatud register

> * Lisatud tarkvara oleku alajagu

> * Lisas teise jaotise Google'i vastased kampaaniad

>> * Lisas kadunud alajaotise

>> * Lisas käimasoleva alajaotise

> * Lisas jaotise allikad

> * Lisas allalaadimislinkide jaotise

> * Värskendas failiteabe jaotist

> * Värskendas failiajaloo jaotist

> * Versioonis 2 muid muudatusi pole

Versioon 3 (kolmapäeval, 24. veebruaril 2021 kell 19.56)

> Muudatused:

> * Uuendas indeksit

> * Viitas degoogle'i ikoonile ja uuele GitHubi organisatsioonile

> * Lisatud lingid uuematele artiklitele

> * Lisas vastutavate argumentide jaotise

>> * Lisas mugavuse alajaotise

>> * Lisas alajaotuse Miks isegi vaeva näha

>> * Lisas teise alajao

> * Värskendas osa andmeid

> * Värskendas failiteabe jaotist

> * Värskendas failiajaloo jaotist

> * Versioonis 3 muid muudatusi pole

Versioon 4 (neljapäev, 25. veebruar 2021 kell 21.31)

> Muudatused:

> * Lisatud lingid 10 uuele artiklile

> * Lisas jaotise minu kogemuste degoogeldamise kohta

> * Uuendas indeksit

> * Värskendas failiteabe jaotist

> * Värskendas failiajaloo jaotist

> * Versioonis 4 muid muudatusi pole

Versioon 5 (reede, 9. aprill 2021 kell 18:02)

_Google'i-vastase liikumise värskendusi on mul viimasel ajal puudu, töötan selle nimel, et pärast 1+ kuud pausi selle juurde tagasi pöörduda.

> Muudatused:

> * Pealkirjaosa uuendati

> * Uuendas indeksit

> * Uuendati keeleloendit: fikseeritud lingid ja lisati rohkem toetatud keeli

> * Värskendas artikli oleku jaotist, lisades 4 kahvli linki

> * Värskendas tarkvara oleku jaotist

> * Lisatud jaotis Mine on kuri

> * Lisatud jaotis DRM-i kasutamine

> * Lisatud jaotis Levinud väärarusaamad

>> * Lisatud pole Google'i Interneti-alajagu

> * Lisatud jaotised Internet Explorer 6 ja Chrome

>> * Lisas alajaotise Brave probleem

> * Lisatud Fauxi privaatsuse eemaldamine

> * Lisatud avatud lähtekood ei saa olla osaline alajaotis

> * Lisati alamjagu Oxymoron

> * Lisati jaotis halb jõudlus

> * Lisati jaotis Halb projektijuhtimine

> * Lisatud on jaotis Jube või puudub teenuste modereerimine

> * Lisatud jaotis Astroturfing

> * Lisatud on ebaseaduslike ja ebaeetiliste äritavade jaotis

> * Lisatud alajaotus Euroopas

>> * Lisatud Põhja-Ameerikas alajaotus

>> * Lisatud alajagu Vastuolud

> * Lisatud on Google'i automatiseeritud jaotis

> * Lisas jaotise Android

> * Lisas jaotise Väikesed toimingud abiks

> * Lisas jaotise ebausaldusväärne

> * Lisatud sponsoriteabe jaotis

> * Värskendas jalust

> * Värskendas failiteabe jaotist

> * Värskendas failiajaloo jaotist

> * Versioonis 5 muid muudatusi pole

Versioon 6 (pühapäev, 18. aprill 2021 kell 16.18)

> Muudatused:

> * Uuendas indeksit

> * Lisatud uus ülevaatlik kirjeldus

> * Värskendatud artikli oleku teave

> * Lisas lingi uuele Google FLoC artiklile

> * Lisatud link Wuest 3n Fuchs Degoogle'i artiklile ja selle üldine teave

> * Värskendas failiteabe jaotist

> * Värskendas failiajaloo jaotist

> * Versioonis 6 muid muudatusi pole

Versioon 7 (varsti saadaval)

> Muudatused:

> * Varsti

> * Versioonis 7 muid muudatusi pole

Versioon 8 (varsti saadaval)

> Muudatused:

> * Varsti

> * Versioonis 8 muid muudatusi pole

Versioon 9 (varsti saadaval)

> Muudatused:

> * Varsti

> * Versioonis 9 muid muudatusi pole

Versioon 10 (varsti saadaval)

> Muudatused:

> * Varsti

> * Versioonis 10 muid muudatusi pole

Versioon 11 (varsti saadaval)

> Muudatused:

> * Varsti

> * Versioonis 11 muid muudatusi pole

Versioon 12 (varsti saadaval)

> Muudatused:

> * Varsti

> * Versioonis 12 muid muudatusi pole

***

## jalus

Olete jõudnud selle faili lõppu

([Tagasi üles] (# Üles) | [Tagasi GitHubi] (https://github.com))

### EOF

***
