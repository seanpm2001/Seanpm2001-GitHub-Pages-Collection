***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle hidup Anda

Ini adalah artikel degoogling utama untuk info degoogling umum dan link ke artikel lainnya.

[Lihat daftarnya sebagai organisasi GitHub] (https://github.com/Degoogle-your-life)

***

_Baca artikel ini dalam bahasa lain: _

** Bahasa saat ini adalah: ** `` English (US) `_ (terjemahan mungkin perlu diperbaiki untuk memperbaiki bahasa Inggris menggantikan bahasa yang benar) _

_🌐 Daftar bahasa_

** Diurutkan berdasarkan: ** `A-Z`

[Opsi penyortiran tidak tersedia] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albania | [am አማርኛ] (/. github / README_AM.md) Amharik | [ar عربى] (/.github/README_AR.md) Arab | [hy հայերեն] (/. github / README_HY.md) Armenia | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijan | [eu Euskara] (/. github /README_EU.md) Basque | [be Беларуская] (/. Github / README_BE.md) Belarusia | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) Bulgaria | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) China (Sederhana) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) China (Tradisional) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Kroasia | [cs čeština] (/. Github / README_CS .md) Ceko | [da dansk] (README_DA.md) Denmark | [nl Nederlands] (/. github / README_ NL.md) Belanda | [** en-us English **] (/. github / README.md) Inggris | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonia | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finlandia | [fr français] (/. github / README_FR.md) Prancis | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galisia | [ka ქართველი] (/. github / README_KA) Georgia | [de Deutsch] (/. github / README_DE.md) Jerman | [el Ελληνικά] (/. github / README_EL.md) Yunani | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Kreol Haiti | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) Ibrani | [hai हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hungaria | [adalah Íslenska] (/. github / README_IS.md) Islandia | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandia | [ga Gaeilge] (/. github / README_GA.md) Irlandia | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Jepang | [jw Wong jawa] (/. github / README_JW.md) Jawa | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Korea (Selatan) | [ko-north 문화어] (README_KO_NORTH.md) Korea (Utara) (BELUM DITERJEMAHKAN) | [ku Kurdî] (/. github / README_KU.md) Kurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgistan | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lituavi | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksemburg | [mk Македонски] (/. github / README_MK.md) Makedonia | [mg Malagasi] (/. github / README_MG.md) Malagasi | [ms Bahasa Melayu] (/. github / README_MS.md) Melayu | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Malta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolia | [မြန်မာ saya] (/. github / README_MY.md) Myanmar (Burma) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) Norsk | [atau ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persia [pl polski] (/. github / README_PL.md) Polandia | [pt português] (/. github / README_PT.md) Portugis | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Tidak ada bahasa yang dimulai dengan huruf Q | [ro Română] (/. github / README_RO.md) Rumania | [ru русский] (/. github / README_RU.md) Rusia | [sm Faasamoa] (/. github / README_SM.md) Samoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Gaelik Skotlandia | [sr Српски] (/. github / README_SR.md) Serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slowakia | [sl Slovenščina] (/. github / README_SL.md) Slovenia | [jadi Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spanyol | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Swedia | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Turki | [tk Türkmenler] (/. github / README_TK.md) Turkmenistan | [uk Український] (/. github / README_UK.md) Ukraina | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnam | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Tersedia dalam 110 bahasa (108 jika tidak termasuk Inggris dan Korea Utara, karena Korea Utara belum diterjemahkan [Baca tentang itu di sini] (/ Versi Lama / Korea (Utara ) /README.md))

Terjemahan dalam bahasa selain bahasa Inggris adalah terjemahan mesin dan belum akurat. Belum ada kesalahan yang diperbaiki per 5 Februari 2021. Laporkan kesalahan terjemahan [di sini] (https://github.com/seanpm2001/Degoogle-your-life/issues/) pastikan untuk mencadangkan koreksi Anda dengan sumber dan pandu saya , karena saya tidak tahu bahasa selain bahasa Inggris dengan baik (saya berencana untuk mendapatkan penerjemah pada akhirnya) harap kutip [wiktionary] (https://en.wiktionary.org) dan sumber lain dalam laporan Anda. Gagal melakukannya akan mengakibatkan penolakan publikasi koreksi.

Catatan: karena keterbatasan interpretasi GitHub tentang penurunan harga (dan hampir semua interpretasi penurunan harga berbasis web lainnya) mengklik tautan ini akan mengarahkan Anda ke file terpisah di halaman terpisah yang bukan halaman profil GitHub saya. Anda akan dialihkan ke [repositori seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), tempat README dihosting.

Terjemahan dilakukan dengan Google Translate karena terbatas atau tidak ada dukungan untuk bahasa yang saya butuhkan di layanan terjemahan lain seperti DeepL dan Bing Translate (cukup ironis untuk kampanye anti-Google) Saya sedang mencari alternatif. Untuk beberapa alasan, pemformatan (tautan, pemisah, cetak tebal, miring, dll.) Kacau dalam berbagai terjemahan. Membosankan untuk memperbaikinya, dan saya tidak tahu cara memperbaiki masalah ini dalam bahasa dengan karakter non-latin, dan bahasa kanan ke kiri (seperti bahasa Arab) diperlukan bantuan tambahan untuk memperbaiki masalah ini.

Karena masalah pemeliharaan, banyak terjemahan yang kedaluwarsa dan menggunakan versi lama dari file artikel `README` ini. Seorang penerjemah dibutuhkan. Selain itu, mulai 9 April 2021, saya memerlukan beberapa saat untuk membuat semua tautan baru berfungsi.

***

## Indeks

[00.0 - Judul] (# Degoogling --- Degoogle-hidup-Anda)

> [00.1 - Indeks] (# Indeks)

[01.0 - Deskripsi dasar] (# Deskripsi-dasar)

> [01.1 - Tajuk gudang] (# Degoogle-kehidupan-Anda)

> [01.2 - Ikhtisar deskripsi Wuest3NFuchs] (# Overview-by-Wuest3nFuchs)

>> [01.2.1 - Apa artinya?] (# What-does-it-mean - by-Wuest3nFuchs)

>> [01.2.2 - Mengapa Degoogle?] (# Why-Degoogle - by-Wuest3nFuchs)

[02.0 - Artikel] (# Artikel)

[03.0 - Privasi] (# Privasi)

[04.0 - Kampanye anti-Google lainnya] (# Kampanye-anti-Google lainnya)

> [04.0.1 - Mati] (# Mati)

> [04.0.2 - Sedang Berlangsung] (# Sedang Berlangsung)

[05.0 - Melawan argumen lain] (# Countering-other-arguments)

> [05.0.1 - Kenyamanan] (# Kenyamanan)

> [05.0.2 - Mengapa itu penting? Lagipula sudah terlambat] (# Why-do-it-matter, -its-too late-anyways)

> [05.0.3 - Lainnya] (# Lainnya)

[06.0 - Sumber] (# Sumber)

[07.0 - Download link] (# Download-link)

[08.0 - Pengalaman degoogling saya] (# Pengalaman-degoogling-saya)

> [08.1 - Dari mana saya beralih] (# What-I-switched-from)

> [08.2 - Produk yang masih belum bisa saya tinggalkan] (# Products-I-still-can't-get-away-from)

[09.0 - Hal lain untuk diperiksa] (# Hal-lain-untuk-check-out)

[10.0 - Info file] (# Info-file)

> [10.1 - Status perangkat lunak] (# Status-perangkat lunak)

> [10.2 - Info sponsor] (# Info-Sponsor)

[11.0 - Riwayat file] (# Riwayat file)

[12.0 - Footer] (# Footer)

***

## Deskripsi dasar

[Dari Wikipedia: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

Gerakan DeGoogle (juga disebut gerakan de-Google) adalah kampanye akar rumput yang muncul karena aktivis privasi mendesak pengguna untuk berhenti menggunakan produk Google sepenuhnya karena kekhawatiran privasi yang berkembang terkait perusahaan. Istilah tersebut mengacu pada tindakan menghapus Google dari kehidupan seseorang. Seiring pertumbuhan pangsa pasar raksasa internet yang menciptakan kekuatan monopoli bagi perusahaan di ruang digital, semakin banyak jurnalis yang mencatat kesulitan untuk menemukan alternatif produk perusahaan.

**Sejarah**

Pada 2013, John Koetsier dari Venturebeat mengatakan tablet berbasis Android Kindle Fire Amazon adalah "versi Android de-Google-ized." Pada tahun 2014 John Simpson dari US News menulis tentang "hak untuk dilupakan" oleh Google dan mesin telusur lainnya. Pada 2015, Derek Scally dari Irish Times menulis artikel tentang cara "De-Google hidup Anda." Pada 2016 Kris Carlon dari Android Otoritas menyarankan agar pengguna CyanogenMod 14 dapat melakukan "de-Google" pada ponsel mereka, karena CyanogenMod juga berfungsi dengan baik tanpa aplikasi Google. Pada tahun 2018, Nick Lucchesi dari Inverse menulis tentang bagaimana ProtonMail mempromosikan cara "dapat sepenuhnya mengubah hidup Anda dari Google.” Brendan Hesse dari Lifehacker menulis tutorial mendetail tentang "keluar dari Google." Jurnalis Gizmodo, Kashmir Hill, mengklaim bahwa dia melewatkan rapat dan kesulitan mengatur pertemuan tanpa menggunakan Google Kalender. Pada tahun 2019, Huawei memberikan pengembalian dana kepada pemilik ponsel di Filipina yang terhambat dalam menggunakan layanan yang disediakan oleh Google karena begitu sedikit alternatif yang ada sehingga tidak adanya produk perusahaan membuat penggunaan internet biasa menjadi tidak layak.

***

# Degoogle-hidup-Anda
Sebuah repositori untuk info degoogling umum dan link ke repositori degoogling saya yang lain.

***

## Ikhtisar oleh Wuest3nFuchs

Deskripsi yang lebih baik, disediakan oleh [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - sumber: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Apa artinya? oleh Wuest3nFuchs

Degoogling berarti berhenti menggunakan apa pun yang menjadi milik Google, apa pun yang dibuat oleh Google. Saya berbicara tentang mesin pencari mereka, layanan surat mereka (Gmail), Youtube, dll.

### Mengapa Degoogle? oleh Wuest3nFuchs

Google adalah salah satu perusahaan terkuat di dunia saat ini. Mereka telah menyimpan sejumlah besar informasi tentang kita semua. Beberapa orang akan berpendapat bahwa informasi kami aman bersama mereka karena mereka tahu cara melindunginya. Tapi ini tidak benar. Google telah merambah sebelumnya dan akan merambah di masa depan. Mungkin bukan oleh beberapa script kiddie tapi itu akan dilakukan oleh negara bangsa. Google menyimpan informasi pribadi kita semua karena begitulah cara mereka menghasilkan uang.

Mereka memindai email kita, menyimpan apa yang kita cari saat kita menggunakan mesin pencari mereka, video apa yang kita tonton di Youtube. Beginilah cara mereka menargetkan kita dan membuat profil pada kita untuk menampilkan beberapa iklan berdasarkan apa yang kita bicarakan dengan sahabat kita sehingga mereka dapat menampilkan iklan untuk sesuatu yang kita butuhkan, tetapi ini terlalu menyeramkan. Berkat Tn. Snowden, kami sekarang tahu bahwa Google telah membagikan informasi pribadi kami dengan NSA di bawah program yang disebut ** "PRISM" **.


Di masa depan seseorang akan dapat mengakses semua informasi itu dan saya jamin sesuatu yang sangat buruk akan terjadi. Untuk mencegah hal itu terjadi, Anda harus memulai Degoogling sekarang juga. Selain itu, Anda tidak boleh menggunakan produk dari perusahaan yang membagikan data Anda dengan ** NSA **. Anda harus menghentikan semua ini dengan degoogling.

** Jika orang lain bisa melakukannya, Anda juga bisa melakukannya. **

[Baca selengkapnya di sini] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Tautan ke garpu saat ini tidak terdaftar, karena saya tidak memiliki repositori ini seluruhnya, dan ingin mempromosikan sumber lain. Sungguh egois untuk menautkan ke https://github.com/Degoogle-your-life/Degoogle saya sendiri! ->

***

## Artikel

### Status artikel

_Semua artikel saat ini sedang dalam proses dan membutuhkan peningkatan besar-besaran. Saran dan perbaikan diperbolehkan._

_Per 18 April 2021 pukul 16:09, sebagian besar artikel belum dimulai. Saya sedang berusaha mencari waktu dan upaya untuk memulainya._

[Mengapa Anda harus berhenti menggunakan Google Chrome] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Berhenti menggunakan ChromeBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Berhenti menggunakan WideVine DRM / Saatnya memotong WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Mengapa Anda harus berhenti menggunakan ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Alternatif dari YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Berhenti Googling, mengapa Anda harus berhenti menggunakan Google Penelusuran] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[Mengapa Anda harus berhenti menggunakan Gmail] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Mengapa Anda harus berhenti menggunakan Android] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Mengapa Anda harus menghindari Google Amp] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Mengapa Anda harus berhenti menggunakan Google Drive] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Mengapa Anda harus berhenti menggunakan Google Maps dan Google Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Hai Google, hentikan] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Berhenti membaca dari Google / Play buku] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Berhenti menggunakan Google Kelas] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Mengapa Anda harus berhenti menggunakan Google Terjemahan] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Mengapa Anda harus berhenti menggunakan Akun Google Anda] (https://github.com/seanpm2001/Why-you-should-sAkun-Google yang paling banyak digunakan) <! - 16! ->

** Artikel baru akan segera ditulis: **

[Mengapa Anda harus berhenti menggunakan Gerrit] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Mengapa Anda harus berhenti menggunakan Google Analytics (repositori rusak di pihak saya pada Rabu, 24 Februari 2021 pukul 16:13)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics) <! - 18! ->

<! - Pembatas kerja! ->

[Mengapa Anda harus berhenti menggunakan Google AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Mengapa Anda harus berhenti menggunakan Google One] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Mengapa Anda harus berhenti menggunakan Google+ (tidak berfungsi)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Mengapa Anda harus berhenti menggunakan Google Play Store] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Mengapa Anda harus berhenti menggunakan Google Dokumen] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Mengapa Anda harus berhenti menggunakan Google Slide] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Mengapa Anda harus berhenti menggunakan Google Sheets] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Mengapa Anda harus berhenti menggunakan Google Formulir] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Mengapa Anda harus berhenti menggunakan Google Cardboard] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Mengapa Anda harus berhenti menggunakan Google Message] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Mengapa Anda harus berhenti menggunakan Desain Material Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Mengapa Anda harus berhenti menggunakan Google Glass / Kacamata] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Mengapa Anda harus berhenti menggunakan Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Mengapa Anda harus berhenti menggunakan GBoard] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Mengapa Anda harus berhenti menggunakan Google Home] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Mengapa Anda harus berhenti menggunakan Google Nest] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Mengapa Anda harus berhenti menggunakan Google Hangouts (tidak berfungsi)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Mengapa Anda harus berhenti menggunakan Google Duo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Mengapa Anda harus berhenti menggunakan Google Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Mengapa Anda harus berhenti menggunakan Google Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Mengapa Anda harus berhenti menggunakan Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Mengapa Anda harus berhenti menggunakan bahasa pemrograman Googles Go] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Mengapa Anda harus berhenti menggunakan bahasa pemrograman Google Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Mengapa Anda harus berhenti menggunakan format gambar WebP Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Mengapa Anda harus berhenti menggunakan format video WebM Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Mengapa Anda harus berhenti menggunakan Google Video] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Mengapa Anda harus berhenti menggunakan Google Sites (klasik)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Mengapa Anda harus berhenti menggunakan Google Sites ("Baru")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Mengapa Anda harus berhenti menggunakan Google Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Mengapa Anda harus berhenti menggunakan Android Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Mengapa Anda harus berhenti menggunakan Google VPN (oxymoron)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Mengapa Anda harus berhenti menggunakan Google Foto] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[Mengapa Anda harus berhenti menggunakan Google Kalender] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Mengapa Anda harus berhenti menggunakan VirusTotal (karena telah dimiliki oleh Google sejak September 2012] (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Mengapa Anda harus berhenti menggunakan Google Fi] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi) <! - 53! ->

[Mengapa Anda harus berhenti menggunakan Google Stadia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Mengapa Anda harus berhenti menggunakan Google Keep] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Mengapa Anda harus berhenti menggunakan Google Base] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Mengapa Anda harus berhenti berpartisipasi dalam Google Summer of Code] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Mengapa Anda harus berhenti menggunakan Google Kamera] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Mengapa Anda harus berhenti menggunakan Google Kalkulator (mungkin tampak ekstrem, tetapi Anda harus melepaskan Google dari segalanya, sangat mudah untuk berganti-ganti)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Kalkulator) <! - 59! ->

[Mengapa Anda harus berhenti menggunakan Google Survey + rewards] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Mengapa Anda harus berhenti menggunakan Google Gambar] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Mengapa Anda harus berhenti menggunakan Tenor (situs GIF, milik Google sejak 2019)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Apa FLoC - Mengapa Anda harus menghindari masalah besar FLoCing Google (berhenti menggunakan Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Total artikel: ** `63`

** Artikel [roadmap AB] (DegoogleCampaign_2021Roadmap_Part1.md) (hingga 12 Maret 2021) 2 hari libur **

** Artikel [roadmap BB] (DegoogleCampaign_2021Roadmao_Part2.md) (hingga? 2021) 2 hari libur **

Status artikel

Semua artikel saat ini sedang dalam proses dan membutuhkan perbaikan besar-besaran. Saran dan perbaikan diperbolehkan.

** Garpu **

Memperluas jaringan Degoogle saya, dan menambahkan beberapa kemudahan akses, dan teriakan komunitas.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Bercabang dari: [https://github.com/wacko1805/Fossapps](https://github.com/wacko1805/Fossapps) (Inggris)

2. [Tautan-privasi] (https://github.com/Degoogle-your-life/Privacy-links) | Bercabang dari: [https://github.com/Arturro43/privacy-links](https://github.com/Arturro43/privacy-links) (Polandia)

3. [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Bercabang dari: [https://github.com/LinuxCafeFederation/Delightful-Privacy](https://github.com/LinuxCafeFederation/Delightful-Privacy) (Inggris)

4. [Daftar Blokir] (https://github.com/Degoogle-your-life/blocklists) | Bercabang dari: [https://github.com/jmdugan/blocklists](https://github.com/jmdugan/blocklists) (Inggris)

5. [Degoogle, oleh Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Bercabang dari: [https://github.com/Wuest3nFuchs/Degoogle](https://github.com/Wuest3nFuchs/Degoogle) (Inggris)

** Terkait **

[Penelitian Mesin Virtual ponsel Android degoogled] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Lihat juga:**

[Kritik Google di Wikipedia] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[The Google Graveyard (killbygoogle.com) - daftar yang diurutkan dari 224+ produk yang telah dibunuh oleh Google] (https://killedbygoogle.com/)

> [Tautan GitHub] (https://github.com/codyogden/killedbygoogle)

[Serikat pekerja alfabet - Serikat pekerja baru di Google dengan lebih dari 800 anggota] (https://alphabetworkersunion.org/people/our-union/)

[Tidak ingin berpisah dengan telur paskah dinosaurus? Situs web ini membantu Anda] (https://chromedino.com/)

***

## Privasi

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument # Criticism) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -essay-samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- of-data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -your-personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -monetizes-and) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- collection-mengungkapkan.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ kesehatan-kebugaran-data-privasi /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https://moz.com /blog/where-does-google-draw-the-data-collection-line)[e](https://mashable.com/article/google-android-data-collection-study/)[s](https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)[o](https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -klaim-atas-nama-dari-5-m illion-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/)[r](https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/)[i](https://www.cbsnews.com/news/google-education-spies-on-collects- data-on-million-of-kids-alleges-lawsuit-new-mexico-attorney-general /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -di bawah hidung kita /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / technology / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : //medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Saya dapat melanjutkan dan melanjutkan dengan bukti ini, tetapi butuh waktu lama untuk menemukan dan mempelajari semua ini artikel)

Privasi pada produk Google selalu buruk, karena semua produk Google mengandung spyware.

Apa pun yang Anda lakukan, saat Anda menggunakan Google, semua data pribadi sensitif Anda dikirim ke Google dan orang lain. Google juga terlihat melakukan program terbuka. Misalnya, dari pengalaman pribadi (di Firefox) dengan tab YouTube terbuka yang tidak saya kunjungi, saya menonton beberapa video secara offline (VLC Media Player) Kemudian ketika saya pergi untuk memeriksa rekomendasi, itu hampir semua yang saya tonton. Tidak diragukan lagi mereka juga memata-matai program lain.

Di Chrome (dan banyak browser lainnya) mode penyamaran hadir. Di Chrome, mode ini tidak ada gunanya, karena Google masih akan menambang data Anda. Meskipun Anda menonaktifkan penambangan / pelacakan data, dan mengaktifkan sinyal "jangan lacak", kejutan mengejutkan, Google masih menambang data Anda.

Jika Anda merasa tidak ada yang perlu disembunyikan, ** Anda salah **. Argumen ini telah dibantah berkali-kali:

[Melalui Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden berkomentar "Mendebat bahwa Anda tidak peduli tentang hak privasi karena Anda tidak memiliki apa pun untuk disembunyikan tidak berbeda dengan mengatakan Anda tidak peduli dengan kebebasan berbicara karena Anda tidak memiliki apa-apa untuk dikatakan." Ketika Anda mengatakan, ' Saya tidak menyembunyikan apa pun, 'Anda berkata,' Saya tidak peduli tentang hak ini. 'Anda berkata,' Saya tidak memiliki hak ini, karena saya sudah sampai pada titik di mana saya harus membenarkan. itu. 'Cara kerja hak adalah, pemerintah harus membenarkan gangguannya terhadap hak-hak Anda. "

2. Daniel J. Solove menyatakan dalam sebuah artikel untuk The Chronicle of Higher Education bahwa ia menentang argumen tersebut; dia menyatakan bahwa pemerintah bisa belajark informasi tentang seseorang dan menyebabkan kerusakan pada orang itu, atau menggunakan informasi tentang seseorang untuk menolak akses ke layanan bahkan jika seseorang tidak benar-benar melakukan kesalahan, dan bahwa pemerintah dapat menyebabkan kerusakan pada kehidupan pribadi seseorang melalui kesalahan. Solove menulis, "Ketika terlibat secara langsung, argumen tidak ada yang disembunyikan dapat menjerat, karena memaksa debat untuk fokus pada pemahaman sempitnya tentang privasi. Tetapi ketika dihadapkan dengan pluralitas masalah privasi yang terkait dengan pengumpulan dan penggunaan data pemerintah di luar pengawasan dan pengungkapan, argumen tidak ada yang disembunyikan, pada akhirnya, tidak memiliki apa-apa untuk dikatakan. "

3. Adam D. Moore, penulis Privacy Rights: Moral and Legal Foundations, berpendapat, "ini adalah pandangan bahwa hak tahan terhadap biaya / manfaat atau semacam argumen konsekuensialis. Di sini kami menolak pandangan bahwa kepentingan privasi adalah semacam itu. hal-hal yang dapat diperdagangkan untuk keamanan. " Ia juga menyatakan bahwa pengawasan dapat mempengaruhi kelompok tertentu dalam masyarakat secara tidak proporsional berdasarkan penampilan, etnis, seksualitas, dan agama.

4. Bruce Schneier, seorang ahli keamanan komputer dan kriptografer, menyatakan penolakannya, mengutip pernyataan Kardinal Richelieu "Jika seseorang memberi saya enam baris yang ditulis oleh tangan orang yang paling jujur, saya akan menemukan sesuatu di dalamnya untuk membuatnya digantung", merujuk tentang bagaimana pemerintah negara bagian dapat menemukan aspek-aspek dalam kehidupan seseorang untuk menuntut atau memeras individu tersebut. Schneier juga berpendapat, "Terlalu banyak yang secara keliru menggolongkan perdebatan sebagai 'keamanan versus privasi.' Pilihan sebenarnya adalah kebebasan versus kendali. "

5. Harvey A. Silverglate memperkirakan bahwa orang biasa, rata-rata, tanpa sadar melakukan tiga kejahatan sehari di AS.

6. Emilio Mordini, filsuf dan psikoanalis, berpendapat bahwa argumen "tidak ada yang disembunyikan" pada dasarnya bersifat paradoks. Orang tidak perlu memiliki "sesuatu yang disembunyikan" untuk menyembunyikan "sesuatu". Apa yang disembunyikan belum tentu relevan, klaim Mordini. Sebaliknya, dia berpendapat bahwa area intim yang dapat disembunyikan dan akses dibatasi diperlukan karena, secara psikologis, kita menjadi individu melalui penemuan bahwa kita dapat menyembunyikan sesuatu kepada orang lain.

7. Julian Assange menyatakan "Belum ada jawaban yang mematikan. Jacob Appelbaum (@ioerror) memiliki tanggapan yang cerdas, meminta orang-orang yang mengatakan ini untuk kemudian menyerahkan ponsel mereka tidak terkunci dan menurunkan celananya. Versi saya adalah mengatakan, 'well, jika kamu begitu membosankan maka kami tidak boleh berbicara dengan kamu, dan begitu pula dengan orang lain', tetapi secara filosofis, jawaban sebenarnya adalah ini: Pengawasan massal adalah perubahan struktural massal. Ketika masyarakat memburuk, itu akan terjadi untuk membawamu bersamanya, bahkan jika kamu adalah orang paling hambar di dunia. "

8. Ignacio Cofone, profesor hukum, berpendapat bahwa argumen tersebut salah dalam istilahnya sendiri karena, setiap kali orang mengungkapkan informasi yang relevan kepada orang lain, mereka juga mengungkapkan informasi yang tidak relevan. Informasi yang tidak relevan ini memiliki biaya privasi dan dapat menyebabkan kerugian lain, seperti diskriminasi.

***

## Kampanye anti-Google lainnya

Ini adalah daftar kampanye anti-Google terkenal lainnya. Daftar ini tidak lengkap. Anda dapat membantu dengan mengembangkannya.

### Mati

[Digeledah - Oleh Microsoft (November 2012 hingga 2014)] (https://en.wikipedia.org/wiki/Scroogled)

_Tidak ada entri lain saat ini._

### Sedang Berlangsung

_Daftar ini saat ini kosong._

***

## Melawan argumen lain

Ada beberapa argumen yang dibuat orang untuk membenarkan Google. Salah satu yang utama pertama sudah dibantah [di sini] (# Privasi) tetapi berikut adalah beberapa yang lain:

### Kenyamanan

Ya, produk Google sepertinya nyaman. Namun, Anda memperdagangkan segala sesuatu untuk kenyamanan, termasuk keamanan, privasi, dan keandalan. Google semakin malas selama bertahun-tahun, dan server mereka semakin turun. Saat ini, server Google turun hampir satu jam 1-2 kali per bulan (terutama YouTube)

Sayangnya, karena ketergantungan masyarakat pada Google, Google telah mendominasi Internet, dan berusaha untuk mengontrol lebih banyak lagi. Pada tahun 2012, saat Google mengalami gangguan selama 5 menit, dilaporkan bahwa ** global ** lalu lintas Internet ** turun sebesar 40% ** Google sering berhenti beroperasi selama 1-2 jam, dan dengan [pemecatan tim etik mereka] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) antara lain, mereka akan menjadi semakin tidak nyaman.

Kenyamanan tidak selalu merupakan hal yang baik. Anda harus menyadari apa yang sedang terjadi dan bersiap-siap ketika mereka turun, karena tidak ada cara agar server tidak mati sesekali.

Google juga tidak senyaman yang Anda pikirkan. Ada situs lain yang jauh lebih nyaman. Google jauh dari nyaman, ketika Anda memperhitungkan penangguhan dan penghentian akun acak mereka tanpa tanggapan (kecuali Anda cukup menarik perhatian ke akun twitter Google atau menuntut mereka sebesar $ 100.000.000 atau lebih) maka mereka telah memanfaatkan Anda, mengacaukan Anda, dan memaksa Anda untuk berteriak ke bantal, di mana tidak ada yang bisa mendengar teriakan Andauntuk bantuan.

### Mengapa itu penting, sudah terlambat

Ini adalah argumen yang kurang umum, tetapi perlu penjelasan. Dengan keadaan saat ini, sebagian besar pemerintah dunia, bersama dengan beberapa perusahaan kuat tampaknya mengetahui setiap gerakan Anda, jadi mengapa repot-repot menjauh darinya? Jawabannya sederhana: ** Anda pantas mendapatkan yang lebih baik **. Jika Anda berhasil menjauh dari mereka pada saat ini, akan lebih sulit bagi mereka untuk melacak langkah Anda lebih jauh, dan Anda dapat membangun kehidupan baru yang lebih pribadi.

[1 sumber] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Ngomong-ngomong, saya telah memberikan penghargaan Reddit gratis untuk postingan ini setiap kali saya mendapatkannya selama lebih dari seminggu sekarang (bersama dengan 500 koin gratis saya) untuk meningkatkan topik ini lebih jauh. Sejauh ini, saya telah memberikan posting ini lebih dari 14 penghargaan gratis. Memang tidak banyak, tapi hal-hal kecil bisa berdampak besar, tergantung bagaimana hal itu dipersepsikan, dan oleh siapa.

### Lainnya

Saya tidak memiliki argumen lain saat ini.

_Daftar ini tidak lengkap_

***

## Sumber

Salinan:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritik) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-tentang-Anda-Anda-dapat-menemukan-dan-menghapus-sekarang /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -dan) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- klaim-atas-nama-5-juta-pengguna-iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technology / 2014/01 / what-google-can-really-do-nest-or-really-nests-data /) [i] (https://www.cbsnews.com/news/google-education -spies-on-collects-data-on-million-of-kids-alleges-lawsuit-new-mexico-attorney-general /) [v] (https://www.nationalreview.com/2018/04/the- student-data-mining-scandal-under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did -have-something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Sumber lain:

[Aliansi Lima Mata] (https://en.wikipedia.org/wiki/Five_Eyes) [Sembilan belas delapan puluh empat] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Unduh tautan

[Dapatkan Firefox] (https://www.mozilla.org/en-US/firefox/new/) [Dapatkan browser Tor] (https://www.torproject.org/download/) [Lainnya / tidak tersedia] (https : //www.example.com)

***

## Pengalaman degoogling saya

Saya akhirnya mulai melihat masalah dengan teknologi besar pada tahun 2018, dan saya mulai degoogling. Dalam beberapa bulan pertama, saya membuat kemajuan yang signifikan. Itu sangat melambat sejak saat itu.


### Dari mana saya beralih

Google Chrome -> Firefox / Tor

Pencarian Google -> DuckDuckGo (default) / Ecosia (saat saya ingin) / Bing (jarang)

GMail - ProtonMail (belum sepenuhnya diaktifkan)

Google Sites -> Hosting mandiri (belum sepenuhnya dialihkan)

Google+ -> Hampir tidak pernah digunakan, dihapus sendiri karena dimatikan sendiri

Google Docs -> Tidak pernah digunakan, saya hanya menggunakan Microsoft Word 2013 (sebelum 2019) dan LibreOffice (2019-dan seterusnya).

Google Sheets -> Tidak pernah digunakan, saya hanya menggunakan Microsoft Excel 2013 (sebelum 2019) dan LibreOffice (2019-dan seterusnya).

Google Slides -> Tidak pernah digunakan, saya hanya menggunakan Microsoft PowerPoint 2013 (sebelum 2019) dan LibreOffice (2019-dan seterusnya).

Google Gambar -> Tidak pernah digunakan, saya hanya menggunakan LibreOffice (2019-dan seterusnya).

Gerrit -> Tidak pernah digunakan, saya hanya menggunakan GitHub (default saat ini), GitLab, BitBucket, dan SourceForge sebagai gantinya.

Google Foto -> Tidak pernah digunakan

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-sekarang)

Google Maps -> OpenStreetMaps / Apple Maps

Go - Membuat pengecualian khusus, tetapi tidak menggunakan sebagai bahasa pemrograman fungsional

Dart - Membuat pengecualian khusus, tetapi tidak menggunakan sebagai bahasa pemrograman fungsional

Flutter - Membuat pengecualian khusus, tetapi tidak menggunakan sebagai bahasa pemrograman fungsional

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> Tidak pernah digunakan, saya merasa sangat menyeramkan

Google Fi -> Tidak pernah digunakan

Google Kalender -> Tidak pernah digunakan

Kalkulator Google -> Secara harfiah aplikasi kalkulator lainnya, bahkan terminal Linux yang berjalan dalam mode Python jika saya mau

Google Nest -> Tidak pernah digunakan

Google AMP -> Tidak pernah digunakan

Google VPN -> Tidak pernah digunakan, juga oxymoron

Google Pay -> Tidak pernah digunakan

Google Summer of Code -> Jangan pernah berpartisipasi

Tenor -> Situs GIF lain, meskipun GIF tidak terlalu penting bagi saya. Saya biasanya mendapatkan file GIF dari gambar DuckDuckGo, Imgur, Reddit, atau situs lain.

Blockly -> Tidak lagi digunakan, tidak yakin apakah Scratch langsung berjalan dengan blockly. Saya menjadi programmer fungsional pada tahun 2017 dan seterusnya, dan tumbuh dari Scratch.

GBoard -> Digunakan sekali, tetapi ditinggalkan

Google Glass -> Tidak pernah digunakan, dianggap sebagai anak kecil tetapi memutuskan untuk tidak mendapatkannya / menggunakan jika saya punya pilihan

_List mungkin tidak lengkap._

### Produk yang masih belum bisa saya tinggalkan

Mulai 25 Februari 2021, berikut adalah produk Google yang mencegah saya dari degoogling sepenuhnya:

1. YouTube

2. Android

3. Google Play Store

4. Gmail (hanya untuk sekolah dan beberapa situs)

5. Google Kelas (hanya untuk sekolah)

6. Google Terjemahan

7. Akun Google

8. Google Sites (karena Google melanggar hukum GDPR (dan dapat dikenakan denda € 5.000.000,00 lagi sampai diperbaiki) dan melarang download produk ini)

Saya telah merendahkan dari yang lainnya.

***

## Pergi itu jahat

Google steamrolled atas 2003 bahasa pemrograman Berbasis Agen `Go!` Dengan bahasa pemrograman mereka `Go` (dari 2009, 6 tahun kemudian) dan mengklaim bahwa bahasa mereka tidak akan mempengaruhi bahasa lain sama sekali. Google dikritik habis-habisan karena motto `Jangan jahat` mereka masih aktif saat itu, dan ini adalah salah satu dari banyak insiden yang membuat motto jangan jahat pensiun.

Pada akhirnya, pengembangan `Go !` berhenti, sementara` Go` menjadi semakin umum. Google mengklaim bahwa mereka tidak akan mencampuri `` Pergi! '' Tetapi pada akhirnya, mereka melakukannya, dan mereka lolos begitu saja (per 9 April 2021)

[Baca selengkapnya tentang Go dan cara berganti di sini] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Penggunaan DRM

Google menggunakan DRM (Digital Restrictions Management) melalui "layanan" WideVine DRM dan bentuk lainnya. Tujuan DRM adalah menghancurkan Internet yang terbuka dan memberi perusahaan kekuasaan monopoli atas pengguna. Anda harus menyingkirkan WideVine sepenuhnya, berapa pun biayanya.

[Baca selengkapnya tentang WideVine dan masalahnya di sini] (https://github.com/Degoogle-your-life/Its-time-to-cut-WideVine-DRM)

***

## Kesalahpahaman umum

Ini adalah daftar beberapa kesalahpahaman umum tentang produk Google.

### Google bukanlah Internet

Pencarian Google / Google bukanlah Internet, pencarian Google hanyalah mesin pencari, seperti bagaimana tidak setiap game untuk platform Nintendo dibuat oleh Nintendo, tetapi dilisensikan oleh Nintendo, tetapi pada tingkat yang jauh lebih besar. Jika semua server Google dihancurkan secara bersamaan saat ini, hanya Situs Google seperti YouTube, Gmail, Google Docs, pencarian Google, dll. Yang akan hilang, tetapi sebagian besar Internet akan tetap ada (Wikipedia, Stackoverflow, GitHub, semua situs web Microsoft, NYTimes, Samsung, TikTok, dll.) mereka mungkin kehilangan fungsi masuk dan analitis Google, tetapi mereka masih berfungsi (kecuali jika diprogram dengan buruk dan bergantung langsung pada Google)

***

## Internet Explorer 6 dan Chrome

Google Chrome menjadi Internet Explorer 6. Saat Google Chrome pertama kali diluncurkan, Firefox adalah browser yang dominan, dan sebagian besar telah mematikan pangsa pasar Internet Explorer (yang melampaui 96% sebelum jutaan orang beralih ke Firefox dan browser lain) saat Google Chrome keluar, orang-orang beralih karena kecepatannya dan itu dilakukan oleh Google (yang tidak dianggap jahat pada saat itu, karena sebagian besar masalah privasi belum terungkap) Google Chrome awalnya menghormati standar web (itulah yang dilakukan Firefox. yang membunuh 96% pangsa pasar browser Penjelajah Internet) namun, karena pangsa pasar Google Chromes meningkat, Google mulai menghapus lebih banyak fitur, menambahkan lebih banyak spyware, dan berhenti menerima standar web, Google Chrome telah menjadi Internet Explorer 6 yang baru.

Masalah utama saat ini adalah situs web yang hanya menggunakan Chrome, dan tidak akan berfungsi di browser lain, karena pengembang mereka memutuskan bahwa mereka tidak ingin 30-40% pengguna Internet lainnya yang tidak menggunakan Chrome menggunakan situs mereka.

Bahkan Google sendiri membuat situs mereka hanya untuk Chrome. Misalnya, penelusuran Google akan meminta Anda mengunduh Chrome 3 kali setiap 10 detik jika mendeteksi Anda tidak menggunakan Google Chrome (bahkan peramban berbasis Chromium lainnya seperti Brave juga terpengaruh) dan situs seperti Google Earth tidak mengizinkan pengguna Firefox untuk melakukannya. menggunakan situs mereka (per 2020) ditambah Google Terjemahan tidak mendukung input suara di Firefox, dan browser non-Google Chrome lainnya.

### Masalah dengan Brave

Browser lain yang berbasis Chromium, seperti Brave dan Microsoft Edge tidak sepenuhnya bebas dari spyware Google. Brave biasanya direkomendasikan oleh pihak yang salah dalam komunitas privasi, tetapi Brave masih menjadi masalah, karena menggunakan Chromium. Internet tidak boleh hanya terdiri dari browser Chromium, harus ada berbagai pilihan. Berani adalah jalan yang salah.

[Baca selengkapnya tentang degoogling dari Google Chrome / Chromium di sini] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Baca selengkapnya tentang degoogling dari ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) di sini] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Pembaruan privasi palsu

Google telah mencoba memberi tahu dunia bahwa mereka peduli dengan privasi, setelah semuanya terlambat. Mereka terus mengklaim bahwa mereka menghormati privasi pengguna, tetapi mereka masih belum memperbaiki semua masalah privasi mereka.

### Sumber terbuka tidak boleh sebagian

Sumber terbuka tidak boleh sebagian. Google adalah buktinya. Setiap bit dan byte dari kode sumber harus dapat dilihat oleh publik, bahkan dengan tidak menyembunyikan seperdelapan byte.

Proyek seperti Android dan ChromeOS sebagian merupakan sumber terbuka, tetapi mengandung sebagian besar elemen berpemilik, spyware.

### Oxymoron

Google VPN adalah sebuah oxymoron. Google tidak peduli dengan privasi, dan Jaringan Pribadi Maya (VPN) dari perusahaan seperti mereka akan menjadi salah satu pilihan terburuk untuk layanan VPN.

***

## Performa buruk

Google tidak peduli dengan performa produk mereka setidaknya pada tahun 2017, karena perangkat lunak pembandingan terakhir mereka (Google Octane) telah dihentikan pada tahun 2017.

***

## Manajemen proyek yang buruk

Google memiliki sistem manajemen proyek internal yang sangat buruk. Beberapa contoh umum dari program yang semakin banyak diturunkan versinya termasuk Google Duo dan musik YouTube (sebelumnya Google Play Musik)

Dalam sistem pengembangan internal Google, 1 aplikasi mengarah ke aplikasi lain dengan setengah dari fungsinya, lalu aplikasi asli akan dihapus. Beberapa tahun kemudian, aplikasi baru dengan fungsionalitas 75% lebih sedikit dibuat, dan kemudian aplikasi dengan fungsionalitas 50% dihapus, diikuti oleh aplikasi baru dengan 87,5% fungsionalitas sedang dibuat, kemudian aplikasi dengan 75% fungsionalitas dihentikan , dan seterusnya.

***

## Mengerikan atau tidak ada moderasi layanan

YouTube adalah contoh paling umum di dunia moderasi buruk yang menciptakan platform terburuk yang pernah ada. Google juga sepertinya tidak mengerti bahwa YouTube bukanlah anak-anak YouTube.

Untuk YouTube, konten pro-Nazi dan White Supremacist yang penuh kebencian disajikan kepada pengguna dengan tujuan untuk mendapatkan lebih banyak waktu interaksi dan lebih banyak uang. Google juga telah melakukan beberapa halhal-hal bodoh dalam jumlah sedang, seperti menyetujui video Seks Anal Kristen sebagai konten `Dibuat untuk Anak-Anak` sementara pada saat yang sama membatasi video tersebut berdasarkan usia. Tidak jarang juga melihat iklan pornografi atau sadis tepat di bawah video Baby Shark, bersama dengan berbagai konten `Dibuat untuk Anak-Anak` lainnya.

Pengguna YouTube sangat sering mengeluh tentang moderasi yang buruk di YouTube untuk konten yang buruk (seperti contoh yang tercantum di atas) sementara pengguna dapat menghapus videonya secara acak tanpa alasan tanpa kemampuan untuk mencabut, bersama dengan pengguna yang dihukum atas segala bentuk sumpah serapah, bahkan kasus yang sangat kecil seperti mengatakan `omong kosong`, pengguna biasanya membandingkan YouTube dengan [Uni Soviet] (https://en.wikipedia.org/wiki/Soviet_Union) di era Stalin, karena hukuman yang tidak setara ini.

Pada tahun 2021, Google mengumumkan bahwa mereka akan memasang iklan di semua video, meskipun video tersebut di-demonitisasi (agar Google menghasilkan uang, tetapi pembuatnya tidak) ini tidak terlalu berhubungan dengan moderasi, tetapi penting untuk diperhatikan.

YouTube dimoderasi (meskipun sangat buruk) tetapi layanan iklan Google yang menghasilkan sebagian besar uang mereka tampaknya memiliki sedikit atau tanpa moderasi.

[Baca lebih lanjut tentang masalah moderasi YouTube dan cara beralih dari YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Iklan untuk Google Play dihasilkan dari bot farm, Anda dapat mengetahui dari skenario iklan yang sama yang digunakan oleh ratusan perusahaan dengan sedikit perubahan, dan tidak ada hubungannya dengan produk (contoh umum: Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City, dan ribuan lainnya) bersama dengan tren iklan berbahaya yang sedang booming yang mengklaim bahwa pengguna dapat memperoleh uang dengan bermain game, mendengarkan musik, dll. PayPal belum mengomentari hal ini, tetapi jelas bahwa ini adalah penipuan, seolah-olah Anda dapat membuat lebih dari $ 10.000 dalam waktu kurang dari 20 detik dengan memainkan permainan yang dijamin, tidak ada yang akan melakukan pekerjaan dan akan melakukan ini sebagai gantinya, yang tidak mungkin, dan bisnis tidak dapat bekerja seperti ini. Penipuan yang jelas ini telah berkembang kuat sejak 2019, dan sekarang bot farm yang menghasilkan iklan ini saling berkelahi dalam iklan mereka sendiri.

Beberapa iklan juga sangat cabul, dan berusaha membuat pengguna (mayoritas dari mereka adalah pengguna di bawah usia 13 tahun, atau bot) untuk mengklik manipulasi seksual.

Banyak aplikasi menggunakan bot dan astroturf produk mereka, jadi setiap kali ulasan buruk dibuat, akun bot boneka kaus kaki akan mulai memposting ulasan bintang 5 dan berusaha meniadakan kritik Anda. [Google melakukannya sendiri juga] (# Astroturfing)

[Baca selengkapnya tentang masalah dengan Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

Definisi umum [(dari Wikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

``
Astroturfing adalah praktik menutupi sponsor pesan atau organisasi (misalnya, politik, periklanan, agama atau hubungan masyarakat) agar tampak seolah-olah berasal dari dan didukung oleh peserta akar rumput. Ini adalah praktik yang dimaksudkan untuk memberikan kredibilitas pada pernyataan atau organisasi dengan menahan informasi tentang hubungan keuangan sumber. Istilah astroturfing berasal dari AstroTurf, merek karpet sintetis yang dirancang menyerupai rumput alami, sebagai plesetan dari kata "akar rumput". Implikasi di balik penggunaan istilah ini adalah bahwa alih-alih upaya akar rumput yang "benar" atau "alami" di balik aktivitas yang dipermasalahkan, ada tampilan dukungan yang "palsu" atau "artifisial".
``

Google memiliki sejarah astroturfing untuk membuatnya tampak seperti mereka tidak melakukan sesuatu yang jahat (dalam prosesnya, astroturfing itu jahat) misalnya, memposting kritik terhadap Google di platform seperti Twitter (yang mereka miliki akunnya) akan menghasilkan beberapa akun yang telah ada untuk sementara waktu tetapi tidak pernah diposting sebelum keluar dan mengklaim bahwa apa yang Anda katakan itu salah, dan kemudian mengklaim bahwa Google adalah perusahaan terbaik, tetapi dilakukan dengan cara yang mungkin tidak jelas bahwa ini adalah bot untuk sebagian besar orang-orang.

***

## Praktik bisnis ilegal dan tidak etis

Google menggunakan praktik bisnis ilegal dan tidak etis untuk melanjutkan monopoli mereka, seperti menggunakan tempat bebas pajak, pekerjaan outsourcing, dan terus melakukan aktivitas invasif ilegal sebagai biaya menjalankan bisnis.

### Di Eropa

Eropa sering menggugat Google, gugatan terbesar adalah terhadap perilaku ilegal di Android, yang mengakibatkan Google menerima € 5.000.000.000 (setara dengan $ 5.947.083.703,68 dalam uang 9 April 2021)

### Di Amerika Utara

Amerika Serikat belum memberikan denda yang hampir cukup kepada Google, dibandingkan dengan denda € 5.000.000.000 di Eropa.

### Kontroversi

Google tidak peduli tentang suatu masalah sampai hal itu menimbulkan kontroversi, kemudian mereka akan melakukan upaya yang buruk untuk memperbaikinya, cukup agar kontroversi tersebut menghilang sementara, dan masalah tersebut kemudian menjadi semakin buruk secara eksponensial hingga menimbulkan kontroversi lain, dan siklus terus berlanjut. Mereka tidak cukup peduli untuk melakukan sesuatu yang serius tentang itu.

***

## Google otomatis

Sebagai seorang company, Google sebagian besar otomatis, dengan lebih sedikit moderasi daripada otomatisasi.

Perusahaan tidak boleh sepenuhnya otomatis. Google adalah contohnya. Moderasi mengerikan bila dilakukan hanya oleh AI, YouTube adalah contoh yang baik, bahkan dengan tambahan sedikit (ratusan, atau mungkin seribu) orang yang memoderasi situs, di mana tampaknya sangat buruk sehingga kebanyakan dari mereka harus menjalani terapi saat bekerja.

***

## Android

Android dimiliki oleh Google. Bagian dari Open Handset Alliance (yang belum dibuka sejak Android) Android telah menjadi titik monopoli lain bagi Google, dan sangat sulit untuk dihindari.

Android telah dilaporkan menelepon ke rumah ke Google setidaknya 10 kali per hari, dan meskipun sebagian bersifat open source, ia masih bertindak berat sebagai spyware.

Beberapa proyek telah dibuat untuk menggantikan Android, tetapi membutuhkan rooting perangkat Anda. Ini tidak mungkin lagi untuk ponsel Samsung tertentu di AS, karena Knox DRM. Alternatif umum untuk Android termasuk iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch, dan PiPhone (Pi Phone adalah merek ponsel yang menjalankan berbagai sistem Linux pada perangkat seluler, seperti Fedora, Ubuntu, Arch, dll.)

[Lihat penelitian saya tentang mendapatkan fungsi mesin virtual Android yang terdegoogle] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Lihat cara degoogle dari Android] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Tindakan kecil untuk membantu

Menyebarkan kesadaran dengan segala cara yang Anda bisa itu penting. Bagi saya, saya tidak hanya sering berbicara tentang degoogling, dan menulis artikel, tetapi saya juga memiliki sedikit kebiasaan, di mana saya memberikan penghargaan Reddit gratis harian saya ke posting yang disematkan di r / degoogle untuk meningkatkan kesadaran. Sejauh ini, saya telah memberikan hampir 30 penghargaan ke posting yang disematkan (saya juga menghabiskan 500 koin gratis saya untuk 10 penghargaan untuk posting itu)

***

## Tidak dapat dipercaya

Google tidak bisa dipercaya, dan tidak bisa dipercaya lagi. Mereka telah benar-benar berubah dari "jangan menjadi jahat" (mereka selalu jahat) menjadi benar-benar jahat dan tidak berusaha menyembunyikannya.

***

## Hal-hal lain untuk diperiksa

[The Google Graveyard (killbygoogle.com) - daftar yang diurutkan dari 224+ produk yang telah dibunuh oleh Google] (https://killedbygoogle.com/)

> [Tautan GitHub] (https://github.com/codyogden/killedbygoogle)

[Serikat pekerja alfabet - Serikat pekerja baru di Google dengan lebih dari 800 anggota] (https://alphabetworkersunion.org/people/our-union/)

[Tidak ingin berpisah dengan telur paskah dinosaurus? Situs web ini membantu Anda] (https://chromedino.com/)

Ada alternatif lain, cari saja.

***

Beberapa pemeriksaan fakta diperlukan untuk artikel ini

***

## Info file

Jenis file: `Markdown (* .md)`

Jumlah baris (termasuk baris kosong dan baris penyusun): `968`

Versi file: `` 6 (Minggu, 18 April 2021 pukul 16:18) `

***

### Status perangkat lunak

Semua karya saya bebas beberapa batasan. DRM (** D ** igital ** R ** estrictions ** M ** anagement) tidak ada di semua karya saya.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Stiker ini didukung oleh Free Software Foundation. Saya tidak pernah berniat untuk memasukkan DRM ke dalam karya saya.

Saya menggunakan singkatan "Digital Restrictions Management" alih-alih yang lebih dikenal "Digital Rights Management" karena cara umum untuk mengatasinya salah, tidak ada hak dengan DRM. Ejaan "Digital Restrictions Management" lebih akurat, dan didukung oleh [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) dan [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Bagian ini digunakan untuk meningkatkan kesadaran akan masalah DRM, dan juga untuk memprotesnya. DRM memiliki desain yang rusak dan merupakan ancaman utama bagi semua pengguna komputer dan kebebasan perangkat lunak.

Kredit gambar: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Info sponsor

! [SponsorButton.png] (SponsorButton.png) <- Jangan klik tombol ini, tidak berfungsi, ini hanya gambar. Tombol sebenarnya ada di bagian atas halaman di pojok kanan (<- L ** R ** ->)

Anda dapat mensponsori proyek ini jika Anda suka, tetapi harap tentukan untuk apa Anda ingin berdonasi. [Lihat dana yang dapat Anda donasikan ke sini] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Anda dapat melihat info sponsor lainnya [di sini] (https://github.com/seanpm2001/Sponsor-info/)

Cobalah! Tombol sponsor berada tepat di sebelah tombol tonton / buka.

***

## Riwayat file



 * Memulai file

> * Menambahkan bagian judul

> * Menambahkan indeks

> * Menambahkan bagian tentang

> * Menambahkan bagian Wiki

> * Menambahkan bagian riwayat versi

> * Menambahkan bagian masalah.

> * Menambahkan bagian masalah sebelumnya

> * Menambahkan bagian permintaan tarik sebelumnya

> * Menambahkan bagian permintaan tarik aktif

> * Menambahkan bagian kontributor

> * Menambahkan bagian berkontribusi

> * Menambahkan bagian tentang README

> * Menambahkan bagian riwayat versi README

> * Menambahkan bagian sumber daya

> * Menambahkan bagian status perangkat lunak, dengan stiker dan pesan gratis DRM

> *Menambahkan bagian info sponsor

> * Tidak ada perubahan lain di versi 0.1

Versi 1 (Jumat, 19 Februari 2021 pukul 17:20)

> Perubahan:

> * Memulai file

> * Menambahkan bagian deskripsi dasar

> * Menambahkan bagian deskripsi repositori

> * Menambahkan daftar artikel, dengan 14 entri

>> * Menambahkan bagian `artikel terkait`

>> * Menambahkan bagian `lihat juga`

> * Menambahkan bagian info file

> * Menambahkan bagian riwayat file

> * Menambahkan footer

> * Tidak ada perubahan lain di versi 1

Versi 2 (Jumat, 19 Februari 2021 pukul 17:26)

> Perubahan:

> * Menambahkan bagian status terjemahan

> * Menambahkan bagian Hal lain untuk diperiksa

> * Menambahkan bagian privasi

> * Menambahkan indeks

> * Menambahkan subbagian status perangkat lunak

> * Menambahkan bagian kampanye anti-Google lainnya

>> * Menambahkan subbagian yang tidak berfungsi

>> * Menambahkan subbagian yang sedang berlangsung

> * Menambahkan bagian sumber

> * Menambahkan bagian tautan unduhan

> * Memperbarui bagian info file

> * Memperbarui bagian riwayat file

> * Tidak ada perubahan lain di versi 2

Versi 3 (Rabu, 24 Februari 2021 pukul 19:56)

> Perubahan:

> * Memperbarui indeks

> * Merujuk ikon degoogle dan organisasi GitHub yang baru

> * Menambahkan tautan ke artikel yang lebih baru

> * Menambahkan bagian argumen lain yang melawan

>> * Menambahkan subbagian kenyamanan

>> * Ditambahkan Mengapa repot-repot subbagian

>> * Menambahkan subbagian lainnya

> * Memperbarui beberapa data

> * Memperbarui bagian info file

> * Memperbarui bagian riwayat file

> * Tidak ada perubahan lain di versi 3

Versi 4 (Kamis, 25 Februari 2021 pukul 21:31)

> Perubahan:

> * Menambahkan tautan ke 10 artikel baru

> * Menambahkan bagian tentang pengalaman saya degoogling

> * Memperbarui indeks

> * Memperbarui bagian info file

> * Memperbarui bagian riwayat file

> * Tidak ada perubahan lain di versi 4

Versi 5 (Jumat, 9 April 2021 pukul 18.02)

_Terlalu ada pembaruan tentang gerakan anti-Google dari saya akhir-akhir ini, saya sedang mengupayakan kembali setelah jeda selama 1 bulan lebih._

> Perubahan:

> * Memperbarui bagian judul

> * Memperbarui indeks

> * Memperbarui daftar bahasa: tautan tetap, dan menambahkan lebih banyak bahasa yang didukung

> * Memperbarui bagian status artikel, menambahkan 4 tautan garpu

> * Memperbarui bagian status perangkat lunak

> * Menambahkan bagian Go is evil

> * Menambahkan bagian Penggunaan DRM

> * Menambahkan bagian kesalahpahaman umum

>> * Ditambahkan Google bukan sub-bagian Internet

> * Menambahkan bagian Internet Explorer 6 dan Chrome

>> * Menambahkan masalah dengan subbagian Brave

> * Menambahkan penghapusan privasi Faux

> * Menambahkan Open source tidak bisa menjadi sub-bagian parsial

> * Menambahkan subbagian Oxymoron

> * Menambahkan bagian kinerja buruk

> * Menambahkan bagian manajemen proyek yang buruk

> * Menambahkan bagian Layanan yang Mengerikan atau tanpa moderasi

> * Menambahkan bagian Astroturfing

> * Menambahkan bagian praktik bisnis ilegal dan tidak etis

> * Menambahkan subbagian Di Eropa

>> * Menambahkan subbagian Di Amerika Utara

>> * Menambahkan sub-bagian Kontroversi

> * Menambahkan bagian Google adalah otomatis

> * Menambahkan bagian Android

> * Menambahkan tindakan Kecil untuk membantu bagian

> * Menambahkan bagian Tidak Dapat Dipercaya

> * Menambahkan bagian info sponsor

> * Memperbarui footer

> * Memperbarui bagian info file

> * Memperbarui bagian riwayat file

> * Tidak ada perubahan lain di versi 5

Versi 6 (Minggu, 18 April 2021 pukul 16:18)

> Perubahan:

> * Memperbarui indeks

> * Menambahkan deskripsi ikhtisar baru

> * Info status artikel yang diperbarui

> * Menambahkan tautan ke artikel Google FLoC baru

> * Menambahkan tautan ke artikel Wuest 3n Fuchs Degoogle dan info umum di dalamnya

> * Memperbarui bagian info file

> * Memperbarui bagian riwayat file

> * Tidak ada perubahan lain di versi 6

Versi 7 (Segera hadir)

> Perubahan:

> * Segera hadir

> * Tidak ada perubahan lain di versi 7

Versi 8 (Segera hadir)

> Perubahan:

> * Segera hadir

> * Tidak ada perubahan lain di versi 8

Versi 9 (Segera hadir)

> Perubahan:

> * Segera hadir

> * Tidak ada perubahan lain di versi 9

Versi 10 (Segera hadir)

> Perubahan:

> * Segera hadir

> * Tidak ada perubahan lain di versi 10

Versi 11 (Segera hadir)

> Perubahan:

> * Segera hadir

> * Tidak ada perubahan lain di versi 11

Versi 12 (Segera hadir)

> Perubahan:

> * Segera hadir

> * Tidak ada perubahan lain di versi 12

***

## Footer

Anda telah mencapai akhir file ini

([Kembali ke atas] (# Atas) | [Kembali ke GitHub] (https://github.com))

### EOF

***
