***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle maisha yako

Hii ndio nakala kuu ya upunguzaji wa habari kwa habari ya jumla ya uwachano na kiunga cha nakala zingine.

[Angalia orodha kama shirika la GitHub] (https://github.com/Degoogle-your-life)

***

_Soma nakala hii kwa lugha tofauti: _

** Lugha ya sasa ni: ** `Kiingereza (Kimarekani)` _ _ (tafsiri zinaweza kuhitaji kurekebishwa ili kurekebisha Kiingereza kuchukua nafasi ya lugha sahihi) _

_🌐 Orodha ya lugha_

** Imepangwa kwa: ** `A-Z`

[Chaguo za kupanga hazipatikani] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanian | [am አማርኛ] (/. github / README_AM.md) Kiamhariki | [ar عربى] (/.github/README_AR.md) Kiarabu | [hy հայերեն] (/. github / README_HY.md) Kiarmenia | [az Azrbaycan dili] (/. github / README_AZ.md) Kiazabajani | [eu Euskara] (/. github) /README_EU.md) Kibasque | [be Беларуская] (/. Github / README_BE.md) Kibelarusi | [bn বাংলা] (/. Github / README_BN.md) Kibengali | [bs Bosanski] (/. Github / README_BS.md) Kibosnia | [bg български] (/. Github / README_BG.md) Kibulgaria | [ca Català] (/. Github / README_CA.md) Kikatalani | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 中文 中文] (/. github / README_ZH-CN.md) Kichina (Kilichorahisishwa) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Kichina (Jadi) | [co Corsu] (/. Github / README_CO.md) Kikosikani | [hr Hrvatski] (/. Github / README_HR.md) Kikroeshia | [cs čeština] (/. Github / README_CS .md) Kicheki | [da dansk] (README_DA.md) Kidenmaki | [nl Nederlands] (/. github / README_ NL.md) Kiholanzi | [** en-us English **] (/. github / README.md) Kiingereza | [EO Kiesperanto] (/. Github / README_EO.md) Kiesperanto | [et Eestlane] (/. github / README_ET.md) Kiestonia | [tl Ufilipino] (/. github / README_TL.md) Kifilipino | [fi Suomalainen] (/. github / README_FI.md) Kifini | [fr français] (/. github / README_FR.md) Kifaransa | [fy Frysk] (/. github / README_FY.md) Kifrisia | [gl Galego] (/. github / README_GL.md) Kigalisia | [ka ქართველი] (/. github / README_KA) Kijojiajia [de Deutsch] (/. github / README_DE.md) Kijerumani | [el Ελληνικά] (/. github / README_EL.md) Kigiriki | [gu ગુજરાતી] (/. github / README_GU.md) Kigujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Kikrioli cha Haiti | [ha Hausa] (/. github / SOMAE_HA.md) Kihausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Kihawai | [he עִברִית] (/. github / README_HE.md) Kiebrania | [hi हिन्दी] (/. github / README_HI.md) Kihindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Kihungari | [ni Íslenska] (/. github / README_IS.md) Kiaislandi | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Kiaislandi | [ga Gaeilge] (/. github / README_GA.md) Kiayalandi | [italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Kijapani | [jw Wong jawa] (/. github / README_JW.md) Kijava | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kikannada | [kk Қазақ] (/. github / README_KK.md) Kikazaki | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-kusini 韓國 語] (/. github / README_KO_SOUTH.md) Kikorea (Kusini) | [ko-north 문화어] (README_KO_NORTH.md) Kikorea (Kaskazini) (BADO HATAFSILIWA) | [ku Kurdî] (/. github / README_KU.md) Kikurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kikirigizi | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Kilatini | [lt Lietuvis] (/. github / README_LT.md) Kilithuania | [lb Lëtzebuergesch] (/. github / README_LB.md) Kilasembagi | [mk Македонски] (/. github / README_MK.md) Kimasedonia | [mg Malagasy] (/. github / README_MG.md) Malagasi | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [ml മലയാളം] (/. github / README_ML.md) Kimalayalam | [mt Malti] (/. github / README_MT.md) Kimalta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Kimarathi | [mn Монгол] (/. github / README_MN.md) Kimongolia | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Kiburma) | [ne नेपाली] (/. github / README_NE.md) Kinepali | [hakuna norsk] (/. github / README_NO.md) Kinorwe | [au ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Kiorya) | [ps پښتو] (/. github / README_PS.md) Kipashto | [fa فارسی] (/. github / README_FA.md) | Kiajemi [pl polski] (/. github / README_PL.md) Kipolishi | [pt português] (/. github / README_PT.md) Kireno | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Kipunjabi | Hakuna lugha zinazopatikana zinazoanza na herufi Q | [ro Română] (/. github / README_RO.md) Kiromania | [ru русский] (/. github / README_RU.md) Kirusi | [sm Faasamoa] (/. github / README_SM.md) Msamoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scots Gaelic | [sr Српски] (/. github / README_SR.md) Kiserbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Kishona | [sd سنڌي] (/. github / README_SD.md) Kisindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Kislovakia | [sl Slovenščina] (/. github / README_SL.md) Kislovenia | [kwa hivyo Soomaali] (/. github / README_SO.md) Msomali | [[es español] (/. github / README_ES.md) Kihispania | [su Sundanis] (/. github / README_SU.md) Msunda | [sw Kiswahili] (/. github / README_SW.md) Kiswahili | [sv Svenska] (/. github / SOMAE_SV.md) Kiswidi | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Kitamil | [tt Татар] (/. github / README_TT.md) Kitatari | [te తెలుగు] (/. github / README_TE.md) Kitelugu | [th ไทย] (/. github / README_TH.md) Kitai | [tr Türk] (/. github / README_TR.md) Kituruki | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Kiukreni | [ur اردو] (/. github / README_UR.md) Kiurdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Kiuzbeki | [vi Tiếng Việt] (/. github / README_VI.md) Kivietinamu | [cy Cymraeg] (/. github / README_CY.md) Kiwelsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Kiyidi | [yo Kiyoruba] (/. github / README_YO.md) Kiyoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Inapatikana katika lugha 110 (108 wakati wa kuhesabu Kiingereza na Kikorea cha Kaskazini, kwani Korea Kaskazini bado haijatafsiriwa [Soma juu yake hapa] (/ OldVersions / Kikorea (Kaskazini ) / README.md))

Tafsiri katika lugha zingine isipokuwa Kiingereza zinatafsiriwa kwa mashine na bado si sahihi. Hakuna makosa ambayo yamerekebishwa hadi Februari 5, 2021. Tafadhali ripoti makosa ya kutafsiri [hapa] (https://github.com/seanpm2001/Degoogle-your-life/issues/) hakikisha unasahihisha marekebisho yako na vyanzo na uniongoze , kwani sijui lugha zingine isipokuwa Kiingereza vizuri (nina mpango wa kupata mtafsiri hatimaye) tafadhali taja [wiktionary] (https://en.wiktionary.org) na vyanzo vingine katika ripoti yako. Kukosa kufanya hivyo kutasababisha kukataliwa kwa marekebisho hayo.

Kumbuka: kwa sababu ya mapungufu na ufafanuzi wa GitHub wa alama (na karibu kila tafsiri nyingine ya wavuti ya alama) kubonyeza viungo hivi vitakuelekeza kwa faili tofauti kwenye ukurasa tofauti ambayo sio ukurasa wangu wa wasifu wa GitHub. Utaelekezwa kwa [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), ambapo README inakaribishwa.

Tafsiri hufanywa na Google Tafsiri kwa sababu ya msaada mdogo au hakuna kwa lugha ninazohitaji katika huduma zingine za kutafsiri kama DeepL na Bing Tafsiri (ajabu sana kwa kampeni ya kupambana na Google) ninafanya kazi kutafuta njia mbadala. Kwa sababu fulani, muundo (viungo, wagawanyiko, ujasiri, italiki, nk) umechanganywa katika tafsiri anuwai. Inachosha kurekebisha, na sijui jinsi ya kurekebisha masuala haya kwa lugha na herufi zisizo za Kilatini, na lugha za kulia kwenda kushoto (kama Kiarabu) msaada wa ziada unahitajika katika kurekebisha maswala haya.

Kwa sababu ya maswala ya matengenezo, tafsiri nyingi zimepitwa na wakati na zinatumia toleo la zamani la faili hii ya nakala ya `README`. Mtafsiri anahitajika. Pia, kuanzia Aprili 9, 2021, itanichukua muda kupata viungo vyote vipya kufanya kazi.

***

## Kielelezo

[00.0 - Kichwa] (# Kujiandikisha --- Degoogle-maisha yako)

> [00.1 - Kielelezo] (# Index)

[01.0 - Maelezo ya kimsingi] (# Maelezo ya kimsingi)

> [01.1 - Kichwa cha kumbukumbu] (# Degoogle-yako-maisha)

> [01.2 - Wuest3NFuchs maelezo ya jumla] (# Muhtasari-na-Wuest3nFuchs)

>> [01.2.1 - Inamaanisha nini?] (# Je! Inamaanisha nini - na-Wuest3nFuchs)

>> [01.2.2 - Kwanini Degoogle?] (# Why-Degoogle - by-Wuest3nFuchs)

[02.0 - Nakala] (Nakala #)

[03.0 - Faragha] (# Faragha)

[04.0 - Kampeni zingine za kupambana na Google] (# Kampeni zingine za kupinga Google-Google)

> [04.0.1 - Haifanyi kazi] (# Haifanyi kazi)

> [04.0.2 - Inaendelea] (# Inaendelea)

[05.0 - Kukabiliana na hoja zingine] (# Kukabiliana-na-hoja zingine)

> [05.0.1 - Urahisi] (# Urahisi)

> [05.0.2 - Kwa nini ni muhimu? Umechelewa wakati wowote] (# Kwanini-ina-maana, -e-imechelewa-wakati wowote)

> [05.0.3 - Nyingine] (# Nyingine)

[06.0 - Vyanzo] (# Vyanzo)

[07.0 - Viungo vya kupakua] (viungo # vya kupakua)

[08.0 - Uzoefu wangu wa kufanya deogogling] (# Uzoefu wangu wa kujiondoa)

> [08.1 - Nilichobadilisha kutoka] [# Nimebadilisha-nini-kutoka)

> [08.2 - Bidhaa ambazo bado siwezi kuziondoa] (# Bidhaa-bado-siwezi-kutoka-kutoka)

[09.0 - Vitu vingine vya kuangalia] [# Vitu-vingine-vya-kukagua)

[10.0 - Maelezo ya faili] (# Faili-maelezo)

> [10.1 - Hali ya programu] (# hadhi ya programu)

> [10.2 - Maelezo ya wadhamini] (# Mdhamini-maelezo)

[11.0 - Historia ya faili] (# Historia ya faili)

[12.0 - Kijachini] (# Kijachini)

***

## Maelezo ya kimsingi

[Kutoka Wikipedia: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

Harakati ya DeGoogle (pia inaitwa harakati ya de-Google) ni kampeni ya msingi ambayo imetokea wakati wanaharakati wa faragha wanahimiza watumiaji kuacha kutumia bidhaa za Google kabisa kutokana na kuongezeka kwa wasiwasi wa faragha kuhusu kampuni hiyo. Neno hilo linamaanisha kitendo cha kuondoa Google kutoka kwa maisha ya mtu. Kama sehemu inayoongezeka ya soko la kampuni kubwa ya mtandao inaunda nguvu ya ukiritimba kwa kampuni katika nafasi za dijiti, idadi kubwa ya waandishi wa habari imebaini ugumu wa kupata njia mbadala za bidhaa za kampuni.

** Historia **

Mnamo 2013, John Koetsier wa Venturebeat alisema kibao cha Amazon Kindle Fire Android kilikuwa "toleo la Android-ized la Android." Mnamo 2014 John Simpson wa Habari ya Amerika aliandika juu ya "haki ya kusahaulika" na Google na injini zingine za utaftaji. Mnamo mwaka wa 2015, Derek Scally wa Irish Times aliandika nakala juu ya jinsi ya "De-Google maisha yako." Mnamo 2016 Kris Carlon wa Android Mamlaka ilipendekeza kuwa watumiaji wa CyanogenMod 14 wangeweza "kuzima-Google" simu zao, kwa sababu CyanogenMod inafanya kazi vizuri bila programu za Google pia. Mnamo mwaka wa 2018 Nick Lucchesi wa Inverse aliandika juu ya jinsi ProtonMail ilivyokuwa ikikuza jinsi ya "kuweza kuondoa kabisa Google-fy maisha yako." Brendan Hesse wa Lifehacker aliandika mafunzo ya kina juu ya "kuacha Google." Mwandishi wa habari wa Gizmodo Kashmir Hill anadai kwamba alikosa mikutano na alikuwa na shida kuandaa mkutano bila matumizi ya Kalenda ya Google. Imezuiliwa kutumia huduma zinazotolewa na Google kwa sababu kuna njia mbadala ambazo kutokuwepo kwa bidhaa za kampuni hiyo kulifanya matumizi ya kawaida ya mtandao kutofaulu.

***

# Degoogle-maisha yako
Hifadhi ya habari ya jumla ya upunguzaji wa viungo na viungo kwa hazina zingine za deogogling.

***

## Muhtasari wa Wuest3nFuchs

Maelezo bora, yaliyotolewa na [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - chanzo: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Inamaanisha nini? na Wuest3nFuchs

Degoogling inamaanisha kuacha kutumia chochote kilicho cha Google, chochote kilichotengenezwa na Google. Ninazungumza juu ya injini yao ya utaftaji, huduma yao ya barua (Gmail), Youtube, n.k.

### Kwa nini Degoogle? na Wuest3nFuchs

Google ni moja ya kampuni zenye nguvu zaidi ulimwenguni hivi sasa. Wamehifadhi habari nyingi kwetu sisi sote. Wengine wangeweza kusema kuwa habari yetu ni salama nao kwa sababu wanajua jinsi ya kuilinda. Lakini hii sio kweli. Google imepenyezwa hapo awali na itapenyezwa baadaye. Labda sio na mtoto mdogo wa maandishi lakini itafanywa na serikali ya kitaifa. Google huhifadhi habari za kibinafsi kwetu sote kwa sababu ndivyo wanavyopata pesa.

Wanachunguza barua pepe zetu, kuhifadhi kile tunachotafuta tunapotumia injini yao ya utaftaji, ni video gani tunazotazama kwenye Youtube. Hivi ndivyo wanavyotulenga na kujenga wasifu juu yetu kutuonyesha tangazo kulingana na kile tulichozungumza na rafiki yetu wa karibu ili waweze kutuonyesha tangazo la kitu tunachohitaji, lakini hii ni mbaya sana. Shukrani kwa Bwana Snowden sasa tunajua kuwa Google imeshiriki habari zetu za kibinafsi na NSA chini ya programu inayoitwa ** "PRISM" **.


Katika siku za usoni mtu atakuwa na uwezo wa kupata habari hizo zote na nakuhakikishia kuna jambo baya sana litatokea. Ili kuzuia hilo kutokea, unapaswa kuanza Kujishughulisha hivi sasa. Pia haupaswi kutumia bidhaa na kampuni inayoshiriki data yako na ** NSA **. Unapaswa kusitisha haya yote kwa kupuuza.

** Ikiwa watu wengine wanaweza kuifanya, unaweza kuifanya pia.

[Soma zaidi hapa] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Kiunga cha uma sasa hakijaorodheshwa, kwani siko na hazina hii kabisa, na ninataka kukuza vyanzo vingine. Itakuwa ubinafsi kuungana na yangu mwenyewe https://github.com/Degoogle-your-life/Degoogle! ->

***

## Nakala

### Hali ya kifungu

_Makala zote kwa sasa ni kazi inayoendelea na zinahitaji maboresho makubwa. Mapendekezo na marekebisho yanaruhusiwa._

_Kwa Aprili 18, 2021 saa 4:09 jioni, nakala nyingi bado hazijaanza. Ninafanya kazi kutafuta wakati na juhudi za kuzianzisha ._

[Kwanini unapaswa kuacha kutumia Google Chrome] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Acha kutumia ChromeBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Acha kutumia WideVine DRM / Ni wakati wa kukata WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Kwanini unapaswa kuacha kutumia ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Kubadilisha kutoka YouTube] (https://github.com/seanpm2001/Kubadilisha- kutoka-YouTube) <! - 5! ->

[Stop Googling, kwanini unapaswa kuacha kutumia Utafutaji wa Google] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! >

[Kwanini unapaswa kuacha kutumia Gmail] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Kwanini unapaswa kuacha kutumia Android] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Kwanini unapaswa kuepuka Google Amp] (https://github.com/seanpm2001/Why-you-should-void-Google-AMP) <! - 9! ->

[Kwanini unapaswa kuacha kutumia Hifadhi ya Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Kwanini unapaswa kuacha kutumia Ramani za Google na Google Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Hey Google, simama] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Acha kusoma kutoka kwa vitabu vya Google / Google Play] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Acha kutumia Darasa la Google] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Kwanini unapaswa kuacha kutumia Google Tafsiri] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Kwanini unapaswa kuacha kutumia Akaunti zako za Google] (https://github.com/seanpm2001/Why-you-should-skutumia-Akaunti-za-Google-juu) <! - 16! ->

** Nakala mpya zitaandikwa hivi karibuni: **

[Kwanini unapaswa kuacha kutumia Gerrit] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Kwanini unapaswa kuacha kutumia Google Analytics (ghala limevunjika mwisho wangu kuanzia Jumatano, Februari 24, 2021 saa 4: 13 jioni)] (https://github.com/seanpm2001/Why-you-stall- stop -using Uchanganuzi wa Google) <! - 18! ->

<! - Mgawanyaji wa kazi! ->

[Kwanini unapaswa kuacha kutumia Google AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Kwanini unapaswa kuacha kutumia Google One] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Kwanini unapaswa kuacha kutumia Google+ (haifanyi kazi)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Kwanini unapaswa kuacha kutumia Duka la Google Play] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Kwanini unapaswa kuacha kutumia Hati za Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Kwanini unapaswa kuacha kutumia Google Slides] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Kwanini unapaswa kuacha kutumia Majedwali ya Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google- Sheets) <! - 25! ->

[Kwanini unapaswa kuacha kutumia Fomu za Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Kwanini unapaswa kuacha kutumia Google Cardboard] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Kwanini unapaswa kuacha kutumia Ujumbe wa Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Kwanini unapaswa kuacha kutumia Ubunifu wa Vifaa vya Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Kwanini unapaswa kuacha kutumia Google Glass / Glasi] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Kwanini unapaswa kuacha kutumia Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Kwanini unapaswa kuacha kutumia GBoard] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Kwanini unapaswa kuacha kutumia Google Home] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Kwanini unapaswa kuacha kutumia Kiota cha Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Kwanini unapaswa kuacha kutumia Hangouts za Google (haifanyi kazi)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Kwanini unapaswa kuacha kutumia Google Duo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Kwanini unapaswa kuacha kutumia Google Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Kwanini unapaswa kuacha kutumia Google Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Kwanini unapaswa kuacha kutumia Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Kwanini unapaswa kuacha kutumia lugha ya programu ya Googles Go] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Kwanini unapaswa kuacha kutumia lugha ya programu ya Googles Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Kwanini unapaswa kuacha kutumia muundo wa picha za Googles WebP] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Kwanini unapaswa kuacha kutumia muundo wa video wa Googles WebM] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Kwa nini unapaswa kuacha kutumia Google Video] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Kwanini unapaswa kuacha kutumia Google Sites (classic)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Kwanini unapaswa kuacha kutumia Tovuti za Google ("Mpya")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Kwanini unapaswa kuacha kutumia Google Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Kwanini unapaswa kuacha kutumia Android Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Kwanini unapaswa kuacha kutumia Google VPN (oxymoron)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Kwanini unapaswa kuacha kutumia Picha za Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[Kwanini unapaswa kuacha kutumia Kalenda ya Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Kwanini unapaswa kuacha kutumia VirusTotal (kwani imemilikiwa na Google tangu Septemba 2012] (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Kwanini unapaswa kuacha kutumia Google Fi] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi) <! - 53! ->

[Kwanini unapaswa kuacha kutumia Google Stadia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Kwanini unapaswa kuacha kutumia Google Keep] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Kwanini unapaswa kuacha kutumia Google Base] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Kwanini unapaswa kuacha kushiriki katika Msimu wa Google wa Msimbo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Kwanini unapaswa kuacha kutumia Kamera ya Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Kwanini unapaswa kuacha kutumia Kikokotoo cha Google (inaweza kuonekana kuwa kali, lakini unapaswa kuachana na kila kitu, rahisi sana kubadilisha)] (https://github.com/seanpm2001/Why-you-shop-stop-using-Google- Kikokotoo) <! - 59! ->

[Kwanini unapaswa kuacha kutumia tuzo za Google Survey +) (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Kwanini unapaswa kuacha kutumia Michoro ya Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Kwanini unapaswa kuacha kutumia Tenor (tovuti ya GIF, inayomilikiwa na Google tangu 2019)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Nini FLoC - Kwanini unapaswa kuepuka shida kubwa ya Googles ya FLoCing (acha kutumia Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Jumla ya makala: ** `63`

** Kifungu [ramani ya barabara AB] (DegoogleCampaign_2021Roadmap_Part1.md) (hadi Machi 12, 2021) siku 2 za mapumziko **

** Kifungu [ramani ya barabara BB] (DegoogleCampaign_2021Roadmao_Part2.md) (hadi? 2021) siku 2 za mapumziko **

Hali ya kifungu

Nakala zote kwa sasa ni kazi inayoendelea na zinahitaji maboresho makubwa. Mapendekezo na marekebisho yanaruhusiwa.

** uma **

Kupanua mtandao wangu wa Degoogle, na kuongeza urahisi wa ufikiaji, na vifijo vya jamii.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Iliyotengwa kutoka: [https://github.com/wacko1805/Fossapps] (http://github.com/wacko1805/Fossapps) (Kiingereza)

2. [Viungo vya faragha] (https://github.com/Degoogle-your-life/Privacy-links) | Imetengwa kutoka: [https://github.com/Arturro43/privacy-links] (http://github.com/Arturro43/privacy-links) (Kipolishi)

3. [Kupendeza-Faragha] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Iliyotengwa kutoka: [https://github.com/LinuxCafeFederation/Delightful-Privacy)

4. [Orodha za kuzuia] (https://github.com/Degoogle-your-life/listslists) | Iliyotengwa kutoka: [https://github.com/jmdugan/blocklists] (http://github.com/jmdugan/blocklists) (Kiingereza)

5. [Degoogle, na Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Iliyotengwa kutoka: [https://github.com/Wuest3nFuchs/Degoogle] (https://github.com/Wuest3nFuchs/Degoogle) (Kiingereza)

** Kuhusiana **

[Utaftaji wa Mashine ya Virtual ya simu ya Android] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Angalia pia:**

[Ukosoaji wa Google katika Wikipedia] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[Makaburi ya Google (killbygoogle.com) - orodha iliyopangwa ya bidhaa 224+ ambazo Google imeua] (https://killedbygoogle.com/)

> [Kiunga cha GitHub] (https://github.com/codyogden/killedbygoogle)

[Chama cha wafanyikazi wa Alfabeti - Chama kipya cha wafanyikazi katika Google kilicho na zaidi ya washiriki 800] (https://alphabetworkersunion.org/people/our-union/)

[Hawataki kuachana na yai ya Pasaka ya dinosaur? Tovuti hii umefunika] (https://chromedino.com/)

***

## Faragha

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -a mbaya /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / data-yote-facebook-google-ina-wewe-faragha) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico- watoto-privacy-school-chromebook-lawsuit)letons/https://www.eff.org/deeplinks/2019/08/dont- play-googles-privacy- sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-hehe) data ya alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-faragha-shida /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_arhati # Ukosoaji) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -sampuli-za-sampuli / hakuna-kitu cha kuficha-hoja-hana-cha kusema /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-mount- ya-data-kuhusu-wewe-unaweza-kupata-na-kuifuta-sasa /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -data-yako-ya-kibinafsi-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -fanya mapato-na) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / data-yote-facebook-google-ina-wewe-faragha) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- ukusanyaji-kufunuliwa.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ afya-fitness-data-faragha /) [h] (https://www.pcmag.com/news/google-sued-ov vitabu-vya-ukusanyaji-wa-elimu-juu-ya-chromebook) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / serikali-ya-serikali-ya-google-ukusanyaji-mashtaka-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html))o)(https://en.wikipedia.org/wiki/2018_Google_data_breach)inglymmw (https://moz.com /blog/ambapo-google-draw-the-data-collection-line)inglyee (http://mashable.com/article/google-android-data-collection-study/)[s)(https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)letono- (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -dai-kwa niaba-ya-5-m watumiaji-iphone-milioni) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) sigator [http://arstechnica.com/information-technology/2014/01 / nini-google-naweza- kufanya-ni-ni-ni-ni-ni-nihakiki-data-)/i [i] [http://www.cbsnews.com/news/google-education-spies-on-collects- data-on-million-of-kids-alleges-lawsuit-new-Mexico-attorney-general /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-candal -katika-pua zetu /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / teknolojia / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to--ide-ficha-40689565c550) [.] (https: //fi.tv. : //medium.com/digitalprivacywise/why- unapaswa- kuacha-kutumia-google-chrome-6c934c9a827c) (ningeweza kuendelea na ushahidi wa hii, lakini ilichukua muda mrefu kupata na kupitia haya yote makala)

Faragha kwenye bidhaa za Google huwa mbaya kila wakati, kwa sababu ya bidhaa zote za Google zilizo na spyware.

Haijalishi unafanya nini, unapotumia Google, data zako zote nyeti za kibinafsi zinatumwa kwa Google na wengine. Google pia imeonekana kupitia programu wazi. Kwa mfano, kutokana na uzoefu wa kibinafsi (kwenye Firefox) na kichupo cha YouTube kilichofunguliwa ambacho sikutembelea, nilitazama video kadhaa nje ya mkondo (VLC Media Player) Baadaye nilipoenda kuangalia mapendekezo, ilikuwa karibu kila kitu ambacho nilikuwa nimeangalia. Hakuna shaka wanapeleleza programu zingine pia.

Katika Chrome (na vivinjari vingine vingi) hali ya incognito iko. Katika Chrome, hali hii haina maana, kwani Google bado itachimba data yako. Hata ukizima uchimbaji / ufuatiliaji wa data, na kuwezesha ishara ya "usifuatilie", mshangao wa kushangaza, Google bado inachimba data yako.

Ikiwa unafikiria hauna kitu cha kujificha, ** umekosea kabisa **. Hoja hii imefutwa mara nyingi zaidi:

[Kupitia Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden alisema "Kubishana kwamba haujali haki ya faragha kwa sababu huna kitu cha kuficha sio tofauti na kusema hujali hotuba ya bure kwa sababu huna la kusema." Unaposema, ' Sina la kuficha, "unasema," Sijali haki hii. "Unasema," Sina haki hii, kwa sababu nimepata mahali ambapo lazima nihalalishe Njia ya haki ni, serikali inapaswa kuhalalisha uingiliaji wake katika haki zako. "

2. Daniel J. Solove alisema katika nakala ya The Chronicle of Higher Education kwamba anapinga hoja hiyo; alisema kuwa serikali inaweza kuachak habari juu ya mtu na kusababisha uharibifu kwa mtu huyo, au tumia habari juu ya mtu kukataa ufikiaji wa huduma hata ikiwa mtu hakuhusika katika uovu, na kwamba serikali inaweza kusababisha uharibifu kwa maisha ya kibinafsi kwa kufanya makosa. Solove aliandika "Wakati wa kushiriki moja kwa moja, hoja ya kujificha inaweza kunasa, kwani inalazimisha mjadala kuzingatia uelewa wake mdogo wa faragha. Lakini wakati inakabiliwa na wingi wa shida za faragha zinazohusishwa na ukusanyaji wa data ya serikali na matumizi zaidi ya ufuatiliaji na kutoa taarifa, hoja ya kujificha, mwishowe, haina cha kusema. "

3. Adam D. Moore, mwandishi wa Haki za Faragha: Misingi ya Maadili na Sheria, alisema, "ni maoni kwamba haki zinakabiliwa na gharama / faida au aina ya hoja. Hapa tunakataa maoni kwamba masilahi ya faragha ndio aina. ya vitu ambavyo vinaweza kuuzwa kwa usalama. " Alisema pia kuwa ufuatiliaji unaweza kuathiri vikundi kadhaa katika jamii kulingana na muonekano, kabila, ujinsia, na dini.

4. Bruce Schneier, mtaalam wa usalama wa kompyuta na mwandishi wa kriptografia, alielezea upinzani, akinukuu taarifa ya Kardinali Richelieu "Ikiwa mtu atanipa mistari sita iliyoandikwa na mkono wa mtu mwaminifu zaidi, ningepata kitu ndani yao ili anyongwe", akimaanisha jinsi serikali ya jimbo inavyoweza kupata huduma katika maisha ya mtu ili kumshtaki au kumtapeli mtu huyo. Schneier pia alisema "Mengi yanaonyesha vibaya mjadala kama 'usalama dhidi ya faragha.' Chaguo halisi ni uhuru dhidi ya udhibiti. "

5. Harvey A. Silverglate alikadiria kuwa mtu wa kawaida, kwa wastani, bila kujua anafanya maiti tatu kwa siku huko Merika.

6. Emilio Mordini, mwanafalsafa na mtaalam wa kisaikolojia, alisema kuwa hoja ya "hakuna ya kuficha" ni ya asili ya kupingana. Watu hawahitaji kuwa na "kitu cha kuficha" ili kuficha "kitu". Kilichojificha sio lazima, anadai Mordini. Badala yake, anasema eneo la karibu ambalo linaweza kufichwa na kuzuiwa kwa ufikiaji ni muhimu kwani, tukiongea kisaikolojia, tunakuwa watu binafsi kupitia ugunduzi kwamba tunaweza kuficha kitu kwa wengine.

7. Julian Assange alisema "Bado hakuna jibu la muuaji. Jacob Appelbaum (@ioerror) ana jibu la busara, akiuliza watu wanaosema hivi basi wampe simu yao imefunguliwa na kubomoa suruali zao. Toleo langu la kusema, "vema, ikiwa unachosha sana basi hatupaswi kuwa tunazungumza na wewe, na hakuna mtu mwingine yeyote", lakini kifalsafa, jibu halisi ni hili: Ufuatiliaji wa Misa ni mabadiliko ya kimuundo. Jamii inapokuwa mbaya, inaenda kukuchukua nayo, hata ikiwa wewe ndiye mtu mbishi zaidi duniani. "

8. Ignacio Cofone, profesa wa sheria, anasema kuwa hoja hiyo imekosea kwa maneno yake kwa sababu, wakati wowote watu wanapofichua habari muhimu kwa wengine, pia hufunua habari isiyo na maana. Habari hii isiyo na maana ina gharama za faragha na inaweza kusababisha madhara mengine, kama vile ubaguzi.

***

## Kampeni zingine za kupambana na Google

Hii ni orodha ya kampeni zingine maarufu za kupambana na Google. Orodha hii haijakamilika. Unaweza kusaidia kwa kuipanua.

### Haifanyi kazi

[Scroogled - Na Microsoft (Novemba 2012 hadi 2014)] (https://en.wikipedia.org/wiki/Scroogled)

_Hakuna maingizo mengine kwa sasa._

### Inaendelea

_ Orodha hii kwa sasa haina kitu._

***

## Kukabiliana na hoja zingine

Kuna hoja ambazo watu hutoa ili kuhalalisha Google. Moja kuu ya kwanza tayari imeondolewa [hapa] (# Faragha) lakini hizi ndio zingine:

### Urahisi

Ndio, bidhaa za Google zinaonekana kuwa rahisi. Walakini, unafanya biashara kila kitu kizuri kwa urahisi, pamoja na usalama, faragha, na kuegemea. Google imekuwa ikilegea zaidi ya miaka, na seva zao zimepungua zaidi na zaidi. Hivi sasa, seva za Google hushuka kwa karibu saa moja mara 1-2 kwa mwezi (haswa YouTube)

Kwa bahati mbaya, kwa sababu ya jamii kutegemea Google, Google imekuja kutawala mtandao, na inatafuta kudhibiti zaidi na zaidi. Mnamo mwaka wa 2012, Google iliposhuka kwa dakika 5, iliripotiwa kuwa ** trafiki ya mtandao ** ** imeshuka kwa 40% ** Google mara kwa mara hushuka kwa masaa 1-2, na [kurusha timu yao ya maadili] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-searcher-margaret-mitchell/) kati ya mambo mengine, zitakuwa rahisi na kidogo.

Urahisi sio jambo nzuri kila wakati. Unapaswa kujua nini kinaendelea na uwe tayari kwa wakati watashuka, kwani hakuna njia ya kuwa na seva isianguke kila mara kwa wakati.

Google pia sio rahisi kama unavyofikiria. Kuna tovuti zingine rahisi zaidi. Google ni rahisi sana, unapohesabu kusimamishwa kwa akaunti zao kwa njia isiyo ya kawaida na hakuna jibu (isipokuwa ukiangalia akaunti ya twitter ya Google au uwashtaki kwa $ 100,000,000 au zaidi) basi wamekutumia faida yako, wakakudanganya, na alikulazimisha kupiga kelele kwenye mto, ambapo hakuna mtu anayeweza kusikia mayowe yakokwa msaada.

### Kwa nini ni muhimu, wakati wowote umechelewa

Hii ni hoja isiyo ya kawaida, lakini inahitaji maelezo. Pamoja na hali ya sasa, serikali nyingi za ulimwengu, pamoja na mashirika kadhaa yenye nguvu wanaonekana kujua kila hatua yako, kwa nini hata ujisumbue kuachana nayo? Jibu ni rahisi: ** unastahili bora **. Ikiwa unafanikiwa kutoka kwao kwa wakati huu, ni ngumu kwao kufuatilia hatua zako zaidi, na unaweza kujenga maisha mapya zaidi ya faragha.

[Chanzo 1] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Kumbe, nimekuwa nikitoa tuzo yangu ya bure ya Reddit kwenye chapisho hili kila wakati ninapoipata kwa zaidi ya wiki sasa (pamoja na sarafu zangu zote 500 za bure) kuongeza mada hii zaidi. Kufikia sasa, nimetoa chapisho hili zaidi ya tuzo 14 za bure. Sio mengi, lakini vitu vidogo vinaweza kuleta athari kubwa, kulingana na jinsi inavyoonekana, na nani.

### Nyingine

Sina hoja nyingine kwa sasa.

_ Orodha hii haijakamilika_

***

## Vyanzo

Nakili:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -a mbaya /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / data-yote-facebook-google-ina-wewe-faragha) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico- watoto-privacy-school-chromebook-lawsuit)letons/https://www.eff.org/deeplinks/2019/08/dont- play-googles-privacy- sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-hehe) data ya alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-faragha-shida /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Ukosoaji) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -sampuli / hakuna-kitu cha kuficha-hoja-hana-cha kusema /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-mount-of- data-kuhusu-wewe-unaweza-kupata-na-kuifuta-sasa /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your data-ya kibinafsi-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetize -na) [c] (https://www.wired.com/story/google-tracks-you -binafsi /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)letondhttps: //www.reuters.com/article/us-alfabeti- shtaka la google-faragha-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)letono-https://en.wikipedia.org/wiki/2018_Google_data_breach)[m)(https://:// moz.com/bl og / wapi-google-chora-data-ya-mkusanyiko-wa-mstari) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / teknolojia / google-europe-gdpr-faini.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- madai kwa niaba-ya-milioni-5-watumiaji wa iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W))ealie -simu-haitumiwi /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / informatikwenye-teknolojia / 2014/01 / nini-google-inaweza-kufanya-kweli-na-kiota-au-kweli-viota-data /) [i] (https://www.cbsnews.com/news/google-education -wapelelezi-wakusanya-data-kwa-mamilioni-ya-watoto-wanadai-kesi-mpya-mexico-wakili-mkuu /) [v] (https://www.nationalreview.com/2018/04/the- kashfa-ya-data-ya-kashfa-chini ya-pua zetu /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)inglyy -enye kitu-cha-kujificha-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Vyanzo vingine:

[Muungano wa macho matano] (https://en.wikipedia.org/wiki/Five_Eyes) [Sitini na themanini na nne] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Pakua viungo

[Pata Firefox] (https://www.mozilla.org/en-US/firefox/new/) [Pata kivinjari cha Tor] (https://www.torproject.org/download/) [Nyingine / haipatikani] (https : //www.example.com)

***

## Uzoefu wangu wa kupuuza

Mwishowe nilianza kuona shida na teknolojia kubwa mnamo 2018, na nikaanza kufanya ujanja. Katika miezi michache ya kwanza, nilifanya maendeleo makubwa. Ilipungua sana tangu wakati huo.


### Nilichobadilisha kutoka

Google Chrome -> Firefox / Tor

Utafutaji wa Google -> DuckDuckGo (chaguo-msingi) / Ecosia (wakati nahisi kama hiyo) / Bing (mara chache)

GMail - ProtonMail (bado haijabadilishwa kabisa)

Tovuti za Google -> Kujiandaa mwenyewe (bado haujabadilishwa kikamilifu)

Google+ -> Haijawahi kutumiwa, kujifuta yenyewe kwa sababu ya kuzima kwake

Hati za Google -> Zisizotumiwa kamwe, ninatumia tu Microsoft Word 2013 (kabla ya 2019) na LibreOffice (2019-onward) badala yake.

Majedwali ya Google -> Haijawahi kutumiwa, ninatumia tu Microsoft Excel 2013 (kabla ya 2019) na LibreOffice (2019-onward) badala yake.

Google Slides -> Haikutumika kamwe, ninatumia tu Microsoft PowerPoint 2013 (kabla ya 2019) na LibreOffice (2019-onward) badala yake.

Michoro ya Google -> Haikutumika kamwe, ninatumia LibreOffice (2019-kuendelea) badala yake.

Gerrit -> Kamwe usseded, mimi tu kutumia GitHub (chaguo-msingi ya sasa), GitLab, BitBucket, na SourceForge badala yake.

Picha za Google -> Zisizotumiwa kamwe

Hifadhi ya Google -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-present)

Ramani za Google -> OpenStreetMaps / Apple Maps

Nenda - Kufanya ubaguzi maalum, lakini sio kutumia kama lugha inayofaa ya programu

Dart - Kufanya ubaguzi maalum, lakini sio kutumia kama lugha inayofaa ya programu

Flutter - Kufanya ubaguzi maalum, lakini sio kutumia kama lugha inayofaa ya programu

Google Earth -> OpenStreetMaps / Apple Maps

Mtazamo wa Google Streetview -> Haijawahi kutumiwa, naona ni ya kutisha zaidi

Google Fi -> Haikutumika kamwe

Kalenda ya Google -> Haikutumika kamwe

Kikokotoo cha Google -> Kwa kweli programu nyingine yoyote ya kikokotoo, hata terminal ya Linux inayoendesha katika hali ya Python ikiwa najisikia

Kiota cha Google -> Haikutumika kamwe

Google AMP -> Haikutumika kamwe

Google VPN -> Haijawahi kutumiwa, pia oksijeni

Google Pay -> Haikutumika kamwe

Msimu wa Google wa Msimbo -> Haikushiriki kamwe

Tenor -> Tovuti zingine za GIF, ingawa GIF sio muhimu sana kwangu. Kawaida mimi hupata faili za GIF kutoka picha za DuckDuckGo, Imgur, Reddit, au tovuti zingine.

Blockly -> Haitumiki tena, sijui ikiwa Mwanzo moja kwa moja ilizuia. Nikawa programu nzuri mnamo 2017 na kuendelea, na nikakua kutoka mwanzo.

GBoard -> Imetumika mara moja, lakini imeachwa

Kioo cha Google -> Haikutumiwa kamwe, inachukuliwa kama mtoto mdogo lakini niliamua kutopata / kutumia moja ikiwa nilikuwa na chaguo

_List inaweza kuwa haijakamilika._

### Bidhaa bado siwezi kutoka

Kuanzia tarehe 25 Februari 2021, hizi ni bidhaa za Google ambazo zinanizuia nisijiandikishe kabisa:

1. YouTube

2. Android

3. Duka la Google Play

4. Barua pepe (kwa shule tu na tovuti zingine)

5. Darasa la Google (la shule tu)

6. Tafsiri ya Google

7. Akaunti ya Google

8. Google Sites (kwani Google inakiuka sheria za GDPR (na inaweza kukabiliwa na faini nyingine ya € 5,000,000.00 hadi itakaporekebishwa) na kukataza upakuaji wa bidhaa hii

Nimejiondoa kutoka kwa kila kitu kingine.

***

## Nenda ni mbaya

Google ilihamasisha lugha ya programu ya wakala ya 2003 "Nenda!" Na lugha yao ya programu "Nenda" (kutoka 2009, miaka 6 baadaye) na kudai kwamba lugha yao haitaathiri lugha nyingine kabisa. Google ililalamikiwa sana kwa hii, kwani kauli mbiu yao ya "Usiwe mbaya" ilikuwa bado inafanya kazi wakati huo, na hii ni moja wapo ya visa vingi ambavyo vilipata kuwa sio motto mbaya mstaafu.

Mwishowe, ukuzaji wa "Nenda!" Ulikoma, wakati `Go` ilizidi kuwa kawaida. Google ilidai hawatadanganya juu ya "Nenda!" Lakini mwishowe, walifanya hivyo, na waliepuka (kama vile Aprili 9, 2021)

[Soma zaidi kuhusu Nenda na jinsi ya kubadilisha hapa] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Matumizi ya DRM

Google hutumia DRM (Usimamizi wa Vizuizi vya Dijiti) kupitia huduma yao ya "WideVine DRM" na aina zingine. Lengo la DRM ni kuharibu mtandao ulio wazi na kuzipa kampuni nguvu ya ukiritimba juu ya watumiaji. Unapaswa kuondoa WideVine kabisa, bila kujali gharama.

[Soma zaidi kuhusu WideVine na shida zake hapa] (https://github.com/Degoogle-your-life/Its-time-kukata-WideVine-DRM)

***

## Dhana potofu za kawaida

Hii ni orodha ya maoni potofu ya kawaida na bidhaa za Google.

### Google sio Mtandao

Utafutaji wa Google / Google sio mtandao, utaftaji wa Google ni injini ya utaftaji tu, kama vile sio kila mchezo wa jukwaa la Nintendo umetengenezwa na Nintendo, lakini imepewa leseni na Nintendo, lakini kwa kiwango kikubwa zaidi. Ikiwa seva zote za Googles zingeangamizwa wakati huo huo sasa, Tovuti za Google tu kama YouTube, Gmail, Google Docs, utaftaji wa Google, n.k zingekuwa hazipo, lakini mtandao mwingi bado ungekuwepo (Wikipedia, Stackoverflow, GitHub, tovuti zote za Microsofts, NYTimes, Samsung, TikTok, n.k.) zinaweza kupoteza huduma ya kuingia na utambuzi wa Google, lakini bado ingekuwa inafanya kazi (isipokuwa ikiwa haikuwekwa sawa na kutegemewa moja kwa moja kwenye Google)

***

## Internet Explorer 6 na Chrome

Google Chrome inakuwa Internet Explorer mpya 6. Wakati Google Chrome ilipotoka hapo awali, Firefox ilikuwa kivinjari kinachotawala, na ilikuwa imeua zaidi soko la Internet Explorer (ambalo lilizidi asilimia 96% kabla mamilioni ya watu hawajaenda Firefox na vivinjari vingine) wakati Google Chrome ilitoka, watu walibadilisha kwa sababu ya kasi yake na ilikuwa kwa Google (ambayo haikuchukuliwa kuwa mbaya wakati huo, kwani maswala mengi ya faragha yalikuwa hayajafahamika bado) Google Chrome mwanzoni iliheshimu viwango vya wavuti (ndivyo Firefox ilivyofanya ambayo iliwaua Wapelelezi wa Mtandao 96% ya soko la kivinjari), hata hivyo, kama soko la Google Chromes liliongezeka, Google ilianza kuondoa huduma zaidi na zaidi, ikiongeza spyware zaidi, na ikaacha kukubali viwango vya wavuti, Google Chrome imekuwa Internet Explorer 6 mpya.

Shida kubwa sasa ni tovuti ambazo ni Chrome tu, na hazitafanya kazi kwenye vivinjari vingine, kwani watengenezaji wao waliamua hawataki wengine 30-40% ya watumiaji wa mtandao ambao hawatumii Chrome kutumia wavuti yao.

Hata Google wenyewe hufanya tovuti zao kuwa za Chrome tu. Kwa mfano, utaftaji wa Google utakuchochea kupakua Chrome mara 3 kila sekunde 10 ikiwa itagundua hutumii Google Chrome (hata vivinjari vingine vya msingi wa Chromium kama vile Jasiri vimeathiriwa) na tovuti kama Google Earth hairuhusu watumiaji wa Firefox tumia tovuti yao (kama ya 2020) pamoja na Google Tafsiri haingilii uingizaji wa sauti kwenye Firefox, na vivinjari vingine visivyo vya Google Chrome.

### Shida na Jasiri

Vivinjari vingine ambavyo vinategemea Chromium, kama vile Jasiri na Microsoft Edge sio bure kabisa na programu ya ujasusi ya Google. Jasiri hupendekezwa kawaida na upande mbaya wa jamii ya faragha, lakini Jasiri bado ni shida, kwani hutumia Chromium. Mtandao haupaswi kuwa na vivinjari vya Chromium tu, inapaswa kuwa na chaguo anuwai. Jasiri ni njia mbaya ya kwenda.

[Soma zaidi kuhusu kujiondoa kwenye Google Chrome / Chromium hapa] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Soma zaidi juu ya kujiondoa kutoka kwa ChromeOS / ChromiumOS (Chromebook / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) hapa] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Usasishaji wa faragha bandia

Google imekuwa ikijaribu kuambia ulimwengu wanajali faragha, baada ya kuchelewa tayari. Wanaendelea kudai wanaheshimu faragha ya mtumiaji, lakini bado hawatatulii shida zao zote za faragha.

### Chanzo wazi hakiwezi kuwa sehemu

Chanzo wazi hakiwezi kuwa sehemu. Google ni uthibitisho wa hii. Kila sehemu na nambari ya nambari ya chanzo lazima ionekane kwa umma, bila hata ya 8 ya ka iliyofichwa.

Miradi kama Android na ChromeOS ni chanzo wazi, lakini ina idadi kubwa ya wamiliki, vitu vya ujasusi.

### Oxymoron

Google VPN ni oksijeni. Google haijali faragha, na Mtandao wa Kibinafsi wa Virtual (VPN) kutoka kwa kampuni kama hizo itakuwa moja wapo ya chaguo mbaya zaidi kwa huduma ya VPN.

***

## Utendaji mbaya

Google haijali utendakazi wa bidhaa zao kama ya 2017, kwani programu yao ya mwisho ya alama (Google Octane) ilikomeshwa mnamo 2017.

***

## Usimamizi mbaya wa mradi

Google ina mfumo mbaya sana wa usimamizi wa miradi. Mifano kadhaa za kawaida za programu ambazo zimepungua zaidi na zaidi ni pamoja na Google Duo na muziki wa YouTube (zamani Muziki wa Google Play)

Katika mfumo wa ukuzaji wa ndani wa Googles, programu 1 inaongoza kwa programu nyingine na utendaji wa nusu, basi programu asili inafutwa. Miaka michache baadaye, programu mpya iliyo na utendakazi wa chini ya 75% inafanywa, halafu programu iliyo na utendakazi wa 50% imeondolewa, ikifuatiwa na programu mpya na 87.5% ya utendaji unaoundwa, kisha programu iliyo na utendaji wa 75% imekoma , Nakadhalika.

***

## Kutisha au hakuna wastani wa huduma

YouTube ni mfano wa kawaida katika ulimwengu wa kiasi kibaya kuunda jukwaa baya zaidi kuwapo. Google pia haionekani kupata kwamba YouTube sio watoto wa YouTube.

Kwa YouTube, maudhui ya chuki ya pro-Nazi na White Supremacist hutolewa kwa watumiaji kwa sababu ya wakati zaidi wa ushiriki na pesa zaidi. Google pia imefanya sanavitu vya kijinga kwa kiasi chao, kama vile kuidhinisha video ya Ukristo ya Jinsia kama yaliyomo "yaliyotengenezwa kwa watoto" wakati huo huo umri unazuia video. Pia sio kawaida sana kuona matangazo ya ponografia au ya kutisha yakiwa sawa chini ya video ya Baby Shark, pamoja na anuwai zingine za "yaliyotengenezwa kwa watoto".

Watumiaji wa YouTube wanalalamika mara kwa mara juu ya kiwango duni kwenye YouTube kwa maudhui mabaya (kama mifano iliyoorodheshwa hapo juu) wakati watumiaji wanaweza kufuta video zao bila mpangilio bila sababu bila uwezo wa kufuta, pamoja na watumiaji kuadhibiwa kwa aina yoyote ya kuapa, hata kesi ndogo sana kama kusema "watumiaji wa ujinga" kawaida hulinganisha YouTube na [Soviet Union] (https://en.wikipedia.org/wiki/Soviet_Union) katika enzi ya Stalin, kwa sababu ya adhabu hizi zisizo sawa.

Mnamo 2021, Google ilitangaza kwamba wataweka matangazo kwenye video zote, licha ya video hiyo kuletwa na mapepo (ili Google ipate pesa, lakini muundaji hana) hii haihusiani na kiasi sana, lakini ni muhimu kutambua.

YouTube imesimamiwa (ingawa ni mbaya sana) lakini huduma ya matangazo ya Google ambayo huwafanya pesa zao nyingi inaonekana kuwa na kiasi kidogo.

[Soma zaidi juu ya maswala ya udhibiti wa YouTube na jinsi ya kubadilisha kutoka YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Matangazo ya Google Play yanatengenezwa kutoka kwa shamba za bot, unaweza kujua kwa hali zile zile za matangazo zinazotumiwa na mamia ya kampuni zilizo na mabadiliko kidogo, na hakuna uhusiano wowote na bidhaa (mifano ya kawaida: Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City, na maelfu zaidi) pamoja na mwenendo mbaya wa matangazo yanayodai kuwa watumiaji wanaweza kupata pesa kwa kucheza michezo, kusikiliza muziki, nk PayPal haijatoa maoni haya, lakini ni dhahiri kuwa huu ni utapeli, kana kwamba unaweza kufanya zaidi ya $ 10,000 kwa chini ya sekunde 20 kwa kucheza mchezo umehakikishiwa, hakuna mtu angefanya kazi na angefanya hii badala yake, ambayo haiwezekani, na biashara haikuweza kufanya kazi kama hii. Kashfa hii dhahiri imekuwa ikikua na nguvu tangu 2019, na sasa shamba za bot zinazozalisha matangazo haya zinapigana kati yao katika matangazo yao wenyewe.

Matangazo kadhaa pia ni ya kijinga sana, na hujaribu kupata watumiaji (wengi wao wakiwa watumiaji chini ya umri wa miaka 13, au bots) kubonyeza kupitia ujanja wa kijinsia.

Programu nyingi hutumia bots na astroturf bidhaa zao, kwa hivyo wakati wowote ukaguzi mbaya unafanywa, akaunti za sock puppet bot zitaanza kutuma hakiki 5 za nyota na kujaribu kupuuza ukosoaji wako. [Google inajifanyia wenyewe pia] (# Astroturfing)

[Soma zaidi kuhusu maswala na Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Usafiri wa kijeshi

Ufafanuzi wa jumla [(kutoka Wikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

"
Utaftaji wa nyota ni mazoezi ya kuwafunika wadhamini wa ujumbe au shirika (kwa mfano, kisiasa, matangazo, mahusiano ya kidini au ya umma) kuifanya ionekane kana kwamba inatoka na inasaidiwa na washiriki wa msingi. Ni mazoezi yaliyokusudiwa kutoa taarifa au uaminifu wa mashirika kwa kuzuia habari kuhusu unganisho la kifedha la chanzo. Neno astroturfing limetokana na AstroTurf, chapa ya kutengeneza mazulia iliyoundwa ili kufanana na nyasi za asili, kama mchezo kwenye neno "mashina". Maana nyuma ya matumizi ya neno ni kwamba badala ya juhudi za "kweli" au "asili" nyuma ya shughuli husika, kuna mwonekano wa msaada "bandia" au "bandia".
"

Google ina historia ya utaftaji wa nyota ili kuifanya ionekane kama hawafanyi chochote kibaya (kwa kufanya hivyo, ujasusi ni mbaya) kwa mfano, kuchapisha ukosoaji wa Google kwenye jukwaa kama Twitter (ambayo wana akaunti) itasababisha akaunti kadhaa ambazo zimekuwepo kwa muda lakini hazijawahi kuchapishwa kabla ya kutoka na kudai kuwa uliyosema ni ya uwongo, na kisha kudai kuwa Google ni kampuni bora, lakini imefanywa kwa njia ambayo inaweza kuwa dhahiri kuwa hizi ni bots kwa wengi watu.

***

## Biashara haramu na zisizo za maadili

Google hutumia mazoea ya biashara haramu na yasiyo ya kimaadili kuendeleza ukiritimba wao, kama vile kutumia kimbilio la ushuru, kutoa kazi nje, na kuendelea kufanya shughuli haramu kama gharama ya kufanya biashara.

### Barani Ulaya

Ulaya imekuwa ikiishtaki Google, kesi kubwa ni dhidi ya tabia haramu katika Android, ambayo ilisababisha Google kupokea € 5,000,000,000 (sawa na $ 5,947,083,703.68 mnamo Aprili 9 pesa 2021)

### Nchini Amerika ya Kaskazini

Merika haijatoa faini ya kutosha kwa Google bado, ikilinganishwa na Europe € 5,000,000,000.

### Mabishano

Google haijali shida hadi itengeneze ubishani, basi watafanya jaribio duni la kuitatua, ya kutosha tu kwa mzozo huo kuondoka kwa muda, na shida hiyo inazidi kuwa mbaya hadi itakapoleta ubishani mwingine, na mzunguko unaendelea. Hawajali vya kutosha kufanya chochote mbaya juu yake.

***

## Google ni otomatiki

Kama company, Google ni zaidi ya kiotomatiki, na kiasi kidogo kuliko kiotomatiki.

Kampuni haipaswi kujiendesha kikamilifu. Google ni mfano wa hii. Udhibiti ni wa kutisha wakati unafanywa na AI tu, YouTube ni mfano mzuri, hata na watu wachache zaidi (mamia, au labda elfu) wanaodhibiti tovuti, ambapo inaonekana ni mbaya sana kwamba wengi wao wanapaswa kupata tiba wakati wa kufanya kazi.

***

## Android

Android inamilikiwa na Google. Sehemu ya Ushirika wa Open handset (ambao haujafunguliwa tangu Android) Android imekuwa hatua nyingine ya ukiritimba kwa Google, na ngumu sana kutoroka.

Android imeripotiwa kupiga simu nyumbani kwa Google angalau mara 10 kwa siku, na licha ya kuwa chanzo wazi, bado inafanya kazi kama spyware.

Miradi kadhaa imeundwa kubadilisha kutoka kwa Android, lakini inahitaji kuhimili kifaa chako. Hii haiwezekani tena kwa simu maalum za Samsung huko Amerika, kwa sababu ya Knox DRM. Njia mbadala za Android ni pamoja na iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch, na PiPhone (Pi Simu ni chapa ya simu ambazo zinaendesha mifumo anuwai ya Linux kwenye kifaa cha rununu, kama Fedora, Ubuntu, Arch, n.k.)

[Tazama utafiti wangu juu ya kupata kazi ya mashine inayotumika ya Android] [https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Angalia jinsi ya kuondoa Google kutoka Android] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Vitendo vidogo kusaidia

Kueneza ufahamu kwa kila njia unayoweza ni muhimu. Kwangu, siongei tu mara kwa mara juu ya kudharau, na kuandika nakala, lakini pia nina tabia ndogo ndogo, ambapo ninatoa tuzo yangu ya bure ya kila siku ya Reddit kwa chapisho lililobandikwa kwenye r / degoogle ili kuongeza ufahamu. Kufikia sasa, nimetoa karibu tuzo 30 kwa chapisho lililobandikwa (pia nilitumia sarafu zangu 500 za bure kwenye tuzo 10 za chapisho hilo)

***

## Haiaminiki

Google haiwezi kuaminika, na haiwezi kuaminiwa tena. Wameondoka kabisa "usiwe mwovu" (kila wakati walikuwa wabaya) hadi kuwa wabaya kabisa na hawajaribu kuificha.

***

## Vitu vingine vya kuangalia

[Makaburi ya Google (killbygoogle.com) - orodha iliyopangwa ya bidhaa 224+ ambazo Google imeua] (https://killedbygoogle.com/)

> [Kiunga cha GitHub] (https://github.com/codyogden/killedbygoogle)

[Chama cha wafanyikazi wa Alfabeti - Chama kipya cha wafanyikazi katika Google kilicho na zaidi ya washiriki 800] (https://alphabetworkersunion.org/people/our-union/)

[Hawataki kuachana na yai ya Pasaka ya dinosaur? Tovuti hii umefunika] (https://chromedino.com/)

Kuna njia zingine, tafuta tu.

***

Uhakiki wa ukweli unahitajika kwa nakala hii

***

# # Maelezo ya faili

Aina ya faili: `Markdown (* .md)`

Hesabu ya laini (pamoja na laini tupu na laini ya mkusanyaji): `968`

Toleo la faili: `6 (Jumapili, Aprili 18, 2021 saa 4:18 jioni)`

***

### Hali ya programu

Kazi zangu zote ni bure vizuizi vingine. DRM (** D ** igital ** R ** vizuizi ** M ** anagement) haipo katika kazi yangu yoyote.

! [Bila_label.en.svg isiyo na DRM] (bila-DRM_label.en.svg)

Kibandiko hiki kinasaidiwa na Free Software Foundation. Sijakusudia kuingiza DRM katika kazi zangu.

Ninatumia kifupi "Usimamizi wa Vizuizi vya Dijiti" badala ya "Usimamizi wa Haki za Dijiti" inayojulikana kama njia ya kawaida ya kuishughulikia ni ya uwongo, hakuna haki na DRM. Tahajia "Usimamizi wa Vizuizi vya Dijiti" ni sahihi zaidi, na inasaidiwa na [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) na [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Sehemu hii hutumiwa kukuza uelewa juu ya shida na DRM, na pia kuipinga. DRM ina kasoro kwa muundo na ni tishio kubwa kwa watumiaji wote wa kompyuta na uhuru wa programu.

Mkopo wa picha: [defectivebydesign.org/drm-free/...) (http://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Habari za wafadhili

! [SponsorButton.png] (SponsorButton.png) <- Usibofye kitufe hiki, haifanyi kazi, ni picha tu. Kitufe cha kweli kiko juu ya ukurasa katika kona ya kulia (<- L ** R ** ->)

Unaweza kudhamini mradi huu ukipenda, lakini tafadhali taja ni nini unataka kuchangia. [Tazama pesa unazoweza kuchangia hapa] (https://github.com/seanpm2001/Sponsor-info/tree/main/For- Sponsors)

Unaweza kuona maelezo mengine ya wafadhili [hapa] (https://github.com/seanpm2001/Sponsor-info/)

Jaribu! Kitufe cha mdhamini kiko karibu kabisa na kitufe cha kutazama / kufungua.

***

## Historia ya faili



 * Ilianza faili

> * Imeongeza sehemu ya kichwa

> * Aliongeza faharisi

> * Imeongeza sehemu kuhusu

> * Imeongeza sehemu ya Wiki

> * Imeongeza sehemu ya historia ya toleo

> * Imeongeza sehemu ya maswala.

> * Imeongeza sehemu ya maswala yaliyopita

> * Imeongeza sehemu ya maombi ya kuvuta ya zamani

> * Imeongeza sehemu ya maombi ya kuvuta inayotumika

> * Imeongeza sehemu ya wachangiaji

> * Imeongeza sehemu ya kuchangia

> * Imeongeza sehemu kuhusu README

> * Aliongeza sehemu ya historia ya toleo la README

> * Imeongeza sehemu ya rasilimali

> * Imeongeza sehemu ya hali ya programu, na stika na ujumbe wa bure wa DRM

> *Imeongeza sehemu ya maelezo ya mdhamini

> * Hakuna mabadiliko mengine katika toleo la 0.1

Toleo la 1 (Ijumaa, Februari 19 2021 saa 5:20 jioni)

> Mabadiliko:

> * Ilianza faili

> * Imeongeza sehemu ya maelezo ya msingi

> * Imeongeza sehemu ya maelezo ya hazina

> * Aliongeza orodha ya nakala, na maingizo 14

>> * Imeongeza sehemu ya `makala zinazohusiana`

>> * Imeongeza sehemu ya `tazama pia`

> * Imeongeza sehemu ya maelezo ya faili

> * Imeongeza sehemu ya historia ya faili

> * Aliongeza kijachini

> * Hakuna mabadiliko mengine katika toleo 1

Toleo la 2 (Ijumaa, Februari 19 2021 saa 5:26 jioni)

> Mabadiliko:

> * Imeongeza sehemu ya hali ya tafsiri

> * Aliongeza vitu vingine kuangalia sehemu

> * Imeongeza sehemu ya faragha

> * Imeongeza faharisi

> * Imeongeza kifungu cha hali ya programu

> * Aliongeza sehemu nyingine ya kampeni za kupambana na Google

>> * Imeongeza kifungu kidogo kilichokatika

>> * Imeongeza kifungu kidogo kinachoendelea

> * Imeongeza sehemu ya vyanzo

> * Imeongeza sehemu ya viungo vya kupakua

> * Imesasisha sehemu ya maelezo ya faili

> * Imesasisha sehemu ya historia ya faili

> * Hakuna mabadiliko mengine katika toleo la 2

Toleo la 3 (Jumatano, Februari 24, 2021 saa 7:56 jioni)

> Mabadiliko:

> * Imesasisha faharisi

> * Ilirejelea ikoni ya degoogle na shirika jipya la GitHub

> * Viungo vilivyoongezwa kwenye nakala mpya

> * Imeongeza sehemu ya kupinga hoja zingine

>> * Imeongeza kifungu kidogo cha urahisi

>> * Aliongeza kifungu kwanini hata cha kusumbua

>> * Aliongeza kifungu kingine

> * Imesasisha data zingine

> * Imesasisha sehemu ya maelezo ya faili

> * Imesasisha sehemu ya historia ya faili

> * Hakuna mabadiliko mengine katika toleo la 3

Toleo la 4 (Jumanne, Februari 25, 2021 saa 9:31 jioni)

> Mabadiliko:

> * Imeongeza viungo kwenye nakala mpya 10

> * Aliongeza sehemu juu ya uzoefu wangu wa kupuuza

> * Imesasisha faharisi

> * Imesasisha sehemu ya maelezo ya faili

> * Imesasisha sehemu ya historia ya faili

> * Hakuna mabadiliko mengine katika toleo la 4

Toleo la 5 (Ijumaa, Aprili 9, 2021 saa 6:02 jioni)

_Kumekuwa na ukosefu wa sasisho kwenye harakati za kupambana na Google kutoka kwangu hivi karibuni, ninajitahidi kuirudi baada ya mapumziko ya mwezi 1+._

> Mabadiliko:

> * Imesasisha sehemu ya kichwa

> * Imesasisha faharisi

> * Imesasisha orodha ya lugha: viungo vilivyowekwa, na kuongeza lugha zaidi zinazoungwa mkono

> * Imesasisha sehemu ya hali ya kifungu, na kuongeza viungo 4 vya uma

> * Imesasisha sehemu ya hali ya programu

> * Imeongezwa Go ni sehemu mbaya

> * Imeongeza Matumizi ya sehemu ya DRM

> * Imeongeza sehemu ya maoni potofu ya Kawaida

>> * Imeongezwa Google sio kifungu cha mtandao

> * Imeongeza sehemu ya Internet Explorer 6 na Chrome

>> * Aliongeza Tatizo na kifungu kidogo cha Jasiri

> * Imeongeza kuondolewa kwa faragha kwa uwongo

> * Kilichoongezwa chanzo wazi hakiwezi kuwa kifungu kidogo

> * Aliongeza kifungu cha Oxymoron

> * Imeongeza sehemu mbaya ya utendaji

> * Imeongeza sehemu mbaya ya usimamizi wa mradi

> * Imeongeza sehemu ya kutisha au hakuna huduma

> * Aliongeza sehemu ya Astroturfing

> * Imeongeza sehemu ya biashara haramu na isiyo ya maadili

> * Aliongeza kifungu cha Ulaya

>> * Aliongeza kifungu cha Amerika Kaskazini

>> * Aliongeza kifungu kidogo cha utata

> * Imeongezwa sehemu ya Google ni otomatiki

> * Imeongeza sehemu ya Android

> * Aliongeza vitendo vidogo kusaidia sehemu

> * Imeongeza sehemu isiyoaminika

> * Imeongeza sehemu ya maelezo ya mdhamini

> * Imesasisha kijachini

> * Imesasisha sehemu ya maelezo ya faili

> * Imesasisha sehemu ya historia ya faili

> * Hakuna mabadiliko mengine katika toleo la 5

Toleo la 6 (Jumapili, Aprili 18, 2021 saa 4:18 jioni)

> Mabadiliko:

> * Imesasisha faharisi

> * Imeongeza maelezo mapya ya muhtasari

> * Maelezo ya hali ya nakala iliyosasishwa

> * Aliongeza kiunga kwenye kifungu kipya cha Google FLoC

> * Aliongeza kiunga kwa nakala ya Wuest 3n Fuchs Degoogle na maelezo ya jumla juu yake

> * Imesasisha sehemu ya maelezo ya faili

> * Imesasisha sehemu ya historia ya faili

> * Hakuna mabadiliko mengine katika toleo la 6

Toleo la 7 (Inakuja hivi karibuni)

> Mabadiliko:

> * Inakuja hivi karibuni

> * Hakuna mabadiliko mengine katika toleo la 7

Toleo la 8 (Inakuja hivi karibuni)

> Mabadiliko:

> * Inakuja hivi karibuni

> * Hakuna mabadiliko mengine katika toleo la 8

Toleo la 9 (Inakuja hivi karibuni)

> Mabadiliko:

> * Inakuja hivi karibuni

> * Hakuna mabadiliko mengine katika toleo la 9

Toleo la 10 (Inakuja hivi karibuni)

> Mabadiliko:

> * Inakuja hivi karibuni

> * Hakuna mabadiliko mengine katika toleo la 10

Toleo la 11 (Inakuja hivi karibuni)

> Mabadiliko:

> * Inakuja hivi karibuni

> * Hakuna mabadiliko mengine katika toleo la 11

Toleo la 12 (Inakuja hivi karibuni)

> Mabadiliko:

> * Inakuja hivi karibuni

> * Hakuna mabadiliko mengine katika toleo la 12

***

## Kijachini

Umefika mwisho wa faili hii

([Rudi juu] (# Juu) | [Rudi kwa GitHub] (https://github.com))

### EOF

***
