***

！[DEGOOGLE1.jpeg]（DEGOOGLE1.jpeg）

＃Degoogling-讓您的生活失去谷歌

這是有關常規去膠信息的主要去膠文章，以及指向其他文章的鏈接。

[查看列表作為GitHub組織]（https://github.com/Degoogle-your-life）

***

_以另一種語言閱讀本文：_

**當前語言是：**`英語（美國）`_（翻譯可能需要更正以修復英語，以替換正確的語言）_

_🌐語言列表_

**排序：**`A-Z`

[排序選項不可用]（https://github.com/Degoogle-your-Life）

（[af Afrikaans]（/。github / README_AF.md）Afrikaans | [sq Shqiptare]（/。github / README_SQ.md）阿爾巴尼亞語| [amአማርኛ]（/。github / README_AM.md）Amharic | [arعربى] （/.github/README_AR.md）阿拉伯語| [hyհայերեն]（/。github / README_HY.md）亞美尼亞語| [azAzərbaycandili]（/。github / README_AZ.md）阿塞拜疆| [eu Euskara]（/。github /README_EU.md）巴斯克語| [beБеларуская]（/。github / README_BE.md）白俄羅斯語| [bnবাংলা]（/。github / README_BN.md）孟加拉語| [bs Bosanski]（/。github / README_BS.md）波斯尼亞語| [bgбългарски]（/。github / README_BG.md）保加利亞語| [caCatalà]（/。github / README_CA.md）加泰羅尼亞語| [ceb Sugbuanon]（/ .. github / README_CEB.md）Cebuano | [ny Chichewa ]（/。github / README_NY.md）Chichewa | [zh-CN簡體中文]（/。github / README_ZH-CN.md）簡體中文| [zh-t中國傳統的）]（/。github / README_ZH -T.md）中文（繁體）| [co Corsu]（/。github / README_CO.md）科西嘉語| [hr Hrvatski]（/。github / README_HR.md）克羅地亞語| [csčeština]（/。github / README_CS .md）捷克語| [da dansk]（README_DA.md）丹麥語| [nl Nederlands]（/。github / README_ NL.md）荷蘭語| [** zh-cn英語**]（/。github / README.md）英語| [EO世界語]（/。github / README_EO.md）世界語| [et Eestlane]（/。github / README_ET.md）愛沙尼亞語| [tl Pilipino]（/。github / README_TL.md）菲律賓| [fi Suomalainen]（/。github / README_FI.md）芬蘭語| [frfrançais]（/。github / README_FR.md）法語| [fy Frysk]（/。github / README_FY.md）弗里斯蘭語| [gl Galego]（/。github / README_GL.md）加利西亞語| [kaქართველი]（/。github / README_KA）格魯吉亞語| [de Deutsch]（/。github / README_DE.md）德語| [elΕλληνικά]（/。github / README_EL.md）希臘語| [guગુજરાતી]（/。github / README_GU.md）古吉拉特語| [htKreyòlayisyen]（/。github / README_HT.md）海地克里奧爾語| [ha Hausa]（/。github / README_HA.md）Hausa | [hawŌleloHawaiʻi]（/。github / README_HAW.md）夏威夷語| [heעִברִית]（/。github / README_HE.md）希伯來語| [hiहिन्दी]（/。github / README_HI.md）印地語| [hmn Hmong]（/。github / README_HMN.md）Hmong | [hu Magyar]（/。github / README_HU.md）匈牙利語| [是Íslenska]（/。github / README_IS.md）冰島語| [ig Igbo]（/。github / README_IG.md）Igbo | [id bahasa Indonesia]（/。github / README_ID.md）冰島語| [ga Gaeilge]（/。github / README_GA.md）愛爾蘭語| [it Italiana / Italiano]（/。github / README_IT.md）| [ja日本語]（/。github / README_JA.md）日語| [jw Wong頜骨]（/。github / README_JW.md）Javanese | [knಕನ್ನಡ]（/。github / README_KN.md）卡納達語| [kkҚазақ]（/。github / README_KK.md）哈薩克語| [kmខ្មែរ]（/。github / README_KM.md）高棉語| [rw Kinyarwanda]（/。github / README_RW.md）Kinyarwanda | [ko-south韓國語]（/。github / README_KO_SOUTH.md）韓語（南）| [ko-north문화어]（README_KO_NORTH.md）朝鮮語（北部）（尚未翻譯）| [kuKurdî]（/。github / README_KU.md）庫爾德語（Kurmanji）| [kyКыргызча]（/。github / README_KY.md）吉爾吉斯語| [loລາວ]（/。github / README_LO.md）老撾| [la Latine]（/。github / README_LA.md）拉丁語| [lt Lietuvis]（/。github / README_LT.md）立陶宛語| [lbLëtzebuergesch]（/。github / README_LB.md）盧森堡語| [mkМакедонски]（/。github / README_MK.md）馬其頓語| [mg馬達加斯加語]（/。github / README_MG.md）馬達加斯加語| [ms Bahasa Melayu]（/。github / README_MS.md）馬來語| [mlമലയാളം]（/。github / README_ML.md）馬拉雅拉姆語| [mt Malti]（/。github / README_MT.md）馬耳他語| [mi Maori]（/。github / README_MI.md）毛利人| [mrमराठी]（/。github / README_MR.md）馬拉地語| [mnМонгол]（/。github / README_MN.md）蒙古語| [myမြန်မာ]（/。github / README_MY.md）緬甸（緬甸）| [neनेपाली]（/。github / README_NE.md）尼泊爾語| [no norsk]（/。github / README_NO.md）挪威文| [或ଓଡିଆ（ଓଡିଆ）]（/。github / README_OR.md）Odia（奧里亞語）| [psپښتو]（/。github / README_PS.md）普什圖語| [faفارسی]（/。github / README_FA.md）|波斯語[pl polski]（/。github / README_PL.md）波蘭語| [ptportuguês]（/。github / README_PT.md）葡萄牙語| [paਪੰਜਾਬੀ]（/。github / README_PA.md）旁遮普語|沒有可用字母Q |開頭的語言。 [roRomână]（/。github / README_RO.md）羅馬尼亞語| [ruрусский]（/。github / README_RU.md）俄語| [sm Faasamoa]（/。github / README_SM.md）薩摩亞語| [gdGàidhligna h-Alba]（/。github / README_GD.md）Scots Gaelic | [srСрпски]（/。github / README_SR.md）塞爾維亞語| [st Sesotho]（/。github / README_ST.md）Sesotho | [sn Shona]（/。github / README_SN.md）Shona | [sdسنڌي]（/。github / README_SD.md）信德語| [siසිංහල]（/。github / README_SI.md）僧伽羅語| [sk斯洛伐克語]（/。github / README_SK.md）斯洛伐克語| [slSlovenščina]（/。github / README_SL.md）斯洛文尼亞語| [so Soomaali]（/。github / README_SO.md）索馬里文| [[es enespañol]（/。github / README_ES.md）西班牙語| [su Sundanis]（/。github / README_SU.md）Sundanese | [sw Kiswahili]（/。github / README_SW.md）斯瓦希里語| [sv Svenska]（/。github / README_SV。md）瑞典語| [tgТоҷикӣ]（/。github / README_TG.md）塔吉克語| [taதமிழ்]（/。github / README_TA.md）泰米爾語| [ttТатар]（/。github / README_TT.md）塔塔爾語| [teతెలుగు]（/。github / README_TE.md）泰盧固語| [thไทย]（/。github / README_TH.md）泰國語| [trTürk]（/。github / README_TR.md）土耳其語| [tkTürkmenler]（/。github / README_TK.md）土庫曼人| [ukУкраїнський]（/。github / README_UK.md）烏克蘭語| [urاردو]（/。github / README_UR.md）烏爾都語| [ugئۇيغۇر]（/。github / README_UG.md）維吾爾語| [uz O'zbek]（/。github / README_UZ.md）烏茲別克語| [viTiếngViệt]（/。github / README_VI.md）越南語| [cy Cymraeg]（/。github / README_CY.md）威爾士語| [xh isiXhosa]（/。github / README_XH.md）Xhosa | [yiיידיש]（/。github / README_YI.md）意第緒語| [yo Yoruba]（/。github / README_YO.md）Yoruba | [zu Zulu]（/。github / README_ZU.md）Zulu）有110種語言版本（不算英語和朝鮮語時為108種語言，因為朝鮮語尚未翻譯。 ）/README.md））

除英語以外的其他語言的翻譯是機器翻譯的，尚不准確。截至2021年2月5日，尚未修復錯誤。請在此處報告翻譯錯誤[https://github.com/seanpm2001/Degoogle-your-life/issues/）確保備份您的更正並提供指導，因為我不太懂英語（我打算最終聘請翻譯）以外的語言，所以請在報告中引用[wiktionary]（https://en.wiktionary.org）和其他來源。否則，將拒絕發布更正。

注意：由於GitHub對markdown的解釋（以及幾乎所有其他基於Web的markdown解釋）的限制，單擊這些鏈接會將您重定向到另一個頁面上的單獨文件，該頁面不是我的GitHub個人資料頁面。您將被重定向到託管README的[seanpm2001 / seanpm2001存儲庫]（https://github.com/seanpm2001/seanpm2001）。

由於我在其他翻譯服務（如DeepL和Bing Translate（對於反Google廣告系列而言頗具諷刺意味））所需要的語言支持有限或不提供支持，因此使用Google Translate進行翻譯。我正在尋找替代方案。由於某種原因，格式（鏈接，分隔符，粗體，斜體等）在各種翻譯中都被弄亂了。解決起來很繁瑣，而且我不知道如何使用非拉丁字符的語言來解決這些問題，從右到左的語言（例如阿拉伯語）需要額外的幫助來解決這些問題。

由於維護問題，許多翻譯版本已經過時，並且使用的是本“ README”文章文件的過時版本。需要翻譯器。另外，從2021年4月9日開始，要使所有新鏈接正常工作還需要一段時間。

***

＃＃ 指數

[00.0-標題]（＃Degoogling --- Degoogle-your-life）

> [00.1-索引]（＃Index）

[01.0-基本描述]（＃Basic-description）

> [01.1-存儲庫標題]（＃Degoogle-your-life）

> [01.2-Wuest3NFuchs描述概述]（＃Overview-by-Wuest3nFuchs）

>> [01.2.1-這是什麼意思？]（＃Wuest3nFuchs的意思是什麼？）

>> [01.2.2-為什麼要使用Google？]（＃Why-Degoogle--by-Wuest3nFuchs）

[02.0-文章]（＃Articles）

[03.0-隱私]（＃Privacy）

[04.0-其他反Google廣告系列]（＃Other-anti-Google-campaigns）

> [04.0.1-已終止]（＃已終止）

> [04.0.2-進行中]（＃Ongoing）

[05.0-反其他參數]（＃Countering-other-arguments）

> [05.0.1-便利]（＃便利）

> [05.0.2-為什麼重要？無論如何都為時已晚]（＃為什麼會如此，但它也太遲了）

> [05.0.3-其他]（＃Other）

[06.0-來源]（＃Sources）

[07.0-下載鏈接]（＃Download-links）

[08.0-我的Degoogling經驗]（＃My-degoogling-experience）

> [08.1-我切換的內容]（＃What-I-switched-from）

> [08.2-我仍然無法擺脫的產品]（＃Products-我仍然無法擺脫-）

[09.0-其他要簽出的東西]（＃Other-things-things）

[10.0-文件信息]（＃File-info）

> [10.1-軟件狀態]（＃Software-status）

> [10.2-贊助商信息]（＃Sponsor-info）

[11.0-文件歷史記錄]（＃File-history）

[12.0-頁腳]（＃Footer）

***

##基本描述

[摘自Wikipedia：Degoogle]（https://en.wikipedia.org/wiki/DeGoogle）

DeGoogle運動（也稱為de Google運動）是一個草根運動，它是由隱私權活動家敦促用戶完全停止使用Google產品（由於對該公司的隱私問題日益關注）而發起的。該術語是指將Google從自己的生活中刪除的行為。隨著互聯網巨頭不斷增長的市場份額為公司在數字空間中創造了壟斷力量，越來越多的記者註意到難以找到公司產品的替代品。

**歷史**

2013年，Venturebeat的John Koetsier表示，亞馬遜基於Android的Kindle Fire平板電腦是“經過Google谷歌化的Android版本。” 2014年，《美國新聞》的約翰·辛普森（John Simpson）發表了有關Google和其他搜索引擎的“被遺忘權”。 2015年，愛爾蘭時報的Derek Scally撰寫了一篇文章，介紹瞭如何“去Google化您的生活”。 2016年，Androi的克里斯·卡洛恩（Kris Carlon）d Authority建議CyanogenMod 14的用戶可以將其手機“去Google化”，因為CyanogenMod在沒有Google應用的情況下也可以正常工作。 Inverse的Nick Nickcheschesi在2018年撰寫了有關ProtonMail如何促進“完全擺脫Google的生活”的文章。 Lifehacker的Brendan Hesse寫了一篇關於“退出Google”的詳細教程。Gizmodo記者Kashmir Hill聲稱她錯過了會議，並且在不使用Google Calendar的情況下組織聚會很困難。2019年，華為向菲律賓的手機所有者退款，這些人當時是禁止使用Google提供的服務，因為很少有其他選擇，以至於缺少公司產品會導致無法正常使用互聯網。

***

＃Degoogle-您的生活
一個常規的Degoogling信息的存儲庫，並鏈接到我的其他Degoogling的存儲庫。

***

## Wuest3nFuchs概述

由[Wuest3nFuchs]（https://github.com/Wuest3nFuchs）提供的更好的描述-來源：[Wuest3nFuchs / Degoogle]（https://github.com/Wuest3nFuchs/Degoogle）

＃＃＃ 這是什麼意思？通過Wuest3nFuchs

[消隱手段]（https://en.wikipedia.org/wiki/DeGoogle）停止使用屬於Google的任何東西，即由Google製造的任何東西。我說的是他們的[搜索引擎]（https://en.wikipedia.org/wiki/Google_Search），他們的郵件服務（[Gmail]（https://en.wikipedia.org/wiki/Gmail），[ YouTube]（https://en.wikipedia.org/wiki/Criticism_of_Google#YouTube)，[etc](https://en.wikipedia.org/wiki/List_of_Google_products）。

###為什麼要使用Google？通過Wuest3nFuchs

Google是目前世界上最強大的公司之一。 [他們]（https://www.cnbc.com/2017/11/20/what-does-google-know-about-me.html）[有]（https://vulcanpost.com/636465/google- personal-info /）存儲了大量[信息]（https://www.security-faqs.com/how-many-ways-does-google-store-your-personal-information.html）[在]（ https://www.cnet.com/how-to/google-collects-a-frightening-amount-of-data-about-you-you-can-find-and-delete-it-now/）[全部] （https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy)[of](https://www.nbcnews.com / tech / tech-news / google-sells-future-powered-your-personal-data-n870501）[我們]（https://www.wired.com/story/google-tracks-you-privacy/）。有人會說我們的信息對他們是安全的，因為他們知道如何保護它。但這不是真的。 Google之前已經被滲透，並且將來會被滲透。也許不是由某個腳本小子來完成，而是由一個民族國家來完成。 Google會在我們所有人中存儲個人信息，因為這是他們賺錢的方式。

[他們掃描了我們的電子郵件]（https://www.forbes.com/sites/daveywinder/2020/02/28/google-confirms-new-ai-tool-scans-300-billion-gmail-attachments-every-week /），[存儲我們在使用他們的搜索引擎時搜索的內容]（https://www.wired.com/story/google-tracks-you-privacy/），[我們在YouTube上觀看的視頻]（https ：//www.nytimes.com/2016/08/13/technology/personaltech/how-to-make-youtube-stop-watching-what-you-watch.html）。他們以此為目標，並在我們的個人資料上建立我們的形象，以便根據我們與我們最好的朋友的交談向我們展示一些廣告，以便他們可以向我們展示我們需要的廣告，但這太令人毛骨悚然了。多虧了[先生斯諾登]（https://en.wikipedia.org/wiki/Edward_Snowden），我們現在知道Google已通過名為**“ [PRISM]（https://en.wikipedia.org/ Wiki / PRISM_（surveillance_program））“ **。


將來，有人將能夠訪問所有這些信息，我向您保證，確實會發生[糟糕]（https://en.wikipedia.org/wiki/Nazi_Germany）。為防止這種情況的發生，您應該立即開始Degoogling。同樣，您不應該使用與** [NSA]（https://en.wikipedia.org/wiki/National_Security_Agency）共享數據的公司的產品。您應該通過取消搜索來阻止所有這一切。

**如果其他人可以做到，您也可以做到。

[在這裡閱讀更多]（https://github.com/Wuest3nFuchs/Degoogle）

<！-當前未列出到fork的鏈接，因為我並不完全擁有此存儲庫，並且想推廣其他資源。鏈接到我自己的https://github.com/Degoogle-your-life/Degoogle會很自私！->

***

##文章

###文章狀態

_所有文章目前仍在進行中，需要大量改進。提出建議和修正。_

_截至2021年4月18日下午4:09，大多數文章尚未開始。我正在努力尋找時間和精力來啟動它們。_

[為什麼您應該停止使用Google Chrome]（https://github.com/seanpm2001/Why-you-should-stop-using-Chrome）<！-1！->

[停止使用ChromeBooks]（https://github.com/seanpm2001/Stop-using-Chromebooks）<！-2！->

[停止使用WideVine DRM /是時候切割WideVine DRM]（https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM）<！-3！->

[為什麼您應該停止使用ReCaptcha]（https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha）<！-4！->

[從YouTube替代]（https：//github.com/seanpm2001/Alternating-from-YouTube）<！-5！->

[停止谷歌搜索，為什麼您應該停止使用Google搜索]（https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search）<！-6！- >

[為什麼您應該停止使用Gmail]（https://github.com/seanpm2001/Why-you-should-stop-using-GMail）<！-7！->

[為什麼你應該停止使用Android]（https://github.com/seanpm2001/Why-you-should-stop-using-Android）<！-8！->

[為什麼您應該避免使用Google Amp]（https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP）<！-9！->

[為什麼您應該停止使用Google雲端硬盤]（https://github.com/seanpm2001/為什麼-您-應該-停止使用Google-雲端硬盤）<！-10！->

[為什麼您應該停止使用Google Maps和Google Earth]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth）<！-11！- ->

[嘿Google，停止]（https://github.com/seanpm2001/Hey-Google-Stop）<！-12！​​->

[停止從Google / Play圖書中閱讀]（https://github.com/seanpm2001/Stop-reading-from-Google-Books）<！-13！->

[停止使用Google課堂]（https://github.com/seanpm2001/Stop-using-Google-Classroom）<！-14！->

[為什麼您應該停止使用Google Translate]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate）<！-15！->

[為什麼要停止使用您的Google帳戶]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Accounts）<！-16！->

**即將撰寫的新文章：**

[為什麼您應該停止使用Gerrit]（https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit）<！-17！->

[為什麼您應該停止使用Google Analytics（分析，該存儲庫在2021年2月24日，星期三，4：13 pm截止，我的頭就壞了）]] -Google-Analytics）<！-18！->

<！-工作分隔線！->

[為什麼您應該停止使用Google AdSense]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense）<！-19！->

[為什麼您應該停止使用Google One]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-One）<！-20！->

[為什麼您應該停止使用Google+（已停用）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus）<！-21！->

[為什麼您應該停止使用Google Play商店]（https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store）<！-22！->

[為什麼您應該停止使用Google文檔]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs）<！-23！->

[為什麼您應該停止使用Google幻燈片]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides）<！-24！->

[為什麼您應該停止使用Google表格]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets）<！-25！->

[為什麼您應該停止使用Google表單]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms）<！-26！->

[為什麼您應該停止使用Google Cardboard]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard）<！-27！->

[為什麼您應該停止使用Google Messages]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages）<！-28！->

[為什麼您應該停止使用Google Material Design]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design）<！-29！->

[為什麼您應該停止使用Google Glass / Glasses]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass）<！-30！->

[為什麼您應該停止使用Google紫紅色]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia）<！-31！->

[為什麼您應該停止使用GBoard]（https://github.com/seanpm2001/Why-you-should-stop-using-GBoard）<！-32！->

[為什麼您應該停止使用Google Home]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home）<！-33！->

[為什麼您應該停止使用Google Nest]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest）<！-34！->

[為什麼您應該停止使用Google Hangouts（已終止）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts）<！-35！->

[為什麼您應該停止使用Google Duo]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo）<！-36！->

[為什麼您應該停止使用Google Tensorflow]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow）<！-37！->

[為什麼您應該停止使用Google Blockly]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly）<！-38！->

[為什麼您應該停止使用Google Flutter]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter）<！-39！->

[為什麼您應該停止使用Google Go語言編程語言]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go）<！-40！->

[為什麼您應該停止使用Google Dart編程語言]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart）<！-41！->

[為什麼您應該停止使用Google WebP圖像格式]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP）<！-42！->

[為什麼您應該停止使用Google的WebM視頻格式]（https://github.com / seanpm2001 /為什麼要停止使用Google-WebM）<！-43！->

[為什麼您應該停止使用Google Video]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video）<！-44！->

[為什麼您應該停止使用Google網站（經典）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic）<！-45！->

[為什麼您應該停止使用Google協作平台（“新”）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New）<！-46！->

[為什麼您應該停止使用Google Pay]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay）<！-47！->

[為什麼您應該停止使用Android Pay]（https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay）<！-48！->

[為什麼您應該停止使用Google VPN（oxymoron）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN）<！-49！->

[為什麼您應該停止使用Google相簿]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos）<！-50！->

[為什麼您應該停止使用Google日曆]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar）<！-51！->

[為什麼您應該停止使用VirusTotal（因為自2012年9月以來它已由Google擁有）（https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal）<！-52！- >

[為什麼您應該停止使用Google Fi]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi）<！-53！->

[為什麼您應該停止使用Google Stadia]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia）<！-54！->

[為什麼您應該停止使用Google Keep]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep）<！-55！->

[為什麼您應該停止使用Google Base]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base）<！-56！->

[為什麼您應該停止參加Google Summer of Code]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code）<！-57！- >

[為什麼您應該停止使用Google Camera]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera）<！-58！->

[為什麼您應該停止使用Google計算器（可能看起來很極端，但是您應該從所有內容中刪除Google，非常容易替代）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-計算器）<！-59！->

[為什麼您應該停止使用Google調查+獎勵]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards）<！-60！->

[為什麼您應該停止使用Google繪圖]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings）<！-61！->

[為什麼您應該停止使用Tenor（GIF網站，自2019年以來由Google擁有）]（https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor）<！-62！- ->

[什麼是FLoC-為什麼您應該避免Google的大FLoCing問題（停止使用Google Chrome）]（https://github.com/seanpm2001/What-the-FLoC）<！-63！->

**總文章數：**`63`

**第[路線圖AB]（DegoogleCampaign_2021Roadmap_Part1.md）（截至2021年3月12日）休假2天**

**第[路線圖BB]（DegoogleCampaign_2021Roadmao_Part2.md）（最晚2021年）關閉2天**

文章狀態

所有文章目前仍在進行中，需要大量改進。建議和修正是允許的。

**叉**

擴展我的Degoogle網絡，並增加訪問便利性和社區呼聲。

1. [Fossapps]（https://github.com/Degoogle-your-life/Fossapps）|派生自：[https://github.com/wacko1805/Fossapps]（https://github.com/wacko1805/Fossapps）（英語）

2. [隱私鏈接]（https://github.com/Degoogle-your-life/Privacy-links）|派生自：[https://github.com/Arturro43/privacy-links](https://github.com/Arturro43/privacy-links）（波蘭語）

3. [令人愉快的隱私]（https://github.com/Degoogle-your-life/Delightful-Privacy）|派生自：[https://github.com/LinuxCafeFederation/Delightful-Privacy]（https://github.com/LinuxCafeFederation/Delightful-Privacy）（英語）

4. [阻止列表]（https://github.com/Degoogle-your-life/blocklists）|派生自：[https://github.com/jmdugan/blocklists]（https://github.com/jmdugan/blocklists）（英語）

5. [Degoogle，作者：Wuest3nFuchs]（https://github.com/Degoogle-your-life/Degoogle）|派生自：[https://github.com/Wuest3nFuchs/Degoogle]（https://github.com/Wuest3nFuchs/Degoogle）（英語）

**有關的**

[已刪除Android手機虛擬機的研究]（https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research）

**也可以看看：**

[Google在Wikipedia上的批評]（https://en.wikipedia.org/wiki/Criticism_of_Google）

[Google Graveyard（killedbygoogle.com）-Google殺死了224種以上產品的排序列表]（https://killedbygoogle.com/）

> [GitHub鏈接]（https://github.com/codyogden/killedbygoogle）

[字母工會-Google的新工會有800多名成員]（https://alphabetworkersunion.org/people/our-union/）

[不想與恐龍復活節彩蛋分開嗎？該網站覆蓋了您] [https://chromedino.com/）

***

＃＃ 隱私

[G]（https://en.wikipedia.org/wiki/Criticism_of_Google）[o]（https://zh.wikipedia.org/wiki/PRISM_（監視程序））[o]（https://www.reddit.com/r/degoogle/）[g]（https：//www.wired .com / 2012/06 / opinion-google-is-evil /）[l]（https://securitygladiators.com/chrome-privacy-bad/）[e]（https://www.zdnet.com/article / goodbye-google-why-and-how-to-take-back-your-privacy /）[h]（https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data- facebook-google-has-on-you-privacy）[a]（https://www.vox.com/recode/2020/2/21/21146998/google-new-mexico-children-privacy-school-chromebook-訴訟] [s]（https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox-1）[a]（https://money.cnn.com/2017/ 10/11 / technology / google-home-mini-security-flaw / index.html）[v]（https://www.huffpost.com/entry/why-googles-spying-on-use_b_3530296）[e]（ https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81)[r](https://www.theguardian.com/technology/2019/ nov / 05 / fitbit-google-acquisition-health-data）[y]（https://www.computerworld.com/article/312 8791 / how-google-homes-always-on-will-affect-privacy.html）[v]（https://protonmail.com/blog/google-privacy-problem/）[e]（https：// www .forbes.com / sites / gordonkelly / 2020/02/23 / google-chrome-80-upgrade-deep-linking-update-chrome-browser /）[r]（https://www.wired.co.uk/ article / duckduckgo-google-alternative-search-privacy）[y]（https://zh.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism）[b]（https://spreadprivacy.com/three-reasons-why-沒有隱藏的論據是有缺陷的/)[a](https://eduzaurus.com/free-essay-samples/nothing-to-hide-argument-has-nothing-to-say/） [d]（https://www.cnet.com/how-to/google-collects-a-frightening-amount-of-data-about-you-you-can-find-and-delete-it-now/ ）[r]（https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your-personal-data-n870501）[e]（https://www.eff.org /deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes-and)[c](https://www.wired.com/story/google -tracks-you-privacy /）[o]（https://www.theguardian.com/commentisfree /2018/mar/28/all-the-data-facebook-google-has-on-you-privacy)[r](https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision -TOTAL-data-collection-revealed.html）[d]（https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H）[w]（https：//www.wired .com / story / health-fitness-data-privacy /）[h]（https://www.pcmag.com/news/google-sued-over-kids-data-collection-on-education-chromebooks）[e ]（https://mashable.com/article/google-android-data-collection-study/）[n]（https://www.engadget.com/australian-government-google-data-collection-lawsuit-182043643 .html）[i]（https://www.maketecheasier.com/studyandroid-data-google-ios-apple/）[t]（https://www.washingtonpost.com/technology/2019/07/23/ never-googlers-web-users-take-ultimate-step-guard-their-data /）[c]（https://www.cnn.com/2019/11/12/business/google-project-nightingale-ascension /index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https://moz.com/blog/where-does-google-draw-the-data-collection行）[e]（ https://mashable.com/article/google-android-data-collection-study/)[s](https://eandt.theiet.org/content/articles/2020/06/google-sued-over-data -collection-from-users-in-inognito-mode /）[t]（https://www.nytimes.com/2019/01/21/technology/google-europe-gdpr-fine.html）[o]（ https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data-claims-on-behalf-of-5-million-iphone-users）[u]（https： //time.com/23782/google-flu-trends-big-data-problems/)[s](https://www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https ：//www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/）[r]（https：//www.computerworld。 com / article / 2914838 / project-fi-will-help-google-amass-even-more-data-about-you.html）[p]（https://topclassactions.com/lawsuit-settlements/privacy/google-說類行動訴訟訴訟同意書到數據收集/][r](https://arstechnica.com/information-technology/2014/01/what-google-can-really-do-with巢還是巢y-nests-data /）[i]（https://www.cbsnews.com/news/google-education-spies-on-collects-data-on-millions-of-kids-alleges-lawsuit-new-mexico -attorney-general /）[v]（https://www.nationalreview.com/2018/04/the-student-data-mining-scandal-under-our-noses/）[a]（https：// www .wired.com / insights / 2012/10 / google-opt-out /）[c]（https://www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html） [y]（https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550）[。]（https://medium.com/digitalprivacywise / why-you-should-stop-using-google-chrome-6c934c9a827c）（我可以繼續證明這一點，但是花了很長時間才找到並仔細閱讀所有這些文章）

由於所有Google產品都包含間諜軟件，因此Google產品的隱私始終很糟糕。

無論您做什麼，使用Google時，所有敏感個人數據都會發送給Google和其他人。谷歌也被發現正在經歷開放程序。例如，根據個人經驗（oFirefox）並打開了一個我沒有訪問過的YouTube標籤，然後我離線觀看了多個視頻（VLC Media Player）。後來，當我檢查建議時，幾乎看到了所有內容。毫無疑問，他們也在監視其他程​​序。

在Chrome（和許多其他瀏覽器）中，存在隱身模式。在Chrome中，此模式毫無意義，因為Google仍會挖掘您的數據。即使您關閉了數據挖掘/跟踪功能並啟用了“請勿跟踪”信號，這也令人驚訝，Google仍在挖掘您的數據。

如果您認為自己沒有什麼可隱藏的，那麼**您絕對是錯誤的**。這個論點被多次揭穿：

[通過維基百科]（https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism）

1.愛德華·斯諾登（Edward Snowden）說：“爭辯說您不關心隱私權是因為您沒有什麼可隱瞞的，這與說您不在乎言論自由是因為您無話可說。”我沒什麼可隱瞞的，”您說，“我不在乎這項權利。”您在說，“我沒有這項權利，因為我必須要證明自己是正確的。權利的運作方式是，政府必須證明其侵犯您權利的合理性。”

2. Daniel J. Solove在《高等教育紀事》的一篇文章中說，他反對這一論點。他說，政府可能洩漏有關某人的信息並對該人造成損害，或者即使某人實際上沒有從事不正當行為，也可能利用有關某人的信息拒絕獲得服務，並且政府可能對某人的個人造成損害通過犯錯誤來生活。索洛夫（Solove）寫道：“直接參與時，無所不包的論點可能會令人反感，因為它迫使辯論集中在對隱私的狹understanding理解上。但是，當面對由政府數據收集和使用所帶來的眾多隱私問題時，就超出了監視和監視的範圍。披露，最後無話可說的說法無話可說。”

3.隱私權：道德和法律基金會的作者亞當·D·摩爾認為：“這是權利抗拒成本/收益或後果論點之類的觀點。在這裡，我們拒絕認為隱私利益屬於這種觀點。可以交易以換取安全性的東西。”他還指出，監視可以根據外觀，種族，性取向和宗教對社會中的某些群體產生不成比例的影響。

4.計算機安全專家和密碼學家布魯斯·施耐爾（Bruce Schneier）表示反對，他援引了黎塞留樞機主教的說法：“如果給我六句由最誠實的人手寫的文字，我會發現其中有些東西使他被絞死”州政府如何在一個人的生活中找到某些方面，以起訴或勒索該人。施耐爾還指出：“太多人錯誤地將辯論描述為'安全與隱私'。真正的選擇是自由與控制。”

5. Harvey A. Silverglate估計，普通百姓平均每天在美國不知情的情況下犯下三項重罪。

6.哲學家和心理分析家埃米利奧·莫迪尼（Emilio Mordini）認為，“無可掩蓋”的論點本質上是自相矛盾的。人們不需要具有“隱藏的東西”即可隱藏“某些東西”。莫迪尼說，隱藏的東西不一定是相關的。相反，他認為必須同時隱藏和限制訪問的私密區域是必要的，因為從心理上講，我們通過發現可以向他人隱藏某些東西而成為個人。

7.朱利安·阿桑奇（Julian Assange）表示：“尚無殺手.。雅各布·阿佩爾鮑姆（@ioerror）做出了明智的回應，要求說這話的人將手機解鎖並放下褲子，我的意思是， “好吧，如果你是如此無聊，那麼我們不應該和你說話，其他任何人也不要說話。”但從哲學上講，真正的答案是：大規模監視是一種大規模的結構性變化。即使你是地球上最卑鄙的人，也要接受它。”

8.法學教授伊格納西奧·科豐（Ignacio Cofone）辯稱，該論點本身是錯誤的，因為每當人們向他人披露相關信息時，他們也會披露不相關的信息。這些不相關的信息會增加隱私成本，並可能導致其他危害，例如歧視。

***

##其他反Google廣告系列

這是其他一些著名的反Google廣告系列的列表。此列表不完整。你可以幫助擴展它。

###已終止

[Scroogled-Microsoft（2012年11月至2014年11月）]（https://en.wikipedia.org/wiki/Scroogled）

_目前沒有其他條目。

###進行中

_此列表當前為空。

***

##反擊其他參數

人們提出一些論據來證明Google的正當性。第一個主要的對象之一已經被揭穿了[here]（＃Privacy），但這裡還有一些其他的：

＃＃＃ 方便

是的，Google產品似乎很方便。但是，為了方便起見，您在進行一切有利的交易，包括安全性，私密性和可靠性。多年來，Google變得越來越懶惰，其服務器的故障越來越多。目前，Google服務器每月會中斷近一小時一到兩次的時間（最著名的是YouTube）

不幸的是，由於社會對Google的依賴，Google已成為互聯網的主導者，並且正在尋求控制越來越多的東西。 2012年，當Google下降5分鐘時，據報導，“全球**互聯網流量”下降了40％**谷歌經常下降了1-2小時，並且[解雇了道德團隊] （https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/）等，它們將變得越來越不方便。

便利並不總是一件好事。您應該知道發生了什麼情況，並為它們出現故障做好準備，因為沒有一種方法可以使服務器偶爾不間斷。

Google也不如您想像的那樣方便。還有其他更方便的站點。 Google遠非如此，當您對他們的隨機帳戶被暫停和終止而無任何響應（除非您對Google Twitter帳戶引起足夠的關注或以1億美元或更高的價格起訴他們）時，他們就利用了您，將您搞砸了，並且迫使您尖叫到枕頭上，沒人能聽到您的尖叫聲以尋求幫助。

###為什麼重要，反正為時已晚

這是一個不太常見的論點，但需要解釋。在目前的狀態下，大多數世界各國政府以及幾家實力雄厚的公司似乎都知道您的一舉一動，那麼，為什麼還要為此而煩惱呢？答案很簡單：**您應該得到更好的**。如果此時您設法遠離他們，那麼他們就很難進一步追踪您的舉動，並且您可以建立一種新的更加私密的生活。

[1個來源]（https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/）順便說一句，每當我獲得這個帖子超過一周的時間，我都會給我免費的Reddit獎。現在（連同我所有的500個免費硬幣）進一步推動這個話題。到目前為止，我已為該帖子提供了14多個免費獎項。數量不多，但細小的事情會產生很大的影響，這取決於它的感知方式和對象。

＃＃＃ 其他

我目前沒有其他論點。

_此列表不完整_

***

##來源

複製：

[G]（https://en.wikipedia.org/wiki/Criticism_of_Google）[o]（https://en.wikipedia.org/wiki/PRISM_（surveillance_program））[o]（https：//www.reddit .com / r / degoogle /）[g]（https://www.wired.com/2012/06/opinion-google-is-evil/）[l]（https://securitygladiators.com/chrome-privacy -bad /）[e]（https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/）[h]（https：// www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy）[a]（https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1）[a]（https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html）[v]（https：//www.huffpost .com / entry / why-googles-spying-on-use_b_3530296）[e]（https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ）[r]（https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data）[y]（https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html）[v]（https：// protonmail。 com / blog / google-privacy-problem /）[e]（https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /）[r]（https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy）[y]（https://en.wikipedia.org/wiki/Nothing_to_hide_argument#批評）[b]（https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/）[a]（https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /）[d]（https://www.cnet.com/how-to/google-collects-a-frightening-amount-of-關於您的數據可以找到並刪除，現在/）[r]（https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501）[e]（https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -and）[c]（https://www.wired.com/story/google-tracks-you -privacy /）[o]（https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy）[r]（https： //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H）[w]（https://www.wired.com/story/health-fitness-data-privacy/）[h]（https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks）[e]（https://mashable.com/article/google-android-data-collection-study/）[n]（https：// www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html）[i]（https://www.maketecheasier.com/studyandroid-data-google-ios-apple/）[t]（https://www.washingtonpost.com/technology/2019/07/23 / never-googlers-web-users-take-ultimate-step-guard-their-data /）[c]（https://www.cnn.com/2019/11/12/business/google-project-nightingale- ascension / index.html）[o]（https://en.wikipedia.org/wiki/2018_Google_data_breach）[m]（https://moz.com/blog/where-does-google-draw-the-data-收集行）[e]（https://mashable.com/article/google-android-data-collection-study/）[s]（https://eandt.theiet.org/content/articles/2020/06 / google-sued-over-data-collection-from-users-in-incognito-mode /）[t]（https://www.nytimes.com/2019/01/21/technology/google-europe-gdpr- fine.html）[o]（https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data-claims-on-behalf-of-5-million-iphone-用戶）[u]（https://time.com/23782/google-flu-trends-big-data-problems/）[s]（https://www.reuters.com/article/dataprivacy-googleyoutube-kidsdata -idUSL1N2J306W）[e]（https://www.adweek.com/performan ce-marketing / google-is-collecting-your-data-even-when-your-phone-isnt-in-in-use /）[r]（https://www.computerworld.com/article/2914838/project-fi -will-help-google-amass-even-more-data-about-you.html）[p]（https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs -consented-to-data-collection /）[r]（https://arstechnica.com/information-technology/2014/01/what-google-can-really-do-with-nest-or-really-nests-數據/)[i](https://www.cbsnews.com/news/google-education-spies-on-collects-data-on-millions-of-kids-alleges-lawsuit-new-mexico-attorney-general /)[v](https://www.nationalreview.com/2018/04/the-student-data-mining-scandal-under-our-noses/)[a](https://www.wired.com / insights / 2012/10 / google-opt-out /）[c]（https://www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html）[y]（ https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550)[.](https://medium.com/digitalprivacywise/why-you -應該停止使用Google-chrome-6c934c9 a827c）

其他來源：

[五隻眼睛聯盟]（https://en.wikipedia.org/wiki/Five_Eyes）[十四十四]（https://en.wikipedia.org/wiki/十九四十四）

***

##下載鏈接

[獲取Firefox]（https://www.mozilla.org/zh-CN/firefox/new/）[獲取Tor瀏覽器]（https://www.torproject.org/download/）[其他/不可用]（https ：//www.example.com）

***

##我的脫膠經驗

我終於在2018年開始看到大型技術存在的問題，並且我開始取消定位。在最初的幾個月中，我取得了長足的進步。從那以後，它大大放慢了速度。


###我從何而來

Google Chrome-> Firefox / Tor

Google搜索-> DuckDuckGo（默認）/ Ecosia（我感覺到）/ Bing（很少）

GMail-ProtonMail（尚未完全切換）

Google協作平台->自託管（尚未完全切換）

Google+->很少使用，由於自身關閉而被刪除

Google文檔->從未使用過，我只使用Microsoft Word 2013（在2019年之前）和LibreOffice（從2019年開始）。

Google表格->從未使用過，我只使用Microsoft Excel 2013（在2019年之前）和LibreOffice（從2019年開始）。

Google幻燈片->從未使用過，我只使用Microsoft PowerPoint 2013（在2019年之前）和LibreOffice（從2019年開始）。

Google繪圖->從未使用過，我只是使用LibreOffice（從2019年開始）而已。

Gerrit->從來沒有用過，我只使用GitHub（當前默認設置），GitLab，BitBucket和SourceForge。

Google相冊->從未使用

Google雲端硬盤-> OneDrive（2019-2020）Degoo（2020-2020）pCloud（2020年至今）

Google Maps-> OpenStreetMaps / Apple Maps

Go-進行特殊處理，但不用作功能性編程語言

Dart-產生特殊異常，但不用作功能性編程語言

Flutter-產生特殊異常，但不用作功能編程語言

Google地球-> OpenStreetMaps / Apple Maps

Google Streetview->從未使用過，我覺得它特別令人毛骨悚然

Google Fi->從未使用

Google日曆->從未使用

Google計算器->從字面上看，其他任何計算器應用程序，甚至我認為都可以在Python模式下運行的Linux終端

Google Nest->從未使用

Google AMP->從未使用

Google VPN->從未使用過，也是矛盾的

Google Pay->從未使用

Google Summer of Code->從未參加

Tenor->其他GIF站點，儘管GIF對我來說不太重要。我通常從DuckDuckGo圖像，Imgur，Reddit或其他站點獲取GIF文件。

塊狀->不再使用，不確定是否Scratch直接塊狀運行。我從2017年開始成為函數程序員，從Scratch成長而來。

GBoard->使用一次，但被廢棄

Google眼鏡->從未使用過，被認為是一個小孩子，但是如果我可以選擇的話，決定不買一個/用一個

_列表可能不完整。

###我仍然無法擺脫的產品

自2021年2月25日起，以下這些Google產品使我無法完全取消使用Google搜索：

1. YouTube

2. Android

3. Google Play商店

4. GMail（僅適用於學校和某些網站）

5. Google課堂（僅適用於學校）

6. Google Translate

7. Google帳戶

8. Google協作平台（由於Google違反了GDPR的法律（在將其解決之前，可能會面臨另外的5,000,000.00歐元的罰款），並禁止下載該產品）

我已經從其他一切中脫穎而出。

***

##走是邪惡的

Google用其編程語言“ Go”（從6年後的2009年開始）改用了2003年基於Agent的編程語言“ Go！”，並聲稱他們的語言完全不會影響其他語言。谷歌為此受到了嚴厲的批評，因為當時他們的“不要作惡”的座右銘仍然很活躍，這是使“不要作惡”的座右銘退休的眾多事件之一。

最後，“ Go！”的開發停止了，而“ Go”變得越來越普遍。 Google聲稱他們不會涉足Go !，但是最終他們做到了，他們就放棄了（截至2021年4月9日）

[在此處閱讀有關Go的更多信息以及替代方法]（https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go）

***

## DRM的用法

Google通過其WideVine DRM“服務”和其他形式使用DRM（數字限制管理）。 DRM的目標是破壞開放的Internet，並賦予公司對用戶的壟斷權。無論成本如何，您都應該完全擺脫WideVine。

[在此處閱讀有關WideVine及其問題的更多信息]（https://github.com/Degoogle-your-life/Its-time-to-cut-WideVine-DRM）

***

##常見誤解

這是對Google產品的一些常見誤解的列表。

### Google不是互聯網

Google / Google搜索不是互聯網，Google搜索只是一個搜索引擎，就像不是Nintendo平台上的每款遊戲都不是Nintendo製作的，而是Nintendo許可的，但程度更大。如果現在要同時銷毀所有Google服務器，那麼只有YouTube，Gmail，Google Docs，Google搜索等Google站點會消失，但是大部分Internet仍然存在（Wikipedia，Stackoverflow，GitHub， Microsoft的所有網站，NYTimes，三星，TikTok等），它們可能會失去其Google登錄和分析功能，但它們仍然可以正常工作（除非它們的程序設計不佳且直接依賴於Google）

***

## Internet Explorer 6和Chrome

谷歌瀏覽器正在成為新的Internet Explorer6。當谷歌瀏覽器最初問世時，Firefox是占主導地位的瀏覽器，當谷歌瀏覽器出現時，它主要扼殺了Internet Explorer的市場份額（在數以百萬計的人切換到Firefox和其他瀏覽器之前，該市場份額已超過96％）。出來之後，人們由於它的速度和它的速度而被Google所取代（當時還不認為它是邪惡的，因為大多數隱私問題尚未揭曉），谷歌瀏覽器最初尊重網絡標準（這是Firefox所做的）導致Internet Explorer失去了96％的瀏覽器市場份額），但是，隨著Google Chrome瀏覽器市場份額的上升，Google開始刪除越來越多的功能，添加了更多的間諜軟件，並停止接受網絡標準，Google Chrome已成為新的Internet Explorer 6。

目前的主要問題是僅使用Chrome的網站，並且無法在其他瀏覽器上運行，因為開發人員認為他們不希望其他30-40％的不使用Chrome的互聯網用戶使用他們的網站。

甚至Google本身也只將自己的網站設置為Chrome。例如，如果Google搜索檢測到您未使用Google Chrome（即使其他基於Chromium的瀏覽器，例如Br​​ave也會受到影響），並且Google Earth不允許Firefox用戶訪問，則每10秒會提示您下載Chrome 3次。使用他們的網站（截至2020年），並且Google Translate不支持Firefox和其他非Google Chrome瀏覽器上的語音輸入。

###勇敢的問題

其他基於Chromium的瀏覽器（例如​​Brave和Microsoft Edge）並非完全沒有Google間諜軟件。隱私社區的另一端通常建議使用“勇敢”，但“勇敢”仍是一個問題，因為它使用Chromium。互聯網不應僅由Chromium瀏覽器組成，應該有多種選擇。勇敢是錯誤的路要走。

[在此處閱讀有關從Google Chrome / Chromium進行信息刪除的更多信息]（https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome）

[在此處詳細了解有關從ChromeOS / ChromiumOS（Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC）取消搜索的信息]（https://github.com/Degoogle-your-life/Stop-using-Chromebooks）

***

##偽造的隱私續約

在為時已晚之後，Google一直在試圖向世界表明他們關心隱私。他們繼續聲稱自己尊重用戶隱私，但仍未解決所有隱私問題。

###開源不能部分

開源不能是局部的。 Google證明了這一點。源代碼的每一位和每一字節都必須是公眾可見的，甚至不能隱藏八分之一字節。

像Android和ChromeOS這樣的項目是部分開源的，但是包含大多數專有的間諜軟件元素。

### Oxymoron

Google VPN是正矛盾。 Google並不關心隱私，像這樣的公司提供的虛擬專用網（VPN）將是VPN服務最糟糕的選擇之一。

***

##表現不佳

Google不在乎產品至少在2017年之前的性能，因為其最新的基準測試軟件（Google Octane）已於2017年停產。

***

##錯誤的項目管理

Google的內部項目管理系統非常糟糕。越來越被降級的程序的一些常見示例包括Google Duo和YouTube音樂（以前稱為Google Play音樂）

在Google的內部開發系統中，一個應用程序引向另一個具有一半功能的應用程序，然後原始應用程序被刪除。幾年後，製作了功能減少了75％的新應用，然後刪除了功能減少了50％的應用，隨後又創建了具有87.5％的功能的新應用，然後停用了功能減少了75％的應用， 等等。

***

##糟糕或無節制的服務

YouTube是不良節制世界中最常見的示例，它創造了最糟糕的平台。 Google似乎也沒有發現YouTube不是YouTube的孩子。

對於YouTube，向用戶投放可憎的親納粹和白人至上主義者的內容是為了給用戶更多的參與時間和更多的錢。 Google在節制方面也做了一些非常愚蠢的事情，例如，批准將Christian Anal Sex視頻作為“為孩子製作的”內容，同時限制了該視頻的年齡。在“小鯊魚”視頻下面加上色情廣告或血腥廣告，以及其他各種“為孩子製作”的內容，也很常見。

YouTube用戶經常抱怨YouTube對不良內容的管理不善（例如上面列出的示例），而用戶卻可以無緣無故地無緣無故地刪除自己的視頻，並且會因任何形式的咒罵而受到懲罰，由於這些不平等的懲罰，即使是很小的情況，例如說“廢話”的用戶，通常在斯大林時代也將YouTube與[Soviet Union]（https://en.wikipedia.org/wiki/Soviet_Union）進行比較。

2021年，Google宣布儘管視頻已被取消（儘管Google賺錢，但創作者沒有），但他們仍將在所有視頻上投放廣告，這與節制並不過分，但這很重要。

YouTube處於受監管的狀態（儘管效果很差），但是，使他們賺錢最多的Google廣告服務似乎很少或沒有節制。

[閱讀有關YouTube審核問題以及如何從YouTube替代的更多信息]（https://github.com/seanpm2001/Alternating-from-YouTube）

Google Play的廣告是從漫遊器農場中產生的，您可以通過數百家公司使用相同的廣告場景進行幾乎沒有變化但與產品沒有任何關係的廣告來判斷（常見示例：Playrix（居家風光，Gardenscapes）Fishdom，黑手黨城和數以千計的廣告）以及日益猖malicious的惡意廣告趨勢，聲稱用戶可以通過玩遊戲，聽音樂等來賺錢。PayPal沒有對此發表評論，但是很明顯，這是一個騙局，就好像您可以賺錢一樣。通過保證玩的遊戲，在不到20秒的時間內超過了10,000美元，沒人會去做，而是會去做，這是不可能的，並且企業也無法像這樣工作。自2019年以來，這種明顯的騙局一直在變得越來越強大，現在製作這些廣告的機器人農場正在各自的廣告中相互搏鬥。

幾則廣告也非常誘人，並試圖吸引用戶（其中大多數是13歲以下的用戶或漫遊器）通過性操作進行點擊。

許多應用使用機器人並對其產品進行草皮處理，因此，每當進行不良評論時，襪子木偶機器人帳戶就會開始發布5星評論，並試圖消除您的批評。 [Google也在自己做這件事]（＃Astroturfing）

[閱讀有關Google AdSense問題的更多信息]（https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense）

***

##草皮

通用定義[（來自Wikipedia）]（https://en.wikipedia.org/wiki/Astroturfing）

```
塗草皮是一種掩蓋消息或組織（例如政治，廣告，宗教或公共關係）贊助者的做法，以使其看起來好像是來自基層參與者並受到其支持。這種做法旨在通過隱瞞有關來源的財務聯繫的信息來使聲明或組織具有信譽。術語“草皮草料”源自AstroTurf，這是一種合成地毯的品牌，旨在模仿天然草，用作“草根”一詞的玩法。使用該術語的含義是，所支持的活動不是“真實的”或“自然的”草根努力，而是“假的”或“人為的”支持。
```

Google一直在進行草皮整理，以使其看起來沒有做任何壞事（在此過程中，草皮整理是惡作劇），例如，在諸如Twitter之類的平台（他們有一個帳戶）上對Google進行欺詐，將導致存在多個帳戶一段時間，但從未發布過，然後才聲稱您所說的是假的，然後聲稱Google是最好的公司，但這樣做的方式對於大多數人來說似乎不是機器人。

***

##非法和不道德的商業行為

Google使用非法和不道德的商業慣例來進一步擴大其壟斷地位，例如利用避稅天堂，外包工作以及繼續從事非法侵入性活動作為經營成本。

＃＃＃ 在歐洲

歐洲經常起訴Google，最大的訴訟是針對Android中的非法行為，這導致Google收到5,000,000,000歐元（相當於2021年4月9日的5,947,083,703.68美元）

###在北美

與歐洲的50億歐元罰款相比，美國尚未向Google支付足夠的罰款。

###爭議

Google只會在引起爭議之前才關心問題，然後他們會做出糟糕的嘗試來解決它，足以使爭議暫時消失，然後問題成倍地惡化，直到引發另一個爭議為止，並且週期繼續。他們根本不在乎做任何認真的事情。

***

## Google是自動化的

作為一家公司，Google大多是自動化的，其自動化程度要低於自動化。

公司不應該完全自動化。谷歌就是一個例子。僅由AI進行審核是很可怕的，YouTube就是一個很好的例子，即使有很少（數百甚至一千）的人對網站進行審核，這顯然很糟糕，以至於大多數人在工作時都必須接受治療。

***

＃＃ 安卓

Android由Google擁有。開放手機聯盟（自Android以來一直未開放）的一部分，Android已成為Google的另一個壟斷點，並且是一個很難擺脫的壟斷點。

據報導，Android每天至少會向Google打電話10次，儘管它是部分開源的，但它仍在充當間諜軟件。

已經創建了多個項目來替代Android，但需要使您的設備生根。由於Knox DRM，對於美國的特定三星手機而言，這根本不可能了。 Android的常見替代產品包括iOS，iPadOS，LineageOS，Android x86，Ubuntu Touch和PiPhone（Pi Phone是在移動設備上運行各種Linux系統的手機，例如Fedora，Ubuntu，Arch等）。

[請參閱我對獲得脫谷歌的Android虛擬機功能的研究]（https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research）

[查看如何從Android解Google]（https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android）

***

##可以幫助的小動作

盡一切可能傳播意識很重要。對我來說，我不僅經常談論脫膠和寫文章，而且還有一個小習慣，我每天都會將免費的Reddit獎授予r / degoogle上的固定帖子，以提高知名度。到目前為止，我已將近30個獎項授予了該固定帖子（為此帖子我還花了500枚免費硬幣用於10個獎項）

***

##不可信

Google無法被信任，也永遠不會再被信任。他們已經完全從“別作惡”（他們總是作惡）轉變為完全作惡而不是試圖隱藏它。

***

##其他要檢查的東西

[Google Graveyard（killedbygoogle.com）-Google殺死了224種以上產品的排序列表]（https://killedbygoogle.com/）

> [GitHub鏈接]（https://github.com/codyogden/killedbygoogle）

[字母工會-Google的新工會有800多名成員]（https://alphabetworkersunion.org/people/our-union/）

[不想與恐龍復活節彩蛋分開嗎？該網站覆蓋了您] [https://chromedino.com/）

還有其他替代品，只需搜索它們即可。

***

本文需要進行一些事實檢查

***

##文件信息

文件類型：`Markdown（* .md）`

行數（包括空行和編譯器行）：968

文件版本：`6（2021年4月18日，星期日，下午4:29）`

***

###軟件狀態

我所有的作品都是免費的，有一些限制。我的任何作品中都沒有DRM（** D **原始** R **限制** M **管理）。

！[DRM-free_label.en.svg]（DRM-free_label.en.svg）

此標籤由自由軟件基金會支持。我從不打算在自己的作品中加入DRM。

我使用的縮寫是“數字限制管理”，而不是更廣為人知的“數字權限管理”，因為解決它的常見方法是錯誤的，DRM沒有權限。 [Richard M. Stallman（RMS）]（https://en.wikipedia.org/wiki/Richard_Stallman）和[Free Software Foundation（FSF）]支持拼寫“數字限制管理”， https://zh.wikipedia.org/wiki/Free_Software_Foundation）

本部分用於提高對DRM問題的認識，並進行抗議。 DRM有缺陷通過設計，是對所有計算機用戶和軟件自由的重大威脅。

圖片來源：[defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label）

***

##贊助商信息

！[SponsorButton.png]（SponsorButton.png）<-不要單擊此按鈕，它不起作用，它只是一張圖像。實按鈕位於頁面右上角（<-L ** R **->）的頂部

您可以根據需要贊助此項目，但請指定您要捐贈的內容。 [在這裡查看您可以捐贈的資金]（https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors）

您可以在此處查看其他贊助商信息（https://github.com/seanpm2001/Sponsor-info/）

試試看！贊助商按鈕在觀看/取消觀看按鈕旁邊。

***

##文件歷史

版本1（2021年2月19日，星期五，下午5:20）

>變更：

> *開始文件

> *添加了基本描述部分

> *添加了存儲庫描述部分

> *添加了文章列表，其中有14個條目

>> *添加了“相關文章”部分

>> *添加了“另請參見”部分

> *添加了文件信息部分

> *添加了文件歷史記錄部分

> *添加了頁腳

> *版本1中沒有其他更改

版本2（2021年2月19日，星期五，下午5:26）

>變更：

> *添加了翻譯狀態部分

> *添加了“其他要檢查的內容”部分

> *添加了“隱私”部分

> *添加了索引

> *添加了軟件狀態小節

> *添加了其他反Google廣告系列部分

>> *添加了已失效的小節

>> *添加了正在進行的小節

> *添加了源代碼部分

> *添加了下載鏈接部分

> *更新了文件信息部分

> *更新了文件歷史記錄部分

> *版本2中沒有其他更改

版本3（2021年2月24日，星期三，晚上7:56）

>變更：

> *更新了索引

> *引用了degoogle圖標和新的GitHub組織

> *添加了指向較新文章的鏈接

> *添加了反其他參數部分

>> *添加了便利性小節

>> *添加了“為什麼還要打擾”小節

>> *添加了其他小節

> *更新了一些數據

> *更新了文件信息部分

> *更新了文件歷史記錄部分

> *版本3中沒有其他更改

版本4（2021年2月25日，星期四，9：31 pm）

>變更：

> *添加了10篇新文章的鏈接

> *添加了有關我的經驗消除的部分

> *更新了索引

> *更新了文件信息部分

> *更新了文件歷史記錄部分

> *版本4中沒有其他更改

第5版（2021年4月9日，星期五，下午6:02）

_最近我一直缺乏反Google運動的更新，我正努力在中斷1個月後恢復使用它。_

>變更：

> *更新了標題部分

> *更新了索引

> *更新了語言列表：修復了鏈接，並添加了更多受支持的語言

> *更新了文章狀態部分，添加了4個fork鏈接

> *更新了軟件狀態部分

> *添加了圍棋是邪惡的部分

> *添加了“ DRM的用法”部分

> *添加了常見的誤解部分

>> * *添加了Google不是Internet小節

> *添加了Internet Explorer 6和Chrome部分

>> *添加了“勇敢的問題”小節

> *添加了偽造的隱私刪除

> *添加了“開源不能部分劃分”部分

> *添加了Oxymoron小節

> *添加了不良表現部分

> *添加了不良項目管理部分

> *添加了可怕或無節制的服務部分

> *添加了Astroturfing部分

> *添加了非法和不道德的商業行為部分

> *添加了“歐洲”小節

>> *添加了“北美地區”小節

>> *添加了“爭議”小節

> *添加了Google自動化部分

> *添加了Android部分

> *添加了“小操作幫助”部分

> *添加了“不可信任”部分

> *添加了贊助商信息部分

> *更新了頁腳

> *更新了文件信息部分

> *更新了文件歷史記錄部分

> *版本5中沒有其他更改

版本6（2021年4月18日，星期日，下午4:29）

>變更：

> *更新了索引

> *添加了新的概述說明

> *更新了文章狀態信息

> *為新的Google FLoC文章添加了鏈接

> *為Wuest 3n Fuchs Degoogle文章及其一般信息添加了鏈接

> *更新了文件信息部分

> *更新了文件歷史記錄部分

> *版本6中沒有其他更改

版本7（即將推出）

>變更：

> *即將推出

> *版本7中沒有其他更改

版本8（即將推出）

>變更：

> *即將推出

> *版本8中沒有其他更改

版本9（即將推出）

>變更：

> *即將推出

> *版本9中沒有其他更改

版本10（即將推出）

>變更：

> *即將推出

> *版本10中沒有其他更改

版本11（即將推出）

>變更：

> *即將推出

> *版本11中沒有其他更改

版本12（即將推出）

>變更：

> *即將推出

> *版本12中沒有其他更改

***

##頁腳

你有每個文件的結尾

（[返回頁首]（＃Top）| [返回GitHub]（https://github.com））

### EOF

***
