***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle igbesi aye rẹ

Eyi ni akọọlẹ degoogling akọkọ fun alaye degoogling gbogbogbo ati ọna asopọ si awọn nkan miiran.

[Wo atokọ bi agbari GitHub] (https://github.com/Degoogle-your-life)

***

_ Ka nkan yii ni ede miiran: _

** Ede lọwọlọwọ jẹ: ** “Gẹẹsi (AMẸRIKA)“ _ (awọn itumọ le nilo atunṣe lati ṣatunṣe Gẹẹsi ti o rọpo ede to tọ) _

_🌐 Akojọ awọn ede_

** A to lẹsẹsẹ nipasẹ: ** `A-Z`

[Awọn aṣayan tito lẹtọ ko si] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanian | [am English] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) Arabic | [hy հայերեն] (/. github / README_HY.md) Armenian | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijani | [eu Euskara] (/. github /README_EU.md) Basque | [jẹ Беларуская] (/. Github / README_BE.md) Belarus | | bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnian | [bg български] (/. Github / README_BG.md) Bulgarian | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Ṣaina (Irọrun) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Ara Ṣaina (Ibile) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Croatian | [cs čeština] (/. Github / README_CS .md) Czech | [da dansk] (README_DA.md) Danish | [nl Nederlands] (/. github / README_ NL.md) Dutch | [** en-us Gẹẹsi **] (/. github / README.md) Gẹẹsi | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonia | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finnish | [fr Français] (/. github / README_FR.md) Faranse | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galician | [ka ქართველი] (/. github / README_KA) Georgian | [de Deutsch] (/. github / README_DE.md) Jẹmánì | [el Ελληνικά] (/. github / README_EL.md) Giriki | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Ilu Hawahi | [oun עִברִית] (/. github / README_HE.md) Heberu | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ara Ilu Hungary | [jẹ Íslenska] (/. github / README_IS.md) Icelandic | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Icelandic | [ga Gaeilge] (/. github / README_GA.md) Irish | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Ara ilu Japanese | [jw Wong jawa] (/. github / README_JW.md) Javanese | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-guusu 韓國 語] (/. github / README_KO_SOUTH.md) Korean (Guusu) | [ko-north문화어] [ku Kurdî] (/. github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kyrgyz | [wo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lithuanian | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxembourgish | [mk Македонски] (/. github / README_MK.md) Macedonian | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [milimita മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Ilu Malta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolian | [mi မြန်မာ] (/. github / README_MY.md) Mianma (Burmese) | [ne नेपाली] (/. github / README_NE.md) Nepali | [ko si norsk] (/. github / README_NO.md) Norwegian | [tabi ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persia [pl polski] (/. github / README_PL.md) Polandii | [pt português] (/. github / README_PT.md) Ilu Pọtugalii | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Ko si awọn ede ti o wa ti o bẹrẹ pẹlu lẹta Q | [ro Română] (/. github / README_RO.md) Romanian | [ru русский] (/. github / README_RU.md) Russian | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scots Gaelic | [sr Српски] (/. github / README_SR.md) Ara Ilu Serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovak | [sl Slovenščina] (/. github / README_SL.md) Ara Slovenia | [nitorina Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Ede Sipeeni | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [SV Svenska] (/. github / README_SV.md) Swedish | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Tọki | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ti Ukarain | [ur]] / / github / README_UR.md) Ilu Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnam | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | { ) / README.md))

Awọn itumọ ni awọn ede miiran yatọ si Gẹẹsi jẹ itumọ ẹrọ ati pe ko iti pe. Ko si awọn aṣiṣe ti o wa titi sibẹsibẹ ti Oṣu Karun ọjọ karun 2021. Jọwọ jọwọ ṣabọ awọn aṣiṣe itumọ [nibi] (https://github.com/seanpm2001/Degoogle-your-life/issues/) rii daju lati ṣe afẹyinti atunṣe rẹ pẹlu awọn orisun ati itọsọna mi , nitori Emi ko mọ awọn ede miiran yatọ si Gẹẹsi daradara (Mo gbero lati ni onitumọ nikẹhin) jọwọ tọka [wiktionary] (https://en.wiktionary.org) ati awọn orisun miiran ninu ijabọ rẹ. Ti o ba kuna lati ṣe bẹ yoo jẹ ki ijusile ti atunṣe ti n gbejade.

Akiyesi: nitori awọn idiwọn pẹlu itumọ GitHub ti markdown (ati pupọ julọ gbogbo itumọ orisun wẹẹbu miiran ti markdown) tite awọn ọna asopọ wọnyi yoo ṣe atunṣe ọ si faili ọtọtọ lori oju-iwe ọtọ ti kii ṣe oju-iwe profaili GitHub mi. A o darí rẹ si ibi ipamọ [seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), nibiti a ti gbalejo README naa.

Ti ṣe awọn itumọ pẹlu Google Translate nitori opin tabi ko si atilẹyin fun awọn ede ti Mo nilo ninu awọn iṣẹ itumọ miiran bi DeepL ati Bọtini Bing (ẹlẹya ẹlẹwa fun ipolongo Google-anti-Google) Mo n ṣiṣẹ lori wiwa yiyan. Fun idi diẹ, kika (awọn ọna asopọ, awọn pinpin, igboya, awọn italisi, ati bẹbẹ lọ) jẹ idotin ni awọn itumọ oriṣiriṣi. O jẹ ohun ti o nira lati ṣatunṣe, ati pe emi ko mọ bi a ṣe le ṣatunṣe awọn ọran wọnyi ni awọn ede pẹlu awọn ohun kikọ ti kii ṣe latin, ati sọtun si awọn ede apa osi (bii Arabic) nilo iranlọwọ afikun ni titọ awọn ọrọ wọnyi

Nitori awọn ọran itọju, ọpọlọpọ awọn itumọ ti wa ni ọjọ ati lo ẹya ti igba atijọ ti faili nkan “README` yii. O nilo onitumọ kan. Pẹlupẹlu, bii Oṣu Kẹrin Ọjọ 9th 2021, yoo gba mi ni igba diẹ lati gba gbogbo awọn ọna asopọ tuntun ṣiṣẹ.

***

Atọka ##

[00.0 - Akọle] (# Degoogling --- Degoogle-your-life)

> [00.1 - Atọka] (# Atọka)

[01.0 - Apejuwe ipilẹ] (# Apejuwe ipilẹ)

> [01.1 - Akọsori ibi ipamọ] (# Degoogle-your-life)

> [01.2 - Akopọ apejuwe Wuest3NFuchs] (# Akopọ-nipasẹ-Wuest3nFuchs)

>> [01.2.1 - Kini o tumọ si?] (# Kini-o-tumọ si - nipasẹ-Wuest3nFuchs)

>> [01.2.2 - Kilode ti Degoogle?] (# Why-Degoogle - by-Wuest3nFuchs)

[02.0 - Awọn nkan] (# Awọn nkan)

[03.0 - Asiri] (# Asiri)

[04.0 - Awọn ipolongo miiran ti o lodi si Google] (# Awọn ipolongo miiran-egboogi-Google-ipolongo)

> [04.0.1 - Defunct] (# Iṣẹ)

> [04.0.2 - Ti nlọ lọwọ] (# Ti nlọ lọwọ)

[05.0 - Iṣiro awọn ariyanjiyan miiran] (# Awọn ariyanjiyan miiran-awọn ariyanjiyan)

> [05.0.1 - Irọrun] (# Irọrun)

> [05.0.2 - Kini idi ti o ṣe pataki? O ti pẹ ju lọnakọna] (# Kini idi-o-ṣe-ọrọ, -its-too-pẹ-ni gbogbo ọna)

> [05.0.3 - Omiiran] (# Omiiran)

[06.0 - Awọn orisun] (# Awọn orisun)

[07.0 - Ṣe igbasilẹ awọn ọna asopọ] (# Awọn ọna asopọ Gbigba lati ayelujara)

[08.0 - Ìrírí mi tí n dẹkun]

> [08.1 - Ohun ti Mo yipada lati] (# Kini-MO-yipada-lati)

> [08.2 - Awọn ọja ti Emi ko tun le lọ kuro] (# Awọn ọja-Emi-ko-le-kuro-kuro)

[09.0 - Awọn nkan miiran lati ṣayẹwo] (# Awọn ohun miiran-lati-ṣayẹwo)

[10.0 - Alaye faili] (# Alaye-faili)

> [10.1 - Ipo sọfitiwia] (# Ipo sọfitiwia)

> [10.2 - Alaye Onigbowo] (# Alaye Onigbowo)

[11.0 - Itan faili] (# Itan-faili)

[12.0 - Ẹlẹsẹ] (# Ẹlẹsẹ)

***

## Apejuwe ipilẹ

[Lati Wikipedia: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

Igbimọ DeGoogle (eyiti a tun pe ni de-Google ronu) jẹ ipolongo koriko ti o ti wa bi awọn ajafitafita aṣiri n rọ awọn olumulo lati da lilo awọn ọja Google duro patapata nitori awọn ifiyesi aṣiri nipa idagbasoke nipa ile-iṣẹ naa. Oro naa n tọka si iṣe yiyọ Google kuro ninu igbesi aye ẹnikan. Bii ipin ọja ti ndagba ti omiran intanẹẹti ṣẹda agbara anikanjọpọn fun ile-iṣẹ ni awọn aye oni-nọmba, awọn nọmba ti npọ si ti awọn onise iroyin ti ṣe akiyesi iṣoro lati wa awọn omiiran si awọn ọja ile-iṣẹ naa.

** Itan **

Ni ọdun 2013, John Koetsier ti Venturebeat sọ pe tabulẹti orisun Kindu Fire ti Amazon jẹ “ẹya de-Google-ized ti Android.” Ni ọdun 2014 John Simpson ti US News kowe nipa “ẹtọ lati gbagbe” nipasẹ Google ati awọn ẹrọ iṣawari miiran. Ni ọdun 2015, Derek Scally ti Irish Times kọ nkan kan lori bii o ṣe le "De-Google igbesi aye rẹ." Ni ọdun 2016 Kris Carlon ti Android Alaṣẹ daba pe awọn olumulo ti CyanogenMod 14 le “de-Google” awọn foonu wọn, nitori CyanogenMod n ṣiṣẹ daradara laisi awọn ohun elo Google paapaa. Ni ọdun 2018 Nick Lucchesi ti Inverse kọwe nipa bii ProtonMail ṣe n ṣe igbega bi o ṣe le “ni anfani lati de-Google-fy igbesi aye rẹ patapata.” Lifehacker's Brendan Hesse kọ ikẹkọ ti alaye lori “fifi Google silẹ.” Oniroyin Gizmodo Kashmir Hill sọ pe o padanu awọn ipade ati pe o ni awọn iṣoro ṣeto awọn ipade laisi lilo Kalẹnda Google. Ni ọdun 2019, Huawei funni ni agbapada si awọn oniwun foonu ni Philippines ti o wa ni idiwọ lati lilo awọn iṣẹ ti Google pese nitori awọn ọna miiran diẹ lo wa pe isansa awọn ọja ile-iṣẹ ṣe intanẹẹti deede ti ko ṣee ṣe.

***

# Degoogle-igbesi aye rẹ
Ibi-ipamọ fun alaye degoogling gbogbogbo ati awọn asopọ si awọn ibi ipamọ degoogling mi miiran.

***

## Akopọ nipasẹ Wuest3nFuchs

Apejuwe ti o dara julọ, ti a pese nipasẹ [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - orisun: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Kini o je? nipasẹ Wuest3nFuchs

Degoogling tumọ si lati da lilo ohunkohun ti o jẹ ti Google, ohunkohun ti o ṣe nipasẹ Google. Mo n sọrọ nipa ẹrọ wiwa wọn, iṣẹ ifiweranṣẹ wọn (Gmail), Youtube, abbl.

### Kini idi ti Degoogle? nipasẹ Wuest3nFuchs

Google jẹ ọkan ninu awọn ile-iṣẹ ti o lagbara julọ ni agbaye ni bayi. Wọn ti tọju iye ti alaye nla lori gbogbo wa. Diẹ ninu yoo jiyan pe alaye wa ni ailewu pẹlu wọn nitori wọn mọ bi wọn ṣe le daabobo. Ṣugbọn eyi kii ṣe otitọ. Ti wọ inu Google ṣaaju ki o to yoo wọ inu rẹ ni ọjọ iwaju. Boya kii ṣe nipasẹ iwe afọwọkọ kiddie ṣugbọn o yoo ṣee ṣe nipasẹ ilu orilẹ-ede kan. Google ṣe ifitonileti ti ara ẹni lori gbogbo wa nitori eyi ni bi wọn ṣe ṣe owo.

Wọn ṣayẹwo awọn imeeli wa, tọju ohun ti a wa nigba ti a nlo ẹrọ wiwa wọn, kini awọn fidio ti a wo lori Youtube. Eyi ni bii wọn ṣe fojusi wa ati kọ profaili lori wa lati fihan wa diẹ ninu ipolowo ti o da lori ohun ti a sọrọ nipa pẹlu ọrẹ wa to dara julọ ki wọn le fi ipolowo kan han wa fun nkan ti a nilo, ṣugbọn eyi jẹ ohun ti irako ju. O ṣeun fun Ọgbẹni Snowden a mọ nisisiyi pe Google ti pin alaye ti ara ẹni wa pẹlu NSA labẹ eto ti a pe ni ** "PRISM" **.


Ni ọjọ iwaju ẹnikan yoo ni agbara lati wọle si gbogbo alaye yẹn ati pe Mo da ọ loju pe ohunkan ti o buru gaan yoo ṣẹlẹ. Lati yago fun iyẹn lati ṣẹlẹ, o yẹ ki o bẹrẹ Degoogling ni bayi. Bakannaa o yẹ ki o ko lo awọn ọja nipasẹ ile-iṣẹ kan ti o pin data rẹ pẹlu ** NSA **. O yẹ ki o fi iduro si gbogbo eyi nipasẹ degoogling.

** Ti awọn eniyan miiran ba le ṣe, o le ṣe pẹlu. **

[Ka diẹ sii nibi] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Ọna asopọ si orita ko si ni atokọ lọwọlọwọ, nitori Emi ko ni ibi ipamọ yii ni gbogbogbo, ati fẹ lati ṣe igbega awọn orisun miiran. Yoo jẹ amotaraeninikan lati sopọ si temi https://github.com/Degoogle-your-life/Degoogle! ->

***

## Awọn nkan

### Ipo nkan

_Gbogbo awọn nkan jẹ iṣẹ lọwọlọwọ ati nilo awọn ilọsiwaju nla. Awọn aba ati awọn atunṣe ni a gba laaye._

_Bi Oṣu Kẹrin Ọjọ 18 ọdun 2021 ni 4: 09 pm, ọpọlọpọ awọn nkan ko ti bẹrẹ sibẹsibẹ. Mo n ṣiṣẹ lori wiwa akoko ati igbiyanju lati bẹrẹ wọn._

[Kilode ti o yẹ ki o da lilo Google Chrome] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Da lilo ChromeBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Da lilo WideVine DRM duro / O to akoko lati ge WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Kilode ti o yẹ ki o da lilo ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Omiiran lati YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Duro Googling, kilode ti o yẹ ki o da lilo Wiwa Google] (https://github.com/seanpm2001/Stop-Googling-- Kini idi-you-should-stop-using-Google-Search) <! - 6! >

[Idi ti o fi yẹ ki o da lilo Gmail duro] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Idi ti o fi yẹ ki o da lilo Android] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[Kilode ti o yẹ ki o yago fun Google Amp] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Idi ti o fi yẹ ki o da lilo Google Drive duro] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Kilode ti o yẹ ki o da lilo Maps Google ati Google Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Hey Google, da duro] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Duro kika lati awọn iwe Google / Play] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Duro lilo Kilasi ti Google] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Idi ti o fi yẹ ki o da lilo Itumọ Google duro] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Idi ti o fi yẹ ki o da lilo Apamọ (Google) rẹ (] Google)oke-lilo-Awọn iroyin Google] <! - 16! ->

** Awọn nkan tuntun lati kọ laipe: **

[Idi ti o fi yẹ ki o da lilo Gerrit duro] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[Idi ti o fi yẹ ki o da lilo Awọn atupale Google duro (ibi ipamọ ti baje ni opin mi bi ti Ọjọru, Oṣu Kẹwa Ọjọ 24th 2021 ni 4: 13 pm)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Awọn atupale) <! - 18! ->

<! - Olupin iṣẹ! ->

[Idi ti o fi yẹ ki o da lilo Google AdSense duro] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[Idi ti o fi yẹ ki o da lilo Google Ọkan] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Idi ti o fi yẹ ki o da lilo Google+ (ti da)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[Idi ti o fi yẹ ki o da lilo itaja itaja Google] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[Idi ti o fi yẹ ki o da lilo Awọn iwe Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Idi ti o fi yẹ ki o da lilo Awọn Ifaworanhan Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Idi ti o fi yẹ ki o da lilo Awọn iwe Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Idi ti o fi yẹ ki o da lilo Awọn Fọọmu Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Idi ti o fi yẹ ki o da lilo Cardboard Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Kilode ti o yẹ ki o da lilo Awọn ifiranṣẹ Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Idi ti o fi yẹ ki o da lilo Apẹrẹ Ohun elo Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[Kilode ti o yẹ ki o da lilo Google Glass / Glasses] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[Idi ti o fi yẹ ki o da lilo Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[Kilode ti o yẹ ki o da lilo GBoard duro] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Idi ti o fi yẹ ki o da lilo Ile Google duro (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Idi ti o fi yẹ ki o da lilo Google itẹ-ẹiyẹ] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Idi ti o fi yẹ ki o da lilo Google Hangouts (ti da)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[Idi ti o fi yẹ ki o da lilo Google Duo duro] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Idi ti o fi yẹ ki o da lilo Tensorflow Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[Kilode ti o yẹ ki o da lilo Google Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Kilode ti o yẹ ki o da lilo Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Idi ti o fi yẹ ki o da lilo ede siseto Googles Go] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Idi ti o fi yẹ ki o da lilo ede siseto Googles Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[Kilode ti o yẹ ki o da lilo ọna kika aworan Googles WebP] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[Idi ti o fi yẹ ki o da lilo ọna kika fidio Googles WebM] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[Kilode ti o yẹ ki o da lilo Fidio Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Idi ti o fi yẹ ki o da lilo Awọn Ojula Google (Ayebaye)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Idi ti o fi yẹ ki o da lilo Awọn Ojula Google ("Titun")] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[Kilode ti o yẹ ki o da lilo lilo Google Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Idi ti o fi yẹ ki o da lilo Sanwo Android] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Idi ti o fi yẹ ki o da lilo Google VPN (oxymoron)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[Kilode ti o yẹ ki o da lilo Awọn fọto Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[Idi ti o fi yẹ ki o da lilo Kalẹnda Google duro] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Idi ti o fi yẹ ki o da lilo VirusTotal (nitori o ti jẹ ohun-ini nipasẹ Google lati Oṣu Kẹsan ọdun 2012] (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[Idi ti o fi yẹ ki o da lilo Google Fi duro] (https://github.com/seanpm2001/Why-you-should-da-lilo-Google-Fi) <! - 53! ->

[Idi ti o fi yẹ ki o da lilo Google Stadia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Idi ti o fi yẹ ki o da lilo Google Keep] duro (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Kilode ti o yẹ ki o da lilo Mimọ Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Kilode ti o yẹ ki o dawọ kopa ninu Google Summer of Code] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[Idi ti o fi yẹ ki o da lilo Kamẹra Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Idi ti o fi yẹ ki o da lilo Ẹrọ iṣiro Google (o le dabi iwọn pupọ, ṣugbọn o yẹ ki o dagoogle kuro ninu ohun gbogbo, rọrun pupọ lati yipada lati)] Ẹrọ iṣiro) <! - 59! ->

[Kini idi ti o yẹ ki o da lilo lilo iwadi Google + awọn ẹsan] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[Idi ti o fi yẹ ki o da lilo Awọn aworan Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Kilode ti o yẹ ki o da lilo Tenor (aaye GIF, ti Google ni lati ọdun 2019)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Kini FLoC - Kilode ti o yẹ ki o yago fun iṣoro FLoCing nla Googles (da lilo Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Lapapọ awọn nkan: ** `63`

** Abala [ọna opopona AB] (DegoogleCampaign_2021Roadmap_Part1.md) (titi di Oṣu Kẹta Ọjọ 12 2021) ọjọ 2 kuro ni **

** Abala [opopona opopona BB] (DegoogleCampaign_2021Roadmao_Part2.md) (to? 2021) Awọn ọjọ 2 kuro ni **

Ipo nkan

Gbogbo awọn nkan lọwọlọwọ jẹ iṣẹ ti nlọ lọwọ ati nilo awọn ilọsiwaju nla. Awọn aba ati awọn atunṣe ni a gba laaye.

** Awọn abọ **

Faagun nẹtiwọọki Degoogle mi, ati fifi diẹ ninu irọra ti iwọle sii, ati awọn itusilẹ agbegbe.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Ti beere lati: [https://github.com/wacko1805/Fossapps] [//https://github.com/wacko1805/Fossapps] (Gẹẹsi)

2. [Awọn ọna asopọ Ìpamọ] [https://github.com/Degoogle-your-life/Privacy-links] | Ti beere lati: [https://github.com/Arturro43/privacy-links] [//https://github.com/Arturro43/privacy-links] (Polish)

3. [Asiri-Asiri] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Ti beere lati: [https://github.com/LinuxCafeFederation/Delightful-Privacy] [https://github.com/LinuxCafeFederation/Delightful-Privacy] (Gẹẹsi)

4. [Awọn bulọọki] (https://github.com/Degoogle-your-life/blocklists) | Ti beere lati: [https://github.com/jmdugan/blocklists] (https://tith://github.com/jmdugan/blocklists) (Gẹẹsi)

5. [Degoogle, nipasẹ Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Ti beere lati: [https://github.com/Wuest3nFuchs/Degoogle] (https://github.com/Wuest3nFuchs/Degoogle) (Gẹẹsi)

** Jẹmọ **

[Iwadi Ẹrọ Ẹrọ Foju Android] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Wo eleyi na:**

[Lodi ti Google ni Wikipedia] (https://en.wikipedia.org/wiki/ Criticism_of_Google)

[Ibojì Google (kashebygoogle.com) - atokọ lẹsẹsẹ ti awọn ọja 224 + ti Google ti pa] (https://killedbygoogle.com/)

> [Ọna asopọ GitHub] (https://github.com/codyogden/killedbygoogle)

[Iṣọkan osise abidi - Ẹgbẹ alabaṣiṣẹpọ tuntun ni Google pẹlu awọn ọmọ ẹgbẹ ti o ju 800] (https://alphabetworkersunion.org/people/our-union/)

[Ṣe o ko fẹ lati pin pẹlu ẹyin aarun dinosaur? Oju opo wẹẹbu yii ti bo o] (https://chromedino.com/)

***

## Asiri

[G] (https://en.wikipedia.org/wiki/ Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (iwo-kakiri_eto)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / gbogbo-data-facebook-google-has-on-you-ikọkọ) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit).Thes -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / titẹsi / idi-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / bulọọgi / google-ìpamọ-iṣoro /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument # Criticism) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -essay-ayẹwo / ko si nkan-lati pamọ-ariyanjiyan-ko ni nkankan-lati sọ /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- ti-data-nipa-iwọ-le-wa-ati-paarẹ-bayi-) / r [(https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -your-personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -iṣowo-ati) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / gbogbo-data-facebook-google-has-on-you-privacy) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- gbigba-fi han.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ ilera-amọdaju-data-aṣiri /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australia-government-google-data-gbigba-ẹjọ-ẹjọ-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html) [0] [https://en.wikipedia.org/wiki/2018_Google_data_breach)=m] // https://moz.com /blog/where-does-google-draw-the-data-collection-line)Nee [//https://mashable.com/article/google-android-data-collection-study/)=s=(https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html) [0] [https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -nperare-lori dípò-ti-5-m awọn olumulo illion-iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [0] [https://arstechnica.com/information-technology/2014/01 / Kini-google-can-really-do-with-nest-or-really-nests-data/)Press/ [https://www.cbsnews.com/news/google-education-spies-on-collects- data-on-million-of-kids-alleges-ẹjọ-titun-mexico-Attorney-General /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -a-imu-wa /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / imọ-ẹrọ / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : //medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Mo le lọ siwaju ati siwaju pẹlu ẹri ti eyi, ṣugbọn o gba akoko pipẹ lati wa ati kọja gbogbo awọn wọnyi ohun èlò)

Asiri lori awọn ọja Google jẹ buburu nigbagbogbo, nitori gbogbo awọn ọja Google ti o ni spyware.

Laibikita ohun ti o ṣe, nigbati o ba nlo Google, gbogbo data ti ara ẹni ti o ni ifura ni a firanṣẹ si Google ati awọn miiran. A tun ti rii Google ti n lọ nipasẹ awọn eto ṣiṣi. Fun apẹẹrẹ, lati iriri ti ara ẹni (lori Firefox) pẹlu taabu YouTube ti ṣiṣi ti Emi ko ṣabẹwo, Mo wo ọpọlọpọ awọn fidio ni aisinipo (VLC Media Player) Nigbamii nigbati mo lọ ṣayẹwo awọn iṣeduro, o fẹrẹ jẹ ohun gbogbo ti Mo ti wo. Ko si iyemeji pe wọn n ṣe amí lori awọn eto miiran paapaa.

Ni Chrome (ati ọpọlọpọ awọn aṣawakiri miiran) ipo idanimọ kan wa. Ni Chrome, ipo yii jẹ asan, bi Google yoo tun jẹ data mi. Paapa ti o ba pa iwakusa data / ipasẹ kuro, ki o jẹki ami “maṣe tọpinpin”, iyalẹnu iyalẹnu, Google ṣi n wa data rẹ.

Ti o ba ro pe o ko ni nkankan lati tọju, ** o jẹ aṣiṣe patapata **. A ti ṣe ariyanjiyan ariyanjiyan yii ni ọpọlọpọ awọn igba lori:

[Nipasẹ Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden ṣe akiyesi “Jiyàn pe iwọ ko bikita nipa ẹtọ si ikọkọ nitori o ko ni nkankan lati tọju ko yatọ si ju sisọ pe o ko bikita nipa ọrọ ọfẹ nitori o ko ni nkankan lati sọ.” Nigbati o sọ, ‘ Mi o ni nkankan lati fi pamọ, 'o n sọ pe,' Emi ko fiyesi nipa ẹtọ yii. 'Iwọ n sọ pe,' Emi ko ni ẹtọ yii, nitori Mo ti de aaye ti Mo ni lati lare o. 'Ọna ti awọn ẹtọ n ṣiṣẹ jẹ, ijọba ni lati ṣalaye ifọpa si awọn ẹtọ rẹ. "

2. Daniel J. Solove sọ ninu nkan kan fun The Chronicle of Higher Education pe o tako ariyanjiyan naa; o ṣalaye pe ijọba kan le lek alaye nipa eniyan kan ki o fa ibajẹ si eniyan naa, tabi lo alaye nipa eniyan lati sẹ wiwọle si awọn iṣẹ paapaa ti eniyan ko ba ṣe aiṣedede, ati pe ijọba kan le fa ibajẹ si igbesi aye ara ẹni ẹnikan nipasẹ ṣiṣe awọn aṣiṣe. Solove kọwe “Nigbati o ba ṣiṣẹ taara, ariyanjiyan ariyanjiyan ohunkohun lati fi pamọ le dẹkun, fun o fi agbara mu ariyanjiyan naa lati dojukọ oye rẹ ti o ni oye ti aṣiri. Ṣugbọn nigbati o ba dojuko pẹlu ọpọlọpọ awọn iṣoro aṣiri ti o kan nipa gbigba data ijọba ati lilo kọja iwo-kakiri ati iṣafihan, ariyanjiyan ariyanjiyan-lati-tọju, ni ipari, ko ni nkankan lati sọ. "

3. Adam D. Moore, onkọwe ti Awọn ẹtọ Asiri: Iwa ati Awọn ipilẹ Ofin, jiyan, “o jẹ iwo ti awọn ẹtọ jẹ alatako si idiyele / anfani tabi iru awọn ariyanjiyan. ti awọn ohun ti o le ṣe tita fun aabo. " O tun ṣalaye pe iwo-kakiri le ni ipa aiṣedeede ni ipa awọn ẹgbẹ kan ni awujọ ti o da lori irisi, ẹya, ibalopọ, ati ẹsin.

4. Bruce Schneier, amoye aabo kọnputa ati onitumọ ọrọ, ṣalaye atako, ni atọkasi ọrọ Cardinal Richelieu “Ti ẹnikan ba fun mi ni awọn ila mẹfa ti a kọ nipasẹ ọwọ ọkunrin oloootọ julọ, Emi yoo wa nkan ninu wọn lati jẹ ki o so mọ”, ifilo si bawo ni ijọba ipinlẹ kan ṣe le wa awọn aaye ninu igbesi aye eniyan lati le pe lẹjọ tabi ba ẹni yẹn jẹ. Schneier tun jiyan “Pupọ pupọ ti o ṣe apejuwe jiyan ariyanjiyan bi 'aabo ni ilodi si aṣiri.' Aṣayan gidi jẹ ominira dipo iṣakoso. ”

5. Harvey A. Silverglate ṣe iṣiro pe eniyan ti o wọpọ, ni apapọ, laimọmọ ṣe awọn odaran mẹta lojoojumọ ni AMẸRIKA.

6. Emilio Mordini, onimọ-jinlẹ ati onimọran nipa imọ-ọrọ, jiyan pe ariyanjiyan “ko si nkan lati fi pamọ” jẹ eyiti o jẹ atako ti ẹda. Awọn eniyan ko nilo lati ni “nkankan lati tọju” lati le fi “nkankan” pamọ. Ohun ti o farapamọ ko jẹ dandan ti o yẹ, Mordini sọ. Dipo, o jiyan agbegbe timotimo eyiti o le farapamọ ati ihamọ-wiwọle jẹ pataki nitori, ni sisọrọ nipa ti imọ-ọrọ, a di ẹni-kọọkan nipasẹ iwari pe a le fi nkan pamọ si awọn miiran.

7. Julian Assange ṣalaye "Ko si idahun apaniyan sibẹsibẹ. Jacob Appelbaum (@ioerror) ni idahun ọlọgbọn, o beere lọwọ awọn eniyan ti o sọ eyi ki wọn fun foonu rẹ ṣiṣi silẹ ki o fa sokoto wọn silẹ. Ẹya mi ti iyẹn ni lati sọ, 'daradara, ti o ba jẹ alaidun nigbana ko yẹ ki a ba ọ sọrọ, ati pe ko yẹ ki ẹnikẹni miiran', ṣugbọn ni ọgbọn-ọgbọn, idahun gidi ni eyi: Ikiyesi ibi-pupọ jẹ iyipada eto igbepọ. Nigba ti awujọ ba buru, o n lọ lati mu ọ pẹlu rẹ, paapaa ti o ba jẹ eniyan abuku julọ ni agbaye. "

8. Ignacio Cofone, olukọ ofin, jiyan pe ariyanjiyan jiyan ni awọn ọrọ tirẹ nitori, nigbakugba ti eniyan ba ṣafihan alaye ti o yẹ fun awọn miiran, wọn tun ṣafihan alaye ti ko ṣe pataki. Alaye ti ko ṣe pataki yii ni awọn idiyele aṣiri ati o le ja si awọn ipalara miiran, bii iyasoto.

***

## Awọn ipolongo miiran ti o lodi si Google

Eyi ni atokọ ti awọn ipolongo alatako-miiran olokiki ti Google. Atokọ yii ko pe. O le ṣe iranlọwọ nipa fifẹ rẹ.

### Iṣẹ

[Scroogled - Nipasẹ Microsoft (Oṣu kọkanla 2012 si 2014)] (https://en.wikipedia.org/wiki/Scroogled)

_Ko si awọn titẹ sii miiran ni akoko yii._

### nlọ lọwọ

_ Atokọ yii ṣofo lọwọlọwọ._

***

## Ṣika awọn ariyanjiyan miiran

Awọn ariyanjiyan kan wa ti awọn eniyan ṣe lati da Google lare. Ọkan ninu akọkọ akọkọ ti wa ni debunked tẹlẹ [nibi] (# Asiri) ṣugbọn eyi ni diẹ ninu awọn miiran:

### Irọrun

Bẹẹni, awọn ọja Google dabi ẹni pe o rọrun. Sibẹsibẹ, o n ta ohun gbogbo ti o dara fun irọrun, pẹlu aabo, aṣiri, ati igbẹkẹle. Google ti n gba alara lori awọn ọdun, ati pe awọn olupin wọn ti lọ silẹ siwaju ati siwaju sii. Ni bayi, awọn olupin Google sọkalẹ fun o fẹrẹ to wakati kan 1-2 igba fun oṣu kan (pataki julọ YouTube)

Laanu, nitori igbẹkẹle awọn awujọ lori Google, Google ti wa lati jọba lori Intanẹẹti, o si n wa lati ṣakoso siwaju ati siwaju sii. Ni ọdun 2012, nigbati Google sọkalẹ fun iṣẹju marun 5, o royin pe ** agbaye ** ijabọ Intanẹẹti ** silẹ nipasẹ 40% ** Google nigbagbogbo n lọ silẹ fun awọn wakati 1-2, ati pẹlu [tita ibọn ẹgbẹ ẹgbẹ wọn] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) laarin awọn ohun miiran, wọn yoo dinku ati kere si rọrun.

Irọrun kii ṣe nkan to dara nigbagbogbo. O yẹ ki o mọ ohun ti n lọ ki o mura silẹ fun nigbati wọn ba lọ silẹ, nitori ko si ọna lati ni olupin ko ma sọkalẹ ni gbogbo lẹẹkan ni igba diẹ.

Google tun ko rọrun bi o ṣe ro. Awọn aaye miiran ti o rọrun pupọ diẹ sii wa. Google ko jinna si irọrun, nigbati o ba ṣoto awọn ifura akọọlẹ ID ati awọn ifopinsi wọn laisi idahun (ayafi ti o ba fa ifojusi to si akọọlẹ twitter ti Google tabi pe wọn lẹjọ fun $ 100,000,000 tabi diẹ ẹ sii) lẹhinna wọn ti ni anfani rẹ, wọn ti sọ ọ, ati fi agbara mu ọ lati kigbe sinu irọri kan, nibiti ko si ẹnikan ti o le gbọ igbe rẹfun iranlọwọ.

### Kini idi ti o ṣe pataki, o pẹ ju lọnakọna

Eyi jẹ ariyanjiyan ti ko wọpọ, ṣugbọn o nilo alaye. Pẹlu ipo lọwọlọwọ, ọpọlọpọ awọn ijọba agbaye, pẹlu ọpọlọpọ awọn ile-iṣẹ alagbara ti o dabi ẹni pe o mọ gbogbo gbigbe rẹ, nitorinaa kilode ti o fi ṣoro lati lọ kuro lọdọ rẹ? Idahun si jẹ rọrun: ** o tọsi dara julọ **. Ti o ba ṣakoso lati lọ kuro lọdọ wọn ni aaye yii, o nira fun wọn lati tọpinpin awọn gbigbe rẹ siwaju, ati pe o le kọ igbesi aye ikọkọ diẹ sii.

[Orisun 1] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Ni ọna, Mo ti n fun ni ẹbun Reddit ọfẹ mi si ifiweranṣẹ yii ni gbogbo igba ti mo ba gba fun ọsẹ kan bayi (pẹlu gbogbo awọn 500 awọn owó ọfẹ mi) lati ṣe agbega koko yii ni ilọsiwaju. Nitorinaa, Mo ti fun ifiweranṣẹ yii lori awọn ẹbun ọfẹ ọfẹ 14. Kii ṣe pupọ, ṣugbọn awọn ohun kekere le ṣe ipa nla, da lori bii o ṣe rii, ati nipasẹ tani.

### Omiiran

Emi ko ni awọn ariyanjiyan miiran ni akoko yii.

_ Atokọ yii ko pe_

***

## Awọn orisun

Daakọ:

[G] (https://en.wikipedia.org/wiki/ Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (iwo-kakiri_eto)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / gbogbo-data-facebook-google-has-on-you-ikọkọ) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit).Thes -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / titẹsi / idi-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / bulọọgi / google-ìpamọ-iṣoro /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Alariwisi) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -awọn apẹẹrẹ / nkankan-lati-tọju-ariyanjiyan-ko ni nkankan-lati sọ /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-nipa-o-le-wa-ati-paarẹ-bayi-) / r [(https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -ati) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html) [=] // [//https://www.reuters.com/article/us-alphabet- google-ìpamọ-ẹjọ-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)Press] [https://en.wikipedia.org/wiki/2018_Google_data_breach)=m] (https://) moz.com/bl og / ibo-ni-google-fa-laini gbigba-data-naa) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / imọ-ẹrọ / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- awọn ẹtọ-lori-dípò-ti-5-million-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) [= ]https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / alayelori-imọ ẹrọ / 2014/01 / kini-google-le-ṣe-ga-pẹlu-itẹ-tabi-gan-awọn itẹ-data /) [i] (https://www.cbsnews.com/news/google-education -spies-on-collections-data-on-million-of-kids-alleges-ẹjọ-titun-mexico-Attorney-General /) [v] (https://www.nationalreview.com/2018/04/the- akeko-data-iwakusa-sikandali-labẹ-wa-imu /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) [] [//https://medium.com/@hansdezwart/during-world-war-ii-we-did -a ni-nkankan-lati-tọju-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Awọn orisun miiran:

[Awọn Alliance marun oju] (https://en.wikipedia.org/wiki/Five_Eyes) [Ọgọrin ati ọgọrin mẹrin] (https://en.wikipedia.org/wiki/Neteen_Eighty-Four)

***

## Awọn ọna asopọ igbasilẹ

[Gba Firefox] (https://www.mozilla.org/en-US/firefox/new/) [Gba aṣàwákiri Tor] (https://www.torproject.org/download/) [Omiiran / ko si] [https : //www.example.com)

***

## Mi degoogling iriri

Ni ipari Mo bẹrẹ lati wo awọn iṣoro pẹlu tekinoloji nla ni ọdun 2018, ati pe MO bẹrẹ dagoogling. Ni awọn oṣu diẹ akọkọ, Mo ti ni ilọsiwaju pataki. O lọra lọpọlọpọ lati igba naa lọ.


### Ohun ti Mo yipada lati

Google Chrome -> Firefox / Tor

Wiwa Google -> DuckDuckGo (aiyipada) / Ecosia (nigbati Mo nifẹ rẹ) / Bing (ṣọwọn)

GMail - ProtonMail (ko tii yipada ni kikun)

Awọn Ojula Google -> Alejo ara ẹni (ko tii yipada ni kikun)

Google+ -> O fee ni lilo lailai, paarẹ ararẹ nitori tiipa tirẹ

Awọn Docs Google -> Ko lo, Mo kan lo Microsoft Word 2013 (ṣaaju 2019) ati LibreOffice (2019-onward) dipo.

Awọn iwe Google -> Ko lo rara, Mo kan lo Microsoft Excel 2013 (ṣaaju 2019) ati LibreOffice (2019-onward) dipo.

Awọn ifaworanhan Google -> Ko lo rara, Mo kan lo Microsoft PowerPoint 2013 (ṣaaju 2019) ati LibreOffice (2019-onward) dipo.

Awọn aworan Google -> Ko lo rara, Mo kan lo LibreOffice (2019-siwaju) dipo.

Gerrit -> Ko ṣe lo, Mo kan lo GitHub (aiyipada lọwọlọwọ), GitLab, BitBucket, ati SourceForge dipo.

Awọn fọto Google -> Ko lo rara

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-bayi)

Maps Google -> OpenStreetMaps / Apple Maps

Lọ - Ṣiṣe iyasọtọ pataki, ṣugbọn kii ṣe lilo bi ede siseto iṣẹ

Dart - Ṣiṣe iyasọtọ pataki, ṣugbọn kii ṣe lilo bi ede siseto iṣẹ-ṣiṣe

Flutter - Ṣiṣe iyasọtọ pataki, ṣugbọn kii ṣe lilo bi ede siseto iṣẹ-ṣiṣe

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> Ko lo rara, Mo rii afikun ti irako

Google Fi -> Ko lo

Kalẹnda Google -> Ko lo rara

Ẹrọ iṣiro Google -> Ni ọna kika eyikeyi ohun elo iṣiro miiran, paapaa ebute Linux kan ti n ṣiṣẹ ni ipo Python ti Mo ba nifẹ si i

Itẹ-ẹiyẹ Google -> Ko lo rara

AMP Google -> Ko lo rara

Google VPN -> Ko lo, tun atẹgun

Google Pay -> Ko lo rara

Ooru Google ti Koodu -> Ko ṣe alabapin

Tenor -> Awọn aaye GIF miiran, botilẹjẹpe awọn GIF ko ṣe pataki si mi. Mo gba awọn faili GIF deede lati awọn aworan DuckDuckGo, Imgur, Reddit, tabi awọn aaye miiran.

Ni idiwọ -> A ko lo mọ, ko daadaa ti Scratch taara ṣiṣe ni bulọki. Mo ti di komputa iṣẹ-ṣiṣe ni ọdun 2017 siwaju, ati dagba lati Scratch.

GBoard -> Ti lo lẹẹkan, ṣugbọn o fi silẹ

Gilasi Google -> Ko lo, ṣe akiyesi bi ọmọde ṣugbọn o pinnu lati ma gba ọkan / lo ọkan ti Mo ba ni aṣayan

_ Atokọ ko le pe._

### Awọn ọja Emi ko tun le kuro ni

Gẹgẹ bi Oṣu Kínní 25th 2021, iwọnyi ni awọn ọja Google ti n pa mi mọ lati dagoogulu ni kikun:

1. YouTube

2. Android

3. Ile itaja itaja Google

4. GMail (nikan fun ile-iwe ati diẹ ninu awọn aaye)

5. Yara ikawe Google (nikan fun ile-iwe)

6. Google Tumọ

7. Iroyin Google

8. Awọn Ojula Google (bi Google ṣe n tako awọn ofin ti GDPR (ati pe o le dojuko itanran € 5,000,000.00 miiran titi ti wọn yoo fi ṣatunṣe rẹ) ati eewọ awọn gbigba lati ayelujara ti ọja yii)

Mo ti dagoogled lati ohun gbogbo miiran.

***

## Lọ jẹ ibi

Google lọ lori ede siseto Agent 2003 “Lọ!” Pẹlu ede siseto wọn “Go` (lati ọdun 2009, ọdun 6 lẹhinna) o sọ pe ede wọn kii yoo ni ipa lori ede miiran rara. Google ti ṣofintoto darale fun eyi, nitoripe ọrọ wọn “Maṣe jẹ buburu” ṣi wa lọwọ ni akoko yẹn, ati pe eyi jẹ ọkan ninu ọpọlọpọ awọn iṣẹlẹ ti o ni ki o má jẹ ki Motto buburu ti fẹyìntì.

Ni ipari, idagbasoke ti “Lọ!” Dawọ, lakoko ti “Go` di pupọ ati siwaju sii. Google sọ pe wọn kii yoo rin kiri lori “Lọ!” Ṣugbọn ni ipari, wọn ṣe, wọn si lọ pẹlu rẹ (bii Oṣu Kẹrin Ọjọ 9th 2021)

[Ka diẹ sii nipa Go ati bii o ṣe le ṣe iyipo nibi] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Lilo ti DRM

Google lo DRM (Iṣakoso Awọn ihamọ Awọn ihamọ Digital) nipasẹ WideVine DRM "iṣẹ" wọn ati awọn fọọmu miiran. Aṣeyọri ti DRM ni lati pa Intanẹẹti ṣi silẹ ati fun awọn ile-iṣẹ ni agbara anikanjọpọn lori awọn olumulo. O yẹ ki o yọ WideVine kuro patapata, laibikita idiyele rẹ.

[Ka diẹ sii nipa WideVine ati awọn iṣoro rẹ nibi] (https://github.com/Degoogle-your-life/Its-time-lati-ge-WideVine-DRM)

***

## Awọn aṣiṣe ti o wọpọ

Eyi ni atokọ ti diẹ ninu awọn aṣiṣe ti o wọpọ pẹlu awọn ọja Google.

### Google kii ṣe Intanẹẹti

Wiwa Google / Google kii ṣe Intanẹẹti, wiwa Google jẹ ẹrọ wiwa nikan, iru bii bawo ni kii ṣe gbogbo ere fun pẹpẹ Nintendo ni Nintendo ṣe, ṣugbọn iwe-aṣẹ nipasẹ Nintendo, ṣugbọn si iye ti o pọ julọ. Ti gbogbo awọn olupin Googles ba fẹ parun nigbakanna ni bayi, Awọn aaye Google nikan bi YouTube, Gmail, Awọn iwe Google, wiwa Google, ati bẹbẹ lọ yoo lọ, ṣugbọn ọpọlọpọ Intanẹẹti yoo wa sibẹ (Wikipedia, Stackoverflow, GitHub, gbogbo awọn oju opo wẹẹbu Microsofts, NYTimes, Samsung, TikTok, ati bẹbẹ lọ) wọn le padanu ibuwolu wọle Google ati iṣẹ ṣiṣe itupalẹ, ṣugbọn wọn yoo tun jẹ iṣẹ-ṣiṣe (ayafi ti wọn ko ba ti ṣeto eto daradara ti wọn gbẹkẹle taarata lori Google)

***

## Internet Explorer 6 ati Chrome

Google Chrome n di Internet Explorer tuntun 6. Nigbati Google Chrome akọkọ jade, Firefox ni aṣawakiri aṣaaju, ati pe o pa julọ ni ọja ọja Awọn oluwakiri Ayelujara (eyiti o kọja 96% ṣaaju ki awọn miliọnu eniyan yipada si Firefox ati awọn aṣawakiri miiran) nigbati Google Chrome jade, awọn eniyan yipada nitori iyara rẹ ati pe o jẹ nipasẹ Google (eyiti ko ṣe akiyesi bi ibi ni akoko naa, nitori ọpọlọpọ awọn ọrọ aṣiri ko ti wa si imọlẹ sibẹsibẹ) Google Chrome ni akọkọ bọwọ fun awọn iṣedede wẹẹbu (eyiti o jẹ ohun ti Firefox ṣe ti o pa pipa Awọn oluwakiri Intanẹẹti 96% ṣiṣowo ọja aṣawakiri) sibẹsibẹ, bi iṣowo ọja Google Chromes ti dide, Google bẹrẹ yiyọ awọn ẹya diẹ sii ati siwaju sii, fifi spyware diẹ sii, o dẹkun gbigba awọn ipolowo wẹẹbu, Google Chrome ti di Internet Explorer 6 tuntun.

Iṣoro akọkọ ni bayi ni awọn oju opo wẹẹbu ti o jẹ Chrome nikan, ati pe kii yoo ṣiṣẹ lori awọn aṣawakiri miiran, bi awọn oludasile wọn pinnu pe wọn ko fẹ 30-40% miiran ti awọn olumulo Intanẹẹti ti ko lo Chrome lati lo aaye wọn.

Paapaa Google funrara wọn n ṣe awọn aaye wọn nikan Chrome. Fun apẹẹrẹ, wiwa Google yoo tọ ọ lati ṣe igbasilẹ Chrome ni igba mẹta 3 ni gbogbo awọn aaya 10 ti o ba ṣe iwari pe o ko lo Google Chrome (paapaa awọn aṣawakiri orisun Chromium miiran bii Onígboyà ni o kan) ati awọn aaye bii Google Earth ko gba awọn olumulo Firefox laaye lati lo aaye wọn (bii ti ọdun 2020) pẹlu Google Translate ko ṣe atilẹyin igbewọle ohun lori Firefox, ati awọn aṣawakiri miiran ti kii ṣe Google Chrome.

### Iṣoro naa pẹlu Onígboyà

Awọn aṣawakiri miiran ti o da lori Chromium, gẹgẹbi Brave ati Microsoft Edge ko ni ọfẹ patapata ti spyware Google. Onígboyà ni a ṣe iṣeduro nigbagbogbo nipasẹ ẹgbẹ ti ko tọ ti agbegbe aṣiri, ṣugbọn Onígboyà tun jẹ iṣoro, bi o ṣe nlo Chromium. Intanẹẹti ko yẹ ki o jẹ ti awọn aṣawakiri Chromium nikan, o yẹ ki ọpọlọpọ yiyan wa. Onígboyà ni ọna ti ko tọ lati lọ.

[Ka diẹ sii nipa degoogling lati Google Chrome / Chromium nibi] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Ka diẹ sii nipa degoogling lati ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) nibi] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Isọdọtun aṣiri Faux

Google ti n gbiyanju lati sọ fun agbaye pe wọn bikita nipa aṣiri, lẹhin ti o ti pẹ. Wọn tẹsiwaju lati beere pe wọn bọwọ fun aṣiri olumulo, ṣugbọn wọn ko tunṣe gbogbo awọn iṣoro aṣiri wọn.

### Orisun ṣiṣi ko le ṣe ipin

Orisun ṣiṣi ko le ṣe ipin. Google jẹ ẹri ti eyi. Gbogbo bit ati baiti ti koodu orisun gbọdọ han si gbogbo eniyan, pẹlu ko tilẹ jẹ 8th ti baiti kan ti o farapamọ.

Awọn iṣẹ akanṣe bii Android ati ChromeOS jẹ orisun ṣiṣi apakan, ṣugbọn ni ọpọlọpọ ninu ohun-ini, awọn eroja spyware ni.

### Oxymoron

Google VPN jẹ oxymoron. Google ko bikita nipa aṣiri, ati Nẹtiwọọki Ikọkọ Aladani kan (VPN) lati ile-iṣẹ bii wọn yoo jẹ ọkan ninu awọn yiyan ti o ṣeeṣe ti o buru julọ fun iṣẹ VPN kan.

***

## Iṣe buburu

Google ko bikita nipa iṣẹ ti awọn ọja wọn bi ti o kere ju ọdun 2017, bi a ti dawọ sọfitiwia aṣepari ti o kẹhin wọn (Google Octane) ni ọdun 2017.

***

## Isakoso ise agbese ti ko dara

Google ni eto iṣakoso idawọle inu ti o buru pupọ. Diẹ ninu awọn apẹẹrẹ ti o wọpọ ti awọn eto ti o ti sọ di pupọ siwaju sii pẹlu Google Duo ati orin YouTube (Orin Google Play tẹlẹ)

Ninu eto idagbasoke inu Googles, ohun elo 1 yori si ohun elo miiran pẹlu idaji iṣẹ ṣiṣe, lẹhinna ohun elo atilẹba ti paarẹ. Awọn ọdun meji nigbamii, a ṣe ohun elo tuntun pẹlu 75% iṣẹ ṣiṣe ti o kere si, lẹhinna ohun elo pẹlu iṣẹ 50% ni a yọkuro, atẹle pẹlu ohun elo tuntun pẹlu 87.5% ti iṣẹ ṣiṣe ti ṣẹda, lẹhinna ohun elo pẹlu iṣẹ 75% ti pari , ati bẹbẹ lọ.

***

## Ibanuje tabi ko si iwọntunwọnsi ti awọn iṣẹ

YouTube jẹ apẹẹrẹ ti o wọpọ julọ ni agbaye ti iwọntunwọnsi buburu ṣiṣẹda pẹpẹ ti o buru julọ ni aye. Google tun ko dabi pe o gba pe YouTube kii ṣe awọn ọmọde YouTube.

Fun YouTube, Pro-Nazi ikorira ati akoonu White Supremacist ni a ṣe iranṣẹ si awọn olumulo fun idi ti akoko ifunni diẹ sii ati owo diẹ sii. Google tun ti ṣe diẹ pupọawọn ohun aṣiwere ni iwọntunwọnsi wọn, gẹgẹ bi itẹwọgba fidio Fidio Ibalopo Onigbagbọ bi akoonu “ti a ṣe fun awọn ọmọ wẹwẹ“ lakoko kanna ni ọjọ ori ni ihamọ fidio naa. O tun kii ṣe loorekoore pupọ lati wo aworan iwokuwo tabi awọn ipolowo gore ti o wa labẹ fidio fidio Shark Baby, pẹlu ọpọlọpọ miiran “ti a ṣe fun akoonu awọn ọmọde.

Awọn olumulo YouTube nkùn lalailopinpin nipa iwọntunwọnsi ti ko dara lori YouTube fun akoonu buburu (bii awọn apẹẹrẹ ti a ṣe akojọ loke) lakoko ti awọn olumulo le gba awọn fidio wọn paarẹ laileto laisi idi laisi agbara lati fagile, pẹlu awọn olumulo ti n jiya fun eyikeyi iru ibura, paapaa awọn ọrọ ti o kere pupọ bi sisọ “awọn olumulo inira” ṣe afiwe YouTube si [Soviet Union] (https://en.wikipedia.org/wiki/Soviet_Union) ni akoko Stalin, nitori awọn ijiya ti ko ṣe deede wọnyi.

Ni 2021, Google kede pe wọn yoo fi awọn ipolowo sori gbogbo awọn fidio, botilẹjẹpe fidio ti ni ẹmi eṣu (nitorinaa Google ṣe owo, ṣugbọn eleda ko ṣe) eyi ko ni ibatan si iwọntunwọnsi pupọ, ṣugbọn o ṣe pataki lati ṣe akiyesi.

YouTube ti ṣabojuto (botilẹjẹpe o jẹ alaini pupọ) ṣugbọn iṣẹ ipolowo Google ti o jẹ ki wọn pọ julọ ti owo wọn dabi pe ko ni diẹ si ko si iwọntunwọnsi.

[Ka diẹ sii nipa awọn ọran iṣatunṣe YouTube ati bii a ṣe le yipada si YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Awọn ipolowo fun Google Play ni ipilẹṣẹ lati awọn oko oko bot, o le sọ nipa awọn oju iṣẹlẹ ipolowo kanna ti o nlo nipasẹ awọn ọgọọgọrun ti awọn ile-iṣẹ pẹlu awọn ayipada kekere, ati pe ko si ibatan si ọja naa (awọn apẹẹrẹ ti o wọpọ: Playrix (Awọn oju-ile, Awọn ile-ọgba) Fishdom, Ilu Mafia, ati ẹgbẹẹgbẹrun diẹ sii) pẹlu aṣa irira ti ariwo ti awọn ipolowo ti o nperare pe awọn olumulo le ni owo nipa ṣiṣere awọn ere, gbigbọ orin, ati bẹbẹ lọ PayPal ko ti asọye lori eyi, ṣugbọn o han gbangba pe eyi jẹ ete itanjẹ, bi ẹni pe o le ṣe lori $ 10,000 ni kere ju awọn aaya 20 nipasẹ ṣiṣere ere ti o ni idaniloju, ko si ẹnikan ti yoo ṣe iṣẹ ati pe yoo ṣe eyi dipo, eyiti ko ṣee ṣe, ati pe iṣowo ko le ṣiṣẹ bi eleyi. Ete itanjẹ ti o han gbangba yii ti ndagba lagbara lati ọdun 2019, ati nisisiyi awọn oko bot ti o ṣe awọn ipolowo wọnyi n ja pẹlu ara wọn ni awọn ipolowo tiwọn.

Ọpọlọpọ awọn ipolowo tun jẹ ibajẹ pupọ, ati igbiyanju lati gba awọn olumulo (ọpọlọpọ ninu wọn jẹ awọn olumulo labẹ ọdun 13, tabi awọn bot) lati tẹ nipasẹ ifọwọyi ibalopo.

Ọpọlọpọ awọn lw lo awọn botilẹtẹ ati astroturf awọn ọja wọn, nitorinaa nigbakugba ti atunyẹwo buburu kan ba ṣe, awọn akọọlẹ bot puetet bot yoo bẹrẹ fifiranṣẹ awọn atunwo irawọ 5 ati igbiyanju lati tako ilodi rẹ. [Google n ṣe eyi funra wọn pẹlu] (# Astroturfing)

[Ka diẹ sii nipa awọn ọran pẹlu AdSense Google] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

Itumọ gbogbogbo [(lati Wikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

“
Astroturfing jẹ iṣe ti iboju boju awọn onigbọwọ ti ifiranṣẹ kan tabi agbari (fun apẹẹrẹ, iṣelu, ipolowo, awọn ibatan ẹsin tabi ti gbogbo ilu) lati jẹ ki o han bi ẹni pe o ti ipilẹṣẹ ati atilẹyin nipasẹ awọn olukopa ipilẹ. O jẹ iṣe ti a pinnu lati fun awọn alaye tabi awọn igbekele agbari nipasẹ igbẹkẹle alaye nipa isopọ owo ti orisun. Ọrọ naa astroturfing jẹ orisun lati AstroTurf, ami iyasọtọ ti capeti ti iṣelọpọ ti a ṣe apẹrẹ lati jọ koriko ti ara, bi ere lori ọrọ “awọn koriko”. Itumọ ti o wa lẹhin lilo ọrọ naa ni pe dipo igbiyanju “koriko” tabi “abayọ” lati legbe iṣẹ ṣiṣe ni ibeere, irisi “iro” tabi “atọwọda” wa ti atilẹyin.
“

Google ni itan-akọọlẹ ti astroturfing lati jẹ ki o dabi pe wọn ko ṣe ohunkohun ti o buru (ninu ilana naa, astroturfing jẹ ibi) fun apẹẹrẹ, fifiranṣẹ atako ti Google lori pẹpẹ bi Twitter (eyiti wọn ni akọọlẹ kan lori) yoo ja si ni ọpọlọpọ awọn akọọlẹ ti o ti wa fun igba diẹ ṣugbọn ko firanṣẹ ṣaaju ki o to jade ati nipe pe ohun ti o sọ jẹ eke, ati lẹhinna sọ pe Google ni ile-iṣẹ ti o dara julọ, ṣugbọn ṣe ni ọna ti o le ma han gbangba pe awọn wọnyi jẹ awọn bot si pupọ julọ eniyan.

***

## Awọn iṣe iṣowo ti ofin ati aibikita

Google lo awọn ilana iṣowo ti ko ni ofin ati aibikita lati ṣe afikun anikanjọpọn wọn, gẹgẹbi lilo awọn ibi aabo owo-ori, awọn iṣẹ itusita, ati tẹsiwaju lati ṣe awọn iṣẹ apanirun arufin bi idiyele ti iṣowo.

### Ni Yuroopu

Yuroopu ti ṣe idajọ Google nigbagbogbo, ẹjọ ti o tobi julọ ni ilodi si ihuwasi arufin ni Android, eyiti o jẹ ki Google gba € 5,000,000,000 (deede si $ 5,947,083,703.68 ni Oṣu Kẹrin Ọjọ 9th 2021)

### Ni Ariwa America

Orilẹ Amẹrika ko fun fere to ti itanran si Google sibẹsibẹ, ni akawe si Europes € 5,000,000,000 itanran.

### Awọn ariyanjiyan

Google ko ṣe aniyan nipa iṣoro kan titi o fi ṣẹda ariyanjiyan, lẹhinna wọn yoo ṣe igbiyanju talaka lati ṣatunṣe rẹ, o kan to fun ariyanjiyan naa lati lọ fun igba diẹ, ati pe iṣoro naa yoo buru si gaan titi yoo fi ṣẹda ariyanjiyan miiran, ati pe kẹkẹ tẹsiwaju. Wọn ko bikita to lati ṣe ohunkohun to ṣe pataki nipa rẹ.

***

## Google jẹ adaṣe

Bi company, Google jẹ okeene adaṣe, pẹlu iwọntunwọnsi ju adaṣe.

Ile-iṣẹ ko yẹ ki o wa ni adaṣe ni kikun. Google jẹ apẹẹrẹ ti eyi. Iwontunwọnsi jẹ ẹru nigbati o ṣe nipasẹ AI nikan, YouTube jẹ apẹẹrẹ ti o dara, paapaa pẹlu awọn diẹ diẹ (awọn ọgọọgọrun, tabi boya ẹgbẹrun kan) awọn eniyan ti n ṣatunṣe aaye, nibiti o ti jẹ pe o buru pupọ pe ọpọlọpọ ninu wọn ni lati gba itọju ailera lakoko ti n ṣiṣẹ.

***

## Android

Android jẹ ohun-ini nipasẹ Google. Apakan ti Open Handset Alliance (eyiti ko ṣii lati igba Android) Android ti di aaye anikanjọpọn miiran fun Google, ati pe o nira pupọ lati sa fun.

A ti royin Android si foonu si ile Google ni o kere ju awọn akoko 10 fun ọjọ kan, ati botilẹjẹpe o jẹ orisun ṣiṣi apakan, o tun n ṣiṣẹ darale bi spyware.

Orisirisi awọn iṣẹ akanṣe ti ṣẹda lati miiran lati Android, ṣugbọn nilo rutini ẹrọ rẹ. Eyi kii ṣe ṣeeṣe mọ fun awọn foonu Samusongi kan pato ni AMẸRIKA, nitori Knox DRM. Awọn iyipo ti o wọpọ si Android pẹlu iOS, iPadOS, LineageOS, Android x86, Ubuntu Fọwọkan, ati PiPhone (Pi foonu jẹ ami ti awọn foonu ti o nṣiṣẹ ọpọlọpọ awọn eto Linux lori ẹrọ alagbeka, gẹgẹbi Fedora, Ubuntu, Arch, ati bẹbẹ lọ)

[Wo iwadi mi lori gbigba iṣẹ-ṣiṣe ẹrọ foju foju Android kan] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Wo bi o ṣe le degoogle lati Android] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Awọn iṣe kekere lati ṣe iranlọwọ

Pin imoye ni gbogbo ọna ti o le ṣe jẹ pataki. Fun mi, kii ṣe nigbagbogbo sọrọ nipa didoogling, ati kọ awọn nkan, ṣugbọn Mo tun ni ihuwa kekere kekere kan, nibiti Mo fun ni aami Reddit ọfẹ ọfẹ lojoojumọ si ifiweranṣẹ ti a pin lori r / degoogle lati ṣe agbega imọ. Nitorinaa, Mo ti fun awọn ẹbun ti o fẹrẹ to 30 si ifiweranṣẹ ti a pinni (Mo tun lo 500 ti awọn owó ọfẹ mi lori awọn ẹbun 10 fun ifiweranṣẹ naa)

***

## Aigbagbọ

Google ko le ni igbẹkẹle, ati pe ko le ni igbẹkẹle lailai. Wọn ti lọ patapata lati “maṣe jẹ eniyan buburu” (wọn jẹ eniyan nigbagbogbo) si jijẹ buburu patapata ati pe ko gbiyanju lati tọju.

***

## Awọn ohun miiran lati ṣayẹwo

[Ibojì Google (kashebygoogle.com) - atokọ lẹsẹsẹ ti awọn ọja 224 + ti Google ti pa] (https://killedbygoogle.com/)

> [Ọna asopọ GitHub] (https://github.com/codyogden/killedbygoogle)

[Iṣọkan osise abidi - Ẹgbẹ alabaṣiṣẹpọ tuntun ni Google pẹlu awọn ọmọ ẹgbẹ ti o ju 800] (https://alphabetworkersunion.org/people/our-union/)

[Ṣe o ko fẹ lati pin pẹlu ẹyin aarun dinosaur? Oju opo wẹẹbu yii ti bo o] (https://chromedino.com/)

Awọn omiiran miiran wa, kan wa fun wọn.

***

Diẹ ninu ṣayẹwo otitọ ni o nilo fun nkan yii

***

## Alaye faili

Iru faili: “Markdown (* .md)”

Nọmba laini (pẹlu awọn laini òfo ati laini akopọ): “968`

Ẹya faili: "6 (Ọjọ Sundee, Ọjọ Kẹrin Ọjọ 1821 ni 4:18 irọlẹ)"

***

### Ipo sọfitiwia

Gbogbo awọn iṣẹ mi ni ominira diẹ ninu awọn ihamọ. DRM (** D ** igital ** R ** estrictions ** M ** anagement) ko si ni eyikeyi awọn iṣẹ mi.

! [DRM-ọfẹ_label.en.svg] (DRM-free_label.en.svg)

Sitika yii ni atilẹyin nipasẹ Foundation Software ọfẹ. Emi ko pinnu lati fi DRM sinu awọn iṣẹ mi.

Mo n lo abbreviation "Iṣakoso Awọn ihamọ Awọn ihamọ Digital" dipo ti o mọ diẹ sii "Iṣakoso Awọn ẹtọ Onitẹsiwaju" bi ọna ti o wọpọ ti n ba sọrọ jẹ eke, ko si awọn ẹtọ pẹlu DRM. Akọtọ ọrọ “Iṣakoso Awọn ihamọ Awọn ihamọ Digital” jẹ deede julọ, ati pe o ni atilẹyin nipasẹ [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) ati [Foundation Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

A lo apakan yii lati gbe imoye fun awọn iṣoro pẹlu DRM, ati lati ṣe ikede rẹ. DRM jẹ alebu nipa apẹrẹ ati pe o jẹ irokeke nla si gbogbo awọn olumulo kọmputa ati ominira sọfitiwia.

Kirẹditi aworan: [defectivebydesign.org/drm-free/...] (//https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Alaye Onigbowo

! [SponsorButton.png] (SponsorButton.png) <- Maṣe tẹ bọtini yii, ko ṣiṣẹ, o kan jẹ aworan kan. Bọtini gidi wa ni oke oju-iwe ni apa ọtun (<- L ** R ** ->) igun

O le ṣe onigbọwọ iṣẹ yii ti o ba fẹ, ṣugbọn jọwọ ṣafihan ohun ti o fẹ lati ṣetọrẹ si. [Wo awọn owo ti o le ṣetọrẹ si ibi] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

O le wo alaye onigbowo miiran [nibi] (https://github.com/seanpm2001/Sponsor-info/)

Gbiyanju o jade! Bọtini onigbọwọ wa ni titọ lẹgbẹẹ bọtini iṣọ / ṣiṣi.

***

## Itan faili



 * Bibẹrẹ faili naa

> * Ṣafikun apakan akọle

> * Ṣafikun atọka naa

> * Fi kun nipa apakan

> * Ṣafikun apakan Wiki

> * Ṣafikun apakan itan ẹya

> * Ṣafikun apakan awọn ọran naa.

> * Ṣafikun apakan awọn ọran ti o kọja

> * Ṣafikun apakan awọn ibeere fifa ti o kọja

> * Ṣafikun apakan awọn ibeere fa lọwọ

> * Ṣafikun apakan awọn oluranlọwọ

> * Ṣafikun apakan idasi

> * Fikun-un nipa apakan README

> * Ṣafikun apakan itan ẹya README

> * Ṣafikun apakan awọn orisun

> * Ṣafikun apakan ipo sọfitiwia, pẹlu sitika ọfẹ DRM ati ifiranṣẹ

> *Ṣafikun apakan alaye onigbowo

> * Ko si awọn ayipada miiran ninu ẹya 0.1

Ẹya 1 (Ọjọ Ẹtì, Kínní 19th 2021 ni 5: 20pm)

> Awọn ayipada:

Bẹrẹ faili naa

> * Ṣafikun apakan apejuwe ipilẹ

> * Ṣafikun apakan apejuwe ibi ipamọ

> * Ṣafikun atokọ awọn nkan, pẹlu awọn titẹ sii 14

>> * Ṣafikun apakan awọn nkan ti o jọmọ

>> * Ṣafikun apakan kan “wo tun`

> * Ṣafikun apakan alaye faili naa

> * Fikun apakan apakan itan faili

> * Ṣafikun ẹlẹsẹ

> * Ko si awọn ayipada miiran ninu ẹya 1

Ẹya 2 (Ọjọ Ẹtì, Kínní 19th 2021 ni 5: 26pm)

> Awọn ayipada:

> * Ṣafikun apakan ipo itumọ

> * Ṣafikun Awọn ohun miiran lati ṣayẹwo apakan

> * Ṣafikun apakan ikọkọ

> * Ṣafikun itọka kan

> * Ṣafikun ipin ipo sọfitiwia

> * Ṣafikun apakan awọn ipolongo anti-Google miiran

>> * Ṣafikun ipin-iṣẹ ti o pari

>> * Ṣafikun ipin-ti nlọ lọwọ

> * Ṣafikun apakan awọn orisun

> * Ṣafikun apakan awọn ọna asopọ igbasilẹ

> * Ṣe imudojuiwọn apakan alaye faili naa

> * Ṣe imudojuiwọn apakan itan itan faili

> * Ko si awọn ayipada miiran ninu ẹya 2

Ẹya 3 (Ọjọru, Oṣu Kẹwa Ọjọ 24th 2021 ni 7:56 pm)

> Awọn ayipada:

> * Imudojuiwọn atọka naa

> * Ti ṣe afihan aami degoogle ati agbari GitHub tuntun

> * Awọn ọna asopọ ti a ṣafikun si awọn nkan tuntun

> * Ṣafikun apakan idako awọn ariyanjiyan miiran

>> * Ṣafikun ipin-wewewe

& Gt; & gt; Ṣafikun idi ti paapaa ipin kekere

>> * Ṣafikun ipin-keji miiran

> * Ṣe imudojuiwọn diẹ ninu data

> * Ṣe imudojuiwọn apakan alaye faili naa

> * Ṣe imudojuiwọn apakan itan itan faili

> * Ko si awọn ayipada miiran ninu ẹya 3

Ẹya 4 (Ọjọbọ, Kínní 25th 2021 ni 9: 31pm)

> Awọn ayipada:

> * Awọn ọna asopọ ti a ṣafikun si awọn nkan tuntun 10

> * Ṣafikun apakan kan nipa iriri iriri mi

> * Imudojuiwọn atọka naa

> * Ṣe imudojuiwọn apakan alaye faili naa

> * Ṣe imudojuiwọn apakan itan itan faili

> * Ko si awọn ayipada miiran ninu ẹya 4

Ẹya 5 (Ọjọ Jimọ, Ọjọ Kẹrin 9th 2021 ni 6:02 pm)

_Aini awọn imudojuiwọn ti wa si igbiyanju alatako Google lati ọdọ mi laipẹ, Mo n ṣiṣẹ lori ipadabọ si ọdọ rẹ lẹhin igbati oṣu kan 1 +.

> Awọn ayipada:

> * Imudojuiwọn apakan akọle

> * Imudojuiwọn atọka naa

> * Ṣe imudojuiwọn akojọ ede: awọn ọna asopọ ti o wa titi, ati ṣafikun awọn ede ti o ni atilẹyin diẹ sii

> * Ṣe imudojuiwọn apakan ipo ipo nkan, fifi awọn ọna asopọ orita 4 kun

> * Ṣe imudojuiwọn apakan ipo ipo sọfitiwia

> * Ṣafikun Go jẹ apakan ibi

> * Ṣafikun Lilo ti apakan DRM

> * Ṣafikun apakan awọn aṣiṣe ti o wọpọ

>> * Ṣafikun Google kii ṣe abala Intanẹẹti

> * Ṣafikun Intanẹẹti Explorer 6 ati apakan Chrome

>> * Ṣafikun iṣoro naa pẹlu abala igboya

> * Ṣafikun Faux yiyọ aṣiri

> * Ṣafikun orisun Ṣii ko le jẹ apakan apakan

> * Ṣafikun apakan Oxymoron

> * Ṣafikun apakan iṣẹ Iṣe Buburu

> * Ṣafikun apakan iṣakoso idawọle Buburu

> * Ṣafikun Ibanuje tabi ko si iwọntunwọnsi ti apakan awọn iṣẹ

> * Ṣafikun apakan Astroturfing

> * Ṣafikun apakan Awọn iṣe iṣowo arufin ati aibuku

> * Ṣafikun apakan In Europe Yuroopu

>> * Ṣafikun apakan In North America

>> * Ṣafikun apakan Awọn ariyanjiyan

> * Ṣafikun Google jẹ apakan adaṣe

> * Ṣafikun apakan Android

> * Ṣafikun awọn iṣe Kekere lati ṣe iranlọwọ apakan

> * Ṣafikun apakan igbẹkẹle

> * Ṣafikun apakan alaye onigbowo

> * Ṣe imudojuiwọn ẹlẹsẹ

> * Ṣe imudojuiwọn apakan alaye faili naa

> * Ṣe imudojuiwọn apakan itan itan faili

> * Ko si awọn ayipada miiran ninu ẹya 5

Ẹya 6 (Ọjọ Sundee, Oṣu Kẹrin Ọjọ 1821 ni 4: 18pm)

> Awọn ayipada:

> * Imudojuiwọn atọka naa

> * Ṣafikun apejuwe iwoye tuntun

> * Imudojuiwọn alaye ipo nkan

> * Ṣafikun ọna asopọ kan si nkan Google FLoC tuntun

> * Ṣafikun ọna asopọ kan si Wuest 3n Fuchs Degoogle nkan ati alaye gbogbogbo lori rẹ

> * Ṣe imudojuiwọn apakan alaye faili naa

> * Ṣe imudojuiwọn apakan itan itan faili

> * Ko si awọn ayipada miiran ninu ẹya 6

Ẹya 7 (Wiwa laipe)

> Awọn ayipada:

> * Wiwa laipẹ

> * Ko si awọn ayipada miiran ninu ẹya 7

Ẹya 8 (Wiwa laipe)

> Awọn ayipada:

> * Wiwa laipẹ

> * Ko si awọn ayipada miiran ninu ẹya 8

Ẹya 9 (Wiwa laipe)

> Awọn ayipada:

> * Wiwa laipẹ

> * Ko si awọn ayipada miiran ninu ẹya 9

Ẹya 10 (Wiwa laipe)

> Awọn ayipada:

> * Wiwa laipẹ

> * Ko si awọn ayipada miiran ninu ẹya 10

Ẹya 11 (Wiwa laipe)

> Awọn ayipada:

> * Wiwa laipẹ

> * Ko si awọn ayipada miiran ninu ẹya 11

Ẹya 12 (Wiwa laipe)

> Awọn ayipada:

> * Wiwa laipẹ

> * Ko si awọn ayipada miiran ninu ẹya 12

***

## Ẹsẹ

O ti de opin faili yii

([Pada si oke] (# Top) | [Pada si GitHub] (https://github.com))

### EOF

***
