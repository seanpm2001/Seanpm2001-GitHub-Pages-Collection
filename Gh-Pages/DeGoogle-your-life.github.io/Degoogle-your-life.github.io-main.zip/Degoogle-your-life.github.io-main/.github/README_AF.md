***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle jou lewe

Dit is die hoofontwikkelingsartikel vir algemene inligting rakende ontginning en 'n skakel na die ander artikels.

[Sien die lys as 'n GitHub-organisasie] (https://github.com/Degoogle-your-life)

***

_ Lees hierdie artikel in 'n ander taal:

** Huidige taal is: ** `Engels (VS)` _ (vertalings moet dalk reggestel word om Engels reg te stel wat die regte taal vervang) _

_🌐 Lys van tale_

** Gesorteer op: ** `A-Z`

[Sorteeropsies nie beskikbaar nie] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanees | [am አማርኛ] (/. github / README_AM.md) Amharies | [ar عربى] (/.github/README_AR.md) Arabies | [hy հայերեն] (/. github / README_HY.md) Armeens | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbeidjans | [eu Euskara] (/. github /README_EU.md) Baskies | [wees Беларуская] (/. Github / README_BE.md) Belo-Russies | [bn বাংলা] (/. Github / README_BN.md) Bengaals | [bs Bosanski] (/. Github / README_BS.md) Bosnies | [bg български] (/. Github / README_BG.md) Bulgaars | [ca Català] (/. Github / README_CA.md) Katalaans | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chinees (Vereenvoudigd) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chinees (Tradisioneel) | [co Corsu] (/. Github / README_CO.md) Korsikaans | [hr Hrvatski] (/. Github / README_HR.md) Kroaties | [cs čeština] (/. Github / README_CS .md) Tsjeggies [da dansk] (README_DA.md) Deens | [nl Nederlands] (/. github / README_ NL.md) Nederlands | [** en-us Engels **] (/. github / README.md) Engels | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estnies | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Fins | [fr français] (/. github / README_FR.md) Frans | [fy Frysk] (/. github / README_FY.md) Fries | [gl Galego] (/. github / README_GL.md) Galisies | [ka ქართველი] (/. github / README_KA) Georgies | [de Deutsch] (/. github / README_DE.md) Duits | [el Ελληνικά] (/. github / README_EL.md) Grieks | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haïtiaanse Creools | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaïaans | [he עִברִית] (/. github / README_HE.md) Hebreeus | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hongaars | [is Íslenska] (/. github / README_IS.md) Yslands | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesië] (/. github / README_ID.md) Yslands | [ga Gaeilge] (/. github / README_GA.md) Iers | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japannees | [jw Wong jawa] (/. github / README_JW.md) Javaans | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazaks | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-suid 韓國 語] (/. github / README_KO_SOUTH.md) Koreaans (Suid) | [ko-noord 문화어] (README_KO_NORTH.md) Koreaans (Noord) (nog nie vertaal nie) | [ku Kurdî] (/. github / README_KU.md) Koerdies (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgisies | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latyn | [lt Lietuvis] (/. github / README_LT.md) Litaus | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgs | [mk Македонски] (/. github / README_MK.md) Masedonies | [mg Malgassies] (/. github / README_MG.md) Malgassies | [ms Bahasa Melayu] (/. github / README_MS.md) Maleis | [ml മലയാളം] (/. github / README_ML.md) Malabaars | [mt Malti] (/. github / README_MT.md) Maltees | [mi Maori] (/. github / README_MI.md) Maori | [mnr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongools | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Birmaans) | [ne नेपाली] (/. github / README_NE.md) Nepalees | [no norsk] (/. github / README_NO.md) Noors | [of ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pasjto | [fa فارسی] (/. github / README_FA.md) | Persies [pl polski] (/. github / README_PL.md) Pools | [pt português] (/. github / README_PT.md) Portugees | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Geen tale beskikbaar wat met die letter Q | begin nie [ro Română] (/. github / README_RO.md) Roemeens | [ru русский] (/. github / README_RU.md) Russies | [sm Faasamoa] (/. github / README_SM.md) Samoaans | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Skotse Gaelies | [sr Српски] (/. github / README_SR.md) Serwies | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slowaaks | [sl Slovenščina] (/. github / README_SL.md) Sloweens | [so Soomaali] (/. github / README_SO.md) Somalies | [[es en español] (/. github / README_ES.md) Spaans | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Sweeds | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tataars | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Turks | [tk Türkmenler] (/. github / README_TK.md) Turkmeens | [uk Український] (/. github / README_UK.md) Oekraïens | [ur اردو] (/. github / README_UR.md) Oerdoe | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Oezbeeks | [vi Tiếng Việt] (/. github / README_VI.md) Viëtnamees | [cy Cymraeg] (/. github / README_CY.md) Wallies | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Jiddisj | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zoeloe] (/. github / README_ZU.md) Zoeloe) Beskikbaar in 110 tale (108 as u nie Engels en Noord-Koreaans tel nie, aangesien Noord-Koreaans nog nie vertaal is nie [Lees hieroor]] (/ OldVersions / Koreaans (Noord ) /README.md))

Vertalings in ander tale as Engels word masjienvertaal en is nog nie akkuraat nie. Geen foute is nog opgelos vanaf 5 Februarie 2021. Rapporteer asseblief vertaalfoute [hier] (https://github.com/seanpm2001/Degoogle-your-life/issues/), maak seker dat u u regstelling met bronne rugsteun en my lei. Aangesien ek nie ander tale as Engels goed ken nie (ek is van plan om uiteindelik 'n vertaler te kry) noem u [wiktionary] (https://en.wiktionary.org) en ander bronne in u verslag. As u dit nie doen nie, sal die regstelling van die hand gewys word.

Opmerking: as gevolg van beperkings met die interpretasie van GitHub van markdown (en bykans elke ander webgebaseerde interpretasie van markdown), klik hierdie skakels u na 'n aparte lêer op 'n aparte bladsy wat nie my GitHub-profielblad is nie. U sal na die [seanpm2001 / seanpm2001-bewaarplek] (https://github.com/seanpm2001/seanpm2001) herlei word, waar die README aangebied word.

Vertalings word met Google Translate gedoen as gevolg van beperkte of geen ondersteuning vir die tale wat ek benodig in ander vertaaldienste soos DeepL en Bing Translate (redelik ironies vir 'n anti-Google-veldtog). Ek is besig om 'n alternatief te vind. Om die een of ander rede is die opmaak (skakels, verdelers, vetdruk, kursief, ens.) Deurmekaar in verskillende vertalings. Dit is vervelig om op te los, en ek weet nie hoe om hierdie probleme in tale met nie-Latynse karakters op te los nie, en van regs na links (soos Arabies) is ekstra hulp nodig om hierdie probleme op te los

As gevolg van instandhoudingsprobleme is baie vertalings verouderd en gebruik 'n verouderde weergawe van hierdie 'README'-artikellêer. 'N Vertaler is nodig. Vanaf 9 April 2021 sal dit my 'n rukkie neem om al die nuwe skakels te laat werk.

***

## Indeks

[00.0 - Titel] (# Degoogling --- Degoogle-jou-lewe)

> [00.1 - Indeks] (# indeks)

[01.0 - Basiese beskrywing] (# Basiese beskrywing)

> [01.1 - Repository header] (# Degoogle-your-life)

> [01.2 - Wuest3NFuchs beskrywing oorsig] (# Oorsig-vir-Wuest3nFuchs)

>> [01.2.1 - Wat beteken dit?] (# Wat-dit-beteken-deur-Wuest3nFuchs)

>> [01.2.2 - Waarom Degoogle?] (# Waarom-Degoogle - deur-Wuest3nFuchs)

[02.0 - Artikels] (# artikels)

[03.0 - Privaatheid] (# privaatheid)

[04.0 - Ander anti-Google-veldtogte] (# Ander-anti-Google-veldtogte)

> [04.0.1 - Ontbreek] (# Ontbreek)

> [04.0.2 - Deurlopend] (# Aaneenlopend)

[05.0 - Teen ander argumente] (# Teen-ander-argumente)

> [05.0.1 - Gemak] (# gemak)

> [05.0.2 - Waarom maak dit saak? Dit is in elk geval te laat] (# Waarom-maak-dit-saak, dit is in elk geval te laat)

> [05.0.3 - Ander] (# Ander)

[06.0 - Bronne] (# bronne)

[07.0 - Aflaaiskakels] (# Aflaaiskakels)

[08.0 - My ontgroening-ervaring] (# My-ontoog-ervaring)

> [08.1 - Waarvandaan het ek oorgeskakel] (# Waarvan het ek oorgeskakel)

> [08.2 - Produkte waarvan ek nog nie kan wegkom nie] (# Produkte-ek kan nog steeds nie wegkom nie)

[09.0 - Ander dinge om na te gaan] (# Ander-dinge-om-uit te kyk)

[10.0 - Lêer-inligting] (# Lêer-inligting)

> [10.1 - Sagtewarestatus] (# Sagtewarestatus)

> [10.2 - Borginligting] (# borginligting)

[11.0 - Lêergeskiedenis] (# Lêergeskiedenis)

[12.0 - Footer] (# Footer)

***

## Basiese beskrywing

[Van Wikipedia: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

Die DeGoogle-beweging (ook bekend as die de-Google-beweging) is 'n voetsoolveldtog wat ontstaan ​​het omdat privaatheidsaktiviste gebruikers versoek om heeltemal op te hou om Google-produkte te gebruik vanweë toenemende privaatheidsbekommernisse rakende die maatskappy. Die term verwys na die daad om Google uit u lewe te verwyder. Aangesien die groeiende markaandeel van die internetreus monopolistiese mag vir die maatskappy in digitale ruimtes skep, het toenemende getalle joernaliste opgemerk dat dit moeilik is om alternatiewe vir die maatskappy se produkte te vind.

** Geskiedenis **

In 2013 het John Koetsier van Venturebeat gesê dat Amazon se Kindle Fire Android-gebaseerde tablet ''n de-Google-weergawe van Android is.' In 2014 skryf John Simpson van US News oor die "reg om vergeet te word" deur Google en ander soekenjins. In 2015 het Derek Scally van Irish Times 'n artikel geskryf oor hoe om jou lewe te de-google. In 2016 Kris Carlon van Android Authority het voorgestel dat gebruikers van CyanogenMod 14 hul telefone kan "de-Google", omdat CyanogenMod ook goed werk sonder Google-programme. In 2018 het Nick Lucchesi van Inverse geskryf hoe ProtonMail bevorder het hoe om 'u lewe heeltemal te kan de-Google.' Brendan Hesse, Lifehacker, het 'n gedetailleerde handleiding geskryf oor 'ophou met Google'. Gizmodo-joernalis Kashmir Hill beweer dat sy vergaderings misgeloop het en probleme ondervind met die organisering van ontmoetings sonder die gebruik van Google Kalender. die gebruik van dienste wat deur Google aangebied word, verhinder omdat daar so min alternatiewe bestaan ​​dat die afwesigheid van die maatskappy se produkte normale internetgebruik onuitvoerbaar gemaak het.

***

# Degoogle-jou-lewe
'N Bewaarplek vir algemene inligting oor inligting en skakels na my ander bewaarplekke.

***

## Oorsig deur Wuest3nFuchs

'N Beter beskrywing, verskaf deur [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - bron: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Wat beteken dit? deur Wuest3nFuchs

Degoogling beteken om op te hou om enigiets wat aan Google behoort, te gebruik, enigiets wat deur Google gemaak is. Ek praat van hul soekenjin, hul e-posdiens (Gmail), Youtube, ens.

### Waarom Degoogle? deur Wuest3nFuchs

Google is tans een van die magtigste maatskappye ter wêreld. Hulle het 'n groot hoeveelheid inligting oor ons almal gestoor. Sommige sal redeneer dat ons inligting veilig is, want hulle weet hoe om dit te beskerm. Maar dit is nie waar nie. Google is al voorheen deurgedring en dit sal in die toekoms binnegedring word. Miskien nie deur een of ander draaiboek nie, maar dit sal deur 'n volkstaat gedoen word. Google stoor persoonlike inligting oor ons almal, want dit is hoe hulle geld verdien.

Hulle skandeer ons e-posse, bêre wat ons soek as ons hul soekenjin gebruik, watter video's ons op Youtube kyk. Dit is hoe hulle ons rig en 'n profiel op ons bou om vir ons 'n advertensie te wys op grond waarvan ons met ons beste vriend gepraat het, sodat hulle 'n advertensie kan wys vir iets wat ons nodig het, maar dit is te grillerig. Danksy mnr. Snowden weet ons nou dat Google ons persoonlike inligting met NSA gedeel het onder 'n program genaamd ** 'PRISM' **.


In die toekoms sal iemand toegang tot al die inligting hê, en ek kan u verseker dat daar iets regtig sleg gaan gebeur. Om te verhoed dat dit gebeur, moet u dadelik met Degoogling begin. U moet ook nie produkte gebruik deur 'n maatskappy wat u data met ** NSA ** deel nie. U moet dit alles stop deur te soek.

** As ander mense dit kan doen, kan u dit ook doen. **

[Lees meer hier] (https://github.com/Wuest3nFuchs/Degoogle)

<! - 'n Skakel na die vurk word tans nie gelys nie, aangesien ek nie hierdie bewaarplek besit nie en ander bronne wil bevorder. Dit sou selfsugtig wees om na my eie https://github.com/Degoogle-your-life/Degoogle te skakel! ->

***

## Artikels

### Artikelstatus

_Alle artikels is tans besig om te werk en benodig groot verbeterings. Voorstelle en regstellings word toegelaat._

_ Vanaf 18 April 2021 om 16:09 is die meeste artikels nog nie begin nie. Ek werk daaraan om tyd en moeite te vind om dit te begin._

[Waarom moet jy ophou om Google Chrome te gebruik] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Chrome) <! - 1! ->

[Hou op om ChromeBooks te gebruik] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Stop met die gebruik van WideVine DRM / Dit is tyd om WideVine DRM te sny] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[Waarom jy moet ophou om ReCaptcha te gebruik] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-ReCaptcha) <! - 4! ->

[Afwisselend van YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Hou op met Google, waarom moet u ophou om Google Search te gebruik] (https://github.com/seanpm2001/Stop-Googling--Waarom-jy- moet-ophou-gebruik-Google-Search) <! - 6! - >

[Waarom moet u ophou om Gmail te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[Waarom moet jy ophou om Android te gebruik] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Android) <! - 8! ->

[Waarom jy Google Amp moet vermy] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[Waarom moet jy ophou om Google Drive te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[Waarom moet u ophou om Google Maps en Google Earth te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Hey Google, stop] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Hou op om uit Google / Play-boeke te lees] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Hou op om Google Classroom te gebruik] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[Waarom moet u ophou om Google Translate te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[Waarom moet u ophou om u Google-rekening (s) te gebruik] (https://github.com/seanpm2001/Waarom-jou-moet-sGoogle-rekeninge wat die beste gebruik) <! - 16! ->

** Nuwe artikels word binnekort geskryf: **

[Waarom moet u ophou om Gerrit te gebruik] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Gerrit) <! - 17! ->

[Waarom moet u ophou om Google Analytics te gebruik (die bewaarplek is aan my kant gebreek vanaf Woensdag 24 Februarie 2021 om 16:13 uur)] (https://github.com/seanpm2001/Waarom-jou- moet-stop-gebruik -Google-Analytics) <! - 18! ->

<! - Werkverdeler! ->

[Waarom moet u ophou om Google AdSense te gebruik] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Google-AdSense) <! - 19! ->

[Waarom moet u ophou om Google One te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[Waarom jy moet ophou om Google+ te gebruik (verval)] (https://github.com/seanpm2001/Waarom-jou- moet-stop-gebruik-Google-Plus) <! - 21! ->

[Waarom moet u ophou om die Google Play Store te gebruik] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-die-Google-Play-Store) <! - 22! ->

[Waarom u Google Docs moet ophou gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[Waarom moet u ophou om Google Slides te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[Waarom u Google Sheets moet ophou gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[Waarom moet u ophou om Google Forms te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[Waarom jy moet ophou om Google Cardboard te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[Waarom moet u ophou om Google Messages te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[Waarom moet u ophou om Google Materiaalontwerp te gebruik] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Google-Materiaal-Design) <! - 29! ->

[Waarom moet jy ophou om Google Glass / Glasses te gebruik] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Google-Glass) <! - 30! ->

[Waarom moet jy ophou om Google Fuchsia te gebruik] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Google-Fuchsia) <! - 31! ->

[Waarom moet u ophou om GBoard te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[Waarom moet u ophou om Google Home te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[Waarom jy Google Nest moet ophou gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[Waarom moet jy ophou om Google Hangouts te gebruik (ontbreek)] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Google-Hangouts) <! - 35! ->

[Waarom moet u ophou om Google Duo te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[Waarom moet jy ophou om Google Tensorflow te gebruik] (https://github.com/seanpm2001/Waarom-jy-moet-stop-gebruik-Google-Tensorstroom) <! - 37! ->

[Waarom moet u ophou om Google Blockly te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[Waarom moet jy ophou om Google Flutter te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[Waarom moet u ophou om Googles Go-programmeertaal te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[Waarom moet u ophou om die Googles Dart-programmeertaal te gebruik] (https://github.com/seanpm2001/Waarom-jou- moet-stop-gebruik-Google-Dart) <! - 41! ->

[Waarom moet u ophou om Googles WebP-beeldformaat te gebruik] (https://github.com/seanpm2001/Waarom-jou- moet-stop-gebruik-Google-WebP) <! - 42! ->

[Waarom moet u ophou om die Googles WebM-videoformaat te gebruik] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Google-WebM) <! - 43! ->

[Waarom moet u ophou om Google Video te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[Waarom moet u ophou om Google Sites (klassiek) te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[Waarom moet u ophou om Google Sites te gebruik ("Nuut")] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Google-Sites_New) <! - 46! ->

[Waarom moet u ophou om Google Pay te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[Waarom moet u ophou om Android Pay te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[Waarom moet u ophou om Google Skynprivaatnetwerk (oxymoron) te gebruik] (https://github.com/seanpm2001/Waarom-jou- moet-stop-gebruik-Google-VPN) <! - 49! ->

[Waarom moet u ophou om Google Foto's te gebruik] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Google-Photos) <! - 50! ->

[Waarom moet u ophou om Google Kalender te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[Waarom moet u ophou om VirusTotal te gebruik (aangesien dit sedert September 2012 deur Google besit word) (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-VirusTotaal) <! - 52! - >

[Waarom moet u ophou om Google Fi te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-gebruik-Google-Fi) <! - 53! ->

[Waarom moet u ophou om Google Stadia te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[Waarom moet jy ophou om Google Keep te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[Waarom moet u ophou om Google Base te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[Waarom jy moet ophou om aan die Google Summer of Code deel te neem] (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Google-Somer-van-code) <! - 57! - >

[Waarom moet jy ophou om Google Camera te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[Waarom moet u ophou om Google Sakrekenaar te gebruik (dit lyk dalk ekstreem, maar u moet van alles afmeld, uiters maklik om af te wissel)) (https://github.com/seanpm2001/Waarom-jou-moet-stop-gebruik-Google- Sakrekenaar) <! - 59! ->

[Waarom moet jy ophou om Google Survey + -belonings te gebruik] (https://github.com/seanpm2001/Waarom-jou- moet-stop-gebruik-Google-Survey-rewards) <! - 60! ->

[Waarom moet u ophou om Google Drawings te gebruik] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[Waarom moet u ophou om Tenor te gebruik (GIF-werf, sedert 2019 in besit van Google)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Wat die FLoC - Waarom u Google se groot FLoCing-probleem moet vermy (stop met die gebruik van Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Totale artikels: ** `63`

** Artikel [roadmap AB] (DegoogleCampaign_2021Roadmap_Part1.md) (tot 12 Maart 2021) 2 dae af **

** Artikel [padkaart BB] (DegoogleCampaign_2021Roadmao_Part2.md) (tot? 2021) 2 dae af **

Artikelstatus

Al die artikels is tans besig om te werk en benodig groot verbeterings. Voorstelle en regstellings word toegelaat.

** vurke **

Die uitbreiding van my Degoogle-netwerk en die gemak van toegang en die uitroepe van die gemeenskap.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Vork uit: [https://github.com/wacko1805/Fossapps ](https://github.com/wacko1805/Fossapps) (Engels)

2. [Privaatheidskakels] (https://github.com/Degoogle-your-life/Privacy-links) | Vork uit: [https://github.com/Arturro43/privacy-links ](https://github.com/Arturro43/privacy-links) (Pools)

3. [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Vork uit: [https://github.com/LinuxCafeFederation/Delightful-Privacy ](https://github.com/LinuxCafeFederation/Delightful-Privacy) (Engels)

4. [Blokkelyste] (https://github.com/Degoogle-your-life/blocklists) | Gevork vanaf: [https://github.com/jmdugan/blocklists ](https://github.com/jmdugan/blocklists) (Engels)

5. [Degoogle, deur Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Vork uit: [https://github.com/Wuest3nFuchs/Degoogle ](https://github.com/Wuest3nFuchs/Degoogle) (Engels)

**Verwante**

[Degoogled Android-selfoon-ondersoek na virtuele masjien] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Sien ook:**

[Kritiek op Google op Wikipedia] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[Die Google-begraafplaas (killbygoogle.com) - 'n gesorteerde lys van die 224+ produkte wat Google vermoor het] (https://killedbygoogle.com/)

> [GitHub-skakel] (https://github.com/codyogden/killedbygoogle)

[Alphabet workers union - Die nuwe werkersunie by Google met meer as 800 lede] (https://alphabetworkersunion.org/people/our-union/)

[Wil u nie met die dinosourus-paaseier skei nie? Hierdie webwerf behandel u] (https://chromedino.com/)

***

## Privaatheid

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) [s ](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / waarom-googles-spioenasie-op-gebruik_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument # Kritiek) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -sê voorbeelde / niks-om-weg te steek-argument-het-niks-om te sê nie /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- van-data-oor-jy-jy-kan-dit-nou-vind-en-verwyder / / [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -jou-persoonlike-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -monetiseer-en) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- collection-reveal.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ gesondheid-fiksheid-data-privaatheid /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-government-google-data-collection-process-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html) [o ](https://en.wikipedia.org/wiki/2018_Google_data_breach) [m ](https://moz.com /blog/where-does-google-draw-the-data-collection-line) [e ](https://mashable.com/article/google-android-data-collection-study/) [s ](https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html) [o ](https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -eise-namens-van-5-m illion-iphone-gebruikers) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r ](https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/) [i ](https://www.cbsnews.com/news/google-education-spies-on-collects- data-oor-miljoene-kinders-beweer-regsgeding-new-mexico-prokureur-generaal /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -onder-ons-neuse /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / tegnologie / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : //medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (ek kon aanhou met bewyse hiervan, maar dit het lank geneem om al hierdie dinge te vind en deur te gaan artikels)

Privaatheid op Google-produkte is altyd sleg, omdat alle Google-produkte spyware bevat.

Dit maak nie saak wat u doen nie, wanneer u Google gebruik, word al u sensitiewe persoonlike data na Google en ander gestuur. Google is ook gesien wat deur oop programme gaan. Uit persoonlike ervaring (op Firefox) met 'n oop YouTube-blad wat ek nie besoek het nie, het ek byvoorbeeld verskeie video's vanlyn gekyk (VLC Media Player) Later, toe ek die aanbevelings gaan nagaan, was dit amper alles wat ek gekyk het. Daar is geen twyfel dat hulle ook op ander programme spioeneer nie.

In Chrome (en baie ander blaaiers) is 'n incognito-modus beskikbaar. In Chrome is hierdie modus sinneloos, aangesien Google u data steeds sal ontgin. Selfs as u data-ontginning / -opsporing afskakel en die sein "nie opspoor nie" inskakel, verbaas u u, Google ontgin steeds u data.

As u dink dat u niks het om weg te steek nie, ** is u heeltemal verkeerd **. Hierdie argument is al baie keer ontbloot:

[Via Wikipedia] (https://en.wikipedia.org/wiki/Niks_to_verberg_argument#Kritiek)

1. Edward Snowden het opgemerk: 'Om te betoog dat u nie omgee vir die reg op privaatheid nie, omdat u niks het om weg te steek nie, is nie anders as om te sê dat u nie omgee vir vrye spraak nie, omdat u niks het om te sê nie.' As u sê: ' Ek het niks om weg te steek nie, 'sê jy,' ek gee nie om vir hierdie reg nie. ' dit. 'Soos die regte werk, moet die regering sy indringing in u regte regverdig.'

2. Daniel J. Solove het in 'n artikel vir The Chronicle of Higher Education gesê dat hy die argument teenstaan; hy het verklaar dat 'n regering kan losk inligting oor 'n persoon en skade aan die persoon aanrig, of inligting oor 'n persoon gebruik om toegang tot dienste te weier, selfs al het iemand nie daadwerklik gepleeg nie, en dat 'n regering skade aan sy persoonlike lewe kan veroorsaak deur foute te maak. Solove het geskryf 'Wanneer die niks-om-te-wegsteek-argument direk betrokke is, kan dit dwarsboom, want dit dwing die debat om te fokus op die noue begrip van privaatheid. Maar wanneer dit gekonfronteer word met die veelheid van privaatheidsprobleme wat geïmpliseer word deur die regering se data-insameling en -gebruik buite toesig en openbaarmaking, die argument om niks te verberg nie, het uiteindelik niks te sê nie. '

3. Adam D. Moore, skrywer van Privacy Rights: Moral and Legal Foundations, het aangevoer: "dit is die mening dat regte bestand is teen koste / voordeel of gevolglike argumente. Hier verwerp ons die siening dat privaatheidsbelange die soort is van dinge wat vir sekuriteit verhandel kan word. ' Hy het ook verklaar dat toesig sekere groepe in die samelewing buite verhouding kan beïnvloed op grond van voorkoms, etnisiteit, seksualiteit en godsdiens.

4. Bruce Schneier, 'n kenner en kriptograaf op die gebied van rekenaarbeveiliging, het teenkanting uitgespreek met verwysing na kardinaal Richelieu se uitspraak "As iemand my ses reëls sou gee wat deur die hand van die eerlikste man geskryf is, sou ek iets daarin vind om hom op te hang", met verwysing hoe 'n staatsregering aspekte in 'n persoon se lewe kan vind om daardie individu te vervolg of afpers. Schneier het ook aangevoer 'Te veel kenmerk die debat verkeerdelik as' veiligheid versus privaatheid '. Die regte keuse is vryheid teenoor beheer. '

5. Harvey A. Silverglate het beraam dat die gewone persoon gemiddeld onwetend drie misdade per dag in die VSA pleeg.

6. Emilio Mordini, filosoof en psigoanalis, het aangevoer dat die argument "niks om weg te steek nie" inherent paradoksaal is. Mense hoef nie 'iets te verberg' om 'iets' weg te steek nie. Wat verborge is, is nie noodwendig relevant nie, beweer Mordini. In plaas daarvan voer hy aan dat 'n intieme gebied wat verborge kan wees en toegangsbeperking nodig is, aangesien ons sielkundig individue word deur die ontdekking dat ons iets vir ander kan wegsteek.

7. Julian Assange het gesê: "Daar is nog geen antwoord op die moordenaar nie. Jacob Appelbaum (@ioerror) reageer slim en vra mense wat dit sê, om dan hul telefoon oopgesluit te gee en hul broek af te trek. My weergawe daarvan is om te sê: 'wel, as u so vervelig is, dan moet ons nie met u praat nie, en ook niemand anders nie', maar filosofies, is die werklike antwoord dit: massatoezicht is 'n groot struktuurverandering. As die samelewing sleg gaan, gaan dit om jou mee te neem, al is jy die sagste persoon op aarde. '

8. Ignacio Cofone, professor in die regte, voer aan dat die argument verkeerdelik in sy eie terme verkeerd is omdat, wanneer mense ook relevante inligting aan ander bekend maak, dit ook irrelevante inligting openbaar. Hierdie irrelevante inligting hou privaatheidskoste in en kan lei tot ander skade, soos diskriminasie.

***

## Ander anti-Google-veldtogte

Dit is 'n lys van ander noemenswaardige anti-Google-veldtogte. Hierdie lys is onvolledig. U kan help deur dit uit te brei.

### Ontbreek

[Scroogled - Deur Microsoft (November 2012 tot 2014)] (https://en.wikipedia.org/wiki/Scroogled)

Geen ander inskrywings is tans beskikbaar nie.

### Deurlopend

_Hierdie lys is tans leeg.

***

## Teenstrydig met ander argumente

Daar is enkele argumente wat mense voer om Google te regverdig. Een van die eerste groot een is al [hier] ontbloot (# privaatheid), maar hier is 'n paar ander:

### Gerief

Ja, Google-produkte lyk gerieflik. U verhandel egter alles goed vir u gemak, insluitend sekuriteit, privaatheid en betroubaarheid. Google het oor die jare lui geraak, en hul bedieners het al hoe meer afgeneem. Op die oomblik gaan die Google-bedieners 1-2 keer per maand vir byna 'n uur af (veral YouTube)

As gevolg van die vertroue van Google op Google, het Google ongelukkig die internet oorheers en probeer dit om meer en meer te beheer. In 2012, toe Google vir vyf minute afgeneem het, is gerapporteer dat ** wêreldwyd ** internetverkeer ** met 40% gedaal het. Google gaan gereeld vir 1-2 uur af, en met die [ontslag van hul etiese span] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/), gaan hulle al hoe minder gerieflik raak.

Gerief is nie altyd 'n goeie ding nie. U moet bewus wees van wat aangaan en voorbereid wees op wanneer hulle afgaan, want daar is nie 'n manier om 'n bediener te laat afneem nie.

Google is ook nie so gerieflik as wat jy dink nie. Daar is ander baie geriefliker webwerwe. Google is ver van gerieflik, as u hul ewekansige rekeningopskortings en beëindigings sonder antwoord reageer (tensy u genoeg aandag aan die Google-twitterrekening vestig of dit vir $ 100.000.000 of meer dagvaar), dan het hulle u benut, geskok en het jou gedwing om in 'n kussing in te skree, waar niemand jou gille kon hoor nievir hulp.

### Waarom maak dit saak, dit is in elk geval te laat

Dit is 'n minder algemene argument, maar dit moet verduidelik word. Met die huidige toestand blyk dit dat die meeste wêreldregerings, tesame met 'n aantal magtige maatskappye, alles weet wat u doen, so waarom moet u dit selfs doen om daarvan weg te kom? Die antwoord is eenvoudig: ** jy verdien beter **. As u op hierdie stadium daarin slaag om van hulle weg te kom, is dit moeiliker vir hulle om u bewegings verder op te spoor, en u kan 'n nuwe privaat lewe opbou.

[1 bron] (https://www.reddit.com/r/degoogle/comments/huk4rp/why_you_should_degoogle_intro_degoogling/) Terloops, ek gee my gratis Reddit-toekenning aan hierdie pos elke keer as ek dit vir meer as 'n week kry nou (tesame met al 500 my gratis munte) om hierdie onderwerp verder te versterk. Tot dusver het ek hierdie pos meer as 14 gratis toekennings gegee. Dit is nie veel nie, maar klein dinge kan 'n groot impak hê, afhangende van hoe dit ervaar word en deur wie.

### Ander

Ek het op die oomblik geen ander argumente nie.

_Hierdie lys is onvolledig_

***

## Bronne

Kopie:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) [s ](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / waarom-googles-spioenasie-op-gebruik_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritiek) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -monsters / niks-om-weg te steek-argument-het-niks-om-te sê nie /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-oor-jy-jy-kan-dit-nou-vind-en-verwyder /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -persoonlike-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -en) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html) [d ](https://www.reuters.com/article/us-alphabet- google-privaatheidsgeding-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html) [o ](https://en.wikipedia.org/wiki/2018_Google_data_breach) [m ](https:// moz.com/bl og / waar-google-teken-die-data-versameling-lyn) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- eis-namens-van-5-miljoen-iphone-gebruikers) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)(e ](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your your -telefoon-is nie-in-gebruik /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technology / 2014/01 / wat-google-kan-regtig-doen-met-nes-of-regtig-nes-data /) [i] (https://www.cbsnews.com/news/google-education -spioene-op-versamel-data-op-miljoene-kinders-bewerings-regsgeding-nuwe-mexico-prokureur-generaal /) [v] (https://www.nationalreview.com/2018/04/the- student-data-ontginning-skandaal-onder-ons-neus /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) [y ](https://medium.com/@hansdezwart/during-world-war-ii-we-did -het-iets-om-weg te steek-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Ander bronne:

[Alliansie met vyf oë] (https://en.wikipedia.org/wiki/Five_Eyes) [Negentien vier en tagtig] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Laai skakels af

[Kry Firefox] (https://www.mozilla.org/en-US/firefox/new/) [Kry Tor-blaaier] (https://www.torproject.org/download/) [Ander / onbeskikbaar] (https : //www.voorbeeld.com)

***

## My degoogling ervaring

Ek het uiteindelik die probleme met groot tegnologie in 2018 begin sien, en ek het begin soek. In die eerste paar maande het ek aansienlike vordering gemaak. Dit het sedertdien geweldig afgeneem.


### Waarvan ek oorgeskakel het

Google Chrome -> Firefox / Tor

Google Search -> DuckDuckGo (standaard) / Ecosia (as ek lus het) / Bing (selde)

GMail - ProtonMail (nog nie heeltemal aangeskakel nie)

Google Sites -> Selfhosting (nog nie heeltemal aangeskakel nie)

Google+ -> Skaars gebruik, self uitgevee weens sy eie afskakeling

Google Docs -> Nooit gebruik nie, ek gebruik net Microsoft Word 2013 (voor 2019) en LibreOffice (vanaf 2019).

Google Blaaie -> Nooit gebruik nie, maar ek gebruik net Microsoft Excel 2013 (voor 2019) en LibreOffice (vanaf 2019).

Google Skyfies -> Nooit gebruik nie, ek gebruik net Microsoft PowerPoint 2013 (voor 2019) en LibreOffice (vanaf 2019).

Google Tekeninge -> Nooit gebruik nie; ek gebruik eerder LibreOffice (vanaf 2019).

Gerrit -> Nooit gebruik nie, ek gebruik eerder GitHub (huidige verstek), GitLab, BitBucket en SourceForge.

Google Foto's -> Nooit gebruik nie

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-hede)

Google Maps -> OpenStreetMaps / Apple Maps

Go - Maak 'n spesiale uitsondering, maar gebruik dit nie as 'n funksionele programmeertaal nie

Dart - Maak 'n spesiale uitsondering, maar gebruik dit nie as 'n funksionele programmeertaal nie

Fladder - Maak 'n spesiale uitsondering, maar gebruik dit nie as 'n funksionele programmeertaal nie

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> Nooit gebruik nie, ek vind dit ekstra grillerig

Google Fi -> Nooit gebruik nie

Google Kalender -> Nooit gebruik nie

Google sakrekenaar -> Letterlik enige ander sakrekenaar-app, selfs 'n Linux-terminaal wat in die Python-modus loop as ek so voel

Google Nest -> Nooit gebruik nie

Google AMP -> Nooit gebruik nie

Google VPN -> Nooit gebruik nie, ook 'n oxymoron

Google Pay -> Nooit gebruik nie

Google Summer of Code -> Nooit deelgeneem nie

Tenor -> Ander GIF-webwerwe, hoewel GIF's nie vir my te belangrik is nie. Ek kry gewoonlik GIF-lêers van DuckDuckGo-beelde, Imgur, Reddit of ander webwerwe.

Blokvormig -> Nie meer gebruik nie, nie seker of Scratch direk blokkies geloop het nie. Ek het in 2017 'n funksionele programmeerder geword en het uit Scratch gegroei.

GBoard -> Een keer gebruik, maar verlate

Google Glass -> Nooit gebruik nie, beskou as 'n jong kind, maar besluit om nie een te kry / een te gebruik as ek die opsie het nie

_Lys kan onvolledig wees.

### Produkte waarvan ek steeds nie kan wegkom nie

Op 25 Februarie 2021 is dit die Google-produkte wat my weerhou van 'n volledige skeuring:

1. YouTube

2. Android

3. Google Play Winkel

4. Gmail (slegs vir skool en sommige webwerwe)

5. Google Klaskamer (slegs vir skool)

6. Google Translate

7. Google-rekening

8. Google Sites (aangesien Google die wette van die AVG oortree (en nog 'n boete van € 5.000.000,00 opgelê kan word totdat dit reggestel word) en die aflaai van hierdie produk verbied)

Ek het van alles anders afgegaan.

***

## Go is boos

Google het die 2003-agentgebaseerde programmeertaal 'Go!' Met hul programmeertaal 'Go' gestoom (vanaf 2009, 6 jaar later) en beweer dat hul taal die ander taal glad nie sal beïnvloed nie. Google is hewig daaroor gekritiseer, omdat hul slagspreuk 'Moenie kwaad wees nie' destyds nog aktief was, en dit is een van die vele voorvalle wat die moenie kwaad-motto afgetree het nie.

Uiteindelik het die ontwikkeling van 'Go!' Opgehou, terwyl 'Go' al hoe meer algemeen geword het. Google beweer dat hulle nie oor 'Go!' Sou loop nie, maar uiteindelik het hulle dit gedoen en hulle het daarmee weggekom (vanaf 9 April 2021)

[Lees hier meer oor Go en hoe om af te wissel] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Gebruik van DRM

Google gebruik DRM (Digital Restrictions Management) deur middel van hul WideVine DRM "diens" en ander vorms. Die doel van DRM is om die oop internet te vernietig en ondernemings monopolistiese mag oor gebruikers te gee. U moet WideVine heeltemal ontslae raak, ongeag die koste.

[Lees hier meer oor WideVine en sy probleme] (https://github.com/Degoogle-your-life/Its-time-WideVine-DRM te sny)

***

## Algemene wanopvattings

Dit is 'n lys van algemene misverstande met Google-produkte.

### Google is nie die internet nie

Google / Google-soektogte is nie die internet nie, Google-soektog is net 'n soekenjin, soos hoe nie elke speletjie vir 'n Nintendo-platform deur Nintendo gemaak word nie, maar wel gelisensieer is deur Nintendo, maar in 'n veel groter mate. As alle Google-bedieners tans gelyktydig vernietig sou word, sou net Google Sites soos YouTube, Gmail, Google Docs, Google search, ens. Verdwyn, maar die meerderheid van die internet sou nog steeds daar wees (Wikipedia, Stackoverflow, GitHub, op alle Microsofts-webwerwe, NYTimes, Samsung, TikTok, ens.) kan hulle hul Google-aanmeldings- en analitiese funksies verloor, maar hulle sal steeds funksioneel wees (tensy hulle sleg geprogrammeer en direk op Google staatgemaak het)

***

## Internet Explorer 6 en Chrome

Google Chrome is besig om die nuwe Internet Explorer te word 6. Toe Google Chrome oorspronklik uitgekom het, was Firefox die dominante blaaier en het dit die Internet-ontdekkingsmarkte (wat 96% oortref het voordat miljoene mense na Firefox en ander blaaiers oorgeskakel het) meestal vernietig. uitgekom het, het mense oorgeskakel vanweë die spoed en dit deur Google (wat destyds nie as boos beskou is nie, aangesien die meeste privaatheidskwessies nog nie aan die lig gekom het nie). Google Chrome het oorspronklik webstandaarde gerespekteer (wat Firefox gedoen het) (wat die internetaandeel van 96% op die internetblaaier vermoor het). Maar namate Google Chromes se markaandeel gestyg het, het Google al hoe meer funksies begin verwyder, meer spyware bygevoeg en nie meer webstandaarde aanvaar nie, Google Chrome het die nuwe Internet Explorer 6 geword.

Die grootste probleem is tans webwerwe wat slegs Chrome is en nie op ander blaaiers sal werk nie, omdat hul ontwikkelaars besluit het dat die ander 30-40% van die internetgebruikers wat Chrome nie gebruik nie, hul webwerf wil gebruik.

Selfs Google maak van hul webwerwe slegs Chrome. Met Google-soektog word u byvoorbeeld gevra om Chrome elke 10 sekondes drie keer af te laai as dit ontdek dat u nie Google Chrome gebruik nie (selfs ander Chromium-gebaseerde blaaiers soos Brave word geraak) en webwerwe soos Google Earth laat Firefox-gebruikers nie toe om dit te doen nie. gebruik hul webwerf (vanaf 2020) plus Google Translate ondersteun nie steminvoer op Firefox en ander nie-Google Chrome-blaaiers.

### Die probleem met dapper

Ander blaaiers wat op Chromium gebaseer is, soos Brave en Microsoft Edge, is nie heeltemal vry van Google-spyware nie. Brave word gewoonlik aanbeveel deur die verkeerde kant van die privaatheidsgemeenskap, maar Brave is steeds 'n probleem omdat dit Chromium gebruik. Die internet moet nie slegs uit Chromium-blaaiers bestaan ​​nie; daar moet 'n verskeidenheid opsies wees. Dapper is die verkeerde manier om te gaan.

[Lees hier meer oor degoogling van Google Chrome / Chromium] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Lees hier meer oor die uitzoeken van ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC)] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Faux privaatheidsvernuwing

Google het probeer om die wêreld te vertel dat hulle omgee vir privaatheid, nadat dit al te laat was. Hulle hou aan om te beweer dat hulle die privaatheid van gebruikers respekteer, maar hulle is nog nie besig om al hul privaatheidsprobleme op te los nie.

### Open source kan nie gedeeltelik wees nie

Open source kan nie gedeeltelik wees nie. Google is 'n bewys hiervan. Elke stukkie en greep van die bronkode moet sigbaar wees vir die publiek, met nie eens 'n 8ste byte verborge nie.

Projekte soos Android en ChromeOS is gedeeltelik open source, maar bevat 'n meerderheid eie, spyware-elemente.

### Oxymoron

Google VPN is 'n oksimoron. Google gee nie om vir privaatheid nie, en 'n VPN (Virtual Private Network) van 'n onderneming soos hulle is een van die slegste moontlike keuses vir 'n VPN-diens.

***

## Slegte prestasie

Google gee nie om vir die prestasies van hul produkte vanaf ten minste 2017 nie, aangesien hul laaste benchmark-sagteware (Google Octane) in 2017 gestaak is.

***

## Slegte projekbestuur

Google het 'n baie slegte interne projekbestuurstelsel. Enkele algemene voorbeelde van programme wat al hoe meer afgegradeer is, sluit in Google Duo en YouTube-musiek (voorheen Google Play Music)

In Google se interne ontwikkelingsstelsel lei een app na 'n ander app met die helfte van die funksionaliteit, dan word die oorspronklike app verwyder. 'N Paar jaar later word 'n nuwe app met 75% minder funksionaliteit gemaak, en dan word die app met 50% funksionaliteit verwyder, gevolg deur 'n nuwe app met 87,5% van die funksies wat geskep word, en dan word die app met 75% funksionaliteit gestaak , en so aan.

***

## Verskriklike of geen matigheid van dienste

YouTube is die mees algemene voorbeeld in die wêreld van slegte matigheid wat die slegste platform bestaan ​​wat bestaan. Dit lyk ook nie asof Google sien dat YouTube nie YouTube-kinders is nie.

Vir YouTube word haatlike pro-Nazi- en White Supremacist-inhoud aan gebruikers bedien met die doel om meer betrokkenheidstyd en meer geld te gee. Google het ook baie gedoendom dinge in hul matigheid, soos om 'n Christelike anale seksvideo goed te keur as 'inhoud vir kinders', terwyl die video terselfdertyd beperk word. Dit is ook nie ongewoon om te sien dat pornografiese of gore-advertensies reg onder die Baby Shark-video verskyn nie, tesame met verskeie ander inhoud vir kinders.

YouTube-gebruikers kla uiters gereeld oor die swak matigheid op YouTube vir slegte inhoud (soos die voorbeelde hierbo genoem), terwyl gebruikers hul video's willekeurig sonder enige rede kan laat verwyder sonder om dit te herroep, en dat gebruikers ook gestraf word vir enige vorm van vloek. selfs baie geringe gevalle soos om te sê 'crap'-gebruikers vergelyk YouTube gewoonlik met die [Sowjetunie] (https://en.wikipedia.org/wiki/Soviet_Union) in die Stalin-era, as gevolg van hierdie ongelyke strawwe.

In 2021 het Google aangekondig dat hulle advertensies op alle video's sal plaas, ten spyte daarvan dat die video gedemoniteer word (sodat Google geld verdien, maar die skepper nie), dit hou nie te veel verband met matigheid nie, maar dit is belangrik om daarop te let.

YouTube word gemodereer (hoewel baie sleg), maar die Google-advertensiediens wat hulle die meeste van hul geld maak, het min of geen matigheid nie.

[Lees meer oor YouTube-modereringskwessies en hoe om van YouTube af te wissel] (https://github.com/seanpm2001/Alternating-from-YouTube)

Advertensies vir Google Play word gegenereer uit botplase. U kan sien aan dieselfde advertensie-scenario's wat deur honderde maatskappye gebruik word, met min veranderinge en geen verband met die produk nie (algemene voorbeelde: Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City, en duisende meer) saam met 'n bloeiende kwaadwillige tendens van advertensies wat beweer dat gebruikers geld kan verdien deur speletjies te speel, na musiek te luister, ens. PayPal het nie hierop kommentaar gelewer nie, maar dit is duidelik dat dit 'n bedrogspul is, asof u dit sou kon maak meer as $ 10 000 in minder as 20 sekondes deur 'n gewaarborgde speletjie te speel, sou niemand werk doen nie en dit eerder doen, wat onmoontlik is, en 'n onderneming kan nie so werk nie. Hierdie voor die hand liggende bedrogspul het sedert 2019 sterk gegroei, en nou veg die botplase wat hierdie advertensies lewer, in hul eie advertensies met mekaar.

Verskeie advertensies is ook baie liederlik en probeer gebruikers (meestal gebruikers onder die ouderdom van 13 jaar, of bots) om seksuele manipulasie te laat kliek.

Baie programme gebruik bots en astroturf hul produkte, dus wanneer 'n slegte resensie gedoen word, sal sock puppet bot-rekeninge 5-ster-resensies begin plaas en u kritiek probeer negeer. [Google doen dit ook self] (# Astroturfing)

[Lees meer oor probleme met Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

Algemene definisie [(vanaf Wikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

''
Astroturfing is die gebruik om die borge van 'n boodskap of organisasie (bv. Politieke, reklame, godsdienstige of openbare betrekkinge) te verbloem om dit te laat voorkom asof dit vandaan kom en ondersteun word deur deelnemers aan die voetsoolvlak. Dit is 'n praktyk wat bedoel is om die verklarings of organisasies geloofwaardigheid te gee deur inligting oor die finansiële verband van die bron te weerhou. Die term astroturfing is afgelei van AstroTurf, 'n merk sintetiese tapyt wat ontwerp is om soos natuurlike gras te lyk, as 'n spel op die woord "grassroots". Die implikasie agter die gebruik van die term is dat in plaas van 'n 'ware' of 'natuurlike' voetsoolvlak-inspanning agter die betrokke aktiwiteit, daar 'n 'valse' of 'kunsmatige' voorkoms van ondersteuning is.
''

Google het 'n geskiedenis van astroturfing om dit te laat lyk asof hulle niks kwaad doen nie (in die proses is astroturfing boos) byvoorbeeld, om kritiek op Google op 'n platform soos Twitter te plaas (waarop hulle 'n rekening het) sal lei tot verskeie rekeninge wat al 'n rukkie bestaan, maar nog nooit voorheen uitgereik is nie en beweer dat dit wat u gesê het onwaar is, en dan beweer dat Google die beste maatskappy is, maar op 'n manier gedoen word dat dit miskien nie voor die hand liggend is dat dit vir die meeste bots is nie mense.

***

## Onwettige en onetiese sakepraktyke

Google gebruik onwettige en onetiese sakepraktyke om hul monopolie te bevorder, soos om belastingparadises te gebruik, werk uit te kontrakteer en om onwettige indringende aktiwiteite voort te sit as 'n koste om sake te doen.

### In Europa

Europa het Google gereeld gedagvaar, die grootste regsgeding teen onwettige gedrag in Android, wat daartoe gelei het dat Google 'n bedrag van € 5.000.000.000 ontvang (gelykstaande aan $ 5.947.083.703,68 in geld van 9 April 2021)

### In Noord-Amerika

Die Verenigde State het nog nie naastenby genoeg boete aan Google gegee nie, vergeleke met die boete van € 5.000.000.000.

### Kontroversies

Google gee nie om vir 'n probleem voordat dit 'n kontroversie skep nie, dan sal hulle 'n swak poging aanwend om dit reg te stel, net genoeg om die kontroversie tydelik te laat verdwyn, en die probleem word dan eksponensieel vererger totdat dit weer 'n kontroversie skep, en die siklus voortduur. Hulle gee eenvoudig nie genoeg om iets ernstigs daaraan te doen nie.

***

## Google is outomaties

As 'n komGoogle is meestal outomaties, met minder moderering as outomatisering.

'N Maatskappy moet nie volledig outomaties wees nie. Google is 'n voorbeeld hiervan. Moderering is verskriklik as dit net deur AI gedoen word, YouTube is 'n goeie voorbeeld, selfs met die ekstra paar (honderde, of miskien duisend) mense wat die webwerf modereer, waar dit blykbaar so sleg is dat die meeste van hulle terapie moet kry terwyl hulle werk.

***

## Android

Android word deur Google besit. 'N Deel van die Open Handset Alliance (wat sedert Android nog nie oop was nie) Android het 'n ander monopolipunt vir Google geword en baie moeilik om te ontsnap.

Daar is berig dat Android minstens tien keer per dag by Google bel, en hoewel dit gedeeltelik open source is, dien dit steeds swaar as spyware.

Verskeie projekte is geskep om van Android af te wissel, maar u moet u toestel wortel. Vanweë die Knox DRM is dit eenvoudig nie meer moontlik vir spesifieke Samsung-telefone in die VS nie. Gewone alternatiewe vir Android sluit iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch en PiPhone in (Pi Phone is 'n handelsmerk van telefone wat verskillende Linux-stelsels op 'n mobiele toestel bestuur, soos Fedora, Ubuntu, Arch, ens.)

[Kyk na my navorsing oor hoe om 'n Android-virtuele masjien funksioneel te ontwikkel] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Kyk hoe om van Android te degoogle] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Klein aksies om te help

Dit is belangrik om bewustheid op elke manier te versprei. Vir my praat ek nie net gereeld oor degoogling nie, en skryf ek artikels, maar ek het ook 'n klein gewoonte, waar ek my daaglikse gratis Reddit-toekenning gee aan die vasgepen pos op r / degoogle om my bewus te maak. Tot dusver het ek byna 30 toekennings aan die vasgepen pos gegee (ek het ook 500 van my gratis munte aan 10 toekennings vir die pos uitgegee)

***

## Onbetroubaar

Google kan nie vertrou word nie, en kan ook nooit weer vertrou word nie. Hulle het heeltemal oorgegaan van 'moenie boos wees nie' (hulle was altyd boos) tot net heeltemal boos wees en dit nie probeer wegsteek nie.

***

## Ander dinge om na te gaan

[Die Google-begraafplaas (killbygoogle.com) - 'n gesorteerde lys van die 224+ produkte wat Google vermoor het] (https://killedbygoogle.com/)

> [GitHub-skakel] (https://github.com/codyogden/killedbygoogle)

[Alphabet workers union - Die nuwe werkersunie by Google met meer as 800 lede] (https://alphabetworkersunion.org/people/our-union/)

[Wil u nie met die dinosourus-paaseier skei nie? Hierdie webwerf behandel u] (https://chromedino.com/)

Daar is ander plaasvervangers, soek net na hulle.

***

Daar is 'n mate van feitekontrole nodig vir hierdie artikel

***

## Lêerinligting

Lêerstipe: 'Markdown (* .md)'

Reëntelling (leë reëls en samestellerreël ingesluit): `968`

Lêerweergawe: '6 (Sondag 18 April 2021 om 16:18 uur)'

***

### Sagtewarestatus

Al my werke is gratis, sommige beperkings. DRM (** D ** igital ** R ** estrictions ** M ** anagement) is in geen van my werke aanwesig nie.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Hierdie plakker word ondersteun deur die Free Software Foundation. Ek is nooit van plan om DRM by my werke in te sluit nie.

Ek gebruik die afkorting "Digital Restrictions Management" in plaas van die meer bekende "Digital Rights Management", aangesien die algemene manier om dit aan te spreek onwaar is; daar is geen regte met DRM nie. Die spelling "Digital Restrictions Management" is akkurater en word ondersteun deur [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) en die [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Hierdie afdeling word gebruik om bewustheid te kweek vir die probleme met DRM, en ook om dit te betoog. DRM is gebrekkig van ontwerp en is 'n groot bedreiging vir alle rekenaargebruikers en sagteware-vryheid.

Beeldkrediet: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Borginligting

[SponsorButton.png] (SponsorButton.png) <- Moenie op hierdie knoppie klik nie, dit werk nie, dit is net 'n beeld. Die regte knoppie is bo-aan die bladsy in die regte (<- L ** R ** ->) hoek

U kan hierdie projek borg as u wil, maar spesifiseer asseblief waaraan u wil skenk. [Sien die fondse waaraan u hier kan skenk] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

U kan ander borginligting hier sien (https://github.com/seanpm2001/Sponsor-info/)

Probeer dit! Die borgknoppie is reg langs die horlosie / oopknop-knoppie.

***

## Lêergeskiedenis



 * Het die lêer begin

> * Het die titelgedeelte bygevoeg

> * Die indeks bygevoeg

> * Het die gedeelte oor bygevoeg

> * Het die Wiki-afdeling bygevoeg

> * Het die afdeling weergawegeskiedenis bygevoeg

> * Die afdeling uitgawes is bygevoeg.

> * Het die afdeling vir vorige uitgawes bygevoeg

> * Het die afdeling vir vorige trekversoeke bygevoeg

> * Het die afdeling vir aktiewe trekversoeke bygevoeg

> * Het die afdeling bydraers bygevoeg

> * Die bydraende afdeling is bygevoeg

> * Het die afdeling README bygevoeg

> * Het die README weergawegeskiedenis-afdeling bygevoeg

> * Het die afdeling hulpbronne bygevoeg

> * Het 'n sagtewarestatusafdeling bygevoeg, met 'n DRM-gratis plakker en boodskap

> *Die afdeling vir borginligting is bygevoeg

> * Geen ander veranderinge in weergawe 0.1 nie

Weergawe 1 (Vrydag 19 Februarie 2021 om 17:20 uur)

> Wysigings:

> * Het die lêer begin

> * Het die basiese beskrywingsafdeling bygevoeg

> * Het die afdeling vir beskrywing van die bewaarplek bygevoeg

> * Het die artikelys bygevoeg, met 14 inskrywings

>> * 'N afdeling met betrekking tot artikels bygevoeg

>> * Voeg 'sien ook "-afdeling by

> * Het die lêerinligting-afdeling bygevoeg

> * Het die lêergeskiedenis-afdeling bygevoeg

> * Die voetskrif is bygevoeg

> * Geen ander veranderinge in weergawe 1 nie

Weergawe 2 (Vrydag 19 Februarie 2021 om 17:26)

> Wysigings:

> * Het die afdeling vir vertalingstatus bygevoeg

> * Het die afdeling 'Ander dinge om na te gaan' bygevoeg

> * Het die privaatheidsafdeling bygevoeg

> * Het 'n indeks bygevoeg

> * Het die onderafdeling van die sagtewarestatus bygevoeg

> * Het die ander anti-Google-veldtogafdeling bygevoeg

>> * Die onderbroke onderafdeling is bygevoeg

>> * Die lopende onderafdeling is bygevoeg

> * Het die bronne-afdeling bygevoeg

> * Het die afdeling vir aflaai-skakels bygevoeg

> * Het die lêerinligting-afdeling opgedateer

> * Die afdeling vir lêergeskiedenis is opgedateer

> * Geen ander veranderinge in weergawe 2 nie

Weergawe 3 (Woensdag 24 Februarie 2021 om 19:56 uur)

> Wysigings:

> * Die indeks is opgedateer

> * Verwys na die degoogle-ikoon en die nuwe GitHub-organisasie

> * Bygevoeg skakels na nuwer artikels

> * Die afdeling teen ander argumente bygevoeg

>> * Die onderafdeling gerief het bygevoeg

>> * Het die subartikel Why even bother bygevoeg

>> * Het die ander onderafdeling bygevoeg

> * Sommige data is opgedateer

> * Het die lêerinligting-afdeling opgedateer

> * Die afdeling vir lêergeskiedenis is opgedateer

> * Geen ander veranderinge in weergawe 3 nie

Weergawe 4 (Donderdag 25 Februarie 2021 om 21:31 uur)

> Wysigings:

> * Skakels bygevoeg na tien nuwe artikels

> * Het 'n gedeelte bygevoeg oor my ervaring

> * Die indeks is opgedateer

> * Het die lêerinligting-afdeling opgedateer

> * Die afdeling vir lêergeskiedenis is opgedateer

> * Geen ander veranderinge in weergawe 4 nie

Weergawe 5 (Vrydag 9 April 2021 om 18:02 uur)

_ Daar is onlangs 'n gebrek aan updates vir die anti-Google-beweging van my, ek werk daaraan om na 'n onderbreking van meer as 1 maand terug te keer.

> Wysigings:

> * Die titelafdeling is opgedateer

> * Die indeks is opgedateer

> * Het die taallys opgedateer: vaste skakels, en meer ondersteunde tale bygevoeg

> * Die artikelstatus-afdeling is opgedateer deur vier vurkskakels by te voeg

> * Die afdeling vir sagtewarestatus is opgedateer

> * Die Go is evil-afdeling het bygevoeg

> * Het die gebruik van DRM-afdeling bygevoeg

> * Die afdeling Algemene wanopvattings is bygevoeg

>> * Bygevoeg dat Google nie die onderafdeling Internet is nie

> * Het die Internet Explorer 6 en Chrome-afdeling bygevoeg

>> * Het die probleem met dapper onderafdeling bygevoeg

> * Het die verwydering van privaatheid van Faux bygevoeg

> * Bygevoeg die Open source kan nie gedeeltelike onderafdeling wees nie

> * Die onderafdeling Oxymoron is bygevoeg

> * Het die afdeling Slegte prestasie bygevoeg

> * Het die afdeling Slegte projekbestuur bygevoeg

> * Het die afdeling Horrible of no moderation of services bygevoeg

> * Het die afdeling Astroturfing bygevoeg

> * Het die afdeling Onwettige en onetiese sakepraktyke bygevoeg

> * Die onderafdeling In Europa is bygevoeg

>> * Die onderafdeling In Noord-Amerika is bygevoeg

>> * Die onderafdeling Controversies is bygevoeg

> * Die Google is outomatiese afdeling bygevoeg

> * Het die Android-afdeling bygevoeg

> * Het die afdeling Klein aksies bygevoeg

> * Het die gedeelte wat nie betroubaar is nie, bygevoeg

> * Het die borginligting-afdeling bygevoeg

> * Die voetskrif is opgedateer

> * Het die lêerinligting-afdeling opgedateer

> * Die afdeling vir lêergeskiedenis is opgedateer

> * Geen ander veranderinge in weergawe 5 nie

Weergawe 6 (Sondag 18 April 2021 om 16:18 uur)

> Wysigings:

> * Die indeks is opgedateer

> * Het 'n nuwe oorsigbeskrywing bygevoeg

> * Opgedateerde artikelstatusinligting

> * Het 'n skakel bygevoeg na die nuwe Google FLoC-artikel

> * Het 'n skakel na Wuest 3n Fuchs Degoogle-artikel en algemene inligting daaroor bygevoeg

> * Het die lêerinligting-afdeling opgedateer

> * Die afdeling vir lêergeskiedenis is opgedateer

> * Geen ander veranderinge in weergawe 6 nie

Weergawe 7 (binnekort beskikbaar)

> Wysigings:

> * Binnekort beskikbaar

> * Geen ander veranderinge in weergawe 7 nie

Weergawe 8 (binnekort beskikbaar)

> Wysigings:

> * Binnekort beskikbaar

> * Geen ander veranderinge in weergawe 8 nie

Weergawe 9 (binnekort beskikbaar)

> Wysigings:

> * Binnekort beskikbaar

> * Geen ander veranderinge in weergawe 9 nie

Weergawe 10 (binnekort beskikbaar)

> Wysigings:

> * Binnekort beskikbaar

> * Geen ander veranderinge in weergawe 10 nie

Weergawe 11 (Binnekort beskikbaar)

> Wysigings:

> * Binnekort beskikbaar

> * Geen ander veranderinge in weergawe 11 nie

Weergawe 12 (binnekort beskikbaar)

> Wysigings:

> * Binnekort beskikbaar

> * Geen ander veranderinge in weergawe 12 nie

***

## Voetskrif

U het die einde van hierdie lêer bereik

([Terug na bo] (# Top) | [Terug na GitHub] (https://github.com))

### EOF

***
