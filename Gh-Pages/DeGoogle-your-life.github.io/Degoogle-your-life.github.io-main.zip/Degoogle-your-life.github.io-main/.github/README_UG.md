***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - ھاياتىڭىزنى Degoogle

بۇ ئادەتتىكى چېكىنىش ئۇچۇرلىرىنىڭ ئاساسلىق چۈشكۈنلۈك ماقالىسى ۋە باشقا ماقالىلەرنىڭ ئۇلىنىشى.

[تىزىملىكنى GitHub تەشكىلاتى سۈپىتىدە كۆرۈڭ] (https://github.com/Degoogle-your-life)

***

_ بۇ ماقالىنى باشقا تىلدا ئوقۇڭ: _

** ھازىرقى تىل: ** `ئىنگلىزچە (US)` _ (توغرا تىلنىڭ ئورنىنى ئالغان ئىنگلىزچىنى تۈزىتىش ئۈچۈن تەرجىمىلەرنى تۈزىتىشكە توغرا كېلىدۇ) _

_🌐 تىللار تىزىملىكى_

** رەتلىگەن: ** `A-Z`

[تاللاش تۈرلىرىنى ئىشلەتكىلى بولمايدۇ] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) ئافرىقىلىقلار | [sq Shqiptare] (/. (/.github/README_AR.md) ئەرەبچە | [hy հայերեն] (/. github / README_HY.md) ئەرمېنىيە | /README_EU.md) باسك | [be Беларуская] بوسنىيە | [bg българсki] (/. Github / README_BG.md) بۇلغارىيە | [ca Català] (/. ] (/. github / README_NY.md) چىچېۋا | [zh-CN 简体 中文] (/. -T.md) خەنزۇچە (ئەنئەنىۋى) | [co Corsu] (/. Github / README_CO.md) كورسىكان | [hr Hrvatski] (/. .md) چېخ | [da dansk] (README_DA.md) دانىيە | [nl Nederlands] (/. github / README_ NL.md) گوللاندىيە | [** en-us English **] (/. github / README.md) ئىنگلىز تىلى | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) ئېستونىيە | [tl Pilipino] (/. github / README_TL.md) فىلىپپىن | [fi Suomalainen] (/. github / README_FI.md) فىنلاندىيە | [fr français] (/. github / README_FR.md) فىرانسۇزچە | [fy Frysk] (/. github / README_FY.md) فرىسيان | [gl Galego] (/. github / README_GL.md) گالىسىيە | [ka ქართველი] (/. github / README_KA) گرۇزىيە | [de Deutsch] (/. github / README_DE.md) گېرمان | [el Ελληνικά] (/. github / README_EL.md) گرېتسىيە | [gu ગુજરાતી] (/. github / README_GU.md) گۇجارات | [ht Kreyòl ayisyen] (/. github / README_HT.md) ھايتى كرېئول | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) ھاۋاي | [he עִברִית] (/. github / README_HE.md) ئىبرانىي | [hi हिन्दी] (/. github / README_HI.md) ھىندى | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) ۋېنگرىيە | [Íslenska] (/. github / README_IS.md) ئىسلاندىيە | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa ھىندونېزىيە] (/. github / README_ID.md) ئىسلاندىيە | [ga Gaeilge] (/. github / README_GA.md) ئىرېلاندىيە | [italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) ياپون | [jw Wong jawa] (/. github / README_JW.md) Javanese | [kn ಕನ್ನಡ] (/. github / README_KN.md) كاننادا | [kk Қазақ] (/. github / README_KK.md) قازاقىستان | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) كورېيە (جەنۇب) | [ko-north 문화어] (README_KO_NORTH.md) كورېيە (شىمالىي) (تەرجىمە قىلىنمايدۇ) | [ku Kurdî] (/. github / README_KU.md) كۇردچە (Kurmanji) | [ky Кыр ччача] (/. github / README_KY.md) قىرغىزىستان | [lo ລາວ] (/. github / README_LO.md) لائوس | [la Latine] (/. github / README_LA.md) لاتىنچە | [lt Lietuvis] (/. github / README_LT.md) لىتۋانىيە | [lb Lëtzebuergesch] (/. github / README_LB.md) لىيۇكسېمبۇرگ | [mk Македонски] (/. github / README_MK.md) ماكېدونىيە | [mg Malagasy] (/. github / README_MG.md) مالاگاسى | [ms Bahasa Melayu] (/. github / README_MS.md) مالاي | [ml മലയാളം] (/. github / README_ML.md) مالايالام | [mt Malti] (/. github / README_MT.md) مالتا | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) مارااتى | [mn مونگول] (/. github / README_MN.md) موڭغۇل | [my မြန်မာ] (/. github / README_MY.md) بېرما (بېرما) | [ne नेपाली] (/. github / README_NE.md) نېپال | [no norsk] (/. github / README_NO.md) نورۋېگچە | [ياكى يىزا (زاندا)) (/. github / README_OR.md) ئۇيغۇرچە (ئۇيغۇرچە) | [ps پښتو] (/. github / README_PS.md) پۇشتۇ | [fa فارسی] (/. github / README_FA.md) | پارسچە [pl polski] (/. github / README_PL.md) پولشا | [pt português] (/. github / README_PT.md) پورتۇگالچە | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) پەنجاپ | Q | ھەرىپى بىلەن باشلانغان تىل يوق [ro Română] (/. github / README_RO.md) رۇمىنىيە | [ru русский] (/. github / README_RU.md) رۇسچە | [sm Faasamoa] (/. github / README_SM.md) ساموئان | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) شوتلاندىيە گال تىلى | [sr Српски] (/. github / README_SR.md) سېربىيە | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) شونا | [sd سنڌي] (/. github / README_SD.md) سىندى | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) سلوۋاكىيە | [sl Slovenščina] (/. github / README_SL.md) سىلوۋېنىيە | [شۇڭا سومالى] (/. github / README_SO.md) سومالى | [[es en español] (/. github / README_ES.md) ئىسپانچە | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) شىۋىتسىيە | [tg Тоҷикӣ] (/. github / README_TG.md) تاجىك | [ta தமிழ்] (/. github / README_TA.md) تامىل | [tt Т за] (/. github / README_TT.md) تاتار | [te తెలుగు] (/. github / README_TE.md) تېلۇگۇ | [th ไทย] (/. github / README_TH.md) تايلاند | [tr Türk] (/. github / README_TR.md) تۈرك | [tk Türkmenler] (/. github / README_TK.md) تۈركمەن | [uk Український] (/. github / README_UK.md) ئۇكرائىنا | [ur اردو] (/. github / README_UR.md) ئوردۇچە | [ئۇي ئۇي غۇر غۇر غۇر ((ug ug (ug ((] / ((( [uz O'zbek] (/. github / README_UZ.md) ئۆزبېك | [vi Tiếng Việt] (/. github / README_VI.md) ۋېيتنام | [cy Cymraeg] (/. github / README_CY.md) ۋېلىش | [xh isiXhosa] (/. github / README_XH.md) جوسا | [yi יידיש] (/. github / README_YI.md) يىددىش | [yo Yoruba] (/. github / README_YO.md) يورۇبا | [zu Zulu] ) /README.md))

ئىنگلىز تىلىدىن باشقا تىللاردىكى تەرجىمە ماشىنا تەرجىمە قىلىنغان بولۇپ ، تېخى توغرا ئەمەس. 2021-يىلى 2-ئاينىڭ 5-كۈنىگىچە ھېچقانداق خاتالىق تۈزىتىلمىدى. تەرجىمە خاتالىقلىرىنى دوكلات قىلىڭ (بۇ يەردە) ، مەن ئىنگلىز تىلىدىن باشقا تىللارنى ياخشى بىلمىگەچكە (ئاخىرىدا تەرجىمان ئېلىشنى پىلانلاۋاتىمەن) دوكلاتىڭىزدىكى [wiktionary] (https://en.wiktionary.org) ۋە باشقا مەنبەلەرنى نەقىل كەلتۈرۈڭ. بۇنداق قىلماسلىق تۈزىتىشنىڭ ئېلان قىلىنىشىنى رەت قىلىدۇ.

ئەسكەرتىش: GitHub نىڭ بەلگە بەلگىسىنى ئىزاھلىشىدىكى چەكلىمىلەر سەۋەبىدىن (ۋە باشقا تور بەتتىكى بەلگە بەلگىسىنى چۈشەندۈرۈش) بۇ ئۇلىنىشلارنى چەكسىڭىز ، مېنىڭ GitHub ئارخىپ بېتىم بولمىغان ئايرىم بەتتىكى ئايرىم ھۆججەتكە يۆتكىلىدۇ. سىز README ساھىبخانلىق قىلىدىغان [seanpm2001 / seanpm2001 ئامبىرى] (https://github.com/seanpm2001/seanpm2001) غا قايتا ئۇلىنىسىز.

تەرجىمە GoogleL تەرجىمىسى بىلەن DeepL ۋە Bing Translate غا ئوخشاش باشقا تەرجىمە مۇلازىمەتلىرىدە لازىملىق تىللارنى قوللاش ياكى قوللىماسلىق سەۋەبىدىن ئېلىپ بېرىلىدۇ (گۇگۇلغا قارشى تۇرۇش پائالىيىتى ئۈچۈن تولىمۇ مەسخىرە) مەن باشقا تاللاشنى ئىزدەۋاتىمەن. مەلۇم سەۋەبلەر تۈپەيلىدىن فورماتلاش (ئۇلىنىش ، بۆلگۈچ ، دادىل ، يانتۇ خەت قاتارلىقلار) ھەر خىل تەرجىمىلەردە قالايمىقان. ئوڭشاش زېرىكىشلىك ، مەن بۇ مەسىلىلەرنى لاتىنچە بولمىغان ھەرپلەر بىلەن قانداق ھەل قىلىشنى بىلمەيمەن ، بۇ مەسىلىلەرنى ئوڭشاشتا ئوڭدىن سولغا (ئەرەبچىگە ئوخشاش) قوشۇمچە ياردەم لازىم.

ئاسراش مەسىلىسى سەۋەبىدىن ، نۇرغۇن تەرجىمىلەرنىڭ ۋاقتى ئۆتكەن بولۇپ ، بۇ «README» ماقالە ھۆججىتىنىڭ ۋاقتى ئۆتكەن نەشرىنى ئىشلىتىۋاتىدۇ. تەرجىمان لازىم. شۇنداقلا ، 2021-يىلى 4-ئاينىڭ 9-كۈنىگىچە ، بارلىق يېڭى ئۇلىنىشلارنى ئىشلەشكە بىر ئاز ۋاقىت كېتىدۇ.

***

## Index

[00.0 - ماۋزۇ] (# Degoogling --- Degoogle- ھاياتىڭىز)

> [00.1 - كۆرسەتكۈچ] (# كۆرسەتكۈچ)

[01.0 - ئاساسىي چۈشەندۈرۈش] (# Basic-description)

> [01.1 - ئامبار ماۋزۇسى] (# Degoogle- ھاياتىڭىز)

> [01.2 - Wuest3NFuchs چۈشەندۈرۈش ئومۇمىي كۆرۈنۈشى] (# ئومۇمىي كۆرۈنۈش ئارقىلىق Wuest3nFuchs)

>> [01.2.1 - بۇ نېمىدىن دېرەك بېرىدۇ؟] (# Wuest3nFuchs نىڭ مەنىسى)

>> [01.2.2 - نېمىشقا Degoogle؟] (# نېمىشقا Degoogle - by-Wuest3nFuchs)

[02.0 - ماقالىلەر] (# ماقالىلەر)

[03.0 - مەخپىيەتلىك] (# مەخپىيەتلىك)

[04.0 - گۇگۇلغا قارشى باشقا تەشۋىقاتلار] (# گۇگۇلغا قارشى باشقا تەشۋىقاتلار)

> [04.0.1 - بۇزۇلغان] (# بۇزۇلغان)

> [04.0.2 - داۋاملىشىۋاتىدۇ] (# داۋاملىشىۋاتىدۇ)

[05.0 - باشقا تالاش-تارتىشلارغا قارشى تۇرۇش] (# Countering-other-argument)

> [05.0.1 - قۇلايلىق] (# قۇلايلىق)

> [05.0.2 - نېمىشقا مۇھىم؟ قانداقلا بولمىسۇن بەك كېچىكىپ كەتتى] (# نېمە ئۈچۈن مۇھىم ، -ھەم كېچىكىدۇ)

> [05.0.3 - باشقا] (# باشقا)

[06.0 - مەنبە] (# مەنبە)

[07.0 - چۈشۈرۈش ئۇلانمىلىرى] (# چۈشۈرۈش-ئۇلىنىش)

[08.0 - مېنىڭ چېكىنىش كەچۈرمىشىم] (# مېنىڭ چۈشكۈنلۈك كەچۈرمىشىم)

> [08.1 - مەن ئالماشتۇرغىنىم] (# مەن-مەن ئالماشتۇرغان)

> [08.2 - مەن يەنىلا يىراقلاپ كېتەلمەيدىغان مەھسۇلاتلار] (# مەھسۇلاتلار-مەن يەنىلا يىراقلاپ كېتەلمەيمەن)

[09.0 - تەكشۈرۈشكە تېگىشلىك باشقا ئىشلار] (# باشقا نەرسىلەرنى تەكشۈرۈش)

[10.0 - ھۆججەت ئۇچۇرى] (# ھۆججەت-ئۇچۇر)

> [10.1 - يۇمشاق دېتال ھالىتى] (# يۇمشاق دېتال ھالىتى)

> [10.2 - ياردەم بەرگۈچىلەر ئۇچۇرى] (# ياردەم بەرگۈچى-ئۇچۇر)

[11.0 - ھۆججەت تارىخى] (# ھۆججەت-تارىخ)

[12.0 - بەت ئاستى] (# بەت ئاستى)

***

## Basic description

[ۋىكىپېدىيەدىن: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

DeGoogle ھەرىكىتى (گۇگۇلنى ئەمەلدىن قالدۇرۇش ھەرىكىتى دەپمۇ ئاتىلىدۇ) ئاساسىي قاتلام پائالىيىتى بولۇپ ، مەخپىيەتلىك پائالىيەتچىلىرى ئابونتلارنى شىركەتكە مۇناسىۋەتلىك مەخپىيەتلىك ئەندىشىسىنىڭ كۈچىيىشى سەۋەبىدىن ئابونتلارنى گۇگۇل مەھسۇلاتلىرىنى ئىشلىتىشنى پۈتۈنلەي توختىتىشقا ئۈندەيدۇ. بۇ سۆز گۇگۇلنى ھاياتىدىن چىقىرىۋېتىش ھەرىكىتىنى كۆرسىتىدۇ. ئىنتېرنېت ماگناتىنىڭ بازار ئۈلۈشىنىڭ كۈنسېرى ئېشىۋاتقانلىقى رەقەملىك بوشلۇقتا شىركەت ئۈچۈن مونوپوللۇق كۈچ پەيدا قىلغاچقا ، مۇخبىرلارنىڭ سانىنىڭ ئېشىشى شىركەتنىڭ مەھسۇلاتلىرىنىڭ ئورنىنى ئېلىشنىڭ قىيىنلىقىنى كۆرسەتتى.

** تارىخ **

2013-يىلى ، Venturebeat دىكى John Koetsier ئامازوننىڭ Kindle Fire ئاندىرويىدنى ئاساس قىلغان تاختا كومپيۇتېرنىڭ «گۇگۇلنىڭ چوڭلۇقىدىكى ئاندىرويىد نۇسخىسى» ئىكەنلىكىنى ئېيتتى. 2014-يىلى ئامېرىكا خەۋەرلىرىدىكى جون سىمپسون گۇگۇل ۋە باشقا ئىزدەش ماتورلىرىنىڭ «ئۇنتۇلۇش ھوقۇقى» ھەققىدە يازغان. 2015-يىلى ، ئىرېلاندىيە ۋاقىت گېزىتىدىكى دېرېك سكاللى «ھاياتىڭىزنى گۇگۇلدىن قانداق قىلىش» توغرىسىدا ماقالە يازغان. 2016-يىلى ئاندرويلىق كىرىس كارلونd ئورگان تەرەپ CyanogenMod 14 ئىشلەتكۈچىلىرىنىڭ تېلېفونىنى «گۇگۇلدىن ئۆچۈرۈۋېتىشى» نى تەۋسىيە قىلدى ، چۈنكى CyanogenMod گۇگۇل ئەپلىرىمۇ ياخشى ئىشلىمەيدۇ. 2018-يىلى Inverse دىكى Nick Lucchesi ProtonMail نىڭ قانداق قىلىپ «ھاياتىڭىزنى پۈتۈنلەي گۇگۇلدىن ئۆچۈرۈۋېتەلەيدىغانلىقى» نى تەشۋىق قىلىۋاتقانلىقى توغرىسىدا يازغان. Lifehacker دىكى Brendan Hesse «گۇگۇلدىن چېكىنىش» توغرىسىدا تەپسىلىي دەرسلىك يازغان. Gizmodo ژۇرنالىست كەشمىر خىلل ئۆزىنىڭ ئۇچرىشىشنى قولدىن بېرىپ قويغانلىقىنى ۋە گۇگۇل كالېندارىنى ئىشلەتمەي تۇرۇپ ئۇچرىشىشنى تەشكىللەشتە قىيىنچىلىققا دۇچ كەلگەنلىكىنى ئوتتۇرىغا قويدى. گۇگۇل تەمىنلىگەن مۇلازىمەتنى ئىشلىتىشتىن چەكلەنگەن ، چۈنكى باشقا تاللاشلار ناھايىتى ئاز بولغاچقا ، شىركەتنىڭ مەھسۇلاتلىرىنىڭ بولماسلىقى تورنى نورمال ئىشلىتىشنى مۇمكىنسىز قىلغان.

***

# Degoogle- ھاياتىڭىز
ئادەتتىكى چۈشۈش ئۇچۇرلىرى ئامبىرى ۋە باشقا باشقا ئامبارلىرىمنىڭ ئۇلىنىشى.

***

## Wuest3nFuchs نىڭ ئومۇمىي ئەھۋالى

تېخىمۇ ياخشى تەسۋىر ، [Wuest3nFuchs] تەمىنلىگەن (https://github.com/Wuest3nFuchs) - مەنبە: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### بۇ نېمىدىن دېرەك بېرىدۇ؟ by Wuest3nFuchs

Degoogling دېگەنلىك گۇگۇلغا تەۋە ھەرقانداق نەرسىنى ، گۇگۇل تەرىپىدىن ياسالغان ھەرقانداق نەرسىنى ئىشلىتىشنى توختىتىشنى كۆرسىتىدۇ. مەن ئۇلارنىڭ ئىزدەش ماتورى ، ئۇلارنىڭ خەت مۇلازىمىتى (Gmail) ، Youtube قاتارلىقلار ھەققىدە سۆزلەۋاتىمەن.

### نېمىشقا Degoogle؟ by Wuest3nFuchs

گۇگۇل ھازىر دۇنيادىكى ئەڭ كۈچلۈك شىركەتلەرنىڭ بىرى. ئۇلار ھەممىمىزگە نۇرغۇن ئۇچۇرلارنى ساقلىدى. بەزىلەر ئۇچۇرلىرىمىزنى ئۇلار بىلەن بىخەتەر دەپ قارايدۇ ، چۈنكى ئۇلار ئۇنى قانداق قوغداشنى بىلىدۇ. ئەمما بۇ ئەمەلىيەت ئەمەس. گۇگۇل ئىلگىرى سىڭىپ كىرگەن بولۇپ ، كەلگۈسىدە سىڭىپ كىرىدۇ. بەلكىم بەزى قوليازما چاقچاقلىرى بىلەن ئەمەس ، بەلكى ئۇنى بىر دۆلەت دۆلىتى قىلىدۇ. گۇگۇل ھەممىمىزگە شەخسىي ئۇچۇرلارنى ساقلايدۇ ، چۈنكى ئۇلارنىڭ پۇل تېپىشى مانا مۇشۇنداق.

ئۇلار ئېلېكترونلۇق خەتلىرىمىزنى سايىلەيدۇ ، بىز ئىزدەش ماتورىنى ئىشلەتكەندە نېمىلەرنى ئىزدەيمىز ، Youtube دا قايسى سىنلارنى كۆرىمىز. ئۇلار بىزنى نىشانلاپ ، بىزگە بىر ئارخىپ تۇرغۇزۇپ ، ئەڭ يېقىن دوستىمىز بىلەن پاراڭلاشقانلىرىمىزغا ئاساسەن بىزگە بىر قىسىم ئېلانلارنى كۆرسىتىپ بېرىدۇ ، شۇڭا ئۇلار بىزگە لازىملىق نەرسىنىڭ ئېلانىنى كۆرسىتىپ بېرەلەيدۇ ، ئەمما بۇ بەك ئىتتىك. سىنوۋدېن ئەپەندىگە رەھمەت ، بىز ھازىر گۇگۇلنىڭ شەخسىي ئۇچۇرلىرىمىزنى NSA بىلەن ** «PRISM» ** ناملىق پروگراممىدا ھەمبەھىرلىگەنلىكىنى بىلدۇق.


كەلگۈسىدە بىرەيلەن بۇ ئۇچۇرلارنىڭ ھەممىسىنى زىيارەت قىلالايدۇ ، مەن سىزگە ھەقىقەتەن بىر يامان ئىشنىڭ يۈز بېرىدىغانلىقىنى كاپالەتلەندۈرىمەن. بۇنداق ئەھۋالنىڭ يۈز بېرىشىنىڭ ئالدىنى ئېلىش ئۈچۈن ، ھازىر Degoogling نى باشلىشىڭىز كېرەك. يەنە سانلىق مەلۇماتلىرىڭىزنى ** NSA ** بىلەن ئورتاقلىشىدىغان شىركەت مەھسۇلاتلىرىنى ئىشلەتمەسلىكىڭىز لازىم. سىز تۆۋەنگە چۈشۈش ئارقىلىق بۇلارنىڭ ھەممىسىنى توختىتىشىڭىز كېرەك.

** ئەگەر باشقىلار قىلالايدىغان بولسا ، سىزمۇ قىلالايسىز. **

[بۇ يەرنى تېخىمۇ كۆپ ئوقۇڭ] (https://github.com/Wuest3nFuchs/Degoogle)

<! - مەن بۇ ئامبارغا پۈتۈنلەي ئىگىدارچىلىق قىلمىغاچقا ، باشقا مەنبەلەرنى تەشۋىق قىلماقچى بولغانلىقىم ئۈچۈن ، چاتقالغا ئۇلىنىش ھازىرلانمىدى. ئۆزۈمنىڭ https://github.com/Degoogle-your-life/Degoogle غا ئۇلىنىش شەخسىيەتچىلىك بولىدۇ! ->

***

## ماقالىلەر

### ماقالە ھالىتى

_ بارلىق ماقالىلەر ھازىر ئېلىپ بېرىلىۋاتقان خىزمەت بولۇپ ، كەڭ كۆلەمدە ياخشىلاشقا موھتاج. تەكلىپ ۋە تۈزىتىشكە رۇخسەت قىلىنىدۇ ._

_ 2021-يىل 4-ئاينىڭ 18-كۈنى چۈشتىن كېيىن سائەت 4:09 دە ، كۆپىنچە ماقالىلەر تېخى باشلانمىدى. مەن ئۇلارنى باشلاش ئۈچۈن ۋاقىت ۋە كۈچ تېپىش ئۈچۈن تىرىشىۋاتىمەن ._

[نېمىشقا گۇگۇل Chrome نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمىشقا- نېمە ئۈچۈن توختاپ قېلىش- خىروم) <! - 1! ->

[ChromeBook نى ئىشلىتىشنى توختىتىڭ] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[WideVine DRM نى ئىشلىتىشنى توختىتىڭ / WideVine DRM نى كېسىدىغان پەيت كەلدى] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[نېمىشقا ReCaptcha نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[YouTube دىن ئالمىشىش] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[گۇگۇلنى توختىتىڭ ، نېمىشقا گۇگۇل ئىزدەشنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Stop-Googling-- نېمىشقا- نېمىشقا توختاپ قېلىش- گۇگۇل ئىزدەش) <! - 6! - >

[نېمىشقا Gmail نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[نېمىشقا ئاندىرويىدنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمە ئۈچۈن- ئاندىرويىدنى ئىشلىتىشىڭىز كېرەك؟)

[نېمىشقا Google Amp دىن ساقلىنىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[نېمىشقا Google Drive نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[نېمىشقا گۇگۇل خەرىتىسى ۋە گۇگۇل يەرشارىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمىشقا- نېمىشقا توختاپ قالماسلىقىڭىز كېرەك؟ گۇگۇل خەرىتىلىرى ۋە گۇگۇل يەرلىرى) <! - 11! - ->

[ھەي گۇگۇل ، توختاڭ] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Google / Play كىتابلىرىدىن ئوقۇشنى توختىتىڭ] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Google دەرسخانىسىنى ئىشلىتىشنى توختىتىڭ] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[نېمىشقا گۇگۇل تەرجىمىسىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمىشقا- نېمىشقا توختاپ قالىسىز- Google- تەرجىمە) <! - 15! ->

[نېمىشقا Google ھېساباتىڭىزنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Accounts) <! - 16! ->

** پات يېقىندا يېزىلىدىغان يېڭى ماقالىلەر: **

[نېمىشقا Gerrit نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[نېمىشقا Google Analytics نى ئىشلىتىشنى توختىتىشىڭىز كېرەك (بۇ ئامبار 2021-يىلى 2-ئاينىڭ 24-كۈنى چارشەنبە چۈشتىن كېيىن سائەت 4:13 دە ئاخىرلىشىدۇ)] -Google-Analytics) <! - 18! ->

<! - خىزمەت بۆلگۈچى! ->

[نېمىشقا Google AdSense نى ئىشلىتىشنى توختىتىشىڭىز كېرەك]

[نېمىشقا Google One نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[نېمىشقا Google+ (توختاپ قالغان) نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمىشقا- نېمىشقا توختاپ قېلىشتىن توختىتىسىز؟)! - 21! ->

[نېمىشقا Google Play دۇكىنىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمە ئۈچۈن- Google- ئويۇن قويۇش دۇكىنىنى نېمىشقا توختىتىسىز) <! - 22! ->

[نېمىشقا Google Docs نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23!

[نېمىشقا گۇگۇل تام تەسۋىرنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمىشقا- نېمىشقا- Google- سىيرىلىشنى توختىتىسىز) <! - 24! ->

[نېمىشقا گۇگۇل جەدۋىلىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمىشقا- نېمىشقا- Google- جەدۋەلنى توختىتىسىز) <! - 25! ->

[نېمىشقا گۇگۇل جەدۋىلىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمە ئۈچۈن- Google-Forms نى ئىشلىتىسىز؟) <! - 26! ->

[نېمىشقا Google Cardboard نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمىشقا- نېمىشقا- Google- كارتا تاختىسىدىن توختىتىسىز) <! - 27! ->

[نېمىشقا گۇگۇل ئۇچۇرلىرىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمىشقا- نېمىشقا- Google- ئۇچۇرلىرى) نى ئىشلىتىسىز؟ <! - 28! ->

[نېمىشقا گۇگۇل ماتېرىيال لايىھىسىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمە ئۈچۈن- Google- ماتىرىيال لايىھىلەش) <! - 29! ->

[نېمىشقا گۇگۇل ئەينەك / كۆزئەينەك ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمىشقا- نېمىشقا- توختاپ قېلىشتىن ساقلىنىش- Google- ئەينەك)

[نېمىشقا گۇگۇل فۇچسىيەنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمە ئۈچۈن- نېمىشقا Google-Fuchsia نى توختىتىسىز) <! - 31! ->

[نېمىشقا GBoard نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[نېمىشقا Google Home نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[نېمىشقا Google Nest نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34!

[نېمىشقا Google Hangout (توختاپ قالغان) نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمىشقا- نېمە ئۈچۈن- Google-Hangouts) نى ئىشلىتىڭ؟

[نېمىشقا گۇگۇل Duo نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمىشقا- نېمىشقا- Google-Duo نى ئىشلىتىسىز) <! - 36! ->

[نېمىشقا Google Tensorflow نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمىشقا- نېمىشقا توختاپ قېلىشتىن توختىتىسىز؟)

[نېمىشقا Google Blockly نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38!

[نېمىشقا Google Flutter نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمىشقا- نېمىشقا- توختاپ قېلىشتىن ۋاز كېچىش)

[نېمىشقا Googles Go پروگرامما تىلىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك؟)

[نېمىشقا Googles Dart پروگرامما تىلىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمىشقا- نېمىشقا توختاپ قېلىشتىن توختىتىسىز)

[نېمىشقا Googles WebP رەسىم فورماتىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك]

[نېمىشقا Googles WebM سىن فورماتىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك]

[نېمە ئۈچۈن Google Video نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44!

[نېمىشقا گۇگۇل تور بېكەتلىرىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك (كلاسسىك)] (https://github.com/seanpm2001/ نىمىشقا نېمىشقا توختاپ قېلىشتىن توختىتىسىز؟

[نېمىشقا گۇگۇل تور بېكەتلىرىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك ("يېڭى")] (https://github.com/seanpm2001/ نىمە ئۈچۈن- Google- بېكەتلەر_ يېڭى) <! - 46! ->

[نېمىشقا Google Pay نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[نېمىشقا ئاندىرويىد ھەق تۆلەشنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمە ئۈچۈن- ئاندىرويىد- پۇل تۆلەشتىن توختىتىسىز) <! - 48! ->

[نېمىشقا Google VPN (oxymoron) نى ئىشلىتىشنى توختىتىشىڭىز كېرەك])

[نېمىشقا گۇگۇل رەسىملىرىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمىشقا- نېمە ئۈچۈن- گۇگۇل-سۈرەتلەر) <! - 50! ->

[نېمىشقا گۇگۇل كالېندارىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمىشقا- نېمىشقا- Google- كالېندارنى تاللايسىز) <! - 51! ->

[نېمە ئۈچۈن VirusTotal نى ئىشلىتىشنى توختىتىشىڭىز كېرەك (چۈنكى ئۇ 2012-يىلى 9-ئايدىن باشلاپ گۇگۇلنىڭ ئىگىدارچىلىقىدا بولغاچقا) >

[نېمىشقا Google Fi نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fi) <! - 53! ->

[نېمىشقا گۇگۇل ستادىيىسىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمىشقا- نېمىشقا توختاپ قېلىشتىن ساقلىنىش- گۇگۇل- ستادىيە) <! - 54! ->

[نېمىشقا Google Keep نى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمىشقا- نېمە ئۈچۈن- Google- ساقلاپ قويۇڭ) <! - 55! ->

[نېمىشقا گۇگۇل بازىسىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمىشقا- نېمىشقا- Google-Base نى ئىشلىتىسىز) <! - 56! ->

[نېمىشقا گۇگۇل يازلىق كودقا قاتنىشىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمىشقا- نېمىشقا توختاپ قېلىشتىن ساقلىنىش- گۇگۇل- يازلىق كود) <! - 57! - >

[نېمىشقا گۇگۇل كامېراسىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمىشقا- نېمىشقا- Google- كامېرا) <! - 58! ->

[نېمىشقا گۇگۇل ھېسابلىغۇچنى ئىشلىتىشنى توختىتىشىڭىز كېرەك (قارىماققا چېكىدىن ئاشقاندەك قىلسىمۇ ، ئەمما سىز ھەممە نەرسىدىن ۋاز كېچىشىڭىز كېرەك ، ئالمىشىش ئىنتايىن ئاسان)] (https://github.com/seanpm2001/ نىمىشقا؟ ھېسابلىغۇچ) <! - 59! ->

[نېمىشقا گۇگۇل تەكشۈرۈش + مۇكاپاتلىرىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نېمىشقا- نېمىشقا توختاپ قېلىشتىن ساقلىنىش- گۇگۇل- تەكشۈرۈش- مۇكاپاتلاش) <! - 60! ->

[نېمىشقا گۇگۇل سىزمىلىرىنى ئىشلىتىشنى توختىتىشىڭىز كېرەك] (https://github.com/seanpm2001/ نىمىشقا- نېمىشقا توختاپ قېلىشتىن ساقلىنىش- گۇگۇل رەسىملىرى) <! - 61! ->

[نېمىشقا تېنورنى ئىشلىتىشنى توختىتىشىڭىز كېرەك (GIF تور بېكىتى ، 2019-يىلدىن باشلاپ گۇگۇلنىڭ ئىگىدارچىلىقىدا)] (https://github.com/seanpm2001/ نىمىشقا- نېمىشقا Google- تېنور) ->

[FLoC دېگەن نېمە - نېمىشقا Googles نىڭ چوڭ FLoCing مەسىلىسىدىن ساقلىنىشىڭىز كېرەك (Google Chrome ئىشلىتىشنى توختىتىڭ)] (https://github.com/seanpm2001/ نېمە- FLoC) <! - 63! ->

** ئومۇمىي ماقالىلەر: ** `63`

** ماقالە [يول خەرىتىسى AB] (DegoogleCampaign_2021Roadmap_Part1.md) (2021-يىلى 12-مارتقىچە) 2 كۈن دەم ئېلىش **

** ماقالە [يول خەرىتىسى BB] (DegoogleCampaign_2021Roadmao_Part2.md) (2021-يىلغىچە) 2 كۈن دەم ئېلىش **

ماقالە ھالىتى

بارلىق ماقالىلەر ھازىر ئېلىپ بېرىلىۋاتقان خىزمەت بولۇپ ، كەڭ كۆلەمدە ياخشىلاشقا موھتاج. تەكلىپ ۋە تۈزىتىشكە رۇخسەت قىلىنىدۇ.

** Forks **

مېنىڭ Degoogle تورىنى كېڭەيتىپ ، بىر ئاز قولايلىقلارنى قوشۇش ۋە مەھەللە توۋلاش.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | يوللانغان: [https://github.com/wacko1805/Fossapps)(https://github.com/wacko1805/Fossapps) (ئىنگلىزچە)

2. [مەخپىيەتلىك-ئۇلىنىشلار] (https://github.com/Degoogle-your-life/Privacy-links) | يوللانغان: [https://github.com/Arturro43/privacy-links)(https://github.com/Arturro43/privacy-links) (پولشا)

3. [خۇشاللىق-مەخپىيەتلىك] (https://github.com/Degoogle-your-life/Delightful-Privacy) | ئەمەلدىن قالدۇرۇلدى: [https://github.com/LinuxCafeFederation/Delightful-Privacy Country(https://github.com/LinuxCafeFederation/Delightful-Privacy) (ئىنگلىزچە)

4. [Blocklists] (https://github.com/Degoogle-your-life/blocklists) | يوللانغان: [https://github.com/jmdugan/blocklists دۆلەت (http://github.com/jmdugan/blocklists) (ئىنگلىزچە)

5. [Degoogle ، Wuest3nFuchs تەرىپىدىن] (https://github.com/Degoogle-your-life/Degoogle) | يوللانغان: [https://github.com/Wuest3nFuchs/Degoogle دۆلەت

** مۇناسىۋەتلىك **

[ئاندىرويىد تېلېفونى مەۋھۇم ماشىنا تەتقىقاتى] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

** يەنە قاراڭ: **

[گۇگۇلنىڭ ۋىكىپېدىيەدىكى تەنقىدى] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[Google قەبرىستانلىقى (killedbygoogle.com) - گۇگۇل ئۆلتۈرگەن 224+ مەھسۇلاتنىڭ رەتلەنگەن تىزىملىكى] (https://killedbygoogle.com/)

> [GitHub ئۇلىنىشى] (https://github.com/codyogden/killedbygoogle)

[ئېلىپبە ئىشچىلار ئويۇشمىسى - 800 دىن ئارتۇق ئەزاسى بار گۇگۇلدىكى يېڭى ئىشچىلار ئويۇشمىسى] (https://alphabetworkersunion.org/people/our-union/)

[دىنوزاۋر پاسخا تۇخۇمى بىلەن ئايرىلىشنى خالامسىز؟ بۇ تور بەت سىزنى قاپلىدى] (https://chromedino.com/)

***

## مەخپىيەتلىك

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-you-on-your-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) رەسىملەر دۆلەت (http: //www.eff.org -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/- توختاپ قالدى- ئىشلىتىش ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome تور كۆرگۈچ /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument # تەنقىد) [b] (https://spreadprivacy.com/three-reasons-why-the-thing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -سايا ئەۋرىشكىسى / ھېچنىمىنى يوشۇرۇش-تالاش-تارتىش قىلىش-دەيدىغان گەپ يوق /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- سىز ھازىر بار بولغان ئۇچۇرلارنى تاپالايسىز ۋە ئۆچۈرەلەيسىز /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -بىزنىڭ شەخسىي-سانلىق مەلۇماتلىرىڭىز- n870501) [e] ( -مونېتىزلاش ۋە ۋە) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / بارلىق سانلىق مەلۇماتلار-فېيسبۇك-گۇگۇل-شەخسىي مەخپىيەتلىكىڭىز بار) [r] collection-revealed.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] ساغلاملىق-ساغلاملىق-سانلىق مەلۇمات-مەخپىيەتلىك /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-government-google-data-collection-suit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) //www.washingtonpost.com/technology/2019/07/23/ever-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html) رەسىملىك ​​دۆلەت (http: // en.wikipedia.org /blog/where-does-google-draw-the-data-collection-line) Fotoe Country(https://mashable.com/article/google-android-data-collection-study/) رەسىملەر دۆلەت (https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html) رەسىملىك ​​دۆلەت (http://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data - 5-m نىڭ نامىدا تەلەپ قىلىدۇ illion-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marking / google [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit- دەۋاگەرلەر-بىردەكلىك-سانلىق مەلۇمات توپلاش /) رەسىملىك ​​دۆلەت (http: // arstechnica.com / نېمە- گۇگۇل-ھەقىقىي-ھەقىقىي-ئەڭ ياخشى-ھەقىقىي-ئۇۋا-سانلىق مەلۇمات / سانلىق مەلۇمات /) سۈرەتلىك دۆلەت (http://www.cbsnews.com/news/google- مائارىپ- جاسۇسلار- توپلاملار- مىليونلىغان بالىلار-سانلىق مەلۇمات-شىكايەت-يېڭى-مېكسىكا باش تەپتىشى /) [v] (https://www.nationalreview.com/2018/04/ ئوقۇغۇچىلار- سانلىق مەلۇمات- مىنا- سەتچىلىك -بۇن-بۇرنىمىز /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / تېخنىكا / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-sothing-to-hide-40689565c550) [.] : //medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (مەن بۇ ھەقتە دەلىل-ئىسپاتلار بىلەن داۋاملاشتۇرالايمەن ، ئەمما بۇلارنىڭ ھەممىسىنى تېپىش ۋە ئۆتۈشكە خېلى ئۇزۇن ۋاقىت كەتتى ماقالىلەر)

گۇگۇل مەھسۇلاتلىرىنىڭ مەخپىيەتلىكى ھەمىشە ناچار ، چۈنكى گۇگۇل مەھسۇلاتلىرىنىڭ ھەممىسىدە جاسۇسلۇق دېتاللىرى بار.

نېمە ئىش قىلىشىڭىزدىن قەتئىينەزەر ، گۇگۇلنى ئىشلىتىۋاتقاندا ، سەزگۈر شەخسىي ئۇچۇرلىرىڭىزنىڭ ھەممىسى گۇگۇل ۋە باشقىلارغا ئەۋەتىلىدۇ. گۇگۇلنىڭمۇ ئوچۇق پروگراممىلارنى باشتىن كەچۈرگەنلىكى بايقالدى. مەسىلەن ، مەن زىيارەت قىلمىغان YouTube بەتكۈچنى ئاچقان شەخسىي تەجرىبىدىن (Firefox دا) تورسىز (VLC Media Player) بىر نەچچە سىننى كۆردۈم ، كېيىن تەۋسىيەنى تەكشۈرگىلى بارغىنىمدا ، مەن كۆرگەن نەرسىلەرنىڭ ھەممىسى دېگۈدەك بولدى. ئۇلارنىڭ باشقا پروگراممىلارغىمۇ جاسۇسلۇق قىلىۋاتقانلىقىدا شەك يوق.

Chrome دا (ۋە باشقا نۇرغۇن توركۆرگۈچلەردە) يوشۇرۇن ھالەتتە ھالەتتە. Chrome دا بۇ ھالەتنىڭ ئەھمىيىتى يوق ، چۈنكى گۇگۇل يەنىلا سانلىق مەلۇماتلىرىڭىزنى قېزىۋالىدۇ. سىز سانلىق مەلۇمات قېزىش / ئىز قوغلاشنى تاقاپ ، «ئىز قوغلىماسلىق» سىگىنالىنى قوزغىتىپ ، ھەيران قالارلىق دەرىجىدە ھەيران قالارلىق ئەھۋال ئاستىدا ، گۇگۇل يەنىلا سانلىق مەلۇماتلىرىڭىزنى قېزىۋاتىدۇ.

ئەگەر سىزدە يوشۇرغۇدەك نەرسە يوق دەپ قارىسىڭىز ، ** سىز پۈتۈنلەي خاتالاشقان **. بۇ تالاش-تارتىش كۆپ قېتىم رەت قىلىندى:

[ۋىكىپېدىيە ئارقىلىق] (https://en.wikipedia.org/wiki/ ھېچنېمە_ يوشۇرۇش_ تالاش-تارتىش # تەنقىد)

1. ئېدۋارد سىنوۋدېن «شەخسىي مەخپىيەتلىك ھوقۇقىغا كۆڭۈل بۆلمەيسىز ، چۈنكى سىزدە ھېچقانداق يوشۇرغۇدەك نەرسە يوق ، دەپ تالاش-تارتىش قىلىش ئەركىن سۆزلەشكە كۆڭۈل بۆلمەيسىز ، چۈنكى دەيدىغان گېپىڭىز يوق» دېدى. مېنىڭ يوشۇرغۇدەك ھېچنېمەم يوق ، سىز دەيسىز ، «مەن بۇ ھوقۇققا پەرۋا قىلمايمەن» دەيسىز ، سىز «مېنىڭ بۇ ھوقۇقىم يوق ، چۈنكى مەن ئاقلاشقا تېگىشلىك دەرىجىگە يەتتىم. بۇ ھوقۇقنىڭ خىزمەت ئۇسۇلى ، ھۆكۈمەت سىزنىڭ ھوقۇقىڭىزغا تاجاۋۇز قىلىشىنى ئاقلىشى كېرەك ».

2. دانىيال ج. سولوۋ «ئالىي مائارىپ تەزكىرىسى» نىڭ ماقالىسىدە ئۆزىنىڭ بۇ تالاش-تارتىشقا قارشى تۇرىدىغانلىقىنى ئوتتۇرىغا قويدى. ئۇ ھۆكۈمەتنىڭ چىقالايدىغانلىقىنى بايان قىلدىk بىر ئادەم ھەققىدىكى ئۇچۇرلار ۋە ئۇ كىشىگە زىيان يەتكۈزىدۇ ياكى بىر ئادەم ھەققىدىكى ئۇچۇرلارنى ئىشلىتىپ ، ھەتتا بىر ئادەم ئەمەلىيەتتە قانۇنغا خىلاپلىق قىلمىغان تەقدىردىمۇ ، ھۆكۈمەت خاتالىق ئۆتكۈزۈش ئارقىلىق ئۆزىنىڭ شەخسىي ھاياتىغا زىيان يەتكۈزىدۇ. سولوۋ مۇنداق دەپ يازدى: «بىۋاسىتە شۇغۇللانغاندا ، يوشۇرۇشقا تىگىشلىك تالاش-تارتىش تۇزاققا چۈشۈپ قالىدۇ ، چۈنكى ئۇ مۇنازىرىنى ئۆزىنىڭ شەخسىي مەخپىيەتلىكىنى چۈشىنىشكە مەركەزلەشتۈرىدۇ. ئەمما ھۆكۈمەت سانلىق مەلۇماتلىرىنى يىغىش ۋە نازارەت قىلىشتىن باشقا ئىشلىتىش سەۋەبىدىن كېلىپ چىققان مەخپىيەتلىك مەسىلىلىرىنىڭ كۆپلۈكىگە دۇچ كەلگەندە. ئاشكارىلاش ، يوشۇرۇشقا تىگىشلىك تالاش-تارتىشنىڭ ئاخىرىدا ، دەيدىغان سۆزى يوق ».

3. مەخپىيەتلىك ھوقۇقى: ئەخلاق ۋە قانۇنىي ئاساسلارنىڭ ئاپتورى ئادام D. مور مۇنداق دەپ قارىدى: «بۇ ھوقۇق تەننەرخ / پايدا ياكى ئاقىۋەت كەلتۈرۈپ چىقىرىدىغان تالاش-تارتىشلارغا قارشى تۇرىدۇ ، دېگەن قاراش. بۇ يەردە بىز شەخسىي مەنپەئەتنىڭ تۈرلىرى دېگەن قاراشنى رەت قىلىمىز. بىخەتەرلىك ئۈچۈن سودا قىلىشقا بولىدىغان نەرسىلەرنىڭ ». ئۇ يەنە كۆزىتىشنىڭ تاشقى قىياپەت ، مىللەت ، جىنسىيەت ۋە دىنغا ئاساسەن جەمئىيەتتىكى بەزى گۇرۇپپىلارغا ماس ھالدا تەسىر كۆرسىتىدىغانلىقىنى بايان قىلدى.

4. كومپيۇتېر بىخەتەرلىك مۇتەخەسسىسى ۋە شىفىرلىق يازغۇچى برۇس شنېيېر قارشىلىق بىلدۈرۈپ ، كاردىنال رىچېللېينىڭ «ئەگەر ماڭا ئەڭ سەمىمىي كىشىنىڭ قولى بىلەن يېزىلغان ئالتە قۇرنى بەرگەن بولسا ، مەن ئۇلاردىن دارغا ئېسىلغان بىر نەرسە تاپالايمەن» دېگەن سۆزىنى نەقىل كەلتۈرۈپ. شىتات ھۆكۈمىتىنىڭ ئۇ شەخسنى ئەيىبلەش ياكى قارا چاپلاش ئۈچۈن قانداق قىلىپ بىر ئادەمنىڭ ھاياتىدىكى تەرەپلەرنى تاپالايدىغانلىقىغا. شنېيېر يەنە «بەك كۆپ كىشىلەر مۇنازىرىنى« بىخەتەرلىك بىلەن شەخسىي مەخپىيەتلىك »دەپ سۈپەتلەيدۇ. ھەقىقىي تاللاش ئەركىنلىك بىلەن كونترول قىلىش ».

5. خارۋېي A. سىلۋېرگلاتنىڭ مۆلچەرىچە ، ئادەتتىكى كىشىلەر ئوتتۇرا ھېساب بىلەن ئامېرىكىدا كۈنىگە ئۈچ قېتىم جىنايەت سادىر قىلغان.

6. پەيلاسوپ ۋە پىسخىكا ئانالىزچىسى ئېمىلىيو موردىنى «يوشۇرغۇدەك نەرسە يوق» تالاش-تارتىشنىڭ ئەسلىدىنلا زىددىيەتلىك ئىكەنلىكىنى ئوتتۇرىغا قويدى. كىشىلەر «بىر نەرسە» نى يوشۇرۇش ئۈچۈن «يوشۇرغۇدەك نەرسە» بولۇشىنىڭ ھاجىتى يوق. موردىنىنىڭ ئېيتىشىچە ، يوشۇرۇنغان نەرسە چوقۇم مۇناسىۋەتلىك ئەمەس. ئەكسىچە ، ئۇ يوشۇرۇن ھەم زىيارەت قىلىش چەكلىمىسىگە ئۇچرايدىغان يېقىن رايوننىڭ موھىملىقىنى ئوتتۇرىغا قويدى ، چۈنكى پىسخىكا جەھەتتىن ئېيتقاندا ، بىز باشقىلارغا بىر نەرسە يوشۇرالايدىغانلىقىمىزنى بايقاش ئارقىلىق شەخسكە ئايلىنىمىز.

7. جۇلىئان ئاسسانج مۇنداق دېدى: «ھازىرچە قاتىلنىڭ جاۋابى يوق. جاكوب ئاپپېلباۋ (@ioerror) نىڭ ئاقىلانە ئىنكاسى بار ، ئۇ بۇ سۆزنى قىلغان كىشىلەردىن كېيىن تېلېفوننى قۇلۇپلاپ ئىشتىنىنى چۈشۈرۈۋېتىشنى تەلەپ قىلدى. مېنىڭ بۇ نەشرىم مۇنداق دېدى: «ياخشى ، ئەگەر سىز بەك زېرىكىشلىك بولسىڭىز ، ئۇنداقتا بىز سىز بىلەن پاراڭلاشماسلىقىمىز كېرەك ، باشقىلارمۇ سۆزلىمەسلىكىمىز كېرەك» ، ئەمما پەلسەپە نۇقتىسىدىن ئېيتقاندا ، ھەقىقىي جاۋاب مۇنداق: ئاممىۋى كۆزىتىش ئاممىۋى قۇرۇلما خاراكتېرلىك ئۆزگىرىش. جەمئىيەت ناچارلاشقاندا ، ئۇ كېتىۋاتىدۇ. يەر يۈزىدىكى ئەڭ ئاقكۆڭۈل ئادەم بولسىڭىزمۇ ، ئۇنى سىز بىلەن بىللە ئېلىپ كېتىش ».

8. قانۇن پروفېسسورى ئىگناچىيو كوفون بۇ تالاش-تارتىشنىڭ ئۆز سۆزىدە خاتا ئىكەنلىكىنى ئوتتۇرىغا قويدى ، چۈنكى ، كىشىلەر مۇناسىۋەتلىك ئۇچۇرلارنى باشقىلارغا ئاشكارىلىغاندا ، ئۇلارمۇ مۇناسىۋەتسىز ئۇچۇرلارنى ئاشكارىلايدۇ. بۇ مۇناسىۋەتسىز ئۇچۇرلارنىڭ شەخسىي مەخپىيەتلىكى بار بولۇپ ، كەمسىتىش قاتارلىق باشقا زىيانلارنى كەلتۈرۈپ چىقىرىدۇ.

***

## گۇگۇلغا قارشى باشقا تەشۋىقاتلار

بۇ گۇگۇلغا قارشى باشقا كۆرۈنەرلىك پائالىيەتلەرنىڭ تىزىملىكى. بۇ تىزىملىك ​​تولۇق ئەمەس. ئۇنى كېڭەيتىش ئارقىلىق ياردەم قىلالايسىز.

### ئەمەلدىن قالدۇرۇلدى

[Scroogled - مىكروسوفت تەرىپىدىن (2012-يىلى 11-ئايدىن 2014-يىلغىچە)] (https://en.wikipedia.org/wiki/Scroogled)

_ ھازىرچە باشقا ئەسەرلەر يوق ._

### داۋاملىشىۋاتىدۇ

_ بۇ تىزىملىك ​​ھازىر قۇرۇق ._

***

## باشقا تالاش-تارتىشلارغا قارشى تۇرۇش

كىشىلەر گۇگۇلنى ئاقلاش ئۈچۈن ئوتتۇرىغا قويغان بەزى دەلىللەر بار. بىرىنچى چوڭ بىرىنىڭ بىرى ئاللىقاچان بۇ يەردە (# مەخپىيەتلىك) بۇزۇلدى ، ئەمما بۇ يەردە يەنە بىر قىسىملىرى بار:

### قۇلايلىق

شۇنداق ، گۇگۇل مەھسۇلاتلىرى قۇلايلىقتەك قىلىدۇ. قانداقلا بولمىسۇن ، سىز بىخەتەرلىك ، مەخپىيەتلىك ۋە ئىشەنچلىك قاتارلىق قۇلايلىق ئىشلار ئۈچۈن ياخشى سودا قىلىسىز. گۇگۇل كۆپ يىللاردىن بۇيان ھورۇنلۇققا باشلىدى ، ئۇلارنىڭ مۇلازىمېتىرلىرى بارغانسىرى تۆۋەنلەپ كەتتى. ھازىر ، گۇگۇل مۇلازىمېتىرلىرى ھەر ئايدا 1-2 قېتىم بىر سائەتكە يېقىن تۆۋەنلەيدۇ (بولۇپمۇ YouTube)

بەختكە قارشى ، جەمئىيەتلەرنىڭ گۇگۇلغا تايىنىشى سەۋەبىدىن ، گۇگۇل ئىنتېرنېتنى كونترول قىلىشقا باشلىدى ۋە تېخىمۇ كۆپ كونترول قىلماقچى بولۇۋاتىدۇ. 2012-يىلى ، گۇگۇل 5 مىنۇت تۆۋەنلىگەندە ، ** يەرشارى ** تور ئېقىمى ** نىڭ% 40 تۆۋەنلىگەنلىكى خەۋەر قىلىندى ، گۇگۇل دائىم 1-2 سائەت تۆۋەنلەيدۇ ، ھەمدە ئۇلارنىڭ ئەخلاق ئەترىتىنىڭ ئىشتىن بوشىتىلىشى بىلەن. (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/) قاتارلىقلار ، ئۇلار بارغانسىرى قۇلايلىق بولۇپ قالىدۇ.

قۇلايلىق ھەمىشە ياخشى ئىش ئەمەس. نېمە ئىشلارنىڭ يۈز بېرىدىغانلىقىنى بىلىشىڭىز ۋە ئۇلار چۈشكەندە تەييارلىق قىلىشىڭىز كېرەك ، چۈنكى مۇلازىمېتىرنىڭ ھەر قېتىمدا چۈشۈپ كەتمەسلىكى مۇمكىن ئەمەس.

گۇگۇلمۇ سىز ئويلىغاندەك ئۇنچە قۇلايلىق ئەمەس. باشقا تېخىمۇ قۇلايلىق تور بېكەتلەر بار. گۇگۇل قۇلايلىق ئەمەس ، ئۇلارنىڭ تاسادىپىي ھېساباتنى توختىتىش ۋە ئاخىرلاشتۇرۇشىنى ھېسابقا ئالمىغاندا (ئەگەر سىز گۇگۇلنىڭ twitter ھېساباتىغا يېتەرلىك دىققەت قىلمىسىڭىز ياكى 100،000،000 دوللار ياكى ئۇنىڭدىن يۇقىرى ئەرز سۇنمىسىڭىز) ئۇنداقتا ئۇلار سىزدىن پايدىلىنىپ ، سىزنى ئالدايدۇ ۋە سىزنى ياستۇققا ۋارقىراشقا مەجبۇر قىلدى ، بۇ يەردە ھېچكىم سىزنىڭ ۋاقىرىشىڭىزنى ئاڭلىيالمىدىياردەم ئۈچۈن.

### نېمىشقا مۇھىم ، ھەر ھالدا بەك كېچىكىپ كەتتى

بۇ بىر ئاز ئۇچرايدىغان تالاش-تارتىش ، ئەمما ئۇ چۈشەندۈرۈشكە موھتاج. ھازىرقى ھالەتكە ئەگىشىپ ، دۇنيادىكى نۇرغۇن ھۆكۈمەتلەر ، بىر قانچە كۈچلۈك شىركەتلەر بىلەن بىرلىكتە سىزنىڭ ھەر بىر ھەرىكىتىڭىزنى بىلىدىغاندەك قىلىدۇ ، ئۇنداقتا نېمىشقا ئۇنىڭدىن يىراقلاشقىمۇ ئاۋارە بولىسىز؟ جاۋابى ناھايىتى ئاددىي: ** سىز تېخىمۇ ياخشى **. ئەگەر سىز بۇ ۋاقىتتا ئۇلاردىن يىراقلاشسىڭىز ، ئۇلارنىڭ ھەرىكەتلىرىڭىزنى تېخىمۇ ئىز قوغلىشى تېخىمۇ تەس ، سىز تېخىمۇ يېڭى شەخسىي تۇرمۇش قۇرالايسىز.

[1 مەنبەلەر] ھازىر (مېنىڭ 500 تەڭگە پۇلنىڭ ھەممىسى بىلەن بىللە) بۇ تېمىنى تېخىمۇ ئىلگىرى سۈرۈش ئۈچۈن. ھازىرغا قەدەر مەن بۇ يازمىنى 14 دىن ئارتۇق ھەقسىز مۇكاپاتقا ئېرىشتىم. بۇ ئانچە كۆپ ئەمەس ، ئەمما كىچىك ئىشلار ئۇنىڭ قانداق تونۇلۇشى ۋە كىم تەرىپىدىن بولۇشىغا باغلىق.

### Other

مېنىڭ ھازىرچە باشقا تالاش-تارتىشلىرىم يوق.

_بۇ تىزىملىك ​​تولۇق ئەمەس_

***

## مەنبە

كۆپەيتىلگەن نۇسخىسى:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-you-on-your-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) رەسىملەر دۆلەت (http: //www.eff.org -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/- توختاپ قالدى- ئىشلىتىش ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail com / بىلوگ / google- مەخپىيەتلىك-مەسىلە /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80- دەرىجىسىنى يۇقىرى كۆتۈرۈش تور كۆرگۈچ /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] تەنقىد) [b] (https://spreadprivacy.com/three-reasons-why-the-the-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -مەسىلەر / ھېچنىمىنى يوشۇرۇش-تالاش-تارتىش قىلىش-دەيدىغان گەپ يوق /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- سىز ھازىر تاپالايسىز ۋە ئۆچۈرەلەيسىز /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your شەخسىي-سانلىق مەلۇمات- n870501) [e] ( -and) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html) رەسىملىك ​​دۆلەت (http: google-privacy-suit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https: -ئۈچۈن بالىلار-سانلىق مەلۇمات توپلاش-مائارىپ-خروم كىتابلىرى) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] ( (https://www.washingtonpost.com/technology/2019/07/23/ever-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html) رەسىملىك ​​دۆلەت (http: moz.com/bl og / where-do-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) 2019/01/21 / تېخنىكا / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- 5 مىليونلۇق iphone ئىشلەتكۈچىلەرگە ۋاكالىتەن تەلەپ قىلىش) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) سۈرەتلىك دۆلەت -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit- دەۋاگەرلەر- بىردەك-سانلىق مەلۇمات توپلاش /) [r] .com / information-technology / 2014/01 / google-can-can-do-do-do-with-nest-or-nest-data-data /) [i] جاسۇسلار-مىليونلىغان بالىلار-سانلىق مەلۇماتلارنى توپلايدۇ-شىكايەت-يېڭى-مېكسىكا باش تەپتىشى /) [v] (https://www.nationalreview.com/2018/04/the- ئوقۇغۇچىلار-سانلىق مەلۇمات قېزىش-سەتچىلىكى بۇرنىمىزنىڭ ئاستىدا /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) فوكۇس دۆلەت -ھازىر-يوشۇرۇش -40689565c550). [.] (

باشقا مەنبەلەر:

[بەش كۆز ئىتتىپاقى] (https://en.wikipedia.org/wiki/Five_Eyes) [ئون توققۇز سەكسەن تۆت]

***

## ئۇلىنىشلارنى چۈشۈرۈش

[Firefox غا ئېرىشىش] (https://www.mozilla.org/en-US/firefox/new/) [تور كۆرگۈچكە ئېرىشىش] : //www.example.com)

***

## مېنىڭ چېكىنىش كەچۈرمىشىم

مەن ئاخىرى 2018-يىلى چوڭ تېخنىكىدىكى مەسىلىلەرنى كۆرۈشكە باشلىدىم ۋە چېكىنىشكە باشلىدىم. دەسلەپكى بىر نەچچە ئايدا ، مەن كۆرۈنەرلىك ئىلگىرىلەشكە ئېرىشتىم. شۇنىڭدىن كېيىن ئۇ ناھايىتى ئاستىلىدى.


### مەن ئالماشتۇردۇم

Google Chrome -> Firefox / Tor

Google Search -> DuckDuckGo (سۈكۈتتىكى) / Ecosia (مەن ھېس قىلغان ۋاقتىمدا) / Bing (ناھايىتى ئاز)

GMail - ProtonMail (تېخى تولۇق ئالماشتۇرۇلمىغان)

Google بېكەتلىرى -> ئۆزلۈكىدىن ساھىبخانلىق قىلىش (تېخى تولۇق ئالماشتۇرۇلمىدى)

Google+ -> ئەزەلدىن ئىشلىتىلمىگەن ، ئۆزىنىڭ تاقىلىشى سەۋەبىدىن ئۆزىنى ئۆچۈرۈۋەتكەن

Google Docs -> ئەزەلدىن ئىشلىتىلمەيدۇ ، مەن ئۇنىڭ ئورنىغا Microsoft Word 2013 (2019-يىلدىن بۇرۇن) ۋە LibreOffice (2019-يىلدىن كېيىن) ئىشلىتىمەن.

Google Sheets -> ئەزەلدىن ئىشلىتىلمەيدۇ ، مەن ئۇنىڭ ئورنىغا Microsoft Excel 2013 (2019-يىلدىن بۇرۇن) ۋە LibreOffice (2019-يىلدىن كېيىن) ئىشلىتىمەن.

Google Slides -> ئەزەلدىن ئىشلىتىلمەيدۇ ، مەن ئۇنىڭ ئورنىغا Microsoft PowerPoint 2013 (2019-يىلدىن بۇرۇن) ۋە LibreOffice (2019-يىلدىن كېيىن) ئىشلىتىمەن.

Google رەسىملىرى -> ئەزەلدىن ئىشلىتىلمەيدۇ ، مەن ئۇنىڭ ئورنىغا LibreOffice (2019-يىلدىن باشلاپ) ئىشلىتىمەن.

Gerrit -> ئەزەلدىن ئىشلىتىپ باقمىغان ، مەن ئۇنىڭ ئورنىغا GitHub (ھازىرقى سۈكۈتتىكى) ، GitLab ، BitBucket ۋە SourceForge نى ئىشلىتىمەن.

Google سۈرەتلىرى -> ئەزەلدىن ئىشلىتىلمەيدۇ

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-ھازىرقى)

Google خەرىتىسى -> OpenStreetMaps / ئالما خەرىتىسى

بېرىش - ئالاھىدە مۇستەسنا قىلىش ، ئەمما ئىقتىدارلىق پروگرامما تىلى سۈپىتىدە ئىشلەتمەسلىك

Dart - ئالاھىدە مۇستەسنا قىلىش ، ئەمما ئىقتىدارلىق پروگرامما تىلى سۈپىتىدە ئىشلەتمەسلىك

Flutter - ئالاھىدە مۇستەسنا قىلىش ، ئەمما ئىقتىدارلىق پروگرامما تىلى سۈپىتىدە ئىشلەتمەسلىك

Google Earth -> OpenStreetMaps / ئالما خەرىتىسى

Google Streetview -> ئەزەلدىن ئىشلىتىپ باقمىغان ، مەن ئۇنى تېخىمۇ سىپتا دەپ قارايمەن

Google Fi -> ئەزەلدىن ئىشلىتىلمەيدۇ

Google كالېندارى -> ئەزەلدىن ئىشلىتىلمەيدۇ

Google ھېسابلىغۇچ -> ئەمەلىيەتتە باشقا ھېسابلىغۇچ دېتالى ، ھەتتا مەن ياقتۇرسام Python ھالەتتە ئىجرا بولىدىغان لىنۇكىس تېرمىنالى

Google Nest -> ئەزەلدىن ئىشلىتىلمەيدۇ

Google AMP -> ئەزەلدىن ئىشلىتىلمەيدۇ

Google VPN -> ئەزەلدىن ئىشلىتىلمەيدۇ ، ئوكسىدورمۇ بار

Google Pay -> ئەزەلدىن ئىشلىتىلمەيدۇ

Google يازلىق كود -> ئەزەلدىن قاتناشمىدى

Tenor -> باشقا GIF تور بېكەتلىرى ، گەرچە GIF مەن ئۈچۈن بەك مۇھىم ئەمەس. مەن ئادەتتە DuckDuckGo رەسىملىرى ، Imgur ، Reddit ياكى باشقا تور بېكەتلەردىن GIF ھۆججىتىگە ئېرىشىمەن.

توسۇش -> ئەمدى ئىشلىتىلمەيدۇ ، Scratch نىڭ بىۋاسىتە توسۇلۇپ قالغان ياكى ئەمەسلىكىنى جەزملەشتۈرۈڭ. مەن 2017-يىلدىن باشلاپ ئىقتىدارلىق پروگرامما تۈزگۈچىگە ئايلاندىم ۋە Scratch دىن يېتىشىپ چىقتىم.

GBoard -> بىر قېتىم ئىشلىتىلگەن ، ئەمما تاشلىۋېتىلگەن

Google Glass -> ئەزەلدىن ئىشلىتىپ باقمىغان ، كىچىك بالا دەپ قارالغان ، ئەمما تاللىشىم بولسا بىرنى ئالماسلىقنى قارار قىلغان

_ تىزىملىك ​​تولۇق بولماسلىقى مۇمكىن ._

### مەھسۇلاتلار مەن يەنىلا يىراقلاپ كېتەلمەيمەن

2021-يىلى 2-ئاينىڭ 25-كۈنىگە قەدەر ، بۇلار گۇگۇلنىڭ مەھسۇلاتلىرى مېنى پۈتۈنلەي چۈشكۈنلەشتۈرۈۋاتىدۇ.

1. YouTube

2. ئاندىرويىد

3. Google Play دۇكىنى

4. GMail (پەقەت مەكتەپ ۋە بەزى تور بېكەتلەر ئۈچۈن)

5. Google دەرسخانىسى (پەقەت مەكتەپ ئۈچۈن)

6. Google تەرجىمىسى

7. Google ھېساباتى

8. گۇگۇل تور بېكەتلىرى (گۇگۇل GDPR نىڭ قانۇنىغا خىلاپلىق قىلغانلىقتىن (ۋە ئۇنى ئوڭشاپ بولغۇچە يەنە 5000،000 ياۋرو جەرىمانە تۆلەيدۇ) ۋە بۇ مەھسۇلاتنى چۈشۈرۈشنى مەنئى قىلىدۇ)

مەن باشقا نەرسىلەردىن ۋاز كەچتىم.

***

## Go is evil

گۇگۇل 2003-يىلدىكى ۋاكالەتچى پروگرامما تىلى «Go!» نى پروگرامما تۈزۈش تىلى بىلەن «Go» (2009-يىلدىن 6 يىل ئۆتكەندىن كېيىن) دىن ھالقىپ ، ئۇلارنىڭ تىلىنىڭ باشقا تىلغا تەسىر كۆرسىتەلمەيدىغانلىقىنى ئوتتۇرىغا قويدى. گۇگۇل بۇنىڭ ئۈچۈن قاتتىق تەنقىدكە ئۇچرىدى ، چۈنكى ئۇلارنىڭ «يامان بولماڭ» شۇئارى ئەينى ۋاقىتتا يەنىلا ئاكتىپ ئىدى ، بۇ يامان ئەمەس موتونىڭ پىنسىيەگە چىققان نۇرغۇن ۋەقەلەرنىڭ بىرى.

ئاخىرىدا ، «Go!» نىڭ تەرەققىياتى توختىدى ، شۇنىڭ بىلەن بىر ۋاقىتتا «Go» تېخىمۇ ئومۇملاشتى. گۇگۇل ئۆزلىرىنىڭ «Go!» دىن ھالقىپ كەتمەيدىغانلىقىنى ئوتتۇرىغا قويدى ، ئەمما ئاخىرىدا ئۇلار قىلدى ، ئۇلار ئۇنىڭدىن قۇتۇلدى (2021-يىلى 9-ئاپرېلغىچە)

[Go ۋە بۇ يەردە قانداق ئالمىشىدىغانلىقى توغرىسىدىكى تەپسىلاتلارنى ئوقۇڭ]

***

## DRM نىڭ ئىشلىتىلىشى

گۇگۇل WideVine DRM «مۇلازىمىتى» ۋە باشقا شەكىللەر ئارقىلىق DRM (رەقەملىك چەكلىمىلەرنى باشقۇرۇش) نى ئىشلىتىدۇ. DRM نىڭ مەقسىتى ئوچۇق ئىنتېرنېتنى يوقىتىش ۋە شىركەتلەرگە ئابونتلارغا مونوپول قىلىش ھوقۇقى بېرىش. بەدەل تۆلەشتىن قەتئىينەزەر ، WideVine دىن پۈتۈنلەي قۇتۇلۇشىڭىز كېرەك.

[WideVine ۋە ئۇنىڭ مەسىلىلىرى ھەققىدىكى تەپسىلاتلارنى بۇ يەردىن كۆرۈڭ] (https://github.com/Degoogle-your-life/Its-time-to-cut-WideVine-DRM)

***

## كۆپ ئۇچرايدىغان خاتا قاراش

بۇ گۇگۇل مەھسۇلاتلىرى بىلەن كۆپ ئۇچرايدىغان خاتا قاراشلارنىڭ تىزىملىكى.

### Google ئىنتېرنېت ئەمەس

گۇگۇل / گۇگۇل ئىزدەش ئىنتېرنېت ئەمەس ، گۇگۇل ئىزدەش پەقەت بىر ئىزدەش ماتورى ، Nintendo سۇپىسىدىكى ھەر بىر ئويۇننىڭ Nintendo تەرىپىدىن ياسالغانغا ئوخشاش ئەمەس ، بەلكى Nintendo تەرىپىدىن ئىجازەت بېرىلگەن ، ئەمما تېخىمۇ كەڭ دائىرىدە. ئەگەر ھازىر Googles مۇلازىمېتىرلىرىنىڭ ھەممىسى بىرلا ۋاقىتتا بۇزۇلسا ، پەقەت YouTube ، Gmail ، Google Docs ، گۇگۇل ئىزدەش قاتارلىق Google تور بېكەتلىرىلا يوقالغان بولاتتى ، ئەمما ئىنتېرنېتنىڭ كۆپ قىسمى يەنىلا شۇ يەردە بولاتتى (ۋىكىپېدىيە ، Stackoverflow ، GitHub ، Microsofts توربېكەتلىرىنىڭ ھەممىسى ، NYTimes ، سامسۇڭ ، TikTok قاتارلىقلار) ئۇلارنىڭ گۇگۇلغا كىرىش ۋە ئانالىز قىلىش ئىقتىدارىنى يوقىتىشى مۇمكىن ، ئەمما ئۇلار يەنىلا ئىقتىدارلىق بولىدۇ (ئەگەر ئۇلار پروگرامما تۈزمىگەن ۋە بىۋاسىتە گۇگۇلغا تايانمىغان بولسا)

***

## Internet Explorer 6 ۋە Chrome

گۇگۇل Chrome يېڭى Internet Explorer غا ئايلىنىۋاتىدۇ. گۇگۇل Chrome ئەسلىدە چىققاندا ، Firefox ئاساسلىق توركۆرگۈ بولۇپ ، گۇگۇل Chrome ئىشلەتكەندە تور كۆرگۈچىلەرنىڭ بازار ئۈلۈشىنى ئۆلتۈرگەن (مىليونلىغان كىشى Firefox ۋە باشقا توركۆرگۈچلەرگە ئالماشتۇرۇشتىن بۇرۇن% 96 تىن ئېشىپ كەتكەن). چىقتى ، كىشىلەر ئۇنىڭ سۈرئىتى سەۋەبىدىن ئالماشتى ۋە ئۇ گۇگۇل تەرىپىدىن (ئەينى ۋاقىتتا يامان ئەمەس دەپ قارالمىغاچقا ، كۆپىنچە شەخسىي مەسىلىلەر تېخى ئاشكارىلانمىغاچقا) گۇگۇل Chrome ئەسلىدە تور ئۆلچىمىگە ھۆرمەت قىلغان (بۇ Firefox نىڭ قىلغان ئىشى) بۇ تور ئىزدىگۈچىلىرىنىڭ% 96 توركۆرگۈ بازىرىدىن ئايرىلدى) ئەمما ، گۇگۇل Chromes بازار ئۈلۈشىنىڭ ئۆسۈشىگە ئەگىشىپ ، گۇگۇل تېخىمۇ كۆپ ئىقتىدارلارنى چىقىرىپ تاشلاشقا باشلىدى ، تېخىمۇ كۆپ جاسۇسلۇق دېتال قوشتى ۋە تور ئۆلچىمىنى قوبۇل قىلىشنى توختاتتى ، Google Chrome يېڭى Internet Explorer 6 گە ئايلاندى.

ھازىر ئاساسلىق مەسىلە پەقەت Chrome بولغان تور بېكەتلەر بولۇپ ، باشقا توركۆرگۈچلەردە ئىشلىمەيدۇ ، چۈنكى ئۇلارنىڭ پروگراممېرلىرى Chrome ئىشلەتمەيدىغان باشقا 30-40% تور ئابونتلىرىنىڭ تور بېتىنى ئىشلىتىشىنى خالىمايدىغانلىقىنى قارار قىلدى.

ھەتتا گۇگۇلنىڭ ئۆزىمۇ تور بېكەتلىرىنى Chrome قىلىۋاتىدۇ. مەسىلەن ، گۇگۇل ئىزدەش سىزنى Google Chrome ئىشلەتمەيدىغانلىقىڭىزنى بايقىسا (ھەتتا باتۇرغا ئوخشاش باشقا خىرومنى ئاساس قىلغان توركۆرگۈچلەرمۇ تەسىرگە ئۇچرايدۇ) ، Google Earth غا ئوخشاش تور بېكەتلەر Firefox ئىشلەتكۈچىلىرىگە يول قويمايدۇ. ئۇلارنىڭ تور بېتىنى ئىشلىتىڭ (2020-يىلغىچە) Google تەرجىمىسى Firefox ۋە باشقا Google Chrome تور كۆرگۈلىرىدە ئاۋاز كىرگۈزۈشنى قوللىمايدۇ.

### باتۇرنىڭ مەسىلىسى

خىرومنى ئاساس قىلغان باشقا توركۆرگۈچلەر ، مەسىلەن باتۇر ۋە Microsoft Edge گۇگۇلنىڭ جاسۇسلۇق يۇمشاق دېتالىدىن پۈتۈنلەي خالىي ئەمەس. باتۇر ئادەتتە شەخسىي جەمئىيەتنىڭ خاتا تەرىپى تەرىپىدىن تەۋسىيە قىلىنىدۇ ، ئەمما خىروم ئىشلىتىلگەنلىكى ئۈچۈن ، باتۇر يەنىلا بىر مەسىلە. ئىنتېرنېت پەقەت خىروم توركۆرگۈدىن تەركىب تاپماسلىقى كېرەك ، ھەر خىل تاللاشلار بولۇشى كېرەك. باتۇر خاتا يول.

[Google Chrome / Chromium دىن چېكىنىش ھەققىدىكى تەپسىلاتلارنى بۇ يەردىن كۆرۈڭ] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) دىن چېكىنىش ھەققىدىكى تەپسىلاتلارنى بۇ يەردىن كۆرۈڭ] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## خاتالىق مەخپىيەتلىكىنى يېڭىلاش

گۇگۇل ئاللىقاچان بەك كەچ بولۇپ كەتكەندىن كېيىن ، دۇنياغا ئۆزلىرىنىڭ شەخسىي مەخپىيەتلىككە كۆڭۈل بۆلىدىغانلىقىنى ئېيتماقچى بولۇۋاتىدۇ. ئۇلار داۋاملىق ئابونتلارنىڭ مەخپىيەتلىكىگە ھۆرمەت قىلىدىغانلىقىنى ئوتتۇرىغا قويدى ، ئەمما ئۇلار يەنىلا بارلىق مەخپىيەتلىك مەسىلىلىرىنى ھەل قىلمىدى.

### ئوچۇق مەنبە قىسمەن بولمايدۇ

ئوچۇق مەنبە قىسمەن بولمايدۇ. گۇگۇل بۇنىڭ دەلىلى. ئەسلى كودنىڭ ھەر بىر بىت ۋە بايتلىرى چوقۇم كۆپچىلىككە كۆرۈنۈشى كېرەك ، ھەتتا 8 بايتمۇ يوشۇرۇنمايدۇ.

ئاندىرويىد ۋە ChromeOS غا ئوخشاش تۈرلەر قىسمەن ئوچۇق مەنبەلىك ، ئەمما كۆپىنچە ئىگىدارچىلىق قىلىدىغان ، جاسۇسلۇق دېتاللىرىنى ئۆز ئىچىگە ئالىدۇ.

### Oxymoron

Google VPN بولسا ئوكسىگېن. گۇگۇل شەخسىي مەخپىيەتلىككە پەرۋا قىلمايدۇ ، ئۇلارغا ئوخشاش شىركەتتىكى مەۋھۇم شەخسىي تور (VPN) VPN مۇلازىمىتى ئۈچۈن ئەڭ ناچار تاللاشلارنىڭ بىرى بولۇپ قالىدۇ.

***

## ناچار ئىقتىدار

گۇگۇل مەھسۇلاتلىرىنىڭ ئىپادىسىگە ھېچ بولمىغاندا 2017-يىلغىچە كۆڭۈل بۆلمەيدۇ ، چۈنكى ئۇلارنىڭ ئەڭ ئاخىرقى ئۆلچەم يۇمشاق دېتالى (Google Octane) 2017-يىلى توختىتىلغان.

***

## ناچار تۈر باشقۇرۇش

گۇگۇلنىڭ ئىچكى تۈر باشقۇرۇش سىستېمىسى ئىنتايىن ناچار. بارغانسىرى تۆۋەنلىتىلگەن پروگراممىلارنىڭ كۆپ ئۇچرايدىغان مىساللىرى Google Duo ۋە YouTube مۇزىكىسىنى ئۆز ئىچىگە ئالىدۇ (ئىلگىرىكى Google Play Music)

Googles ئىچكى تەرەققىيات سىستېمىسىدا ، 1 ئەپ يېرىم ئىقتىدارغا ئىگە باشقا ئەپنى كەلتۈرۈپ چىقىرىدۇ ، ئاندىن ئەسلى ئەپ ئۆچۈرۈلىدۇ. بىر نەچچە يىلدىن كېيىن ، ئىقتىدارى% 75 تۆۋەن بولغان يېڭى ئەپ ياسالدى ، ئاندىن% 50 ئىقتىدارغا ئىگە بۇ دېتال چىقىرىۋېتىلدى ، ئۇنىڭدىن كېيىن% 87.5 ئىقتىدار بىلەن يېڭى ئەپ بارلىققا كەلدى ، ئاندىن% 75 ئىقتىدارغا ئىگە بۇ دېتال توختىتىلدى. ۋە باشقىلار.

***

## قورقۇنۇچلۇق ياكى ئوتتۇراھال مۇلازىمەت يوق

YouTube ناچار ئوتتۇراھاللىق دۇنياسىدىكى ئەڭ كۆپ ئۇچرايدىغان مىسال ، مەۋجۇتلۇقتىكى ئەڭ ناچار سۇپا. گۇگۇلمۇ YouTube نىڭ YouTube بالىلىرى ئەمەسلىكىنى ھېس قىلالمايدۇ.

YouTube غا نىسبەتەن ، ناتسىستلارنى قوللايدىغان ۋە ئاق تەنلىك ئاشقۇنلارنىڭ مەزمۇنلىرى تېخىمۇ كۆپ قاتنىشىش ۋاقتى ۋە تېخىمۇ كۆپ پۇل ئۈچۈن ئابونتلارغا تەمىنلىنىدۇ. گۇگۇلمۇ بەزى ئىشلارنى قىلدىئۇلارنىڭ ئوتتۇراھاللىقىدىكى ئەخمەق ئىشلار ، مەسىلەن خىرىستىيان ئانىسىنىڭ جىنسىي فىلىمىنى «بالىلار ئۈچۈن ياسالغان» مەزمۇن بىلەن تەستىقلاش بىلەن بىر ۋاقىتتا ، سىننى چەكلەش. بوۋاقلار لەھەڭ فىلىمى ئاستىدا شەھۋانىي ياكى گورۇپپا ئېلانلىرىنىڭ توغرا ئىكەنلىكىنى ، بالىلار ئۈچۈن ياسالغان باشقا ھەر خىل مەزمۇنلارنى كۆرۈشمۇ كۆپ ئۇچرىمايدۇ.

YouTube ئىشلەتكۈچىلىرى ناچار مەزمۇنلار (يۇقىرىدا كۆرسىتىلگەن مىساللارغا ئوخشاش) YouTube دىكى ئوتتۇراھاللىقنىڭ ناچارلىقىدىن ھەمىشە شىكايەت قىلىدۇ ، ھالبۇكى ئىشلەتكۈچىلەر ھەر قانداق شەكىلدىكى قەسەم قىلىش جىنايىتى بىلەن جازالىنىدۇ ، شۇنىڭ بىلەن بىر ۋاقىتتا ئابونتلار سىنلىرىنى خالىغانچە ئۆچۈرۈۋېتەلەيدۇ. ھەتتا «قىسقۇچپاقا» ئىشلەتكۈچىلەر ستالىن دەۋرىدىكى YouTube نى [سوۋېت ئىتتىپاقى] (https://en.wikipedia.org/wiki/Soviet_Union) بىلەن سېلىشتۇرىدۇ.

2021-يىلى ، گۇگۇل بارلىق سىنلارغا ئېلان قويىدىغانلىقىنى ئېلان قىلدى ، گەرچە بۇ سىن ئالۋاستىغا ئايلانغان بولسىمۇ (گۇگۇل پۇل تاپىدۇ ، ئەمما ئىجادكار ئۇنداق قىلمايدۇ) بۇ ئوتتۇراھاللىق بىلەن ئانچە مۇناسىۋىتى يوق ، ئەمما دىققەت قىلىشقا تېگىشلىكى.

YouTube مۆتىدىل (گەرچە بەك ناچار بولسىمۇ) ، ئەمما ئۇلارنىڭ كۆپ قىسىم پۇلىنى قىلىدىغان گۇگۇل ئېلان مۇلازىمىتى قارىماققا ئانچە مۇۋاپىق ئەمەس.

[YouTube نىڭ ئوتتۇراھال مەسىلىلەر ۋە YouTube دىن قانداق ئالمىشىدىغانلىقى توغرىسىدىكى تەپسىلاتلارنى ئوقۇڭ] (https://github.com/seanpm2001/Alternating-from-YouTube)

Google Play نىڭ ئېلانى بوت دېھقانچىلىق مەيدانىدىن ھاسىل قىلىنغان ، سىز ئوخشاش ئېلان سىنارىيەسى ئارقىلىق يۈزلىگەن شىركەتلەرنىڭ ئازراق ئۆزگىرىشى بار ، ھەمدە مەھسۇلات بىلەن مۇناسىۋىتى يوقلىقىنى بىلەلەيسىز (ئورتاق مىساللار: Playrix (ئائىلە مەنزىرىسى ، باغچا) بېلىقچىلىق ، مافىيە شەھىرى ۋە مىڭلىغان) ئابونتلارنىڭ ئويۇن ئويناش ، مۇزىكا ئاڭلاش قاتارلىق ئۇسۇللار ئارقىلىق پۇل تاپالايدىغانلىقىنى ئىلگىرى سۈرىدىغان يامان غەرەزلىك ئېلانلار بىلەن بىللە ، PayPal بۇنىڭغا ھېچقانداق باھا بەرمىدى ، ئەمما ئېنىقكى بۇ ئالدامچىلىق ، سىز قىلالايدىغاندەك ئويۇن ئويناش ئارقىلىق 20 سېكۇنتقا يەتمىگەن ۋاقىت ئىچىدە 10 مىڭ دوللاردىن ئاشىدۇ ، ھېچكىم خىزمەت قىلمايدۇ ۋە ئۇنىڭ ئورنىغا بۇنداق قىلىدۇ ، بۇ مۇمكىن ئەمەس ، شۇنداقلا سودا بۇنداق قىلالمايدۇ. بۇ روشەن ئالدامچىلىق 2019-يىلدىن باشلاپ كۈچىيىۋاتىدۇ ، ھازىر بۇ ئېلانلارنى ئىشلەپچىقىرىدىغان ئۆسۈملۈك دېھقانچىلىق مەيدانلىرى ئۆز ئېلانىدا ئۆز-ئارا كۆرەش قىلماقتا.

بىر قانچە ئېلانلارمۇ ئىنتايىن سەت بولۇپ ، ئابونتلارنى (كۆپىنچىسى 13 ياشتىن تۆۋەن ئابونتلار ياكى بوتكا) جىنسىي كونترول ئارقىلىق چېكىشكە ئۇرۇنماقچى.

نۇرغۇن ئەپلەر بوتۇلكا ۋە ئاسترونومىيە مەھسۇلاتلىرىنى ئىشلىتىدۇ ، شۇڭا ناچار تەكشۈرۈش ئېلىپ بېرىلغاندا ، پايپاق بوتۇلكا ھېسابات نومۇرى 5 يۇلتۇز باھاسىنى ئېلان قىلىشقا باشلايدۇ ھەمدە سىزنىڭ تەنقىدىڭىزنى ئىنكار قىلىشقا ئۇرۇنىدۇ. [گۇگۇلمۇ بۇنى ئۆزى قىلىۋاتىدۇ] (# Astroturfing)

[Google AdSense دىكى مەسىلىلەر توغرىسىدىكى تەپسىلاتلارنى ئوقۇڭ] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

ئومۇمىي ئېنىقلىما [(ۋىكىپېدىيەدىن)] (https://en.wikipedia.org/wiki/Astroturfing)

`` `
Astroturfing بولسا ئۇچۇر ياكى تەشكىلاتنىڭ قوللىغۇچىلىرىنى نىقابلاش ئادىتى (مەسىلەن ، سىياسىي ، ئېلان ، دىنىي ياكى ئاممىۋى مۇناسىۋەت) ئۇنى ئاساسىي قاتلامدىكى قاتناشقۇچىلار تەرىپىدىن كەلگەن ۋە قوللىغاندەك كۆرسىتىدۇ. بۇ مەنبەنىڭ مالىيە ئۇلىنىشى توغرىسىدىكى ئۇچۇرلارنى تۇتۇپ قېلىش ئارقىلىق بايانات ياكى تەشكىلاتلارغا ئىشەنچلىك بولۇشنى مەقسەت قىلغان ئادەت. ئاسترونومىيە دېگىنىمىز «ئوتلاق» سۆزىدىكى ئويۇن سۈپىتىدە تەبىئىي ئوت-چۆپكە ئوخشاپ كېتىدىغان سۈنئىي گىلەم ماركىسى AstroTurf دىن كەلگەن. بۇ ئاتالغۇنى ئىشلىتىشنىڭ مەنىسى شۇكى ، بۇ پائالىيەتنىڭ ئارقىسىدا «ھەقىقىي» ياكى «تەبىئىي» ئاساسىي قاتلام تىرىشچانلىقىنىڭ ئورنىغا ، «ساختا» ياكى «سۈنئىي» قوللاش شەكلى بار.
`` `

گۇگۇلنىڭ ئاسترونومىيە قىلىش تارىخى بار بولۇپ ، قارىماققا ئۇلار ھېچقانداق يامان ئىش قىلمايدىغاندەك قىلىدۇ (بۇ جەرياندا ، ئاستىرتتىن سەكرەش رەزىل) ، مەسىلەن ، گۇگۇلنىڭ تەنقىدىنى Twitter غا ئوخشاش سۇپىغا يوللاش (ئۇلارنىڭ ھېساباتى بار). بىر مەزگىل مەۋجۇت بولغان ، ئەمما چىقىشتىن بۇرۇن ئەزەلدىن يوللىمىغان ۋە ئېيتقانلىرىڭىزنىڭ يالغانلىقىنى ئوتتۇرىغا قويغان ، ئاندىن گۇگۇلنى ئەڭ ياخشى شىركەت دەپ دەۋا قىلغان ، ئەمما بۇلارنىڭ كۆپىنچىسىگە بوتۇلكا ئىكەنلىكى ئېنىق بولماسلىقى مۇمكىن. كىشىلەر.

***

## قانۇنسىز ۋە ئەخلاقسىز سودا ئادىتى

گۇگۇل قانۇنسىز ۋە ئەخلاقسىز سودا ئادىتىنى ئىشلىتىپ ، مونوپوللۇقنى تېخىمۇ ئىلگىرى سۈرىدۇ ، مەسىلەن باج پونكىتى ئىشلىتىش ، سىرتقا ھۆددىگە بېرىش ۋە قانۇنسىز تاجاۋۇزچىلىق ھەرىكەتلىرىنى داۋاملىق سودا قىلىش بەدىلىگە ئىشلىتىش.

### ياۋروپادا

ياۋروپا دائىم گۇگۇل ئۈستىدىن ئەرز سۇندى ، بۇ ئەڭ چوڭ دەۋا ئاندىرويىدتىكى قانۇنسىز قىلمىشلارغا چېتىشلىق بولۇپ ، نەتىجىدە گۇگۇلنىڭ 5000،000،000 ياۋرو (2021-يىلى 9-ئاپرېلدىكى 5 مىليون 947،083 703.68 دوللار بىلەن باراۋەر)

### شىمالىي ئامېرىكىدا

ئامېرىكا ھازىرغا قەدەر گۇگۇلغا يېتەرلىك جەرىمانە بەرمىدى ، ياۋروپاغا سېلىشتۇرغاندا 5 مىليون 500 مىڭ ياۋرو جەرىمانە قويۇلدى.

### تالاش-تارتىش

گۇگۇل تالاش-تارتىش پەيدا قىلغۇچە مەسىلىگە كۆڭۈل بۆلمەيدۇ ، ئاندىن ئۇلار ئۇنى ئوڭشاشقا ئۇرۇنۇپ قويىدۇ ، پەقەت تالاش-تارتىشنىڭ ۋاقىتلىق تۈگىتىشىگە يېتەرلىك ، بۇ مەسىلە باشقا تالاش-تارتىش پەيدا قىلغۇچە شىددەت بىلەن ئېغىرلىشىدۇ ، ۋە دەۋرىيلىك داۋاملاشتى. ئۇلار پەقەت ئەستايىدىللىق بىلەن ئىش قىلىشقا يېتەرلىك كۆڭۈل بۆلمەيدۇ.

***

## Google ئاپتوماتىك

Company ، گۇگۇل كۆپىنچە ئاپتوماتلاشقان ، ئوتتۇراھاللىقى ئاپتوماتلىشىشقا قارىغاندا ئاز.

شىركەت تولۇق ئاپتوماتلاشتۇرۇلماسلىقى كېرەك. گۇگۇل بۇنىڭ بىر مىسالى. پەقەت سۈنئىي ئەقىل ئارقىلىقلا ئوتتۇراھاللىق قورقۇنچلۇق ، YouTube بىر ياخشى مىسال ، ھەتتا ئارتۇق ساندىكى (يۈزلىگەن ، ياكى مىڭلىغان) كىشىلەر تور بېكەتنى باشقۇرۇۋاتقان بولسىمۇ ، قارىماققا بەك ناچار ، ئۇلارنىڭ كۆپىنچىسى ئىشلەۋاتقاندا داۋالىنىشى كېرەك.

***

## Android

ئاندىرويىد گۇگۇلغا تەۋە. ئوچۇق قول تېلېفون ئىتتىپاقىنىڭ بىر قىسمى (ئاندىرويىدتىن باشلاپ ئېچىلمىدى) ئاندىرويىد گۇگۇلنىڭ يەنە بىر مونوپول نۇقتىسىغا ئايلاندى ، قېچىش ناھايىتى تەس.

خەۋەر قىلىنىشىچە ، ئاندىرويىد كۈنىگە ئاز دېگەندە 10 قېتىم گۇگۇلغا تېلېفون قىلغان بولۇپ ، قىسمەن ئوچۇق مەنبە بولسىمۇ ، يەنىلا جاسۇسلۇق رولىنى ئوينايدۇ.

ئاندىرويىدتىن ئالمىشىش ئۈچۈن بىر قانچە تۈر قۇرۇلدى ، ئەمما ئۈسكۈنىڭىزنى يىلتىز تارتىشنى تەلەپ قىلىدۇ. Knox DRM سەۋەبىدىن ئامېرىكىدىكى كونكرېت سامسۇڭ تېلېفونلىرى ئۈچۈن بۇ ئەمدى مۇمكىن ئەمەس. ئاندىرويىدنىڭ كۆپ ئۇچرايدىغان تاللاشلىرى iOS ، iPadOS ، LineageOS ، ئاندىرويىد x86 ، ئۇبۇنتۇ Touch ۋە PiPhone قاتارلىقلارنى ئۆز ئىچىگە ئالىدۇ (Pi Phone بولسا كۆچمە ئۈسكۈنىدە ھەر خىل Linux سىستېمىلىرىنى باشقۇرىدىغان تېلېفون ماركىسى ، مەسىلەن Fedora ، Ubuntu ، Arch قاتارلىقلار).

[ئاندىرويىد مەۋھۇم ماشىنا ئىقتىدارىغا ئېرىشىش ھەققىدىكى تەتقىقاتىمنى كۆرۈڭ] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[ئاندىرويىدتىن قانداق ئۆچۈرۈشنى كۆرۈڭ] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## ياردەم قىلىدىغان كىچىك ھەرىكەتلەر

ئاڭنى ھەر جەھەتتىن كېڭەيتىش ناھايىتى مۇھىم. مەن ئۈچۈن ئېيتقاندا ، مەن ھەمىشە چېكىنىش توغرىسىدا سۆزلەيمەن ، ھەمدە ماقالە يازىمەن ، ئەمما مېنىڭ يەنە بىر كىچىك ئادىتىم بار ، ئۇ يەردە كۈندىلىك ھەقسىز Reddit مۇكاپاتىمنى r / degoogle دىكى مىخلانغان يازمىغا بېرىمەن. ھازىرغا قەدەر ، مەن چاپلانغان يازمىغا 30 غا يېقىن مۇكاپات بەردىم (ھەقسىز پۇللىرىمنىڭ 500 ىنى ئۇ مۇكاپات ئۈچۈن 10 مۇكاپاتقا خەجلىدىم)

***

## ئىشەنچسىز

گۇگۇلغا ئىشەنچ قىلغىلى بولمايدۇ ، بۇنىڭدىن كېيىن ھەرگىز ئىشەنچ قىلىشقا بولمايدۇ. ئۇلار پۈتۈنلەي «يامان بولماڭ» (ئۇلار ھەمىشە رەزىل ئىدى) دىن پۈتۈنلەي رەزىل بولۇپ ، ئۇنى يوشۇرۇشقا ئۇرۇنمىدى.

***

## تەكشۈرۈشكە تېگىشلىك باشقا ئىشلار

[Google قەبرىستانلىقى (killedbygoogle.com) - گۇگۇل ئۆلتۈرگەن 224+ مەھسۇلاتنىڭ رەتلەنگەن تىزىملىكى] (https://killedbygoogle.com/)

> [GitHub ئۇلىنىشى] (https://github.com/codyogden/killedbygoogle)

[ئېلىپبە ئىشچىلار ئويۇشمىسى - 800 دىن ئارتۇق ئەزاسى بار گۇگۇلدىكى يېڭى ئىشچىلار ئويۇشمىسى] (https://alphabetworkersunion.org/people/our-union/)

[دىنوزاۋر پاسخا تۇخۇمى بىلەن ئايرىلىشنى خالامسىز؟ بۇ تور بەت سىزنى قاپلىدى] (https://chromedino.com/)

باشقا تاللاشلىرى بار ، ئۇلارنى ئىزدەڭ.

***

بۇ ماقالە ئۈچۈن بەزى پاكىتلارنى تەكشۈرۈش كېرەك

***

## ھۆججەت ئۇچۇرى

ھۆججەت تىپى: `Markdown (* .md)`

قۇر سانى (قۇرۇق قۇر ۋە تۈزگۈچى قۇرنى ئۆز ئىچىگە ئالىدۇ): `968`

ھۆججەت نۇسخىسى: `6 (2021-يىلى 4-ئاينىڭ 18-كۈنى يەكشەنبە ، چۈشتىن كېيىن 4:18)

***

### يۇمشاق دېتال ھالىتى

مېنىڭ ئەسەرلىرىمنىڭ ھەممىسى بىر قىسىم چەكلىمىلەر. DRM (** D ** igital ** R ** estrictions ** M ** anagement) مېنىڭ ھېچقانداق ئەسەرلىرىمدە يوق.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

بۇ چاپلاقنى ھەقسىز يۇمشاق دېتال فوندى قوللايدۇ. مەن ھەرگىزمۇ DRM نى ئەسەرلىرىمگە كىرگۈزۈشنى ئويلىمايمەن.

مەن «رەقەملىك چەكلىمىلەرنى باشقۇرۇش» نىڭ قىسقارتىلمىسىنى «رەقەملىك ھوقۇق باشقۇرۇش» نىڭ ئورنىغا ئىشلىتىۋاتىمەن ، چۈنكى بۇنى ھەل قىلىشنىڭ ئورتاق ئۇسۇلى يالغان ، DRM بىلەن ھېچقانداق ھوقۇق يوق. «رەقەملىك چەكلەشنى باشقۇرۇش» ئىملاسى تېخىمۇ توغرا بولۇپ ، [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) ۋە [ھەقسىز يۇمشاق دېتال فوندى (FSF)) قوللايدۇ https://en.wikipedia.org/wiki/Free_Software_Foundation)

بۇ بۆلەك DRM دىكى مەسىلىلەرگە بولغان تونۇشىنى ئۆستۈرۈش ، شۇنداقلا ئۇنىڭغا ئېتىراز بىلدۈرۈش ئۈچۈن ئىشلىتىلىدۇ. DRM لايىھىلەشتە كەمتۈك بولۇپ ، بارلىق كومپيۇتېر ئىشلەتكۈچىلەر ۋە يۇمشاق دېتال ئەركىنلىكى ئۈچۈن زور تەھدىت.

رەسىم ئىناۋىتى: [defektbydesign.org/drm-free/...)(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## ياردەم بەرگۈچى ئۇچۇر

! [SponsorButton.png] (SponsorButton.png) <- بۇ كۇنۇپكىنى باسماڭ ، ئىشلىمەيدۇ ، ئۇ پەقەت بىر رەسىم. ھەقىقىي كۇنۇپكا ئوڭ تەرەپ (<- L ** R ** ->) بۇلۇڭىدىكى بەتنىڭ ئۈستىدە

ئەگەر خالىسىڭىز بۇ تۈرگە ياردەم قىلالايسىز ، ئەمما نېمىگە ئىئانە قىلماقچى ئىكەنلىكىڭىزنى بەلگىلىۈڭ. [بۇ يەرگە ئىئانە قىلالايدىغان مەبلەغنى كۆرۈڭ] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

باشقا ياردەم بەرگۈچىلەرنىڭ ئۇچۇرلىرىنى [بۇ يەردىن] كۆرەلەيسىز (https://github.com/seanpm2001/Sponsor-info/)

سىناپ بېقىڭ! ياردەم بەرگۈچى كۇنۇپكىسى سائەت / كۆرۈش كۇنۇپكىسىنىڭ يېنىدا.

***

## ھۆججەت تارىخى



 * ھۆججەتنى قوزغىدى

> * تېما بۆلىكى قوشۇلدى

> * كۆرسەتكۈچ قوشۇلدى

> * مۇناسىۋەتلىك بۆلەكنى قوشتى

> * Wiki بۆلىكىنى قوشتى

> * نەشر تارىخى بۆلىكى قوشۇلدى

> * مەسىلىلەر بۆلىكى قوشۇلدى.

> * ئالدىنقى مەسىلىلەر بۆلىكىنى قوشتى

> * ئالدىنقى تارتىش تەلەپلىرى بۆلىكى قوشۇلدى

> * ئاكتىپ تارتىش تەلەپلىرى بۆلىكى قوشۇلدى

> * تۆھپىكارلار بۆلىكى قوشۇلدى

> * تۆھپە قوشۇش بۆلىكى قوشۇلدى

> * README ھەققىدىكى بۆلەكنى قوشتى

> * README نەشرى تارىخى بۆلىكى قوشۇلدى

> * بايلىق بۆلىكى قوشۇلدى

> * DRM ھەقسىز چاپلاق ۋە ئۇچۇر بىلەن يۇمشاق دېتال ھالىتى بۆلىكى قوشۇلدى

> *ياردەم بەرگۈچىلەر ئۇچۇر بۆلىكى قوشۇلدى

> * 0.1 نەشرىدە باشقا ئۆزگىرىش يوق

1-نەشرى (2021-يىلى 2-ئاينىڭ 19-كۈنى جۈمە ، كەچ سائەت 5:20 دە)

> ئۆزگەرتىش:

> * ھۆججەتنى قوزغىدى

> * ئاساسىي چۈشەندۈرۈش بۆلىكى قوشۇلدى

> * ئامبار چۈشەندۈرۈش بۆلىكى قوشۇلدى

> * ماقالىلەر تىزىملىكى قوشۇلدى ، 14 تۈر بار

>> * مۇناسىۋەتلىك ماقالىلەر »سەھىپىسىنى قوشتى

>> * يەنە «قاراڭ» دېگەن بۆلەكنى قوشتى

> * ھۆججەت ئۇچۇر بۆلىكى قوشۇلدى

> * ھۆججەت تارىخى بۆلىكى قوشۇلدى

> * بەت ئاستىنى قوشتى

> * 1-نەشرىدە باشقا ئۆزگىرىش يوق

2-نەشرى (2021-يىلى 2-ئاينىڭ 19-كۈنى جۈمە ، كەچ سائەت 5:26 دە)

> ئۆزگەرتىش:

> * تەرجىمە ھالىتى بۆلىكى قوشۇلدى

> * بۆلەكنى تەكشۈرۈش ئۈچۈن باشقا نەرسىلەرنى قوشتى

> * مەخپىيەتلىك بۆلىكى قوشۇلدى

> * كۆرسەتكۈچ قوشۇلدى

> * يۇمشاق دېتال ھالىتى تارماق قىسمى قوشۇلدى

> * گۇگۇلغا قارشى باشقا تەشۋىقات بۆلەكلىرىنى قوشتى

>> * توختاپ قالغان بۆلەكنى قوشتى

>> * داۋاملىشىۋاتقان بۆلەكنى قوشتى

> * مەنبە بۆلىكىنى قوشتى

> * چۈشۈرۈش ئۇلىنىش بۆلىكى قوشۇلدى

> * ھۆججەت ئۇچۇر بۆلىكى يېڭىلاندى

> * ھۆججەت تارىخى بۆلىكى يېڭىلاندى

> * 2-نەشرىدە باشقا ئۆزگىرىش يوق

3-نەشرى (2021-يىلى 2-ئاينىڭ 24-كۈنى چارشەنبە كەچ سائەت 7:56 دە)

> ئۆزگەرتىش:

> * كۆرسەتكۈچ يېڭىلاندى

> * Degoogle سىنبەلگىسى ۋە يېڭى GitHub تەشكىلاتىنى كۆرسىتىدۇ

> * يېڭى ماقالىلەرگە ئۇلىنىش قوشۇلدى

> * قارشى تۇرۇش باشقا تالاش-تارتىش بۆلىكىنى قوشتى

>> * قۇلايلىق بۆلەك قوشۇلدى

>> * نېمىشقا ئاۋارە قىلىدىغان بۆلەكنىمۇ قوشتى

>> * باشقا بۆلەكنى قوشتى

> * بەزى سانلىق مەلۇماتلار يېڭىلاندى

> * ھۆججەت ئۇچۇر بۆلىكى يېڭىلاندى

> * ھۆججەت تارىخى بۆلىكى يېڭىلاندى

> * 3-نەشرىدە باشقا ئۆزگىرىش يوق

4-نەشرى (2021-يىلى 25-فېۋرال كەچ سائەت 9 دىن 31 مىنۇت ئۆتكەندە)

> ئۆزگەرتىش:

> * 10 يېڭى ماقالىگە ئۇلىنىش قوشۇلدى

> * مېنىڭ تەجرىبەمنى ئەمەلدىن قالدۇرۇش توغرىسىدا بىر بۆلەك قوشتى

> * كۆرسەتكۈچ يېڭىلاندى

> * ھۆججەت ئۇچۇر بۆلىكى يېڭىلاندى

> * ھۆججەت تارىخى بۆلىكى يېڭىلاندى

> * 4-نەشرىدە باشقا ئۆزگىرىش يوق

5-نەشرى (2021-يىل 4-ئاينىڭ 9-كۈنى جۈمە ، كەچ سائەت 6:02 دە)

_ يېقىندىن بۇيان مەندىن گۇگۇلغا قارشى تۇرۇش ھەرىكىتىنىڭ يېڭىلىنىشى كەمچىل بولدى ، مەن 1+ ئاي توختاپ قالغاندىن كېيىن ئۇنىڭغا قايتىش ئۈچۈن تىرىشىۋاتىمەن ._

> ئۆزگەرتىش:

> * تېما بۆلىكى يېڭىلاندى

> * كۆرسەتكۈچ يېڭىلاندى

> * تىل تىزىملىكى يېڭىلاندى: مۇقىم ئۇلىنىشلار ۋە تېخىمۇ كۆپ قوللايدىغان تىللار قوشۇلدى

> * ماقالە ھالىتى بۆلىكىنى يېڭىلاپ ، 4 چاتما ئۇلىنىش قوشتى

> * يۇمشاق دېتال ھالىتى بۆلىكىنى يېڭىلىدى

> * Go قوشۇلدى رەزىل بۆلەك

> * DRM بۆلىكىنىڭ ئىشلىتىلىشى قوشۇلدى

> * ئورتاق خاتا چۈشەنچە بۆلىكى قوشۇلدى

>> * قوشۇلغان گۇگۇل ئىنتېرنېت تارماق قىسمى ئەمەس

> * Internet Explorer 6 ۋە Chrome بۆلىكىنى قوشتى

>> * باتۇر تارماق قىسمىدا مەسىلە قوشۇلدى

> * Faux مەخپىيەتلىكنى ئۆچۈرۈش قوشۇلدى

> * ئوچۇق كودنى قوشقاندا قىسمەن بۆلەك بولالمايدۇ

> * Oxymoron تارماق قىسمىنى قوشتى

> * ناچار ئىقتىدار بۆلىكى قوشۇلدى

> * ناچار تۈر باشقۇرۇش بۆلىكى قوشۇلدى

> * قورقۇنۇچلۇق ياكى مۇلازىمەتنىڭ ئوتتۇراھاللىقى يوق

> * ئاسترونومىيە بۆلۈمى قوشۇلدى

> * قانۇنسىز ۋە ئەخلاقسىز سودا مەشغۇلات بۆلىكى قوشۇلدى

> * ياۋروپادا تارماق بۆلەك قوشۇلدى

>> * شىمالىي ئامېرىكىدا تارماق بۆلەك قوشۇلدى

>> * تالاش-تارتىش بۆلىكى قوشۇلدى

> * Google ئاپتوماتىك بۆلەك قوشۇلدى

> * ئاندىرويىد بۆلىكىنى قوشتى

> * ياردەم بۆلىكىگە كىچىك ھەرىكەتلەر قوشۇلدى

> * ئىشەنچسىز بۆلەك قوشۇلدى

> * ياردەم بەرگۈچىلەر ئۇچۇر بۆلىكى قوشۇلدى

> * بەت ئاستىنى يېڭىلىدى

> * ھۆججەت ئۇچۇر بۆلىكى يېڭىلاندى

> * ھۆججەت تارىخى بۆلىكى يېڭىلاندى

> * 5-نەشرىدە باشقا ئۆزگىرىش يوق

6-نەشرى (2021-يىلى 4-ئاينىڭ 18-كۈنى يەكشەنبە ، چۈشتىن كېيىن 4:18)

> ئۆزگەرتىش:

> * كۆرسەتكۈچ يېڭىلاندى

> * يېڭى ئومۇمىي چۈشەنچە قوشۇلدى

> * ماقالە ھالىتى ئۇچۇرى يېڭىلاندى

> * يېڭى Google FLoC ماقالىسىگە ئۇلىنىش قوشۇلدى

> * Wuest 3n Fuchs Degoogle ماقالىسىگە ئۇلىنىش ۋە ئۇنىڭدىكى ئومۇمىي ئۇچۇرلار قوشۇلدى

> * ھۆججەت ئۇچۇر بۆلىكى يېڭىلاندى

> * ھۆججەت تارىخى بۆلىكى يېڭىلاندى

> * 6-نەشرىدە باشقا ئۆزگىرىش يوق

7-نەشرى (پات يېقىندا كېلىدۇ)

> ئۆزگەرتىش:

> * پات يېقىندا كېلىدۇ

> * 7-نەشرىدە باشقا ئۆزگىرىش يوق

8-نەشرى (پات يېقىندا كېلىدۇ)

> ئۆزگەرتىش:

> * پات يېقىندا كېلىدۇ

> * 8-نەشرىدە باشقا ئۆزگىرىش يوق

9-نەشرى (پات يېقىندا كېلىدۇ)

> ئۆزگەرتىش:

> * پات يېقىندا كېلىدۇ

> * 9-نەشرىدە باشقا ئۆزگىرىش يوق

10-نەشرى (پات يېقىندا كېلىدۇ)

> ئۆزگەرتىش:

> * پات يېقىندا كېلىدۇ

> * 10-نەشرىدە باشقا ئۆزگىرىش يوق

11-نەشرى (پات يېقىندا كېلىدۇ)

> ئۆزگەرتىش:

> * پات يېقىندا كېلىدۇ

> * 11-نەشرىدە باشقا ئۆزگىرىش يوق

12-نەشرى (پات يېقىندا كېلىدۇ)

> ئۆزگەرتىش:

> * پات يېقىندا كېلىدۇ

> * 12-نەشرىدە باشقا ئۆزگىرىش يوق

***

## Footer

بۇ ھۆججەتنىڭ ئاخىرىغا كەلدىڭىز

([يۇقىرىغا قايتىش] (# ئۈستى) | [GitHub غا قايتىش] (https://github.com))

### EOF

***
