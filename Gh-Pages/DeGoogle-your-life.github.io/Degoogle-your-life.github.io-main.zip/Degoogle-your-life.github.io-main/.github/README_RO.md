***

! [DEGOOGLE1.jpeg] (DEGOOGLE1.jpeg)

# Degoogling - Degoogle viața ta

Acesta este articolul principal despre degoogling pentru informații generale despre degoogling și un link către celelalte articole.

[Consultați lista ca organizație GitHub] (https://github.com/Degoogle-your-life)

***

_Citiți acest articol într-o altă limbă: _

** Limba actuală este: ** `engleză (SUA)` _ (traducerile ar putea fi necesare pentru a corecta limba engleză înlocuind limba corectă) _

_🌐 Lista limbilor_

** Sortate după: ** `A-Z`

[Opțiunile de sortare nu sunt disponibile] (https://github.com/Degoogle-your-Life)

([af afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albaneză | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) Arabă | [hy հայերեն] (/. github / README_HY.md) Armenian | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijani | [eu Euskara] (/. github /README_EU.md) Bască | [be Беларуская] (/. Github / README_BE.md) Belarusian | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosniacă | [bg български] (/. Github / README_BG.md) Bulgară | [ca Català] (/. Github / README_CA.md) Catalană | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chineză (simplificată) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chineză (tradițională) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Croată | [cs čeština] (/. Github / README_CS .md) cehă | [da dansk] (README_DA.md) daneză | [nl Nederlands] (/. github / README_ NL.md) olandeză | [** en-us English **] (/. github / README.md) English | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonian | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finlandeză | [fr français] (/. github / README_FR.md) franceză | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galiciană | [ka ქართველი] (/. github / README_KA) Georgian | [de Deutsch] (/. github / README_DE.md) Germană | [el Ελληνικά] (/. github / README_EL.md) greacă | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Creole Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) ebraică | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) maghiară | [este Íslenska] (/. github / README_IS.md) islandeză | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) islandeză | [ga Gaeilge] (/. github / README_GA.md) irlandez | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) japoneză | [jw Wong jawa] (/. github / README_JW.md) javanez | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Coreeană (Sud) | [ko-nord 문화어] (README_KO_NORTH.md) coreeană (nord) (NEÎNCĂ TRADUSĂ) | [ku Kurdî] (/. github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirghiză | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lituanian | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgheză | [mk Македонски] (/. github / README_MK.md) Macedoneană | [mg malgache] (/. github / README_MG.md) malgache | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltese | [mi maori] (/. github / README_MI.md) maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolă | [my မြန်မာ] (/. github / README_MY.md) Myanmar (birmaneză) | [ne नेपाली] (/. github / README_NE.md) Nepalieră | [no norsk] (/. github / README_NO.md) Norvegian | [sau ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persană [pl polski] (/. github / README_PL.md) Poloneză | [pt português] (/. github / README_PT.md) portugheză | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Nu există limbi disponibile care încep cu litera Q | [ro Română] (/. github / README_RO.md) română | [ru русский] (/. github / README_RU.md) rusă | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) gaelică scoțiană | [sr Српски] (/. github / README_SR.md) sârbă | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovacă | [sl Slovenščina] (/. github / README_SL.md) slovenă | [deci Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) spaniolă | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) suedez | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) tătară | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Turcă | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) ucraineană | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnameză | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Disponibil în 110 limbi (108 când nu se numără engleza și coreeana de Nord, deoarece Coreea de Nord nu a fost încă tradusă [Citiți despre aceasta aici] (/ OldVersions / Korean (North ) /README.md))

Traducerile în alte limbi decât engleza sunt traduse automat și nu sunt încă exacte. Încă nu au fost remediate erori începând cu 5 februarie 2021. Vă rugăm să raportați erorile de traducere [aici] (https://github.com/seanpm2001/Degoogle-your-life/issues/) asigurați-vă că faceți o copie de rezervă a corecției cu surse și ghidați-mă , întrucât nu știu bine alte limbi decât engleza (intenționez să obțin un traducător în cele din urmă) vă rugăm să citați [wiktionary] (https://en.wiktionary.org) și alte surse din raportul dvs. În caz contrar, va fi publicată respingerea corecției.

Notă: datorită limitării interpretării GitHub a markdown-ului (și aproape a oricărei alte interpretări bazate pe web a markdown-ului), făcând clic pe aceste linkuri vă va redirecționa către un fișier separat pe o pagină separată care nu este pagina mea de profil GitHub. Veți fi redirecționat către [depozitul seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), unde este găzduit README.

Traducerile se fac cu Google Translate datorită asistenței limitate sau absente pentru limbile de care am nevoie în alte servicii de traducere precum DeepL și Bing Translate (destul de ironic pentru o campanie anti-Google) Lucrez la găsirea unei alternative. Din anumite motive, formatarea (linkuri, divizoare, caractere aldine, cursive etc.) este încurcată în diferite traduceri. Este obositor de remediat și nu știu cum să rezolv aceste probleme în limbi cu caractere non-latine, iar limbile de la dreapta la stânga (cum ar fi araba) este nevoie de ajutor suplimentar pentru remedierea acestor probleme.

Din cauza problemelor de întreținere, multe traduceri sunt depășite și utilizează o versiune învechită a acestui fișier de articol „README”. Este nevoie de un traducător. De asemenea, începând cu 9 aprilie 2021, îmi va lua ceva timp să pun în funcțiune toate linkurile noi.

***

## Index

[00.0 - Titlu] (# Degoogling --- Degoogle-your-life)

> [00.1 - Index] (# Index)

[01.0 - Descriere de bază] (# Descriere de bază)

> [01.1 - Antet de depozit] (# Degoogle-your-life)

> [01.2 - Prezentare generală a descrierii Wuest3NFuchs] (# Overview-by-Wuest3nFuchs)

>> [01.2.1 - Ce înseamnă?] (# What-does-it-mean - by-Wuest3nFuchs)

>> [01.2.2 - De ce Degoogle?] (# Why-Degoogle - by-Wuest3nFuchs)

[02.0 - Articole] (# Articole)

[03.0 - Confidențialitate] (# Confidențialitate)

[04.0 - Alte campanii anti-Google] (# Alte campanii anti-Google)

> [04.0.1 - Defunct] (# Defunct)

> [04.0.2 - În curs] (# În curs)

[05.0 - Combaterea altor argumente] (# Countering-other-arguments)

> [05.0.1 - Comoditate] (# Comoditate)

> [05.0.2 - De ce contează? Oricum este prea târziu] (# De ce-contează, -este-prea-târziu-oricum)

> [05.0.3 - Altele] (# Altele)

[06.0 - Surse] (# Surse)

[07.0 - Descărcare linkuri] (# Descărcare-linkuri)

[08.0 - Experiența mea degoogling] (# My-degoogling-experience)

> [08.1 - De la ce am trecut] (# De la ce-am trecut)

> [08.2 - Produse de care încă nu pot scăpa] (# Produse-încă-nu-pot-scăpa-de)

[09.0 - Alte lucruri de verificat] (# Alte lucruri de verificat)

[10.0 - Informații despre fișier] (# Informații despre fișier)

> [10.1 - Stare software] (# Stare software)

> [10.2 - Informații despre sponsor] (# Informații despre sponsor)

[11.0 - Istoricul fișierelor] (# Istoricul fișierelor)

[12.0 - subsol] (# subsol)

***

## Descriere de bază

[Din Wikipedia: Degoogle] (https://en.wikipedia.org/wiki/DeGoogle)

Mișcarea DeGoogle (numită și mișcarea de-Google) este o campanie de bază care a apărut, deoarece activiștii de confidențialitate îndeamnă utilizatorii să nu mai folosească produsele Google în totalitate din cauza preocupărilor tot mai mari privind confidențialitatea cu privire la companie. Termenul se referă la actul de a scoate Google din viața cuiva. Întrucât cota de piață în creștere a gigantului internet creează putere monopolistă pentru companie în spațiile digitale, un număr tot mai mare de jurnaliști au observat dificultatea de a găsi alternative la produsele companiei.

**Istorie**

În 2013, John Koetsier, de la Venturebeat, a declarat că tableta Amazon Kindle Fire, bazată pe Android, este „o versiune a Android de-Google-ized”. În 2014, John Simpson de la US News a scris despre „dreptul de a fi uitat” de Google și alte motoare de căutare. În 2015, Derek Scally de la Irish Times a scris un articol despre cum să „De-Google-ți viața”. În 2016 Kris Carlon din Android Autoritatea a sugerat ca utilizatorii CyanogenMod 14 să-și poată „de-Google” telefoanele, deoarece CyanogenMod funcționează bine și fără aplicațiile Google. În 2018, Nick Lucchesi de la Inverse a scris despre modul în care ProtonMail promovează cum să „poți să-ți dezamăgești complet viața”. Jurnalistul Gizmodo Kashmir Hill susține că a ratat întâlnirile și a avut dificultăți în organizarea întâlnirilor fără utilizarea Google Calendar. În 2019, Huawei a acordat o rambursare proprietarilor de telefoane din Filipine care erau inhibat de la utilizarea serviciilor furnizate de Google deoarece există atât de puține alternative încât absența produselor companiei a făcut imposibilă utilizarea normală a internetului.

***

# Degoogle-your-life
Un depozit pentru informații generale despre degoogling și linkuri către celelalte depozite degoogling ale mele.

***

## Prezentare generală de Wuest3nFuchs

O descriere mai bună, oferită de [Wuest3nFuchs] (https://github.com/Wuest3nFuchs) - sursă: [Wuest3nFuchs / Degoogle] (https://github.com/Wuest3nFuchs/Degoogle)

### Ce înseamnă? de Wuest3nFuchs

Degoogling înseamnă să nu mai folosiți nimic care aparține Google, orice a fost creat de Google. Vorbesc despre motorul lor de căutare, despre serviciul lor de e-mail (Gmail), Youtube etc.

### De ce Degoogle? de Wuest3nFuchs

Google este una dintre cele mai puternice companii din lume în acest moment. Au stocat o cantitate imensă de informații pe noi toți. Unii ar susține că informațiile noastre sunt în siguranță cu ei, deoarece știu cum să le protejeze. Dar acest lucru nu este adevărat. Google a fost pătruns înainte și va fi pătruns în viitor. Poate că nu de un script pentru copii, dar va fi făcut de un stat național. Google stochează informații personale pe noi toți, deoarece astfel câștigă bani.

Ne scanează e-mailurile, stochează ceea ce căutăm atunci când folosim motorul lor de căutare, ce videoclipuri vizionăm pe Youtube. Acesta este modul în care ne vizează și ne construiesc un profil pentru a ne arăta un anunț pe baza a ceea ce am vorbit cu cel mai bun prieten al nostru, astfel încât să ne poată arăta un anunț pentru ceva de care avem nevoie, dar acest lucru este prea înfiorător. Mulțumită domnului Snowden știm acum că Google a împărtășit informațiile noastre personale cu NSA în cadrul unui program numit ** „PRISM” **.


În viitor, cineva va putea accesa toate acele informații și vă asigur că se va întâmpla ceva cu adevărat rău. Pentru a preveni acest lucru, ar trebui să începeți Degoogling chiar acum. De asemenea, nu ar trebui să utilizați produsele unei companii care vă partajează datele cu ** NSA **. Ar trebui să opriți toate acestea prin degoogling.

** Dacă alte persoane o pot face, o puteți face și voi. **

[Citiți mai multe aici] (https://github.com/Wuest3nFuchs/Degoogle)

<! - Un link către furcă nu este în prezent listat, deoarece nu dețin în totalitate acest depozit și vreau să promovez alte surse. Ar fi egoist să mă conectez la propriul meu https://github.com/Degoogle-your-life/Degoogle! ->

***

## Articole

### Starea articolului

_Toate articolele sunt în prezent în lucru și au nevoie de îmbunătățiri masive. Sugestii și remedieri sunt permise._

_ Începând cu 18 aprilie 2021 la 16:09, majoritatea articolelor nu au fost încă lansate. Lucrez la găsirea timpului și a efortului pentru a le începe._

[De ce ar trebui să nu mai utilizați Google Chrome] (https://github.com/seanpm2001/Why-you-should-stop-using-Chrome) <! - 1! ->

[Nu mai utiliza ChromeBooks] (https://github.com/seanpm2001/Stop-using-Chromebooks) <! - 2! ->

[Opriți utilizarea WideVine DRM / Este timpul să tăiați WideVine DRM] (https://github.com/seanpm2001/Its-time-to-cut-WideVine-DRM) <! - 3! ->

[De ce ar trebui să nu mai folosiți ReCaptcha] (https://github.com/seanpm2001/Why-you-should-stop-using-ReCaptcha) <! - 4! ->

[Alternativ de la YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube) <! - 5! ->

[Opriți Google, de ce ar trebui să nu mai utilizați Căutarea Google] (https://github.com/seanpm2001/Stop-Googling--Why-you-should-stop-using-Google-Search) <! - 6! - >

[De ce ar trebui să nu mai utilizați Gmail] (https://github.com/seanpm2001/Why-you-should-stop-using-GMail) <! - 7! ->

[De ce ar trebui să nu mai utilizați Android] (https://github.com/seanpm2001/Why-you-should-stop-using-Android) <! - 8! ->

[De ce ar trebui să evitați Google Amp] (https://github.com/seanpm2001/Why-you-should-avoid-Google-AMP) <! - 9! ->

[De ce ar trebui să nu mai utilizați Google Drive] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drive) <! - 10! ->

[De ce ar trebui să nu mai utilizați Google Maps și Google Earth] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-maps-and-Google-Earth) <! - 11! - ->

[Hei Google, oprește-te] (https://github.com/seanpm2001/Hey-Google-Stop) <! - 12! ->

[Opriți citirea din cărțile Google / Play] (https://github.com/seanpm2001/Stop-reading-from-Google-Books) <! - 13! ->

[Opriți utilizarea Google Classroom] (https://github.com/seanpm2001/Stop-using-Google-Classroom) <! - 14! ->

[De ce ar trebui să nu mai utilizați Google Traducere] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Translate) <! - 15! ->

[De ce ar trebui să nu mai utilizați Conturile dvs. Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Accounts) <! - 16! ->

** Articole noi care vor fi scrise în curând: **

[De ce ar trebui să nu mai utilizați Gerrit] (https://github.com/seanpm2001/Why-you-should-stop-using-Gerrit) <! - 17! ->

[De ce ar trebui să nu mai utilizați Google Analytics (depozitul este rupt la sfârșitul meu de miercuri, 24 februarie 2021 la 16:13)] (https://github.com/seanpm2001/Why-you-should-stop-using -Google-Analytics) <! - 18! ->

<! - Divizor de lucru! ->

[De ce ar trebui să nu mai utilizați Google AdSense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-AdSense) <! - 19! ->

[De ce ar trebui să nu mai utilizați Google One] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-One) <! - 20! ->

[De ce ar trebui să nu mai utilizați Google+ (defunct)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Plus) <! - 21! ->

[De ce ar trebui să nu mai utilizați Magazinul Google Play] (https://github.com/seanpm2001/Why-you-should-stop-using-the-Google-Play-Store) <! - 22! ->

[De ce ar trebui să nu mai utilizați Google Docs] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Docs) <! - 23! ->

[De ce ar trebui să nu mai utilizați Prezentări Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Slides) <! - 24! ->

[De ce ar trebui să nu mai utilizați Foi de calcul Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sheets) <! - 25! ->

[De ce ar trebui să nu mai utilizați Google Forms] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Forms) <! - 26! ->

[De ce ar trebui să nu mai utilizați Google Cardboard] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Cardboard) <! - 27! ->

[De ce ar trebui să nu mai utilizați Google Messages] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Messages) <! - 28! ->

[De ce ar trebui să nu mai utilizați Google Material Design] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Material-Design) <! - 29! ->

[De ce ar trebui să nu mai utilizați Google Glass / Glasses] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Glass) <! - 30! ->

[De ce ar trebui să nu mai utilizați Google Fuchsia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Fuchsia) <! - 31! ->

[De ce ar trebui să nu mai utilizați GBoard] (https://github.com/seanpm2001/Why-you-should-stop-using-GBoard) <! - 32! ->

[De ce ar trebui să nu mai utilizați Google Home] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Home) <! - 33! ->

[De ce ar trebui să nu mai utilizați Google Nest] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Nest) <! - 34! ->

[De ce ar trebui să nu mai utilizați Google Hangouts (defunct)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Hangouts) <! - 35! ->

[De ce ar trebui să nu mai utilizați Google Duo] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Duo) <! - 36! ->

[De ce ar trebui să nu mai utilizați Google Tensorflow] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tensorflow) <! - 37! ->

[De ce ar trebui să nu mai utilizați Google Blockly] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Blockly) <! - 38! ->

[De ce ar trebui să nu mai utilizați Google Flutter] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Flutter) <! - 39! ->

[De ce ar trebui să nu mai utilizați limbajul de programare Googles Go] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Go) <! - 40! ->

[De ce ar trebui să nu mai utilizați limbajul de programare Googles Dart] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Dart) <! - 41! ->

[De ce ar trebui să nu mai utilizați formatul de imagine Googles WebP] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebP) <! - 42! ->

[De ce ar trebui să nu mai utilizați formatul video Googles WebM] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-WebM) <! - 43! ->

[De ce ar trebui să nu mai utilizați Google Video] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Video) <! - 44! ->

[De ce ar trebui să nu mai utilizați Site-uri Google (clasic)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_Classic) <! - 45! ->

[De ce ar trebui să nu mai utilizați Site-uri Google („Nou”)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Sites_New) <! - 46! ->

[De ce ar trebui să nu mai utilizați Google Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Pay) <! - 47! ->

[De ce ar trebui să nu mai utilizați Android Pay] (https://github.com/seanpm2001/Why-you-should-stop-using-Android-Pay) <! - 48! ->

[De ce ar trebui să nu mai folosiți Google VPN (oximoron)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-VPN) <! - 49! ->

[De ce ar trebui să nu mai utilizați Google Photos] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Photos) <! - 50! ->

[De ce ar trebui să nu mai utilizați Google Calendar] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Calendar) <! - 51! ->

[De ce ar trebui să nu mai utilizați VirusTotal (deoarece este deținut de Google din septembrie 2012) (https://github.com/seanpm2001/Why-you-should-stop-using-VirusTotal) <! - 52! - >

[De ce ar trebui să nu mai folosiți Google Fi] (https://github.com/seanpm2001/Why-you-should-stop-folosind-Google-Fi) <! - 53! ->

[De ce ar trebui să nu mai utilizați Google Stadia] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Stadia) <! - 54! ->

[De ce ar trebui să nu mai utilizați Google Keep] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Keep) <! - 55! ->

[De ce ar trebui să nu mai utilizați Google Base] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Base) <! - 56! ->

[De ce ar trebui să nu mai participați la Google Summer of Code] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Summer-of-code) <! - 57! - >

[De ce ar trebui să nu mai utilizați Camera Google] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Camera) <! - 58! ->

[De ce ar trebui să încetați să utilizați Google Calculator (poate părea extrem, dar ar trebui să renunțați la orice, extrem de ușor de alternat)] Calculator) <! - 59! ->

[De ce ar trebui să nu mai utilizați Google Survey + recompense] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Survey-rewards) <! - 60! ->

[De ce ar trebui să nu mai utilizați Google Drawings] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Drawings) <! - 61! ->

[De ce ar trebui să nu mai utilizați Tenor (site GIF, deținut de Google din 2019)] (https://github.com/seanpm2001/Why-you-should-stop-using-Google-Tenor) <! - 62! - ->

[Ce FLoC - De ce ar trebui să evitați problema mare a Google FLoCing (opriți utilizarea Google Chrome)] (https://github.com/seanpm2001/What-the-FLoC) <! - 63! ->

** Total articole: ** `63`

** Articolul [foaia de parcurs AB] (DegoogleCampaign_2021Roadmap_Part1.md) (până pe 12 martie 2021) 2 zile libere **

** Articolul [foaia de parcurs BB] (DegoogleCampaign_2021Roadmao_Part2.md) (până la? 2021) 2 zile libere **

Statutul articolului

Toate articolele sunt în prezent în lucru și au nevoie de îmbunătățiri masive. Sugestii și remedieri sunt permise.

** furculițe **

Extinderea rețelei mele Degoogle și adăugarea unei ușurințe de acces și a strigătelor comunității.

1. [Fossapps] (https://github.com/Degoogle-your-life/Fossapps) | Furcat de la: [https://github.com/wacko1805/Fossapps](https://github.com/wacko1805/Fossapps) (engleză)

2. [Confidențialitate-linkuri] (https://github.com/Degoogle-your-life/Privacy-links) | Furcat de la: [https://github.com/Arturro43/privacy-links](https://github.com/Arturro43/privacy-links) (poloneză)

3. [Delightful-Privacy] (https://github.com/Degoogle-your-life/Delightful-Privacy) | Furcat de la: [https://github.com/LinuxCafeFederation/Delightful-Privacy](https://github.com/LinuxCafeFederation/Delightful-Privacy) (engleză)

4. [Liste de blocuri] (https://github.com/Degoogle-your-life/blocklists) | Furcat de la: [https://github.com/jmdugan/blocklists](https://github.com/jmdugan/blocklists) (engleză)

5. [Degoogle, de Wuest3nFuchs] (https://github.com/Degoogle-your-life/Degoogle) | Furcat de la: [https://github.com/Wuest3nFuchs/Degoogle](https://github.com/Wuest3nFuchs/Degoogle) (engleză)

**Legate de**

[Cercetare mașină virtuală pentru telefonul Android Degoogled] (https://github.com/seanpm2001/Degoogled_Android_Phone_VM_Research)

**Vezi si:**

[Critica Google față de Wikipedia] (https://en.wikipedia.org/wiki/Criticism_of_Google)

[Cimitirul Google (killedbygoogle.com) - o listă sortată cu cele peste 224 de produse pe care Google le-a ucis] (https://killedbygoogle.com/)

> [Link GitHub] (https://github.com/codyogden/killedbygoogle)

[Sindicatul lucrătorilor din alfabet - Noul sindicat al lucrătorilor de la Google cu peste 800 de membri] (https://alphabetworkersunion.org/people/our-union/)

[Nu vrei să te desparti de oul de Paște dinozaur? Acest site web vă acoperă] (https://chromedino.com/)

***

## Confidențialitate

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument # Criticism) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free -esay-samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount- of-data-about-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered -date-personale-date-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares -monetizes-and) [c] (https://www.wired.com/story/google-tracks-you-privacy/) [o] (https://www.theguardian.com/commentisfree/2018/mar/ 28 / all-the-data-facebook-google-has-on-you-privacy) [r] (https://www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data- collection-rivelat.html) [d] (https://www.reuters.com/article/us-alphabet-google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/ sănătate-fitness-confidențialitate-date /) [h] (https://www.pcmag.com/news/google-sued-ov er-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: //www.engadget .com / australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https: //www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https://www.cnn.com /2019/11/12/business/google-project-nightingale-ascension/index.html)[o[(https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https://moz.com /blog/where-does-google-draw-the-data-collection-line)[e[(https://mashable.com/article/google-android-data-collection-study/)[s](https: //eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com /2019/01/21/technology/google-europe-gdpr-fine.html)[o[(https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data -revendică-în numele-5-m illion-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https://www.reuters.com/article/dataprivacy -googleyoutube-kidsdata-idUSL1N2J306W) [e] (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-phone-isnt-in-use/) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you.html) [p] (https: // topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/)[r](https://arstechnica.com/information-technology/2014/01 /what-google-can-really-do-with-nest-or-really-nests-data/)[i](https://www.cbsnews.com/news/google-education-spies-on-collects- date-despre-milioane-de-copii-acuză-proces-nou-mexico-procuror-general /) [v] (https://www.nationalreview.com/2018/04/the-student-data-mining-scandal -under-our-nases /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https://www.nytimes.com/2019 / 09/04 / tehnologie / google-yout ube-fine-ftc.html) [y] (https://medium.com/@hansdezwart/during-world-war-ii-we-did-have-something-to-hide-40689565c550) [.] (https : //medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (aș putea continua cu dovezi în acest sens, dar a durat mult să găsesc și să trec prin toate acestea articole)

Confidențialitatea produselor Google este întotdeauna proastă, datorită tuturor produselor Google care conțin programe spion.

Indiferent de ceea ce faceți, atunci când utilizați Google, toate datele dvs. personale sensibile sunt trimise către Google și către alții. De asemenea, Google a fost văzut trecând prin programe deschise. De exemplu, din experiența personală (pe Firefox) cu o filă YouTube deschisă pe care nu am vizitat-o, am urmărit mai multe videoclipuri offline (VLC Media Player) Mai târziu, când am fost să verific recomandările, era aproape tot ce vizionasem. Fără îndoială că spionează și alte programe.

În Chrome (și multe alte browsere) este prezent un mod incognito. În Chrome, acest mod este inutil, deoarece Google va prelua datele dvs. în continuare. Chiar dacă dezactivați extragerea / urmărirea datelor și activați semnalul „nu urmăriți”, surpriză surpriză, Google vă extrage datele.

Dacă credeți că nu aveți nimic de ascuns, ** vă înșelați **. Acest argument a fost demis de mai multe ori:

[Via Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden a remarcat „Argumentând că nu îți pasă de dreptul la viață privată, deoarece nu ai nimic de ascuns, nu diferă decât să spui că nu-ți pasă de libertatea de exprimare, deoarece nu ai nimic de spus.” Când spui, Nu am nimic de ascuns, tu spui, „nu-mi pasă de acest drept.” Spui: „Nu am acest drept, pentru că am ajuns la punctul în care trebuie să justific „Modul în care funcționează drepturile, guvernul trebuie să-și justifice intruziunea în drepturile dumneavoastră”.

2. Daniel J. Solove a declarat într-un articol pentru Cronica învățământului superior că se opune argumentului; el a declarat că un guvern poate plecak informații despre o persoană și poate provoca daune persoanei respective sau utilizați informații despre o persoană pentru a refuza accesul la servicii, chiar dacă o persoană nu s-a angajat efectiv în săvârșirea de acte greșite și că un guvern poate provoca daune vieții personale prin comiterea unor erori. Solove a scris: „Atunci când este angajat direct, argumentul„ nimic ascuns ”poate prinde, pentru că forțează dezbaterea să se concentreze pe înțelegerea sa restrânsă a vieții private. dezvăluirea, argumentul nimic ascuns, în cele din urmă, nu are nimic de spus. "

3. Adam D. Moore, autorul drepturilor de confidențialitate: fundamentele morale și juridice, a susținut că „drepturile sunt rezistente la costuri / beneficii sau la argumente consecințialiste. Aici respingem opinia că interesele de confidențialitate sunt genul acesta. de lucruri care pot fi schimbate pentru siguranță ". El a afirmat, de asemenea, că supravegherea poate afecta în mod disproporționat anumite grupuri din societate în funcție de aspect, etnie, sexualitate și religie.

4. Bruce Schneier, expert în securitate informatică și criptograf, și-a exprimat opoziția, citând afirmația cardinalului Richelieu „Dacă cineva mi-ar da șase rânduri scrise de mâna celui mai cinstit om, aș găsi ceva în ele pentru a-l spânzura”, referindu-se la modul în care un guvern de stat poate găsi aspecte în viața unei persoane pentru a urmări sau șantaja persoana respectivă. Schneier a argumentat, de asemenea, „Prea mulți caracterizează în mod greșit dezbaterea drept„ securitate versus intimitate ”. Alegerea reală este libertatea versus control ".

5. Harvey A. Silverglate a estimat că persoana obișnuită, în medie, comite, fără să știe, trei infracțiuni pe zi în SUA.

6. Emilio Mordini, filosof și psihanalist, a susținut că argumentul „nimic de ascuns” este inerent paradoxal. Oamenii nu trebuie să aibă „ceva de ascuns” pentru a ascunde „ceva”. Ceea ce este ascuns nu este neapărat relevant, susține Mordini. În schimb, el susține că este necesară o zonă intimă care poate fi atât ascunsă, cât și restricționată pentru acces, deoarece, din punct de vedere psihologic, devenim indivizi prin descoperirea că am putea ascunde ceva altora.

7. Julian Assange a declarat: „Nu există încă un răspuns ucigaș. Jacob Appelbaum (@ioerror) are un răspuns inteligent, cerându-i oamenilor care spun asta să-i dea telefonul descuiat și să-și dea jos pantalonii. Versiunea mea este să spun, „Ei bine, dacă ești atât de plictisitor, atunci nu ar trebui să vorbim cu tine și nici cu nimeni altcineva”, dar din punct de vedere filosofic, răspunsul real este următorul: Supravegherea în masă este o schimbare structurală în masă. Când societatea merge prost, merge să te iau cu el, chiar dacă ești cea mai blandă persoană de pe pământ ".

8. Ignacio Cofone, profesor de drept, susține că argumentul este greșit în propriii termeni, deoarece, ori de câte ori oamenii dezvăluie informații relevante altora, ele dezvăluie și informații irelevante. Aceste informații irelevante au costuri de confidențialitate și pot duce la alte prejudicii, cum ar fi discriminarea.

***

## Alte campanii anti-Google

Aceasta este o listă cu alte campanii anti-Google notabile. Această listă este incompletă. Puteți ajuta extinzându-l.

### Defunct

[Scroogled - De Microsoft (noiembrie 2012 - 2014)] (https://en.wikipedia.org/wiki/Scroogled)

_Nicio altă intrare în acest moment._

### În curs de desfășurare

_Această listă este în prezent goală._

***

## Contracararea altor argumente

Există câteva argumente pe care oamenii le argumentează pentru a justifica Google. Unul dintre primele mari este deja dezmembrat [aici] (# Confidențialitate), dar iată câteva altele:

### Comoditate

Da, produsele Google par convenabile. Cu toate acestea, tranzacționați tot ceea ce este bun pentru confort, inclusiv securitate, confidențialitate și fiabilitate. Google a devenit mai leneș de-a lungul anilor, iar serverele lor au scăzut din ce în ce mai mult. În acest moment, serverele Google coboară timp de aproape o oră de 1-2 ori pe lună (în special YouTube)

Din păcate, datorită dependenței societăților de Google, Google a ajuns să domine Internetul și încearcă să controleze din ce în ce mai mult. În 2012, când Google a scăzut timp de 5 minute, s-a raportat că ** traficul Internet global ** a scăzut cu 40% ** Google coboară frecvent timp de 1-2 ore și cu [concedierea echipei lor de etică] (https://techcrunch.com/2021/02/19/google-fires-top-ai-ethics-researcher-margaret-mitchell/), printre altele, acestea vor deveni din ce în ce mai puțin convenabile.

Confortul nu este întotdeauna un lucru bun. Ar trebui să fiți conștienți de ceea ce se întâmplă și să fiți pregătiți atunci când coboară, deoarece nu există o modalitate de a face ca un server să nu coboare din când în când.

De asemenea, Google nu este atât de convenabil pe cât credeți. Există și alte site-uri mult mai convenabile. Google este departe de a fi convenabil, atunci când îi contabilizați suspendările și rezilierile aleatorii ale contului fără niciun răspuns (cu excepția cazului în care atrageți suficientă atenție asupra contului Google Twitter sau îi dați în judecată pentru 100.000.000 USD sau mai mult), atunci ei au profitat de dvs., v-au înșelat și te-a forțat să țipi într-o pernă, unde nimeni nu-ți putea auzi țipetelepentru ajutor.

### De ce contează, este prea târziu oricum

Acesta este un argument mai puțin obișnuit, dar are nevoie de explicații. Odată cu starea actuală, majoritatea guvernelor mondiale, împreună cu mai multe corporații puternice, par să-ți cunoască fiecare mișcare, așa că de ce să te deranjezi chiar să scapi de ea? Răspunsul este simplu: ** meriți mai bine **. Dacă reușești să te îndepărtezi de ele în acest moment, le este mai greu să-ți urmărească mișcările în continuare și poți construi o nouă viață mai privată.

] acum (împreună cu toate cele 500 de monede gratuite) pentru a susține acest subiect în continuare. Până acum, am acordat acestui post peste 14 premii gratuite. Nu este mult, dar lucrurile mici pot avea un impact mare, în funcție de modul în care sunt percepute și de cine.

### Alte

Nu am alte argumente în acest moment.

_Această listă este incompletă_

***

## Surse

Copie:

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Criticism) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- date-despre-tu-poți-găsi-și-șterge-acum /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -și) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o[(https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- revendicări-în-numele-5-milioane-de-utilizatori-iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technology / 2014/01 / what-google-can-really-do-with-nest-or-really-nests data /) [i] (https://www.cbsnews.com/news/google-education -spies-on-collects-data-on-millions-of-children-allegations-process-new-mexico-procurney-general /) [v] (https://www.nationalreview.com/2018/04/the- student-data-mining-scandal-under-our-nases /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www.nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y)(https://medium.com/@hansdezwart/during-world-war-ii-we-did -have-something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c)

Alte surse:

[Alianța Cinci ochi] (https://en.wikipedia.org/wiki/Five_Eyes) [Nouăzeci și optzeci și patru] (https://en.wikipedia.org/wiki/Nineteen_Eighty-Four)

***

## Descarcă linkuri

[Obțineți Firefox] (https://www.mozilla.org/en-US/firefox/new/) [Descărcați browserul Tor] (https://www.torproject.org/download/) [Altele / indisponibil] (https : //www.example.com)

***

## Experiența mea degoogling

În sfârșit, am început să văd problemele cu tehnologia mare în 2018 și am început să renunț la căutare. În primele câteva luni, am făcut progrese semnificative. De atunci a încetinit enorm.


### De la ce am trecut

Google Chrome -> Firefox / Tor

Căutare Google -> DuckDuckGo (implicit) / Ecosia (când îmi vine) / Bing (rar)

GMail - ProtonMail (încă nu este complet comutat)

Site-uri Google -> Găzduire autonomă (încă nu este complet comutat)

Google+ -> Aproape niciodată folosit, s-a șters din cauza propriei opriri

Documente Google -> Nu a fost folosit niciodată, folosesc doar Microsoft Word 2013 (înainte de 2019) și LibreOffice (2019-ul).

Foi de calcul Google -> Niciodată folosit, folosesc în schimb Microsoft Excel 2013 (înainte de 2019) și LibreOffice (2019-ul).

Prezentări Google -> Nu a fost folosit niciodată, folosesc doar Microsoft PowerPoint 2013 (înainte de 2019) și LibreOffice (începând cu 2019).

Desene Google -> Niciodată folosit, folosesc în schimb LibreOffice (2019-ul).

Gerrit -> Niciodată folosit, folosesc doar GitHub (implicit curent), GitLab, BitBucket și SourceForge.

Google Photos -> Niciodată folosit

Google Drive -> OneDrive (2019-2020) Degoo (2020-2020) pCloud (2020-prezent)

Google Maps -> OpenStreetMaps / Apple Maps

Go - Efectuarea unei excepții speciale, dar nu folosirea ca limbaj de programare funcțional

Dart - Se face o excepție specială, dar nu se folosește ca limbaj de programare funcțional

Flutter - Se face o excepție specială, dar nu se folosește ca limbaj de programare funcțional

Google Earth -> OpenStreetMaps / Apple Maps

Google Streetview -> Niciodată folosit, mi se pare extraordinar

Google Fi -> Niciodată folosit

Google Calendar -> Niciodată folosit

Calculator Google -> Literalmente orice altă aplicație de calculator, chiar și un terminal Linux care rulează în modul Python, dacă îmi place

Google Nest -> Nu a fost folosit niciodată

Google AMP -> Nu a fost folosit niciodată

Google VPN -> Niciodată folosit, de asemenea, un oximoron

Google Pay -> Nu a fost folosit niciodată

Google Summer of Code -> Nu a participat niciodată

Tenor -> Alte site-uri GIF, deși GIF-urile nu sunt prea importante pentru mine. În mod normal, primesc fișiere GIF din imagini DuckDuckGo, Imgur, Reddit sau alte site-uri.

Blockly -> Nu mai este utilizat, nu sunt sigur dacă Scratch a rulat direct blockly. Am devenit programator funcțional în 2017 și am crescut din Scratch.

GBoard -> Folosit o dată, dar abandonat

Google Glass -> Nu a fost folosit niciodată, considerat ca un copil mic, dar a decis să nu obțin unul / să îl folosesc dacă am opțiunea

_Lista poate fi incompletă._

### Produse de care încă nu pot scăpa

Începând cu 25 februarie 2021, acestea sunt produsele Google care mă împiedică să renunț complet:

1. YouTube

2. Android

3. Magazin Google Play

4. GMail (numai pentru școală și unele site-uri)

5. Google Classroom (numai pentru școală)

6. Traducere Google

7. Cont Google

8. Site-uri Google (întrucât Google încalcă legile GDPR (și se poate supune unei alte amenzi de 5.000.000,00 EUR până când nu vor fi remediate) și interzice descărcările acestui produs)

M-am dezlegat de orice altceva.

***

## Du-te este rău

Google a trecut peste limbajul de programare bazat pe agenți din 2003 „Go!” Cu limbajul de programare „Go” (din 2009, 6 ani mai târziu) și a susținut că limba lor nu ar afecta deloc cealaltă limbă. Google a fost criticat puternic pentru acest lucru, deoarece motto-ul lor „Nu fi rău” era încă activ la acea vreme și acesta este unul dintre numeroasele incidente care au făcut ca motto-ul să nu fii rău să fie retras.

În cele din urmă, dezvoltarea „Go!” A încetat, în timp ce „Go” a devenit din ce în ce mai frecventă. Google a susținut că nu se va deplasa peste „Du-te!”, Dar în cele din urmă au făcut-o și au scăpat (din 9 aprilie 2021)

[Citiți mai multe despre Go și cum să faceți o alternativă aici] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-Go)

***

## Utilizarea DRM

Google utilizează DRM (Digital Restrictions Management) prin „serviciul” WideVine DRM și alte forme. Scopul DRM este de a distruge internetul deschis și de a oferi companiilor putere monopolistă asupra utilizatorilor. Ar trebui să scăpați complet de WideVine, indiferent de cost.

[Citiți mai multe despre WideVine și problemele sale aici] (https://github.com/Degoogle-your-life/Its-time-a-tăia-WideVine-DRM)

***

## Concepții greșite frecvente

Aceasta este o listă a unor concepții greșite frecvente cu produsele Google.

### Google nu este Internetul

Căutarea Google / Google nu este Internetul, căutarea Google este doar un motor de căutare, un fel ca și cum nu fiecare joc pentru o platformă Nintendo este realizat de Nintendo, dar este licențiat de Nintendo, dar într-o măsură mult mai mare. Dacă toate serverele Googles ar fi distruse simultan în acest moment, doar site-urile Google precum YouTube, Gmail, Google Docs, căutarea Google etc. ar fi dispărut, dar majoritatea internetului ar mai fi acolo (Wikipedia, Stackoverflow, GitHub, toate site-urile web Microsofts, NYTimes, Samsung, TikTok etc.) își pot pierde funcționalitatea de conectare și analitică de la Google, dar ar fi în continuare funcționale (cu excepția cazului în care au fost slab programate și s-au bazat direct pe Google)

***

## Internet Explorer 6 și Chrome

Google Chrome devine noul Internet Explorer 6. Când a apărut inițial Google Chrome, Firefox era browserul dominant și, în mare parte, eliminase cota de piață a Internet Explorer (care depășea 96% înainte ca milioane de oameni să treacă la Firefox și alte browsere) când Google Chrome a ieșit, oamenii au schimbat din cauza vitezei sale și a fost de către Google (care nu era considerat ca fiind rău în acel moment, deoarece majoritatea problemelor de confidențialitate nu apăruseră încă) Google Chrome a respectat inițial standardele web (ceea ce a făcut Firefox care a ucis Internet Explorer-urile cu 96% cota de piață a browserului), totuși, pe măsură ce cota de piață Google Chromes a crescut, Google a început să elimine din ce în ce mai multe funcții, adăugând mai multe programe spion și a încetat să accepte standardele web, Google Chrome a devenit noul Internet Explorer 6.

Problema majoră în acest moment este site-urile web care sunt numai Chrome și nu vor funcționa pe alte browsere, deoarece dezvoltatorii lor au decis că nu vor ca ceilalți 30-40% dintre utilizatorii de internet care nu folosesc Chrome să își folosească site-ul.

Chiar și Google își creează site-urile numai Chrome. De exemplu, căutarea Google vă va solicita să descărcați Chrome de 3 ori la fiecare 10 secunde dacă detectează că nu utilizați Google Chrome (chiar și alte browsere bazate pe Chromium, cum ar fi Brave, sunt afectate) și site-uri precum Google Earth nu permit utilizatorilor Firefox să folosiți site-ul lor (începând cu 2020), plus Google Translate nu acceptă introducerea vocală pe Firefox și alte browsere care nu sunt Google Chrome.

### Problema cu Brave

Alte browsere care se bazează pe Chromium, cum ar fi Brave și Microsoft Edge, nu sunt complet libere de spyware Google. Brave este de obicei recomandat de partea greșită a comunității de confidențialitate, dar Brave este încă o problemă, deoarece folosește Chromium. Internetul nu ar trebui să fie format doar din browsere Chromium, ar trebui să existe o varietate de opțiuni. Curajos este calea greșită.

[Citiți mai multe despre degoogling de pe Google Chrome / Chromium aici] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Chrome)

[Citiți mai multe despre degoogling din ChromeOS / ChromiumOS (Chromebooks / Chromeboxes / Chromeblets / ChromeBits / ChromeETC) aici] (https://github.com/Degoogle-your-life/Stop-using-Chromebooks)

***

## Reînnoirea față a confidențialității

Google a încercat să spună lumii că le pasă de confidențialitate, după ce a fost deja prea târziu. Ei continuă să afirme că respectă confidențialitatea utilizatorilor, dar încă nu își rezolvă toate problemele de confidențialitate.

### Open source nu poate fi parțial

Open source nu poate fi parțial. Google este dovada acestui lucru. Fiecare bit și octet al codului sursă trebuie să fie vizibil publicului, fără a fi ascuns nici măcar un al optulea de octet.

Proiecte precum Android și ChromeOS sunt parțial open source, dar conțin majoritatea elementelor spyware proprietare.

### Oximoron

Google VPN este un oximoron. Lui Google nu îi pasă de confidențialitate, iar o rețea privată virtuală (VPN) de la o companie ca acestea ar fi una dintre cele mai slabe alegeri posibile pentru un serviciu VPN.

***

## Performanță proastă

Google nu-i pasă de performanța produselor lor începând cu cel puțin 2017, deoarece ultimul lor software de comparare (Google Octane) a fost întrerupt în 2017.

***

## Management de proiect prost

Google are un sistem intern de gestionare a proiectelor foarte prost. Câteva exemple obișnuite de programe care au devenit din ce în ce mai degradate includ Google Duo și muzica YouTube (fostă Google Play Music)

În sistemul de dezvoltare intern Googles, o aplicație duce la o altă aplicație cu jumătate din funcționalitate, apoi aplicația originală este ștearsă. Câțiva ani mai târziu, se realizează o nouă aplicație cu 75% funcționalitate mai mică, apoi aplicația cu 50% funcționalitate este eliminată, urmată de o nouă aplicație cu 87,5% din funcționalitatea fiind creată, apoi aplicația cu 75% funcționalitate este întreruptă , și așa mai departe.

***

## Modificare oribilă sau lipsă de servicii

YouTube este cel mai frecvent exemplu în lumea moderării proaste, creând cea mai proastă platformă existentă. De asemenea, Google nu pare să obțină faptul că YouTube nu este YouTube pentru copii.

Pentru YouTube, conținutul urăsc pro-nazist și supremacist alb este oferit utilizatorilor cu scopul de a implica mai mult timp și mai mulți bani. De asemenea, Google a făcut foarte multelucruri stupide în moderația lor, cum ar fi aprobarea unui videoclip de sex anal creștin ca conținut „creat pentru copii”, în timp ce restricționează în același timp videoclipul. De asemenea, nu este prea neobișnuit să vezi reclame pornografice sau gore chiar sub videoclipul Baby Shark, împreună cu alte conținuturi „făcute pentru copii”.

Utilizatorii YouTube se plâng extrem de frecvent de moderarea slabă pe YouTube pentru conținut rău (cum ar fi exemplele enumerate mai sus), în timp ce utilizatorii își pot șterge videoclipurile la întâmplare fără niciun motiv fără abilitate de abrogare, împreună cu utilizatorii care sunt pedepsiți pentru orice formă de înjurături, chiar și cazuri foarte minore, cum ar fi să spui că utilizatorii „prostii” compară de obicei YouTube cu [Uniunea Sovietică] (https://en.wikipedia.org/wiki/Soviet_Union) în epoca Stalin, din cauza acestor pedepse inegale.

În 2021, Google a anunțat că va pune anunțuri pe toate videoclipurile, în ciuda faptului că videoclipul este demonizat (astfel încât Google să câștige bani, dar creatorul nu), acest lucru nu se referă prea mult la moderare, dar este important de menționat.

YouTube este moderat (deși foarte slab), dar serviciul publicitar Google care îi face să câștige cea mai mare parte a banilor pare să aibă o moderare mică sau deloc moderată.

[Citiți mai multe despre problemele de moderare YouTube și despre cum să alternați de pe YouTube] (https://github.com/seanpm2001/Alternating-from-YouTube)

Reclamele pentru Google Play sunt generate de ferme de bot, vă puteți da seama de aceleași scenarii publicitare utilizate de sute de companii cu mici modificări și fără nicio legătură cu produsul (exemple comune: Playrix (Homescapes, Gardenscapes) Fishdom, Mafia City și alte mii) împreună cu o tendință rău intenționată în creștere a anunțurilor care susțin că utilizatorii pot câștiga bani jucând jocuri, ascultând muzică etc. PayPal nu a comentat acest lucru, dar este evident că este o înșelătorie, ca și cum ai putea face peste 10.000 de dolari în mai puțin de 20 de secunde jucând un joc garantat, nimeni nu ar face treabă și ar face asta în schimb, ceea ce este imposibil, iar o afacere nu ar putea funcționa astfel. Această înșelătorie evidentă a crescut din 2019, iar acum fermele de bot care produc aceste reclame se luptă între ele în propriile reclame.

Mai multe reclame sunt, de asemenea, foarte obraznice și încearcă să-i facă pe utilizatori (majoritatea dintre aceștia să fie utilizatori sub vârsta de 13 ani sau roboți) să facă clic prin manipulare sexuală.

Multe aplicații folosesc roboți și astroturfează produsele lor, așa că, de fiecare dată când se face o recenzie proastă, conturile de bot-marionetă șosete vor începe să posteze recenzii de 5 stele și vor încerca să-ți anuleze criticile. [Google face acest lucru și ei înșiși] (# Astroturfing)

[Citiți mai multe despre problemele legate de Google AdSense] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Google-AdSense)

***

## Astroturfing

Definiție generală [(din Wikipedia)] (https://en.wikipedia.org/wiki/Astroturfing)

""
Astroturfing-ul este practica de a masca sponsorii unui mesaj sau organizație (de exemplu, politic, publicitar, religios sau relații publice) pentru a face să pară că provine și este susținut de participanții de la bază. Este o practică menită să ofere credibilității declarațiilor sau organizațiilor prin reținerea informațiilor despre conexiunea financiară a sursei. Termenul de astroturfing este derivat din AstroTurf, o marcă de covoare sintetice concepute să semene cu iarba naturală, ca un joc pe cuvântul „la bază”. Implicația din spatele utilizării termenului este că, în locul unui efort de bază „adevărat” sau „natural” din spatele activității în cauză, există un aspect „fals” sau „artificial” de sprijin.
""

Google are o istorie a astroturfingului pentru a face să pară că nu fac nimic rău (în acest proces, astroturfingul este rău), de exemplu, postarea critică a Google pe o platformă precum Twitter (pe care au un cont) va avea ca rezultat mai multe conturi care au existat de ceva vreme, dar care nu au fost postate niciodată înainte de a ieși și de a susține că ceea ce ați spus este fals, și apoi a susține că Google este cea mai bună companie, dar realizat într-un mod care poate să nu fie evident că acestea sunt roboți pentru majoritatea oameni.

***

## Practici de afaceri ilegale și neetice

Google folosește practici comerciale ilegale și lipsite de etică pentru a-și continua monopolul, cum ar fi utilizarea paradisurilor fiscale, externalizarea locurilor de muncă și continuarea activităților invazive ilegale ca un cost al activității.

### In Europa

Europa a dat în judecată frecvent Google, cel mai mare proces fiind împotriva comportamentelor ilegale în Android, care au dus la primirea de către Google a unei sume de 5.000.000.000 € (echivalentul a 5.947.083.703,68 dolari în 9 aprilie 2021)

### În America de Nord

Statele Unite nu au acordat încă o amendă suficientă Google, în comparație cu o amendă de 5.000.000.000 de euro din Europa.

### Controverse

Lui Google nu îi pasă de o problemă până când nu creează o controversă, apoi vor face o încercare slabă de a o remedia, suficient pentru ca disputa să dispară temporar, iar problema se agravează exponențial până când creează o altă controversă și ciclul continuă. Pur și simplu nu le pasă suficient de mult pentru a face ceva serios.

***

## Google este automatizat

În calitate de comcompanie, Google este automatizat în cea mai mare parte, cu mai puțină moderare decât automatizarea.

O companie nu ar trebui să fie complet automatizată. Google este un exemplu în acest sens. Moderația este oribilă atunci când este realizată doar de AI, YouTube este un bun exemplu, chiar și cu puțini (sute sau poate o mie) de oameni care moderează site-ul, unde se pare că este atât de rău încât majoritatea dintre ei trebuie să primească terapie în timp ce lucrează.

***

## Android

Android este deținut de Google. Parte a Open Handset Alliance (care nu a mai fost deschisă de la Android) Android a devenit un alt punct de monopol pentru Google și unul foarte greu de scăpat.

Android a fost raportat că telefonează acasă la Google de cel puțin 10 ori pe zi și, în ciuda faptului că este parțial open source, acționează în continuare puternic ca spyware.

Au fost create mai multe proiecte pentru a alterna de la Android, dar necesită înrădăcinarea dispozitivului. Acest lucru pur și simplu nu mai este posibil pentru anumite telefoane Samsung din SUA, datorită Knox DRM. Alternativele comune la Android includ iOS, iPadOS, LineageOS, Android x86, Ubuntu Touch și PiPhone (Pi Phone este o marcă de telefoane care rulează diverse sisteme Linux pe un dispozitiv mobil, cum ar fi Fedora, Ubuntu, Arch etc.)

[Vedeți cercetările mele cu privire la funcționarea funcțională a unei mașini virtuale Android degoogled] (https://github.com/Degoogle-your-life/Degoogled_Android_Phone_VM_Research)

[Vedeți cum să degoogle de pe Android] (https://github.com/Degoogle-your-life/Why-you-should-stop-using-Android)

***

## Mici acțiuni de ajutor

Este important să răspândiți conștientizarea în toate modurile pe care le puteți. Pentru mine, nu numai că vorbesc frecvent despre degoogling și scriu articole, dar am și un mic obicei obișnuit, în care acord premiul meu Reddit gratuit zilnic postării fixate pe r / degoogle pentru a crește gradul de conștientizare. Până acum, am acordat aproape 30 de premii postării fixate (am cheltuit și 500 din monedele mele gratuite pentru 10 premii pentru postul respectiv)

***

## Incredibil

Google nu poate avea încredere și niciodată nu mai poate avea încredere. Au trecut complet de la „nu fi răi” (au fost întotdeauna răi) la a fi complet răi și nu au încercat să-l ascundă.

***

## Alte lucruri de verificat

[Cimitirul Google (killedbygoogle.com) - o listă sortată cu cele peste 224 de produse pe care Google le-a ucis] (https://killedbygoogle.com/)

> [Link GitHub] (https://github.com/codyogden/killedbygoogle)

[Sindicatul lucrătorilor din alfabet - Noul sindicat al lucrătorilor de la Google cu peste 800 de membri] (https://alphabetworkersunion.org/people/our-union/)

[Nu vrei să te desparti de oul de Paște dinozaur? Acest site web vă acoperă] (https://chromedino.com/)

Există și alți supleanți, doar căutați-i.

***

Pentru acest articol este necesară o verificare a faptelor

***

## Informații despre fișier

Tipul de fișier: `Markdown (* .md)`

Numărul de linii (inclusiv liniile goale și linia compilatorului): „968”

Versiunea fișierului: `6 (duminică, 18 aprilie 2021 la 16:18)`

***

### Starea software-ului

Toate lucrările mele sunt gratuite, unele restricții. DRM (** D ** igital ** R ** restricții ** M ** administrare) nu este prezent în niciuna dintre lucrările mele.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Acest autocolant este acceptat de Free Software Foundation. Nu intenționez niciodată să includ DRM în lucrările mele.

Folosesc abrevierea „Digital Restrictions Management” în locul celei mai cunoscute „Digital Rights Management”, deoarece modul obișnuit de abordare este fals, nu există drepturi cu DRM. Ortografia „Managementul restricțiilor digitale” este mai precisă și este susținută de [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) și de [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Această secțiune este utilizată pentru a crește gradul de conștientizare a problemelor cu DRM și, de asemenea, pentru a protesta împotriva acesteia. DRM este defect prin design și reprezintă o amenințare majoră pentru toți utilizatorii de computer și libertatea software-ului.

Credit de imagine: [defectivebydesign.org/drm-free/...)(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Informații despre sponsor

! [SponsorButton.png] (SponsorButton.png) <- Nu faceți clic pe acest buton, nu funcționează, este doar o imagine. Butonul real se află în partea de sus a paginii în colțul din dreapta (<- L ** R ** ->)

Puteți sponsoriza acest proiect dacă doriți, dar vă rugăm să specificați la ce doriți să donați. [Vedeți fondurile pe care le puteți dona aici] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Puteți vedea alte informații despre sponsori [aici] (https://github.com/seanpm2001/Sponsor-info/)

Încearcă! Butonul de sponsorizare se află chiar lângă butonul de ceas / de vizionare.

***

## Istoricul fișierelor



 * A început fișierul

> * S-a adăugat secțiunea de titlu

> * A fost adăugat indexul

> * S-a adăugat secțiunea despre

> * A fost adăugată secțiunea Wiki

> * A fost adăugată secțiunea istoric versiuni

> * A fost adăugată secțiunea de probleme.

> * A fost adăugată secțiunea de numere anterioare

> * A fost adăugată secțiunea de solicitări de extragere din trecut

> * A fost adăugată secțiunea de cereri de extragere active

> * A fost adăugată secțiunea de colaboratori

> * A fost adăugată secțiunea de contribuție

> * S-a adăugat secțiunea despre README

> * S-a adăugat secțiunea istoric versiuni README

> * A fost adăugată secțiunea de resurse

> * A fost adăugată o secțiune de stare software, cu un sticker și un mesaj DRM gratuit

> *A fost adăugată secțiunea de informații despre sponsori

> * Nu există alte modificări în versiunea 0.1

Versiunea 1 (vineri, 19 februarie 2021 la 17:20)

> Modificări:

> * A pornit fișierul

> * A fost adăugată secțiunea de descriere de bază

> * A fost adăugată secțiunea de descriere a depozitului

> * A fost adăugată lista articolelor, cu 14 intrări

>> * A fost adăugată o secțiune „articole conexe”

>> * S-a adăugat o secțiune „vezi și„

> * A fost adăugată secțiunea cu informații despre fișier

> * A fost adăugată secțiunea istoric fișiere

> * S-a adăugat subsolul

> * Nu există alte modificări în versiunea 1

Versiunea 2 (vineri, 19 februarie 2021 la 17:26)

> Modificări:

> * A fost adăugată secțiunea de stare a traducerii

> * S-a adăugat secțiunea Alte lucruri de verificat

> * A fost adăugată secțiunea de confidențialitate

> * A fost adăugat un index

> * A fost adăugată subsecțiunea de stare a software-ului

> * A fost adăugată secțiunea de campanii anti-Google

>> * S-a adăugat subsecțiunea defunctă

>> * S-a adăugat subsecțiunea în curs

> * A fost adăugată secțiunea surse

> * A fost adăugată secțiunea de linkuri de descărcare

> * Actualizat secțiunea cu informații despre fișier

> * Actualizat secțiunea istoric fișier

> * Nu există alte modificări în versiunea 2

Versiunea 3 (miercuri, 24 februarie 2021 la 19:56)

> Modificări:

> * Actualizarea indexului

> * A făcut referire la pictograma degoogle și la noua organizație GitHub

> * S-au adăugat linkuri către articole mai noi

> * A fost adăugată secțiunea de contracarare a altor argumente

>> * S-a adăugat subsecțiunea de comoditate

>> * A fost adăugată subsecțiunea De ce să te deranjezi chiar

>> * S-a adăugat cealaltă subsecțiune

> * Am actualizat unele date

> * Actualizat secțiunea cu informații despre fișier

> * Actualizat secțiunea istoric fișier

> * Nu există alte modificări în versiunea 3

Versiunea 4 (joi, 25 februarie 2021 la 21:31)

> Modificări:

> * S-au adăugat linkuri către 10 articole noi

> * Am adăugat o secțiune despre experiența mea degoogling

> * Actualizarea indexului

> * Actualizat secțiunea cu informații despre fișier

> * Actualizat secțiunea istoric fișier

> * Nu există alte modificări în versiunea 4

Versiunea 5 (vineri, 9 aprilie 2021 la 18:02)

_ În ultimul timp au lipsit actualizări ale mișcării anti-Google de la mine, lucrez la revenirea la aceasta după o pauză de peste o lună ._

> Modificări:

> * Actualizat secțiunea titlu

> * Actualizarea indexului

> * Actualizarea listei de limbi: linkuri fixe și adăugarea mai multor limbi acceptate

> * S-a actualizat secțiunea de stare a articolului, adăugând 4 linkuri furculiță

> * Actualizat secțiunea de stare a software-ului

> * S-a adăugat secțiunea Go is evil

> * A fost adăugată secțiunea Utilizare DRM

> * A fost adăugată secțiunea Concepții greșite frecvente

>> * Adăugat că Google nu este subsecțiunea Internet

> * S-a adăugat secțiunea Internet Explorer 6 și Chrome

>> * S-a adăugat subsecțiunea Problema cu Brave

> * A fost adăugată eliminarea confidențialității Faux

> * Adăugat că Open source nu poate fi subsecțiune parțială

> * S-a adăugat subsecțiunea Oxymoron

> * A fost adăugată secțiunea Performanță slabă

> * A fost adăugată secțiunea de gestionare a proiectelor incorecte

> * A fost adăugată secțiunea Oribilă sau fără moderare a serviciilor

> * A fost adăugată secțiunea Astroturfing

> * A fost adăugată secțiunea de practici comerciale ilegale și neetice

> * A fost adăugată subsecțiunea În Europa

>> * A fost adăugată subsecțiunea În America de Nord

>> * A fost adăugată subsecțiunea Controverse

> * A fost adăugată secțiunea Google este automatizată

> * A fost adăugată secțiunea Android

> * A fost adăugată secțiunea Acțiuni mici pentru ajutor

> * A fost adăugată secțiunea de necredibil

> * A fost adăugată secțiunea de informații despre sponsori

> * Actualizat subsolul

> * Actualizat secțiunea cu informații despre fișier

> * Actualizat secțiunea istoric fișier

> * Nu există alte modificări în versiunea 5

Versiunea 6 (duminică, 18 aprilie 2021 la 16:18)

> Modificări:

> * Actualizarea indexului

> * S-a adăugat o nouă descriere de ansamblu

> * Informații despre starea articolului actualizate

> * S-a adăugat un link către noul articol Google FLoC

> * S-a adăugat un link la articolul Wuest 3n Fuchs Degoogle și informații generale despre acesta

> * Actualizat secțiunea cu informații despre fișier

> * Actualizat secțiunea istoric fișier

> * Nu există alte modificări în versiunea 6

Versiunea 7 (În curând)

> Modificări:

> * În curând

> * Nu există alte modificări în versiunea 7

Versiunea 8 (În curând)

> Modificări:

> * În curând

> * Nu există alte modificări în versiunea 8

Versiunea 9 (În curând)

> Modificări:

> * În curând

> * Nu există alte modificări în versiunea 9

Versiunea 10 (În curând)

> Modificări:

> * În curând

> * Nu există alte modificări în versiunea 10

Versiunea 11 (În curând)

> Modificări:

> * În curând

> * Nu există alte modificări în versiunea 11

Versiunea 12 (În curând)

> Modificări:

> * În curând

> * Nu există alte modificări în versiunea 12

***

## Subsol

Ați ajuns la sfârșitul acestui fișier

([Înapoi sus) (# Sus) | [Înapoi la GitHub] (https://github.com))

### EOF

***
