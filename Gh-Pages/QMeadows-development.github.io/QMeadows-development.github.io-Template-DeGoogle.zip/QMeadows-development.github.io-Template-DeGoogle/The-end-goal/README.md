
***

# The end goal (DeGoogling your life)

![Degoogle_End_Goal.jpg failed to load. The image may not exist, may not be supported by your browser, may have been moved or corrupted, or the path is incorrect](/The-end-goal/Degoogle_End_Goal.jpg)

This is the end goal to DeGoogling your life. It is a challenge really worth going towards, and defining this as an end goal feels so much more rewarding.

This is an achievement to life!

***
