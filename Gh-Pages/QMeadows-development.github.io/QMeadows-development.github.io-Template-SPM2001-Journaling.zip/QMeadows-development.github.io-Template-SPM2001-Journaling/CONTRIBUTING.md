
***

# Contributing.md

Contributions currently aren't allowed here. This is a personal project for my journaling archive, and I don't need too much help other than suggestions. I have this under control.

***

Contributing file version: `1 (Saturday, October 24th 2020 at 5:27 pm)`

***
