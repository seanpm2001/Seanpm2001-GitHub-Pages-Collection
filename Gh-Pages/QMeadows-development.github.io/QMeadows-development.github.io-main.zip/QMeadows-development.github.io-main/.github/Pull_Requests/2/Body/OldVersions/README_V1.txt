Create the DeGoogle branch.
