
***

# SECURITY_INCIDENTS.md

## Security log for this project

### Template_GitHubPages_Default_V4

**01 - Saturday, July 17th 2021 :|:** a bad URL was added to the project README file but was fixed. I honestly thought that ddg.com was still the active shortened URL. I may have gotten it wrong, but Firefox immediately gave me a red flag. The link has been fixed, but it remains unaltered in archived old versions, and in 2 past commits.

No other security incidents so far.

***
