
***

# Changelog

## V1 of Template_GitHubPages

> Changes:

* To be added here

* No other changes in V1

## V2 of Template_GitHubPages

> Changes:

* To be added here

* No other changes in V2

## V3 of Template_GitHubPages

> Changes:

* To be added here

* No other changes in V3

## V4 of Template_GitHubPages_Default

> Changes:

* To be added here

* No other changes in V4

## V5 of Template_GitHubPages_Default

> Changes:

* Typo: `SNU Erotica` removed entirely

* Added better alt names than file.svg

* Commented out the first line of the By: section

* Fixed the index, and added the history section

* Added the changelog

* No other changes in V5

## V6 of Template_GitHubPages_Default

> Changes:

* Updated the `.editorconfig` file to version 2, adding better editor support for several languages and file types

* Added new August 2021 changes, files added: `.gitignore` `copying` `install` `credits` and `makefile.mk`

* Updated `README.md` file with new changes

* No other changes in V6

## V7 of Template_GitHubPages_Default

> Changes:

* Temporarily removed support for the `install` file due to a critical error (still being investigated) that caused GitHub pages to fail all checks

* Updated the changelog

* Updated the `README.md` file, adding support for Author files, updated the index, and adding [Swisscows](https://swisscows.com/) as a 4th search engine option

* No other changes in V7

***
