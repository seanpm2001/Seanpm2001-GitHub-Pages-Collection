
***

### Top

# TalkScript
An older idea I had for a programming language IDE that works entirely through voice, so people who are blind, or have no arms can program, or even people who just want to program by simply talking script.

***

# README Index

[00.0 - Title](#TalkScript)

[01.0 - README Index](#README-Index)

[02.0 - About](#About)

[03.0 - Project Wiki](#Project-Wiki)

[04.0 - Version history](#Version-history)

[05.0 - Contributers](#Contributers)

[06.0 - Contributing](#Contributing)

[07.0 - README info](#README-info)

[08.0 - Footer](#End-of-README-file)

***

# About

See above

***

## Project Wiki

[Click/tap here to view this projects Wiki](https://github.com/seanpm2001/TalkScript/Wiki/)

***

## Version history

Unavailable

[More versions coming soon](https://www.example.com/)

***

## Contributers

Currently, I am the only contributer, but if you follow ther CONTRIBUTING rules, you can contribute as well.

1. [seanpm2001](https://github.com/seanpm2001/) - 14 commits (As of Wednesday, July 8th 2020 at 3:42 pm)

2. No other contributers at the moment

***

## Contributing

Please abide by the contributing rules for this project. They are listed [here.](https://github.com/seanpm2001/TalkScript/blob/master/CONTRIBUTING.md)

***

## README info

File type: `Markdown (*.md)`

Line count (including blank lines): `84`

File version: `1 (Wednesday, July 8th 2020 at 3:42 pm)`

***

### End of README file

( [Back to top](#Top) | [Exit](https://github.com) )

***
