
***

# Acronym list

This is a list of acronyms used on this project.

> * `KA` - This acronym stands for: `Khan Academy`

> * `JS` - This acronym stands for: `JavaScript`

> * `PNG` - This acronym stands for: `Portable Network Graphics`

> * `SQL` - This acronym stands for: `Structured Query Language`

> * `HTML` - This acronym stands for: `HyperText Markup Language`

> * `CSS` - This acronym stands for: `Cascade Styling Sheets`

> * `JPG` - This acronym stands for: `Joint Photographic experts Group`

> * `MP4` - This acronym stands for: `MPEG Part 14`

> * `WP3` - This acronym stands for: `Windows Photo story 3 project`

> * `WLMP` - This acronym stands for: `Windows Live Movie maker Project`

> * `WMV` - This acronym stands for: `Windows Media Video`

> * `MD` - This acronym stands for: `MarkDown`

> * `INI` - This acronym stands for: `microsoft INItialization file`

> * `ODT` - This acronym stands for: `Open Document Text`

> * `TXT` - This acronym stands for: `plain TeXT`

> * `HTM` - This acronym stands for: `HyperText Markup language`

> * `ZIP` - This acronym stands for: `ZIP archive`

Those are all the acronyms used on this project. If I missed any, please point them out.

***

## File info

File version: `2 (Tuesday, July 28th 2020 at 5:05 pm)`

File format: `Markdown (*.md)`

Line count (including blank lines and compiler line): `57`

### End of file

***
