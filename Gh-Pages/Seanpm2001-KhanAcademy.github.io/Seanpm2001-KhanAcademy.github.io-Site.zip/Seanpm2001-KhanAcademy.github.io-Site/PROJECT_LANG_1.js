// Start of script
// This project is mostly written in JavaScript, so I chose JavaScript as the project language.
console.log ("This project is mostly written in JavaScript, so I chose JavaScript as the project language.");
/* File info
* File version: 1 (Thursday, December 31st 2020 at 6:31 pm)
* File type: JavaScript script file (*.js)
* Line count (including blank lines and compiler line): 10
*/
// End of script
