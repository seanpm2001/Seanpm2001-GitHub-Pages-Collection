***

# `README.md`

***

# Index

[Title](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/edit/master/README.md#README.md)

[Index (recursive)](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/edit/master/README.md#Index)

[Description](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/edit/master/README.md#KhanAcademyData_u-Seanwallawallaofficial)

[About](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/edit/master/README.md#About)

[Current issues](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/edit/master/README.md#Current_issues)

[Pending features](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/edit/master/README.md#Pending_features)

[Contributing](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/edit/master/README.md#Contributing)

[Wiki](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/edit/master/README.md#Wiki)

[Version history](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/edit/master/README.md#Version_history)

[Contributers](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/edit/master/README.md#Contributers)

[About README.md](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/edit/master/README.md#About_README.md)

[Footer](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/edit/master/README.md#You_have_reached_the_end_of_the_README_file)

***

## KhanAcademyData_u-Seanwallawallaofficial
All of my Khan Academy data from my main account and my school account. The school account no longer exists. Link to my profile: https://www.khanacademy.org/profile/seanwallawallaofficial/

***

## About

See above

***

## Current issues

These issues are currently needing to be fixed:

1. [#1 Root folder is missing](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/issues/1)

2. No other issues at the moment

***

## Pending features

These features are pending:

1. [KDE icon support](https://www.kde.org/)

2. [GNOME icon support](https://www.gnome.org/)

3. [MacOS icon support](https://www.apple.com)

4. [XFCE icon support](https://xfce.org/)

5. [Solaris icon support](https://www.oracle.com/solaris/solaris11/)

6. [CINNAMON icon support](https://cinnamon-spices.linuxmint.com/)

7. [Other DE icon support](https://en.wikipedia.org/wiki/Desktop_environment)

8. No other pending features at the moment

***

## Contributing

[Click here to learn how to contribute](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/blob/master/CONTRIBUTING.md)

***

## Wiki

[Click/tap here to view this projects Wiki](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/wiki)

***

## Version history

1. [Version 1.0](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/releases/tag/V1.0) - Released June 9th 2020 at 6:31 pm

2. [Version 1.01](https://github.com/seanpm2001/KhanAcademyData_u-Seanwallawallaofficial/releases/tag/V1.01) - Released June 10th 2020 at 11:00 pm

3. [Version 1.02](https://www.example.com) - Coming soon

***

## Contributers

Currently, I am the only contributer.

> * 1. [seanpm2001](https://github.com/seanpm2001/) - 201 commits (As of Wednesday, June 10th 2020 at 11:02 pm)

> * 2. No other contributers at the moment

> * 3. Contributer slot 3

> * 4. Contributer slot 4

> * 5. Contributer slot 5

> * 6. Contributer slot 6

> * 7. Contributer slot 7

> * 8. Contributer slot 8

> * 9. Contributer slot 9

> * 10. Contributer slot 10

***

## About README.md

File type: `Markdown (*.md)`

File version: `3 (Wednesday, June 10th 2020 at 11:02 pm)`

Line count: `0,139`

***

### You have reached the end of the README file

***

