***

# Cam Cam Plus (CC +)

! [{Projektiikoon} Selle pildi laadimine nurjus. Selle põhjuseks võib olla faili kättesaamatus või üldine viga. Võimaliku üldise tõrke kõrvaldamiseks laadige leht uuesti.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Kõrval:

## [Seanpm2001] (https://github.com/seanpm2001) ja teised kaastöötajad

### Üles

# "README.md"

***

## Lugege seda artiklit teises keeles

** Praegune keel on: ** "inglise (USA)" _ (tõlkimine võib osutuda vajalikuks parandada inglise keelt, asendades õige keele) _

_🌐 keelte loend_

** Sorteeritud: ** "A-Z"

[Sorteerimisvalikud pole saadaval] (https://github.com/Degoogle-your-Life)

([af afrikaans] (/. github / README_AF.md) afrikaani | [sq Shqiptare] (/. github / README_SQ.md) albaania | [am አማርኛ] (/. github / README_AM.md) amhari keel | [ar عربى] (/.github/README_AR.md) araabia | [hy հայերեն] (/. github / README_HY.md) armeenia | [az Azərbaycan dili] (/. github / README_AZ.md) aserbaidžaani | [eu Euskara] (/. github /README_EU.md) baski keel | [be Беларуская] (/. Github / README_BE.md) valgevene keel [[bn বাংলা] (/. Github / README_BN.md) bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) bulgaaria | [ca Català] (/. Github / README_CA.md) katalaani | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichich ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) hiina (lihtsustatud) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) hiina (traditsiooniline) | [co Corsu] (/. Github / README_CO.md) Korsika | [hr Hrvatski] (/. Github / README_HR.md) horvaadi | [cs čeština] (/. Github / README_CS .md) tšehhi | [da dansk] (README_DA.md) taani | [nl Nederlands] (/. github / README_ NL.md) hollandi | [** et et eesti keel **] (/. github / README.md) inglise keel [EO esperanto] (/. Github / README_EO.md) esperanto | [et Eestlane] (/. github / README_ET.md) eesti keel [tl Pilipino] (/. github / README_TL.md) filipiinlane | [fi Suomalainen] (/. github / README_FI.md) soome keel [fr français] (/. github / README_FR.md) prantsuse | [fy Frysk] (/. github / README_FY.md) friisi | [gl Galego] (/. github / README_GL.md) galeegi keel [ka ქართველი] (/. github / README_KA) gruusia | [de Deutsch] (/. github / README_DE.md) saksa keel [el Ελληνικά] (/. github / README_EL.md) kreeka | [gu ગુજરાતી] (/. github / README_GU.md) gudžarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haiti kreool | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) havai | [ta עִברִית] (/. github / README_HE.md) heebrea | [tere हिन्दी] (/. github / README_HI.md) hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) ungari keel [on Íslenska] (/. github / README_IS.md) islandi keel | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) islandi | [ga Gaeilge] (/. github / README_GA.md) iiri keel [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) jaapani keel [jw Wong jawa] (/. github / README_JW.md) jaava keel | [kn ಕನ್ನಡ] (/. github / README_KN.md) kannada | [kk Қазақ] (/. github / README_KK.md) kasahhi keel | [km ខ្មែរ] (/. github / README_KM.md) khmeeri | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-lõuna 韓國 語] (/. github / README_KO_SOUTH.md) Korea (lõuna) | [ko-põhja 문화어] (README_KO_NORTH.md) korea (põhi) (EI VEEL TÕLKETUD) | [ku Kurdî] (/. github / README_KU.md) kurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kõrgõzstani | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) ladina keel [lt Lietuvis] (/. github / README_LT.md) leedu | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksemburgi keel | [mk Македонски] (/. github / README_MK.md) makedoonia | [mg Madagaskari] (/. github / README_MG.md) Madagaskari | [ms Bahasa Melayu] (/. github / README_MS.md) malai | [ml മലയാളം] (/. github / README_ML.md) malajalami | [mt Malti] (/. github / README_MT.md) malta keel [mi maoori] (/. github / README_MI.md) maoori | [hr मराठी] (/. github / README_MR.md) marathi | [mn Монгол] (/. github / README_MN.md) mongoli keel | [minu မြန်မာ] (/. github / README_MY.md) Myanmar (Birma) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) norra keel [või ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) pastu | [fa فارسی] (/. github / README_FA.md) | pärsia [pl polski] (/. github / README_PL.md) poola keel | [pt português] (/. github / README_PT.md) portugali keel [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) pandžabi | Q-tähega algavaid keeli pole [ro Română] (/. github / README_RO.md) rumeenia keel [ru русский] (/. github / README_RU.md) vene keel [sm Faasamoa] (/. github / README_SM.md) Samoa keel | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) šoti gaeli keel | [sr Српски] (/. github / README_SR.md) serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) slovaki | [sl Slovenščina] (/. github / README_SL.md) sloveeni | [nii Soomaali] (/. github / README_SO.md) somaali | [[es en español] (/. github / README_ES.md) hispaania keel [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) suahiili | [sv Svenska] (/. github / README_SV.md) rootsi | [tg Тоҷикӣ] (/. github / README_TG.md) tadžiki keel | [ta தமிழ்] (/. github / README_TA.md) tamili | [tt Татар] (/. github / README_TT.md) tatari | [te తెలుగు] (/. github / README_TE.md) telugu | [th ไทย] (/. github / README_TH.md) tai | [tr Türk] (/. github / README_TR.md) türgi keel [tk Türkmenler] (/. github / README_TK.md) turkmeeni | [uk Український] (/. github / README_UK.md) ukrainlane | [ur اردو] (/. github / README_UR.md) urdu | [ug ئۇيغۇر] (/. github / README_UG.md) uiguuri | [uz O'zbek] (/. github / README_UZ.md) usbeki keel | [vi Tiếng Việt] (/. github / README_VI.md) vietnami keel [cy Cymraeg] (/. github / README_CY.md) kõmri | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jidiši | [yo joruba] (/. github / README_YO.md) joruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Saadaval 110 keeles (108, kui mitte arvestada inglise ja põhja-korea keelt, kuna põhja-korea keelt pole veel tõlgitud [Loe selle kohta siit] (/ OldVersions / Korea (North ) /README.md))

Tõlked muudesse keeltesse kui inglise keelde tõlgitakse masinaga ja pole veel täpsed. 5. veebruari 2021. aasta seisuga pole veel ühtegi viga parandatud. Palun teatage tõlkevigadest [siin] (https://github.com/seanpm2001/CamCamPlus/issues/). Varundage kindlasti oma parandus allikatega ja juhendage mind, nagu ma ei oska 'ei oska muid keeli peale inglise keele (kavatsen lõpuks tõlgi hankida), palun tsiteerige oma aruandes [vikisõnaraamat] (https://et.wiktionary.org) ja muid allikaid. Kui seda ei tehta, lükatakse parandus tagasi.

Märkus. GitHubi märgistuse tõlgendamise piirangute tõttu (ja peaaegu kõigi muude veebipõhiste märgistuste tõlgenduste korral) suunab nende linkide klõpsamine teid eraldi lehele eraldi faili, mis pole minu GitHubi profiilileht. Teid suunatakse [seanpm2001 / seanpm2001 hoidlasse] (https://github.com/seanpm2001/seanpm2001), kus hostitakse README-d.

Tõlked tehakse Google'i tõlkega, kuna muudes tõlketeenustes, näiteks DeepL ja Bing Translate, on mul vajalike keelte tugi piiratud või puudub. Töötan alternatiivi leidmise nimel. Millegipärast on vormindus (lingid, eraldajad, painutamine, kursiiv jne) segatud erinevates tõlgetes. Selle parandamine on tüütu ja ma ei tea, kuidas neid probleeme lahendada keeltes, kus pole ladina tähemärki ja paremalt vasakule (nagu araabia) kasutatavates keeltes on nende probleemide lahendamiseks vaja täiendavat abi

Hooldusprobleemide tõttu on paljud tõlked ajale jalgu jäänud ja kasutavad selle artikli „README“ vananenud versiooni. Vaja on tõlki. Alates 22. aprillist 2021 võtab mul ka aega, et kõik uued lingid tööle saada.

***

# Indeks

[00.0 - ülemine] (# ülemine)

> [00.1 - pealkiri] (# CamCamPlus)

> [00.2 - lugege seda artiklit teises keeles] (# Loe seda artiklit-erinevas keeles)

> [00.3 - register] (# register)

[01.0 - kirjeldus] (# CamCamPlus)

[02.0 - Teave] (# About)

[03.0 - Wiki] (# Wiki)

[04.0 - versioonide ajalugu] (# versioonide ajalugu)

[05.0 - Tarkvara olek] (# Tarkvara olek)

[06.0 - sponsori teave] (# sponsori teave)

[07.0 - kaastöötajad] (# kaastöötajat)

[08.0 - väljaanded] (# numbrit)

> [08.1 - jooksvad väljaanded] (# jooksvad väljaanded)

> [08.2 - Varasemad väljaanded] (# Varasemad väljaanded)

> [08.3 - Varasemad tõmbenõuded] (# Varasemad tõmbenõuded)

> [08.4 - aktiivsed tõmbetaotlused] (# aktiivsed-tõmbenõuded)

[09.0 - ressursid] (# ressurssi)

[10.0 - kaastöö] (# kaastöö)

[11.0 - Teave README kohta] (# About-README)

[12.0 - README versiooni ajalugu] (# README-versiooni ajalugu)

[13.0 - jalus] (# olete jõudnud faili README lõppu)

> [13.1 - faili lõpp] (# EOF)

***

# CamCamPlus
CamCamPlus on tippklassi tasuta ja avatud lähtekoodiga kaamera, mis võimaldab pildistada ja videoid mitmes vormingus ning paljude eraldusvõimega.

***

## Umbes

Vt eespool. See projekt räägib avatud lähtekoodiga võimsast kaamerast, mis annab palju võimalusi ja purustab tõkkeid, mis teistel tavalistel kaamerarakendustel on (näiteks 30-minutiline salvestuspiirang)

***

## Wiki

[Projektide Wiki vaatamiseks klõpsake / koputage siin] (https://github.com/seanpm2001/CamCamPlus/wiki)

Kui projekt on hargnenud, eemaldati Wiki tõenäoliselt. Õnneks lisan ka manustatud versiooni. Saate seda vaadata [siin] (/ External / ProjectWiki /).

***

## Sponsorite teave

! [SponsorButton.png] (SponsorButton.png)

Soovi korral saate seda projekti sponsoreerida, kuid palun täpsustage, millele soovite annetada. [Vaadake vahendeid, millele saate annetada, siit] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Sponsorite muud teavet saate vaadata [siit] (https://github.com/seanpm2001/Sponsor-info/)

Proovi! Sponsori nupp asub otse vaatamis- / vaatamisnupu kõrval.

***

## Versioonide ajalugu

** Versiooniajalugu pole praegu saadaval **

** Ühtegi muud versiooni pole loetletud **

***

## Tarkvara olek

Kõik minu teosed on teatud piiranguteta. DRM-i (** D ** igital ** R ** ehted ** M ** anagement) ei esine üheski minu teoses.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Seda kleebist toetab Free Tarkvara Sihtasutus. Ma ei kavatse kunagi DRM-i oma töödesse kaasata.

Kasutan rohkem tuntud digitaalse õiguste halduse asemel lühendit "Digitaalsete piirangute haldamine", kuna levinud viis selle lahendamiseks on vale, DRM-iga pole õigusi. Õigekiri "Digitaalsete piirangute haldamine" on täpsem ja seda toetavad [Richard M. Stallman (RMS)] (https://et.wikipedia.org/wiki/Richard_Stallman) ja [Vaba tarkvara sihtasutus (FSF)] ( https://et.wikipedia.org/wiki/Free_Software_Foundation)

Seda jaotist kasutatakse DRM-i probleemide teadvustamiseks ja ka selle vastu protestimiseks. DRM on disainilt defektne ja ohustab oluliselt kõiki arvutikasutajaid ning tarkvaravabadust.

Pildikrediit: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Kaastöötajad

Praegu olen ainus panustaja. Kaastöö on lubatud, kui järgite faili [KAASETÖÖD.md] (KAASNÄITAMINE.md) reegleid.

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 kohustust (neljapäeval, 22. aprillil 2021 kell 18:30)

> * 2. Teisi kaasautoreid pole.

***

## probleemid

### Praegused probleemid

* Praegu pole ühtegi

* Muud jooksvad probleemid puuduvad

Kui hoidla on hargnenud, on probleemid tõenäoliselt eemaldatud. Õnneks hoian teatud piltide arhiivi [siin] (/. Github / Issues /)

[Lugege väljaande arhiivimise privaatsuseeskirju siit] (/. Github / Issues / README.md)

** TL; DR **

Arhiivin oma väljaanded. Teie probleemi ei arhiveerita enne, kui taotlete selle arhiivimist.

### Varasemad probleemid

* Praegu pole ühtegi

* Muid mineviku probleeme pole

Kui hoidla on hargnenud, on probleemid tõenäoliselt eemaldatud. Õnneks hoian teatud piltide arhiivi [siin] (/. Github / Issues /)

[Lugege väljaande arhiivimise privaatsuseeskirju siit] (/. Github / Issues / README.md)

** TL; DR **

Arhiivin oma väljaanded. Teie probleemi ei arhiveerita enne, kui taotlete selle arhiivimist.

### Varasemad tõmbetaotlused

* Praegu pole ühtegi

* Muid varasemaid tõmbetaotlusi pole

Kui hoidla on hargnenud, on probleemid tõenäoliselt eemaldatud. Õnneks hoian teatud piltide arhiivi [siin] (/. Github / Issues /)

[Lugege väljaande arhiivimise privaatsuseeskirju siit] (/. Github / Issues / README.md)

** TL; DR **

Arhiivin oma väljaanded. Teie probleemi ei arhiveerita enne, kui taotlete selle arhiivimist.

### Aktiivsed tõmbetaotlused

* Praegu pole ühtegi

* Muid aktiivseid tõmbetaotlusi pole

Kui hoidla on hargnenud, on probleemid tõenäoliselt eemaldatud. Õnneks hoian teatud piltide arhiivi [siin] (/. Github / Issues /)

[Lugege väljaande arhiivimise privaatsuseeskirju siit] (/. Github / Issues / README.md)

** TL; DR **

Arhiivin oma väljaanded. Teie probleemi ei arhiveerita enne, kui taotlete selle arhiivimist.

***

## Ressursid

Siin on mõned muud selle projekti ressursid:

[Projekti keelefail] (PROJECT_LANG.cpp)

[Selle projekti uurimistööde raamatukogu] (/ Viited /)

[Selle projekti spetsiaalne videomoodul (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[Liituge GitHubi aruteluga] (https://github.com/seanpm2001/CamCamPlus/discussions)

Praegu pole muid ressursse.

***

## Kaastöö

Selles projektis on kaastöö tegemine lubatud, kui järgite faili `CONTRIBUTING.md` reegleid.

[Klõpsake / puudutage siin, et vaadata selle projekti kaasreegleid] (CONTRIBUTING.md)

***

## Teave README kohta

Failitüüp: "Markdown (* .md)"

Failiversioon: "1 (neljapäeval, 22. aprillil 2021 kell 18:30)"

Ridade arv: "0,306"

***

## README versiooni ajalugu

Versioon 1 (neljapäeval, 22. aprillil 2021 kell 18:30)

> Muudatused:

> * Alustas faili

> * Lisatud pealkirjaosa

> * Lisas indeksi

> * Lisatud jaotis umbes

> * Lisas Wiki jaotise

> * Lisatud versiooniajaloo jaotis

> * Lisas jaotise Probleemid.

> * Lisas eelmiste väljaannete jaotise

> * Lisas jaotise eelmised tõmbetaotlused

> * Lisati aktiivsete tõmbetaotluste jaotis

> * Lisatud kaastöötajate jaotis

> * Lisatud kaastöö jaotis

> * Lisas jaotise umbes README

> * Lisatud jaotis README versiooniajalugu

> * Lisatud ressursside jaotis

> * Lisatud tarkvara oleku jaotis koos DRM-i tasuta kleebise ja sõnumiga

> * Lisatud sponsoriteabe jaotis

> * Versioonis 1 muid muudatusi pole

Versioon 2 (varsti saadaval)

> Muudatused:

> * Varsti

> * Versioonis 2 muid muudatusi pole

***

### Olete jõudnud faili README lõppu

[Tagasi üles] (# ülaosa) [Exit] (https://github.com)

### EOF

***
