***

# Cam Cam Plus (CC +)

! [{Project icon} Deze afbeelding kan niet worden geladen. Het kan komen doordat het bestand niet wordt bereikt of een algemene fout. Laad de pagina opnieuw om een ​​mogelijke algemene fout te verhelpen.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Door:

## [Seanpm2001] (https://github.com/seanpm2001) en andere bijdragers

### Boven

# `README.md`

***

## Lees dit artikel in een andere taal

** Huidige taal is: ** `Engels (VS)` _ (vertalingen moeten mogelijk worden gecorrigeerd om ervoor te zorgen dat Engels de juiste taal vervangt) _

_🌐 Lijst met talen_

** Gesorteerd op: ** `A-Z`

[Sorteeropties niet beschikbaar] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanees | [ben አማርኛ] (/. github / README_AM.md) Amhaars | [ar عربى] (/.github/README_AR.md) Arabisch | [hy հայերեն] (/. github / README_HY.md) Armeens | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbeidzjaans | [eu Euskara] (/. github /README_EU.md) Baskisch | [be Беларуская] (/. Github / README_BE.md) Wit-Russisch | [bn বাংলা] (/. Github / README_BN.md) Bengaals | [bs Bosanski] (/. Github / README_BS.md) Bosnisch | [bg български] (/. Github / README_BG.md) Bulgaars | [ca Català] (/. Github / README_CA.md) Catalaans | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chinees (vereenvoudigd) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chinees (traditioneel) | [co Corsu] (/. Github / README_CO.md) Corsicaans | [hr Hrvatski] (/. Github / README_HR.md) Kroatisch | [cs čeština] (/. Github / README_CS .md) Tsjechisch | [da dansk] (README_DA.md) Deens | [nl Nederlands] (/. github / README_ NL.md) Nederlands | [** en-us Engels **] (/. github / README.md) Engels | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Ests | [tl Pilipino] (/. github / README_TL.md) Filipijns | [fi Suomalainen] (/. github / README_FI.md) Fins | [fr français] (/. github / README_FR.md) Frans | [fy Frysk] (/. github / README_FY.md) Fries | [gl Galego] (/. github / README_GL.md) Galicisch | [ka ქართველი] (/. github / README_KA) Georgisch | [de Deutsch] (/. github / README_DE.md) Duits | [el Ελληνικά] (/. github / README_EL.md) Grieks | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haïtiaans Creools | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiiaans | [he עִברִית] (/. github / README_HE.md) Hebreeuws | [hoi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hongaars | [is Íslenska] (/. github / README_IS.md) IJslands | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) IJslands | [ga Gaeilge] (/. github / README_GA.md) Iers | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japans | [jw Wong jawa] (/. github / README_JW.md) Javaans | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazachs | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Koreaans (Zuid) | [ko-north 문화어] (README_KO_NORTH.md) Koreaans (Noord) (NOG NIET VERTAALD) | [ku Kurdî] (/. github / README_KU.md) Koerdisch (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgizisch | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latijn | [lt Lietuvis] (/. github / README_LT.md) Litouws | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgs | [mk Македонски] (/. github / README_MK.md) Macedonisch | [mg Malagasy] (/. github / README_MG.md) Malagasi | [ms Bahasa Melayu] (/. github / README_MS.md) Maleis | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltees | [mi Maori] (/. github / README_MI.md) Maori | [dhr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongools | [mijn မြန်မာ] (/. github / README_MY.md) Myanmar (Birmaans) | [ne नेपाली] (/. github / README_NE.md) Nepalees | [no norsk] (/. github / README_NO.md) Noors | [of ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pasjtoe | [fa فارسی] (/. github / README_FA.md) | Perzisch [pl polski] (/. github / README_PL.md) Pools | [pt português] (/. github / README_PT.md) Portugees | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Geen talen beschikbaar die beginnen met de letter Q | [ro Română] (/. github / README_RO.md) Roemeens | [ru русский] (/. github / README_RU.md) Russisch | [sm Faasamoa] (/. github / README_SM.md) Samoaans | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Schots-Gaelisch | [sr Српски] (/. github / README_SR.md) Servisch | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slowaaks | [sl Slovenščina] (/. github / README_SL.md) Sloveens | [dus Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spaans | [su Sundanis] (/. github / README_SU.md) Zondanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Zweeds | [tg Тоҷикӣ] (/. github / README_TG.md) Tadzjieks | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tataars | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thais | [tr Türk] (/. github / README_TR.md) Turks | [tk Türkmenler] (/. github / README_TK.md) Turkmeens | [uk Український] (/. github / README_UK.md) Oekraïens | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Oeigoers | [uz O'zbek] (/. github / README_UZ.md) Oezbeeks | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamees | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Jiddisch | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Beschikbaar in 110 talen (108 als Engels en Noord-Koreaans niet meegeteld worden, aangezien Noord-Koreaans nog niet vertaald is [Lees er hier meer over] (/ OldVersions / Korean (North ) /README.md))

Vertalingen in andere talen dan het Engels zijn automatisch vertaald en zijn nog niet nauwkeurig. Vanaf 5 februari 2021 zijn er nog geen fouten verholpen. Rapporteer vertaalfouten [hier] (https://github.com/seanpm2001/CamCamPlus/issues/). Maak een back-up van uw correctie met bronnen en begeleid mij, zoals ik niet doe Ik ken geen andere talen dan Engels (ik ben van plan om uiteindelijk een vertaler te krijgen), vermeld [wiktionary] (https://en.wiktionary.org) en andere bronnen in je rapport. Als u dit niet doet, wordt de publicatie van de correctie afgewezen.

Opmerking: vanwege beperkingen met GitHub's interpretatie van markdown (en vrijwel elke andere webgebaseerde interpretatie van markdown), zal het klikken op deze links je doorverwijzen naar een apart bestand op een aparte pagina die niet mijn GitHub-profielpagina is. U wordt doorgestuurd naar de [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), waar de README wordt gehost.

Vertalingen worden gedaan met Google Translate vanwege beperkte of geen ondersteuning voor de talen die ik nodig heb in andere vertaaldiensten zoals DeepL en Bing Translate. Ik ben bezig met het vinden van een alternatief. Om de een of andere reden is de opmaak (links, scheidingslijnen, vetgedrukt, cursief, enz.) In verschillende vertalingen verknoeid. Het is vervelend om op te lossen en ik weet niet hoe ik deze problemen moet oplossen in talen met niet-Latijnse tekens, en talen van rechts naar links (zoals Arabisch) extra hulp is nodig bij het oplossen van deze problemen

Vanwege onderhoudsproblemen zijn veel vertalingen verouderd en gebruiken ze een verouderde versie van dit "README" -artikelbestand. Er is een vertaler nodig. Ook zal het vanaf 22 april 2021 even duren voordat alle nieuwe links werken.

***

# Inhoudsopgave

[00.0 - Top] (# Top)

> [00.1 - Titel] (# CamCamPlus)

> [00.2 - Lees dit artikel in een andere taal] (# Lees dit artikel in een andere taal)

> [00.3 - Index] (# Index)

[01.0 - Beschrijving] (# CamCamPlus)

[02.0 - Over] (# Over)

[03.0 - Wiki] (# Wiki)

[04.0 - Versiegeschiedenis] (# Versiegeschiedenis)

[05.0 - Softwarestatus] (# Softwarestatus)

[06.0 - Sponsor info] (# Sponsor-info)

[07.0 - bijdragers] (# bijdragers)

[08.0 - problemen] (# problemen)

> [08.1 - Huidige problemen] (# Huidige problemen)

> [08.2 - Afleveringen uit het verleden] (# Afleveringen uit het verleden)

> [08.3 - Eerdere pull-verzoeken] (# Past-pull-verzoeken)

> [08.4 - Actieve pull-aanvragen] (# Active-pull-aanvragen)

[09.0 - Bronnen] (# Bronnen)

[10.0 - Bijdragen] (# Bijdragen)

[11.0 - Over README] (# Over-README)

[12.0 - README Versiegeschiedenis] (# README-versiegeschiedenis)

[13.0 - Footer] (# U-hebt-het-einde-van-het-LEESMIJ-bestand-bereikt)

> [13.1 - Einde van bestand] (# EOF)

***

# CamCamPlus
CamCamPlus is een hoogwaardige gratis en open-source camera die foto's en video's in vele formaten en resoluties kan maken.

***

## Over

Zie hierboven. Dit project gaat over een krachtige open source camera die veel opties biedt en barrières wegneemt die andere veelgebruikte camera-apps hebben (zoals de opnamelimiet van 30 minuten)

***

## Wiki

[Klik / tik hier om de Wiki van dit project te bekijken] (https://github.com/seanpm2001/CamCamPlus/wiki)

Als het project geforked is, is de Wiki waarschijnlijk verwijderd. Gelukkig voeg ik een embedded versie toe. Je kunt het [hier] (/ External / ProjectWiki /) bekijken.

***

## Sponsor info

! [SponsorButton.png] (SponsorButton.png)

U kunt dit project sponsoren als u dat wilt, maar geef aan waaraan u wilt doneren. [Bekijk hier het geld dat u kunt doneren] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

U kunt andere sponsorinformatie [hier] bekijken (https://github.com/seanpm2001/Sponsor-info/)

Probeer het! De sponsorknop bevindt zich direct naast de watch / unwatch-knop.

***

## Versiegeschiedenis

** Versiegeschiedenis momenteel niet beschikbaar **

** Geen andere versies vermeld **

***

## Softwarestatus

Al mijn werken zijn gratis, sommige beperkingen. DRM (** D ** igital ** R ** beperkingen ** M ** anagement) is in geen van mijn werken aanwezig.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Deze sticker wordt ondersteund door de Free Software Foundation. Ik ben nooit van plan DRM in mijn werken op te nemen.

Ik gebruik de afkorting "Digital Restrictions Management" in plaats van het meer bekende "Digital Rights Management", aangezien de gebruikelijke manier om het aan te pakken onjuist is, er zijn geen rechten bij DRM. De spelling "Digital Restrictions Management" is nauwkeuriger en wordt ondersteund door [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) en de [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Dit gedeelte wordt gebruikt om mensen bewust te maken van de problemen met DRM, en ook om ertegen te protesteren. DRM is defect door ontwerp en vormt een grote bedreiging voor alle computergebruikers en softwarevrijheid.

Afbeeldingskrediet: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Bijdragers

Momenteel ben ik de enige donateur. Bijdragen is toegestaan, zolang je de regels van het bestand [CONTRIBUTING.md] (CONTRIBUTING.md) volgt.

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 commits (vanaf donderdag 22 april 2021 om 18.30 uur)

> * 2. Geen andere bijdragers.

***

## problemen

### Huidige problemen

* Momenteel geen

* Geen andere actuele problemen

Als de repository is geforked, zijn de problemen waarschijnlijk verwijderd. Gelukkig bewaar ik een archief van bepaalde afbeeldingen [hier] (/. Github / Issues /)

[Lees hier het privacybeleid over het archiveren van problemen] (/. Github / Issues / README.md)

** TL; DR **

Ik archiveer mijn eigen problemen. Uw probleem wordt niet gearchiveerd, tenzij u een verzoek indient om het te archiveren.

### Eerdere problemen

* Momenteel geen

* Geen andere problemen uit het verleden

Als de repository is geforked, zijn de problemen waarschijnlijk verwijderd. Gelukkig bewaar ik een archief van bepaalde afbeeldingen [hier] (/. Github / Issues /)

[Lees hier het privacybeleid over het archiveren van problemen] (/. Github / Issues / README.md)

** TL; DR **

Ik archiveer mijn eigen problemen. Uw probleem wordt niet gearchiveerd, tenzij u een verzoek indient om het te archiveren.

### Eerdere pull-verzoeken

* Momenteel geen

* Geen andere eerdere pull-verzoeken

Als de repository is geforked, zijn de problemen waarschijnlijk verwijderd. Gelukkig bewaar ik een archief van bepaalde afbeeldingen [hier] (/. Github / Issues /)

[Lees hier het privacybeleid over het archiveren van problemen] (/. Github / Issues / README.md)

** TL; DR **

Ik archiveer mijn eigen problemen. Uw probleem wordt niet gearchiveerd, tenzij u een verzoek indient om het te archiveren.

### Actieve pull-verzoeken

* Momenteel geen

* Geen andere actieve pull-verzoeken

Als de repository is geforked, zijn de problemen waarschijnlijk verwijderd. Gelukkig bewaar ik een archief van bepaalde afbeeldingen [hier] (/. Github / Issues /)

[Lees hier het privacybeleid over het archiveren van problemen] (/. Github / Issues / README.md)

** TL; DR **

Ik archiveer mijn eigen problemen. Uw probleem wordt niet gearchiveerd, tenzij u een verzoek indient om het te archiveren.

***

## Bronnen

Hier zijn enkele andere bronnen voor dit project:

[Projecttaalbestand] (PROJECT_LANG.cpp)

[Onderzoeksreferentiebibliotheek voor dit project] (/ Referenties /)

[De speciale videomodule voor dit project (SVG-video)] (https://github.com/seanpm2001/SVG_Video/)

[Doe mee aan de discussie op GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

Geen andere middelen op dit moment.

***

## Bijdragende

Bijdragen aan dit project is toegestaan, zolang je de regels van het bestand `CONTRIBUTING.md` volgt.

[Klik / tik hier om de bijdragende regels voor dit project te bekijken] (CONTRIBUTING.md)

***

## Over README

Bestandstype: `Markdown (* .md)`

Bestandsversie: `1 (donderdag 22 april 2021 om 18.30 uur)`

Aantal lijnen: `0,306`

***

## README versiegeschiedenis

Versie 1 (donderdag 22 april 2021 om 18.30 uur)

> Veranderingen:

> * Startte het bestand

> * De titelsectie toegevoegd

> * Toegevoegd de index

> * De over sectie toegevoegd

> * De Wiki-sectie toegevoegd

> * De sectie met versiegeschiedenis toegevoegd

> * De sectie met problemen toegevoegd.

> * De sectie over eerdere problemen toegevoegd

> * De sectie over eerdere pull-verzoeken toegevoegd

> * De sectie met actieve trekverzoeken toegevoegd

> * De bijdragerssectie toegevoegd

> * De bijdragende sectie toegevoegd

> * De over README sectie toegevoegd

> * Toegevoegd de README versiegeschiedenis sectie

> * De bronnensectie toegevoegd

> * Een softwarestatussectie toegevoegd, met een DRM-vrije sticker en bericht

> * De sponsor info sectie toegevoegd

> * Geen andere wijzigingen in versie 1

Versie 2 (binnenkort beschikbaar)

> Veranderingen:

> * Binnenkort beschikbaar

> * Geen andere wijzigingen in versie 2

***

### U heeft het einde van het README-bestand bereikt

[Terug naar boven] (# Boven) [Afsluiten] (https://github.com)

### EOF

***
