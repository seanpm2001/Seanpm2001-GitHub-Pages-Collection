***

# Cam Cam Plus (CC +)

! [{Projekt ikon} Ezt a képet nem sikerült betölteni. Ennek oka lehet a fájl nem elérése, vagy általános hiba. Töltse fel újra az oldalt egy esetleges általános hiba kijavításához.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Írta:

## [Seanpm2001] (https://github.com/seanpm2001) és más közreműködők

### Felső

# "README.md"

***

## Olvassa el ezt a cikket egy másik nyelven

** A jelenlegi nyelv: ** "angol (amerikai)" _ (a fordításokat javítani kell, hogy javítsák az angolt, a megfelelő nyelv helyett)

_🌐 Nyelvek listája_

** Rendezés: ** `A-Z`

[A rendezési lehetőségek nem érhetők el] (https://github.com/Degoogle-your-Life)

([af afrikaans] (/. github / README_AF.md) afrikaans | [sq Shqiptare] (/. github / README_SQ.md) albán | [am አማርኛ] (/. github / README_AM.md) amhara | [ar عربى] (/.github/README_AR.md) arab | [hy հայերեն] (/. github / README_HY.md) örmény | [az Azərbaycan dili] (/. github / README_AZ.md) azerbajdzsáni | [eu Euskara] (/. github /README_EU.md) baszk | [be Беларуская] (/. Github / README_BE.md) belorusz | [bn বাংলা] (/. Github / README_BN.md) bengáli | [bs Bosanski] (/. Github / README_BS.md) Bosnyák | [bg български] (/. Github / README_BG.md) bolgár | [ca Català] (/. Github / README_CA.md) katalán | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichew ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) kínai (egyszerűsített) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) kínai (hagyományos) | [co Corsu] (/. Github / README_CO.md) korzikai | [hr Hrvatski] (/. Github / README_HR.md) horvát | [cs čeština] (/. Github / README_CS .md) cseh | [da dansk] (README_DA.md) dán | [nl Nederlands] (/. github / README_ NL.md) holland | [** hu-magyar angol **] (/. github / README.md) angol | [EO eszperantó] (/. Github / README_EO.md) eszperantó [et Eestlane] (/. github / README_ET.md) észt | [tl Pilipino] (/. github / README_TL.md) filippínó | [fi Suomalainen] (/. github / README_FI.md) finn | [fr français] (/. github / README_FR.md) francia | [fy Frysk] (/. github / README_FY.md) fríz | [gl Galego] (/. github / README_GL.md) galíciai | [ka ქართველი] (/. github / README_KA) grúz | [de Deutsch] (/. github / README_DE.md) német | [el Ελληνικά] (/. github / README_EL.md) görög | [gu ગુજરાતી] (/. github / README_GU.md) gudzsaráti | [ht Kreyòl ayisyen] (/. github / README_HT.md) haiti kreol | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) hawaii | [he עִברִית] (/. github / README_HE.md) héber | [szia हिन्दी] (/. github / README_HI.md) hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) magyar | [is Íslenska] (/. github / README_IS.md) izlandi | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) izlandi [ga Gaeilge] (/. github / README_GA.md) ír | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) japán | [jw Wong jawa] (/. github / README_JW.md) jávai | [kn ಕನ್ನಡ] (/. github / README_KN.md) kannada | [kk Қазақ] (/. github / README_KK.md) kazah | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) koreai (dél) | [ko-észak 문화어] (README_KO_NORTH.md) koreai (északi) (NEM FORDÍTOTT) | [ku Kurdî] (/. github / README_KU.md) kurd (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) kirgiz | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) latin | [lt Lietuvis] (/. github / README_LT.md) litván | [lb Lëtzebuergesch] (/. github / README_LB.md) luxemburgi | [mk Македонски] (/. github / README_MK.md) macedón | [mg madagaszkár] (/. github / README_MG.md) madagaszkári | [ms Bahasa Melayu] (/. github / README_MS.md) maláj | [ml മലയാളം] (/. github / README_ML.md) malajalam | [mt Malti] (/. github / README_MT.md) máltai | [mi maori] (/. github / README_MI.md) maori | [मराठी] (/. github / README_MR.md) marathi | [mn Монгол] (/. github / README_MN.md) mongol | [my မြန်မာ] (/. github / README_MY.md) Mianmar (burmai) | [ne नेपाली] (/. github / README_NE.md) nepáli | [no norsk] (/. github / README_NO.md) norvég | [vagy ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) pastu | [fa فارسی] (/. github / README_FA.md) | perzsa [pl polski] (/. github / README_PL.md) lengyel | [pt português] (/. github / README_PT.md) portugál | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) pandzsábi | Nincs elérhető nyelv, amely Q | betűvel kezdődne [ro Română] (/. github / README_RO.md) román | [ru русский] (/. github / README_RU.md) orosz | [sm Faasamoa] (/. github / README_SM.md) szamoai | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) skót gael | [sr Српски] (/. github / README_SR.md) szerb | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) szindhi | [si සිංහල] (/. github / README_SI.md) szingaléz | [sk Slovák] (/. github / README_SK.md) szlovák | [sl Slovenščina] (/. github / README_SL.md) szlovén | [tehát Soomaali] (/. github / README_SO.md) szomáliai | [[es en español] (/. github / README_ES.md) spanyol | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) szuahéli | [sv Svenska] (/. github / README_SV.md) svéd | [tg Тоҷикӣ] (/. github / README_TG.md) tadzsik | [ta தமிழ்] (/. github / README_TA.md) tamil | [tt Татар] (/. github / README_TT.md) tatár | [te తెలుగు] (/. github / README_TE.md) telugu | [th ไทย] (/. github / README_TH.md) thai | [tr Türk] (/. github / README_TR.md) török ​​| [tk Türkmenler] (/. github / README_TK.md) türkmén | [uk Український] (/. github / README_UK.md) ukrán | [ur اردو] (/. github / README_UR.md) urdu | [ug ئۇيغۇر] (/. github / README_UG.md) ujgur | [uz O'zbek] (/. github / README_UZ.md) üzbég | [vi Tiếng Việt] (/. github / README_VI.md) vietnami | [cy Cymraeg] (/. github / README_CY.md) walesi | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jiddis | [yo joruba] (/. github / README_YO.md) joruba | [zu Zulu] (/. github / README_ZU.md) Zulu) 110 nyelven érhető el (108, ha nem vesszük figyelembe az angolt és az észak-koreait, mivel az észak-koreait még nem fordították le [Olvasson róla itt] (/ OldVersions / Koreai (Észak) ) /README.md))

A nem angol nyelvű fordítások gépi fordításúak és még nem pontosak. 2021. február 5-én még nem javítottak ki hibákat. Kérjük, jelentse a fordítási hibákat [itt] (https://github.com/seanpm2001/CamCamPlus/issues/), győződjön meg róla, hogy biztonsági másolatot készít a forrásokról, és útmutatást adjon nekem, mivel nem Nem ismeri az angolon kívül más nyelveket (tervezem, hogy végül fordítót szerzek). Kérjük, idézze meg a [wiktionary] -ot (https://en.wiktionary.org) és más forrásokat. Ennek elmulasztása a javítás közzétételének elutasítását eredményezi.

Megjegyzés: a GitHub markdown értelmezésének korlátozásai miatt (és nagyjából minden más webalapú markdown értelmezésnél) ezekre a linkekre kattintva egy külön fájlra irányítja át egy külön oldalon, amely nem az én GitHub profil oldalam. Átirányít a [seanpm2001 / seanpm2001 adattárba] (https://github.com/seanpm2001/seanpm2001), ahol a README van tárolva.

A fordításokat a Google Fordítóval végzik, mivel más fordítási szolgáltatásokban, például a DeepL és a Bing Translatorban, a szükséges nyelvek támogatása korlátozott vagy egyáltalán nincs. Dolgozom egy alternatíva megtalálásán. Valamilyen oknál fogva a formázás (linkek, elválasztók, nagyító, dőlt, stb.) Különböző fordításokban elrontott. Unalmas kijavítani, és nem tudom, hogyan lehet ezeket a problémákat nem latin karakterekkel rendelkező nyelveken megoldani, és a jobbról balra eső nyelveken (például arabul) további segítségre van szükség a problémák megoldásához

Karbantartási problémák miatt sok fordítás elavult és a `README` cikkfájl elavult verzióját használja. Fordítóra van szükség. Ezenkívül 2021. április 22-én eltart egy ideig, mire az összes új link működőképes lesz.

***

# Index

[00.0 - felső] (# felső)

> [00.1 - Cím] (# CamCamPlus)

> [00.2 - Olvassa el ezt a cikket egy másik nyelven] (# Olvassa el ezt a cikket-más-más nyelven)

> [00.3 - Index] (# Index)

[01.0 - Leírás] (# CamCamPlus)

[02.0 - About] (# About)

[03.0 - Wiki] (# Wiki)

[04.0 - Verzióelőzmények] (# Verzióelőzmények)

[05.0 - Szoftver állapota] (# Szoftver állapota)

[06.0 - Szponzor információk] (# Szponzor-információk)

[07.0 - Közreműködők] (# Közreműködők)

[08.0 - számok] (# szám)

> [08.1 - Aktuális kérdések] (# Aktuális kérdések)

> [08.2 - Korábbi számok] (# Korábbi kiadások)

> [08.3 - Korábbi lekérési kérelmek] (# Múlt-húzás-kérelmek)

> [08.4 - Aktív lekérési kérelmek] (# Aktív-pull-kérések)

[09.0 - Források] (# Források)

[10.0 - közreműködés] (# közreműködés)

[11.0 - A README-ről] (# About-README)

[12.0 - README verziótörténet] (# README-version-history)

[13.0 - lábléc] (# Ön elérte a README fájl végét)

> [13.1 - fájl vége] (# EOF)

***

# CamCamPlus
A CamCamPlus egy csúcskategóriás ingyenes és nyílt forráskódú kamera, amely sokféle formátumban és felbontásban képes képeket és videókat készíteni.

***

## Ról ről

Lásd fent. Ez a projekt egy nyílt forráskódú, nagy teljesítményű kameráról szól, amely számos lehetőséget kínál és lebontja a többi általános kameraalkalmazás akadályait (például a 30 perces rögzítési korlátot).

***

## Wiki

[Kattintson ide a projekt Wiki megtekintéséhez] (https://github.com/seanpm2001/CamCamPlus/wiki)

Ha a projekt elágazik, akkor valószínűleg eltávolították a Wikit. Szerencsére mellékelek egy beágyazott verziót. Megtekintheti [itt] (/ External / ProjectWiki /).

***

## Szponzor információk

! [SponsorButton.png] (SponsorButton.png)

Szponzorálhatja ezt a projektet, ha úgy tetszik, de kérjük, adja meg, hogy mihez szeretne adományozni. [Az adományokat itt tekintheti meg] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

A szponzor egyéb információit megtekintheti [itt] (https://github.com/seanpm2001/Sponsor-info/)

Próbáld ki! A szponzor gomb fent van a nézés / visszavonás gomb mellett.

***

## Verziótörténet

** A verzióelőzmények jelenleg nem érhetők el **

** Nincs más verzió felsorolva **

***

## Szoftver állapota

Minden művem bizonyos korlátozásoktól mentes. A DRM (** D ** igital ** R ** estrictions ** M ** anagement) egyik művemben sem található meg.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ezt a matricát a Fre támogatjae Software Foundation. Soha nem szándékozom beépíteni a DRM-et műveimbe.

A "Digitális korlátozások kezelése" rövidítést használom az ismertebb "Digitális jogkezelés" helyett, mivel a kezelés általános módja hamis, a DRM-mel nincsenek jogok. A "Digital Restrictions Management" helyesírás pontosabb, és támogatja [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) és a [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Ez a szakasz a DRM problémáinak tudatosítására szolgál, és tiltakozásul is szolgál. A DRM kialakítása hibás, és komoly veszélyt jelent az összes számítógép-felhasználóra és a szoftver szabadságára.

Kép jóváírása: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Közreműködők

Jelenleg én vagyok az egyetlen közreműködő. A közreműködés megengedett, amennyiben betartja a [BEVEZETÉS.md] (BETÖLTÉS.md) fájl szabályait.

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 kötelezettségvállalás (2021. április 22-én, csütörtökön 18: 30-kor)

> * 2. Nincs más közreműködő.

***

## Problémák

### Aktuális kérdések

* Jelenleg nincs

* Nincs más aktuális kérdés

Ha az adattár elágazik, a problémákat valószínűleg eltávolították. Szerencsére bizonyos képeket archiválok [itt] (/. Github / Issues /)

[Olvassa el a kiadási archívum adatvédelmi irányelveit itt] (/. Github / Issues / README.md)

** TL; DR **

Archiválom a saját kérdéseimet. Problémáját csak akkor archiváljuk, ha archiválását kéri.

### Korábbi kérdések

* Jelenleg nincs

* Nincsenek korábbi kérdések

Ha az adattár elágazik, a problémákat valószínűleg eltávolították. Szerencsére bizonyos képeket archiválok [itt] (/. Github / Issues /)

[Olvassa el a kiadási archívum adatvédelmi irányelveit itt] (/. Github / Issues / README.md)

** TL; DR **

Archiválom a saját kérdéseimet. Problémáját csak akkor archiváljuk, ha archiválását kéri.

### Korábbi lekérési kérelmek

* Jelenleg nincs

* Nincs más múltbeli kérés

Ha az adattár elágazik, a problémákat valószínűleg eltávolították. Szerencsére bizonyos képeket archiválok [itt] (/. Github / Issues /)

[Olvassa el a kiadási archívum adatvédelmi irányelveit itt] (/. Github / Issues / README.md)

** TL; DR **

Archiválom a saját kérdéseimet. Problémáját csak akkor archiváljuk, ha archiválását kéri.

### Aktív lekérési kérelmek

* Jelenleg nincs

* Nincs más aktív lekérési kérelem

Ha az adattár elágazik, a problémákat valószínűleg eltávolították. Szerencsére bizonyos képeket archiválok [itt] (/. Github / Issues /)

[Olvassa el a kiadási archívum adatvédelmi irányelveit itt] (/. Github / Issues / README.md)

** TL; DR **

Archiválom a saját kérdéseimet. Problémáját csak akkor archiváljuk, ha archiválását kéri.

***

## Erőforrások

Íme néhány további forrás a projekthez:

[Projekt nyelvi fájl] (PROJECT_LANG.cpp)

[A projekt kutatási referenciakönyvtára] (/ Referenciák /)

[A projekt speciális videomodulja (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[Csatlakozzon a GitHub beszélgetéséhez] (https://github.com/seanpm2001/CamCamPlus/discussions)

Jelenleg nincs más forrás.

***

## Hozzájárul

A közreműködés engedélyezett ebben a projektben, amennyiben betartja a `CONTRIBUTING.md` fájl szabályait.

[Kattintson / koppintson ide a projekt hozzájáruló szabályainak megtekintéséhez] (CONTRIBUTING.md)

***

## A README-ről

Fájl típus: `Markdown (* .md)`

A fájl változata: "1 (2021. április 22., csütörtök, 18:30)"

Vonalszám: "0,306"

***

## README verziótörténet

1. verzió (2021. április 22., csütörtök, 18:30)

> Változások:

> * Elindította a fájlt

> * Hozzáadta a cím részt

> * Hozzáadta az indexet

> * Hozzáadta a about részt

> * Hozzáadta a Wiki részt

> * Hozzáadta a verziótörténeti részt

> * Hozzáadta a kérdések szakaszt.

> * Hozzáadta a múltbeli részeket

> * Hozzáadta a múltbeli lekérési szakaszot

> * Hozzáadta az aktív lekérési szakaszokat

> * Hozzáadta a közreműködők szakaszt

> * Hozzáadta a közreműködő részt

> * Hozzáadta a about README részt

> * Hozzáadta a README verziótörténeti részt

> * Hozzáadta az erőforrások részt

> * Hozzáadott egy szoftverállapot-részt DRM-mentes matricával és üzenettel

> * Hozzáadta a szponzor információ szakaszát

> * Nincs más változás az 1. verzióban

2. verzió (hamarosan)

> Változások:

> * Hamarosan

> * Nincs más változás a 2. verzióban

***

### Elérte a README fájl végét

[Vissza a tetejére] (# top) [Kilépés] (https://github.com)

### EOF

***
