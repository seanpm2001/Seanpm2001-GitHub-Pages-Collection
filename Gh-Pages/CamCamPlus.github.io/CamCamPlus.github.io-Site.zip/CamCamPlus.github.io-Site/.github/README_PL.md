***

# Cam Cam Plus (CC +)

! [{Ikona projektu} Nie udało się załadować tego obrazu. Może to być spowodowane brakiem dostępu do pliku lub ogólnym błędem. Załaduj ponownie stronę, aby naprawić możliwy ogólny błąd.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Przez:

## [Seanpm2001] (https://github.com/seanpm2001) i inni współtwórcy

### Top

# `README.md`

***

## Przeczytaj ten artykuł w innym języku

** Bieżący język to: ** `English (US)` _ (tłumaczenia mogą wymagać korekty, aby naprawić angielski zastępujący prawidłowy język) _

_🌐 Lista języków_

** Posortowane według: ** `A-Z`

[Opcje sortowania niedostępne] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) albański | [am አማርኛ] (/. github / README_AM.md) amharski | [ar عربى] (/.github/README_AR.md) arabski | [hy հայերեն] (/. github / README_HY.md) armeński | [az Azərbaycan dili] (/. github / README_AZ.md) azerbejdżański | [eu Euskara] (/. github /README_EU.md) baskijski | [be Беларуская] (/. Github / README_BE.md) białoruski | [bn বাংলা] (/. Github / README_BN.md) bengalski | [bs Bosanski] (/. Github / README_BS.md) Bośniacki | [bg български] (/. Github / README_BG.md) bułgarski | [ca Català] (/. Github / README_CA.md) kataloński | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chiński (uproszczony) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) chiński (tradycyjny) | [co Corsu] (/. Github / README_CO.md) korsykański | [hr Hrvatski] (/. Github / README_HR.md) chorwacki | [cs čeština] (/. Github / README_CS .md) czeski | [da dansk] (README_DA.md) duński | [nl Nederlands] (/. github / README_ NL.md) holenderski | [** en-us English **] (/. github / README.md) Angielski | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) estoński | [tl Pilipino] (/. github / README_TL.md) filipiński | [fi Suomalainen] (/. github / README_FI.md) fiński | [fr français] (/. github / README_FR.md) francuski | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galicyjski | [ka ქართველი] (/. github / README_KA) gruziński | [de Deutsch] (/. github / README_DE.md) niemiecki | [el Ελληνικά] (/. github / README_EL.md) grecki | [gu ગુજરાતી] (/. github / README_GU.md) gudżarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) haitański | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawajski | [he עִברִית] (/. github / README_HE.md) hebrajski | [hi हिन्दी] (/. github / README_HI.md) hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) węgierski | [is Íslenska] (/. github / README_IS.md) islandzki | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) islandzki | [ga Gaeilge] (/. github / README_GA.md) irlandzki | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japoński | [jw Wong jawa] (/. github / README_JW.md) jawajski | [kn ಕನ್ನಡ] (/. github / README_KN.md) kannada | [kk Қазақ] (/. github / README_KK.md) Kazachski | [km ខ្មែរ] (/. github / README_KM.md) khmerski | [rw kinyarwanda] (/. github / README_RW.md) kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) koreański (południe) | [ko-north 문화어] (README_KO_NORTH.md) koreański (północ) (JESZCZE NIE PRZETŁUMACZONY) | [ku Kurdî] (/. github / README_KU.md) kurdyjski (kurmanji) | [ky Кыргызча] (/. github / README_KY.md) kirgiski | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) litewski | [lb Lëtzebuergesch] (/. github / README_LB.md) luksemburski | [mk Македонски] (/. github / README_MK.md) Macedoński | [mg malgaski] (/. github / README_MG.md) malgaski | [ms Bahasa Melayu] (/. github / README_MS.md) Malajski | [ml മലയാളം] (/. github / README_ML.md) malajalam | [mt Malti] (/. github / README_MT.md) maltański | [mi Maori] (/. github / README_MI.md) Maoryski | [pan मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) mongolski | [my မြန်မာ] (/. github / README_MY.md) Myanmar (birmański) | [ne नेपाली] (/. github / README_NE.md) nepalski | [no norsk] (/. github / README_NO.md) norweski | [lub ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) paszto | [fa فارسی] (/. github / README_FA.md) | perski [pl polski] (/. github / README_PL.md) polski | [pt português] (/. github / README_PT.md) portugalski | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Brak dostępnych języków zaczynających się na literę Q | [ro Română] (/. github / README_RO.md) rumuński | [ru русский] (/. github / README_RU.md) rosyjski | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Szkocki gaelicki | [sr Српски] (/. github / README_SR.md) serbski | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) syngaleski | [sk Slovák] (/. github / README_SK.md) słowacki | [sl Slovenščina] (/. github / README_SL.md) słoweński | [so Soomaali] (/. github / README_SO.md) Somalijski | [[es en español] (/. github / README_ES.md) hiszpański | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) suahili | [sv Svenska] (/. github / README_SV.md) szwedzki | [tg Тоҷикӣ] (/. github / README_TG.md) tadżycki | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) tatarski | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) tajski | [tr Türk] (/. github / README_TR.md) turecki | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) ukraiński | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) uzbecki | [vi Tiếng Việt] (/. github / README_VI.md) wietnamski | [cy Cymraeg] (/. github / README_CY.md) walijski | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jidysz | [yo Yoruba] (/. github / README_YO.md) Joruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Dostępny w 110 językach (108 nie licząc angielskiego i północnokoreańskiego, ponieważ język północnokoreański nie został jeszcze przetłumaczony [Przeczytaj o tym tutaj] (/ OldVersions / Korean (North ) /README.md))

Tłumaczenia na języki inne niż angielski są tłumaczone maszynowo i nie są jeszcze dokładne. Żadne błędy nie zostały jeszcze naprawione na dzień 5 lutego 2021 r. Proszę zgłaszać błędy w tłumaczeniu [tutaj] (https://github.com/seanpm2001/CamCamPlus/issues/), upewnij się, że utworzyłeś kopię zapasową swojej poprawki ze źródłami i poprowadź mnie, tak jak nie Nie znam dobrze języków innych niż angielski (planuję w końcu znaleźć tłumacza), proszę zacytować [wiktionary] (https://en.wiktionary.org) i inne źródła w swoim raporcie. Niezastosowanie się do tego spowoduje odrzucenie opublikowanej korekty.

Uwaga: ze względu na ograniczenia interpretacji przeceny przez GitHub (i prawie każdej innej internetowej interpretacji przeceny) kliknięcie tych linków przekieruje Cię do oddzielnego pliku na osobnej stronie, która nie jest moją stroną profilu GitHub. Nastąpi przekierowanie do [repozytorium seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), gdzie znajduje się plik README.

Tłumaczenia są wykonywane za pomocą Tłumacza Google ze względu na ograniczoną obsługę języków, których potrzebuję, lub jej brak w innych usługach tłumaczeniowych, takich jak DeepL i Bing Translate. Pracuję nad znalezieniem alternatywy. Z jakiegoś powodu formatowanie (linki, separatory, pogrubienie, kursywa itp.) Jest pomieszane w różnych tłumaczeniach. Jest to żmudne naprawianie i nie wiem, jak rozwiązać te problemy w językach ze znakami innymi niż łacińskie, a języki pisane od prawej do lewej (np. Arabski) wymagają dodatkowej pomocy w rozwiązywaniu tych problemów

Z powodu problemów konserwacyjnych, wiele tłumaczeń jest nieaktualnych i używa nieaktualnej wersji tego pliku z artykułem README. Potrzebny jest tłumacz. Ponadto od 22 kwietnia 2021 roku zajmie mi trochę czasu, zanim wszystkie nowe linki zaczną działać.

***

# Index

[00.0 - Top] (# Top)

> [00.1 - Tytuł] (# CamCamPlus)

> [00.2 - Przeczytaj ten artykuł w innym języku] (# Przeczytaj ten artykuł w innym języku)

> [00.3 - Indeks] (# Indeks)

[01.0 - Opis] (# CamCamPlus)

[02.0 - Informacje] (# Informacje)

[03.0 - Wiki] (# Wiki)

[04.0 - Historia wersji] (# Historia wersji)

[05.0 - Stan oprogramowania] (# Stan oprogramowania)

[06.0 - Informacje o sponsorze] (# Informacje o sponsorze)

[07.0 - Współpracownicy] (# Współpracownicy)

[08.0 - problemy] (# problemy)

> [08.1 - Bieżące problemy] (# Bieżące problemy)

> [08.2 - Wcześniejsze problemy] (# Wcześniejsze problemy)

> [08.3 - Poprzednie żądania ściągnięcia] (# Poprzednie żądania ściągnięcia)

> [08.4 - Aktywne żądania ściągnięcia] (# aktywnych żądań ściągnięcia)

[09.0 - Zasoby] (# Zasoby)

[10.0 - Współtworzenie] (# Wkład)

[11.0 - O README] (# About-README)

[12.0 - Historia wersji README] (# README-version-history)

[13.0 - Stopka] (# Osiągnąłeś-koniec-pliku-README)

> [13.1 - Koniec pliku] (# EOF)

***

# CamCamPlus
CamCamPlus to wysokiej klasy darmowy aparat o otwartym kodzie źródłowym, który może robić zdjęcia i nagrywać filmy w wielu formatach i wielu rozdzielczościach.

***

## O

Patrz wyżej. Ten projekt dotyczy potężnej kamery open source, która daje wiele opcji i przełamuje bariery, które mają inne popularne aplikacje do obsługi aparatu (takie jak limit nagrywania 30 minut)

***

## Wiki

[Kliknij / dotknij tutaj, aby wyświetlić wiki tego projektu] (https://github.com/seanpm2001/CamCamPlus/wiki)

Jeśli projekt został rozwidlony, prawdopodobnie Wiki została usunięta. Na szczęście dołączam wersję osadzoną. Możesz go zobaczyć [tutaj] (/ Zewnętrzne / ProjectWiki /).

***

## Informacje o sponsorze

! [SponsorButton.png] (SponsorButton.png)

Możesz sponsorować ten projekt, jeśli chcesz, ale określ, na co chcesz przekazać darowiznę. [Zobacz fundusze, na które możesz przekazać darowiznę tutaj] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Możesz wyświetlić inne informacje o sponsorach [tutaj] (https://github.com/seanpm2001/Sponsor-info/)

Wypróbuj to! Przycisk sponsora znajduje się tuż obok przycisku zegarka / odblokowania.

***

## Historia wersji

** Historia wersji jest obecnie niedostępna **

** Brak innych wersji na liście **

***

## Stan oprogramowania

Wszystkie moje prace są wolne od pewnych ograniczeń. DRM (** D ** igital ** R ** estrictions ** M ** anagement) nie występuje w żadnej z moich prac.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ta naklejka jest obsługiwana przez Free Software Foundation. Nigdy nie zamierzam włączać DRM do moich prac.

Używam skrótu „Digital Restrictions Management” zamiast bardziej znanego „Digital Rights Management”, ponieważ powszechny sposób rozwiązywania tego problemu jest fałszywy, nie ma praw z DRM. Pisownia „Digital Restrictions Management” jest dokładniejsza i jest obsługiwana przez [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) i [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Ta sekcja służy do podnoszenia świadomości na temat problemów z DRM, a także do protestowania przeciwko temu. DRM jest wadliwy z założenia i stanowi główne zagrożenie dla wszystkich użytkowników komputerów i wolności oprogramowania.

Źródło obrazu: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Współtwórcy

Obecnie jestem jedynym współpracownikiem. Współtworzenie jest dozwolone, o ile przestrzegasz zasad pliku [CONTRIBUTING.md] (CONTRIBUTING.md).

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 zatwierdzeń (od czwartku 22 kwietnia 2021 r. O 18:30)

> * 2. Brak innych współpracowników.

***

## Problemy

### Obecne problemy

* W tej chwili brak

* Brak innych bieżących problemów

Jeśli repozytorium zostało rozwidlone, problemy prawdopodobnie zostały usunięte. Na szczęście mam archiwum niektórych obrazów [tutaj] (/. Github / Issues /)

[Przeczytaj politykę prywatności dotyczącą archiwizacji wydań tutaj] (/. Github / Issues / README.md)

** TL; DR **

Archiwizuję własne problemy. Twój problem nie zostanie zarchiwizowany, chyba że poprosisz o archiwizację.

### Wcześniejsze problemy

* W tej chwili brak

* Żadnych innych problemów z przeszłości

Jeśli repozytorium zostało rozwidlone, problemy prawdopodobnie zostały usunięte. Na szczęście mam archiwum niektórych obrazów [tutaj] (/. Github / Issues /)

[Przeczytaj politykę prywatności dotyczącą archiwizacji wydań tutaj] (/. Github / Issues / README.md)

** TL; DR **

Archiwizuję własne problemy. Twój problem nie zostanie zarchiwizowany, chyba że poprosisz o archiwizację.

### Poprzednie żądania ściągnięcia

* W tej chwili brak

* Żadnych innych poprzednich żądań ściągnięcia

Jeśli repozytorium zostało rozwidlone, problemy prawdopodobnie zostały usunięte. Na szczęście mam archiwum niektórych obrazów [tutaj] (/. Github / Issues /)

[Przeczytaj politykę prywatności dotyczącą archiwizacji wydań tutaj] (/. Github / Issues / README.md)

** TL; DR **

Archiwizuję własne problemy. Twój problem nie zostanie zarchiwizowany, chyba że poprosisz o archiwizację.

### Aktywne żądania ściągnięcia

* W tej chwili brak

* Brak innych aktywnych żądań ściągnięcia

Jeśli repozytorium zostało rozwidlone, problemy prawdopodobnie zostały usunięte. Na szczęście mam archiwum niektórych obrazów [tutaj] (/. Github / Issues /)

[Przeczytaj politykę prywatności dotyczącą archiwizacji wydań tutaj] (/. Github / Issues / README.md)

** TL; DR **

Archiwizuję własne problemy. Twój problem nie zostanie zarchiwizowany, chyba że poprosisz o archiwizację.

***

## Zasoby

Oto kilka innych zasobów dotyczących tego projektu:

[Plik języka projektu] (PROJECT_LANG.cpp)

[Biblioteka badawcza dla tego projektu] (/ Referencje /)

[Specjalny moduł wideo dla tego projektu (wideo SVG)] (https://github.com/seanpm2001/SVG_Video/)

[Dołącz do dyskusji na GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

W tej chwili nie ma innych zasobów.

***

## Współtworzenie

Współtworzenie jest dozwolone dla tego projektu, o ile przestrzegasz zasad pliku `CONTRIBUTING.md`.

[Kliknij / dotknij tutaj, aby wyświetlić zasady współtworzenia dla tego projektu] (CONTRIBUTING.md)

***

## O README

Typ pliku: `Markdown (* .md)`

Wersja pliku: `1 (czwartek, 22 kwietnia 2021 o godzinie 18:30)`

Liczba linii: „0,306”

***

Historia wersji pliku ## README

Wersja 1 (czwartek, 22 kwietnia 2021 r., Godz. 18:30)

> Zmiany:

> * Uruchomił plik

> * Dodano sekcję tytułową

> * Dodano indeks

> * Dodano sekcję about

> * Dodano sekcję Wiki

> * Dodano sekcję historii wersji

> * Dodano sekcję problemów.

> * Dodano sekcję dotyczącą wcześniejszych problemów

> * Dodano sekcję poprzednich żądań ściągnięcia

> * Dodano sekcję aktywnych żądań ściągnięcia

> * Dodano sekcję współtwórców

> * Dodano sekcję współpracującą

> * Dodano sekcję o README

> * Dodano sekcję historii wersji README

> * Dodano sekcję zasobów

> * Dodano sekcję stanu oprogramowania z naklejką i komunikatem bez DRM

> * Dodano sekcję informacji o sponsorach

> * Brak innych zmian w wersji 1

Wersja 2 (wkrótce)

> Zmiany:

> * Wkrótce

> * Brak innych zmian w wersji 2

***

### Dotarłeś do końca pliku README

[Powrót do góry] (# Do góry) [Wyjście] (https://github.com)

### EOF

***
