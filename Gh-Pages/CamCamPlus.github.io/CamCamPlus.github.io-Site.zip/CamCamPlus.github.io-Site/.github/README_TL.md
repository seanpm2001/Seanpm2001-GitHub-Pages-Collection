***

# Cam Cam Plus (CC +)

! [{Icon ng proyekto} Hindi na-load ang imaheng ito. Maaaring sanhi ito ng hindi maabot ang file, o isang pangkalahatang error. I-reload ang pahina upang ayusin ang isang posibleng pangkalahatang error.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Ni:

## [Seanpm2001] (https://github.com/seanpm2001) at iba pang mga nag-ambag

### Nangunguna

# `README.md`

***

## Basahin ang artikulong ito sa ibang wika

** Kasalukuyang wika ay: ** `English (US)` _ (maaaring kailanganing iwasto ang mga salin upang ayusin ang Ingles na papalit sa tamang wika) _

_🌐 Listahan ng mga wika_

** Pinagsunod-sunod ni: ** `A-Z`

[Hindi magagamit ang mga pagpipilian sa pag-uuri] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanian | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) Arabe | [hy հայերեն] (/. github / README_HY.md) Armenian | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijani | [eu Euskara] (/. github /README_EU.md) Basque | [be Беларуская] (/. Github / README_BE.md) Belarusian | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnian | [bg български] (/. Github / README_BG.md) Bulgarian | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chinese (Pinasimple) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chinese (Tradisyunal) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Croatian | [cs čeština] (/. Github / README_CS .md) Czech | [da dansk] (README_DA.md) Danish | [nl Nederlands] (/. github / README_ NL.md) Dutch | [** en-us English **] (/. github / README.md) English | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonian | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finnish | [fr français] (/. github / README_FR.md) Pranses | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galician | [ka ქართველი] (/. github / README_KA) Georgian | [de Deutsch] (/. github / README_DE.md) Aleman | [el Ελληνικά] (/. github / README_EL.md) Greek | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [siya ay nagsulat] (/. github / README_HE.md) Hebrew | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hungarian | [ay Íslenska] (/. github / README_IS.md) Icelandic | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Icelandic | [ga Gaeilge] (/. github / README_GA.md) Irish | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japanese | [jw Wong jawa] (/. github / README_JW.md) Java | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-southern 韓國 語] (/. github / README_KO_SOUTH.md) Koreano (Timog) | [ko-hilaga 문화어] (README_KO_NORTH.md) Koreano (Hilaga) (HINDI PA NAKASALIN) | [ku Kurdî] (/. github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kyrgyz | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lithuanian | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxembourgish | [mk Македонски] (/. github / README_MK.md) Macedonian | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltese | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolian | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Burmese) | [ne नेेपल]] (/. github / README_NE.md) Nepali | [walang norsk] (/. github / README_NO.md) Norwegian | [o ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persian [pl polski] (/. github / README_PL.md) Polish | [pt português] (/. github / README_PT.md) Portuguese | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Walang mga magagamit na wika na nagsisimula sa titik Q | [ro Română] (/. github / README_RO.md) Romanian | [ru русский] (/. github / README_RU.md) Russian | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scots Gaelic | [sr Српски] (/. github / README_SR.md) Serbiano | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovak | [sl Slovenščina] (/. github / README_SL.md) Slovenian | [so Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spanish | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Suweko | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Turkish | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukrainian | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamese | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi י:05]] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Magagamit sa 110 mga wika (108 kung hindi binibilang ang Ingles at Hilagang Korea, dahil ang Hilagang Korea ay hindi pa naisasalin [Basahin ang tungkol dito] (/ OldVersions / Korean (North ) /README.md))

Ang mga pagsasalin sa mga wika maliban sa Ingles ay isinalin sa makina at hindi pa tumpak. Walang mga error na naayos pa noong Pebrero 5 2021. Mangyaring iulat ang mga error sa pagsasalin [dito] (https://github.com/seanpm2001/CamCamPlus/issues/) siguraduhing i-backup ang iyong pagwawasto sa mga mapagkukunan at gabayan ako, habang hindi hindi alam ang mga wika maliban sa Ingles (balak kong makakuha ng tagasalin sa kalaunan) mangyaring banggitin [wikipedia] (https://en.wiktionary.org) at iba pang mga mapagkukunan sa iyong ulat. Ang kabiguang gawin ito ay magreresulta sa isang pagtanggi sa pagwawasto ng pagwawasto.

Tandaan: dahil sa mga limitasyon sa interpretasyon ng GitHub ng markdown (at halos lahat ng iba pang pagbibigay-kahulugan sa markdown na batay sa web) i-redirect ka sa isang magkahiwalay na file sa isang hiwalay na pahina na hindi ang aking pahina sa profile na GitHub. Ire-redirect ka sa [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), kung saan naka-host ang README.

Ginagawa ang mga pagsasalin sa Google Translate dahil sa limitado o walang suporta para sa mga wikang kailangan ko sa ibang mga serbisyo sa pagsasalin tulad ng DeepL at Bing Translate. Nagtatrabaho ako sa paghahanap ng isang kahalili. Sa ilang kadahilanan, ang pag-format (mga link, divider, bolding, italics, atbp.) Ay ginulo sa iba't ibang mga pagsasalin. Nakakapagod na ayusin, at hindi ko alam kung paano ayusin ang mga isyung ito sa mga wikang may mga character na hindi pang-latin, at kanan sa kaliwang wika (tulad ng Arabe) na kailangan ng dagdag na tulong sa pag-aayos ng mga isyung ito

Dahil sa mga isyu sa pagpapanatili, maraming mga pagsasalin ang wala sa panahon at gumagamit ng isang hindi napapanahong bersyon ng 'README` na file ng artikulo. Kailangan ng tagasalin. Gayundin, hanggang Abril 22, 2021, tatagal ako ng ilang sandali upang gumana ang lahat ng mga bagong link.

***

# Index

[00.0 - Nangungunang] (# Nangungunang)

> [00.1 - Pamagat] (# CamCamPlus)

> [00.2 - Basahin ang artikulong ito sa ibang wika] (# Basahin-ang-artikulong ito-sa-ibang-wika)

> [00.3 - Index] (# Index)

[01.0 - Paglalarawan] (# CamCamPlus)

[02.0 - About] (# About)

[03.0 - Wiki] (# Wiki)

[04.0 - Kasaysayan ng bersyon] (# Bersyon-kasaysayan)

[05.0 - Katayuan ng software] (# Software-status)

[06.0 - Impormasyon ng sponsor] (# Impormasyon ng Sponsor)

[07.0 - Mga Nag-ambag] (# Mga Nag-ambag)

[08.0 - Mga Isyu] (# Mga Isyu)

> [08.1 - Mga kasalukuyang isyu] (# Mga kasalukuyang-isyu)

> [08.2 - Mga nakaraang isyu] (# Mga nakaraang isyu)

> [08.3 - Mga kahilingan sa nakaraang paghatak] (# Mga nakaraang kahilingan sa paghila)

> [08.4 - Mga aktibong kahilingan sa paghila] (# Mga aktibong-paghihiling-hinihiling)

[09.0 - Mga Mapagkukunan] (# Mga Mapagkukunan)

[10.0 - Nag-aambag] (# Nag-aambag)

[11.0 - About README] (# About-README)

[12.0 - README Kasaysayan ng bersyon] (# README-bersyon-kasaysayan)

[13.0 - Footer] (# Naabot mo na-ang-dulo-ng-README-file)

> [13.1 - Pagtatapos ng file] (# EOF)

***

# CamCamPlus
Ang CamCamPlus ay isang high-end na libre at open-source na kamera na maaaring kumuha ng mga larawan at video sa maraming mga format, at maraming mga resolusyon.

***

## Tungkol sa

Tingnan sa itaas. Ang proyektong ito ay tungkol sa isang bukas na mapagkukunang makapangyarihang camera na nagbibigay ng maraming mga pagpipilian at pinuputol ang mga hadlang na mayroon ang iba pang mga karaniwang apps ng camera (tulad ng 30 minutong limitasyon sa pagrekord)

***

## Wiki

[Mag-click / mag-tap dito upang matingnan ang mga proyektong ito Wiki] (https://github.com/seanpm2001/CamCamPlus/wiki)

Kung ang proyekto ay tinidor, malamang na ang Wiki ay tinanggal. Sa kabutihang palad, nagsasama ako ng isang naka-embed na bersyon. Maaari mo itong tingnan [dito] (/ Panlabas / ProjectWiki /).

***

## Impormasyon ng sponsor

! [Sponsor Button.png] (Sponsor Button.png)

Maaari mong i-sponsor ang proyektong ito kung nais mo, ngunit mangyaring tukuyin kung ano ang gusto mong ibigay. [Tingnan ang mga pondo na maaari mong ibigay dito] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Maaari mong tingnan ang iba pang impormasyon sa sponsor [dito] (https://github.com/seanpm2001/Sponsor-info/)

Subukan! Ang pindutan ng sponsor ay nasa tabi mismo ng pindutan ng relo / pag-unsatch.

***

## Kasaysayan ng bersyon

** Kasalukuyang hindi magagamit ang kasaysayan ng bersyon **

** Walang ibang nakalista na mga bersyon **

***

## Katayuan ng software

Lahat ng aking mga gawa ay libre ng ilang mga paghihigpit. Ang DRM (** D ** igital ** R ** mga paghihigpit ** M ** anagement) ay wala sa alinman sa aking mga gawa.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ang sticker na ito ay suportado ng Free Software Foundation. Hindi ko balak na isama ang DRM sa aking mga gawa.

Ginagamit ko ang pagdadaglat na "Pamamahala sa Mga Paghihigpit sa Digital" sa halip na ang mas kilala na "Digital Rights Management" bilang karaniwang paraan ng pagtugon dito ay mali, walang mga karapatan sa DRM. Ang spelling na "Digital Restrictions Management" ay mas tumpak, at sinusuportahan ng [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) at ng [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Ang seksyon na ito ay ginagamit upang taasan ang kamalayan para sa mga problema sa DRM, at upang protesta rin ito. Ang DRM ay may sira sa pamamagitan ng disenyo at isang pangunahing banta sa lahat ng mga gumagamit ng computer at kalayaan sa software.

Kredito sa imahe: [defectivebydesign.org/drm-free/...<<(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Mga Nag-aambag

Sa kasalukuyan, ako lang ang contributer. Pinapayagan ang pag-ambag, basta sundin mo ang mga patakaran ng [CONTRIBUTING.md] (CONTRIBUTING.md) na file.

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 commits (As of Thursday, April 22nd 2021 at 6:30 pm)

> * 2. Walang ibang mga nag-ambag.

***

## Mga Isyu

### Mga kasalukuyang isyu

* Wala sa ngayon

* Walang ibang kasalukuyang mga isyu

Kung ang tinipunan ay tinidor, malamang na tinanggal ang mga isyu. Sa kabutihang-palad ay nagtatago ako ng isang archive ng ilang mga imahe [dito] (/. Github / Mga Isyu /)

[Basahin ang patakaran sa privacy sa isyu ng archival dito] (/. Github / Mga Isyu / README.md)

** TL; DR **

Ini-archive ko ang aking sariling mga isyu. Ang iyong isyu ay hindi mai-archive maliban kung hiniling mo itong i-archive.

### Mga nakaraang isyu

* Wala sa ngayon

* Walang iba pang mga nakaraang isyu

Kung ang tinipunan ay tinidor, malamang na tinanggal ang mga isyu. Sa kabutihang-palad ay nagtatago ako ng isang archive ng ilang mga imahe [dito] (/. Github / Mga Isyu /)

[Basahin ang patakaran sa privacy sa isyu ng archival dito] (/. Github / Mga Isyu / README.md)

** TL; DR **

Ini-archive ko ang aking sariling mga isyu. Ang iyong isyu ay hindi mai-archive maliban kung hiniling mo itong i-archive.

### Nakaraang mga kahilingan sa paghila

* Wala sa ngayon

* Walang iba pang mga nakaraang humiling ng paghila

Kung ang tinipunan ay tinidor, malamang na tinanggal ang mga isyu. Sa kabutihang-palad ay nagtatago ako ng isang archive ng ilang mga imahe [dito] (/. Github / Mga Isyu /)

[Basahin ang patakaran sa privacy sa isyu ng archival dito] (/. Github / Mga Isyu / README.md)

** TL; DR **

Ini-archive ko ang aking sariling mga isyu. Ang iyong isyu ay hindi mai-archive maliban kung hiniling mo itong i-archive.

### Mga aktibong kahilingan sa paghila

* Wala sa ngayon

* Walang iba pang mga aktibong kahilingan sa paghila

Kung ang tinipunan ay tinidor, malamang na tinanggal ang mga isyu. Sa kabutihang-palad ay nagtatago ako ng isang archive ng ilang mga imahe [dito] (/. Github / Mga Isyu /)

[Basahin ang patakaran sa privacy sa isyu ng archival dito] (/. Github / Mga Isyu / README.md)

** TL; DR **

Ini-archive ko ang aking sariling mga isyu. Ang iyong isyu ay hindi mai-archive maliban kung hiniling mo itong i-archive.

***

## Mga mapagkukunan

Narito ang ilang iba pang mga mapagkukunan para sa proyektong ito:

[File ng wika ng proyekto] (PROJECT_LANG.cpp)

[Library reference library para sa proyektong ito] (/ Mga Sanggunian /)

[Ang espesyal na module ng video para sa proyektong ito (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[Sumali sa talakayan sa GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

Walang ibang mapagkukunan sa ngayon.

***

## Nag-aambag

Pinapayagan ang pag-ambag para sa proyektong ito, hangga't sinusunod mo ang mga patakaran ng file na `CONTRIBUTING.md`.

[Mag-click / mag-tap dito upang tingnan ang mga panuntunan sa pagbibigay para sa proyektong ito] (CONTRIBUTING.md)

***

## Tungkol sa README

Uri ng file: `Markdown (* .md)`

Bersyon ng file: `1 (Huwebes, Abril 22nd 2021 ng 6:30 pm)`

Bilang ng linya: `0,306`

***

## README na kasaysayan ng bersyon

Bersyon 1 (Huwebes, Abril 22nd 2021 ng 6:30 pm)

> Mga pagbabago:

> * Sinimulan ang file

> * Idinagdag ang seksyon ng pamagat

> * Idinagdag ang index

> * Idinagdag ang tungkol sa seksyon

> * Idinagdag ang seksyon ng Wiki

> * Idinagdag ang seksyon ng kasaysayan ng bersyon

> * Idinagdag ang seksyon ng mga isyu.

> * Idinagdag ang nakaraang seksyon ng mga isyu

> * Idinagdag ang nakaraang seksyon ng mga kahilingan sa paghila

> * Idinagdag ang seksyon ng mga aktibong kahilingan sa paghila

> * Idinagdag ang seksyon ng mga nag-aambag

> * Idinagdag ang seksyon ng nag-aambag

> * Idinagdag ang tungkol sa seksyong README

> * Idinagdag ang seksyon ng kasaysayan ng README bersyon

> * Idinagdag ang seksyon ng mga mapagkukunan

> * Nagdagdag ng isang seksyon ng katayuan ng software, na may isang libreng sticker at mensahe ng DRM

> * Idinagdag ang seksyon ng impormasyon ng sponsor

> * Walang ibang mga pagbabago sa bersyon 1

Bersyon 2 (Malapit na)

> Mga pagbabago:

> * Malapit na

> * Walang ibang mga pagbabago sa bersyon 2

***

### Naabot mo na ang dulo ng file na README

[Bumalik sa tuktok] (# Nangungunang) [Exit] (https://github.com)

### EOF

***
