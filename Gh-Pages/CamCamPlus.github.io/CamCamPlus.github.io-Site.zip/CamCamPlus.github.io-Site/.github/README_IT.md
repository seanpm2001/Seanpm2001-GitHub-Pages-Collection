***

# Cam Cam Plus (CC +)

! [{Icona progetto} Impossibile caricare questa immagine. Potrebbe essere dovuto al mancato raggiungimento del file o a un errore generale. Ricarica la pagina per correggere un possibile errore generale.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Di:

## [Seanpm2001] (https://github.com/seanpm2001) e altri collaboratori

### Superiore

# `README.md`

***

## Leggi questo articolo in una lingua diversa

** La lingua corrente è: ** `Inglese (USA)` _ (potrebbe essere necessario correggere le traduzioni per correggere l'inglese sostituendo la lingua corretta) _

_🌐 Elenco delle lingue_

** Ordinati per: ** `A-Z`

[Opzioni di ordinamento non disponibili] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanese | [am አማርኛ] (/. github / README_AM.md) Amarico | [ar عربى] (/.github/README_AR.md) Arabo | [hy հայերեն] (/. github / README_HY.md) Armeno | [az Azərbaycan dili] (/. github / README_AZ.md) Azero | [eu Euskara] (/. github /README_EU.md) Basco | [be Беларуская] (/. Github / README_BE.md) Bielorusso | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosniaco | [bg български] (/. Github / README_BG.md) Bulgaro | [ca Català] (/. Github / README_CA.md) Catalano | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Cinese (semplificato) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Cinese (tradizionale) | [co Corsu] (/. Github / README_CO.md) Corso | [hr Hrvatski] (/. Github / README_HR.md) Croato | [cs čeština] (/. Github / README_CS .md) Ceco | [da dansk] (README_DA.md) Danese | [nl Nederlands] (/. github / README_ NL.md) Olandese | [** en-us English **] (/. github / README.md) Inglese | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estone | [tl Pilipino] (/. github / README_TL.md) Filippino | [fi Suomalainen] (/. github / README_FI.md) Finlandese | [fr français] (/. github / README_FR.md) Francese | [fy Frysk] (/. github / README_FY.md) Frisone | [gl Galego] (/. github / README_GL.md) Galiziano | [ka ქართველი] (/. github / README_KA) Georgiano | [de Deutsch] (/. github / README_DE.md) Tedesco | [el Ελληνικά] (/. github / README_EL.md) Greco | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Creolo haitiano | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiano | [he עִברִית] (/. github / README_HE.md) Ebraico | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ungherese | [è Íslenska] (/. github / README_IS.md) Islandese | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandese | [ga Gaeilge] (/. github / README_GA.md) Irlandese | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Giapponese | [jw Wong jawa] (/. github / README_JW.md) Giavanese | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazako | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Coreano (Sud) | [ko-north 문화어] (README_KO_NORTH.md) Coreano (Nord) (NON ANCORA TRADOTTO) | [ku Kurdî] (/. github / README_KU.md) Curdo (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirghizistan | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latino | [lt Lietuvis] (/. github / README_LT.md) Lituano | [lb Lëtzebuergesch] (/. github / README_LB.md) Lussemburghese | [mk Македонски] (/. github / README_MK.md) Macedone | [mg malgascio] (/. github / README_MG.md) malgascio | [ms Bahasa Melayu] (/. github / README_MS.md) Malese | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltese | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolo | [my မြန်မာ] (/. github / README_MY.md) Myanmar (birmano) | [ne नेपाली] (/. github / README_NE.md) Nepalese | [no norsk] (/. github / README_NO.md) Norvegese | [o ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persiano [pl polski] (/. github / README_PL.md) Polacco | [pt português] (/. github / README_PT.md) Portoghese | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Non sono disponibili lingue che iniziano con la lettera Q | [ro Română] (/. github / README_RO.md) Rumeno | [ru русский] (/. github / README_RU.md) Russo | [sm Faasamoa] (/. github / README_SM.md) Samoano | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Gaelico scozzese | [sr Српски] (/. github / README_SR.md) Serbo | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Singalese | [sk Slovák] (/. github / README_SK.md) Slovacco | [sl Slovenščina] (/. github / README_SL.md) Sloveno | [so Soomaali] (/. github / README_SO.md) Somalo | [[es en español] (/. github / README_ES.md) Spagnolo | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Svedese | [tg Тоҷикӣ] (/. github / README_TG.md) Tagicco | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatarico | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Tailandese | [tr Türk] (/. github / README_TR.md) Turco | [tk Türkmenler] (/. github / README_TK.md) Turkmeno | [uk Український] (/. github / README_UK.md) Ucraino | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbeko | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamita | [cy Cymraeg] (/. github / README_CY.md) Gallese | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Disponibile in 110 lingue (108 senza contare l'inglese e il nordcoreano, poiché il nordcoreano non è stato ancora tradotto [Leggi qui] (/ OldVersions / coreano (nord ) /README.md))

Le traduzioni in lingue diverse dall'inglese sono tradotte automaticamente e non sono ancora accurate. Nessun errore è stato ancora corretto a partire dal 5 febbraio 2021. Segnala gli errori di traduzione [qui] (https://github.com/seanpm2001/CamCamPlus/issues/) assicurati di eseguire il backup della tua correzione con le fonti e guidami, poiché io non Non conosci bene lingue diverse dall'inglese (ho intenzione di trovare un traduttore alla fine) per favore cita [wiktionary] (https://en.wiktionary.org) e altre fonti nel tuo rapporto. In caso contrario, la pubblicazione della correzione verrà rifiutata.

Nota: a causa delle limitazioni con l'interpretazione del markdown di GitHub (e praticamente ogni altra interpretazione del markdown basata sul web) facendo clic su questi collegamenti verrai reindirizzato a un file separato su una pagina separata che non è la mia pagina del profilo GitHub. Verrai reindirizzato al [repository seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), dove è ospitato il README.

Le traduzioni vengono eseguite con Google Translate a causa del supporto limitato o inesistente per le lingue di cui ho bisogno in altri servizi di traduzione come DeepL e Bing Translate. Sto lavorando per trovare un'alternativa. Per qualche ragione, la formattazione (collegamenti, divisori, grassetto, corsivo, ecc.) È incasinata in varie traduzioni. È noioso da risolvere e non so come risolvere questi problemi nelle lingue con caratteri non latini e per le lingue da destra a sinistra (come l'arabo) è necessario ulteriore aiuto per risolvere questi problemi

A causa di problemi di manutenzione, molte traduzioni non sono aggiornate e utilizzano una versione obsoleta di questo file di articolo "README". Serve un traduttore. Inoltre, a partire dal 22 aprile 2021, mi ci vorrà un po 'per far funzionare tutti i nuovi collegamenti.

***

# Indice

[00.0 - Top] (# Top)

> [00.1 - Titolo] (# CamCamPlus)

> [00.2 - Leggi questo articolo in una lingua diversa] (# Leggi questo articolo in una lingua diversa)

> [00.3 - Indice] (# Indice)

[01.0 - Descrizione] (# CamCamPlus)

[02.0 - Informazioni] (# Informazioni)

[03.0 - Wiki] (# Wiki)

[04.0 - Cronologia delle versioni] (# Cronologia delle versioni)

[05.0 - Stato del software] (# Stato del software)

[06.0 - Informazioni sullo sponsor] (# informazioni sullo sponsor)

[07.0 - Collaboratori] (# collaboratori)

[08.0 - Problemi] (# problemi)

> [08.1 - Problemi attuali] (# Problemi attuali)

> [08.2 - Numeri passati] (# Numeri precedenti)

> [08.3 - Richieste pull precedenti] (# Richieste pull precedenti)

> [08.4 - Richieste pull attive] (# Richieste pull attive)

[09.0 - Risorse] (# risorse)

[10.0 - Contribuire] (# Contribuire)

[11.0 - Informazioni su README] (# Informazioni su README)

[12.0 - README Version history] (# README-version-history)

[13.0 - Piè di pagina] (# Hai-raggiunto-la-fine-del-file-README)

> [13.1 - Fine del file] (# EOF)

***

# CamCamPlus
CamCamPlus è una fotocamera di fascia alta gratuita e open source che può scattare foto e video in molti formati e molte risoluzioni.

***

## Di

Vedi sopra. Questo progetto riguarda una potente fotocamera open source che offre molte opzioni e abbatte le barriere che altre app per fotocamere comuni hanno (come il limite di registrazione di 30 minuti)

***

## Wiki

[Fare clic / toccare qui per visualizzare la Wiki di questo progetto] (https://github.com/seanpm2001/CamCamPlus/wiki)

Se il progetto è stato biforcato, probabilmente il Wiki è stato rimosso. Fortunatamente, includo una versione incorporata. Puoi vederlo [qui] (/ External / ProjectWiki /).

***

## Informazioni sullo sponsor

! [SponsorButton.png] (SponsorButton.png)

Puoi sponsorizzare questo progetto se lo desideri, ma specifica a cosa vuoi donare. [Vedi i fondi a cui puoi donare qui] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Puoi visualizzare altre informazioni sugli sponsor [qui] (https://github.com/seanpm2001/Sponsor-info/)

Provalo! Il pulsante sponsor si trova proprio accanto al pulsante guarda / rimuovi.

***

## Cronologia delle versioni

** Cronologia delle versioni attualmente non disponibile **

** Nessun'altra versione elencata **

***

## Stato del software

Tutti i miei lavori sono liberi da alcune restrizioni. DRM (** D ** igital ** R ** estrictions ** M ** anagement) non è presente in nessuno dei miei lavori.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Questo adesivo è supportato da Free Software Foundation. Non ho mai intenzione di includere DRM nei miei lavori.

Sto usando l'abbreviazione "Digital Restrictions Management" invece del più noto "Digital Rights Management" poiché il modo comune di affrontarlo è falso, non ci sono diritti con DRM. L'ortografia "Digital Restrictions Management" è più accurata ed è supportata da [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) e dalla [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Questa sezione viene utilizzata per aumentare la consapevolezza dei problemi con DRM e anche per protestare. DRM è difettoso in base alla progettazione ed è una grave minaccia per tutti gli utenti di computer e per la libertà del software.

Credito immagine: [defectivebydesign.org/drm-free/...”(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Collaboratori

Attualmente, sono l'unico contributore. Contribuire è consentito, purché si seguano le regole del file [CONTRIBUTING.md] (CONTRIBUTING.md).

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 commit (a partire da giovedì 22 aprile 2021 alle 18:30)

> * 2. Nessun altro contributore.

***

## Problemi

### Problemi attuali

* Nessuno al momento

* Nessun altro problema attuale

Se il repository è stato forkato, è probabile che i problemi siano stati rimossi. Per fortuna tengo un archivio di alcune immagini [qui] (/. Github / Issues /)

[Leggi l'informativa sulla privacy per l'archiviazione del problema qui] (/. Github / Issues / README.md)

** TL; DR **

Archivia i miei problemi. Il tuo problema non verrà archiviato a meno che tu non ne richieda l'archiviazione.

### Problemi passati

* Nessuno al momento

* Nessun altro problema passato

Se il repository è stato forkato, è probabile che i problemi siano stati rimossi. Per fortuna tengo un archivio di alcune immagini [qui] (/. Github / Issues /)

[Leggi l'informativa sulla privacy per l'archiviazione del problema qui] (/. Github / Issues / README.md)

** TL; DR **

Archivia i miei problemi. Il tuo problema non verrà archiviato a meno che tu non ne richieda l'archiviazione.

### Richieste pull passate

* Nessuno al momento

* Nessun'altra richiesta pull passata

Se il repository è stato forkato, è probabile che i problemi siano stati rimossi. Per fortuna tengo un archivio di alcune immagini [qui] (/. Github / Issues /)

[Leggi l'informativa sulla privacy per l'archiviazione del problema qui] (/. Github / Issues / README.md)

** TL; DR **

Archivia i miei problemi. Il tuo problema non verrà archiviato a meno che tu non ne richieda l'archiviazione.

### Richieste pull attive

* Nessuno al momento

* Nessun'altra richiesta pull attiva

Se il repository è stato forkato, è probabile che i problemi siano stati rimossi. Per fortuna tengo un archivio di alcune immagini [qui] (/. Github / Issues /)

[Leggi l'informativa sulla privacy per l'archiviazione del problema qui] (/. Github / Issues / README.md)

** TL; DR **

Archivia i miei problemi. Il tuo problema non verrà archiviato a meno che tu non ne richieda l'archiviazione.

***

## Risorse

Ecco alcune altre risorse per questo progetto:

[File lingua progetto] (PROJECT_LANG.cpp)

[Biblioteca di riferimento per la ricerca per questo progetto] (/ Riferimenti /)

[Il modulo video speciale per questo progetto (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[Partecipa alla discussione su GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

Nessun'altra risorsa al momento.

***

## Contribuire

È consentito contribuire a questo progetto, purché si seguano le regole del file `CONTRIBUTING.md`.

[Clicca / tocca qui per visualizzare le regole di contribuzione per questo progetto] (CONTRIBUTING.md)

***

## Informazioni su README

Tipo di file: `Markdown (* .md)`

Versione file: "1 (giovedì 22 aprile 2021 alle 18:30)"

Conteggio righe: "0,306"

***

## README cronologia delle versioni

Versione 1 (giovedì 22 aprile 2021 alle 18:30)

> Modifiche:

> * Ha avviato il file

> * Aggiunta la sezione del titolo

> * Aggiunto l'indice

> * Aggiunta la sezione Informazioni

> * Aggiunta la sezione Wiki

> * Aggiunta la sezione della cronologia delle versioni

> * Aggiunta la sezione dei problemi.

> * Aggiunta la sezione dei problemi passati

> * Aggiunta la sezione delle richieste pull passate

> * Aggiunta la sezione delle richieste pull attive

> * Aggiunta la sezione dei contributori

> * Aggiunta la sezione dei contributi

> * Aggiunta la sezione README

> * Aggiunta la sezione della cronologia delle versioni README

> * Aggiunta la sezione delle risorse

> * Aggiunta una sezione di stato del software, con un adesivo e un messaggio senza DRM

> * Aggiunta la sezione delle informazioni sugli sponsor

> * Nessun altro cambiamento nella versione 1

Versione 2 (disponibile a breve)

> Modifiche:

> * Prossimamente

> * Nessun altro cambiamento nella versione 2

***

### Hai raggiunto la fine del file README

[Torna all'inizio] (# Top) [Esci] (https://github.com)

### EOF

***
