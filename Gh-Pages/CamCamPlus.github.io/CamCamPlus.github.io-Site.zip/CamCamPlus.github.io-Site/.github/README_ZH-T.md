***

＃Cam Cam Plus（CC +）

！[{項目圖標}此圖像無法加載。可能是由於未到達文件或一般錯誤。重新加載頁面以解決可能的一般錯誤。]（/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg）

＃ 經過：

## [Seanpm2001]（https://github.com/seanpm2001）和其他貢獻者

＃＃＃ 頂部

＃`README.md`

***

##用另一種語言閱讀本文

**當前語言是：**`英語（美國）`_（翻譯可能需要更正以修復英語，以替換正確的語言）_

_🌐語言列表_

**排序：**`A-Z`

[排序選項不可用]（https://github.com/Degoogle-your-Life）

（[af Afrikaans]（/。github / README_AF.md）Afrikaans | [sq Shqiptare]（/。github / README_SQ.md）阿爾巴尼亞語| [amአማርኛ]（/。github / README_AM.md）Amharic | [arعربى] （/.github/README_AR.md）阿拉伯語| [hyհայերեն]（/。github / README_HY.md）亞美尼亞語| [azAzərbaycandili]（/。github / README_AZ.md）阿塞拜疆| [eu Euskara]（/。github /README_EU.md）巴斯克語| [beБеларуская]（/。github / README_BE.md）白俄羅斯語| [bnবাংলা]（/。github / README_BN.md）孟加拉語| [bs Bosanski]（/。github / README_BS.md）波斯尼亞語| [bgбългарски]（/。github / README_BG.md）保加利亞語| [caCatalà]（/。github / README_CA.md）加泰羅尼亞語| [ceb Sugbuanon]（/ .. github / README_CEB.md）Cebuano | [ny Chichewa ]（/。github / README_NY.md）Chichewa | [zh-CN簡體中文]（/。github / README_ZH-CN.md）簡體中文| [zh-t中國傳統的）]（/。github / README_ZH -T.md）中文（繁體）| [co Corsu]（/。github / README_CO.md）科西嘉語| [hr Hrvatski]（/。github / README_HR.md）克羅地亞語| [csčeština]（/。github / README_CS .md）捷克語| [da dansk]（README_DA.md）丹麥語| [nl Nederlands]（/。github / README_ NL.md）荷蘭語| [** zh-cn英語**]（/。github / README.md）英語| [EO世界語]（/。github / README_EO.md）世界語| [et Eestlane]（/。github / README_ET.md）愛沙尼亞語| [tl Pilipino]（/。github / README_TL.md）菲律賓| [fi Suomalainen]（/。github / README_FI.md）芬蘭語| [frfrançais]（/。github / README_FR.md）法語| [fy Frysk]（/。github / README_FY.md）弗里斯蘭語| [gl Galego]（/。github / README_GL.md）加利西亞語| [kaქართველი]（/。github / README_KA）格魯吉亞語| [de Deutsch]（/。github / README_DE.md）德語| [elΕλληνικά]（/。github / README_EL.md）希臘語| [guગુજરાતી]（/。github / README_GU.md）古吉拉特語| [htKreyòlayisyen]（/。github / README_HT.md）海地克里奧爾語| [ha Hausa]（/。github / README_HA.md）Hausa | [hawŌleloHawaiʻi]（/。github / README_HAW.md）夏威夷語| [heעִברִית]（/。github / README_HE.md）希伯來語| [hiहिन्दी]（/。github / README_HI.md）印地語| [hmn Hmong]（/。github / README_HMN.md）Hmong | [hu Magyar]（/。github / README_HU.md）匈牙利語| [是Íslenska]（/。github / README_IS.md）冰島語| [ig Igbo]（/。github / README_IG.md）Igbo | [id bahasa Indonesia]（/。github / README_ID.md）冰島語| [ga Gaeilge]（/。github / README_GA.md）愛爾蘭語| [it Italiana / Italiano]（/。github / README_IT.md）| [ja日本語]（/。github / README_JA.md）日語| [jw Wong頜骨]（/。github / README_JW.md）Javanese | [knಕನ್ನಡ]（/。github / README_KN.md）卡納達語| [kkҚазақ]（/。github / README_KK.md）哈薩克語| [kmខ្មែរ]（/。github / README_KM.md）高棉語| [rw Kinyarwanda]（/。github / README_RW.md）Kinyarwanda | [ko-south韓國語]（/。github / README_KO_SOUTH.md）韓語（南）| [ko-north문화어]（README_KO_NORTH.md）朝鮮語（北部）（尚未翻譯）| [kuKurdî]（/。github / README_KU.md）庫爾德語（Kurmanji）| [kyКыргызча]（/。github / README_KY.md）吉爾吉斯語| [loລາວ]（/。github / README_LO.md）老撾| [la Latine]（/。github / README_LA.md）拉丁語| [lt Lietuvis]（/。github / README_LT.md）立陶宛語| [lbLëtzebuergesch]（/。github / README_LB.md）盧森堡語| [mkМакедонски]（/。github / README_MK.md）馬其頓語| [mg馬達加斯加語]（/。github / README_MG.md）馬達加斯加語| [ms Bahasa Melayu]（/。github / README_MS.md）馬來語| [mlമലയാളം]（/。github / README_ML.md）馬拉雅拉姆語| [mt Malti]（/。github / README_MT.md）馬耳他語| [mi Maori]（/。github / README_MI.md）毛利人| [mrमराठी]（/。github / README_MR.md）馬拉地語| [mnМонгол]（/。github / README_MN.md）蒙古語| [myမြန်မာ]（/。github / README_MY.md）緬甸（緬甸）| [neनेपाली]（/。github / README_NE.md）尼泊爾語| [no norsk]（/。github / README_NO.md）挪威文| [或ଓଡିଆ（ଓଡିଆ）]（/。github / README_OR.md）Odia（奧里亞語）| [psپښتو]（/。github / README_PS.md）普什圖語| [faفارسی]（/。github / README_FA.md）|波斯語[pl polski]（/。github / README_PL.md）波蘭語| [ptportuguês]（/。github / README_PT.md）葡萄牙語| [paਪੰਜਾਬੀ]（/。github / README_PA.md）旁遮普語|沒有可用字母Q |開頭的語言。 [roRomână]（/。github / README_RO.md）羅馬尼亞語| [ruрусский]（/。github / README_RU.md）俄語| [sm Faasamoa]（/。github / README_SM.md）薩摩亞語| [gdGàidhligna h-Alba]（/。github / README_GD.md）Scots Gaelic | [srСрпски]（/。github / README_SR.md）塞爾維亞語| [st Sesotho]（/。github / README_ST.md）Sesotho | [sn Shona]（/。github / README_SN.md）Shona | [sdسنڌي]（/。github / README_SD.md）信德語| [siසිංහල]（/。github / README_SI.md）僧伽羅語| [sk斯洛伐克語]（/。github / README_SK.md）斯洛伐克語| [slSlovenščina]（/。github / README_SL.md）斯洛文尼亞語| [so Soomaali]（/。github / README_SO.md）索馬里文| [[es enespañol]（/。github / README_ES.md）西班牙語| [su Sundanis]（/。github / README_SU.md）Su丹麥語| [sw Kiswahili]（/。github / README_SW.md）斯瓦希里語| [sv Svenska]（/。github / README_SV.md）瑞典語| [tgТоҷикӣ]（/。github / README_TG.md）塔吉克語| [taதமிழ்]（/。github / README_TA.md）泰米爾語| [ttТатар]（/。github / README_TT.md）塔塔爾語| [teతెలుగు]（/。github / README_TE.md）泰盧固語| [thไทย]（/。github / README_TH.md）泰國語| [trTürk]（/。github / README_TR.md）土耳其語| [tkTürkmenler]（/。github / README_TK.md）土庫曼人| [ukУкраїнський]（/。github / README_UK.md）烏克蘭語| [urاردو]（/。github / README_UR.md）烏爾都語| [ugئۇيغۇر]（/。github / README_UG.md）維吾爾語| [uz O'zbek]（/。github / README_UZ.md）烏茲別克語| [viTiếngViệt]（/。github / README_VI.md）越南語| [cy Cymraeg]（/。github / README_CY.md）威爾士語| [xh isiXhosa]（/。github / README_XH.md）Xhosa | [yiיידיש]（/。github / README_YI.md）意第緒語| [yo Yoruba]（/。github / README_YO.md）Yoruba | [zu Zulu]（/。github / README_ZU.md）Zulu）支持110種語言（不算英語和朝鮮語時為108種語言，因為朝鮮語尚未翻譯[請在此處閱讀] [/ OldVersions / Korean（North ）/README.md））

除英語以外的其他語言的翻譯是機器翻譯的，尚不准確。截至2021年2月5日，尚未修復錯誤。請在此處報告翻譯錯誤[https://github.com/seanpm2001/CamCamPlus/issues/）確保備份您的更正內容並指導我，因為我不這樣做。除了英語以外，我還不太會說其他語言（我最終打算安排翻譯），請在您的報告中引用[wiktionary]（https://en.wiktionary.org）和其他來源。否則，將拒絕發布更正。

注意：由於GitHub對markdown的解釋（以及幾乎所有其他基於Web的markdown解釋）的限制，單擊這些鏈接會將您重定向到單獨頁面上的單獨文件，該頁面不是我的GitHub個人資料頁面。您將被重定向到託管README的[seanpm2001 / seanpm2001存儲庫]（https://github.com/seanpm2001/seanpm2001）。

由於我在其他翻譯服務（例如DeepL和Bing Translate）中所需語言的支持有限或不支持，因此需要使用Google Translate進行翻譯。我正在尋找替代方案。由於某種原因，格式（鏈接，分隔符，粗體，斜體等）在各種翻譯中都被弄亂了。解決起來很繁瑣，而且我不知道如何使用非拉丁字符的語言來解決這些問題，從右到左的語言（例如阿拉伯語）需要額外的幫助來解決這些問題。

由於維護問題，許多翻譯版本已經過時，並且使用的是本“ README”文章文件的過時版本。需要翻譯器。另外，從2021年4月22日開始，要使所有新鏈接正常工作還需要一段時間。

***

＃ 指數

[00.0-頁首]（＃Top）

> [00.1-標題]（＃CamCamPlus）

> [00.2-用另一種語言閱讀本文]（＃Read-this-article-in-a-language語言）

> [00.3-索引]（＃Index）

[01.0-說明]（＃CamCamPlus）

[02.0-關於]（＃About）

[03.0-Wiki]（＃Wiki）

[04.0-版本歷史記錄]（＃Version-history）

[05.0-軟件狀態]（＃Software-status）

[06.0-贊助商信息]（＃Sponsor-info）

[07.0-貢獻者]（＃貢獻者）

[08.0-問題]（＃問題）

> [08.1-當前問題]（＃當前問題）

> [08.2-過去的問題]（＃過去的問題）

> [08.3-過去的拉取請求]（＃Past-pull-requests）

> [08.4-活動請求請求]（＃Active-pull-requests）

[09.0-資源]（＃Resources）

[10.0-貢獻]（＃貢獻）

[11.0-關於自述文件]（＃About-README）

[12.0-自述版本歷史記錄]（＃README-version-history）

[13.0-頁腳]（＃您已到達自述文件的結尾）

> [13.1-文件結束]（＃EOF）

***

＃CamCamPlus
CamCamPlus是一款高端的免費開源相機，可以拍攝多種格式和分辨率的照片和視頻。

***

＃＃ 關於

看上面。該項目是關於一個開源的，功能強大的相機，它提供了許多選項並打破了其他常見相機應用程序所具有的障礙（例如30分鐘的錄製限制）

***

##維基

[單擊/點擊此處以查看此項目Wiki]（https://github.com/seanpm2001/CamCamPlus/wiki）

如果項目已經分叉，則可能已刪除Wiki。幸運的是，我包含一個嵌入式版本。您可以在[此處]（/ External / ProjectWiki /）進行查看。

***

##贊助商信息

！[SponsorButton.png]（SponsorButton.png）

您可以根據需要贊助此項目，但請指定您要捐贈的內容。 [在這裡查看您可以捐贈的資金]（https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors）

您可以在此處查看其他贊助商信息（https://github.com/seanpm2001/Sponsor-info/）

試試看！贊助商按鈕在觀看/取消觀看按鈕旁邊。

***

##版本歷史

**當前版本歷史不可用**

**未列出其他版本**

***

##軟件狀態

我所有的作品都是免費的，有一些限制。我的任何作品中都沒有DRM（** D **原始** R **限制** M **管理）。

！[DRM-free_label.en.svg]（DRM-free_label.en.svg）

此貼紙由Fre支持e軟件基金會。我從不打算在自己的作品中加入DRM。

我使用的縮寫是“數字限制管理”，而不是更廣為人知的“數字版權管理”，因為解決它的常見方法是錯誤的，DRM沒有任何版權。 [Richard M. Stallman（RMS）]（https://en.wikipedia.org/wiki/Richard_Stallman）和[Free Software Foundation（FSF）]支持拼寫“數字限制管理”， https://zh.wikipedia.org/wiki/Free_Software_Foundation）

本部分用於提高對DRM問題的認識，並進行抗議。 DRM在設計上是有缺陷的，並且是對所有計算機用戶和軟件自由的重大威脅。

圖片來源：[defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label）

***

##貢獻者

目前，我是唯一的貢獻者。只要您遵守[CONTRIBUTING.md]（CONTRIBUTING.md）文件的規則，就可以進行貢獻。

> * 1. [seanpm2001]（https://github.com/seanpm2001/）-138次提交（截至2021年4月22日，星期四，下午6:30）

> * 2.沒有其他貢獻者。

***

＃＃ 問題

＃＃＃ 當前的問題

*目前沒有

*沒有其他當前問題

如果存儲庫已分叉，則可能已消除了問題。幸運的是，我在此處保存了某些圖像的存檔（/.github/Issues/）

[在此處閱讀有關問題存檔的隱私政策]（/。github / Issues / README.md）

** TL; DR **

我將自己的問題存檔。除非您要求存檔，否則不會存檔您的問題。

###過去的問題

*目前沒有

*沒有其他過去的問題

如果存儲庫已分叉，則可能已消除了問題。幸運的是，我在此處保存了某些圖像的存檔（/.github/Issues/）

[在此處閱讀有關問題存檔的隱私政策]（/。github / Issues / README.md）

** TL; DR **

我將自己的問題存檔。除非您要求存檔，否則不會存檔您的問題。

###過去的拉取請求

*目前沒有

*沒有其他過去的拉取請求

如果存儲庫已分叉，則可能已消除了問題。幸運的是，我在此處保存了某些圖像的存檔（/.github/Issues/）

[在此處閱讀有關問題存檔的隱私政策]（/。github / Issues / README.md）

** TL; DR **

我將自己的問題存檔。除非您要求存檔，否則不會存檔您的問題。

###活動拉取請求

*目前沒有

*沒有其他活動的請求請求

如果存儲庫已分叉，則可能已消除了問題。幸運的是，我在此處保存了某些圖像的存檔（/.github/Issues/）

[在此處閱讀有關問題存檔的隱私政策]（/。github / Issues / README.md）

** TL; DR **

我將自己的問題存檔。除非您要求存檔，否則不會存檔您的問題。

***

＃＃ 資源

這是該項目的其他一些資​​源：

[項目語言文件]（PROJECT_LANG.cpp）

[此項目的研究參考庫]（/ References /）

[此項目的特殊視頻模塊（SVG視頻）]（https://github.com/seanpm2001/SVG_Video/）

[在GitHub上加入討論]（https://github.com/seanpm2001/CamCamPlus/discussions）

目前沒有其他資源。

***

##貢獻

只要您遵循CONTRIBUTING.md文件的規則，就可以為該項目做貢獻。

[點擊/點擊此處查看該項目的貢獻規則]（CONTRIBUTING.md）

***

##關於自述文件

文件類型：`Markdown（* .md）`

檔案版本：`1（2021年4月22日，星期四，下午6:30）

行數：`0,306`

***

##自述版本歷史

版本1（2021年4月22日，星期四，下午6:30）

>變更：

> *開始文件

> *添加了標題部分

> *添加索引

> *添加了關於部分

> *添加了Wiki部分

> *添加了版本歷史記錄部分

> *添加了問題部分。

> *添加了“過去的問題”部分

> *添加了過去的拉取請求部分

> *添加了活動拉取請求部分

> *添加了貢獻者部分

> *添加了貢獻部分

> *添加了關於README部分

> *添加了自述版本歷史記錄部分

> *添加了資源部分

> *添加了軟件狀態部分，帶有免費的DRM標籤和消息

> *添加了贊助商信息部分

> *版本1中沒有其他更改

版本2（即將推出）

>變更：

> *即將推出

> *版本2中沒有其他更改

***

###您已到達README文件的末尾

[返回頁首]（＃Top）[退出]（https://github.com）

### EOF

***
