***

# מצלמת פקה פלוס (CC +)

! [{סמל הפרויקט} לא ניתן היה לטעון תמונה זו. זה יכול להיות בגלל שלא הגיע לקובץ או משגיאה כללית. טען מחדש את הדף כדי לתקן שגיאה כללית אפשרית.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# על ידי:

## [Seanpm2001] (https://github.com/seanpm2001) ותורמים אחרים

### חלק עליון

# `README.md`

***

## קרא מאמר זה בשפה אחרת

** השפה הנוכחית היא: ** `אנגלית (ארה"ב)` _ (יתכן שיהיה צורך לתקן תרגומים כדי לתקן אנגלית שתחליף את השפה הנכונה) _

_🌐 רשימת שפות_

** ממוינים לפי: ** `A-Z`

[אפשרויות המיון אינן זמינות] (https://github.com/Degoogle-your-Life)

([Af אפריקאנס] (/ GitHub / README_AF.md) אפריקאנס |. [ר Shqiptare] (/ GitHub / README_SQ.md) אלבנית |.. [בבוקר አማርኛ] (/ GitHub / README_AM.md) אמהרית | [ar عربى] (/.github/README_AR.md) ערבית | [hy հայերեն] (/. github / README_HY.md) ארמנית | [az Azərbaycan dili] (/. github / README_AZ.md) אזרבייג'נית | [eu Euskara] (/. github /README_EU.md) באסקית | [be Беларуская] (/. Github / README_BE.md) בלארוסית | [bn বাংলা] (/. Github / README_BN.md) בנגלית | [bs Bosanski] (/. Github / README_BS.md) בוסנית | [bg български] (/. Github / README_BG.md) בולגרית | [ca Català] (/. Github / README_CA.md) קטלאנית | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) סינית (פשוטה) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) סינית (מסורתית) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) קרואטית | [cs čeština] (/. Github / README_CS .md) צ'כית | [da dansk] (README_DA.md) דנית | [nl Nederlands] (/. github / README_ NL.md) הולנדית | [** en-us אנגלית **] (/. github / README.md) אנגלית | [EO אספרנטו] (/. Github / README_EO.md) אספרנטו | [et Eestlane] (/. github / README_ET.md) אסטונית | [tl פיליפינית] (/. github / README_TL.md) פיליפינית | [fi Suomalainen] (/. github / README_FI.md) פינית | [fr français] (/. github / README_FR.md) צרפתית | [fy English] (/. github / README_FY.md) פריזית | [gl Galego] (/. github / README_GL.md) גליציאנית | [ka ქართველი] (/. github / README_KA) גרוזיני | [de Deutsch] (/. github / README_DE.md) גרמנית | [el Ελληνικά] (/. github / README_EL.md) יוונית | [gu ગુજરાતી] (/. github / README_GU.md) גוג'ראטי | [ht Kreyòl ayisyen] (/. github / README_HT.md) קריאולית האיטי | [הא האוזה] (/. github / README_HA.md) האוסה | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) הוואי | [he עִברִית] (/. github / README_HE.md) עברית | [היי हिन्दी] (/. github / README_HI.md) הינדית | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) הונגרית | [is Íslenska] (/. github / README_IS.md) איסלנדית | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) איסלנדית | [ga Gaeilge] (/. github / README_GA.md) אירית | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) יפנית | [jw Wong jawa] (/. github / README_JW.md) ג'וואנית | [kn ಕನ್ನಡ] (/. github / README_KN.md) קנדה | [kk Қазақ] (/. github / README_KK.md) קזחית | [ק"מ ខ្មែរ] (/. github / README_KM.md) חמר | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) קוריאנית (דרום) | [ko-north 문화어] (README_KO_NORTH.md) קוריאנית (צפון) (עדיין לא תורגם) | [ku Kurdî] (/. github / README_KU.md) כורדית (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) קירגיזים | [lo ລາວ] (/. github / README_LO.md) לאו | [la Latine] (/. github / README_LA.md) לטינית | [lt Lietuvis] (/. github / README_LT.md) ליטאי | [lb Lëtzebuergesch] (/. github / README_LB.md) לוקסמבורגית | [mk Македонски] (/. github / README_MK.md) מקדונית | [מ"ג מלגית] (/. github / README_MG.md) מלגית | [ms Bahasa Melayu] (/. github / README_MS.md) מלאית | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) מלטזית | [mi Maori] (/. github / README_MI.md) מאורי | [mr मराठी] (/. github / README_MR.md) מארתי | [mn Монгол] (/. github / README_MN.md) מונגולית | [my မြန်မာ] (/. github / README_MY.md) מיאנמר (בורמזית) | [ne नेपाली] (/. github / README_NE.md) נפאלית | [no norsk] (/. github / README_NO.md) נורווגית | [או ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) אודיה (אוריה) | [PS پښتو] (/ GitHub / README_PS.md.) פשטו | [Fa فارسی] (/ GitHub / README_FA.md.) | הפרסי [pl polski] (/ GitHub / README_PL.md.) פולנית | [pt português] (/. github / README_PT.md) פורטוגזית | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) פונג'אבי | אין שפות זמינות שמתחילות באות Q | [ro Română] (/. github / README_RO.md) רומנית | [ru русский] (/. github / README_RU.md) רוסית | [sm Faasamoa] (/. github / README_SM.md) סמואן | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) סקוטית גאלית | [sr Српски] (/. github / README_SR.md) סרבית | [סזוטו הקדוש] (/. github / README_ST.md) סזוטו | [sn Shona] (/. github / README_SN.md) Shona | [Sd سنڌي] (/ GitHub / README_SD.md.) הסינדהית | [si සිංහල] (/. github / README_SI.md) סינהלה | [sk Slovák] (/. github / README_SK.md) סלובקית | [sl Slovenščina] (/. github / README_SL.md) סלובנית | [so Soomaali] (/. github / README_SO.md) סומלית | [[es en español] (/. github / README_ES.md) ספרדית | [su Sundanis] (/. github / README_SU.md) Suנדאני | [sw Kiswahili] (/. github / README_SW.md) סוואהילי | [sv Svenska] (/. github / README_SV.md) שוודית | [tg Тоҷикӣ] (/. github / README_TG.md) טג'יקית | [ta தமிழ்] (/. github / README_TA.md) טמילית | [tt Татар] (/. github / README_TT.md) טטרית | [te తెలుగు] (/. github / README_TE.md) טלוגו | [th ไทย] (/. github / README_TH.md) תאילנדי | [tr Türk] (/. github / README_TR.md) טורקית | [tk Türkmenler] (/. github / README_TK.md) טורקמני | [בריטניה Український] (/. github / README_UK.md) אוקראינית | [Ur اردو] (/ GitHub / README_UR.md.) אורדו | [UG ئۇيغۇر] (/ GitHub / README_UG.md.) אויגורים | [uz O'zbek] (/. github / README_UZ.md) אוזבקית | [vi Tiếng Việt] (/. github / README_VI.md) וייטנאמית | [cy Cymraeg] (/. github / README_CY.md) וולשית | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [יי יידיש] (/. github / README_YI.md) יידיש | [יו יורובה] (/. github / README_YO.md) יורובה | [zu זולו] (/. github / README_ZU.md) זולו) זמין ב -110 שפות (108 כאשר לא סופרים אנגלית וצפון קוריאנית, מכיוון שעדיין לא תורגמה צפון קוריאנית [קרא על זה כאן] (/ OldVersions / Korean (North ) / README.md))

תרגומים בשפות שאינן אנגלית מתורגמים במכונה ואינם מדויקים עדיין. עדיין לא תוקנו שגיאות החל מה -5 בפברואר 2021. אנא דווח על שגיאות תרגום [כאן] (https://github.com/seanpm2001/CamCamPlus/issues/) דאג לגבות את התיקון שלך במקורות ולהנחות אותי, מכיוון שאינני עושה זאת אינך יודע היטב שפות שאינן אנגלית (אני מתכוון להשיג מתרגם בסופו של דבר) אנא ציטט את [ויקימילון] (https://en.wiktionary.org) ומקורות אחרים בדו"ח שלך. כישלון בכך יביא לדחיית התיקון לפרסום.

הערה: עקב מגבלות הפרשנות של GitHub ל Markdown (וכמעט כל פרשנות אחרת מבוססת רשת של Markdown) לחיצה על קישורים אלה תפנה אותך לקובץ נפרד בעמוד נפרד שאינו עמוד הפרופיל שלי ב- GitHub. תועבר למאגר [seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), שם מתארח ה- README.

התרגומים נעשים עם Google Translate בגלל תמיכה מוגבלת או ללא תמיכה בשפות שאני זקוק לשירותי תרגום אחרים כמו DeepL ו- Bing Translate. אני עובד על מציאת חלופה. משום מה, העיצוב (קישורים, מחיצות, מודגש, נטוי וכו ') מבולגן בתרגומים שונים. זה מייגע לתקן, ואני לא יודע איך לתקן את הבעיות האלה בשפות עם תווים לא לטיניים, ושפות מימין לשמאל (כמו ערבית) נדרשות עזרה נוספת בתיקון הבעיות

עקב בעיות תחזוקה, תרגומים רבים אינם מעודכנים ומשתמשים בגרסה מיושנת של קובץ המאמרים `README 'זה. יש צורך במתרגם. כמו כן, החל מה- 22 באפריל 2021, ייקח לי זמן עד שכל הקישורים החדשים יעבדו.

***

# אינדקס

[00.0 - למעלה] (# למעלה)

> [00.1 - כותרת] (# CamCamPlus)

> [00.2 - קרא מאמר זה בשפה אחרת] (# קרא-מאמר זה-בשפה אחרת)

> [00.3 - אינדקס] (אינדקס #)

[01.0 - תיאור] (# CamCamPlus)

[02.0 - אודות] (# אודות)

[03.0 - Wiki] (Wiki #)

[04.0 - היסטוריית גרסאות] (היסטוריית גרסאות #)

[05.0 - מצב תוכנה] (# מצב-תוכנה)

[06.0 - מידע על נותני חסות] (מידע על נותני חסות)

[07.0 - תורמים] (# תורמים)

[08.0 - גליונות] (# גליונות)

> [08.1 - גיליונות אקטואליים] (# גיליונות שוטפים)

> [08.2 - גליונות עבר] (# גליונות עבר)

> [08.3 - בקשות משיכה בעבר] (# בקשות משיכה בעבר)

> [08.4 - בקשות משיכה פעילה] (# בקשות משיכה פעילה)

[09.0 - משאבים] (# משאבים)

[10.0 - תורם] (# תורם)

[11.0 - אודות README] (# About-README)

[12.0 - היסטוריית גרסאות של README] (# היסטוריה של גירסאות README)

[13.0 - כותרת תחתונה] (# הגעת לסוף הקובץ README)

> [13.1 - סוף הקובץ] (# EOF)

***

# CamCamPlus
CamCamPlus היא מצלמת קוד פתוח וחינמית מתקדמת שיכולה לצלם תמונות וסרטונים בפורמטים רבים ובהחלטות רבות.

***

## על אודות

ראה לעיל. פרויקט זה עוסק במצלמה חזקה בקוד פתוח הנותנת אפשרויות רבות ומפרקת חסמים שיש לאפליקציות מצלמה נפוצות אחרות (כגון מגבלת ההקלטה של ​​30 דקות).

***

## ויקי

[לחץ / הקש כאן לצפייה בפרויקטים Wiki] (https://github.com/seanpm2001/CamCamPlus/wiki)

אם הפרויקט הועבר למזלג, סביר להניח שהוויקי הוסר. למרבה המזל, אני כולל גרסה משובצת. תוכלו לצפות בו [כאן] (/ External / ProjectWiki /).

***

## מידע על נותני חסות

! [SponsorButton.png] (SponsorButton.png)

אתה יכול לתת חסות לפרויקט זה אם תרצה, אך אנא ציין למה אתה רוצה לתרום. [ראה את הכספים שתוכל לתרום להם כאן] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

תוכלו להציג מידע נוסף על נותני חסות [כאן] (https://github.com/seanpm2001/Sponsor-info/)

נסה את זה! כפתור החסות נמצא ממש ליד כפתור השעון / ביטול הצפייה.

***

## היסטוריית גרסאות

** היסטוריית הגרסאות אינה זמינה כרגע **

** אין גרסאות אחרות ברשימה **

***

## מצב תוכנה

כל העבודות שלי הן ללא הגבלות. DRM (** D ** igital ** R ** estrictions ** M ** anagement) אינו קיים באף אחת מהעבודות שלי.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

מדבקה זו נתמכת על ידי ה- Freקרן תוכנה. אני אף פעם לא מתכוון לכלול DRM בעבודות שלי.

אני משתמש בקיצור "ניהול הגבלות דיגיטליות" במקום "ניהול זכויות דיגיטליות" הידוע יותר כדרך הנפוצה להתייחס אליו כוזבת, אין זכויות על DRM. האיות "ניהול הגבלות דיגיטליות" מדויק יותר, והוא נתמך על ידי [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) ו- [Foundation Free Software (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

חלק זה משמש להעלאת המודעות לבעיות ב- DRM, וגם להפגנה עליו. DRM לקוי מבחינה עיצובית ומהווה איום גדול על כל משתמשי המחשב ועל חופש התוכנה.

קרדיט תמונה: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## תורמים

נכון לעכשיו, אני התורם היחיד. מותר לתרום, כל עוד אתה מקיים את כללי הקובץ [CONTRIBUTING.md] (CONTRIBUTING.md).

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 התחייבות (החל מיום חמישי, 22 באפריל 2021 בשעה 18:30)

> * 2. אין תורמים אחרים.

***

## נושאים

### הבעיות הנוכחיות

* אף אחד כרגע

* אין נושאים שוטפים אחרים

אם המאגר הועבר למזלג, סביר להניח שהבעיות הוסרו. למזלי אני שומר ארכיון של תמונות מסוימות [כאן] (/. Github / Issues /)

[קרא את מדיניות הפרטיות בנושא ארכיון הבעיות כאן] (/. Github / Issues / README.md)

** TL; DR **

אני ארכיון את הגיליונות שלי. הבעיה שלך לא תועבר לארכיון אלא אם תבקש להעביר אותה לארכיון.

### גליונות עבר

* אף אחד כרגע

* אין גליונות עבר אחרים

אם המאגר הועבר למזלג, סביר להניח שהבעיות הוסרו. למזלי אני שומר ארכיון של תמונות מסוימות [כאן] (/. Github / Issues /)

[קרא את מדיניות הפרטיות בנושא ארכיון הבעיות כאן] (/. Github / Issues / README.md)

** TL; DR **

אני ארכיון את הגיליונות שלי. הבעיה שלך לא תועבר לארכיון אלא אם תבקש להעביר אותה לארכיון.

### בקשות משיכה בעבר

* אף אחד כרגע

* אין בקשות משיכה אחרות בעבר

אם המאגר הועבר למזלג, סביר להניח שהבעיות הוסרו. למזלי אני שומר ארכיון של תמונות מסוימות [כאן] (/. Github / Issues /)

[קרא את מדיניות הפרטיות בנושא ארכיון הבעיות כאן] (/. Github / Issues / README.md)

** TL; DR **

אני ארכיון את הגיליונות שלי. הבעיה שלך לא תועבר לארכיון אלא אם תבקש להעביר אותה לארכיון.

### בקשות משיכה פעילה

* אף אחד כרגע

* אין בקשות משיכה אקטיביות אחרות

אם המאגר הועבר למזלג, סביר להניח שהבעיות הוסרו. למזלי אני שומר ארכיון של תמונות מסוימות [כאן] (/. Github / Issues /)

[קרא את מדיניות הפרטיות בנושא ארכיון הבעיות כאן] (/. Github / Issues / README.md)

** TL; DR **

אני ארכיון את הגיליונות שלי. הבעיה שלך לא תועבר לארכיון אלא אם תבקש להעביר אותה לארכיון.

***

## משאבים

להלן כמה משאבים נוספים לפרויקט זה:

[קובץ שפת פרויקט] (PROJECT_LANG.cpp)

[ספריית עזר למחקר עבור פרויקט זה] (/ הפניות /)

[מודול הווידאו המיוחד לפרויקט זה (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[הצטרף לדיון ב- GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

אין משאבים אחרים כרגע.

***

## תורם

מותר לתרום לפרויקט זה, כל עוד אתה מקיים את כללי הקובץ 'CONTRIBUTING.md'.

[לחץ / הקש כאן כדי להציג את הכללים התורמים לפרויקט זה] (CONTRIBUTING.md)

***

## על README

סוג קובץ: "Markdown (* .md)"

גרסת הקובץ: "1 (יום חמישי, 22 באפריל 2021 בשעה 18:30)"

ספירת קווים: `0,306`

***

## היסטוריית גרסאות של README

גרסה 1 (יום חמישי, 22 באפריל 2021 בשעה 18:30)

> שינויים:

> * התחיל את הקובץ

> * הוסיף את קטע הכותרת

> * נוסף האינדקס

> * הוסיף את החלק אודות

> * הוסיף את קטע הוויקי

> * נוסף החלק של היסטוריית הגרסאות

> * הוסיף את קטע הבעיות.

> * הוסיף את חלק הגיליונות הקודמים

> * הוסיף את החלק הקודם של בקשות משיכה

> * נוסף החלק של בקשות המשיכה הפעילות

> * הוסיף את החלק התורמים

> * הוסיף את החלק התורם

> * הוסיף את החלק README בערך

> * נוסף החלק של היסטוריית הגרסאות של README

> * הוסיף את מקטע המשאבים

> * נוסף קטע סטטוס תוכנה, עם מדבקה והודעה ללא DRM

> * הוסיף את קטע פרטי החסות

> * אין שינויים אחרים בגרסה 1

גרסה 2 (בקרוב)

> שינויים:

> * בקרוב

> * אין שינויים אחרים בגרסה 2

***

### הגעת לסוף קובץ README

[חזרה למעלה] (# למעלה) [יציאה] (https://github.com)

### EOF

***
