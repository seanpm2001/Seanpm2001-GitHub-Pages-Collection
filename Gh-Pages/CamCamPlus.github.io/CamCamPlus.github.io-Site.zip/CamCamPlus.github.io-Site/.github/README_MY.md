***

# Cam Cam Plus (CC +)

!!! ၎င်းသည်ဖိုင်ကိုမရောက်ရှိခြင်းသို့မဟုတ်အထွေထွေအမှားကြောင့်ဖြစ်နိုင်သည်။ ဖြစ်နိုင်ချေရှိသောအထွေထွေအမှားကိုပြင်ဆင်ရန်စာမျက်နှာကိုပြန်တင်ပါ။ ] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# မှ:

## [Seanpm2001] (https://github.com/seanpm2001) နှင့်အခြားပံ့ပိုးသူများ

### ထိပ်တန်း

# `README.md`

***

## ဤဆောင်းပါးအားအခြားဘာသာစကားဖြင့်ဖတ်ပါ

** လက်ရှိဘာသာစကားမှာ - ** `အင်္ဂလိပ် (ယူအက်စ်)` `(အင်္ဂလိပ်သည်မှန်ကန်သောဘာသာစကားနေရာတွင်အစားထိုးပြင်ဆင်ရန်ဘာသာပြန်ချက်များကိုပြုပြင်ရန်လိုအပ်နိုင်သည်) _

_🌐ဘာသာစကားစာရင်း။

** ဖြင့်ခွဲခြားထားသည်။ ** `A-Z`

[ရွေးစရာများကိုမရရှိနိုင်ပါ။ ] (https://github.com/Degoogle-your-Life)

([Afrikaans Afrikaans] (/ github / README_AF.md) အာဖရိကန် | [sqq Shqiptare] (/ github / README_SQ.md) အယျလျဘေးနီးယား | [am አማርኛ] (/ ။ github / README_AM.md) အမ်ဟာရစ် | [ar عربى] (/.github/README_AR.md) အာရပ်ဘာသာစကား | [hy հայերեն] (/ ။ github / README_HY.md) အာမေးနီးယား | [az Azərbaycan dili] (/ ။ github / README_AZ.md) အဇာဘိုင်ဂျန် | [EU euskara] (/ ။ github) /README_EU.md) ဘစ်စကီ | [be Беларуская] (/ ။ github / README_BE.md) ဘီလာရုစ် | [ဘီလီယံ (] (/ ။ github / README_BN.md) ဘင်္ဂါလီ | [bs Bosanski] (/ ။ github / README_BS.md) ဘော့စျနီးယား | [bg български] (/ ။ github / README_BG.md) ဘူဂေးရီးယား | [ca Català] (/ ။ github / README_CA.md) ကက်တလန် | [ceb Sugbuanon] (/ ။ github / README_CEB.md) Cebuano | [ny Chichewa | ] (။ ။ github / README_NY.md) Chichewa | [zh-CN 简体中文] (/ github / README_ZH-CN.md) တရုတ် (ရိုးရှင်း) | [zh-t 中國傳統的）] (/ ။ github / README_ZH) -T.md) တရုတ် (ရိုးရာ) | [co Corsu] (/ github / README_CO.md) Corsican | [hr Hrvatski] (/ ။ github / README_HR.md) ခရိုအေရှန် | [cs čeština] (/ ။ github / README_CS) .md) ချက် ([da dansk] (README_DA.md) ဒိန်းမတ် | [nl Nederlands] (/ github / README_ NL.md) ဒတ်ခ်ျ | [** en-us English **] (/ ။ github / README.md) အင်္ဂလိပ် | [EO Esperanto] (/ ။ github / README_EO.md) အက်စပရန်တို | [et Eestlane] (/ github / README_ET.md) အက်စ်တိုးနီးယား | [ဖိလစ်ပိုင် tl] (/ ။ github / README_TL.md) ဖိလစ်ပိုင် | [fi Suomalainen] (/ ။ github / README_FI.md) ဖင်လန် | [fr français] (။ ။ github / README_FR.md) ပြင်သစ် [fy Frysk] (/ ။ github / README_FY.md) Frisian | [gl Galego] (/ github / README_GL.md) Galician | [ka ქართველი] (/ ။ github / README_KA) ဂျော်ဂျီယာ | [က de Deutsch] (။ ။ github / README_DE.md) ဂျာမန်။ [el Ελληνικά] (/ ။ github / README_EL.md) ဂရိ | [gu ગુજરાતી] (/ ။ github / README_GU.md) ဂူဂျာရီးယား | [ht Kreyòl ayisyen] (/ ။ github / README_HT.md) Haitian Creole | [ha Hausa] (။ ။ github / README_HA.md) ဟာဟာစာ | [haw Ōlelo Hawaiʻi] (/ ။ github / README_HAW.md) ဟာဝယေံ | [သူעִברִית] (/ ။ github / README_HE.md) ဟီဘရူး | [hi हिन्दी] (/ ။ github / README_HI.md) ဟိန္ဒူ | [hmn Hmong] (။ ။ github / README_HMN.md) Hmong | [hu Magyar] (/ ။ github / README_HU.md) ဟနျဂရေီ | (/ lslenska) သည် (/ github / README_IS.md) အိုက်စလန်ဖြစ်သည် [Igbo ig] (/ ။ github / README_IG.md) အစ်ဂဘို | [id bahasa Indonesia] (/ ။ github / README_ID.md) အိုက်စလန် | [ga Gaeilge] (/ ။ github / README_GA.md) အိုငျးရစျ | [it Italiana / Italiano] (။ ။ github / README_IT.md) | [ja 日本語] (/ github / README_JA.md) ဂျပန်။ [jw Wong Jawa] (/ ။ github / README_JW.md) ဂျာဗားနီးယား | [kn ಕನ್ನಡ] ကန်နာဒါ။ (/ ။ github / README_KN.md) | [kk Қазақ] (/ ။ github / README_KK.md) Kazakh | [km ខ្មែរ] Khmer / | github / README_KM.md) ခမာ | [rw Kinyarwanda] (/ ။ github / README_RW.md) Kinyarwanda | [ko-south 韓國語] (/ ။ github / README_KO_SOUTH.md) ကိုရီးယား (တောင်ပိုင်း) | [ko-north 문화어] (README_KO_NORTH.md) ကိုရီးယား (မြောက်ပိုင်း) (ဘာသာပြန်ခြင်းမရှိ) | [ku Kurdî] (/ ။ github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/ ။ github / README_KY.md) ခရူဂ | [lo ລາວ] (/ github / README_LO.md) လာအို။ [la လက်တင်] (။ ။ github / README_LA.md) လက်တင် | [ဒု Lietuvis] (။ / github / README_LT.md) လစ်သူယေးနီးယား [lb Lëtzebuergesch] (/ ။ github / README_LB.md) လူဇင်ဘတ် | [mk Македонски] (/ ။ github / README_MK.md) Macedonian | [mg mg Malagasy] (/ ။ github / README_MG.md) အာလာဂါစီ | [ms Bahasa Melayu] (/ ။ github / README_MS.md) မလေး | [ml ml] (/ github / README_ML.md) မလေးရာလ | [mt Malti] (/ ။ github / README_MT.md) Maltese | [မိုင်ရီ] (/ ။ github / README_MI.md) Maori | [mr मराठी] (/ ။ github / README_MR.md) မာရသီ | [mn Монгол] (/ ။ github / README_MN.md) မွန်ဂို | [my မြန်မာ] (/ ။ github / README_MY.md) မြန်မာ (မြန်မာ) | [ne नेपाली] (/ ။ github / README_NE.md) နီပေါ [no norsk] (/ github / README_NO.md) နော်ဝေ | [or ଓଡିଆ (ଓଡିଆ)] (/ ။ github / README_OR.md) Odia (Oriya) | [ps پښتو] (/ ။ github / README_PS.md) ပါရှ်တို | [fa فارسی] (/ ။ github / README_FA.md) | ပါရှန်း [pl polski] (/ ။ github / README_PL.md) ပိုလန် | [pt português] (/ github / README_PT.md) ပေါ်တူဂီ | [pa ਪੰਜਾਬੀ] (/ ။ github / README_PA.md) ပနျဂြာ | Q | အက္ခရာနှင့်စတင်သောဘာသာစကားများမရှိပါ [ro Română] (/ ။ github / README_RO.md) ရိုမေးနီးယား | [ru русский] (/ ။ github / README_RU.md) ရုရှား | [sm Faasamoa] (။ ။ github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/ ။ github / README_GD.md) စကော့ [sr Српски] (/ ။ github / README_SR.md) ဆားဗီးယား | [st Sesotho] (။ ။ github / README_ST.md) Sesotho | [SN Shona] (။ ။ github / README_SN.md) Shona | [sd سنڌي] (/ ။ github / README_SD.md) စင်ဒီ | [si සිංහල] (/ ။ github / README_SI.md) ဆငျဟာလ | [sk Slovák] (/ ။ github / README_SK.md) စလိုဗက် | [sl Slovenščina] (/ ။ github / README_SL.md) ဆလိုဗေးနီးယား | [ဒါ Soomaali] (/ ။ github / README_SO.md) ဆိုမာလီ | [[es en español] စပိန် | / / github / README_ES.md) [su Sundanis] (/ ။ github / README_SU.md) Sundanese | [sw Kiswahili] (/ ။ github / README_SW.md) ဆွာဟီလီ | [sv Svenska] ဆွီဒင် (/ github / README_SV.md) ။ [tg Тоҷикӣ] (/ ။ github / README_TG.md) Tajik | [ta தமிழ்] (/ github / README_TA.md) တမီး | [tt Татар] (/ ။ github / README_TT.md) Tatar | [te తెలుగు] (/ ။ github / README_TE.md) တီလူ [ကြိမ်မြောက် Thai] (/ github / README_TH.md) ထိုင်း | [TR တူရကီ] (/ ။ github / README_TR.md) တူရကီ | [tk Türkmenler] (/ ။ github / README_TK.md) Turkmen | [uk Український] (/ ။ github / README_UK.md) ယူကရိန်း | [ur اردو] (/ ။ github / README_UR.md) အူဒူ | [ug ئۇيغۇر] (/ ။ github / README_UG.md) ဥဂါးရ် | [uz O'zbek] (/ ။ github / README_UZ.md) Uzbek | [vi TiếngViệt] (/ ။ github / README_VI.md) ဗီယက်နမ် | [cy Cymraeg] (/ ။ github / README_CY.md) ဝလေ | [။ xh isiXhosa] (/ github / README_XH.md ။ ) Xhosa | [yi יידיש] (/ ။ github / README_YI.md) Yiddish | [yo Yoruba] (/ ။ github / README_YO.md) ရိုရုဘာ | [zu Zulu] (/ ။ github / README_ZU.md) ဇူလူ) ဘာသာစကား ၁၁၀ ဖြင့်ရနိုင်သည်။ (မြောက်ကိုရီးယားကိုမပြန်ရသေးသောကြောင့်၊ 108 နှင့်အင်္ဂလိပ်နှင့်မြောက်ကိုရီးယားတို့ကိုရေတွက်။ မရပါ။ [Old ဤနေရာတွင်ဖတ်ပါ] (OldVersions / Korean (North) ) /README.md))

အင်္ဂလိပ် မှလွဲ၍ အခြားဘာသာဖြင့်ဘာသာပြန်ထားသောစက်များသည်စက်ဖြင့်ပြန်ဆိုထားသောကြောင့်တိကျမှုမရှိသေးပါ။ ၂၀၂၁ ခုနှစ်ဖေဖော်ဝါရီ ၅ ရက်အထိအမှားများကိုမဖြေရှင်းနိုင်ပါ။ ကျေးဇူးပြု၍ ဘာသာပြန်အမှားများကိုဤနေရာတွင်အစီရင်ခံပါ (https://github.com/seanpm2001/CamCamPlus/issues/) သည်သင်၏အမှားကိုရင်းမြစ်များနှင့်အရန်ကူးယူပြီးသေချာအောင်ပြုလုပ်ပါ။ အင်္ဂလိပ်စာမဟုတ်သောအခြားဘာသာစကားများကိုသိရှိပါသလား (နောက်ဆုံးတွင်ဘာသာပြန်ဆိုရန်ကျွန်ုပ်စီစဉ်ထားသည်) ကျေးဇူးပြု၍ [wiktionary] (https://en.wiktionary.org) နှင့်သင်၏အစီရင်ခံစာတွင်အခြားရင်းမြစ်များကိုကိုးကားပါ။ ယင်းသို့ပြုလုပ်ရန်ပျက်ကွက်ပါကပြင်ဆင်ခြင်းကိုပယ်ချလိမ့်မည်။

မှတ်ချက် - GitHub ရဲ့ markdown အဓိပ္ပာယ်ဖွင့်ဆိုချက်နှင့် (နှင့်အခြား web-based markdown ၏တော်တော်များများ) ကန့်သတ်ချက်များကြောင့်ဒီလင့်ခ်များကိုနှိပ်ခြင်းအားဖြင့်သင့် GitHub ပရိုဖိုင်စာမျက်နှာမဟုတ်သောသီးခြားစာမျက်နှာတစ်ခုသို့သီးခြားဖိုင်တစ်ခုဆီသို့လမ်းကြောင်းပြောင်းလိမ့်မည်။ README တည်နေရာရှိ [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001) သို့သင့်အားသင်လမ်းကြောင်းပြောင်းလိမ့်မည်။

DeepL နှင့် Bing Translate ကဲ့သို့သောအခြားဘာသာပြန်ဝန်ဆောင်မှုများတွင်ကျွန်ုပ်လိုအပ်သောဘာသာစကားအတွက်အကန့်အသတ်သာရှိခြင်းသို့မဟုတ်မရှိခြင်းကြောင့်ဘာသာပြန်များကို Google Translate ဖြင့်ပြုလုပ်သည်။ ငါကအခြားရွေးချယ်စရာရှာဖွေတာအပေါ်အလုပ်လုပ်ကိုင်နေပါတယ်။ အကြောင်းပြချက်အချို့အတွက် (link များ၊ dividers, bolding, စာလုံးစောင်းစသည်ဖြင့်) ကိုပုံစံအမျိုးမျိုးဖြင့်ဘာသာပြန်ထားသောဘာသာပြန်များတွင်ရှုပ်ထွေးနေသည်။ ဒါကိုပြင်ဖို့အရမ်းပင်ပန်းတယ်၊ ဒီပြissuesနာတွေကိုလက်တင်မဟုတ်တဲ့အက္ခရာတွေနဲ့ဘာသာစကားနဲ့ဘယ်လိုဖြေရှင်းရမှန်းကျွန်တော်မသိဘူး၊ ဒီပြissuesနာတွေကိုပြုပြင်ရာမှာဘယ်လက် (ဘယ်) (ဘယ်လို) လက်ဝဲဘာသာစကားတွေလိုအပ်တယ်။

ပြုပြင်ထိန်းသိမ်းမှုဆိုင်ရာပြissuesနာများကြောင့်ဘာသာပြန်များစွာသည်ခေတ်နောက်ကျနေသောဤ README ဆောင်းပါးဖိုင်၏ခေတ်မမီတော့သောဗားရှင်းကိုအသုံးပြုနေကြသည်။ ဘာသာပြန်တစ် ဦး လိုအပ်သည် ဒါ့အပြင် ၂၀၂၁ ခုနှစ်22ပြီလ ၂၂ ရက်နေ့မှာအချိတ်အဆက်အသစ်တွေအားလုံးအလုပ်လုပ်ဖို့ကျွန်တော့်ကိုခဏလောက်သွားခိုင်းလိမ့်မယ်။

***

# အညွှန်းကိန်း

[00.0 - အပေါ်ဆုံး] (# ထိပ်)

> [00.1 - Title] (# CamCamPlus)

> [00.2 - ဤဆောင်းပါးအားအခြားဘာသာစကားဖြင့်ဖတ်ပါ] (# Read-this-article-in-a-different-language)

> [00.3 - အညွှန်းကိန်း] (# အညွှန်းကိန်း)

[01.0 - ဖော်ပြချက်] (# CamCamPlus)

[၂.၀ - အကြောင်း] (# အကြောင်း)

[03.0 - Wiki] (# Wiki)

[၄.၀ - ဗားရှင်းသမိုင်း] (# ဗားရှင်း - သမိုင်း)

[05.0 - Software အခြေအနေ] (# Software-status)

[06.0 - ပံ့ပိုးသူအချက်အလက်] (# စပွန်ဆာ-info)

[07.0 - ပံ့ပိုးသူများ] (# မျှဝေသူများ)

[08.0 - ကိစ္စများ] (# ကိစ္စများ)

> [08.1 - လက်ရှိပြissuesနာများ] (# လက်ရှိ - ပြissuesနာများ)

> [08.2 - အတိတ်အရေးကိစ္စများ] (# အတိတ်အရေးကိစ္စများ)

> [08.3 - အတိတ်ဆွဲထုတ်ရန်တောင်းဆိုမှုများ] (# အတိတ် - ဆွဲခြင်းတောင်းဆိုမှုများ)

> [08.4 - တက်ကြွစွာဆွဲဆောင်ရန်တောင်းဆိုမှုများ] (# Active-pull-requests)

[09.0 - အရင်းအမြစ်များ] (# အရင်းအမြစ်များ)

[၁၀.၀ ပံ့ပိုးမှု] (# ပံ့ပိုးသည်)

[၁၁.၀ - README အကြောင်း] (# အကြောင်း - ဖတ်ရန်)

[၁၂.၀ - README ဗားရှင်းသမိုင်း] (# README-version-history)

[၁၃.၀ - အောက်ခြေမှတ်ချက်] (# သင် - ရောက်ရှိနေပြီ - နောက်ဆုံးအဆင့် - ဖတ်ရန်ဖိုင်)

> [13.1 - ဖိုင်၏အဆုံး] (# EOF)

***

# CamCamPlus
CamCamPlus သည်အဆင့်မြင့်အခမဲ့နှင့်ပွင့်လင်းသောအရင်းအမြစ်ကင်မရာဖြစ်ပြီးရုပ်ပုံများနှင့်ဗွီဒီယိုများကိုပုံစံအမျိုးမျိုးနှင့်ရိုက်ကူးနိုင်သည်။

***

## အကြောင်း

အပေါ်ကြည့်ပါ။ ဤစီမံကိန်းသည်အရင်းအမြစ်အမြောက်အမြား ပေး၍၊ အခြားသာမန်ကင်မရာအက်ပ်များ (မိနစ် ၃၀ မှတ်တမ်းတင်ခြင်းကန့်သတ်ချက်) ရှိသည့်အတားအဆီးများကိုဖြိုဖျက်သောပွင့်လင်းသောအရင်းအမြစ်စွမ်းအားရှိသောကင်မရာအကြောင်းဖြစ်သည်။

***

## ဝီကီ

[ဤဝီကီစီမံကိန်းများကိုကြည့်ရှုရန်ဒီနေရာကိုနှိပ်ပါ / နှိပ်ပါ] (https://github.com/seanpm2001/CamCamPlus/wiki)

အကယ်၍ စီမံကိန်းကိုဖော်ထုတ်ပြီးပါကဝီကီအားဖယ်ရှားပစ်ဖွယ်ရှိသည်။ ကံကောင်းတာကငါ၌ embedded ဗားရှင်းပါဝင်သည်။ သင်ဒီမှာကြည့်နိုင်သည် (/ External / ProjectWiki /)

***

## ထောက်ပံ့သူအချက်အလက်

! [SponsorButton.png] (SponsorButton.png)

သင်ဤစီမံကိန်းကိုသင်ကြိုက်နှစ်သက်ပါကကမကထပြုနိုင်သည်။ [ဤနေရာတွင်သင်လှူဒါန်းနိုင်သောရန်ပုံငွေများကိုကြည့်ပါ] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

အခြားစပွန်ဆာအချက်အလက် [ဒီမှာ] ကိုကြည့်နိုင်သည်။ (https://github.com/seanpm2001/Sponsor-info/)

စမ်းကြည့်ပါ ဦး ။ စပွန်ဆာခလုတ်သည်နာရီ / နာရီမဖွင့်သောခလုတ်၏ဘေးတွင်ရှိသည်။

***

## ဗားရှင်းသမိုင်း

** ဗားရှင်းသမိုင်းအားလက်ရှိမရနိုင်ပါ။

** အခြားမူကွဲစာရင်းမရှိပါ။

***

## ဆော့ဗ်ဝဲအခြေအနေ

ကျွန်ုပ်၏လုပ်ဆောင်မှုအားလုံးသည်အချို့သောကန့်သတ်ချက်များရှိသည်။ DRM (** D ** igital ** R ** estrictions ** M ** anagement) ကျွန်ုပ်၏လက်ရာများတွင်မရှိပါ။

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

ဒီစတစ်ကာကို Fre ကထောက်ခံသည်e Software Foundation ။ ငါသည်ငါ့အကျင့်ကိုကျင့်အတွက် DRM ထည့်သွင်းရန်ရည်ရွယ်ထားဘူး။

ငါကဒီဂျစ်တယ်အခွင့်အရေးစီမံခန့်ခွဲမှုအစားဒီဂျစ်တယ်ကန့်သတ်ချက်စီမံခန့်ခွဲမှုအတိုကောက်အက္ခရာကိုသုံးပြီးမှားယွင်းစွာကိုင်တွယ်ဖြေရှင်းတဲ့ဘုံနည်းလမ်းအဖြစ်အသုံးပြုနေပါတယ်။ DRM မှာအခွင့်အရေးမရှိဘူး။ "Digital Restrictions Management" စာလုံးပေါင်းသည်ပိုမိုတိကျပြီး၎င်းကို [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) နှင့် [Free Software Foundation (FSF)] မှထောက်ခံသည်။ https://en.wikipedia.org/wiki/Free_Software_Foundation)

ဤအပိုင်းကို DRM နှင့်ပြproblemsနာများအတွက်အသိပညာပေးရန်နှင့်၎င်းကိုကန့်ကွက်ရန်အသုံးပြုသည်။ DRM သည်ဒီဇိုင်းကြောင့်ချွတ်ယွင်း။ ကွန်ပျူတာအသုံးပြုသူများနှင့်ဆော့ဝဲလွတ်လပ်ခွင့်အတွက်အဓိကခြိမ်းခြောက်မှုတစ်ခုဖြစ်သည်။

image credit: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## အလှူရှင်များ

လောလောဆယ်ငါကသာပံ့ပိုးဖြစ်၏။ သငျသညျ [CONTRIBUTING.md] (CONTRIBUTING.md) ဖိုင်၏စည်းမျဉ်းစည်းကမ်းတွေကိုလိုက်နာနေသမျှကာလပတ်လုံး, အလှူငွေထည့်ဝင်ခွင့်ပြုသည်။

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - ၁၃၈ ကျူးလွန်ခြင်း (ကြာသပတေးနေ့၊ 21ပြီ ၂၂ ရက်၊ ၂၁၂၁ ခုနှစ်၊ ညနေ ၆ း ၃၀)

> * ၂ ။

***

## ပြIssနာများ

### လက်ရှိပြissuesနာများ

* ယခုအချိန်တွင်အဘယ်သူမျှမ

* အဘယ်သူမျှမကအခြားလက်ရှိကိစ္စများ

အကယ်၍ သိုလှောင်ရုံကိုဆန့်ကျင်လျှင်၊ ပြissuesနာများကိုဖယ်ရှားနိုင်သည်။ ကံကောင်းတာကကျွန်တော်ဒီမှာဓာတ်ပုံအချို့ကိုသိမ်းထားပါတယ် (/ ။ github / Issues /)

[ဤနေရာတွင်ပြarchနာ archivating အပေါ် privacy မူဝါဒကိုဖတ်ပါ] (/ ။ github / Issues / README.md)

** TL; DR **

ငါသည်ငါ့ကိုယ်ပိုင်ကိစ္စများ archive ။ သင့်၏မော်ကွန်းတင်ရန်မတောင်းဆိုပါကသင်၏ပြissueနာကိုသိမ်းဆည်းထားမည်မဟုတ်ပါ။

### အတိတ်ကိစ္စများ

* ယခုအချိန်တွင်အဘယ်သူမျှမ

* အခြားအတိတ်ပြissuesနာများ

အကယ်၍ သိုလှောင်ရုံကိုဆန့်ကျင်လျှင်၊ ပြissuesနာများကိုဖယ်ရှားနိုင်သည်။ ကံကောင်းတာကကျွန်တော်ဒီမှာဓာတ်ပုံအချို့ကိုသိမ်းထားပါတယ် (/ ။ github / Issues /)

[ဤနေရာတွင်ပြarchနာ archivating အပေါ် privacy မူဝါဒကိုဖတ်ပါ] (/ ။ github / Issues / README.md)

** TL; DR **

ငါသည်ငါ့ကိုယ်ပိုင်ကိစ္စများ archive ။ သင့်၏မော်ကွန်းတင်ရန်မတောင်းဆိုပါကသင်၏ပြissueနာကိုသိမ်းဆည်းထားမည်မဟုတ်ပါ။

### အတိတ်တောင်းဆိုမှုများဆွဲ

* ယခုအချိန်တွင်အဘယ်သူမျှမ

* အဘယ်သူမျှမကအခြားအတိတ်ဆွဲတောင်းဆိုမှုများ

အကယ်၍ သိုလှောင်ရုံကိုဆန့်ကျင်လျှင်၊ ပြissuesနာများကိုဖယ်ရှားနိုင်သည်။ ကံကောင်းတာကကျွန်တော်ဒီမှာဓာတ်ပုံအချို့ကိုသိမ်းထားပါတယ် (/ ။ github / Issues /)

[ဤနေရာတွင်ပြarchနာ archivating အပေါ် privacy မူဝါဒကိုဖတ်ပါ] (/ ။ github / Issues / README.md)

** TL; DR **

ငါသည်ငါ့ကိုယ်ပိုင်ကိစ္စများ archive ။ သင့်၏မော်ကွန်းတင်ရန်မတောင်းဆိုပါကသင်၏ပြissueနာကိုသိမ်းဆည်းထားမည်မဟုတ်ပါ။

### တက်ကြွဆွဲတောင်းဆိုမှုများ

* ယခုအချိန်တွင်အဘယ်သူမျှမ

* အဘယ်သူမျှမကအခြားတက်ကြွဆွဲတောင်းဆိုမှုများ

အကယ်၍ သိုလှောင်ရုံကိုဆန့်ကျင်လျှင်၊ ပြissuesနာများကိုဖယ်ရှားနိုင်သည်။ ကံကောင်းတာကကျွန်တော်ဒီမှာဓာတ်ပုံအချို့ကိုသိမ်းထားပါတယ် (/ ။ github / Issues /)

[ဤနေရာတွင်ပြarchနာ archivating အပေါ် privacy မူဝါဒကိုဖတ်ပါ] (/ ။ github / Issues / README.md)

** TL; DR **

ငါသည်ငါ့ကိုယ်ပိုင်ကိစ္စများ archive ။ သင့်၏မော်ကွန်းတင်ရန်မတောင်းဆိုပါကသင်၏ပြissueနာကိုသိမ်းဆည်းထားမည်မဟုတ်ပါ။

***

## အရင်းအမြစ်များ

ဤစီမံကိန်းအတွက်အခြားအရင်းအမြစ်များကိုဒီမှာဖော်ပြထားသည်။

[စီမံကိန်းဘာသာစကားဖိုင်] (PROJECT_LANG.cpp)

[ဤစီမံကိန်းအတွက်သုတေသနရည်ညွှန်းစာကြည့်တိုက်] (/ ကိုးကား /)

[ဤစီမံကိန်းအတွက်အထူးဗီဒီယိုအပိုင်း (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[GitHub အပေါ်ဆွေးနွေးမှုကိုဆက်သွယ်ပါ] (https://github.com/seanpm2001/CamCamPlus/discussions)

ယခုအချိန်တွင်အခြားအရင်းအမြစ်များမရှိပါ။

***

ပံ့ပိုးမှု ##

`CONTRIBUTING.md` ဖိုင်၏စည်းမျဉ်းများကိုသင်လိုက်နာသရွေ့ဤစီမံကိန်းအတွက်ပါဝင်ခွင့်ပြုနိုင်သည်။

[ဤစီမံကိန်းအတွက်ပံ့ပိုးပေးသောစည်းမျဉ်းများကိုကြည့်ရှုရန်ဒီနေရာကိုနှိပ်ပါ / နှိပ်ပါ] (CONTRIBUTING.md)

***

README အကြောင်း ##

ဖိုင်အမျိုးအစားအမျိုးအစား - `Markdown (* .md)`

file version: `၁ (၂၀၂၁ ခုနှစ်၊ ကြာသပတေးနေ့၊ 21ပြီ ၂၂ ရက်ညနေ ၆ း ၃၀)`

လိုင်းအရေအတွက်: `0,306`

***

## README ဗားရှင်းသမိုင်း

ဗားရှင်း ၁ (၂၀၂၁ ခုနှစ်၊ ကြာသပတေးနေ့၊ 21ပြီ ၂၂ ရက်ညနေ ၆ း ၃၀)

> အပြောင်းအလဲများ -

> * ဖိုင်ကိုစတင်ခဲ့သည်

> * ခေါင်းစဉ်အပိုင်းကဆက်ပြောသည်

> * အညွှန်းကိန်းကဆက်ပြောသည်

> * အကြောင်းအပိုင်းထည့်သွင်းခဲ့သည်

> * ဝီကီအပိုင်းကိုထပ်ထည့်သည်

> * ဗားရှင်းသမိုင်းအပိုင်းကိုထည့်သွင်းခဲ့သည်

> * ပြissuesနာများအပိုင်းကိုထည့်သွင်းခဲ့သည်။

> * အတိတ်ပြissuesနာများအပိုင်းကိုထည့်သွင်းခဲ့သည်

> * အတိတ်ဆွဲတောင်းဆိုမှုများအပိုင်းကဆက်ပြောသည်

> * တက်ကြွစွာဆွဲတောင်းဆိုမှုများအပိုင်းထည့်သွင်းခဲ့သည်

> * အမျှဝေသူအပိုင်းထည့်သွင်းခဲ့သည်

> * ပံ့ပိုးအပိုင်းထည့်သွင်းခဲ့သည်

> * README အကြောင်းများကိုထပ်ထည့်သည်

> * README ဗားရှင်းသမိုင်းအပိုင်းကိုထပ်ထည့်လိုက်သည်

> * အရင်းအမြစ်များကဏ္ section ကိုထည့်သွင်းခဲ့သည်

>> အခမဲ့ဆော့ (ဖ်) ဝဲ (လ်) အခြေအနေကဏ္ section ကို DRM အခမဲ့စတစ်ကာနှင့်သတင်းစကားပါရှိသည်

> * စပွန်ဆာအချက်အလက်ကဏ္ Added ကိုထည့်သွင်းခဲ့သည်

> * ဗားရှင်း ၁ တွင်အခြားအပြောင်းအလဲမရှိပါ

ဗားရှင်း ၂ (မကြာမီလာမည်)

> အပြောင်းအလဲများ -

မကြာမီလာမည်

> * ဗားရှင်း ၂ တွင်အခြားအပြောင်းအလဲမရှိပါ

***

### README ဖိုင်ရဲ့အဆုံးကိုရောက်ပြီ

[အပေါ်သို့] (# ထိပ်) [Exit] (https://github.com)

### EOF

***
