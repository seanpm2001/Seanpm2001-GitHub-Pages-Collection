***

# Cam Cam Plus (CC +)

! [{Project-ikoon} Kon nie hierdie prent laai nie. Dit kan wees as gevolg van die feit dat die lêer nie bereik is nie, of 'n algemene fout. Herlaai die bladsy om 'n moontlike algemene fout op te los.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Deur:

## [Seanpm2001] (https://github.com/seanpm2001) en ander bydraers

### Top

# `README.md`

***

## Lees hierdie artikel in 'n ander taal

** Huidige taal is: ** `Engels (VS)` _ (vertalings moet dalk reggestel word om Engels reg te stel wat die regte taal vervang) _

_🌐 Lys van tale_

** Gesorteer op: ** `A-Z`

[Sorteeropsies nie beskikbaar nie] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanees | [am አማርኛ] (/. github / README_AM.md) Amharies | [ar عربى] (/.github/README_AR.md) Arabies | [hy հայերեն] (/. github / README_HY.md) Armeens | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbeidjans | [eu Euskara] (/. github /README_EU.md) Baskies | [wees Беларуская] (/. Github / README_BE.md) Belo-Russies | [bn বাংলা] (/. Github / README_BN.md) Bengaals | [bs Bosanski] (/. Github / README_BS.md) Bosnies | [bg български] (/. Github / README_BG.md) Bulgaars | [ca Català] (/. Github / README_CA.md) Katalaans | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chinees (Vereenvoudigd) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chinees (Tradisioneel) | [co Corsu] (/. Github / README_CO.md) Korsikaans | [hr Hrvatski] (/. Github / README_HR.md) Kroaties | [cs čeština] (/. Github / README_CS .md) Tsjeggies [da dansk] (README_DA.md) Deens | [nl Nederlands] (/. github / README_ NL.md) Nederlands | [** en-us Engels **] (/. github / README.md) Engels | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estnies | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Fins | [fr français] (/. github / README_FR.md) Frans | [fy Frysk] (/. github / README_FY.md) Fries | [gl Galego] (/. github / README_GL.md) Galisies | [ka ქართველი] (/. github / README_KA) Georgies | [de Deutsch] (/. github / README_DE.md) Duits | [el Ελληνικά] (/. github / README_EL.md) Grieks | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haïtiaanse Creools | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaïaans | [he עִברִית] (/. github / README_HE.md) Hebreeus | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hongaars | [is Íslenska] (/. github / README_IS.md) Yslands | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesië] (/. github / README_ID.md) Yslands | [ga Gaeilge] (/. github / README_GA.md) Iers | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japannees | [jw Wong jawa] (/. github / README_JW.md) Javaans | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazaks | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-suid 韓國 語] (/. github / README_KO_SOUTH.md) Koreaans (Suid) | [ko-noord 문화어] (README_KO_NORTH.md) Koreaans (Noord) (nog nie vertaal nie) | [ku Kurdî] (/. github / README_KU.md) Koerdies (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgisies | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latyn | [lt Lietuvis] (/. github / README_LT.md) Litaus | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgs | [mk Македонски] (/. github / README_MK.md) Masedonies | [mg Malgassies] (/. github / README_MG.md) Malgassies | [ms Bahasa Melayu] (/. github / README_MS.md) Maleis | [ml മലയാളം] (/. github / README_ML.md) Malabaars | [mt Malti] (/. github / README_MT.md) Maltees | [mi Maori] (/. github / README_MI.md) Maori | [mnr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongools | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Birmaans) | [ne नेपाली] (/. github / README_NE.md) Nepalees | [no norsk] (/. github / README_NO.md) Noors | [of ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pasjto | [fa فارسی] (/. github / README_FA.md) | Persies [pl polski] (/. github / README_PL.md) Pools | [pt português] (/. github / README_PT.md) Portugees | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Geen tale beskikbaar wat met die letter Q | begin nie [ro Română] (/. github / README_RO.md) Roemeens | [ru русский] (/. github / README_RU.md) Russies | [sm Faasamoa] (/. github / README_SM.md) Samoaans | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Skotse Gaelies | [sr Српски] (/. github / README_SR.md) Serwies | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slowaaks | [sl Slovenščina] (/. github / README_SL.md) Sloweens | [so Soomaali] (/. github / README_SO.md) Somalies | [[es en español] (/. github / README_ES.md) Spaans | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Sweeds | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tataars | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Turks | [tk Türkmenler] (/. github / README_TK.md) Turkmeens | [uk Український] (/. github / README_UK.md) Oekraïens | [ur اردو] (/. github / README_UR.md) Oerdoe | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Oezbeeks | [vi Tiếng Việt] (/. github / README_VI.md) Viëtnamees | [cy Cymraeg] (/. github / README_CY.md) Wallies | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Jiddisj | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Beskikbaar in 110 tale (108 as Engels en Noord-Koreaans nie getel word nie, aangesien Noord-Koreaans nog nie vertaal is nie [Lees hieroor]] (/ OldVersions / Koreaans (Noord ) /README.md))

Vertalings in ander tale as Engels word masjienvertaal en is nog nie akkuraat nie. Nog geen foute is reggestel vanaf 5 Februarie 2021. Rapporteer asseblief vertaalfoute [hier] (https://github.com/seanpm2001/CamCamPlus/issues/), maak seker dat u u regstelling met bronne rugsteun en my lei, aangesien ek dit nie doen nie U kan nie ander tale as Engels goed ken nie (ek is van plan om uiteindelik 'n vertaler te kry) noem [wiktionary] (https://en.wiktionary.org) en ander bronne in u verslag. As u dit nie doen nie, sal die regstelling van die hand gewys word.

Opmerking: as gevolg van beperkings met die interpretasie van GitHub van markdown (en bykans elke ander webgebaseerde interpretasie van markdown), klik hierdie skakels u na 'n aparte lêer op 'n aparte bladsy wat nie my GitHub-profielblad is nie. U sal na die [seanpm2001 / seanpm2001-bewaarplek] (https://github.com/seanpm2001/seanpm2001) herlei word, waar die README aangebied word.

Vertalings word met Google Translate gedoen as gevolg van beperkte of geen ondersteuning vir die tale wat ek benodig in ander vertaaldienste soos DeepL en Bing Translate. Ek werk daaraan om 'n alternatief te vind. Om die een of ander rede is die opmaak (skakels, verdelers, vetdruk, kursief, ens.) Deurmekaar in verskillende vertalings. Dit is vervelig om op te los, en ek weet nie hoe om hierdie probleme in tale met nie-Latynse karakters op te los nie, en van regs na links (soos Arabies) is ekstra hulp nodig om hierdie probleme op te los

As gevolg van instandhoudingsprobleme is baie vertalings verouderd en gebruik 'n verouderde weergawe van hierdie 'README'-artikellêer. 'N Vertaler is nodig. Vanaf 22 April 2021 neem dit my ook 'n rukkie om al die nuwe skakels te laat werk.

***

# Indeks

[00.0 - Top] (# Top)

> [00.1 - titel] (# CamCamPlus)

> [00.2 - Lees hierdie artikel in 'n ander taal] (# Lees-hierdie-artikel-in-'n-ander-taal)

> [00.3 - Indeks] (# indeks)

[01.0 - Beskrywing] (# CamCamPlus)

[02.0 - About] (# About)

[03.0 - Wiki] (# Wiki)

[04.0 - Weergawe-geskiedenis] (# weergawe-geskiedenis)

[05.0 - Sagtewarestatus] (# Sagteware-status)

[06.0 - Borginligting] (# borginligting)

[07.0 - Bydraers] (# bydraers)

[08.0 - Uitgawes] (# uitgawes)

> [08.1 - Huidige uitgawes] (# Huidige uitgawes)

> [08.2 - Uitgawe in die verlede] (# vorige uitgawes)

> [08.3 - Verlede trekversoeke] (# Verlede trek-versoeke)

> [08.4 - Aktiewe trekversoeke] (# Aktiewe trekversoeke)

[09.0 - Hulpbronne] (# bronne)

[10.0 - Bydra] (# dra by)

[11.0 - Oor README] (# About-README)

[12.0 - README weergawe geskiedenis] (# README-weergawe-geskiedenis)

[13.0 - Footer] (# U het die einde van die README-lêer bereik)

> [13.1 - Einde van lêer] (# EOF)

***

# CamCamPlus
CamCamPlus is 'n hoë-end gratis en open-source kamera wat foto's en video's in baie formate en in baie resolusies kan neem.

***

## Oor

Sien hierbo. Hierdie projek handel oor 'n oopbron-kragtige kamera wat baie opsies bied en hindernisse wat ander algemene kamera-programme het, afbreek (soos die opname-limiet van 30 minute)

***

## Wiki

[Klik / tik hier om die Wiki van hierdie projekte te sien] (https://github.com/seanpm2001/CamCamPlus/wiki)

As die projek voorgehou is, is die Wiki waarskynlik verwyder. Gelukkig bevat ek 'n ingeboude weergawe. U kan dit [hier] (/ External / ProjectWiki /) besigtig.

***

## Borginligting

! [SponsorButton.png] (SponsorButton.png)

U kan hierdie projek borg as u wil, maar spesifiseer asseblief waaraan u wil skenk. [Sien die fondse waaraan u hier kan skenk] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

U kan ander borginligting [hier] sien (https://github.com/seanpm2001/Sponsor-info/)

Probeer dit! Die borgknoppie is reg langs die horlosie / oopknop-knoppie.

***

## Weergawe geskiedenis

** Weergawegeskiedenis tans nie beskikbaar nie **

** Geen ander weergawes gelys nie **

***

## Sagteware status

Al my werke is gratis, sommige beperkings. DRM (** D ** igital ** R ** estrictions ** M ** anagement) is in geen van my werke aanwesig nie.

! [DRM-vry_label.en.svg] (DRM-vry_label.en.svg)

Hierdie plakker word ondersteun deur die Free Sagtewarestigting. Ek is nooit van plan om DRM by my werke in te sluit nie.

Ek gebruik die afkorting "Digital Restrictions Management" in plaas van die meer bekende "Digital Rights Management", aangesien die algemene manier om dit aan te spreek onwaar is; daar is geen regte met DRM nie. Die spelling "Digital Restrictions Management" is akkurater en word ondersteun deur [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) en die [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Hierdie afdeling word gebruik om bewustheid te verhoog vir die probleme met DRM, en ook om dit te betoog. DRM is gebrekkig van ontwerp en is 'n groot bedreiging vir alle rekenaargebruikers en sagteware-vryheid.

Beeldkrediet: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Bydraers

Tans is ek die enigste bydraer. Bydrae is toegelaat, solank u die reëls van die lêer [CONTRIBUTING.md] (CONTRIBUTING.md) volg.

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 verbintenisse (vanaf Donderdag 22 April 2021 om 18:30)

> * 2. Geen ander bydraers nie.

***

## Kwessies

### Huidige uitgawes

* Geen op die oomblik nie

* Geen ander huidige kwessies nie

As die bewaarplek opgegaar is, is probleme waarskynlik verwyder. Gelukkig hou ek 'n argief van sekere beelde [hier] (/. Github / Issues /)

[Lees hier die privaatheidsbeleid oor argiewe vir kwessies] (/. Github / Issues / README.md)

** TL; DR **

Ek argiveer my eie uitgawes. U kwessie sal eers geargiveer word tensy u versoek om dit te argiveer.

### Uitgawe in die verlede

* Geen op die oomblik nie

* Geen ander uitgawes uit die verlede nie

As die bewaarplek opgegaar is, is probleme waarskynlik verwyder. Gelukkig hou ek 'n argief van sekere beelde [hier] (/. Github / Issues /)

[Lees hier die privaatheidsbeleid oor argiewe vir kwessies] (/. Github / Issues / README.md)

** TL; DR **

Ek argiveer my eie uitgawes. U kwessie sal eers geargiveer word tensy u versoek om dit te argiveer.

### Vorige trekversoeke

* Geen op die oomblik nie

* Geen ander versoeke om in die verlede te trek nie

As die bewaarplek opgegaar is, is probleme waarskynlik verwyder. Gelukkig hou ek 'n argief van sekere beelde [hier] (/. Github / Issues /)

[Lees hier die privaatheidsbeleid oor argiewe vir kwessies] (/. Github / Issues / README.md)

** TL; DR **

Ek argiveer my eie uitgawes. U kwessie sal eers geargiveer word tensy u versoek om dit te argiveer.

### Aktiewe trekversoeke

* Geen op die oomblik nie

* Geen ander aktiewe trekversoeke nie

As die bewaarplek opgegaar is, is probleme waarskynlik verwyder. Gelukkig hou ek 'n argief van sekere beelde [hier] (/. Github / Issues /)

[Lees hier die privaatheidsbeleid oor argiewe vir kwessies] (/. Github / Issues / README.md)

** TL; DR **

Ek argiveer my eie uitgawes. U kwessie sal eers geargiveer word tensy u versoek om dit te argiveer.

***

## Hulpbronne

Hier is 'n paar ander bronne vir hierdie projek:

[Projektaallêer] (PROJECT_LANG.cpp)

[Navorsingsbiblioteek vir hierdie projek] (/ Verwysings /)

[Die spesiale videomodule vir hierdie projek (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[Sluit aan by die bespreking oor GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

Geen ander hulpbronne op die oomblik nie.

***

## Bydraend

Bydrae is toegelaat vir hierdie projek, solank u die reëls van die lêer `CONTRIBUTING.md` volg.

[Klik / tik hier om die bydraende reëls vir hierdie projek te sien] (CONTRIBUTING.md)

***

## Oor README

Lêerstipe: 'Markdown (* .md)'

Lêerweergawe: '1 (Donderdag 22 April 2021 om 18:30)'

Reëltelling: `0,306`

***

## README weergawe geskiedenis

Weergawe 1 (Donderdag 22 April 2021 om 18:30)

> Wysigings:

> * Het die lêer begin

> * Het die titelgedeelte bygevoeg

> * Die indeks bygevoeg

> * Het die gedeelte oor bygevoeg

> * Het die Wiki-afdeling bygevoeg

> * Het die afdeling weergawegeskiedenis bygevoeg

> * Die afdeling uitgawes is bygevoeg.

> * Het die afdeling vir vorige uitgawes bygevoeg

> * Het die afdeling vir vorige trekversoeke bygevoeg

> * Het die afdeling vir aktiewe trekversoeke bygevoeg

> * Het die afdeling bydraers bygevoeg

> * Die bydraende afdeling is bygevoeg

> * Het die afdeling README bygevoeg

> * Het die README weergawegeskiedenis-afdeling bygevoeg

> * Het die afdeling hulpbronne bygevoeg

> * Het 'n sagtewarestatusafdeling bygevoeg, met 'n DRM-gratis plakker en boodskap

> * Het die borginligting-afdeling bygevoeg

> * Geen ander veranderinge in weergawe 1 nie

Weergawe 2 (binnekort beskikbaar)

> Wysigings:

> * Binnekort beskikbaar

> * Geen ander veranderinge in weergawe 2 nie

***

### U het die einde van die README-lêer bereik

[Terug na bo] (# Top) [Afrit] (https://github.com)

### EOF

***
