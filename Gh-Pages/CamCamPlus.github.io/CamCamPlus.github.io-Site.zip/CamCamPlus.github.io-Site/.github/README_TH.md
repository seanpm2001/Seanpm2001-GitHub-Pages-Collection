***

# แคม Cam Plus (CC +)

! [{Project icon} ภาพนี้ไม่สามารถโหลดได้ อาจเป็นเพราะเข้าไม่ถึงไฟล์หรือเกิดข้อผิดพลาดทั่วไป โหลดหน้านี้ซ้ำเพื่อแก้ไขข้อผิดพลาดทั่วไปที่อาจเกิดขึ้น] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# โดย:

## [Seanpm2001] (https://github.com/seanpm2001) และผู้ร่วมให้ข้อมูลอื่น ๆ

### ด้านบน

# `README.md`

***

## อ่านบทความนี้ในภาษาอื่น

** ภาษาปัจจุบันคือ: ** `อังกฤษ (สหรัฐอเมริกา)` _ (อาจต้องแก้ไขคำแปลเพื่อแก้ไขภาษาอังกฤษแทนที่ภาษาที่ถูกต้อง) _

_🌐รายชื่อภาษา _

** จัดเรียงโดย: ** `A-Z`

[ตัวเลือกการจัดเรียงไม่พร้อมใช้งาน] (https://github.com/Degoogle-your-Life)

([af แอฟริกัน] (/. github / README_AF.md) ภาษาแอฟริกัน | [sq Shqiptare] (/. github / README_SQ.md) แอลเบเนีย | [am አማርኛ] (/. github / README_AM.md) อัมฮาริก | [ar عربى] (/.github/README_AR.md) อาหรับ | [hy հայերեն] (/. github / README_HY.md) อาร์เมเนีย | [az Azərbaycan dili] (/. github / README_AZ.md) อาเซอร์ไบจัน | [eu Euskara] (/. github /README_EU.md) บาสก์ | [be Беларуская] (/. github / README_BE.md) เบลารุส | [bn বাংলা] (/. github / README_BN.md) เบงกาลี | [bs Bosanski] (/. github / README_BS.md) บอสเนีย | [bg български] (/. github / README_BG.md) บัลแกเรีย | [ca Català] (/. github / README_CA.md) คาตาลัน | [ceb Sugbuanon] (/. github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) ชิเชว่า | [zh-CN 简体中文] (/. github / README_ZH-CN.md) จีน (ตัวย่อ) | [zh-t 中國傳統的）] (/. github / README_ZH) -T.md) จีน (ตัวเต็ม) | [co Corsu] (/. github / README_CO.md) คอร์ซิกา | [hr Hrvatski] (/. github / README_HR.md) โครเอเชีย | [cs čeština] (/. github / README_CS .md) เช็ก | [da dansk] (README_DA.md) เดนมาร์ก | [nl Nederlands] (/. github / README_ NL.md) ดัตช์ | [** th-us English **] (/. github / README.md) ภาษาอังกฤษ | [EO Esperanto] (/. github / README_EO.md) ภาษาเอสเปรันโต | [et Eestlane] (/. github / README_ET.md) เอสโตเนีย | [tl Pilipino] (/. github / README_TL.md) ฟิลิปปินส์ | [fi Suomalainen] (/. github / README_FI.md) ฟินแลนด์ | [fr français] (/. github / README_FR.md) ฝรั่งเศส | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) กาลิเซีย | [ka ქართველი] (/. github / README_KA) จอร์เจีย | [de Deutsch] (/. github / README_DE.md) เยอรมัน | [el Ελληνικά] (/. github / README_EL.md) กรีก | [gu ગુજરાતી] (/. github / README_GU.md) คุชราต | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) เฮาซา | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) ฮาวาย | [he עִברִית] (/. github / README_HE.md) ฮีบรู | [สวัสดีहिन्दी] (/. github / README_HI.md) ภาษาฮินดี | [หืมม้ง] (/. github / README_HMN.md) ม้ง | [hu Magyar] (/. github / README_HU.md) ฮังการี | [is Íslenska] (/. github / README_IS.md) ไอซ์แลนด์ | [ig อิกโบ] (/. github / README_IG.md) อิกโบ | [id บาฮาซาอินโดนีเซีย] (/. github / README_ID.md) ไอซ์แลนด์ | [ga Gaeilge] (/. github / README_GA.md) ไอริช | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) ญี่ปุ่น | [jw Wong jawa] (/. github / README_JW.md) ชวา | [kn ಕನ್ನಡ] (/. github / README_KN.md) กันนาดา | [kk Қазақ] (/. github / README_KK.md) คาซัค | [km ខ្មែរ] (/. github / README_KM.md) เขมร | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國語] (/. github / README_KO_SOUTH.md) เกาหลี (ใต้) | [ko-north 문화어] (README_KO_NORTH.md) เกาหลี (เหนือ) (ยังไม่ได้แปล) | [ku Kurdî] (/. github / README_KU.md) เคิร์ด (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) คีร์กีซ | [lo ລາວ] (/. github / README_LO.md) ลาว | [la Latine] (/. github / README_LA.md) ละติน | [lt Lietuvis] (/. github / README_LT.md) ลิทัวเนีย | [lb Lëtzebuergesch] (/. github / README_LB.md) ลักเซมเบิร์ก | [mk Македонски] (/. github / README_MK.md) มาซิโดเนีย | [mg Malagasy] (/. github / README_MG.md) มาลากาซี | [ms Bahasa Melayu] (/. github / README_MS.md) มาเลย์ | [ml മലയാളം] (/. github / README_ML.md) มาลายาลัม | [mt Malti] (/. github / README_MT.md) มอลตา | [mi เมารี] (/. github / README_MI.md) เมารี | [mr मराठी] (/. github / README_MR.md) มราฐี | [mn Монгол] (/. github / README_MN.md) มองโกเลีย | [my မြန်မာ] (/. github / README_MY.md) เมียนมาร์ (พม่า) | [ne नेपाली] (/. github / README_NE.md) เนปาล | [no norsk] (/. github / README_NO.md) นอร์เวย์ | [หรือଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (โอริยา) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | เปอร์เซีย [pl polski] (/. github / README_PL.md) โปแลนด์ | [pt português] (/. github / README_PT.md) โปรตุเกส | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) ปัญจาบ | ไม่มีภาษาที่ขึ้นต้นด้วยตัวอักษร Q | [ro Română] (/. github / README_RO.md) โรมาเนีย | [ru русский] (/. github / README_RU.md) รัสเซีย | [sm Faasamoa] (/. github / README_SM.md) ซามัว | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) สก็อตเกลิค | [sr Српски] (/. github / README_SR.md) เซอร์เบีย | [st Sesotho] (/. github / README_ST.md) เซโซโท | [sn โชนา] (/. github / README_SN.md) โชนา | [sd سنڌي] (/. github / README_SD.md) สินธี | [si සිංහල] (/. github / README_SI.md) สิงหล | [sk Slovák] (/. github / README_SK.md) สโลวัก | [sl Slovenščina] (/. github / README_SL.md) สโลวีเนีย | [Soomaali] (/. github / README_SO.md) โซมาเลีย | [[es en español] (/. github / README_ES.md) สเปน | [su Sundanis] (/. github / README_SU.md) สุndanese | [sw Kiswahili] (/. github / README_SW.md) ภาษาสวาฮิลี | [sv Svenska] (/. github / README_SV.md) สวีเดน | [tg Тоҷикӣ] (/. github / README_TG.md) ทาจิก | [ta தமிழ்] (/. github / README_TA.md) ทมิฬ | [tt Татар] (/. github / README_TT.md) ตาตาร์ | [te తెలుగు] (/. github / README_TE.md) กู | [th ไทย] (/. github / README_TH.md) ภาษาไทย | [tr Türk] (/. github / README_TR.md) ตุรกี | [tk Türkmenler] (/. github / README_TK.md) เติร์กเมน | [uk Український] (/. github / README_UK.md) ยูเครน | [ur اردو] (/. github / README_UR.md) ภาษาอูรดู | [ug ئۇيغۇر] (/. github / README_UG.md) อุยกูร์ | [uz O'zbek] (/. github / README_UZ.md) อุซเบก | [vi TiếngViệt] (/. github / README_VI.md) เวียดนาม | [cy Cymraeg] (/. github / README_CY.md) เวลส์ | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) ยิดดิช | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) ซูลู) มีให้บริการใน 110 ภาษา (108 ภาษาเมื่อไม่นับอังกฤษและเกาหลีเหนือเนื่องจากเกาหลีเหนือยังไม่ได้รับการแปล [อ่านเพิ่มเติมได้ที่นี่] (/ OldVersions / Korean (North ) /README.md))

การแปลในภาษาอื่นที่ไม่ใช่ภาษาอังกฤษได้รับการแปลโดยคอมพิวเตอร์และยังไม่ถูกต้อง ยังไม่มีการแก้ไขข้อผิดพลาด ณ วันที่ 5 กุมภาพันธ์ 2021 โปรดรายงานข้อผิดพลาดในการแปล [ที่นี่] (https://github.com/seanpm2001/CamCamPlus/issues/) อย่าลืมสำรองข้อมูลการแก้ไขด้วยแหล่งข้อมูลและแนะนำฉันตามที่ฉันทำ ไม่รู้ภาษาอื่นนอกจากภาษาอังกฤษดี (ฉันวางแผนที่จะรับนักแปลในที่สุด) โปรดอ้างอิง [วิกิพจนานุกรม] (https://en.wiktionary.org) และแหล่งข้อมูลอื่น ๆ ในรายงานของคุณ หากไม่ดำเนินการดังกล่าวจะส่งผลให้มีการปฏิเสธการแก้ไขที่เผยแพร่

หมายเหตุ: เนื่องจากข้อ จำกัด ในการตีความ markdown ของ GitHub (และการตีความ markdown บนเว็บอื่น ๆ ) การคลิกลิงก์เหล่านี้จะนำคุณไปยังไฟล์แยกต่างหากในหน้าแยกต่างหากที่ไม่ใช่หน้าโปรไฟล์ GitHub ของฉัน คุณจะถูกเปลี่ยนเส้นทางไปยัง [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001) ซึ่งโฮสต์ README

การแปลทำได้ด้วย Google Translate เนื่องจากการรองรับภาษาที่ฉันต้องการในบริการแปลอื่น ๆ เช่น DeepL และ Bing Translate มีอย่าง จำกัด หรือไม่มีเลย ฉันกำลังหาทางเลือกอื่น ด้วยเหตุผลบางประการการจัดรูปแบบ (ลิงก์ตัวแบ่งตัวหนาตัวเอียง ฯลฯ ) จึงสับสนในการแปลต่างๆ เป็นเรื่องที่น่าเบื่อที่จะต้องแก้ไขและฉันไม่รู้วิธีแก้ไขปัญหาเหล่านี้ในภาษาที่มีอักขระที่ไม่ใช่ภาษาละตินและต้องการความช่วยเหลือเพิ่มเติมจากขวาไปซ้าย (เช่นภาษาอาหรับ) ในการแก้ไขปัญหาเหล่านี้

เนื่องจากปัญหาการบำรุงรักษาคำแปลจำนวนมากจึงล้าสมัยและกำลังใช้ไฟล์บทความ "README" เวอร์ชันที่ล้าสมัยนี้ จำเป็นต้องมีนักแปล นอกจากนี้ในวันที่ 22 เมษายน 2021 ฉันต้องใช้เวลาสักพักเพื่อให้ลิงก์ใหม่ทั้งหมดทำงานได้

***

# ดัชนี

[00.0 - บนสุด] (# บนสุด)

> [00.1 - ชื่อ] (# CamCamPlus)

> [00.2 - อ่านบทความนี้ในภาษาอื่น] (# Read-this-article-in-a-different-language)

> [00.3 - ดัชนี] (# ดัชนี)

[01.0 - คำอธิบาย] (# CamCamPlus)

[02.0 - About] (# About)

[03.0 - วิกิ] (# วิกิ)

[04.0 - ประวัติเวอร์ชัน] (# ประวัติเวอร์ชัน)

[05.0 - สถานะซอฟต์แวร์] (# สถานะซอฟต์แวร์)

[06.0 - ข้อมูลผู้สนับสนุน] (# ข้อมูลผู้สนับสนุน)

[07.0 - ผู้ร่วมให้ข้อมูล] (# ผู้ร่วมให้ข้อมูล)

[08.0 - ปัญหา] (# ฉบับ)

> [08.1 - ปัญหาปัจจุบัน] (# ปัญหาปัจจุบัน)

> [08.2 - ปัญหาที่ผ่านมา] (# ปัญหาในอดีต)

> [08.3 - คำขอดึงที่ผ่านมา] (# คำขอดึงที่ผ่านมา)

> [08.4 - คำขอดึงที่ใช้งานอยู่] (# คำขอดึงที่ใช้งานอยู่)

[09.0 - ทรัพยากร] (# แหล่งข้อมูล)

[10.0 - การมีส่วนร่วม] (# การร่วมให้ข้อมูล)

[11.0 - เกี่ยวกับ README] (# About-README)

[12.0 - ประวัติเวอร์ชัน README] (# README- รุ่น - ประวัติ)

[13.0 - ส่วนท้าย] (# คุณมีไฟล์ถึงจุดสิ้นสุดของไฟล์ README)

> [13.1 - จุดสิ้นสุดของไฟล์] (# EOF)

***

# CamCamPlus
CamCamPlus เป็นกล้องระดับไฮเอนด์ฟรีและโอเพ่นซอร์สที่สามารถถ่ายภาพและวิดีโอได้หลายรูปแบบและมีความละเอียดมากมาย

***

## เกี่ยวกับ

ดูด้านบน. โปรเจ็กต์นี้เกี่ยวกับกล้องทรงพลังแบบโอเพนซอร์สที่ให้ตัวเลือกมากมายและทำลายอุปสรรคที่แอพกล้องทั่วไปอื่น ๆ มี (เช่นขีด จำกัด การบันทึก 30 นาที)

***

## วิกิ

[คลิก / แตะที่นี่เพื่อดูโครงการนี้ Wiki] (https://github.com/seanpm2001/CamCamPlus/wiki)

หากโปรเจ็กต์ถูกแยกออกแสดงว่า Wiki น่าจะถูกลบออก โชคดีที่ฉันมีเวอร์ชันฝังตัว คุณสามารถดูได้ [ที่นี่] (/ ภายนอก / ProjectWiki /)

***

## ข้อมูลผู้สนับสนุน

! [SponsorButton.png] (SponsorButton.png)

คุณสามารถสนับสนุนโครงการนี้ได้หากต้องการ แต่โปรดระบุสิ่งที่คุณต้องการบริจาค [ดูเงินที่คุณสามารถบริจาคได้ที่นี่] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

คุณสามารถดูข้อมูลผู้สนับสนุนอื่น ๆ [ที่นี่] (https://github.com/seanpm2001/Sponsor-info/)

ลองดูสิ! ปุ่มสปอนเซอร์จะอยู่ถัดจากปุ่มนาฬิกา / ยกเลิกนาฬิกา

***

## ประวัติเวอร์ชัน

** ประวัติเวอร์ชันไม่สามารถใช้งานได้ในขณะนี้ **

** ไม่มีรุ่นอื่นอยู่ในรายการ **

***

## สถานะซอฟต์แวร์

ผลงานทั้งหมดของฉันไม่มีข้อ จำกัด บางประการ DRM (** D ** igital ** R ** estrictions ** M ** anagement) ไม่มีอยู่ในผลงานของฉัน

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

สติกเกอร์นี้ได้รับการสนับสนุนโดย Free Software Foundation ฉันไม่เคยตั้งใจที่จะรวม DRM ไว้ในผลงานของฉัน

ฉันใช้ตัวย่อ "Digital Restrictions Management" แทน "Digital Rights Management" ซึ่งเป็นที่รู้จักกันดีกว่าเนื่องจากวิธีทั่วไปในการระบุว่าเป็นเท็จไม่มีสิทธิ์ใด ๆ กับ DRM การสะกด "Digital Restrictions Management" มีความแม่นยำมากขึ้นและได้รับการสนับสนุนโดย [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) และ [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

ส่วนนี้ใช้เพื่อสร้างความตระหนักถึงปัญหาเกี่ยวกับ DRM และเพื่อประท้วง DRM มีข้อบกพร่องจากการออกแบบและเป็นภัยคุกคามที่สำคัญต่อผู้ใช้คอมพิวเตอร์และเสรีภาพของซอฟต์แวร์ทั้งหมด

เครดิตรูปภาพ: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## ผู้ร่วมให้ข้อมูล

ปัจจุบันฉันเป็นผู้สนับสนุนเพียงคนเดียว อนุญาตให้มีส่วนร่วมได้ตราบเท่าที่คุณปฏิบัติตามกฎของไฟล์ [CONTRIBUTING.md] (CONTRIBUTING.md)

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 คอมมิต (ณ วันพฤหัสบดีที่ 22 เมษายน 2564 เวลา 18:30 น.)

> * 2. ไม่มีผู้ร่วมให้ข้อมูลอื่น ๆ

***

## ปัญหา

### ปัญหาปัจจุบัน

* ไม่มีในขณะนี้

* ไม่มีปัญหาอื่น ๆ ในปัจจุบัน

หากที่เก็บถูกแยกออกปัญหาที่น่าจะถูกลบออกไป โชคดีที่ฉันเก็บภาพบางภาพไว้ [ที่นี่] (/. github / Issues /)

[อ่านนโยบายความเป็นส่วนตัวเกี่ยวกับปัญหาการเก็บถาวรที่นี่] (/. github / Issues / README.md)

** TL; DR **

ฉันเก็บปัญหาของตัวเอง ปัญหาของคุณจะไม่ถูกเก็บถาวรเว้นแต่คุณจะขอให้เก็บถาวร

### ปัญหาที่ผ่านมา

* ไม่มีในขณะนี้

* ไม่มีปัญหาในอดีตอื่น ๆ

หากที่เก็บถูกแยกออกปัญหาที่น่าจะถูกลบออกไป โชคดีที่ฉันเก็บภาพบางภาพไว้ [ที่นี่] (/. github / Issues /)

[อ่านนโยบายความเป็นส่วนตัวเกี่ยวกับปัญหาการเก็บถาวรที่นี่] (/. github / Issues / README.md)

** TL; DR **

ฉันเก็บปัญหาของตัวเอง ปัญหาของคุณจะไม่ถูกเก็บถาวรเว้นแต่คุณจะขอให้เก็บถาวร

### คำขอดึงที่ผ่านมา

* ไม่มีในขณะนี้

* ไม่มีคำขอดึงที่ผ่านมาอื่น ๆ

หากที่เก็บถูกแยกออกปัญหาที่น่าจะถูกลบออกไป โชคดีที่ฉันเก็บภาพบางภาพไว้ [ที่นี่] (/. github / Issues /)

[อ่านนโยบายความเป็นส่วนตัวเกี่ยวกับปัญหาการเก็บถาวรที่นี่] (/. github / Issues / README.md)

** TL; DR **

ฉันเก็บปัญหาของตัวเอง ปัญหาของคุณจะไม่ถูกเก็บถาวรเว้นแต่คุณจะขอให้เก็บถาวร

### คำขอดึงที่ใช้งานอยู่

* ไม่มีในขณะนี้

* ไม่มีคำขอดึงอื่น ๆ ที่ใช้งานอยู่

หากที่เก็บถูกแยกออกปัญหาที่น่าจะถูกลบออกไป โชคดีที่ฉันเก็บภาพบางภาพไว้ [ที่นี่] (/. github / Issues /)

[อ่านนโยบายความเป็นส่วนตัวเกี่ยวกับปัญหาการเก็บถาวรที่นี่] (/. github / Issues / README.md)

** TL; DR **

ฉันเก็บปัญหาของตัวเอง ปัญหาของคุณจะไม่ถูกเก็บถาวรเว้นแต่คุณจะขอให้เก็บถาวร

***

## ทรัพยากร

นี่คือแหล่งข้อมูลอื่น ๆ สำหรับโครงการนี้:

[ไฟล์ภาษาโครงการ] (PROJECT_LANG.cpp)

[ไลบรารีอ้างอิงงานวิจัยสำหรับโครงการนี้] (/ อ้างอิง /)

[โมดูลวิดีโอพิเศษสำหรับโปรเจ็กต์นี้ (วิดีโอ SVG)] (https://github.com/seanpm2001/SVG_Video/)

[เข้าร่วมการสนทนาบน GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

ไม่มีทรัพยากรอื่น ๆ ในขณะนี้

***

## การมีส่วนร่วม

อนุญาตให้มีการร่วมให้ข้อมูลสำหรับโปรเจ็กต์นี้ตราบใดที่คุณปฏิบัติตามกฎของไฟล์ "CONTRIBUTING.md"

[คลิก / แตะที่นี่เพื่อดูกฎการมีส่วนร่วมสำหรับโครงการนี้] (CONTRIBUTING.md)

***

## เกี่ยวกับ README

ประเภทไฟล์: Markdown (* .md)“

เวอร์ชันไฟล์: `1 (พฤหัสบดี 22 เมษายน 2564 เวลา 18:30 น.)"

จำนวนบรรทัด: "0,306"

***

## ประวัติรุ่น README

เวอร์ชั่น 1 (วันพฤหัสบดีที่ 22 เมษายน 2564 เวลา 18:30 น.)

> การเปลี่ยนแปลง:

> * เริ่มไฟล์

> * เพิ่มหัวข้อ

> * เพิ่มดัชนี

> * เพิ่มส่วนเกี่ยวกับ

> * เพิ่มส่วน Wiki

> * เพิ่มส่วนประวัติเวอร์ชัน

> * เพิ่มส่วนปัญหา

> * เพิ่มส่วนปัญหาที่ผ่านมา

> * เพิ่มส่วนคำขอดึงที่ผ่านมา

> * เพิ่มส่วนคำขอดึงที่ใช้งานอยู่

> * เพิ่มส่วนผู้ร่วมให้ข้อมูล

> * เพิ่มส่วนการมีส่วนร่วม

> * เพิ่มส่วนเกี่ยวกับ README

> * เพิ่มส่วนประวัติเวอร์ชัน README

> * เพิ่มส่วนทรัพยากร

> * เพิ่มส่วนสถานะซอฟต์แวร์พร้อมสติกเกอร์และข้อความ DRM ฟรี

> * เพิ่มส่วนข้อมูลผู้สนับสนุน

> * ไม่มีการเปลี่ยนแปลงอื่น ๆ ในเวอร์ชัน 1

เวอร์ชัน 2 (เร็ว ๆ นี้)

> การเปลี่ยนแปลง:

> * เร็ว ๆ นี้

> * ไม่มีการเปลี่ยนแปลงอื่น ๆ ในเวอร์ชัน 2

***

### คุณมาถึงจุดสิ้นสุดของไฟล์ README

[กลับไปด้านบน] (# บนสุด) [ออก] (https://github.com)

### EOF

***
