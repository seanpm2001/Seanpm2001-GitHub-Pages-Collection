***

# Cam Cam Plus (CC +)

! [{Ikon proyék} Gambar ieu gagal dimuat. Éta panginten alatan file henteu ngahontal, atanapi kasalahan umum. Muat ulang halaman pikeun ngalereskeun kasalahan umum anu mungkin.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Ku:

## [Seanpm2001] (https://github.com/seanpm2001) sareng kontributor anu sanés

### Top

# `README.md`

***

## Maca tulisan ieu dina basa anu sanés

** Bahasa ayeuna nyaéta: ** `English (US)` _ (tarjamahan panginten kedah dilereskeun kanggo ngalereskeun basa Inggris ngagentos bahasa anu leres) _

_🌐 Daptar bahasa_

** Diurutkeun ku: ** `A-Z`

[Pilihan asihan henteu sayogi] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albania | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) Arab | [hy հայերեն] (/. github / README_HY.md) Armenia | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijan | [eu Euskara] (/. github /README_EU.md) Basque | [janten Беларуская] (/. Github / README_BE.md) Bélarus | [bn বাংলা] (/. Github / README_BN.md) Benggali | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) Bulgaria | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Cina (Disederhanakeun) | [zh-t 中國 國 的）] (/. github / README_ZH -T.md) Cina (Tradisional) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Kroasia | [cs čeština] (/. Github / README_CS .md) Czech | [da dansk] (README_DA.md) Denmark | [nl Nederlands] (/. github / README_ NL.md) Walanda | [** en-us English **] (/. github / README.md) Inggris | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Éstonia | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finlandia | [fr français] (/. github / README_FR.md) Perancis | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galicia | [ka ქართველი] (/. github / README_KA) Georgia | [de Deutsch] (/. github / README_DE.md) Jérman | [el Ελληνικά] (/. github / README_EL.md) Yunani | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaii | [anjeunna עִברִית] (/. github / README_HE.md) Ibrani | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hungaria | [nyaéta Íslenska] (/. github / README_IS.md) Islandia | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandia | [ga Gaeilge] (/. github / README_GA.md) Irlandia | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Jepang | [jw Wong jawa] (/. github / README_JW.md) Java | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-kidul 韓國 語] (/. github / README_KO_SOUTH.md) Koréa (Kidul) | [ko-kalér 문화어] (README_KO_NORTH.md) Koréa (Kalér) (TEU BISA DITERJAR) [ku Kurdî] (/. github / README_KU.md) Kurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kyrgyz | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lituania | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksemburg | [mk Македонски] (/. github / README_MK.md) Macedonian | [mg Malagasi] (/. github / README_MG.md) Malagasi | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Malta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolian | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Burma) | [ne नेपाली] (/. github / README_NE.md) Nepali | [henteu norsk] (/. github / README_NO.md) Norwegia | [atanapi ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persia [pl polski] (/. github / README_PL.md) Polandia | [pt português] (/. github / README_PT.md) Portugis | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Teu aya basa anu dimimiti ku huruf Q | [ro Română] (/. github / README_RO.md) Romania | [ru русский] (/. github / README_RU.md) Rusia | [sm Faasamoa] (/. github / README_SM.md) Samoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scots Gaelic | [sr Српски] (/. github / README_SR.md) Serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slowakia] (/. github / README_SK.md) Slowakia | [sl Slovenščina] (/. github / README_SL.md) Slovenia | [jadi Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spanyol | [su Sundanis] (/. github / README_SU.md) Sundanon | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Swédia | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెల English] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thailand | [tr Türk] (/. github / README_TR.md) Turki | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukraina | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnam | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Sadia dina 110 basa (108 nalika henteu kaétang Inggris sareng Koréa Kalér, sabab Koréa Kalér teu acan ditarjamahkeun [Maca ngeunaan ieu di dieu] (/ OldVersions / Korea (Kalér ) /README.md))

Tarjamahan dina basa sanés basa Inggris anu ditarjamahkeun ku mesin sareng teu akurat. Teu aya kasalahan anu parantos dibéréskeun dugi ka 5 Pébruari 2021. Punten laporkeun kasalahan tarjamahan [didieu] (https://github.com/seanpm2001/CamCamPlus/issues/) pastikeun nyadangkeun koréksi anjeun sareng sumber sareng ngabimbing kuring, nalika kuring henteu Henteu terang basa sanés basa Inggris ogé (kuring rarancang bakal kéngingkeun penerjemah antukna) punten nyebatkeun [wikipedia] (https://en.wiktionary.org) sareng sumber sanés dina laporan anjeun. Gagal ngalakukeunana bakal ngahasilkeun panolakan kana koreksi anu diterbitkeun.

Catetan: kusabab keterbatasan sareng interpretasi GitHub ngeunaan markdown (sareng seueur unggal penafsiran markdown dumasar kana wéb sanés) ngaklik tautan ieu bakal ngarahkeun anjeun kana file anu misah dina halaman anu sanés halaman profil GitHub kuring. Anjeun bakal dialihkeun ka [seanpm2001 / seanpm2001 Repository] (https://github.com/seanpm2001/seanpm2001), dimana README disimpen.

Tarjamahan dilakukeun ku Google Translate kusabab terbatas atanapi henteu aya dukungan pikeun basa-basa anu kuring peryogikeun dina jasa tarjamahan anu sanés sapertos DeepL sareng Bing Translate. Kuring nuju milarian milarian alternatif. Kusabab kitu, pormatna (tautan, pamisah, kandel, miring, sareng sajabana) kacau dina sababaraha tarjamahan. Éta matak ngamudahkeun pikeun ngalereskeun, sareng kuring henteu terang kumaha ngalereskeun masalah ieu dina basa anu nganggo karakter sanés latin, sareng basa katuhu ka kénca (sapertos basa Arab) peryogi bantosan tambahan pikeun ngalereskeun masalah ieu

Kusabab masalah pangropéa, seueur tarjamahan anu kadaluarsa sareng nganggo pérsi kuno tina file artikel `README` ieu. Panarjamah peryogi. Ogé, dugi ka 22 April 2021, éta bakal ngabutuhkeun kuring bari nyandak sadaya tautan énggal jalan.

***

# Indéks

[00.0 - Top] (# Top)

> [00.1 - Judul] (# CamCamPlus)

> [00.2 - Maca tulisan ieu dina basa anu béda] (# Read-this-article-in-a-béda-basa)

> [00.3 - Indéks] (# Indéks)

[01.0 - Pedaran] (# CamCamPlus)

[02.0 - Ngeunaan] (# Ngeunaan)

[03.0 - Wiki] (# Wiki)

[04.0 - Riwayat versi] (# Vérsi-sajarah)

[05.0 - Status parangkat lunak] (# Parangkat lunak-status)

[06.0 - Inpormasi sponsor] (# Info sponsor-info)

[07.0 - Kontributor] (# Kontributor)

[08.0 - Masalah] (# Masalah)

> [08.1 - Masalah ayeuna] (# Ayeuna-terbitan)

> [08.2 - Masalah baheula] (# Kapungkur-terbitan)

> [08.3 - Paménta narik baheula] (# Kaliwat-tarik-pamundut)

> [08.4 - Permintaan tarik aktip] (# Aktip-tarik-aktip)

[09.0 - Sumber] [# Sumberdaya]

[10.0 - Nyumbangkeun] (# Nyumbangkeun)

[11.0 - Ngeunaan README] (# About-README)

[12.0 - Riwayat Vérsi README] (# README-versi-sajarah)

[13.0 - Footer] (# Anjeun-parantos ngahontal-tungtung-of-the-README-file)

> [13.1 - Tungtung file] (# EOF)

***

# CamCamPlus
CamCamPlus mangrupikeun kaméra gratis sareng sumber terbuka luhur anu tiasa nyandak gambar sareng video dina seueur format, sareng seueur résolusi.

***

## Ngeunaan

Tingali di luhur. Proyék ieu ngeunaan kaméra sumber kabuka anu kuat anu masihan seueur pilihan sareng ngarobih halangan anu ngagaduhan aplikasi kaméra umum sanés (sapertos wates rékaman 30 menit)

***

## Wiki

[Pencét / ketuk di dieu pikeun ningali proyék ieu Wiki] (https://github.com/seanpm2001/CamCamPlus/wiki)

Upami proyekna parantos garpu, Wiki sigana bakal dihapus. Kabeneran, kuring kaasup vérsi anu dilebetkeun. Anjeun tiasa ningali éta [didieu] (/ Éksternal / ProjectWiki /).

***

## Inpo sponsor

! [Sponsor Button.png] (Sponsor Button.png)

Anjeun tiasa sponsor proyék ieu upami anjeun resep, tapi punten tangtukeun naon anu rék disumbangkeun. [Tingali dana anjeun tiasa nyumbang ka dieu] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Anjeun tiasa ningali inpormasi sponsor sanésna [didieu] (https://github.com/seanpm2001/Sponsor-info/)

Coba éta! Tombol sponsor langsung aya di gigireun tombol nonton / henteu dibuka.

***

## Sejarah vérsi

** Riwayat versi ayeuna teu aya **

** Teu aya vérsi séjén anu didaptarkeun **

***

## Status parangkat lunak

Sadaya padamelan abdi gratis sababaraha larangan. DRM (** D ** igital ** R ** estructions ** M ** anagement) henteu aya dina karya kuring.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Stiker ieu dirojong ku Free Yayasan Parangkat Lunak. Kuring henteu pernah niat ngalebetkeun DRM dina karya kuring.

Kuring ngagunakeun singketan "Digital Watesan Manajemén" tibatan anu langkung dikenal "Digital Rights Management" salaku cara umum pikeun nyebatkeun éta palsu, teu aya hak sareng DRM. Éjahan "Manajemén Watesan Digital" langkung akurat, sareng dirojong ku [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) sareng [Free Software Foundation (FSF)] ( https://id.wikipedia.org/wiki/Free_Software_Foundation)

Bagéan ieu dipaké pikeun ningkatkeun kasadaran pikeun masalah anu aya dina DRM, sareng ogé protés. DRM rusak ku desain sareng mangrupikeun ancaman utama pikeun sadaya pangguna komputer sareng kabébasan parangkat lunak.

Kiridit gambar: [defectivebydesign.org/drm-free/...gris(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Kontributor

Ayeuna, kuring ngan ukur kontributer. Kontribusi diidinan, salami anjeun nuturkeun aturan file [CONTRIBUTING.md] (CONTRIBUTING.md) file.

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 ngalakukeun (Sapertos Kemis, 22 April 2021 tabuh 6:30 sonten)

> * 2. Teu aya kontributor anu sanés.

***

## Masalah

### Masalah ayeuna

* Teu aya ayeuna-ayeuna

* Henteu aya masalah anu sanés

Upami Repositoryna parantos garpu, masalah sigana bakal dihapus. Kabeneran kuring nyimpen arsip gambar tangtu [didieu] (/. Github / Issues /)

[Maca kabijakan privasi ngeunaan arsip édisi di dieu] (/. Github / Issues / README.md)

** TL; DR **

Kuring ngarsipkeun masalah kuring nyalira. Masalah anjeun moal diarsipkeun kecuali anjeun nyungkeun arsip.

### Masalah kapungkur

* Teu aya ayeuna-ayeuna

* Teu aya masalah anu kapengker

Upami Repositoryna parantos garpu, masalah sigana bakal dihapus. Kabeneran kuring nyimpen arsip gambar tangtu [didieu] (/. Github / Issues /)

[Maca kabijakan privasi ngeunaan arsip édisi di dieu] (/. Github / Issues / README.md)

** TL; DR **

Kuring ngarsipkeun masalah kuring nyalira. Masalah anjeun moal diarsipkeun kecuali anjeun nyungkeun arsip.

### Paménta narik baheula

* Teu aya ayeuna-ayeuna

* Teu aya pamundut narik anu kapengker

Upami Repositoryna parantos garpu, masalah sigana bakal dihapus. Kabeneran kuring nyimpen arsip gambar tangtu [didieu] (/. Github / Issues /)

[Maca kabijakan privasi ngeunaan arsip édisi di dieu] (/. Github / Issues / README.md)

** TL; DR **

Kuring ngarsipkeun masalah kuring nyalira. Masalah anjeun moal diarsipkeun kecuali anjeun nyungkeun arsip.

### Pénta tarik aktip

* Teu aya ayeuna-ayeuna

* Teu aya pamundut narik anu aktip

Upami Repositoryna parantos garpu, masalah sigana bakal dihapus. Kabeneran kuring nyimpen arsip gambar tangtu [didieu] (/. Github / Issues /)

[Maca kabijakan privasi ngeunaan arsip édisi di dieu] (/. Github / Issues / README.md)

** TL; DR **

Kuring ngarsipkeun masalah kuring nyalira. Masalah anjeun moal diarsipkeun kecuali anjeun nyungkeun arsip.

***

## Sumberdaya

Ieu sababaraha sumber daya sanés pikeun proyék ieu:

[Payil bahasa proyék] (PROJECT_LANG.cpp)

[Perpustakaan rujukan panilitian pikeun proyék ieu] (/ Rujukan /)

[Modul pidéo khusus pikeun proyék ieu (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[Miluan diskusi dina GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

Teu aya sumber daya sanés ayeuna.

***

## Nyumbangkeun

Kontribusi diidinan pikeun proyék ieu, salami anjeun nuturkeun aturan file `CONTRIBUTING.md`.

[Klik / ketok di dieu pikeun ningali aturan kontribusina pikeun proyék ieu] (CONTRIBUTING.md)

***

## Ngeunaan README

Jenis file: `Markdown (* .md)`

Vérsi file: `1 (Kemis, 22 April 2021 tabuh 6:30 sonten)`

Jumlah garis: `0,306`

***

## Sejarah versi README

Vérsi 1 (Kemis, 22 April 2021 tabuh 6:30 sonten)

> Parobihan:

> * Ngamimitian file na

> * Ditambahkeun bagian judulna

> * Ditambahkeun indéks na

> * Ditambahkeun perkawis bagian

> * Ditambahkeun bagian Wiki

> * Ditambahkeun bagian riwayat vérsi

> * Ditambahkeun bagian masalah.

> * Ditambahkeun bagian masalah anu katukang

> * Ditambahkeun bagian paménta narik anu kapengker

> * Ditambahkeun bagian permintaan tarik aktif

> * Ditambahkeun bagian kontributor

> * Ditambahkeun bagian anu nyumbang

> * Ditambahkeun ngeunaan bagian README

> * Ditambahkeun bagian riwayat vérsi README

> * Ditambahkeun bagian sumberdaya

> * Nambahkeun bagian status parangkat lunak, kalayan stiker sareng pesen gratis DRM

> * Ditambahkeun bagian inpormasi sponsor

> * Teu aya parobahan anu sanés dina vérsi 1

Vérsi 2 (Kadieu)

> Parobihan:

> * Kadieu

> * Teu aya parobahan anu sanés dina vérsi 2

***

### Anjeun parantos ngahontal tungtung file README

[Balik deui ka luhur] (# Top) [Exit] (https://github.com)

### EOF

***
