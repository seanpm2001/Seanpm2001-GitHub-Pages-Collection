***

＃カムカムプラス（CC +）

！[{プロジェクトアイコン}この画像を読み込めませんでした。ファイルに到達していないか、一般的なエラーが原因である可能性があります。考えられる一般的なエラーを修正するには、ページを再読み込みしてください。]（/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg）

＃ 沿って：

## [Seanpm2001]（https://github.com/seanpm2001）およびその他の寄稿者

＃＃＃ 上

＃ `README.md`

***

##この記事を別の言語で読む

**現在の言語は次のとおりです：** `英語（米国）` _（正しい言語を置き換える英語を修正するには、翻訳を修正する必要がある場合があります）_

_🌐言語のリスト_

**並べ替え：** `A-Z`

[並べ替えオプションは利用できません]（https://github.com/Degoogle-your-Life）

（[af Afrikaans]（/。github / README_AF.md）Afrikaans | [sq Shqiptare]（/。github / README_SQ.md）アルバニア語| [amአርኛ]（/。github / README_AM.md）アルメニア語| [arعربى] （/.github/README_AR.md）アラビア語| [hyհայերեն]（/。github / README_HY.md）アルメニア語| [azAzərbaycandili]（/。github / README_AZ.md）Azerbaijani | [eu Euskara]（/。github /README_EU.md）バスク語| [beБеларуская]（/。github / README_BE.md）ベラルーシ語| [bnবাংলা]（/。github / README_BN.md）ベンガリ語| [bs Bosanski]（/。github / README_BSバスク語| [bgбългарски]（/。github / README_BG.md）ブルガリア語| [caCatalà]（/。github / README_CA.md）カタロニア語| [ceb Sugbuanon]（/。github / README_CEB.md）Cebuano | [ny Chichewa ]（/。github / README_NY.md）Chichewa | [zh-CN简体中文]（/。github / README_ZH-CN.md）中国語（簡略化）| [zh-t中國傳統的）]（/。github / README_ZH -T.md）中国語（従来）| [co Corsu]（/。github / README_CO.md）コルシカ語| [hr Hrvatski]（/。github / README_HR.md）クロアチア語| [csčeština]（/。github / README_CS .md）チェコ語| [da dansk]（README_DA.md）デンマーク語| [nl Nederlands]（/。github / README_ NL.md）オランダ語| [** en-us英語**]（/。github / README.md）英語| [EOエスペラント]（/。github / README_EO.md）エスペラント| [et Eestlane]（/。github / README_ET.md）エストニア語| [tl Pilipino]（/。github / README_TL.md）フィリピン人| [fi Suomalainen]（/。github / README_FI.md）フィンランド語| [frfrançais]（/。github / README_FR.md）フランス語| [fy Frysk]（/。github / README_FY.md）フリジア語| [gl Galego]（/。github / README_GL.md）ガリシア語| [kaქართველი]（/。github / README_KA）グルジア語| [de Deutsch]（/。github / README_DE.md）ドイツ語| [elΕλληνικά]（/。github / README_EL.md）ギリシャ語| [guગુજરાતી]（/。github / README_GU.md）グジャラート語| [htKreyòlayisyen]（/。github / README_HT.md）ハイチ語クレオール語| [haハウサ語]（/。github / README_HA.md）ハウサ語| [hawŌleloHawaiʻi]（/。github / README_HAW.md）ハワイ語| [彼はעִברִית]（/。github / README_HE.md）ヘブライ語| [こんにちはहिन्दी]（/。github / README_HI.md）ヒンディー語| [hmn Hmong]（/。github / README_HMN.md）モン族| [hu Magyar]（/。github / README_HU.md）ハンガリー語| [isÍslenska]（/。github / README_IS.md）アイスランド語| [ig Igbo]（/。github / README_IG.md）Igbo | [id bahasa Indonesia]（/。github / README_ID.md）アイスランド語| [ga Gaeilge]（/。github / README_GA.md）アイルランド語| [イタリア語/イタリア語]（/。github / README_IT.md）| [ja日本語]（/。github / README_JA.md）日本語| [jw Wongjawa]（/。github / README_JW.md）ジャワ語| [knಕನ್ನಡ]（/。github / README_KN.md）カンナダ語| [kkҚазақ]（/。github / README_KK.md）カザフ語| [kmខ្មែរ]（/。github / README_KM.md）クメール語| [rw Kinyarwanda]（/。github / README_RW.md）Kinyarwanda | [ko-south韓國語]（/。github / README_KO_SOUTH.md）韓国語（南）| [ko-north문화어]（README_KO_NORTH.md）韓国語（北）（まだ翻訳されていません）| [kuKurdî]（/。github / README_KU.md）クルド語（クルマンジー）| [kyКыргызча]（/。github / README_KY.md）キルギス語| [loລາວ]（/。github / README_LO.md）ラオス| [la Latine]（/。github / README_LA.md）ラテン語| [lt Lietuvis]（/。github / README_LT.md）リトアニア語| [lbLëtzebuergesch]（/。github / README_LB.md）ルクセンブルク語| [mkМакедонски]（/。github / README_MK.md）マケドニア語| [mgマダガスカル]（/。github / README_MG.md）マダガスカル| [ms Bahasa Melayu]（/。github / README_MS.md）マレー語| [mlമലയാളം]（/。github / README_ML.md）マラヤーラム語| [mt Malti]（/。github / README_MT.md）マルタ語| [miマオリ]（/。github / README_MI.md）マオリ| [mrमराठी]（/。github / README_MR.md）マラーティー語| [mnМонгол]（/。github / README_MN.md）モンゴル語| [myမြန်မာ]（/。github / README_MY.md）ミャンマー（ビルマ語）| [neनेपाली]（/。github / README_NE.md）ネパール語| [norskなし]（/。github / README_NO.md）ノルウェー語| [またはଓଡିଆ（ଓଡିଆ）]（/。github / README_OR.md）オディア語（オリヤー語）| [psپښتو]（/。github / README_PS.md）パシュトゥー語| [faفارسی]（/。github / README_FA.md）|ペルシア語[pl polski]（/。github / README_PL.md）ポーランド語| [ptportuguês]（/。github / README_PT.md）ポルトガル語| [paਪੰਜਾਬੀ]（/。github / README_PA.md）パンジャブ語|文字Qで始まる言語はありません| [roRomână]（/。github / README_RO.md）ルーマニア語| [ruрусский]（/。github / README_RU.md）ロシア語| [sm Faasamoa]（/。github / README_SM.md）サモア語| [gdGàidhlignah-Alba]（/。github / README_GD.md）スコットランドゲール語| [srСрпски]（/。github / README_SR.md）セルビア語| [st Sesotho]（/。github / README_ST.md）セソト語| [snショナ語]（/。github / README_SN.md）ショナ語| [sdسنڌي]（/。github / README_SD.md）シンド語| [siසිංහල]（/。github / README_SI.md）シンハラ語| [skスロバキア語]（/。github / README_SK.md）スロバキア語| [slSlovenščina]（/。github / README_SL.md）スロベニア語| [so Soomaali]（/。github / README_SO.md）ソマリア語| [[esenespañol]（/。github / README_ES.md）スペイン語| [su Sundanis]（/。github / README_SU.md）Sundanese | [sw Kiswahili]（/。github / README_SW.md）スワヒリ語| [sv Svenska]（/。github / README_SV.md）スウェーデン語| [tgТоҷикӣ]（/。github / README_TG.md）タジク語| [taதமிழ்]（/。github / README_TA.md）タミル語| [ttТатар]（/。github / README_TT.md）タタール| [teతెలుగు]（/。github / README_TE.md）テルグ語| [thไทย]（/。github / README_TH.md）タイ語| [trTürk]（/。github / README_TR.md）トルコ語| [tkTürkmenler]（/。github / README_TK.md）トルクメン語| [ukУкраїнський]（/。github / README_UK.md）ウクライナ語| [urاردو]（/。github / README_UR.md）ウルドゥー語| [ugئۇيغۇر]（/。github / README_UG.md）ウイグル| [uz O'zbek]（/。github / README_UZ.md）ウズベク語| [viTiếngViệt]（/。github / README_VI.md）ベトナム語| [cy Cymraeg]（/。github / README_CY.md）ウェールズ語| [xh isiXhosa]（/。github / README_XH.md）コサ語| [yiיידיש]（/。github / README_YI.md）イディッシュ語| [ヨルバ語]（/。github / README_YO.md）ヨルバ語| [zu Zulu]（/。github / README_ZU.md）Zulu）110言語で利用可能（北朝鮮語はまだ翻訳されていないため、英語と北朝鮮語を数えない場合は108言語[ここで読む]（/ OldVersions / Korean（North ）/README.md））

英語以外の言語での翻訳は機械翻訳されており、まだ正確ではありません。 2021年2月5日の時点では、エラーはまだ修正されていません。翻訳エラーを報告してください[ここ]（https://github.com/seanpm2001/CamCamPlus/issues/）必ずソースを使用して修正をバックアップし、ガイドしてください。英語以外の言語がよくわからない（最終的には翻訳者を雇う予定です）レポートで[wiktionary]（https://en.wiktionary.org）やその他の情報源を引用してください。そうしないと、公開されている修正が拒否されます。

注：GitHubのマークダウンの解釈（および他のほとんどすべてのWebベースのマークダウンの解釈）の制限により、これらのリンクをクリックすると、GitHubプロファイルページではない別のページの別のファイルにリダイレクトされます。 READMEがホストされている[seanpm2001 / seanpm2001リポジトリ]（https://github.com/seanpm2001/seanpm2001）にリダイレクトされます。

DeepLやBingTranslateなどの他の翻訳サービスで必要な言語が制限されているか、サポートされていないため、翻訳はGoogle翻訳で行われます。私は代替案を見つけることに取り組んでいます。何らかの理由で、フォーマット（リンク、仕切り、太字、斜体など）がさまざまな翻訳で混乱しています。修正するのは面倒で、ラテン文字以外の言語でこれらの問題を修正する方法がわかりません。これらの問題を修正するには、右から左への言語（アラビア語など）で追加のヘルプが必要です。

メンテナンスの問題により、多くの翻訳は古く、この「README」記事ファイルの古いバージョンを使用しています。翻訳者が必要です。また、2021年4月22日の時点で、すべての新しいリンクが機能するようになるまでしばらく時間がかかります。

***

＃インデックス

[00.0-トップ]（＃Top）

> [00.1-タイトル]（＃CamCamPlus）

> [00.2-この記事を別の言語で読む]（＃Read-this-article-in-a-different-language）

> [00.3-インデックス]（＃インデックス）

[01.0-説明]（＃CamCamPlus）

[02.0-概要]（＃概要）

[03.0-Wiki]（＃Wiki）

[04.0-バージョン履歴]（＃Version-history）

[05.0-ソフトウェアステータス]（＃Software-status）

[06.0-スポンサー情報]（＃Sponsor-info）

[07.0-寄稿者]（＃寄稿者）

[08.0-問題]（＃問題）

> [08.1-現在の問題]（＃Current-issues）

> [08.2-過去の問題]（＃過去の問題）

> [08.3-過去のプルリクエスト]（＃Past-pull-requests）

> [08.4-アクティブなプルリクエスト]（＃Active-pull-requests）

[09.0-リソース]（＃Resources）

[10.0-寄稿]（＃寄稿）

[11.0-READMEについて]（＃About-README）

[12.0-READMEバージョン履歴]（＃README-バージョン履歴）

[13.0-フッター]（＃You-have-reached-the-end-of-the-README-file）

> [13.1-ファイルの終わり]（＃EOF）

***

＃CamCamPlus
CamCamPlusは、さまざまな形式、さまざまな解像度で写真やビデオを撮影できる、ハイエンドの無料のオープンソースカメラです。

***

＃＃ 約

上記を参照。このプロジェクトは、他の一般的なカメラアプリが持つ多くのオプションを提供し、障壁を打ち破るオープンソースの強力なカメラに関するものです（30分の記録制限など）

***

## Wiki

[このプロジェクトを表示するには、ここをクリック/タップしてくださいWiki]（https://github.com/seanpm2001/CamCamPlus/wiki）

プロジェクトがフォークされている場合、Wikiは削除されている可能性があります。幸いなことに、私は埋め込みバージョンを含めています。あなたはそれを[ここ]（/ External / ProjectWiki /）で見ることができます。

***

##スポンサー情報

！[SponsorButton.png]（SponsorButton.png）

必要に応じてこのプロジェクトを後援することができますが、寄付したいものを指定してください。 [ここに寄付できる資金を参照してください]（https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors）

他のスポンサー情報を表示できます[ここ]（https://github.com/seanpm2001/Sponsor-info/）

やってみて！スポンサーボタンは、ウォッチ/アンウォッチボタンのすぐ隣にあります。

***

##バージョン履歴

**バージョン履歴は現在利用できません**

**他のバージョンはリストされていません**

***

##ソフトウェアステータス

私の作品はすべて無料ですが、いくつかの制限があります。 DRM（** D ** igital ** R ** estrictions ** M ** anagement）は私の作品のいずれにも存在しません。

！[DRM-free_label.en.svg]（DRM-free_label.en.svg）

このステッカーはFreによってサポートされていますeソフトウェアファンデーション。私は自分の作品にDRMを含めるつもりはありません。

私は、より一般的な「デジタル著作権管理」の代わりに「デジタル制限管理」という略語を使用しています。これは、DRMには権利がないという一般的な対処方法です。 「デジタル制限管理」のスペルはより正確であり、[Richard M. Stallman（RMS）]（https://en.wikipedia.org/wiki/Richard_Stallman）および[Free Software Foundation（FSF）]（ https://en.wikipedia.org/wiki/Free_Software_Foundation）

このセクションは、DRMの問題に対する認識を高め、それに抗議するために使用されます。 DRMは設計上欠陥があり、すべてのコンピューターユーザーとソフトウェアの自由に対する大きな脅威です。

画像クレジット：[defectivebydesign.org/drm-free /...]（https://www.defectivebydesign.org/drm-free/how-to-use-label）

***

##寄稿者

現在、私が唯一の貢献者です。 [CONTRIBUTING.md]（CONTRIBUTING.md）ファイルのルールに従っている限り、投稿は許可されます。

> * 1. [seanpm2001]（https://github.com/seanpm2001/）-138コミット（2021年4月22日木曜日午後6時30分現在）

> * 2。他の貢献者はいません。

***

##問題

###現在の問題

*現時点ではありません

*その他の現在の問題はありません

リポジトリがフォークされている場合は、問題が削除されている可能性があります。幸いなことに、私は特定の画像のアーカイブを保持しています[ここ]（/。github / Issues /）

[問題のアーカイブに関するプライバシーポリシーをここで読んでください]（/。github / Issues / README.md）

** TL; DR **

私は自分の問題をアーカイブします。アーカイブをリクエストしない限り、問題はアーカイブされません。

###過去の問題

*現時点ではありません

*他の過去の問題はありません

リポジトリがフォークされている場合は、問題が削除されている可能性があります。幸いなことに、私は特定の画像のアーカイブを保持しています[ここ]（/。github / Issues /）

[問題のアーカイブに関するプライバシーポリシーをここで読んでください]（/。github / Issues / README.md）

** TL; DR **

私は自分の問題をアーカイブします。アーカイブをリクエストしない限り、問題はアーカイブされません。

###過去のプルリクエスト

*現時点ではありません

*他の過去のプルリクエストはありません

リポジトリがフォークされている場合は、問題が削除されている可能性があります。幸いなことに、私は特定の画像のアーカイブを保持しています[ここ]（/。github / Issues /）

[問題のアーカイブに関するプライバシーポリシーをここで読んでください]（/。github / Issues / README.md）

** TL; DR **

私は自分の問題をアーカイブします。アーカイブをリクエストしない限り、問題はアーカイブされません。

###アクティブなプルリクエスト

*現時点ではありません

*他のアクティブなプルリクエストはありません

リポジトリがフォークされている場合は、問題が削除されている可能性があります。幸いなことに、私は特定の画像のアーカイブを保持しています[ここ]（/。github / Issues /）

[問題のアーカイブに関するプライバシーポリシーをここで読んでください]（/。github / Issues / README.md）

** TL; DR **

私は自分の問題をアーカイブします。アーカイブをリクエストしない限り、問題はアーカイブされません。

***

##リソース

このプロジェクトの他のリソースは次のとおりです。

[プロジェクト言語ファイル]（PROJECT_LANG.cpp）

[このプロジェクトの研究参照ライブラリ]（/ References /）

[このプロジェクトの特別なビデオモジュール（SVGビデオ）]（https://github.com/seanpm2001/SVG_Video/）

[GitHubのディスカッションに参加してください]（https://github.com/seanpm2001/CamCamPlus/discussions）

現在、他のリソースはありません。

***

##貢献

`CONTRIBUTING.md`ファイルのルールに従っている限り、このプロジェクトへの貢献は許可されています。

[このプロジェクトの貢献ルールを表示するには、ここをクリック/タップしてください]（CONTRIBUTING.md）

***

## READMEについて

ファイルタイプ： `Markdown（* .md）`

ファイルバージョン： `1（2021年4月22日木曜日午後6時30分）`

行数： `0,306`

***

## READMEのバージョン履歴

バージョン1（2021年4月22日木曜日午後6時30分）

>変更：

> *ファイルを開始しました

> *タイトルセクションを追加しました

> *インデックスを追加しました

> * aboutセクションを追加しました

> * Wikiセクションを追加しました

> *バージョン履歴セクションを追加しました

> *問題のセクションを追加しました。

> *過去の問題のセクションを追加しました

> *過去のプルリクエストセクションを追加しました

> *アクティブなプルリクエストセクションを追加しました

> *寄稿者セクションを追加しました

> *寄稿セクションを追加しました

> * READMEについてのセクションを追加しました

> * READMEバージョン履歴セクションを追加しました

> *リソースセクションを追加しました

> * DRMフリーのステッカーとメッセージを含むソフトウェアステータスセクションを追加しました

> *スポンサー情報セクションを追加しました

> *バージョン1で他の変更はありません

バージョン2（近日公開）

>変更：

> *近日公開

> *バージョン2で他の変更はありません

***

### READMEファイルの最後に到達しました

[トップに戻る]（＃Top）[終了]（https://github.com）

### EOF

***
