***

# Cam Cam Plus (CC +)

! [{Project icon} Gambar ini gagal dimuat. Mungkin karena file tidak terjangkau, atau kesalahan umum. Muat ulang halaman untuk memperbaiki kemungkinan kesalahan umum.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Oleh:

## [Seanpm2001] (https://github.com/seanpm2001) dan kontributor lainnya

### Atas

# `README.md`

***

## Baca artikel ini dalam bahasa lain

** Bahasa saat ini adalah: ** `` English (US) `_ (terjemahan mungkin perlu diperbaiki untuk memperbaiki bahasa Inggris menggantikan bahasa yang benar) _

_🌐 Daftar bahasa_

** Diurutkan berdasarkan: ** `A-Z`

[Opsi penyortiran tidak tersedia] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albania | [am አማርኛ] (/. github / README_AM.md) Amharik | [ar عربى] (/.github/README_AR.md) Arab | [hy հայերեն] (/. github / README_HY.md) Armenia | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijan | [eu Euskara] (/. github /README_EU.md) Basque | [be Беларуская] (/. Github / README_BE.md) Belarusia | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) Bulgaria | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) China (Sederhana) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) China (Tradisional) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Kroasia | [cs čeština] (/. Github / README_CS .md) Ceko | [da dansk] (README_DA.md) Denmark | [nl Nederlands] (/. github / README_ NL.md) Belanda | [** en-us English **] (/. github / README.md) Inggris | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonia | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finlandia | [fr français] (/. github / README_FR.md) Prancis | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galisia | [ka ქართველი] (/. github / README_KA) Georgia | [de Deutsch] (/. github / README_DE.md) Jerman | [el Ελληνικά] (/. github / README_EL.md) Yunani | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Kreol Haiti | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) Ibrani | [hai हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hungaria | [adalah Íslenska] (/. github / README_IS.md) Islandia | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandia | [ga Gaeilge] (/. github / README_GA.md) Irlandia | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Jepang | [jw Wong jawa] (/. github / README_JW.md) Jawa | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Korea (Selatan) | [ko-north 문화어] (README_KO_NORTH.md) Korea (Utara) (BELUM DITERJEMAHKAN) | [ku Kurdî] (/. github / README_KU.md) Kurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgistan | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lituavi | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksemburg | [mk Македонски] (/. github / README_MK.md) Makedonia | [mg Malagasi] (/. github / README_MG.md) Malagasi | [ms Bahasa Melayu] (/. github / README_MS.md) Melayu | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Malta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolia | [မြန်မာ saya] (/. github / README_MY.md) Myanmar (Burma) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) Norsk | [atau ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persia [pl polski] (/. github / README_PL.md) Polandia | [pt português] (/. github / README_PT.md) Portugis | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Tidak ada bahasa yang dimulai dengan huruf Q | [ro Română] (/. github / README_RO.md) Rumania | [ru русский] (/. github / README_RU.md) Rusia | [sm Faasamoa] (/. github / README_SM.md) Samoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Gaelik Skotlandia | [sr Српски] (/. github / README_SR.md) Serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slowakia | [sl Slovenščina] (/. github / README_SL.md) Slovenia | [jadi Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spanyol | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Swensk | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Turki | [tk Türkmenler] (/. github / README_TK.md) Turkmenistan | [uk Український] (/. github / README_UK.md) Ukraina | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnam | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Tersedia dalam 110 bahasa (108 jika tidak termasuk Inggris dan Korea Utara, karena Korea Utara belum diterjemahkan [Baca tentang itu di sini] (/ Versi Lama / Korea (Utara ) /README.md))

Terjemahan dalam bahasa selain bahasa Inggris adalah terjemahan mesin dan belum akurat. Belum ada kesalahan yang diperbaiki per 5 Februari 2021. Laporkan kesalahan terjemahan [di sini] (https://github.com/seanpm2001/CamCamPlus/issues/) pastikan untuk mencadangkan koreksi Anda dengan sumber dan pandu saya, karena saya tidak Saya tidak tahu bahasa selain bahasa Inggris dengan baik (saya berencana untuk mendapatkan penerjemah pada akhirnya) harap kutip [wiktionary] (https://en.wiktionary.org) dan sumber lain dalam laporan Anda. Gagal melakukannya akan mengakibatkan penolakan publikasi koreksi.

Catatan: karena keterbatasan interpretasi GitHub tentang penurunan harga (dan hampir semua interpretasi penurunan harga berbasis web lainnya) mengklik tautan ini akan mengarahkan Anda ke file terpisah di halaman terpisah yang bukan halaman profil GitHub saya. Anda akan dialihkan ke [repositori seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), tempat README dihosting.

Terjemahan dilakukan dengan Google Terjemahan karena dukungan terbatas atau tidak ada untuk bahasa yang saya butuhkan di layanan terjemahan lain seperti DeepL dan Bing Translate. Saya sedang berusaha mencari alternatif. Untuk beberapa alasan, pemformatan (tautan, pemisah, cetak tebal, miring, dll.) Kacau dalam berbagai terjemahan. Membosankan untuk memperbaikinya, dan saya tidak tahu cara memperbaiki masalah ini dalam bahasa dengan karakter non-latin, dan bahasa kanan ke kiri (seperti bahasa Arab) diperlukan bantuan tambahan untuk memperbaiki masalah ini.

Karena masalah pemeliharaan, banyak terjemahan yang kedaluwarsa dan menggunakan versi lama dari file artikel `README` ini. Seorang penerjemah dibutuhkan. Selain itu, mulai 22 April 2021, saya memerlukan beberapa saat untuk membuat semua tautan baru berfungsi.

***

# Indeks

[00.0 - Atas] (# Atas)

> [00.1 - Judul] (# CamCamPlus)

> [00.2 - Baca artikel ini dalam bahasa lain] (# Baca-artikel-ini-dalam-bahasa-bahasa-yang-berbeda)

> [00.3 - Indeks] (# Indeks)

[01.0 - Deskripsi] (# CamCamPlus)

[02.0 - Tentang] (# Tentang)

[03.0 - Wiki] (# Wiki)

[04.0 - Riwayat versi] (# Riwayat versi)

[05.0 - Status perangkat lunak] (# Status-perangkat lunak)

[06.0 - Info Sponsor] (# Info-Sponsor)

[07.0 - Kontributor] (# Kontributor)

[08.0 - Masalah] (# Masalah)

> [08.1 - Masalah saat ini] (# Masalah saat ini)

> [08.2 - Masalah sebelumnya] (# Masalah sebelumnya)

> [08.3 - Permintaan penarikan sebelumnya] (# Permintaan tarik-lalu)

> [08.4 - Permintaan penarikan aktif] (# Permintaan-tarik-aktif)

[09.0 - Sumber Daya] (# Sumber Daya)

[10.0 - Berkontribusi] (# Berkontribusi)

[11.0 - Tentang README] (# About-README)

[12.0 - README Version history] (# README-version-history)

[13.0 - Footer] (# Anda-telah-mencapai-akhir-file-README-)

> [13.1 - Akhir file] (# EOF)

***

# CamCamPlus
CamCamPlus adalah kamera sumber terbuka dan gratis kelas atas yang dapat mengambil gambar dan video dalam banyak format, dan banyak resolusi.

***

## Tentang

Lihat di atas. Proyek ini adalah tentang kamera open source yang kuat yang memberikan banyak pilihan dan mendobrak penghalang yang dimiliki aplikasi kamera umum lainnya (seperti batas perekaman 30 menit)

***

## Wiki

[Klik / ketuk di sini untuk melihat Wiki proyek ini] (https://github.com/seanpm2001/CamCamPlus/wiki)

Jika proyek telah bercabang, Wiki kemungkinan besar telah dihapus. Untungnya, saya menyertakan versi yang disematkan. Anda dapat melihatnya [di sini] (/ Eksternal / ProjectWiki /).

***

## Info sponsor

! [SponsorButton.png] (SponsorButton.png)

Anda dapat mensponsori proyek ini jika Anda suka, tetapi harap tentukan tujuan donasi Anda. [Lihat dana yang dapat Anda donasikan ke sini] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Anda dapat melihat info sponsor lainnya [di sini] (https://github.com/seanpm2001/Sponsor-info/)

Cobalah! Tombol sponsor berada tepat di sebelah tombol tonton / buka.

***

## Riwayat versi

** Riwayat versi saat ini tidak tersedia **

** Tidak ada versi lain yang terdaftar **

***

## Status perangkat lunak

Semua karya saya bebas beberapa batasan. DRM (** D ** igital ** R ** estrictions ** M ** anagement) tidak ada di semua karya saya.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Stiker ini didukung oleh Free Fondasi Perangkat Lunak. Saya tidak pernah berniat untuk memasukkan DRM ke dalam karya saya.

Saya menggunakan singkatan "Digital Restrictions Management" dan bukan "Digital Rights Management" karena cara umum untuk mengatasinya adalah salah, tidak ada hak dengan DRM. Ejaan "Digital Restrictions Management" lebih akurat, dan didukung oleh [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) dan [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Bagian ini digunakan untuk meningkatkan kesadaran akan masalah DRM, dan juga untuk memprotesnya. DRM memiliki desain yang rusak dan merupakan ancaman utama bagi semua pengguna komputer dan kebebasan perangkat lunak.

Kredit gambar: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Kontributor

Saat ini saya satu-satunya kontributor. Berkontribusi diperbolehkan, selama Anda mengikuti aturan dari file [CONTRIBUTING.md] (CONTRIBUTING.md).

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 komitmen (Mulai Kamis, 22 April 2021 pukul 18.30)

> * 2. Tidak ada kontributor lainnya.

***

## Masalah

### Isu saat ini

* Tidak ada saat ini

* Tidak ada masalah lain saat ini

Jika repositori telah bercabang, masalah kemungkinan besar telah dihapus. Untungnya saya menyimpan arsip gambar tertentu [di sini] (/. Github / Issues /)

[Baca kebijakan privasi tentang arsip masalah di sini] (/. Github / Issues / README.md)

** TL; DR **

Saya mengarsipkan masalah saya sendiri. Masalah Anda tidak akan diarsipkan kecuali Anda memintanya untuk diarsipkan.

### Masalah sebelumnya

* Tidak ada saat ini

* Tidak ada masalah masa lalu lainnya

Jika repositori telah bercabang, masalah kemungkinan besar telah dihapus. Untungnya saya menyimpan arsip gambar tertentu [di sini] (/. Github / Issues /)

[Baca kebijakan privasi tentang arsip masalah di sini] (/. Github / Issues / README.md)

** TL; DR **

Saya mengarsipkan masalah saya sendiri. Masalah Anda tidak akan diarsipkan kecuali Anda memintanya untuk diarsipkan.

### Permintaan penarikan sebelumnya

* Tidak ada saat ini

* Tidak ada permintaan penarikan masa lalu lainnya

Jika repositori telah bercabang, masalah kemungkinan besar telah dihapus. Untungnya saya menyimpan arsip gambar tertentu [di sini] (/. Github / Issues /)

[Baca kebijakan privasi tentang arsip masalah di sini] (/. Github / Issues / README.md)

** TL; DR **

Saya mengarsipkan masalah saya sendiri. Masalah Anda tidak akan diarsipkan kecuali Anda memintanya untuk diarsipkan.

### Permintaan penarikan aktif

* Tidak ada saat ini

* Tidak ada permintaan tarik aktif lainnya

Jika repositori telah bercabang, masalah kemungkinan besar telah dihapus. Untungnya saya menyimpan arsip gambar tertentu [di sini] (/. Github / Issues /)

[Baca kebijakan privasi tentang arsip masalah di sini] (/. Github / Issues / README.md)

** TL; DR **

Saya mengarsipkan masalah saya sendiri. Masalah Anda tidak akan diarsipkan kecuali Anda memintanya untuk diarsipkan.

***

## Sumber Daya

Berikut beberapa sumber daya lain untuk proyek ini:

[File bahasa proyek] (PROJECT_LANG.cpp)

[Perpustakaan referensi penelitian untuk proyek ini] (/ Referensi /)

[Modul video khusus untuk proyek ini (Video SVG)] (https://github.com/seanpm2001/SVG_Video/)

[Gabung dalam diskusi di GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

Tidak ada sumber daya lain saat ini.

***

## Berkontribusi

Kontribusi diperbolehkan untuk proyek ini, selama Anda mengikuti aturan file `CONTRIBUTING.md`.

[Klik / ketuk di sini untuk melihat aturan kontribusi untuk proyek ini] (CONTRIBUTING.md)

***

## Tentang README

Jenis file: `Markdown (* .md)`

Versi file: `` 1 (Kamis, 22 April 2021 pukul 6:30 sore) `

Jumlah baris: `0,306`

***

## riwayat versi README

Versi 1 (Kamis, 22 April 2021 pukul 18.30)

> Perubahan:

> * Memulai file

> * Menambahkan bagian judul

> * Menambahkan indeks

> * Menambahkan bagian tentang

> * Menambahkan bagian Wiki

> * Menambahkan bagian riwayat versi

> * Menambahkan bagian masalah.

> * Menambahkan bagian masalah sebelumnya

> * Menambahkan bagian permintaan tarik sebelumnya

> * Menambahkan bagian permintaan tarik aktif

> * Menambahkan bagian kontributor

> * Menambahkan bagian berkontribusi

> * Menambahkan bagian tentang README

> * Menambahkan bagian riwayat versi README

> * Menambahkan bagian sumber daya

> * Menambahkan bagian status perangkat lunak, dengan stiker dan pesan gratis DRM

> * Menambahkan bagian info sponsor

> * Tidak ada perubahan lain di versi 1

Versi 2 (Segera hadir)

> Perubahan:

> * Segera hadir

> * Tidak ada perubahan lain di versi 2

***

### Anda telah mencapai bagian akhir file README

[Kembali ke atas] (# Atas) [Keluar] (https://github.com)

### EOF

***
