***

# Cam Cam Plus (CC +)

! { Inaweza kuwa ni kwa sababu ya faili kutofikiwa, au kosa la jumla. Pakia upya ukurasa ili kurekebisha kosa linalowezekana kwa jumla.] (/ Nyaraka / Picha / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Na:

## [Seanpm2001] (https://github.com/seanpm2001) na wachangiaji wengine

### Juu

# "README.md"

***

## Soma nakala hii kwa lugha tofauti

** Lugha ya sasa ni: ** `Kiingereza (Kimarekani)` _ _ (tafsiri zinaweza kuhitaji kurekebishwa ili kurekebisha Kiingereza kuchukua nafasi ya lugha sahihi) _

_🌐 Orodha ya lugha_

** Imepangwa kwa: ** `A-Z`

[Chaguo za kupanga hazipatikani] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanian | [am አማርኛ] (/. github / README_AM.md) Kiamhariki | [ar عربى] (/.github/README_AR.md) Kiarabu | [hy հայերեն] (/. github / README_HY.md) Kiarmenia | [az Azrbaycan dili] (/. github / README_AZ.md) Kiazabajani | [eu Euskara] (/. github) /README_EU.md) Kibasque | [be Беларуская] (/. Github / README_BE.md) Kibelarusi | [bn বাংলা] (/. Github / README_BN.md) Kibengali | [bs Bosanski] (/. Github / README_BS.md) Kibosnia | [bg български] (/. Github / README_BG.md) Kibulgaria | [ca Català] (/. Github / README_CA.md) Kikatalani | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 中文 中文] (/. github / README_ZH-CN.md) Kichina (Kilichorahisishwa) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Kichina (Jadi) | [co Corsu] (/. Github / README_CO.md) Kikosikani | [hr Hrvatski] (/. Github / README_HR.md) Kikroeshia | [cs čeština] (/. Github / README_CS .md) Kicheki | [da dansk] (README_DA.md) Kidenmaki | [nl Nederlands] (/. github / README_ NL.md) Kiholanzi | [** en-us English **] (/. github / README.md) Kiingereza | [EO Kiesperanto] (/. Github / README_EO.md) Kiesperanto | [et Eestlane] (/. github / README_ET.md) Kiestonia | [tl Ufilipino] (/. github / README_TL.md) Kifilipino | [fi Suomalainen] (/. github / README_FI.md) Kifini | [fr français] (/. github / README_FR.md) Kifaransa | [fy Frysk] (/. github / README_FY.md) Kifrisia | [gl Galego] (/. github / README_GL.md) Kigalisia | [ka ქართველი] (/. github / README_KA) Kijojiajia [de Deutsch] (/. github / README_DE.md) Kijerumani | [el Ελληνικά] (/. github / README_EL.md) Kigiriki | [gu ગુજરાતી] (/. github / README_GU.md) Kigujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Kikrioli cha Haiti | [ha Hausa] (/. github / SOMAE_HA.md) Kihausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Kihawai | [he עִברִית] (/. github / README_HE.md) Kiebrania | [hi हिन्दी] (/. github / README_HI.md) Kihindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Kihungari | [ni Íslenska] (/. github / README_IS.md) Kiaislandi | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Kiaislandi | [ga Gaeilge] (/. github / README_GA.md) Kiayalandi | [italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Kijapani | [jw Wong jawa] (/. github / README_JW.md) Kijava | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kikannada | [kk Қазақ] (/. github / README_KK.md) Kikazaki | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-kusini 韓國 語] (/. github / README_KO_SOUTH.md) Kikorea (Kusini) | [ko-north 문화어] (README_KO_NORTH.md) Kikorea (Kaskazini) (BADO HATafsiri) [ku Kurdî] (/. github / README_KU.md) Kikurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kikirigizi | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Kilatini | [lt Lietuvis] (/. github / README_LT.md) Kilithuania | [lb Lëtzebuergesch] (/. github / README_LB.md) Kilasembagi | [mk Македонски] (/. github / README_MK.md) Kimasedonia | [mg Malagasy] (/. github / README_MG.md) Malagasi | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [ml മലയാളം] (/. github / README_ML.md) Kimalayalam | [mt Malti] (/. github / README_MT.md) Kimalta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Kimarathi | [mn Монгол] (/. github / README_MN.md) Kimongolia | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Kiburma) | [ne नेपाली] (/. github / README_NE.md) Kinepali | [hakuna norsk] (/. github / README_NO.md) Kinorwe | [au ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Kiorya) | [ps پښتو] (/. github / README_PS.md) Kipashto | [fa فارسی] (/. github / README_FA.md) | Kiajemi [pl polski] (/. github / README_PL.md) Kipolishi | [pt português] (/. github / README_PT.md) Kireno | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Kipunjabi | Hakuna lugha zinazopatikana zinazoanza na herufi Q | [ro Română] (/. github / README_RO.md) Kiromania | [ru русский] (/. github / README_RU.md) Kirusi | [sm Faasamoa] (/. github / README_SM.md) Msamoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scots Gaelic | [sr Српски] (/. github / README_SR.md) Kiserbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Kishona | [sd سنڌي] (/. github / README_SD.md) Kisindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Kislovakia | [sl Slovenščina] (/. github / README_SL.md) Kislovenia | [kwa hivyo Soomaali] (/. github / README_SO.md) Msomali | [[es español] (/. github / README_ES.md) Kihispania | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Kiswahili | [sv Svenska] (/. github / README_SV.md) Kiswidi | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Kitamil | [tt Татар] (/. github / README_TT.md) Kitatari | [te తెలుగు] (/. github / README_TE.md) Kitelugu | [th ไทย] (/. github / README_TH.md) Kitai | [tr Türk] (/. github / README_TR.md) Kituruki | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Kiukreni | [ur اردو] (/. github / README_UR.md) Kiurdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Kiuzbeki | [vi Tiếng Việt] (/. github / README_VI.md) Kivietinamu | [cy Cymraeg] (/. github / README_CY.md) Kiwelsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Kiyidi | [yo Kiyoruba] (/. github / README_YO.md) Kiyoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Inapatikana katika lugha 110 (108 wakati wa kuhesabu Kiingereza na Kikorea cha Kaskazini, kwani Korea Kaskazini bado haijatafsiriwa [Soma juu yake hapa] (/ OldVersions / Kikorea (Kaskazini ) / README.md))

Tafsiri katika lugha zingine isipokuwa Kiingereza zinatafsiriwa kwa mashine na bado si sahihi. Hakuna makosa ambayo yamerekebishwa hadi Februari 5, 2021. Tafadhali ripoti makosa ya kutafsiri [hapa] (https://github.com/seanpm2001/CamCamPlus/issues/) hakikisha unasahihisha marekebisho yako na vyanzo na uniongoze, kama ninavyotoa Sijui lugha zingine isipokuwa Kiingereza vizuri (nina mpango wa kupata mtafsiri hatimaye) tafadhali taja [wiktionary] (https://en.wiktionary.org) na vyanzo vingine katika ripoti yako. Kukosa kufanya hivyo kutasababisha kukataliwa kwa marekebisho hayo.

Kumbuka: kwa sababu ya mapungufu na ufafanuzi wa GitHub wa alama (na karibu kila tafsiri nyingine ya wavuti ya alama) kubonyeza viungo hivi vitakuelekeza kwa faili tofauti kwenye ukurasa tofauti ambayo sio ukurasa wangu wa wasifu wa GitHub. Utaelekezwa kwa [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), ambapo README inakaribishwa.

Tafsiri hufanywa na Google Tafsiri kwa sababu ya msaada mdogo au hakuna msaada kwa lugha ninazohitaji katika huduma zingine za kutafsiri kama DeepL na Bing Tafsiri. Ninafanya kazi kutafuta njia mbadala. Kwa sababu fulani, muundo (viungo, wagawanyiko, ujasiri, italiki, nk) umechanganywa katika tafsiri anuwai. Inachosha kurekebisha, na sijui jinsi ya kurekebisha masuala haya kwa lugha na herufi zisizo za Kilatini, na lugha za kulia kwenda kushoto (kama Kiarabu) msaada wa ziada unahitajika katika kurekebisha maswala haya.

Kwa sababu ya maswala ya matengenezo, tafsiri nyingi zimepitwa na wakati na zinatumia toleo la zamani la faili hii ya nakala ya `README`. Mtafsiri anahitajika. Pia, mnamo Aprili 22nd 2021, itanichukua muda kupata viungo vyote vipya kufanya kazi.

***

# Kielelezo

[00.0 - Juu] (# Juu)

> [00.1 - Kichwa] (# CamCamPlus)

> [00.2 - Soma nakala hii kwa lugha tofauti] (# Soma-nakala-hii-kwa-lugha-tofauti)

> [00.3 - Index] (Kielelezo #)

[01.0 - Maelezo] (# CamCamPlus)

[02.0 - Kuhusu] (# Karibu)

[03.0 - Wiki] (# Wiki)

[04.0 - Historia ya toleo] (# Historia-Toleo)

[05.0 - Hali ya programu] (# hadhi ya Programu)

[06.0 - Maelezo ya wadhamini] (# Mdhamini-maelezo)

[07.0 - Wachangiaji] (# Wachangiaji)

[08.0 - Maswala] (Maswala #)

> [08.1 - Maswala ya sasa] (# Matoleo ya sasa)

> [08.2 - Maswala yaliyopita] (# Matoleo ya zamani)

> [08.3 - Maombi ya zamani ya kuvuta] (# Maombi ya zamani-ya kuvuta)

> [08.4 - Maombi ya kuvuta yanayotumika] (# Maombi ya kuvuta-kazi)

[09.0 - Rasilimali] (Rasilimali #)

[10.0 - Inachangia] (# Inachangia)

[11.0 - Kuhusu README] (# Kuhusu-README)

[12.0 - Historia ya Toleo la README] (# README-toleo-historia)

[13.0 - Kijaba] [# Umefikia-mwisho-wa-faili-ya-README-faili)

> [13.1 - Mwisho wa faili] (# EOF)

***

# CamCamPlus
CamCamPlus ni kamera ya chanzo cha bure ya bure na ya wazi ambayo inaweza kuchukua picha na video katika miundo mingi, na maazimio mengi.

***

## Kuhusu

Tazama hapo juu. Mradi huu ni kuhusu kamera yenye nguvu ya chanzo wazi ambayo hutoa chaguzi nyingi na kuvunja vizuizi ambavyo programu zingine za kawaida za kamera zina (kama vile kikomo cha kurekodi cha dakika 30)

***

## Wiki

[Bonyeza / gonga hapa kuona miradi hii Wiki] (https://github.com/seanpm2001/CamCamPlus/wiki)

Ikiwa mradi umefanywa kwa uma, uwezekano wa Wiki uliondolewa. Kwa bahati nzuri, ninajumuisha toleo lililopachikwa. Unaweza kuiangalia [hapa] (/ Nje / ProjectWiki /).

***

## Habari za wafadhili

! [MdhaminiButton.png] (SponsorButton.png)

Unaweza kudhamini mradi huu ukipenda, lakini tafadhali taja ni nini unataka kuchangia. [Tazama pesa unazoweza kuchangia hapa] (https://github.com/seanpm2001/Sponsor-info/tree/main/For- Sponsors)

Unaweza kuona maelezo mengine ya wafadhili [hapa] (https://github.com/seanpm2001/Sponsor-info/)

Jaribu! Kitufe cha mdhamini kiko karibu kabisa na kitufe cha kutazama / kufungua.

***

## Historia ya toleo

** Historia ya toleo haipatikani kwa sasa **

** Hakuna matoleo mengine yaliyoorodheshwa **

***

# # Hali ya programu

Kazi zangu zote ni bure vizuizi vingine. DRM (** D ** igital ** R ** vizuizi ** M ** anagement) haipo katika kazi yangu yoyote.

! [Bila_label.en.svg isiyo na DRM] (bila-DRM_label.en.svg)

Kibandiko hiki kinasaidiwa na Free Msingi wa Programu. Sijakusudia kuingiza DRM katika kazi zangu.

Ninatumia kifupi "Usimamizi wa Vizuizi vya Dijiti" badala ya "Usimamizi wa Haki za Dijiti" inayojulikana kama njia ya kawaida ya kuishughulikia ni uwongo, hakuna haki na DRM. Tahajia "Usimamizi wa Vizuizi vya Dijiti" ni sahihi zaidi, na inasaidiwa na [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) na [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Sehemu hii hutumiwa kukuza uelewa juu ya shida na DRM, na pia kuipinga. DRM ina kasoro kwa muundo na ni tishio kubwa kwa watumiaji wote wa kompyuta na uhuru wa programu.

Mkopo wa picha: [defectivebydesign.org/drm-free/...) (http://www.defectivebydesign.org/drm-free/how-to-use-label)

***

# # Wachangiaji

Hivi sasa, mimi ndiye mchangiaji pekee. Kuchangia kunaruhusiwa, mradi utafuata sheria za faili ya [CONTRIBUTING.md] (CONTRIBUTING.md).

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 anajitolea (Kuanzia Alhamisi, Aprili 22nd 2021 saa 6:30 jioni)

> * 2. Hakuna wachangiaji wengine.

***

## Mambo

### Maswala ya sasa

* Hakuna kwa sasa

* Hakuna maswala mengine ya sasa

Ikiwa ghala limetengwa kwa uma, uwezekano wa masuala yameondolewa. Kwa bahati nzuri ninaweka kumbukumbu ya picha fulani [hapa] (/. Github / Maswala /)

[Soma sera ya faragha kwenye kumbukumbu ya suala hapa] (/. Github / Issues / README.md)

** TL; DR **

Ninahifadhi maswala yangu mwenyewe. Tatizo lako halitawekwa kwenye kumbukumbu isipokuwa ukiomba lihifadhiwe.

### Maswala yaliyopita

* Hakuna kwa sasa

* Hakuna maswala mengine ya zamani

Ikiwa ghala limetengwa kwa uma, uwezekano wa masuala yameondolewa. Kwa bahati nzuri ninaweka kumbukumbu ya picha fulani [hapa] (/. Github / Maswala /)

[Soma sera ya faragha kwenye kumbukumbu ya suala hapa] (/. Github / Issues / README.md)

** TL; DR **

Ninahifadhi maswala yangu mwenyewe. Tatizo lako halitawekwa kwenye kumbukumbu isipokuwa ukiomba lihifadhiwe.

### Maombi ya zamani ya kuvuta

* Hakuna kwa sasa

* Hakuna maombi mengine ya zamani ya kuvuta

Ikiwa ghala limetengwa kwa uma, uwezekano wa masuala yameondolewa. Kwa bahati nzuri ninaweka kumbukumbu ya picha fulani [hapa] (/. Github / Maswala /)

[Soma sera ya faragha kwenye kumbukumbu ya suala hapa] (/. Github / Issues / README.md)

** TL; DR **

Ninahifadhi maswala yangu mwenyewe. Tatizo lako halitawekwa kwenye kumbukumbu isipokuwa ukiomba lihifadhiwe.

### Maombi ya kuvuta yanayotumika

* Hakuna kwa sasa

* Hakuna maombi mengine ya kuvuta yanayotumika

Ikiwa ghala limetengwa kwa uma, uwezekano wa masuala yameondolewa. Kwa bahati nzuri ninaweka kumbukumbu ya picha fulani [hapa] (/. Github / Maswala /)

[Soma sera ya faragha kwenye kumbukumbu ya suala hapa] (/. Github / Issues / README.md)

** TL; DR **

Ninahifadhi maswala yangu mwenyewe. Tatizo lako halitawekwa kwenye kumbukumbu isipokuwa ukiomba lihifadhiwe.

***

Rasilimali # #

Hapa kuna rasilimali zingine za mradi huu:

[Faili ya lugha ya Mradi] (PROJECT_LANG.cpp)

[Maktaba ya kumbukumbu ya utafiti wa mradi huu] (/ Marejeo /)

[Moduli maalum ya video ya mradi huu (Video ya SVG)] (https://github.com/seanpm2001/SVG_Video/)

[Jiunge na majadiliano kwenye GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

Hakuna rasilimali nyingine kwa sasa.

***

## Kuchangia

Kuchangia kunaruhusiwa kwa mradi huu, mradi utafuata sheria za faili ya `CONTRIBUTING.md`.

[Bonyeza / gonga hapa kuona sheria zinazochangia mradi huu] (CONTRIBUTING.md)

***

## Kuhusu README

Aina ya faili: `Markdown (* .md)`

Toleo la faili: "1 (Alhamisi, Aprili 22nd 2021 saa 6:30 jioni)"

Hesabu ya laini: `0,306`

***

## SOMA historia ya toleo

Toleo la 1 (Alhamisi, Aprili 22nd 2021 saa 6:30 jioni)

> Mabadiliko:

> * Ilianza faili

> * Imeongeza sehemu ya kichwa

> * Aliongeza faharisi

> * Imeongeza sehemu kuhusu

> * Imeongeza sehemu ya Wiki

> * Imeongeza sehemu ya historia ya toleo

> * Imeongeza sehemu ya maswala.

> * Imeongeza sehemu ya maswala yaliyopita

> * Imeongeza sehemu ya maombi ya kuvuta ya zamani

> * Imeongeza sehemu ya maombi ya kuvuta inayotumika

> * Imeongeza sehemu ya wachangiaji

> * Imeongeza sehemu ya kuchangia

> * Imeongeza sehemu kuhusu README

> * Aliongeza sehemu ya historia ya toleo la README

> * Imeongeza sehemu ya rasilimali

> * Imeongeza sehemu ya hali ya programu, na stika na ujumbe wa bure wa DRM

> * Imeongeza sehemu ya maelezo ya mdhamini

> * Hakuna mabadiliko mengine katika toleo 1

Toleo la 2 (Inakuja hivi karibuni)

> Mabadiliko:

> * Inakuja hivi karibuni

> * Hakuna mabadiliko mengine katika toleo la 2

***

### Umefika mwisho wa faili ya README

[Rudi juu] (# Juu) [Toka] (https://github.com)

### EOF

***
