***

# Cam Cam Plus (CC +)

! [{Aami iṣẹ akanṣe} Aworan yii kuna lati kojọpọ. O le jẹ nitori faili ko de, tabi aṣiṣe gbogbogbo. Tun gbe oju-iwe naa pada lati ṣatunṣe aṣiṣe gbogbogbo ti o ṣeeṣe.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Nipasẹ:

## [Seanpm2001] (https://github.com/seanpm2001) ati awọn oluranlọwọ miiran

### Top

# “README.md`

***

## Ka nkan yii ni ede miiran

** Ede lọwọlọwọ jẹ: ** “Gẹẹsi (AMẸRIKA)“ _ (awọn itumọ le nilo atunṣe lati ṣatunṣe Gẹẹsi ti o rọpo ede to tọ) _

_🌐 Akojọ awọn ede_

** A to lẹsẹsẹ nipasẹ: ** `A-Z`

[Awọn aṣayan tito lẹtọ ko si] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanian | [am English] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) Arabic | [hy հայերեն] (/. github / README_HY.md) Armenian | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijani | [eu Euskara] (/. github /README_EU.md) Basque | [jẹ Беларуская] (/. Github / README_BE.md) Belarus | | bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnian | [bg български] (/. Github / README_BG.md) Bulgarian | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Ṣaina (Irọrun) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Ara Ṣaina (Ibile) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Croatian | [cs čeština] (/. Github / README_CS .md) Czech | [da dansk] (README_DA.md) Danish | [nl Nederlands] (/. github / README_ NL.md) Dutch | [** en-us Gẹẹsi **] (/. github / README.md) Gẹẹsi | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonia | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finnish | [fr Français] (/. github / README_FR.md) Faranse | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galician | [ka ქართველი] (/. github / README_KA) Georgian | [de Deutsch] (/. github / README_DE.md) Jẹmánì | [el Ελληνικά] (/. github / README_EL.md) Giriki | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Ilu Hawahi | [oun עִברִית] (/. github / README_HE.md) Heberu | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ara Ilu Hungary | [jẹ Íslenska] (/. github / README_IS.md) Icelandic | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Icelandic | [ga Gaeilge] (/. github / README_GA.md) Irish | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Ara ilu Japanese | [jw Wong jawa] (/. github / README_JW.md) Javanese | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-guusu 韓國 語] (/. github / README_KO_SOUTH.md) Korean (Guusu) | [ko-north 문화어] (README_KO_NORTH.md) Korean (Ariwa) (KO T TRTUN T YTỌ) | [ku Kurdî] (/. github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kyrgyz | [wo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lithuanian | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxembourgish | [mk Македонски] (/. github / README_MK.md) Macedonian | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [milimita മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Ilu Malta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolian | [mi မြန်မာ] (/. github / README_MY.md) Mianma (Burmese) | [ne नेपाली] (/. github / README_NE.md) Nepali | [ko si norsk] (/. github / README_NO.md) Norwegian | [tabi ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persia [pl polski] (/. github / README_PL.md) Polandii | [pt português] (/. github / README_PT.md) Ilu Pọtugalii | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Ko si awọn ede ti o wa ti o bẹrẹ pẹlu lẹta Q | [ro Română] (/. github / README_RO.md) Romanian | [ru русский] (/. github / README_RU.md) Russian | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scots Gaelic | [sr Српски] (/. github / README_SR.md) Ara Ilu Serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovak | [sl Slovenščina] (/. github / README_SL.md) Ara Slovenia | [nitorina Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Ede Sipeeni | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Swedish | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Tọki | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ti Ukarain | [ur]] / / github / README_UR.md) Ilu Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnam | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | { ) / README.md))

Awọn itumọ ni awọn ede miiran yatọ si Gẹẹsi jẹ itumọ ẹrọ ati pe ko iti pe. Ko si awọn aṣiṣe ti o wa titi sibẹsibẹ ti Oṣu Karun ọjọ 5th 2021. Jọwọ ṣe ijabọ awọn aṣiṣe itumọ [nibi] (https://github.com/seanpm2001/CamCamPlus/issues/) rii daju lati ṣe afẹyinti atunṣe rẹ pẹlu awọn orisun ati itọsọna mi, bi emi ko ṣe 'Emi ko mọ awọn ede miiran yatọ si Gẹẹsi daradara (Mo gbero lati ni onitumọ nikẹhin) jọwọ sọ [wiktionary] (https://en.wiktionary.org) ati awọn orisun miiran ninu ijabọ rẹ. Ti o ba kuna lati ṣe bẹ yoo jẹ ki ijusile ti atunṣe ti n gbejade.

Akiyesi: nitori awọn idiwọn pẹlu itumọ GitHub ti markdown (ati pupọ julọ gbogbo itumọ orisun wẹẹbu miiran ti markdown) tite awọn ọna asopọ wọnyi yoo ṣe atunṣe ọ si faili ọtọtọ lori oju-iwe ọtọ ti kii ṣe oju-iwe profaili GitHub mi. A o darí rẹ si ibi ipamọ [seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), nibiti a ti gbalejo README naa.

Awọn itumọ ni ṣiṣe pẹlu Google Translate nitori opin tabi ko si atilẹyin fun awọn ede ti Mo nilo ninu awọn iṣẹ itumọ miiran bi DeepL ati Tumọ Bing. Mo n ṣiṣẹ lori wiwa yiyan. Fun idi diẹ, kika (awọn ọna asopọ, awọn pinpin, igboya, awọn italisi, ati bẹbẹ lọ) jẹ idotin ni awọn itumọ oriṣiriṣi. O jẹ ohun ti o nira lati ṣatunṣe, ati pe emi ko mọ bi a ṣe le ṣatunṣe awọn ọran wọnyi ni awọn ede pẹlu awọn ohun kikọ ti kii ṣe latin, ati sọtun si awọn ede apa osi (bii Arabic) nilo iranlọwọ afikun ni titọ awọn ọrọ wọnyi

Nitori awọn ọran itọju, ọpọlọpọ awọn itumọ ti wa ni ọjọ ati lo ẹya ti igba atijọ ti faili nkan “README` yii. O nilo onitumọ kan. Pẹlupẹlu, bi Oṣu Kẹrin Ọjọ 22nd 2021, yoo gba mi ni igba diẹ lati gba gbogbo awọn ọna asopọ tuntun ṣiṣẹ.

***

Atọka

[00.0 - Top] (# Oke)

> [00.1 - Akọle] (# CamCamPlus)

> [00.2 - Ka nkan yii ni ede oriṣiriṣi] (# Ka-nkan yii-ni-ede-oriṣiriṣi-ede kan)

> [00.3 - Atọka] (Atọka #)

[01.0 - Apejuwe] (# CamCamPlus)

[02.0 - Nipa] (# Nipa)

[03.0 - Wiki] (# Wiki)

[04.0 - Itan ẹya] [# Itan-ẹya]

[05.0 - Ipo sọfitiwia] (# Ipo-sọfitiwia)

[06.0 - Alaye Onigbowo] (# Onigbowo-info)

[07.0 - Awọn oluranlowo] (# Awọn oluranlọwọ)

[08.0 - Awọn ipinfunni] (# Awọn ipinfunni)

> [08.1 - Awọn ọran lọwọlọwọ] (# Awọn oran-lọwọlọwọ)

> [08.2 - Awọn ọrọ ti o kọja] (# Awọn ọrọ ti o ti kọja)

> [08.3 - Awọn ibeere fifa sẹhin] (# Awọn ibeere-fa-fa-kọja)

> [08.4 - Awọn ibeere fa fifa ṣiṣẹ] (# Awọn ibeere-fa-fa-ibeere)

[09.0 - Awọn orisun] (# Awọn orisun)

[10.0 - Ṣiṣe alabapin] (# Ṣiṣe alabapin)

[11.0 - Nipa README] (# Nipa-KA)

[12.0 - Ìtàn Ìtàn README] (# itan-KA-ẹya-README)

[13.0 - Ẹlẹsẹ] (# Iwọ-ti-ni-opin-ti-faili-README)

> [13.1 - Opin faili] (# EOF)

***

# CamCamPlus
CamCamPlus jẹ ọfẹ ọfẹ ti o ga julọ ati kamẹra orisun-ṣiṣi ti o le ya awọn aworan ati awọn fidio ni ọpọlọpọ awọn ọna kika, ati ọpọlọpọ awọn ipinnu.

***

## Nipa

Wo loke. Iṣẹ yii jẹ nipa kamẹra ṣiṣi orisun agbara ti o fun ọpọlọpọ awọn aṣayan ati fifọ awọn idena ti awọn ohun elo kamẹra wọpọ miiran ni (bii opin gbigbasilẹ iṣẹju 30)

***

## Wiki

[Tẹ / tẹ ni kia kia lati wo Wiki awọn iṣẹ yii] (https://github.com/seanpm2001/CamCamPlus/wiki)

Ti o ba ti jẹ pe iṣẹ akanṣe naa ti ṣiṣẹ, o ṣee ṣe ki Wiki yọ kuro. Oriire, Mo pẹlu ẹya ifibọ kan. O le wo o [nibi] (/ Ita / ProjectWiki /).

***

## Alaye Onigbowo

! [OnigbowoButton.png] (OnigbowoButton.png)

O le ṣe onigbọwọ iṣẹ yii ti o ba fẹ, ṣugbọn jọwọ ṣafihan ohun ti o fẹ lati ṣetọrẹ si. [Wo awọn owo ti o le ṣetọrẹ si ibi] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

O le wo alaye onigbowo miiran [nibi] (https://github.com/seanpm2001/Sponsor-info/)

Gbiyanju o jade! Bọtini onigbọwọ wa ni titọ lẹgbẹẹ bọtini iṣọ / ṣiṣi.

***

## Itan ẹya

** Itan ẹya ko si ni lọwọlọwọ **

** Ko si awọn ẹya miiran ti a ṣe akojọ **

***

## Ipo sọfitiwia

Gbogbo awọn iṣẹ mi ni ominira diẹ ninu awọn ihamọ. DRM (** D ** igital ** R ** estrictions ** M ** anagement) ko si ni eyikeyi awọn iṣẹ mi.

! [DRM-ọfẹ_label.en.svg] (DRM-free_label.en.svg)

Sitika yii ni atilẹyin nipasẹ Free Ipilẹ sọfitiwia. Emi ko pinnu lati fi DRM sinu awọn iṣẹ mi.

Mo n lo abbreviation "Iṣakoso Awọn ihamọ Awọn ihamọ Digital" dipo ti diẹ mọ diẹ sii "Iṣakoso Awọn ẹtọ Digital” bi ọna ti o wọpọ ti n ba sọrọ jẹ eke, ko si awọn ẹtọ pẹlu DRM. Akọtọ ọrọ “Iṣakoso Awọn ihamọ Awọn ihamọ Digital” jẹ deede julọ, ati pe o ni atilẹyin nipasẹ [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) ati [Foundation Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

A lo apakan yii lati gbe imoye fun awọn iṣoro pẹlu DRM, ati lati ṣe ikede rẹ. DRM jẹ alebu nipa apẹrẹ ati pe o jẹ irokeke nla si gbogbo awọn olumulo kọmputa ati ominira sọfitiwia.

Kirẹditi aworan: [defectivebydesign.org/drm-free/...] (//https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Olùkópa

Lọwọlọwọ, Emi nikan ni oluranlọwọ. A gba laaye idasi, niwọn igba ti o ba tẹle awọn ofin ti faili [CONTRIBUTING.md] (CONTRIBUTING.md).

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - Awọn iṣẹ 138 (Bi ti Ọjọbọ, Ọjọ Kẹrin 22nd 2021 ni 6:30 irọlẹ)

> * 2. Ko si awọn oluranlọwọ miiran.

***

## Awọn ipinfunni

### Awọn oran lọwọlọwọ

* Kò si ni akoko yii

* Ko si awọn ọran lọwọlọwọ miiran

Ti ibi-ifipamọ ti ti forked, awọn oran le ti yọ kuro. Ni Oriire Mo tọju iwe pamosi ti awọn aworan kan [nibi] (/. Github / Issues /)

[Ka eto imulo ipamọ lori iwe ipamọ ọrọ nibi] (/. Github / Issues / README.md)

** TL; DR **

Mo ṣe igbasilẹ awọn ọrọ ti ara mi. Oro rẹ kii yoo ni iwe-iwe ayafi ti o ba beere pe ki o wa ni igbasilẹ.

### Awọn ọrọ ti o ti kọja

* Kò si ni akoko yii

* Ko si awọn ọrọ miiran ti o kọja

Ti ibi-ifipamọ ti ti forked, awọn oran le ti yọ kuro. Ni Oriire Mo tọju iwe pamosi ti awọn aworan kan [nibi] (/. Github / Issues /)

[Ka eto imulo ipamọ lori iwe ipamọ ọrọ nibi] (/. Github / Issues / README.md)

** TL; DR **

Mo ṣe igbasilẹ awọn ọrọ ti ara mi. Oro rẹ kii yoo ni iwe-iwe ayafi ti o ba beere pe ki o wa ni igbasilẹ.

### Awọn ibeere fa ti o ti kọja

* Kò si ni akoko yii

* Ko si awọn ibeere fa miiran ti o kọja

Ti ibi-ifipamọ ti ti forked, awọn oran le ti yọ kuro. Ni Oriire Mo tọju iwe pamosi ti awọn aworan kan [nibi] (/. Github / Issues /)

[Ka eto imulo ipamọ lori iwe ipamọ ọrọ nibi] (/. Github / Issues / README.md)

** TL; DR **

Mo ṣe igbasilẹ awọn ọrọ ti ara mi. Oro rẹ kii yoo ni iwe-iwe ayafi ti o ba beere pe ki o wa ni igbasilẹ.

### Awọn ibeere fa fa lọwọ

* Kò si ni akoko yii

* Ko si awọn ibeere fa miiran ti nṣiṣe lọwọ

Ti ibi-ifipamọ ti ti forked, awọn oran le ti yọ kuro. Ni Oriire Mo tọju iwe pamosi ti awọn aworan kan [nibi] (/. Github / Issues /)

[Ka eto imulo ipamọ lori iwe ipamọ ọrọ nibi] (/. Github / Issues / README.md)

** TL; DR **

Mo ṣe igbasilẹ awọn ọrọ ti ara mi. Oro rẹ kii yoo ni iwe-iwe ayafi ti o ba beere pe ki o wa ni igbasilẹ.

***

## Awọn orisun

Eyi ni diẹ ninu awọn orisun miiran fun iṣẹ yii:

[Faili ede akanṣe] (PROJECT_LANG.cpp)

[Ile-ikawe itọkasi iwadi fun iṣẹ yii] (/ Awọn itọkasi /)

[Modulu fidio pataki fun iṣẹ yii (SVG Fidio)] (https://github.com/seanpm2001/SVG_Video/)

[Darapọ mọ ijiroro lori GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

Ko si awọn orisun miiran ni akoko yii.

***

## Ṣiṣe alabapin

Ti gba laaye idasi fun iṣẹ yii, niwọn igba ti o tẹle awọn ofin ti faili “CONTRIBUTING.md`.

[Tẹ / tẹ ni kia kia lati wo awọn ofin idasi fun iṣẹ yii] (CONTRIBUTING.md)

***

## Nipa README

Iru faili: “Markdown (* .md)”

Ẹya faili: 1 (Ọjọbọde, Oṣu Kẹrin Ọjọ 22nd 2021 ni 6:30 irọlẹ) “

Nọmba laini: `` 0,306`

***

## itan ẹya README

Ẹya 1 (Ọjọbọ, Oṣu Kẹrin Ọjọ 22nd 2021 ni 6:30 irọlẹ)

> Awọn ayipada:

Bẹrẹ faili naa

> * Ṣafikun apakan akọle

> * Ṣafikun atọka naa

> * Fi kun nipa apakan

> * Ṣafikun apakan Wiki

> * Ṣafikun apakan itan ẹya

> * Ṣafikun apakan awọn ọran naa.

> * Ṣafikun apakan awọn ọran ti o kọja

> * Ṣafikun apakan awọn ibeere fifa ti o kọja

> * Ṣafikun apakan awọn ibeere fa lọwọ

> * Ṣafikun apakan awọn oluranlọwọ

> * Ṣafikun apakan idasi

> * Fikun-un nipa apakan README

> * Ṣafikun apakan itan ẹya README

> * Ṣafikun apakan awọn orisun

> * Ṣafikun apakan ipo sọfitiwia, pẹlu sitika ọfẹ DRM ati ifiranṣẹ

> * Ṣafikun apakan alaye onigbowo

> * Ko si awọn ayipada miiran ninu ẹya 1

Ẹya 2 (Nbọ laipẹ)

> Awọn ayipada:

> * Wiwa laipẹ

> * Ko si awọn ayipada miiran ninu ẹya 2

***

### O ti de opin faili README naa

[Pada si oke] (# Oke) [Jade] (https://github.com)

### EOF

***
