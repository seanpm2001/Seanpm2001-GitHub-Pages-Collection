***

# Cam Cam Plus (CC +)

! [{Project icon} Dette billede kunne ikke indlæses. Det kan skyldes, at filen ikke nås, eller en generel fejl. Genindlæs siden for at rette en mulig generel fejl.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Ved:

## [Seanpm2001] (https://github.com/seanpm2001) og andre bidragydere

### Top

# `README.md`

***

## Læs denne artikel på et andet sprog

** Aktuelt sprog er: ** `Engelsk (USA)` _ (oversættelser skal muligvis rettes for at ordne engelsk, der erstatter det korrekte sprog) _

_🌐 Liste over sprog_

** Sorteret efter: ** `A-Z`

[Sorteringsmuligheder ikke tilgængelige] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albansk | [am አማርኛ] (/. github / README_AM.md) Amharisk | [ar عربى] (/.github/README_AR.md) Arabisk | [hy հայերեն] (/. github / README_HY.md) Armensk | [az Azərbaycan dili] (/. github / README_AZ.md) Aserbajdsjansk | [eu Euskara] (/. github /README_EU.md) Baskisk | [være Беларуская] (/. Github / README_BE.md) Hviderussisk | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnisk | [bg български] (/. Github / README_BG.md) Bulgarsk | [ca Català] (/. Github / README_CA.md) Catalansk | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Kinesisk (forenklet) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Kinesisk (traditionel) | [co Corsu] (/. Github / README_CO.md) Korsikansk | [hr Hrvatski] (/. Github / README_HR.md) Kroatisk | [cs čeština] (/. Github / README_CS .md) Tjekkisk | [da dansk] (README_DA.md) Dansk | [nl Nederlands] (/. github / README_ NL.md) Hollandsk | [** en-us engelsk **] (/. github / README.md) Engelsk | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estisk | [tl Pilipino] (/. github / README_TL.md) Filippinsk | [fi Suomalainen] (/. github / README_FI.md) Finsk | [fr français] (/. github / README_FR.md) Fransk | [fy Frysk] (/. github / README_FY.md) Frisisk | [gl Galego] (/. github / README_GL.md) Galicisk | [ka ქართველი] (/. github / README_KA) Georgisk | [de Deutsch] (/. github / README_DE.md) Tysk | [el Ελληνικά] (/. github / README_EL.md) Græsk | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitisk kreolsk | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiiansk | [he עִברִית] (/. github / README_HE.md) Hebraisk | [hej हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ungarsk | [er Íslenska] (/. github / README_IS.md) Islandsk | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandsk | [ga Gaeilge] (/. github / README_GA.md) Irsk | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japansk | [jw Wong jawa] (/. github / README_JW.md) Javanesisk | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kasakhisk | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-syd 韓國 語] (/. github / README_KO_SOUTH.md) Koreansk (Syd) | [ko-nord 문화어] (README_KO_NORTH.md) Koreansk (Nord) (IKKE OVERSAT) | [ku Kurdî] (/. github / README_KU.md) Kurdisk (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgisisk | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Litauisk | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxembourgsk | [mk Македонски] (/. github / README_MK.md) Makedonsk | [mg madagaskisk] (/. github / README_MG.md) madagaskisk | [ms Bahasa Melayu] (/. github / README_MS.md) Malaysisk | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltesisk | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolsk | [min မြန်မာ] (/. github / README_MY.md) Myanmar (burmesisk) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) Norsk | [eller ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persisk [pl polski] (/. github / README_PL.md) Polsk | [pt português] (/. github / README_PT.md) Portugisisk | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Ingen tilgængelige sprog, der starter med bogstavet Q | [ro Română] (/. github / README_RO.md) Rumænsk | [ru русский] (/. github / README_RU.md) Russisk | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Skotsk gælisk | [sr Српски] (/. github / README_SR.md) Serbisk | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovakisk | [sl Slovenščina] (/. github / README_SL.md) Slovensk | [så Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spansk | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Svensk | [tg Тоҷикӣ] (/. github / README_TG.md) Tadsjikisk | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatarisk | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Tyrkisk | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukrainsk | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Usbekisk | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamesisk | [cy Cymraeg] (/. github / README_CY.md) Walisisk | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jiddisk | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Fås på 110 sprog (108 når der ikke tælles engelsk og nordkoreansk, da nordkoreansk endnu ikke er oversat [Læs om det her] (/ OldVersions / koreansk (nord ) /README.md))

Oversættelser på andre sprog end engelsk er maskinoversat og er endnu ikke korrekte. Ingen fejl er rettet endnu den 5. februar 2021. Rapporter venligst oversættelsesfejl [her] (https://github.com/seanpm2001/CamCamPlus/issues/) Sørg for at tage backup af din rettelse med kilder og guide mig, da jeg ikke kender ikke andre sprog end engelsk godt (jeg planlægger at få en oversætter til sidst) citer [wiktionary] (https://en.wiktionary.org) og andre kilder i din rapport. Hvis du ikke gør det, vil en afvisning af rettelsen blive offentliggjort.

Bemærk: på grund af begrænsninger med GitHubs fortolkning af markdown (og stort set alle andre webbaserede fortolkninger af markdown), klikker disse links dig til en separat fil på en separat side, der ikke er min GitHub-profilside. Du vil blive omdirigeret til [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), hvor README er hostet.

Oversættelser foretages med Google Translate på grund af begrænset eller ingen support til de sprog, jeg har brug for i andre oversættelsestjenester som DeepL og Bing Translate. Jeg arbejder på at finde et alternativ. Af en eller anden grund er formateringen (links, skillevægge, fed skrift, kursiv osv.) Rodet i forskellige oversættelser. Det er kedeligt at rette, og jeg ved ikke, hvordan jeg løser disse problemer på sprog med ikke-latinske tegn, og højre til venstre sprog (som arabisk) er der brug for ekstra hjælp til at løse disse problemer

På grund af vedligeholdelsesproblemer er mange oversættelser forældede og bruger en forældet version af denne `README`-artikelfil. En oversætter er nødvendig. Fra den 22. april 2021 vil det også tage mig et stykke tid at få alle de nye links til at fungere.

***

# Indeks

[00.0 - Top] (# Top)

> [00.1 - Titel] (# CamCamPlus)

> [00.2 - Læs denne artikel på et andet sprog] (# Læs-denne-artikel-på-et-andet-sprog)

> [00.3 - Indeks] (# Indeks)

[01.0 - Beskrivelse] (# CamCamPlus)

[02.0 - Om] (# Om)

[03.0 - Wiki] (# Wiki)

[04.0 - Versionshistorik] (# Versionshistorik)

[05.0 - Software status] (# Software-status)

[06.0 - Sponsoroplysninger] (# Sponsorinfo)

[07.0 - Bidragydere] (# bidragydere)

[08.0 - Udgaver] (# udgaver)

> [08.1 - Aktuelle udgaver] (# Aktuelle udgaver)

> [08.2 - Tidligere udgaver] (# Tidligere udgaver)

> [08.3 - Tidligere pull-anmodninger] (# Past-pull-anmodninger)

> [08.4 - Aktive pull-anmodninger] (# Active-pull-anmodninger)

[09.0 - Ressourcer] (# ressourcer)

[10.0 - Bidrag] (# bidrager)

[11.0 - Om README] (# About-README)

[12.0 - README Versionshistorik] (# README-version-historie)

[13.0 - Sidefod] (# Du har nået slutningen af ​​README-filen)

> [13.1 - Slut på fil] (# EOF)

***

# CamCamPlus
CamCamPlus er et high-end gratis og open source-kamera, der kan tage billeder og videoer i mange formater og mange opløsninger.

***

## Om

Se ovenfor. Dette projekt handler om et open source-kraftigt kamera, der giver mange muligheder og nedbryder barrierer, som andre almindelige kameraapps har (såsom 30 minutters optagelsesgrænse)

***

## Wiki

[Klik / tryk her for at se dette projekt Wiki] (https://github.com/seanpm2001/CamCamPlus/wiki)

Hvis projektet er forkaffet, blev Wiki sandsynligvis fjernet. Heldigvis inkluderer jeg en integreret version. Du kan se det [her] (/ Eksternt / ProjectWiki /).

***

## Sponsorinfo

! [SponsorButton.png] (SponsorButton.png)

Du kan sponsorere dette projekt, hvis du vil, men angiv venligst, hvad du vil donere til. [Se de midler, du kan donere til her] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Du kan se anden sponsorinformation [her] (https://github.com/seanpm2001/Sponsor-info/)

Prøve det! Sponsorknappen er lige ved siden af ​​uret / uret-knappen.

***

## Versionshistorik

** Versionshistorik er i øjeblikket ikke tilgængelig **

** Ingen andre versioner angivet **

***

## Software status

Alle mine værker er gratis nogle begrænsninger. DRM (** D ** igital ** R ** estrictions ** M ** anagement) er ikke til stede i nogen af ​​mine værker.

! [DRM-fri_label.en.svg] (DRM-fri_label.en.svg)

Dette mærkat understøttes af Free Software Foundation. Jeg har aldrig til hensigt at medtage DRM i mine værker.

Jeg bruger forkortelsen "Digital Restrictions Management" i stedet for den mere kendte "Digital Rights Management", da den almindelige måde at adressere den på er falsk, der er ingen rettigheder til DRM. Stavemåden "Digital Restrictions Management" er mere nøjagtig og understøttes af [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) og [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Dette afsnit bruges til at øge bevidstheden om problemerne med DRM og også til at protestere mod det. DRM er defekt af design og er en stor trussel mod alle computerbrugere og softwarefrihed.

Billedkredit: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Bidragere

I øjeblikket er jeg den eneste bidragyder. Bidrag er tilladt, så længe du følger reglerne i filen [CONTRIBUTING.md] (CONTRIBUTING.md).

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 forpligtelser (fra torsdag den 22. april 2021 kl. 18:30)

> * 2. Ingen andre bidragydere.

***

## Problemer

### Nuværende problemer

* Ingen i øjeblikket

* Ingen andre aktuelle problemer

Hvis opbevaringsstedet er forked, er problemer sandsynligvis blevet fjernet. Heldigvis opbevarer jeg et arkiv med bestemte billeder [her] (/. Github / Issues /)

[Læs fortrolighedspolitikken om arkivering af emner her] (/. Github / Issues / README.md)

** TL; DR **

Jeg arkiverer mine egne problemer. Dit problem arkiveres ikke, medmindre du anmoder om, at det arkiveres.

### Tidligere udgaver

* Ingen i øjeblikket

* Ingen andre tidligere problemer

Hvis opbevaringsstedet er forked, er problemer sandsynligvis blevet fjernet. Heldigvis opbevarer jeg et arkiv med bestemte billeder [her] (/. Github / Issues /)

[Læs fortrolighedspolitikken om arkivering af emner her] (/. Github / Issues / README.md)

** TL; DR **

Jeg arkiverer mine egne problemer. Dit problem arkiveres ikke, medmindre du anmoder om, at det arkiveres.

### Tidligere pullanmodninger

* Ingen i øjeblikket

* Ingen andre tidligere pull-anmodninger

Hvis opbevaringsstedet er forked, er problemer sandsynligvis blevet fjernet. Heldigvis opbevarer jeg et arkiv med bestemte billeder [her] (/. Github / Issues /)

[Læs fortrolighedspolitikken om arkivering af emner her] (/. Github / Issues / README.md)

** TL; DR **

Jeg arkiverer mine egne problemer. Dit problem arkiveres ikke, medmindre du anmoder om, at det arkiveres.

### Aktive pull-anmodninger

* Ingen i øjeblikket

* Ingen andre aktive pull-anmodninger

Hvis opbevaringsstedet er forked, er problemer sandsynligvis blevet fjernet. Heldigvis opbevarer jeg et arkiv med bestemte billeder [her] (/. Github / Issues /)

[Læs fortrolighedspolitikken om arkivering af emner her] (/. Github / Issues / README.md)

** TL; DR **

Jeg arkiverer mine egne problemer. Dit problem arkiveres ikke, medmindre du anmoder om, at det arkiveres.

***

## Ressourcer

Her er nogle andre ressourcer til dette projekt:

[Projekt sprogfil] (PROJECT_LANG.cpp)

[Forskningsreferencebibliotek for dette projekt] (/ Referencer /)

[Det specielle videomodul til dette projekt (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[Deltag i diskussionen om GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

Ingen andre ressourcer i øjeblikket.

***

## Bidrager

Det er tilladt at bidrage til dette projekt, så længe du følger reglerne i filen `CONTRIBUTING.md`.

[Klik / tryk her for at se de regler, der bidrager til dette projekt] (CONTRIBUTING.md)

***

## Om README

Filtype: 'Markdown (* .md)'

Filversion: '1 (torsdag den 22. april 2021 kl. 18.30)'

Linjetælling: `0,306`

***

## README version historie

Version 1 (torsdag den 22. april 2021 kl. 18.30)

> Ændringer:

> * Startede filen

> * Tilføjede titelsektionen

> * Tilføjet indekset

> * Tilføjet afsnittet om

> * Tilføjet Wiki-sektionen

> * Tilføjet sektionen til versionshistorik

> * Tilføjede afsnittet om problemer.

> * Tilføjet sektionen om tidligere udgaver

> * Tilføjet sektionen om tidligere anmodninger om træk

> * Tilføjet sektionen for aktive pullanmodninger

> * Tilføjet afsnittet om bidragydere

> * Tilføjet det bidragende afsnit

> * Tilføjet sektionen om README

> * Tilføjet sektionen README-versionshistorik

> * Tilføjede ressourceafsnittet

> * Tilføjet et softwarestatusafsnit med et DRM-frit klistermærke og en besked

> * Tilføjet sektionen om sponsorinfo

> * Ingen andre ændringer i version 1

Version 2 (Kommer snart)

> Ændringer:

> * Kommer snart

> * Ingen andre ændringer i version 2

***

### Du har nået slutningen af ​​README-filen

[Tilbage til toppen] (# Top) [Afslut] (https://github.com)

### EOF

***
