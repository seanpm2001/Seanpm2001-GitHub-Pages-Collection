***

# Cam Cam Plus (CC +)

! [{Project icon} Dette bildet kunne ikke lastes inn. Det kan skyldes at filen ikke blir nådd, eller en generell feil. Last siden på nytt for å fikse en mulig generell feil.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Av:

## [Seanpm2001] (https://github.com/seanpm2001) og andre bidragsytere

### Topp

# `README.md`

***

## Les denne artikkelen på et annet språk

** Nåværende språk er: ** `Engelsk (USA)` _ (oversettelser må kanskje rettes for å fikse engelsk som erstatter riktig språk) _

_🌐 Liste over språk_

** Sortert etter: ** `A-Z`

[Sorteringsalternativer utilgjengelige] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albansk | [am አማርኛ] (/. github / README_AM.md) Amharisk | [ar عربى] (/.github/README_AR.md) Arabisk | [hy հայերեն] (/. github / README_HY.md) Armensk | [az Azərbaycan dili] (/. github / README_AZ.md) Aserbajdsjansk | [eu Euskara] (/. github /README_EU.md) Baskisk | [være Беларуская] (/. Github / README_BE.md) Hviterussisk | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnisk | [bg български] (/. Github / README_BG.md) Bulgarsk | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Kinesisk (forenklet) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Kinesisk (tradisjonell) | [co Corsu] (/. Github / README_CO.md) Korsikansk | [hr Hrvatski] (/. Github / README_HR.md) Kroatisk | [cs čeština] (/. Github / README_CS .md) Tsjekkisk | [da dansk] (README_DA.md) Dansk | [nl Nederlands] (/. github / README_ NL.md) Nederlandsk | [** en-us engelsk **] (/. github / README.md) Engelsk | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estisk | [tl Pilipino] (/. github / README_TL.md) Filippinsk | [fi Suomalainen] (/. github / README_FI.md) Finsk | [fr français] (/. github / README_FR.md) Fransk | [fy Frysk] (/. github / README_FY.md) Frisisk | [gl Galego] (/. github / README_GL.md) Galisisk | [ka ქართველი] (/. github / README_KA) Georgian | [de Deutsch] (/. github / README_DE.md) Tysk | [el Ελληνικά] (/. github / README_EL.md) Gresk | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitisk kreolsk | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiisk | [he עִברִית] (/. github / README_HE.md) Hebraisk | [hei हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ungarsk | [er Íslenska] (/. github / README_IS.md) Islandsk | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandsk | [ga Gaeilge] (/. github / README_GA.md) Irsk | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japansk | [jw Wong jawa] (/. github / README_JW.md) Javanesisk | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kasakhisk | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-sør 韓國 語] (/. github / README_KO_SOUTH.md) Koreansk (Sør) | [ko-nord 문화어] (README_KO_NORTH.md) Koreansk (Nord) (IKKE OVERSETT) | [ku Kurdî] (/. github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgisisk | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Litauisk | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxembourgsk | [mk Македонски] (/. github / README_MK.md) Makedonsk | [mg Madagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) Malayisk | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltesisk | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolsk | [min မြန်မာ] (/. github / README_MY.md) Myanmar (burmesisk) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) Norsk | [eller ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persisk [pl polski] (/. github / README_PL.md) Polsk | [pt português] (/. github / README_PT.md) Portugisisk | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Ingen tilgjengelige språk som begynner med bokstaven Q | [ro Română] (/. github / README_RO.md) Rumensk | [ru русский] (/. github / README_RU.md) Russisk | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Skotske gælisk | [sr Српски] (/. github / README_SR.md) Serbisk | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovakisk | [sl Slovenščina] (/. github / README_SL.md) Slovensk | [so Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spansk | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Svensk | [tg Тоҷикӣ] (/. github / README_TG.md) Tadsjik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Tyrkisk | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukrainsk | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Usbekisk | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamesisk | [cy Cymraeg] (/. github / README_CY.md) walisisk | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jiddisk | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Tilgjengelig på 110 språk (108 når du ikke teller engelsk og nordkoreansk, da nordkoreansk ikke er oversatt ennå [Les om det her] (/ OldVersions / Korean (nord ) /README.md))

Oversettelser på andre språk enn engelsk er maskinoversatt og er ennå ikke nøyaktige. Ingen feil er rettet ennå fra 5. februar 2021. Rapporter rapporteringsfeil [her] (https://github.com/seanpm2001/CamCamPlus/issues/), sørg for å sikkerhetskopiere korreksjonen din med kilder og veilede meg, ettersom jeg ikke Kan ikke andre språk enn engelsk (jeg planlegger å skaffe meg en oversetter til slutt), vennligst siter [wiktionary] (https://en.wiktionary.org) og andre kilder i rapporten din. Unnlatelse av å gjøre det vil føre til at avslag på rettelsen blir publisert.

Merk: på grunn av begrensninger med GitHubs tolkning av markdown (og stort sett alle andre nettbaserte tolkninger av markdown), klikker du på disse lenkene til en egen fil på en egen side som ikke er min GitHub-profilside. Du blir omdirigert til [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), der README er vert.

Oversettelser gjøres med Google Translate på grunn av begrenset eller ingen støtte for språkene jeg trenger i andre oversettelsestjenester som DeepL og Bing Translate. Jeg jobber med å finne et alternativ. Av en eller annen grunn er formateringen (lenker, skillelinjer, fet skrift, kursiv osv.) Rotet sammen i forskjellige oversettelser. Det er kjedelig å fikse, og jeg vet ikke hvordan jeg skal løse disse problemene på språk med ikke-latinske tegn, og fra høyre til venstre språk (som arabisk) er det nødvendig med ekstra hjelp til å løse disse problemene

På grunn av vedlikeholdsproblemer er mange oversettelser utdaterte og bruker en utdatert versjon av denne `README`-artikkelfilen. En oversetter er nødvendig. Fra og med 22. april 2021 vil det ta litt tid å få alle de nye lenkene til å fungere.

***

# Indeks

[00.0 - Topp] (# Topp)

> [00.1 - Tittel] (# CamCamPlus)

> [00.2 - Les denne artikkelen på et annet språk] (# Les-denne-artikkelen-på-et-annet-språk)

> [00.3 - Indeks] (# indeks)

[01.0 - Beskrivelse] (# CamCamPlus)

[02.0 - Om] (# Om)

[03.0 - Wiki] (# Wiki)

[04.0 - Versjonshistorikk] (# Versjonshistorikk)

[05.0 - Programvarestatus] (# Programvarestatus)

[06.0 - Sponsorinfo] (# Sponsorinfo)

[07.0 - Bidragsytere] (# bidragsytere)

[08.0 - Utgaver] (# utgaver)

> [08.1 - Aktuelle utgaver] (# Aktuelle utgaver)

> [08.2 - Tidligere utgaver] (# Tidligere utgaver)

> [08.3 - Tidligere trekkforespørsler] (# Tidligere trekkforespørsler)

> [08.4 - Aktive trekkforespørsler] (# Aktive trekkforespørsler)

[09.0 - Ressurser] (# ressurser)

[10.0 - Bidrar] (# Bidrar)

[11.0 - Om README] (# About-README)

[12.0 - README Versjonshistorikk] (# README-versjonshistorikk)

[13.0 - Bunntekst] (# Du har nådd slutten av README-filen)

> [13.1 - Slutt på fil] (# EOF)

***

# CamCamPlus
CamCamPlus er et avansert gratis kamera med åpen kildekode som kan ta bilder og videoer i mange formater og mange oppløsninger.

***

## Om

Se ovenfor. Dette prosjektet handler om et kraftig kamera med åpen kildekode som gir mange muligheter og bryter ned barrierer som andre vanlige kameraapper har (for eksempel 30 minutters opptaksgrense)

***

## Wiki

[Klikk / trykk her for å se prosjektene Wiki] (https://github.com/seanpm2001/CamCamPlus/wiki)

Hvis prosjektet har blitt sluppet, ble Wiki sannsynligvis fjernet. Heldigvis inkluderer jeg en innebygd versjon. Du kan se den [her] (/ Ekstern / ProjectWiki /).

***

## Sponsorinfo

! [SponsorButton.png] (SponsorButton.png)

Du kan sponse dette prosjektet hvis du vil, men spesifiser hva du vil donere til. [Se midlene du kan donere til her] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Du kan se annen sponsorinfo [her] (https://github.com/seanpm2001/Sponsor-info/)

Prøv det! Sponsorknappen er helt oppe ved siden av klokke / urknappen.

***

## Versjonshistorikk

** Versjonshistorikk for øyeblikket utilgjengelig **

** Ingen andre versjoner oppført **

***

## Programvarestatus

Alle verkene mine er gratis, noen begrensninger. DRM (** D ** igital ** R ** estrictions ** M ** anagement) er ikke tilstede i noen av mine verk.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Dette klistremerket støttes av Free Software Foundation. Jeg har aldri tenkt å inkludere DRM i verkene mine.

Jeg bruker forkortelsen "Digital Restrictions Management" i stedet for den mer kjente "Digital Rights Management" som den vanlige måten å adressere den på er falsk, det er ingen rettigheter med DRM. Stavemåten "Digital Restrictions Management" er mer nøyaktig og støttes av [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) og [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Denne delen brukes til å øke bevisstheten om problemene med DRM, og også for å protestere mot den. DRM er defekt av design og er en stor trussel mot alle databrukere og programvarefrihet.

Bildekreditt: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Bidragsytere

For øyeblikket er jeg den eneste bidragsyteren. Det er tillatt å bidra, så lenge du følger reglene i filen [CONTRIBUTING.md] (CONTRIBUTING.md).

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 forplikter (fra torsdag 22. april 2021 kl. 18:30)

> * 2. Ingen andre bidragsytere.

***

## Problemer

### Nåværende problemer

* Ingen for øyeblikket

* Ingen andre aktuelle saker

Hvis depotet har blitt gaffelt, er problemer sannsynligvis fjernet. Heldigvis holder jeg et arkiv med visse bilder [her] (/. Github / Issues /)

[Les personvernreglene for arkiv av problemer her] (/. Github / Issues / README.md)

** TL; DR **

Jeg arkiverer mine egne problemer. Problemet ditt blir ikke arkivert med mindre du ber om at det arkiveres.

### Tidligere utgaver

* Ingen for øyeblikket

* Ingen andre tidligere utgaver

Hvis depotet har blitt gaffelt, er problemer sannsynligvis fjernet. Heldigvis holder jeg et arkiv med visse bilder [her] (/. Github / Issues /)

[Les personvernreglene for arkiv av problemer her] (/. Github / Issues / README.md)

** TL; DR **

Jeg arkiverer mine egne problemer. Problemet ditt blir ikke arkivert med mindre du ber om at det arkiveres.

### Tidligere trekkforespørsler

* Ingen for øyeblikket

* Ingen andre tidligere trekkforespørsler

Hvis depotet har blitt gaffelt, er problemer sannsynligvis fjernet. Heldigvis holder jeg et arkiv med visse bilder [her] (/. Github / Issues /)

[Les personvernreglene for arkiv av problemer her] (/. Github / Issues / README.md)

** TL; DR **

Jeg arkiverer mine egne problemer. Problemet ditt blir ikke arkivert med mindre du ber om at det arkiveres.

### Aktive trekkforespørsler

* Ingen for øyeblikket

* Ingen andre aktive trekkforespørsler

Hvis depotet har blitt gaffelt, er problemer sannsynligvis fjernet. Heldigvis holder jeg et arkiv med visse bilder [her] (/. Github / Issues /)

[Les personvernreglene for arkiv av problemer her] (/. Github / Issues / README.md)

** TL; DR **

Jeg arkiverer mine egne problemer. Problemet ditt blir ikke arkivert med mindre du ber om at det arkiveres.

***

## Ressurser

Her er noen andre ressurser for dette prosjektet:

[Språkfil for prosjekt] (PROJECT_LANG.cpp)

[Forskningsreferansebibliotek for dette prosjektet] (/ Referanser /)

[Den spesielle videomodulen for dette prosjektet (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[Bli med i diskusjonen på GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

Ingen andre ressurser for øyeblikket.

***

## Bidrar

Bidrag er tillatt for dette prosjektet, så lenge du følger reglene i filen `CONTRIBUTING.md`.

[Klikk / trykk her for å se de medvirkende reglene for dette prosjektet] (CONTRIBUTING.md)

***

## Om README

Filtype: `` Markdown (* .md) '

Filversjon: `` 1 (torsdag 22. april 2021 kl. 18:30) '

Linjetelling: `0,306`

***

## README versjonshistorikk

Versjon 1 (torsdag 22. april 2021 kl. 18.30)

> Endringer:

> * Startet filen

> * Lagt til tittelseksjonen

> * Lagt til indeksen

> * Lagt til om-seksjonen

> * Lagt til Wiki-delen

> * Lagt til versjonshistorikk-delen

> * Lagt til problemavsnittet.

> * Lagt til delen for tidligere utgaver

> * Lagt til den siste delen for trekkforespørsler

> * Lagt til delen for aktive trekkforespørsler

> * La til delen bidragsytere

> * Lagt til bidragsdelen

> * Lagt til delen om README

> * Lagt til delen README versjonshistorikk

> * Lagt til ressursdelen

> * Lagt til en programvarestatusdel, med et DRM-gratis klistremerke og melding

> * Lagt til sponsorinfoseksjonen

> * Ingen andre endringer i versjon 1

Versjon 2 (Kommer snart)

> Endringer:

> * Kommer snart

> * Ingen andre endringer i versjon 2

***

### Du har nådd slutten av README-filen

[Tilbake til toppen] (# Topp) [Avslutt] (https://github.com)

### EOF

***
