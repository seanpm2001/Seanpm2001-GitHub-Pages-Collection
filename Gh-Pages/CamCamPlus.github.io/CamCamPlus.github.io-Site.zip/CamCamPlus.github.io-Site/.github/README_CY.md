***

# Cam Cam Plus (CC +)

! [{Eicon prosiect} Methodd y ddelwedd hon â llwytho. Gall fod oherwydd na chyrhaeddwyd y ffeil, neu wall cyffredinol. Ail-lwythwch y dudalen i drwsio gwall cyffredinol posib.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Gan:

## [Seanpm2001] (https://github.com/seanpm2001) a chyfranwyr eraill

### Top

# `README.md`

***

## Darllenwch yr erthygl hon mewn iaith wahanol

** Yr iaith gyfredol yw: ** `Saesneg (UD)` _ (efallai y bydd angen cywiro cyfieithiadau i drwsio'r Saesneg yn lle'r iaith gywir) _

_🌐 Rhestr o ieithoedd_

** Trefnwyd gan: ** `A-Z`

[Nid yw'r opsiynau didoli ar gael] (https://github.com/Degoogle-your-Life)

([af Affricanaidd] (/. github / README_AF.md) Affricaneg | [sq Shqiptare] (/. github / README_SQ.md) Albaneg | [am አማርኛ] (/. github / README_AM.md) Amhareg | [ar عربى] (/.github/README_AR.md) Arabeg | [hy հայերեն] (/. github / README_HY.md) Armeneg | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijani | [eu Euskara] (/. github /README_EU.md) Basg | Bosnia | [bg български] (/. Github / README_BG.md) Bwlgareg | [ca Català] (/. Github / README_CA.md) Catalwnia ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Tsieineaidd (Syml) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Tsieineaidd (Traddodiadol) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Croateg | [cs čeština] (/. Github / README_CS .md) Tsiec | [da dansk] (README_DA.md) Daneg | [nl Nederlands] (/. github / README_ NL.md) Iseldireg | [** en-us Saesneg **] (/. github / README.md) Saesneg | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estoneg | [tl Pilipino] (/. github / README_TL.md) Ffilipineg | [fi Suomalainen] (/. github / README_FI.md) Ffinneg | [fr français] (/. github / README_FR.md) Ffrangeg | [fy Frysk] (/. github / README_FY.md) Ffriseg | [gl Galego] (/. github / README_GL.md) Galisia | [ka ქართველი] (/. github / README_KA) Sioraidd | [de Deutsch] (/. github / README_DE.md) Almaeneg | [el Ελληνικά] (/. github / README_EL.md) Groeg | [gu ગુજરાતી] (/. github / README_GU.md) Gwjarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [ef עִברִית] (/. github / README_HE.md) Hebraeg | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hwngari | [yw Íslenska] (/. github / README_IS.md) Gwlad yr Iâ | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Gwlad yr Iâ | [ga Gaeilge] (/. github / README_GA.md) Gwyddeleg | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japaneaidd | [jw Wong jawa] (/. github / README_JW.md) Javanese | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-de 韓國 語] (/. github / README_KO_SOUTH.md) Corea (De) | [ko-gogledd 문화어] (README_KO_NORTH.md) Corea (Gogledd) (NID YW'N CYFIEITHU) | [ku Kurdî] (/. github / README_KU.md) Cwrdeg (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Cirgise | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Lladin | [lt Lietuvis] (/. github / README_LT.md) Lithwaneg | [lb Lëtzebuergesch] (/. github / README_LB.md) Lwcsembwrg | [mk Македонски] (/. github / README_MK.md) Macedoneg | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) Maleieg | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Malteg | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongoleg | [fy မြန်မာ] (/. github / README_MY.md) Myanmar (Byrmaneg) | [ne नेपाली] (/. github / README_NE.md) Nepali | [dim norsk] (/. github / README_NO.md) Norwyeg | [neu ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Perseg [pl polski] (/. github / README_PL.md) Pwyleg | [pt português] (/. github / README_PT.md) Portiwgaleg | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Nid oes unrhyw ieithoedd ar gael sy'n dechrau gyda'r llythyren Q | [ro Română] (/. github / README_RO.md) Rwmaneg | [ru русский] (/. github / README_RU.md) Rwseg | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Gaeleg yr Alban | [sr Српски] (/. github / README_SR.md) Serbeg | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slofacia | [sl Slovenščina] (/. github / README_SL.md) Slofenia | [felly Soomaali] (/. github / README_SO.md) Somalïaidd | [[es en español] (/. github / README_ES.md) Sbaeneg | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswlarus] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Sweden | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Twrceg | [tk Türkmenler] (/. github / README_TK.md) Tyrcmeneg | [uk Український] (/. github / README_UK.md) Wcreineg | [ur اردو] (/. github / README_UR.md) Wrdw | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Wsbeceg | [vi Tiếng Việt] (/. github / README_VI.md) Fietnam | [cy Cymraeg] (/. github / README_CY.md) Cymraeg | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Iddeweg | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Ar gael mewn 110 o ieithoedd (108 wrth beidio â chyfrif Saesneg a Gogledd Corea, gan nad yw Gogledd Corea wedi'i gyfieithu eto [Darllenwch amdano yma] (/ OldVersions / Korean (Gogledd) ) /README.md))

Mae cyfieithiadau mewn ieithoedd heblaw Saesneg yn cael eu cyfieithu â pheiriant ac nid ydyn nhw'n gywir eto. Nid oes unrhyw wallau wedi'u gosod eto ar 5 Chwefror 2021. Rhowch wybod am wallau cyfieithu [yma] (https://github.com/seanpm2001/CamCamPlus/issues/) gwnewch yn siŵr eich bod yn gwneud copi wrth gefn o'ch cywiriad gyda ffynonellau ac yn fy arwain, fel na roddaf. dydw i ddim yn adnabod ieithoedd heblaw Saesneg yn dda (dwi'n bwriadu cael cyfieithydd yn y pen draw) dyfynnwch [wiktionary] (https://en.wiktionary.org) a ffynonellau eraill yn eich adroddiad. Bydd methu â gwneud hynny yn arwain at gyhoeddi gwrthod y cywiriad.

Sylwch: oherwydd cyfyngiadau gyda dehongliad GitHub o markdown (a bron pob dehongliad arall ar y we o markdown) bydd clicio ar y dolenni hyn yn eich ailgyfeirio i ffeil ar wahân ar dudalen ar wahân nad fy nhudalen proffil GitHub. Fe'ch ailgyfeirir i ystorfa [seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), lle cynhelir y README.

Gwneir cyfieithiadau gyda Google Translate oherwydd cefnogaeth gyfyngedig neu ddim cefnogaeth i'r ieithoedd sydd eu hangen arnaf mewn gwasanaethau cyfieithu eraill fel DeepL a Bing Translate. Rwy'n gweithio ar ddod o hyd i ddewis arall. Am ryw reswm, mae'r fformatio (dolenni, rhanwyr, beiddgar, italig, ac ati) yn cael ei gyboli mewn amryw gyfieithiadau. Mae'n ddiflas trwsio, ac nid wyf yn gwybod sut i ddatrys y materion hyn mewn ieithoedd â chymeriadau nad ydynt yn Lladin, ac mae angen cymorth ychwanegol ar yr iaith dde i'r chwith (fel Arabeg) i ddatrys y materion hyn.

Oherwydd materion cynnal a chadw, mae llawer o gyfieithiadau wedi dyddio ac yn defnyddio fersiwn hen ffasiwn o'r ffeil erthygl hon 'README`. Mae angen cyfieithydd. Hefyd, o Ebrill 22ain 2021, bydd yn cymryd ychydig o amser i mi gael yr holl gysylltiadau newydd i weithio.

***

# Mynegai

[00.0 - Uchaf] (# Uchaf)

> [00.1 - Teitl] (# CamCamPlus)

> [00.2 - Darllenwch yr erthygl hon mewn iaith wahanol] (# Read-this-article-in-a-different-language)

> [00.3 - Mynegai] (# Mynegai)

[01.0 - Disgrifiad] (# CamCamPlus)

[02.0 - Amdanom] (# Amdanom)

[03.0 - Wici] (# Wiki)

[04.0 - Hanes y fersiwn] (# Fersiwn-hanes)

[05.0 - Statws meddalwedd] (# Statws meddalwedd)

[06.0 - Gwybodaeth Noddwr] (# Noddwr-wybodaeth)

[07.0 - Cyfranwyr] (# Cyfranwyr)

[08.0 - Materion] (# Materion)

> [08.1 - Materion cyfredol] (# Materion cyfredol)

> [08.2 - Rhifynnau'r gorffennol] (# Rhifynnau'r gorffennol)

> [08.3 - Ceisiadau tynnu yn y gorffennol] (# Ceisiadau tynnu-gorffennol)

> [08.4 - Ceisiadau tynnu gweithredol] (# Ceisiadau tynnu-gweithredol)

[09.0 - Adnoddau] (# Adnoddau)

[10.0 - Cyfrannu] (# Cyfrannu)

[11.0 - Ynglŷn â README] (# About-README)

[12.0 - Hanes fersiwn README] (# README-version-history)

[13.0 - Troedyn] (# Rydych chi wedi cyrraedd-diwedd-diwedd-y-README-ffeil)

> [13.1 - Diwedd y ffeil] (# EOF)

***

# CamCamPlus
Mae CamCamPlus yn gamera pen uchel rhad ac am ddim a ffynhonnell agored a all dynnu lluniau a fideos mewn sawl fformat, a llawer o benderfyniadau.

***

## Am

Gweler uchod. Mae'r prosiect hwn yn ymwneud â chamera pwerus ffynhonnell agored sy'n rhoi llawer o opsiynau ac yn chwalu rhwystrau sydd gan apiau camera cyffredin eraill (megis y terfyn recordio 30 munud)

***

## Wici

[Cliciwch / tapiwch yma i weld y prosiect hwn Wiki] (https://github.com/seanpm2001/CamCamPlus/wiki)

Os yw'r prosiect wedi'i fforchio, mae'n debyg y byddai'r Wici wedi'i dynnu. Yn ffodus, rwy'n cynnwys fersiwn wedi'i hymgorffori. Gallwch ei weld [yma] (/ Allanol / ProjectWiki /).

***

## Gwybodaeth noddwr

! [SponsorButton.png] (SponsorButton.png)

Gallwch noddi'r prosiect hwn os dymunwch, ond nodwch yr hyn yr ydych am gyfrannu ato. [Gweler yr arian y gallwch chi roi iddo yma] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Gallwch weld gwybodaeth noddwr arall [yma] (https://github.com/seanpm2001/Sponsor-info/)

Rhowch gynnig arni! Mae'r botwm noddwr wrth ymyl y botwm gwylio / dad-anfon.

***

## Hanes y fersiwn

** Hanes y fersiwn ddim ar gael ar hyn o bryd **

** Nid oes unrhyw fersiynau eraill wedi'u rhestru **

***

## Statws meddalwedd

Mae fy holl waith yn rhad ac am ddim rhai cyfyngiadau. Nid yw DRM (** D ** igital ** R ** estrictions ** M ** anagement) yn bresennol yn unrhyw un o fy ngweithiau.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Cefnogir y sticer hwn gan y Free Sefydliad Meddalwedd. Nid wyf byth yn bwriadu cynnwys DRM yn fy ngweithiau.

Rwy'n defnyddio'r talfyriad "Rheoli Cyfyngiadau Digidol" yn lle'r "Rheoli Hawliau Digidol" mwy adnabyddus gan fod y ffordd gyffredin o fynd i'r afael ag ef yn ffug, nid oes unrhyw hawliau gyda DRM. Mae'r sillafu "Digital Restrictions Management" yn fwy cywir, ac fe'i cefnogir gan [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) a'r [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Defnyddir yr adran hon i godi ymwybyddiaeth am y problemau gyda DRM, a hefyd i'w wrthwynebu. Mae DRM yn ddiffygiol o ran dyluniad ac mae'n fygythiad mawr i bob defnyddiwr cyfrifiadur a rhyddid meddalwedd.

Credyd delwedd: [defectivebydesign.org/drm-free/…400(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Cyfranwyr

Ar hyn o bryd, fi yw'r unig gyfrannwr. Caniateir cyfrannu, cyn belled â'ch bod yn dilyn rheolau'r ffeil [CONTRIBUTING.md] (CONTRIBUTING.md).

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 yn ymrwymo (Ar ddydd Iau, Ebrill 22ain 2021 am 6: 30yp)

> * 2. Dim cyfranwyr eraill.

***

## Materion

### Materion cyfredol

* Dim ar hyn o bryd

* Dim materion cyfredol eraill

Os yw'r ystorfa wedi'i fforchio, mae'n debygol bod materion wedi'u dileu. Yn ffodus rwy'n cadw archif o ddelweddau penodol [yma] (/. Github / Issues /)

[Darllenwch y polisi preifatrwydd ar archifol mater yma] (/. Github / Issues / README.md)

** TL; DR **

Rwy'n archifo fy rhifynnau fy hun. Ni fydd eich rhifyn yn cael ei archifo oni bai eich bod yn gofyn iddo gael ei archifo.

### Rhifynnau'r gorffennol

* Dim ar hyn o bryd

* Dim rhifynnau eraill yn y gorffennol

Os yw'r ystorfa wedi'i fforchio, mae'n debygol bod materion wedi'u dileu. Yn ffodus rwy'n cadw archif o ddelweddau penodol [yma] (/. Github / Issues /)

[Darllenwch y polisi preifatrwydd ar archifol mater yma] (/. Github / Issues / README.md)

** TL; DR **

Rwy'n archifo fy rhifynnau fy hun. Ni fydd eich rhifyn yn cael ei archifo oni bai eich bod yn gofyn iddo gael ei archifo.

### Ceisiadau tynnu yn y gorffennol

* Dim ar hyn o bryd

* Dim ceisiadau tynnu eraill yn y gorffennol

Os yw'r ystorfa wedi'i fforchio, mae'n debygol bod materion wedi'u dileu. Yn ffodus rwy'n cadw archif o ddelweddau penodol [yma] (/. Github / Issues /)

[Darllenwch y polisi preifatrwydd ar archifol mater yma] (/. Github / Issues / README.md)

** TL; DR **

Rwy'n archifo fy rhifynnau fy hun. Ni fydd eich rhifyn yn cael ei archifo oni bai eich bod yn gofyn iddo gael ei archifo.

### Ceisiadau tynnu gweithredol

* Dim ar hyn o bryd

* Dim ceisiadau tynnu gweithredol eraill

Os yw'r ystorfa wedi'i fforchio, mae'n debygol bod materion wedi'u dileu. Yn ffodus rwy'n cadw archif o ddelweddau penodol [yma] (/. Github / Issues /)

[Darllenwch y polisi preifatrwydd ar archifol mater yma] (/. Github / Issues / README.md)

** TL; DR **

Rwy'n archifo fy rhifynnau fy hun. Ni fydd eich rhifyn yn cael ei archifo oni bai eich bod yn gofyn iddo gael ei archifo.

***

## Adnoddau

Dyma rai adnoddau eraill ar gyfer y prosiect hwn:

[Ffeil iaith y prosiect] (PROJECT_LANG.cpp)

[Llyfrgell gyfeirio ymchwil ar gyfer y prosiect hwn] (/ Cyfeiriadau /)

[Y modiwl fideo arbennig ar gyfer y prosiect hwn (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[Ymunwch â'r drafodaeth ar GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

Dim adnoddau eraill ar hyn o bryd.

***

## Cyfrannu

Caniateir cyfrannu ar gyfer y prosiect hwn, cyn belled â'ch bod yn dilyn rheolau'r ffeil `CONTRIBUTING.md`.

[Cliciwch / tap yma i weld y rheolau cyfrannu ar gyfer y prosiect hwn] (CYFRANNU.md)

***

## Am README

Math o ffeil: `Markdown (* .md)`

Fersiwn ffeil: `1 (dydd Iau, Ebrill 22ain 2021 am 6: 30yp)`

Cyfrif llinell: `0,306`

***

## Hanes fersiwn README

Fersiwn 1 (Dydd Iau, Ebrill 22ain 2021 am 6: 30yp)

> Newidiadau:

> * Dechreuwyd y ffeil

> * Ychwanegwyd yr adran deitl

> * Ychwanegwyd y mynegai

> * Ychwanegwyd yr adran am

> * Ychwanegwyd yr adran Wici

> * Ychwanegwyd yr adran hanes fersiwn

Ychwanegwyd yr adran materion.

> * Ychwanegwyd yr adran rhifynnau yn y gorffennol

> * Ychwanegwyd yr adran ceisiadau tynnu yn y gorffennol

> * Ychwanegwyd yr adran ceisiadau tynnu gweithredol

> * Ychwanegwyd yr adran cyfranwyr

> * Ychwanegwyd yr adran sy'n cyfrannu

> * Ychwanegwyd yr adran am README

> * Ychwanegwyd adran hanes fersiwn README

Ychwanegwyd yr adran adnoddau

> * Ychwanegwyd adran statws meddalwedd, gyda sticer a neges ddi-DRM

> * Ychwanegwyd yr adran gwybodaeth noddwr

> * Dim newidiadau eraill yn fersiwn 1

Fersiwn 2 (Yn dod yn fuan)

> Newidiadau:

> * Yn dod yn fuan

> * Dim newidiadau eraill yn fersiwn 2

***

### Rydych wedi cyrraedd diwedd y ffeil README

[Yn ôl i'r brig] (# Uchaf) [Allanfa] (https://github.com)

### EOF

***
