***

# Cam Cam Plus (CC +)

! [{Pictograma proiectului} Această imagine nu s-a încărcat. Poate fi din cauza faptului că fișierul nu a fost accesat sau a unei erori generale. Reîncărcați pagina pentru a remedia o posibilă eroare generală.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# De:

## [Seanpm2001] (https://github.com/seanpm2001) și alți colaboratori

### Sus

# `README.md`

***

## Citiți acest articol într-o altă limbă

** Limba actuală este: ** `engleză (SUA)` _ (traducerile ar putea fi necesare pentru a corecta limba engleză înlocuind limba corectă) _

_🌐 Lista limbilor_

** Sortate după: ** `A-Z`

[Opțiunile de sortare nu sunt disponibile] (https://github.com/Degoogle-your-Life)

([af afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albaneză | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) Arabă | [hy հայերեն] (/. github / README_HY.md) Armenian | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijani | [eu Euskara] (/. github /README_EU.md) Bască | [be Беларуская] (/. Github / README_BE.md) Belarusian | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosniacă | [bg български] (/. Github / README_BG.md) Bulgară | [ca Català] (/. Github / README_CA.md) Catalană | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chineză (simplificată) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chineză (tradițională) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Croată | [cs čeština] (/. Github / README_CS .md) Cehă | [da dansk] (README_DA.md) Daneză | [nl Nederlands] (/. github / README_ NL.md) olandeză | [** en-us English **] (/. github / README.md) English | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonian | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finlandeză | [fr français] (/. github / README_FR.md) franceză | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galiciană | [ka ქართველი] (/. github / README_KA) Georgian | [de Deutsch] (/. github / README_DE.md) Germană | [el Ελληνικά] (/. github / README_EL.md) greacă | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Creole Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) ebraică | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) maghiară | [este Íslenska] (/. github / README_IS.md) islandeză | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) islandeză | [ga Gaeilge] (/. github / README_GA.md) irlandez | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) japoneză | [jw Wong jawa] (/. github / README_JW.md) javanez | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Coreeană (Sud) | [ko-nord 문화어] (README_KO_NORTH.md) coreeană (nord) (NEÎNCĂ TRADUSĂ) | [ku Kurdî] (/. github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirghiză | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lituanian | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgheză | [mk Македонски] (/. github / README_MK.md) Macedoneană | [mg malgache] (/. github / README_MG.md) malgache | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltese | [mi maori] (/. github / README_MI.md) maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolă | [my မြန်မာ] (/. github / README_MY.md) Myanmar (birmaneză) | [ne नेपाली] (/. github / README_NE.md) Nepalieră | [no norsk] (/. github / README_NO.md) Norvegian | [sau ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persană [pl polski] (/. github / README_PL.md) Poloneză | [pt português] (/. github / README_PT.md) portugheză | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Nu există limbi disponibile care încep cu litera Q | [ro Română] (/. github / README_RO.md) română | [ru русский] (/. github / README_RU.md) rusă | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) gaelică scoțiană | [sr Српски] (/. github / README_SR.md) sârbă | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovacă | [sl Slovenščina] (/. github / README_SL.md) slovenă | [deci Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) spaniolă | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Suedeză | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) tătară | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Turcă | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) ucraineană | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnameză | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Disponibil în 110 limbi (108 când nu se numără engleza și coreeana de Nord, deoarece Coreea de Nord nu a fost încă tradusă [Citiți despre aceasta aici] (/ OldVersions / Korean (North ) /README.md))

Traducerile în alte limbi decât engleza sunt traduse automat și nu sunt încă exacte. Încă nu au fost remediate erori începând cu 5 februarie 2021. Vă rugăm să raportați erorile de traducere [aici] (https://github.com/seanpm2001/CamCamPlus/issues/) asigurați-vă că copiați corecția cu surse și îndrumați-mă, așa cum nu Nu știu bine alte limbi decât engleza (intenționez să obțin un traducător în cele din urmă), citați [wiktionary] (https://en.wiktionary.org) și alte surse din raportul dvs. În caz contrar, va fi publicată respingerea corecției.

Notă: datorită limitării interpretării GitHub a markdown-ului (și aproape a oricărei alte interpretări bazate pe web a markdown-ului), făcând clic pe aceste linkuri vă va redirecționa către un fișier separat pe o pagină separată care nu este pagina mea de profil GitHub. Veți fi redirecționat către [depozitul seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), unde este găzduit README.

Traducerile se fac cu Google Translate datorită asistenței limitate sau absente pentru limbile de care am nevoie în alte servicii de traducere precum DeepL și Bing Translate. Lucrez la găsirea unei alternative. Din anumite motive, formatarea (linkuri, divizoare, caractere aldine, cursive etc.) este încurcată în diferite traduceri. Este obositor de remediat și nu știu cum să rezolv aceste probleme în limbi cu caractere non-latine, iar limbile de la dreapta la stânga (cum ar fi araba) este nevoie de ajutor suplimentar pentru remedierea acestor probleme.

Din cauza problemelor de întreținere, multe traduceri sunt depășite și utilizează o versiune învechită a acestui fișier de articol „README”. Este nevoie de un traducător. De asemenea, începând cu 22 aprilie 2021, îmi va lua ceva timp să pun în funcțiune toate noile legături.

***

# Index

[00.0 - Sus] (# Sus)

> [00.1 - Titlu] (# CamCamPlus)

> [00.2 - Citiți acest articol într-o altă limbă] (# Citiți-acest-articol-într-o-limbă-diferită)

> [00.3 - Index] (# Index)

[01.0 - Descriere] (# CamCamPlus)

[02.0 - Despre] (# Despre)

[03.0 - Wiki] (# Wiki)

[04.0 - Istoricul versiunilor] (# Istoricul versiunilor)

[05.0 - Starea software-ului] (# Software-status)

[06.0 - Informații despre sponsor] (# Informații despre sponsor)

[07.0 - Contributori] (# Contributori)

[08.0 - Probleme] (# Numere)

> [08.1 - Numere curente] (# Numere curente)

> [08.2 - Numere trecute] (# Numere trecute)

> [08.3 - Cereri de extragere din trecut] (# Cereri de extragere în trecut)

> [08.4 - Cereri de extragere activă] (# Cereri de extragere activă)

[09.0 - Resurse] (# Resurse)

[10.0 - Contribuind] (# Contribuind)

[11.0 - Despre README] (# Despre-README)

[12.0 - Istoricul versiunilor README] (# README-version-history)

[13.0 - subsol] (# Ai-atins-sfârșitul-fișierului-README)

> [13.1 - Sfârșitul fișierului] (# EOF)

***

# CamCamPlus
CamCamPlus este un aparat foto high-end gratuit și open-source care poate face fotografii și videoclipuri în mai multe formate și rezoluții.

***

## Despre

Vezi deasupra. Acest proiect este despre o cameră puternică open source care oferă multe opțiuni și descompune barierele pe care le au alte aplicații obișnuite de cameră (cum ar fi limita de înregistrare de 30 de minute)

***

## Wiki

[Faceți clic / atingeți aici pentru a vizualiza acest proiect Wiki] (https://github.com/seanpm2001/CamCamPlus/wiki)

Dacă proiectul a fost bifurcat, Wiki a fost probabil eliminat. Din fericire, includ o versiune încorporată. O puteți vizualiza [aici] (/ External / ProjectWiki /).

***

## Informații despre sponsor

! [SponsorButton.png] (SponsorButton.png)

Puteți sponsoriza acest proiect dacă doriți, dar vă rugăm să specificați la ce doriți să donați. [Vedeți fondurile pe care le puteți dona aici] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Puteți vedea alte informații despre sponsori [aici] (https://github.com/seanpm2001/Sponsor-info/)

Încearcă! Butonul de sponsor se află chiar lângă butonul de ceas / de vizionare.

***

## Versiunea istorică

** Istoricul versiunilor indisponibil în prezent **

** Nu există alte versiuni listate **

***

## Starea software-ului

Toate lucrările mele sunt gratuite, unele restricții. DRM (** D ** igital ** R ** restricții ** M ** administrare) nu este prezent în niciuna dintre lucrările mele.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Acest autocolant este susținut de Free Software Foundation. Nu intenționez niciodată să includ DRM în lucrările mele.

Folosesc abrevierea „Digital Restrictions Management” în locul celei mai cunoscute „Digital Rights Management”, deoarece modul obișnuit de abordare este fals, nu există drepturi cu DRM. Ortografia „Managementul restricțiilor digitale” este mai precisă și este susținută de [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) și de [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Această secțiune este utilizată pentru a crește gradul de conștientizare a problemelor cu DRM și, de asemenea, pentru a protesta împotriva acesteia. DRM este defect prin design și reprezintă o amenințare majoră pentru toți utilizatorii de computer și libertatea software-ului.

Credit de imagine: [defectivebydesign.org/drm-free/...)(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Contributori

În prezent, eu sunt singurul colaborator. Contribuția este permisă, atâta timp cât respectați regulile fișierului [CONTRIBUTING.md] (CONTRIBUTING.md).

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 de comisioane (începând de joi, 22 aprilie 2021 la 18:30)

> * 2. Niciun alt contribuabil.

***

## Probleme

### Problemele curente

* Nimic în acest moment

* Nu există alte probleme actuale

Dacă depozitul a fost bifurcat, probabil că problemele au fost eliminate. Din fericire păstrez o arhivă a anumitor imagini [aici] (/. Github / Issues /)

[Citiți aici politica de confidențialitate privind arhivarea problemelor] (/. Github / Issues / README.md)

** TL; DR **

Îmi arhivez propriile numere. Problema dvs. nu va fi arhivată decât dacă solicitați arhivarea acesteia.

### Numerele anterioare

* Nimic în acest moment

* Nu există alte probleme anterioare

Dacă depozitul a fost bifurcat, probabil că problemele au fost eliminate. Din fericire păstrez o arhivă a anumitor imagini [aici] (/. Github / Issues /)

[Citiți aici politica de confidențialitate privind arhivarea problemelor] (/. Github / Issues / README.md)

** TL; DR **

Îmi arhivez propriile numere. Problema dvs. nu va fi arhivată decât dacă solicitați arhivarea acesteia.

### Cereri de extragere din trecut

* Nimic în acest moment

* Nu există alte cereri de extragere din trecut

Dacă depozitul a fost bifurcat, probabil că problemele au fost eliminate. Din fericire păstrez o arhivă a anumitor imagini [aici] (/. Github / Issues /)

[Citiți aici politica de confidențialitate privind arhivarea problemelor] (/. Github / Issues / README.md)

** TL; DR **

Îmi arhivez propriile numere. Problema dvs. nu va fi arhivată decât dacă solicitați arhivarea acesteia.

### Solicitări de extragere active

* Nimic în acest moment

* Nu există alte cereri de extragere active

Dacă depozitul a fost bifurcat, probabil că problemele au fost eliminate. Din fericire păstrez o arhivă a anumitor imagini [aici] (/. Github / Issues /)

[Citiți aici politica de confidențialitate privind arhivarea problemelor] (/. Github / Issues / README.md)

** TL; DR **

Îmi arhivez propriile numere. Problema dvs. nu va fi arhivată decât dacă solicitați arhivarea acesteia.

***

## Resurse

Iată câteva alte resurse pentru acest proiect:

[Fișierul cu limba proiectului] (PROJECT_LANG.cpp)

[Biblioteca de referință de cercetare pentru acest proiect] (/ Referințe /)

[Modulul video special pentru acest proiect (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[Alăturați-vă discuției pe GitHub] (https://github.com/seanpm2001/CamCamPlus/discussions)

Nu există alte resurse în acest moment.

***

## Contribuind

Contribuția este permisă pentru acest proiect, atâta timp cât respectați regulile fișierului `CONTRIBUTING.md`.

[Faceți clic / atingeți aici pentru a vizualiza regulile de contribuție pentru acest proiect] (CONTRIBUTING.md)

***

## Despre README

Tipul de fișier: `Markdown (* .md)`

Versiunea fișierului: `1 (joi, 22 aprilie 2021 la 18:30)`

Număr de linii: „0,306”

***

## README istoricul versiunilor

Versiunea 1 (joi, 22 aprilie 2021 la 18:30)

> Modificări:

> * A pornit fișierul

> * S-a adăugat secțiunea de titlu

> * A fost adăugat indexul

> * S-a adăugat secțiunea despre

> * A fost adăugată secțiunea Wiki

> * A fost adăugată secțiunea istoric versiuni

> * A fost adăugată secțiunea de probleme.

> * A fost adăugată secțiunea de numere anterioare

> * A fost adăugată secțiunea de solicitări de extragere din trecut

> * A fost adăugată secțiunea de cereri de extragere active

> * A fost adăugată secțiunea de colaboratori

> * A fost adăugată secțiunea de contribuție

> * S-a adăugat secțiunea despre README

> * S-a adăugat secțiunea istoric versiuni README

> * A fost adăugată secțiunea de resurse

> * A fost adăugată o secțiune de stare software, cu un sticker și un mesaj DRM gratuit

> * A fost adăugată secțiunea de informații despre sponsori

> * Nu există alte modificări în versiunea 1

Versiunea 2 (În curând)

> Modificări:

> * În curând

> * Nu există alte modificări în versiunea 2

***

### Ați ajuns la sfârșitul fișierului README

[Înapoi sus] (# Sus) [Ieși] (https://github.com)

### EOF

***
