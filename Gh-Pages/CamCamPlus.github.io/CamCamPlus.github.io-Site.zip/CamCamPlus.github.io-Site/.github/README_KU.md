***

# Cam Cam Plus (CC +)

! [{Iconkona projeyê} Ev wêne nehat barkirin. Ew dibe ku ji ber pelê negihîştî ye, an jî çewtiyek gelemperî hebe. Rûpelê ji nû ve bikin da ku çewtiyek giştî ya gengaz sererast bikin.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# By:

## [Seanpm2001] (https://github.com/seanpm2001) û beşdarên din

### Top

# `README.md`

***

## Vê gotarê bi zimanek cûda bixwînin

** Zimanê heyî ev e: ** `Englishngilîzî (DY)` _ (dibe ku werger hewce be werin rast kirin ku Englishngilîzî li şûna zimanê rast were rastkirin) _

_🌐 Navnîşa zimanan_

** Bi rêzkirin: ** `A-Z`

[Vebijarkên Rêzkirinê çênabe] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanî | [am አማርኛ] (/. github / README_AM.md) Amharî | [ar عربى] (/.github/README_AR.md) Erebî | [hy Kurdî] (/. github / README_HY.md) Ermenî | [az Azərbaycan dili] (/. github / README_AZ.md) Azerî | [eu Euskara] (/. github /README_EU.md) Baskî | [Be Беларуская] (/. Github / README_BE.md) Belarusî | [bn বাংলা] (/. Github / README_BN.md) Bengalî | [bs Bosanski] (/. Github / README_BS.md) Bosnî | [bg български] (/. Github / README_BG.md) Bulgarî | [ca Català] (/. Github / README_CA.md) Katalanî | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Çînî (Hêsankirî) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Çînî (Kevneşopî) | [co Corsu] (/. Github / README_CO.md) Korsîkî | [hr Hrvatski] (/. Github / README_HR.md) Croatian | [cs čeština] (/. Github / README_CS .md) Çekî | [da dansk] (README_DA.md) Danîmarkî | [nl Nederlands] (/. github / README_ NL.md) Hollandî | [** en-us **ngilîzî **] (/. github / README.md) Englishngilîzî | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonî | [tl Pîlîpînî] (/. github / README_TL.md) Filîpînî | [fi Suomalainen] (/. github / README_FI.md) Fînî | [fr français] (/. github / README_FR.md) Fransî | [frysk] (/. github / README_FY.md) frîsî | [gl Galego] (/. github / README_GL.md) Galîkî | [ka Kurd] (/. github / README_KA) Gurcî | [de Deutsch] (/. github / README_DE.md) Almanî | [el Ελληνικά] (/. github / README_EL.md) Grekî | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Creole Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawayî | [ew] (/. github / README_HE.md) Hebrewbranî | [silav हिन्दी] (/. github / README_HI.md) Hindî | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Macarîstan | [islenska ye] (/. github / README_IS.md) Icelandiczlandî | [ig Igbo] (/. github / README_IG.md) Igbo | [id Indonesia Indonesia] (/. github / README_ID.md) Icelandiczlandî | [ga Gaeilge] (/. github / README_GA.md) îrlandî | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japonî | [jw Wong jawa] (/. github / README_JW.md) Javayî | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kanada | [kk Қазақ] (/. github / README_KK.md) Kazakî | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-başûr 韓國 語] (/. github / README_KO_SOUTH.md) Koreyî (Başûr) | [ko-bakûr 문화어] (README_KO_NORTH.md) Koreyî (Bakur) (H YN NN WERGERAND) | [ku Kurdî] (/. github / README_KU.md) Kurdî (Kurmancî) | [ky Keys] (/. github / README_KY.md) Kirgizîstan | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latînî] (/. github / README_LA.md) Latînî | [lt Lietuvis] (/. github / README_LT.md) Lîtvanî | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksembûrg | [mk Македонски] (/. github / README_MK.md) Makedonî | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Melayu Bahasa] (/. github / README_MS.md) Malayî | [ml മലയാളം] (/. github / README_ML.md) Malayî | [mt Malti] (/. github / README_MT.md) Maltese | [mi Maorî] (/. github / README_MI.md) Maorî | [mr मराठी] (/. github / README_MR.md) Maratî | [mn Mongol] (/. github / README_MN.md) Mongolî | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Burmese) | [ne नेपाली] (/. github / README_NE.md) Nepalî | [no norsk] (/. github / README_NO.md) Norwêcî | [an ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Paştî | [fa فارسی] (/. github / README_FA.md) | Farisî [pl polski] (/. github / README_PL.md) Polonî | [pt português] (/. github / README_PT.md) Portekîzî | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Pencabî | Zimanên ku bi herfa Q | dest pê dikin tune [ro Română] (/. github / README_RO.md) Romanî | [ru руский] (/. github / README_RU.md) Rûsî | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scottish Gaelic | [sr Српски] (/. github / README_SR.md) Sirbî | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindî | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovakî | [sl Slovenščina] (/. github / README_SL.md) Slovenî | [so Soomaali] (/. github / README_SO.md) Somalî | [[es en español] (/. github / README_ES.md) Spanishspanî | [su Sundanis] (/. github / README_SU.md) Sundanî | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Swêdî | [tg Тоҷикӣ] (/. github / README_TG.md) Tacîkî | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Tirkî | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukranî | [ur اردو] (/. github / README_UR.md) urdû | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Viyetnamî | [cy Cymraeg] (/. github / README_CY.md) Welşî | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Di 110 zimanan de heye (108 dema ku whenngilîzî û Koreya Bakur nayê hesibandin, ji ber ku Koreya Bakur hîn nehatiye wergerandin [Li ser vê yekê bixwînin] (/ OldVersions / Koreyî (Bakur ) /README.md))

Wergerên bi zimanên din ji bilî Englishngilîzî bi makîneyê têne wergerandin û hêj ne rast in. Ji 5-ê Sibata 2021.-an û vir ve tu xelet nehatine rast kirin. Ji kerema xwe xeletiyên wergerandinê ragihînin [li vir] (https://github.com/seanpm2001/CamCamPlus/issues/) rast bikin ku rastkirina xwe ji çavkaniyan re hilanîn û rêber bikin, wekî ez 'hûn ji bilî Englishngilîzî zimanên din baş nizanin (Ez plan dikim ku di dawiyê de wergêrekî wergirim) ji kerema xwe [wiktionary] (https://en.wiktionary.org) û çavkaniyên din di rapora xwe de bi nav bikin. Ku wiya neke dê encama redkirina rastkirina ku hatî weşandin encam bide.

Nîşe: ji ber hûrgelan bi şîrovekirina nîşankirinê ya GitHub (û hema hema her şiroveya tevnavkirina nîşana nîşankirinê) bi tikandina van lînkan dê we ber bi pelê veqetandî ve vegerîne ser rûpelek cûda ku ne rûpelê profîla min a GitHub e. Hûn ê werin veguhastin [embara] seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), ku README lê tê mêvan kirin.

Werger ji ber ku ji bo zimanên ku ez di karûbarên wergerandinê yên din de mîna DeepL û Bing Translate hewce dikim, bi Google Translate re tête kirin. Ez li ser dîtina alternatîfek dixebitim. Ji ber hin sedeman, formatkirin (girêdan, dabeşker, qelew, pît, û hwd.) Di wergerandinên cûrbecûr de tevlihev dibe. Çareserkirin westiyayî ye, û ez nizanim çawa van mijaran di zimanên bi tîpên ne-latînî de sererast bikim, û ji zimanên rastê çepê (mîna Erebî) ji bo sererastkirina van pirsgirêkan arîkariyek zêde hewce ye

Ji ber pirsgirêkên parastinê, gelek werger mêjû ne û guhertoyek kevn a vê pelê gotara `README` bikar tînin. Wergêr pêdivî ye. Di heman demê de, ji 22-ê Nîsana 2021-an ve, ew ê demekê bikişîne ku ez hemî girêdanên nû bixebitînim.

***

# Indexndeks

[00.0 - Top] (# Top)

> [00.1 - Sernav] (# CamCamPlus)

> [00.2 - Vê gotarê bi zimanek cûda bixwînin] (# Vê gotarê-bi-zimanek-cuda bixwînin)

> [00.3 - Endeks] (# Endeks)

[01.0 - Danasîn] (# CamCamPlus)

[02.0 - Derheqê] (# Derheqê)

[03.0 - Wiki] (# Wiki)

[04.0 - Dîroka Guhertoyan] (# Dîroka Guhertoyan)

[05.0 - Rewşa nermalavê] (# Status-nermalav)

[06.0 - Agahdariya sponsor] (# agahdariya sponsor)

[07.0 - Alîkar] (# Beşdar)

[08.0 - Mijar] (# Mijar)

> [08.1 - Pirsgirêkên heyî] (# Mijarên heyî)

> [08.2 - Hejmarên borî] (# Hejmarên borî)

> [08.3 - Daxwazên paşîn kişandin] (# Daxwazên paşîn-kişandin)

> [08.4 - Daxwazên vekişîna çalak] (# Daxwaz-vekişîna çalak)

[09.0 - Çavkanî] (# Çavkanî)

[10.0 - Beşdarbûn] (# Beşdarîkirin)

[11.0 - Derheqê README] (# Derheqê-README)

[12.0 - Dîroka Guhertoya README] (# README-guhertoya-dîrokê)

[13.0 - Footer] (# Hûn-gihiştin-dawiya-pel-ê-README-yê)

> [13.1 - Dawiya pelê] (# EOF)

***

# CamCamPlus
CamCamPlus kamerayek serbixwe û çavkanî ya payebilind e ku dikare di gelek formatan de, û gelek biryaran wêne û vîdyoyan bikişîne.

***

## Der barê

Li jor binêrin. Ev proje li ser kameraya hêzdar a çavkaniya vekirî ye ku gelek vebijarkan dide û astengên ku sepanên din ên kamerayên hevpar hene (mînakî 30 hûrdema sînorê tomarkirinê) hilweşîne.

***

## Wiki

[Ji bo dîtina vê projeyê Wiki bitikîne / tap bike] (https://github.com/seanpm2001/CamCamPlus/wiki)

Heke proje hatibe fork kirin, dibe ku Wiki hate rakirin. Bi kêfxweşî, ez guhertoyek bicîhkirî tê de dikim. Hûn dikarin wê [vir] (/ Derve / ProjectWiki /) bibînin.

***

## Agahdariya sponsor

! [SponsorButton.png] (SponsorButton.png)

Ger hûn bixwazin hûn dikarin sponsoriya vê projeyê bikin, lê ji kerema xwe tiştê ku hûn dixwazin bexş bikin diyar bikin. [Darayên ku hûn dikarin bexş bikin li vir bibînin] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Hûn dikarin agahdariyên sponsor ên din jî bibînin [li vir] (https://github.com/seanpm2001/Sponsor-info/)

Biceribînin! Bişkoka sponsor li tenişta bişkoja temaşekirinê / nehiştinê rast e.

***

## dîroka guhertoya

** Dîroka guhertoyên ku niha tune ye **

** Guhertoyên din nehatî navandin **

***

## Rewşa nermalavê

Hemî xebatên min belaş hin qedexe ne. DRM (** D ** igital ** R ** vegotin ** M ** tevger) di tu xebatên min de tune.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ev sticker ji hêla Fre ve tê piştgirî kirine Weqfa Nermalavê. Ez qet naxwazim ku DRM têxim nav karên xwe.

Ez kurteya "Birêvebirina Qedexeyên Dîjîtal" bi kar tînim li şûna ku bêtir tê zanîn "Birêvebiriya Mafên Dîjîtal" wekî awayê hevpar ê xîtabê wê derew e, tu mafên DRM tune. Nivîsîna "Birêvebirina Qedexeyên Dîjîtal" rasttir e, û ji hêla [Richard M. Stallman (RMS)]] (https://en.wikipedia.org/wiki/Richard_Stallman) û [Weqfa Nermalava Azad (FSF)] ve tê piştgirî kirin () https://en.wikipedia.org/wiki/Found_Software_Foundation_Free)

Ev beş tête bikar anîn ku ji bo pirsgirêkên bi DRM re hişyar bikin, û her weha protesto bikin. DRM ji hêla sêwiranê ve kêmas e û ji bo hemî bikarhênerên computer û azadiya nermalavê xeterek mezin e.

Baweriya wêneyê: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Tevkar

Naha, ez tenê tevkar im. Beşdarîkirin destûr tê dayin, heya ku hûn qaîdeyên pelê [CONTRIBUTING.md] (CONTRIBUTING.md) bişopînin.

> * 1.

> * 2. Beşdarên din tune.

***

## Mijar

### Pirsgirêkên heyî

* Vêga tune

* Pirsgirêkên heyî yên din tune

Ger depo hatiye fork kirin, dibe ku pirsgirêkên hatine derxistin. Bi kêfxweşî ez arşîva hin wêneyan digirim [li vir] (/. Github / Issues /)

[Siyaseta taybetîtiyê ya li ser arşîva pirsgirêkan li vir bixwînin] (/. Github / Issues / README.md)

** TL; DR **

Ez pirsgirêkên xwe arşîv dikim. Pirsgirêka we nayê arşîv kirin heya ku hûn nexwazin werin arşîv kirin.

### Hejmarên berê

* Vêga tune

* Pirsgirêkên berê yên din tune

Ger depo hatiye fork kirin, dibe ku pirsgirêkên hatine derxistin. Bi kêfxweşî ez arşîva hin wêneyan digirim [li vir] (/. Github / Issues /)

[Siyaseta taybetîtiyê ya li ser arşîva pirsgirêkan li vir bixwînin] (/. Github / Issues / README.md)

** TL; DR **

Ez pirsgirêkên xwe arşîv dikim. Pirsgirêka we nayê arşîv kirin heya ku hûn nexwazin werin arşîv kirin.

### Daxwaziyên kişandina borî

* Vêga tune

* Tu daxwazên vekişînê yên berê tune

Ger depo hatiye fork kirin, dibe ku pirsgirêkên hatine derxistin. Bi kêfxweşî ez arşîva hin wêneyan digirim [li vir] (/. Github / Issues /)

[Siyaseta taybetîtiyê ya li ser arşîva pirsgirêkan li vir bixwînin] (/. Github / Issues / README.md)

** TL; DR **

Ez pirsgirêkên xwe arşîv dikim. Pirsgirêka we nayê arşîv kirin heya ku hûn nexwazin werin arşîv kirin.

### Daxwazên kişandina çalak

* Vêga tune

* Tu daxwazên vekişînê yên çalak tune

Ger depo hatiye fork kirin, dibe ku pirsgirêkên hatine derxistin. Bi kêfxweşî ez arşîva hin wêneyan digirim [li vir] (/. Github / Issues /)

[Siyaseta taybetîtiyê ya li ser arşîva pirsgirêkan li vir bixwînin] (/. Github / Issues / README.md)

** TL; DR **

Ez pirsgirêkên xwe arşîv dikim. Pirsgirêka we nayê arşîv kirin heya ku hûn nexwazin werin arşîv kirin.

***

## Çavkaniyên

Vê çavkaniyên din ên vê projeyê hene:

[Pelê zimanê projeyê] (PROJECT_LANG.cpp)

[Ji bo vê projeyê pirtûkxaneya referansa lêkolînê] (/ Çavkanî /)

[Moduleya vîdyoyê ya taybetî ji bo vê projeyê (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[Beşdarî nîqaşa li ser GitHub bibin] (https://github.com/seanpm2001/CamCamPlus/discussions)

Vê gavê çavkaniyên din tune.

***

## Beşdarîkirin

Beşdarî ji bo vê projeyê tête destûr kirin, bi şertê ku hûn qaîdeyên pelê `CONTRIBUTING.md` bişopînin.

[Ji bo dîtina rêgezên beşdarî vê projeyê bikirtînin / tapînin vir] (CONTRIBUTING.md)

***

## About README

Pelê pelê: `Markdown (* .md)`

Guhertoya pelê: `1 (Pêncşem, 22-ê Avrêl 2021 li 6:30 danê êvarê)`

Jimareya rêzê: `0,306`

***

## Dîroka guhertoya README

Guhertoya 1 (Pêncşem, 22-ê Avrêl 2021 li 6:30 danê êvarê)

> Guherandin:

> * Pelê dest pê kir

> * Beşa sernavê zêde kir

> * Sermaseyê zêde kir

> * Beşa derbarê zêde kir

> * Beşa Wiki-yê zêde kir

> * Beşa dîroka guhertoya zêde kir

> * Beşa pirsgirêkan zêde kir.

> * Beşa hejmarên borî zêde kir

> * Beşa daxwazên kişandina borî zêde kir

> * Beşa daxwazên kişandina çalak lê zêde kir

> * Beşa beşdaran zêde kir

> * Beşa tevkariyê zêde kir

> * Derheqê beşa README de zêde kir

> * Beşa dîroka guhertoya README zêde kir

> * Beşa çavkaniyan zêde kir

> * Beşa statûya nermalavê, bi diruşmeyek û peyamek belaş a DRM, lê zêde kir

> * Beşa agahdariya sponsor zêde kir

> * Di guhertoya 1 de guhertinên din çênabin

Guhertoya 2 (Di nêzîk de tê)

> Guherandin:

> * Zûtir tê

> * Di guhertoya 2-an de guherînek din çênebû

***

### Hûn gihiştin dawiya pelê README

[Vegere jor] (# Top) [Exit] (https://github.com)

### EOF

***
