***

# Cam Cam Plus (CC +)

! [{Projektikuvake} Tämän kuvan lataaminen epäonnistui. Se voi johtua siitä, että tiedostoa ei ole saavutettu, tai yleisestä virheestä. Korjaa mahdollinen yleinen virhe lataamalla sivu uudelleen.] (/ Docs / Graphics / iOS6 / JPEG / Camera_iOS6_Placeholder.jpeg)

# Kirjoittaja:

## [Seanpm2001] (https://github.com/seanpm2001) ja muut avustajat

### Alkuun

# `` README.md ''

***

## Lue tämä artikkeli toisella kielellä

** Nykyinen kieli on: ** `englanti (Yhdysvallat)` _ (käännökset saatetaan joutua korjaamaan oikean kielen korvaamiseksi.

_🌐 Luettelo kielistä_

** Lajiteltu: ** `` A-Z``

[Lajitteluvaihtoehdot eivät ole käytettävissä] (https://github.com/Degoogle-your-Life)

([af afrikaans] (/. github / README_AF.md) afrikaans | [sq Shqiptare] (/. github / README_SQ.md) albania | [am አማርኛ] (/. github / README_AM.md) amhara | [ar عربى] (/.github/README_AR.md) arabia | [hy հայերեն] (/. github / README_HY.md) armenia | [az Azərbaycan dili] (/. github / README_AZ.md) azerbaidžanilainen | [eu Euskara] (/. github /README_EU.md) baski | [be Беларуская] (/. Github / README_BE.md) valkovenäjä | [bn বাংলা] (/. Github / README_BN.md) bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) bulgaria | [ca Català] (/. Github / README_CA.md) katalaani | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichew ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) kiina (yksinkertaistettu) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) kiina (perinteinen) | [co Corsu] (/. Github / README_CO.md) korsikalainen | [hr Hrvatski] (/. Github / README_HR.md) kroatia | [cs čeština] (/. Github / README_CS .md) tšekki | [da dansk] (README_DA.md) tanska | [nl Nederlands] (/. github / README_ NL.md) hollanti | [** fi-fi englanti **] (/. github / README.md) englanti | [EO esperanto] (/. Github / README_EO.md) esperanto | [et Eestlane] (/. github / README_ET.md) viro | [tl Pilipino] (/. github / README_TL.md) filippiiniläinen | [fi Suomalainen] (/. github / README_FI.md) suomi | [fr français] (/. github / README_FR.md) ranska | [fy Frysk] (/. github / README_FY.md) Friisi | [gl Galego] (/. github / README_GL.md) galicia | [ka ქართველი] (/. github / README_KA) georgialainen | [de Deutsch] (/. github / README_DE.md) saksa | [el Ελληνικά] (/. github / README_EL.md) kreikka | [gu ગુજરાતી] (/. github / README_GU.md) gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitin kreoli | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) havaijilainen | [he עִברִית] (/. github / README_HE.md) heprea | [hi हिन्दी] (/. github / README_HI.md) hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) unkari | [on Íslenska] (/. github / README_IS.md) islanti | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) islanti | [ga Gaeilge] (/. github / README_GA.md) irlanti | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) japani | [jw Wong jawa] (/. github / README_JW.md) jaava | [kn ಕನ್ನಡ] (/. github / README_KN.md) kannada | [kk Қазақ] (/. github / README_KK.md) kazakstan | [km ខ្មែរ] (/. github / README_KM.md) khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-etelä 韓國 語] (/. github / README_KO_SOUTH.md) korea (etelä) | [ko-pohjoinen 문화어] (README_KO_NORTH.md) korea (pohjoinen) (EI Vielä Käännetty) | [ku Kurdî] (/. github / README_KU.md) kurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) kirgisia | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) liettua | [lb Lëtzebuergesch] (/. github / README_LB.md) luxemburg | [mk Македонски] (/. github / README_MK.md) makedonia | [mg madagaskaria] (/. github / README_MG.md) madagaskaria | [ms Bahasa Melayu] (/. github / README_MS.md) malaiji | [ml മലയാളം] (/. github / README_ML.md) malajalam | [mt Malti] (/. github / README_MT.md) maltan kieli | [mi maori] (/. github / README_MI.md) maori | [herra मराठी] (/. github / README_MR.md) marathi | [mn Монгол] (/. github / README_MN.md) mongoli | [my မြန်မာ] (/. github / README_MY.md) Myanmar (burmalainen) | [ne नेपाली] (/. github / README_NE.md) Nepali | [ei norsk] (/. github / README_NO.md) norja | [tai ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) pastu | [fa فارسی] (/. github / README_FA.md) | persia [pl polski] (/. github / README_PL.md) puola | [pt português] (/. github / README_PT.md) portugali | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) pandžabi | Q-kirjaimella alkavia kieliä ei ole käytettävissä [ro Română] (/. github / README_RO.md) romania | [ru русский] (/. github / README_RU.md) venäjä | [sm Faasamoa] (/. github / README_SM.md) Samoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) skotti gaeli | [sr Српски] (/. github / README_SR.md) serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) slovakia | [sl Slovenščina] (/. github / README_SL.md) sloveeni | [niin Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) espanja | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) suahili | [sv Svenska] (/. github / README_SV.md) ruotsi | [tg Тоҷикӣ] (/. github / README_TG.md) tadžiki | [ta தமிழ்] (/. github / README_TA.md) tamili | [tt Татар] (/. github / README_TT.md) tataari | [te తెలుగు] (/. github / README_TE.md) telugu | [th ไทย] (/. github / README_TH.md) thai | [tr Türk] (/. github / README_TR.md) turkki | [tk Türkmenler] (/. github / README_TK.md) turkmeeni | [uk Український] (/. github / README_UK.md) ukraina | [ur اردو] (/. github / README_UR.md) urdu | [ug ئۇيغۇر] (/. github / README_UG.md) uiguuri | [uz O'zbek] (/. github / README_UZ.md) uzbekki | [vi Tiếng Việt] (/. github / README_VI.md) vietnam | [cy Cymraeg] (/. github / README_CY.md) kymri | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jiddiš | [yo joruba] (/. github / README_YO.md) joruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Saatavilla 110 kielellä (108, kun ei lasketa englantia ja pohjoiskorealaista, koska pohjoiskorealaista ei ole vielä käännetty [Lue tästä] (/ OldVersions / Korea (pohjoinen) ) /README.md))

Käännökset muille kielille kuin englanniksi käännetään koneella, eivätkä ne ole vielä tarkkoja. Virheitä ei ole vielä korjattu 5. helmikuuta 2021. Ilmoita käännösvirheistä [täällä] (https://github.com/seanpm2001/CamCamPlus/issues/) varmista, että varmuuskopioit korjauksesi lähteillä ja ohjaat minua 'ei osaa muita kieliä kuin englantia hyvin (aion hankkia kääntäjän lopulta), mainitse [wikisanakirja] (https://fi.wiktionary.org) ja muut lähteet raportissasi. Jos näin ei tehdä, korjauksen julkaiseminen hylätään.

Huomaa: GitHubin tulkinnan rajoitusten vuoksi (ja melkein kaikki muut verkkopohjaiset merkinnät) näiden linkkien napsauttaminen ohjaa sinut erilliseen tiedostoon erilliselle sivulle, joka ei ole minun GitHub-profiilisivu. Sinut ohjataan [seanpm2001 / seanpm2001-arkistoon] (https://github.com/seanpm2001/seanpm2001), jossa README-palvelinta isännöidään.

Käännökset tehdään Google Kääntäjällä, koska muissa käännöspalveluissa, kuten DeepL ja Bing Translate, tarvitsemani kielet ovat rajalliset tai eivät lainkaan. Työskentelen vaihtoehdon löytämiseksi. Jostain syystä muotoilu (linkit, jakajat, taivutus, kursivointi jne.) Sekoitetaan erilaisissa käännöksissä. Se on tylsää korjata, enkä tiedä kuinka korjata nämä ongelmat kielillä, joissa ei ole latinankielisiä merkkejä, ja oikealta vasemmalle (kuten arabia) käytetyille kielille tarvitaan lisäapua näiden ongelmien korjaamiseen

Huolto-ongelmien takia monet käännökset ovat vanhentuneita ja käyttävät tämän `` README`` -artikkelitiedoston vanhentunutta versiota. Kääntäjä tarvitaan. Lisäksi 22. huhtikuuta 2021 alkaen minulla kestää jonkin aikaa saada kaikki uudet linkit toimimaan.

***

# Indeksi

[00.0 - Yläosa] (# Yläosa)

> [00.1 - Otsikko] (# CamCamPlus)

> [00.2 - Lue tämä artikkeli eri kielellä] (# Lue-tämä-artikkeli-eri-kielellä)

> [00.3 - Hakemisto] (# Hakemisto)

[01.0 - Kuvaus] (# CamCamPlus)

[02.0 - Tietoja] (# Tietoja)

[03.0 - Wiki] (# Wiki)

[04.0 - Versiohistoria] (# Versiohistoria)

[05.0 - Ohjelmiston tila] (# Ohjelmiston tila)

[06.0 - Sponsoritiedot] (# Sponsor-info)

[07.0 - Avustajat] (# Avustajat)

[08.0 - numerot] (# numerot)

> [08.1 - Ajankohtaista] (# Ajankohtaista)

> [08.2 - Aikaisemmat numerot] (# Aiemmat numerot)

> [08.3 - Aiemmat vedonpyynnöt] (# Aikaisemmat vedä-pyynnöt)

> [08.4 - Aktiiviset vetopyynnöt] (# Aktiiviset vedonpyynnöt)

[09.0 - Resurssit] (# Resurssit)

[10.0 - osallistuminen] (# osallistuva)

[11.0 - Tietoja README-ohjelmasta] (# About-README)

[12.0 - README-versiohistoria] (# README-version-historia)

[13.0 - alatunniste] (# Olet saavuttanut README-tiedoston lopun)

> [13.1 - Tiedoston loppu] (# EOF)

***

# CamCamPlus
CamCamPlus on huippuluokan ilmainen ja avoimen lähdekoodin kamera, joka voi ottaa kuvia ja videoita monissa muodoissa ja monilla tarkkuuksilla.

***

## Tietoja

Katso edellä. Tämä projekti koskee avoimen lähdekoodin tehokasta kameraa, joka tarjoaa monia vaihtoehtoja ja hajottaa esteitä, joita muilla tavallisilla kamerasovelluksilla on (kuten 30 minuutin tallennusraja)

***

## Wiki

[Napsauta / napauta tätä nähdäksesi tämän projektin Wikin] (https://github.com/seanpm2001/CamCamPlus/wiki)

Jos projekti on haarautunut, Wiki todennäköisesti poistettiin. Onneksi olen sisällyttänyt upotetun version. Voit tarkastella sitä [täällä] (/ External / ProjectWiki /).

***

## Sponsoritiedot

! [SponsorButton.png] (SponsorButton.png)

Voit sponsoroida tätä projektia, jos haluat, mutta täsmennä, mihin haluat lahjoittaa. [Katso varat, joita voit lahjoittaa täältä] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Voit tarkastella muita sponsoritietoja [täällä] (https://github.com/seanpm2001/Sponsor-info/)

Kokeile! Sponsoripainike on aivan katselu- / katselupainikkeen vieressä.

***

## Versiohistoria

** Versiohistoria ei ole tällä hetkellä käytettävissä **

** Muita versioita ei ole luettelossa **

***

## Ohjelmiston tila

Kaikilla teoksillani on joitain rajoituksia. DRM (** D ** igital ** R ** estektiot ** M ** anagement) ei ole missään teoksissani.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Fre tukee tätä tarraae Software Foundation. En koskaan aio sisällyttää DRM: ää teoksihini.

Käytän lyhennettä "Digital Restrictions Management" tunnetumman "Digital Rights Management": n sijaan, koska yleinen tapa puuttua siihen on väärä, DRM: llä ei ole oikeuksia. Oikeinkirjoitus "Digital Restrictions Management" on tarkempi, ja sitä tukevat [Richard M. Stallman (RMS)] (https://fi.wikipedia.org/wiki/Richard_Stallman) ja [Free Software Foundation (FSF)] ( https://fi.wikipedia.org/wiki/Free_Software_Foundation)

Tätä osaa käytetään lisäämään tietoisuutta DRM-ongelmista ja myös vastustamaan sitä. DRM on rakenteeltaan viallinen ja on suuri uhka kaikille tietokoneen käyttäjille ja ohjelmistovapaudelle.

Kuvahyvitys: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Avustajat

Tällä hetkellä olen ainoa avustaja. Osallistuminen on sallittua, kunhan noudatat [CONTRIBUTING.md] (CONTRIBUTING.md) -tiedoston sääntöjä.

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - 138 sitoutuu (torstaina 22. huhtikuuta 2021 klo 18.30)

> * 2. Ei muita avustajia.

***

## ongelmat

### Tämänhetkiset ongelmat

* Ei tällä hetkellä

* Ei muita ajankohtaisia ​​kysymyksiä

Jos arkisto on haarautunut, ongelmat on todennäköisesti poistettu. Onneksi pidän arkistoa tietyistä kuvista [täällä] (/. Github / Issues /)

[Lue tietosuojakäytäntö ongelmien arkistoinnista täältä] (/. Github / Issues / README.md)

** TL; DR **

Arkistoin omat numeroni. Aiheesi arkistoidaan, ellet pyydä sen arkistointia.

### Aiemmat ongelmat

* Ei tällä hetkellä

* Ei muita aikaisempia kysymyksiä

Jos arkisto on haarautunut, ongelmat on todennäköisesti poistettu. Onneksi pidän arkistoa tietyistä kuvista [täällä] (/. Github / Issues /)

[Lue tietosuojakäytäntö ongelmien arkistoinnista täältä] (/. Github / Issues / README.md)

** TL; DR **

Arkistoin omat numeroni. Aiheesi arkistoidaan, ellet pyydä sen arkistointia.

### Aiemmat vetopyynnöt

* Ei tällä hetkellä

* Ei muita aikaisempia vetopyyntöjä

Jos arkisto on haarautunut, ongelmat on todennäköisesti poistettu. Onneksi pidän arkistoa tietyistä kuvista [täällä] (/. Github / Issues /)

[Lue tietosuojakäytäntö ongelmien arkistoinnista täältä] (/. Github / Issues / README.md)

** TL; DR **

Arkistoin omat numeroni. Aiheesi arkistoidaan, ellet pyydä sen arkistointia.

### Aktiiviset vetopyynnöt

* Ei tällä hetkellä

* Ei muita aktiivisia vetopyyntöjä

Jos arkisto on haarautunut, ongelmat on todennäköisesti poistettu. Onneksi pidän arkistoa tietyistä kuvista [täällä] (/. Github / Issues /)

[Lue tietosuojakäytäntö ongelmien arkistoinnista täältä] (/. Github / Issues / README.md)

** TL; DR **

Arkistoin omat numeroni. Aiheesi arkistoidaan, ellet pyydä sen arkistointia.

***

## Resurssit

Tässä on joitain muita resursseja tälle projektille:

[Projektin kielitiedosto] (PROJECT_LANG.cpp)

[Tämän projektin tutkimuksen viitekirjasto] (/ Referenssit /)

[Tämän projektin erityinen videomoduuli (SVG Video)] (https://github.com/seanpm2001/SVG_Video/)

[Liity keskusteluun GitHubissa] (https://github.com/seanpm2001/CamCamPlus/discussions)

Ei muita resursseja tällä hetkellä.

***

## Osallistuminen

Osallistuminen on sallittua tässä projektissa, kunhan noudatat `CONTRIBUTING.md`-tiedoston sääntöjä.

[Napsauta / napauta tätä nähdäksesi tämän projektin avustavat säännöt] (CONTRIBUTING.md)

***

## Tietoja README-palvelusta

Tiedostotyyppi: `Markdown (* .md)`

Tiedostoversio: "1 (torstaina 22. huhtikuuta 2021 klo 18.30)"

Linjan määrä: "0,306"

***

## README-versiohistoria

Versio 1 (torstaina 22. huhtikuuta 2021 klo 18.30)

> Muutokset:

> * Käynnisti tiedosto

> * Lisätty otsikko-osa

> * Lisätty hakemisto

> * Lisätty Tietoja-osio

> * Lisätty Wiki-osio

> * Lisätty versiohistoria-osio

> * Lisäsi aihealueen.

> * Lisäsi aiemmat numerot -osion

> * Lisättiin aikaisemmat vetopyynnöt

> * Lisätty aktiivisten vetopyyntöjen osio

> * Lisätty avustajat-osio

> * Lisätty avustava osa

> * Lisäsi about README -osion

> * Lisäsi README-versiohistoria-osan

> * Lisätty resurssit-osio

> * Lisätty ohjelmiston tilaosio, jossa on DRM-vapaa tarra ja viesti

> * Lisätty sponsorin tiedot -osio

> * Ei muita muutoksia versiossa 1

Versio 2 (Tulossa pian)

> Muutokset:

> * Tulossa pian

> * Ei muita muutoksia versiossa 2

***

### Olet saavuttanut README-tiedoston loppuun

[Takaisin alkuun] (# alkuun) [Poistu] (https://github.com)

### EOF

***
