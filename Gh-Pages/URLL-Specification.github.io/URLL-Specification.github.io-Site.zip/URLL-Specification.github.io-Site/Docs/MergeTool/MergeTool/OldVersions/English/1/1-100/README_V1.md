
***

# Merge Tool

The merge tool is a simple script written in ToBeDecided that lets you merge multiple URL files into a single URL list file. You can also choose to keep or overwrite the existing copies once the URLL file is creating. The limit for file merging is set to 4,000,000,000,000 bytes (4 terabytes) per URLL file merge.

**This document on Merging is incomplete. You can help by _expanding it._**

***
