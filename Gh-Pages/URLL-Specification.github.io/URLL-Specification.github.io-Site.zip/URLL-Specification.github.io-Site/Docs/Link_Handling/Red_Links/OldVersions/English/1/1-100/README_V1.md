
***

# Red links

If a link is detected as invalid, it will appear by default as a red link. This is to tell you that the link provided does not work.

URLL files by default don't connect to the Internet, and doesn't have a database of working and dead links, so you either have to manually define them, or purposefully write an invalid URL.

**This document on Link Handling is incomplete. You can help by _expanding it._**

***
