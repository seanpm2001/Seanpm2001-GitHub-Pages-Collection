
***

# About pages

About pages are supported as links. Pages that start with the protocols:

* `about:` (Mozilla Firefox, SeaMonkey, Pale Moon, etc.)

* `chrome:` (Google Chrome, Google Chromium, Brave, etc.)

* `safari:` (Safari)

* `opera:` (Opera)

And the likes are allowed.

**This document on Link Handling is incomplete. You can help by _expanding it._**

***
