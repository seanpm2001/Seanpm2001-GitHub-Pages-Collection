
***

# Handling IP addresses

URLL files are capable of handling IP addresses as links. Due to the sensitivity of these addresses, it is recommended not to create or share files that contain 1 or more IP address link.

**This document on Link Handling is incomplete. You can help by _expanding it._**

***
