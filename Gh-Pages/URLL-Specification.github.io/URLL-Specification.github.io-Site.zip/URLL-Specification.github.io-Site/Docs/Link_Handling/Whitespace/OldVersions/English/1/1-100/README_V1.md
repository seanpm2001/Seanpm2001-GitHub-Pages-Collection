
***

# Whitespace

If a link has an extra set of tabs or spaces before the link itself, URLL files will automatically generate the link correctly, as it focuses on the elements of the link. It will typically ignore whitespace, unless it is at the end of the link, then it will load each space as `%20` which may cause errors on overly strict web server sites.

**This document on Link Handling is incomplete. You can help by _expanding it._**

***
