
***

# LinkLax Integration + compatibility

[LinkLax](https://github.com/seanpm2001/LinkLax/) is one of my tools that customizes the look and feel of hyperlinks in various ways. It will have its own integration into the URLL file specification.

**This document on program integration is incomplete. You can help by _expanding it._**

***
