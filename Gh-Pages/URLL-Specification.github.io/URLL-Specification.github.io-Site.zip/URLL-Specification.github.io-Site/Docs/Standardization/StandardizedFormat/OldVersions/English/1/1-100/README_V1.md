
***

# Standardized Format

I hope that I can get URLL certified as a standard format someday with the following types:

**MIME type:** `Internet/ShortcutList`

**File extension format:** `.urll`

**This document on Certification is incomplete. You can help by _expanding it._**

***
