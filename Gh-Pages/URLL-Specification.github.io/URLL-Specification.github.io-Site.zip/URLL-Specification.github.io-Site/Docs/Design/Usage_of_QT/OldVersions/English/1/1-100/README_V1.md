
***

# Usage of QT

I am using QT as a model language and platform for the Linux part of this platform, due to the popularity of QT on Linux. GTK, and other models will also be supported in the future. QT support currently isn't available for Windows, MacOS, and BSD.

**This document on Graphic Design is incomplete. You can help by _expanding it._**

***
