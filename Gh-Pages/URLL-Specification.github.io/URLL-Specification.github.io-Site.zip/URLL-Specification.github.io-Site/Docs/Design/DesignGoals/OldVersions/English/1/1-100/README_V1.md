
***

# Design goals

I hope to make the list dialogue prompt to be similar in shape to the `choose a program` menu on Windows 10, but with more gloss, and more customization.

**This article on graphic design is incomplete.You can help by _expanding it._**

***
