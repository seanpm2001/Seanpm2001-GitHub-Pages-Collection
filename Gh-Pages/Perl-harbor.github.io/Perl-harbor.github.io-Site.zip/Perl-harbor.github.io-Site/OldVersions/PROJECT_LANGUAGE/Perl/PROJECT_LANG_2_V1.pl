# Start of script
# Perl Harbor is written in Perl, due to its 1 letter difference with Pearl, and is used to remember and commemorate the attacks on Pearl Harbor on Sunday, December 7th 1941, with the 2399 people killed (2335 when not counting the attacking Kamikaze pilots) I decided to make Perl the second project language file for the projects website in accordance with this.
print "Perl Harbor is written in Perl, due to its 1 letter difference with Pearl, and is used to remember and commemorate the attacks on Pearl Harbor on Sunday, December 7th 1941, with the 2399 people killed (2335 when not counting the attacking Kamikaze pilots) I decided to make Perl the second project language file for the projects website in accordance with this.";
# File info
# File type: Perl source file (*pl)
# File version: 1 (Sunday, 2021 September 12th at 3:14 pm)
# Line count (including blank lines and compiler line): 9
# End of script
