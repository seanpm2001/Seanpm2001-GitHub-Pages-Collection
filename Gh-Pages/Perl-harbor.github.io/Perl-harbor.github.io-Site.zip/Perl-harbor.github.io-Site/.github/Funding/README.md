
***

# About the funding directory

The funding directory contains an archive of the funding file for this project. The funding file enables GitHub sponsorships. The main funding file is 1 directory below, located [here](/.github/FUNDING.yml).

***

## Sponsor info

![/SponsorButton.png](/SponsorButton.png)

You can sponsor this project if you like, but please specify what you want to donate to. [See the funds you can donate to here](https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

You can view other sponsor info [here](https://github.com/seanpm2001/Sponsor-info/)

Try it out! The sponsor button is right up next to the watch/unwatch button.

***

## File info

**File type:** `Markdown (*.md)`

**Original creation date:** `Thursday, March 18th 2021 at 3:33 pm)`

**File version:** `1 (Thursday, March 18th 2021 at 3:33 pm)`

**Line count (including blank lines and compiler line):** `33`

***
