# UCALC
UCALC (Ultimate Calculator) is an advanced Python-based calculator that was my first major Python project.

---

# About

UCALC (Ultimate Calculator) is a python based calculator that can do every type of equation. When I worked on the project originally, I was trying to do 2 things alongside the command line version

> 1. Create a GUI version

> 2. Create a version that could run on an actual calculator

If it were to run on an actual calculator, it would make the TI-40 calculators look like primitive technology compared to something millions of years later. I can still get it done someday.

---

ReadMe info
-----------

Version: 1 (May 29th 2020 at 4:15 pm)

---

