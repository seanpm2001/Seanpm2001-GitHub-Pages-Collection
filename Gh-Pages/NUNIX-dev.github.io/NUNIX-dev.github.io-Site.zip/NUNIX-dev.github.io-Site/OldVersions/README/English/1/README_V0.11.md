
***

### Top

# `README.md`

***

# Index

[00.0 - Top](#Top)

[01.0 - Index](#Index)

[02.0 - Description](#NUNIX)

[03.0 - About](#About)

[04.0 - Wiki](#Wiki)

[05.0 - Version history](#Version-history)

[06.0 - Contributers](#Contributers)

[07.0 - Contributing](#Contributing)

[08.0 - About README](#About-README)

[09.0 - README Version history](#README-Version-history)

[10.0 - Footer](#You-have-reached-the-end-of-the-README-file)

***

# NUNIX
NUNIX (Neural UNIX) is an experimental operating system project that can act as a second brain for the human mind. It is far from complete.

***

## About

See above

***

## Wiki

[Click/tap here to view this projects Wiki](https://github.com/seanpm2001/NUNIX/wiki)

***

## Version history

[More versions coming soon](https://www.example.com)

***

## Contributers

Currently, I am the only contributer. You can contribute as well if you follow the CONTRIBUTING.md files rules. See below.

> * 1. [seanpm2001](https://github.com/seanpm2001/) - 24 commits (As of Wedneday, July 22nd 2020 at 6:24 pm)

> * 2. No other contributers at the moment

***

## Contributing

You can contribute to this project, if you follow the rules of the `CONTRIBUTING.md` file exactly.

Here is the file for reference. [Click here to see the contributing.md file](https://github.com/seanpm2001/NUNIX/blob/master/CONTRIBUTING.md).

***

## About README

File type: `Markdown (*.md)`

File version: `1 (Wednesday, July 22nd 2020 at 6:24 pm)`

Line count (including blank lines and compiler line): `0,130`

***

## README Version history

* Version 1 (July 22nd 2020 at 6:24 pm)

> Changes:

> * Started the README file

> * Added the title section

> * Added the index

> * Added the info section

> * Added the about section

> * Added the Wiki section

> * Added the version history section

> * Added the Contributers section

> * Added the Contributing section

> * Added the About README section

> * Added the README Version history section

> * Added the footer

* Version 2 (Coming soon)

> Changes:

> * Coming soon.

***

### You have reached the end of the README file

( [Back to top](#Top) | [Exit to GitHub](https://github.com) )

***
