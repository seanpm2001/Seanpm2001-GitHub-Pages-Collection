
***

# The NUNIX Project

![TECHNOBRAIN.jpeg This image failed to load. It may be due to the file not being reached, or a general error. Reload the page to fix a possible general error.](/TECHNOBRAIN.jpeg)

# By:

## [Seanpm2001](https://github.com/seanpm2001/), Et; Al.

### Top

# `README.md`

***

## Read this article in a different language

_🌐 List of languages_

**Sorted by:** `A-Z`

[Sorting options unavailable](https://github.com/seanpm2001/NUNIX/)

( [af Afrikaans](/.github/README_AF.md) Afrikaans | [sq Shqiptare](/.github/README_SQ.md) Albanian | [am አማርኛ](/.github/README_AM.md) Amharic | [ar عربى](/.github/README_AR.md) Arabic | [hy հայերեն](/.github/README_HY.md) Armenian | [az Azərbaycan dili](/.github/README_AZ.md) Azerbaijani | [eu Euskara](/.github/README_EU.md) Basque | [be Беларуская](/.github/README_BE.md) Belarusian | [bn বাংলা](/.github/README_BN.md) Bengali | [bs Bosanski](/.github/README_BS.md) Bosnian | [bg български](/.github/README_BG.md) Bulgarian | [ca Català](/.github/README_CA.md) Catalan | [ceb Sugbuanon](/.github/README_CEB.md) Cebuano | [ny Chichewa](/.github/README_NY.md) Chichewa | [zh-CN 简体中文](/.github/README_ZH-CN.md) Chinese (Simplified) | [zh-t 中國傳統的）](/.github/README_ZH-T.md) Chinese (Traditional) | [co Corsu](/.github/README_CO.md) Corsican | [hr Hrvatski](/.github/README_HR.md) Croatian | [cs čeština](/.github/README_CS.md) Czech | [da dansk](README_DA.md) Danish | [nl Nederlands](/.github/README_NL.md) Dutch | [**en-us English**](/.github/README.md) English |  [EO Esperanto](/.github/README_EO.md) Esperanto | [et Eestlane](/.github/README_ET.md) Estonian | [tl Pilipino](/.github/README_TL.md) Filipino | [fi Suomalainen](/.github/README_FI.md) Finnish |  [fr français](/.github/README_FR.md) French | [fy Frysk](/.github/README_FY.md) Frisian | [gl Galego](/.github/README_GL.md) Galician | [ka ქართველი](/.github/README_KA) Georgian | [de Deutsch](/.github/README_DE.md) German | [el Ελληνικά](/.github/README_EL.md) Greek | [gu ગુજરાતી](/.github/README_GU.md) Gujarati | [ht Kreyòl ayisyen](/.github/README_HT.md) Haitian Creole | [ha Hausa](/.github/README_HA.md) Hausa | [haw Ōlelo Hawaiʻi](/.github/README_HAW.md) Hawaiian | [he עִברִית](/.github/README_HE.md) Hebrew | [hi हिन्दी](/.github/README_HI.md) Hindi | [hmn Hmong](/.github/README_HMN.md) Hmong | [hu Magyar](/.github/README_HU.md) Hungarian | [is Íslenska](/.github/README_IS.md) Icelandic | [ig Igbo](/.github/README_IG.md) Igbo | [id bahasa Indonesia](/.github/README_ID.md) Icelandic | [ga Gaeilge](/.github/README_GA.md) Irish | [it Italiana/Italiano](/.github/README_IT.md) | [ja 日本語](/.github/README_JA.md) Japanese | [jw Wong jawa](/.github/README_JW.md) Javanese | [kn ಕನ್ನಡ](/.github/README_KN.md) Kannada | [kk Қазақ](/.github/README_KK.md) Kazakh | [km ខ្មែរ](/.github/README_KM.md) Khmer | [rw Kinyarwanda](/.github/README_RW.md) Kinyarwanda | [ko-south 韓國語](/.github/README_KO_SOUTH.md) Korean (South) | [ko-north 문화어](README_KO_NORTH.md) Korean (North) (NOT YET TRANSLATED) | [ku Kurdî](/.github/README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча](/.github/README_KY.md) Kyrgyz | [lo ລາວ](/.github/README_LO.md) Lao | [la Latine](/.github/README_LA.md) Latin | [lt Lietuvis](/.github/README_LT.md) Lithuanian | [lb Lëtzebuergesch](/.github/README_LB.md) Luxembourgish | [mk Македонски](/.github/README_MK.md) Macedonian | [mg Malagasy](/.github/README_MG.md) Malagasy | [ms Bahasa Melayu](/.github/README_MS.md) Malay | [ml മലയാളം](/.github/README_ML.md) Malayalam | [mt Malti](/.github/README_MT.md) Maltese | [mi Maori](/.github/README_MI.md) Maori | [mr मराठी](/.github/README_MR.md) Marathi | [mn Монгол](/.github/README_MN.md) Mongolian | [my မြန်မာ](/.github/README_MY.md) Myanmar (Burmese) | [ne नेपाली](/.github/README_NE.md) Nepali | [no norsk](/.github/README_NO.md) Norwegian | [or ଓଡିଆ (ଓଡିଆ)](/.github/README_OR.md) Odia (Oriya) | [ps پښتو](/.github/README_PS.md) Pashto | [fa فارسی](/.github/README_FA.md) |Persian  [pl polski](/.github/README_PL.md) Polish | [pt português](/.github/README_PT.md) Portuguese | [pa ਪੰਜਾਬੀ](/.github/README_PA.md) Punjabi | No languages available that start with the letter Q | [ro Română](/.github/README_RO.md) Romanian | [ru русский](/.github/README_RU.md) Russian | [sm Faasamoa](/.github/README_SM.md) Samoan | [gd Gàidhlig na h-Alba](/.github/README_GD.md) Scots Gaelic | [sr Српски](/.github/README_SR.md) Serbian | [st Sesotho](/.github/README_ST.md) Sesotho | [sn Shona](/.github/README_SN.md) Shona | [sd سنڌي](/.github/README_SD.md) Sindhi | [si සිංහල](/.github/README_SI.md) Sinhala | [sk Slovák](/.github/README_SK.md) Slovak | [sl Slovenščina](/.github/README_SL.md) Slovenian | [so Soomaali](/.github/README_SO.md) Somali | [[es en español](/.github/README_ES.md) Spanish | [su Sundanis](/.github/README_SU.md) Sundanese | [sw Kiswahili](/.github/README_SW.md) Swahili | [sv Svenska](/.github/README_SV.md) Swedish | [tg Тоҷикӣ](/.github/README_TG.md) Tajik | [ta தமிழ்](/.github/README_TA.md) Tamil | [tt Татар](/.github/README_TT.md) Tatar | [te తెలుగు](/.github/README_TE.md) Telugu | [th ไทย](/.github/README_TH.md) Thai | [tr Türk](/.github/README_TR.md) Turkish | [tk Türkmenler](/.github/README_TK.md) Turkmen | [uk Український](/.github/README_UK.md) Ukrainian | [ur اردو](/.github/README_UR.md) Urdu | [ug ئۇيغۇر](/.github/README_UG.md) Uyghur | [uz O'zbek](/.github/README_UZ.md) Uzbek | [vi Tiếng Việt](/.github/README_VI.md) Vietnamese | [cy Cymraeg](/.github/README_CY.md) Welsh | [xh isiXhosa](/.github/README_XH.md) Xhosa | [yi יידיש](/.github/README_YI.md) Yiddish | [yo Yoruba](/.github/README_YO.md) Yoruba | [zu Zulu](/.github/README_ZU.md) Zulu ) Available in 110 languages (108 when not counting English and North Korean, as North Korean has not been translated yet [Read about it here](/OldVersions/Korean(North)/README.md))

Translations in languages other than English are machine translated and are not yet accurate. No errors have been fixed yet as of March 21st 2021. Please report translation errors [here](https://github.com/seanpm2001/NUNIX/issues/). Make sure to backup your correction with sources and guide me, as I don't know languages other than English well (I plan on getting a translator eventually) please cite [wiktionary](https://en.wiktionary.org) and other sources in your report. Failing to do so will result in a rejection of the correction being published.

Note: due to limitations with GitHub's interpretation of markdown (and pretty much every other web-based interpretation of markdown) clicking these links will redirect you to a separate file on a separate page that isn't my GitHub profile page. You will be redirected to the [seanpm2001/seanpm2001 repository](https://github.com/seanpm2001/seanpm2001), where the README is hosted.

Translations are done with Google Translate due to limited or no support for the languages I need in other translation services like DeepL and Bing Translate (pretty ironic for an anti-Google campaign) I am working on finding an alternative. For some reason, the formatting (links, dividers, bolding, italics, etc.) is messed up in various translations. It is tedious to fix, and I do not know how to fix these issues in languages with non-latin characters, and right to left languages (like Arabic) extra help is needed in fixing these issues

Due to maintenance issues, many translations are out of date and are using an outdated version of this `README` article file. A translator is needed. Also, as of April 9th 2021, it is going to take me a while to get all the new links working.

***

# Index

[00.0 - Top](#Top)

> [00.1 - Title](#The-NUNIX-Project)

> [00.2 - Read this article in a different language](#Read-this-article-in-a-different-language)

> [00.3 - Index](#Index)

[01.0 - Description](#NUNIX)

[02.0 - About](#About)

[03.0 - Wiki](#Wiki)

[04.0 - History](#History)

> [04.1 - SNU Smell Project](#SNU-Smell-Project)

> [04.2 - SNU NUNIX](#SNU-NUNIX)

> [04.3 - NUNIX Project](#NUNIX-Project)

[05.0 - Samples](#Samples)

[06.0 - Version history](#Version-history)

[07.0 - Software status](#Software-status)

[08.0 - Sponsor info](#Sponsor-info)

[09.0 - Contributers](#Contributers)

[10.0 - Issues](#Issues)

> [10.1 - Current issues](#Current-issues)

> [10.2 - Past issues](#Past-issues)

> [10.3 - Past pull requests](#Past-pull-requests)

> [10.4 - Active pull requests](#Active-pull-requests)

[11.0 - Resources](#Resources)

[12.0 - Contributors](#Contributors)

[13.0 - Contributing](#Contributing)

[14.0 - About README](#About-README)

[15.0 - README Version history](#README-version-history)

[16.0 - Footer](#You-have-reached-the-end-of-the-README-file)

> [16.1 - End of file](#EOF)

***

# NUNIX
NUNIX (Neural UNIX) is an experimental operating system project that can act as a second brain for the human mind. It is far from complete.
 
***

## About

See above and below for more info.

***

## Wiki

[Click/tap here to view this projects Wiki](https://github.com/seanpm2001/NUNIX/wiki/)

If the project has been forked, the Wiki was likely removed. Luckily, I include an embedded version. You can view it [here](/External/ProjectWiki/).

***

## History

This project was started early on as a concept for a UNIX-Like system in the human brain. Since this has never been done before, and the technology needed doesn't exist yet, this project is designed for the future. Precautions are currently being taken, so there will be several decades of preparation and stress testing to get the concept just right, as a lot can go wrong here. See [Council](#Council) and [Existential threats](#Existential-threats)

***

## Council

This project currently has a council in early Alpha. The council will be made up of neurologists, computer programmers, hardware engineers, and the top thinkers in the subjects of ethics and dystopian reality, so that all the possible dystopian endings can be closed.

[See the council by clicking/tapping here](/Council/)

### Pre-council decisions

Before I created the council, I had 1 critical restriction in mind, which I knew from day 1 would be the worst possible thing that could be done to the human brain:

Internet Access.

NUNIX will ***NEVER*** have Internet Access, as this would jeopardize the whole project, and make humans just devices that could be hacked and manipulated, which is a big and deadly scenario that will lead to Genocide and the end of humanity. Not even bluetooth will be supported.

***

## Existential threats

Some of the existential threats that can occur if this project is not done correctly include:

Mind control

100% authoritarian regime

Genocide of all races

The end of free thought

The end of human progress

and more...

***

## API

This project has a specialized API.

### HAP

HAP (**H**uman **A**pplicable **P**rogram) is the default package format for NUNIX, it does what the name says it is, its purpose is to be a human applicable, hyman applicable program.

### Programming

The HAP package has swappable programming language support via a magic keyword. The package format can be written in any programming language. Depending on its formatting, it will only be able to do certain things (such as HTML packages only giving off access to offline web pages)

***

## Sponsor info

![SponsorButton.png](SponsorButton.png)

You can sponsor this project if you like, but please specify what you want to donate to. [See the funds you can donate to here](https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors/)

You can view other sponsor info [here](https://github.com/seanpm2001/Sponsor-info/)

Try it out! The sponsor button is right up next to the watch/unwatch button.

***

## Version history

**Version history currently unavailable**

**No other versions listed**

***

## Software status

All of my works are free some restrictions. DRM (**D**igital **R**estrictions **M**anagement) is not present in any of my works.

![DRM-free_label.en.svg](DRM-free_label.en.svg)

This sticker is supported by the Free Software Foundation. I never intend to include DRM in my works.

I am using the abbreviation "Digital Restrictions Management" instead of the more known "Digital Rights Management" as the common way of addressing it is false, there are no rights with DRM. The spelling "Digital Restrictions Management" is more accurate, and is supported by [Richard M. Stallman (RMS)](https://en.wikipedia.org/wiki/Richard_Stallman/) and the [Free Software Foundation (FSF)](https://en.wikipedia.org/wiki/Free_Software_Foundation/)

This section is used to raise awareness for the problems with DRM, and also to protest it. DRM is defective by design and is a major threat to all computer users and software freedom.

Image credit: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label/)

***

## Contributers

Currently, I am the only contributer. Contributing is allowed, as long as you follow the rules of the [CONTRIBUTING.md](/CONTRIBUTING.md) file.

> * 1. [seanpm2001](https://github.com/seanpm2001/) - 54 commits (As of Thursday, July 15th 2021 at 3:44 pm)

> * 2. No other contributers.

***

## Issues

### Current issues

* None at the moment

* No other current issues

If the repository has been forked, issues likely have been removed. Luckily I keep an archive of certain images [here](/.github/Issues/)

[Read the privacy policy on issue archival here](/.github/Issues/README.md)

**TL;DR**

I archive my own issues. Your issue won't be archived unless you request it to be archived.

### Past issues

* None at the moment

* No other past issues

If the repository has been forked, issues likely have been removed. Luckily I keep an archive of certain images [here](/.github/Issues/)

[Read the privacy policy on issue archival here](/.github/Issues/README.md)

**TL;DR**

I archive my own issues. Your issue won't be archived unless you request it to be archived.

### Past pull requests

* None at the moment

* No other past pull requests

If the repository has been forked, issues likely have been removed. Luckily I keep an archive of certain images [here](/.github/Issues/)

[Read the privacy policy on issue archival here](/.github/Issues/README.md)

**TL;DR**

I archive my own issues. Your issue won't be archived unless you request it to be archived.

### Active pull requests

* None at the moment

* No other active pull requests

If the repository has been forked, issues likely have been removed. Luckily I keep an archive of certain images [here](/.github/Issues/)

[Read the privacy policy on issue archival here](/.github/Issues/README.md)

**TL;DR**

I archive my own issues. Your issue won't be archived unless you request it to be archived.

***

## Resources

Here are some other resources for this project:

[Project language file](/PROJECT_LANG.htm)

[Join the discussion on GitHub](https://github.com/seanpm2001/NUNIX/discussions/)

No other resources at the moment.

***

## Contributing

Contributing is allowed for this project, as long as you follow the rules of the `CONTRIBUTING.md` file.

[Click/tap here to view the contributing rules for this project](/CONTRIBUTING.md)

***

## About README

File type: `Markdown (*.md)`

File version: `1 (Thursday, July 15th 2021 at 3:44 pm)`

Line count: `0,388`

***

## README version history

Version 0.1/1 (Wednesday, July 22nd 2020 at 6:24 pm)

> Changes:

> * Started the file

> * Added the title section

> * Added the index

> * Added the about section

> * Added the Wiki section

> * Added the version history section

> * Added the issues section.

> * Added the past issues section

> * Added the past pull requests section

> * Added the active pull requests section

> * Added the contributors section

> * Added the contributing section

> * Added the about README section

> * Added the README version history section

> * Added the resources section

> * Added a software status section, with a DRM free sticker and message

> * Added the sponsor info section

> * No other changes in version 0.1

Version 1 (Thursday, July 15th 2021 at 3:44 pm)

> Changes:

> * Started the article

> * Replaced template links and headings

> * Updated the language list section

> * Added the history section

> * Added the samples section

> * Updated the index

> * Updated the file info section

> * Updated the file history section

> * No other changes in version 1

Version 2 (Coming soon)

> Changes:

> * Coming soon

> * No other changes in version 2

***

### You have reached the end of the README file

[Back to top](#Top) [Exit](https://github.com)

### EOF

***
