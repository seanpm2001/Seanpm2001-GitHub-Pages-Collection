***

##### Top

_ Lees hierdie artikel in 'n ander taal:

** Huidige taal is: ** `Engels (VS)` _ (vertalings moet dalk reggestel word om Engels reg te stel wat die regte taal vervang) _

_🌐 Lys van tale_

** Gesorteer op: ** `A-Z`

[Sorteeropsies nie beskikbaar nie] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanees | [am አማርኛ] (/. github / README_AM.md) Amharies | [ar عربى] (/.github/README_AR.md) Arabies | [hy հայերեն] (/. github / README_HY.md) Armeens | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbeidjans | [eu Euskara] (/. github /README_EU.md) Baskies | [wees Беларуская] (/. Github / README_BE.md) Belo-Russies | [bn বাংলা] (/. Github / README_BN.md) Bengaals | [bs Bosanski] (/. Github / README_BS.md) Bosnies | [bg български] (/. Github / README_BG.md) Bulgaars | [ca Català] (/. Github / README_CA.md) Katalaans | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chinees (Vereenvoudigd) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chinees (Tradisioneel) | [co Corsu] (/. Github / README_CO.md) Korsikaans | [hr Hrvatski] (/. Github / README_HR.md) Kroaties | [cs čeština] (/. Github / README_CS .md) Tsjeggies [da dansk] (README_DA.md) Deens | [nl Nederlands] (/. github / README_ NL.md) Nederlands | [** en-us Engels **] (/. github / README.md) Engels | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estnies | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Fins | [fr français] (/. github / README_FR.md) Frans | [fy Frysk] (/. github / README_FY.md) Fries | [gl Galego] (/. github / README_GL.md) Galisies | [ka ქართველი] (/. github / README_KA) Georgies | [de Deutsch] (/. github / README_DE.md) Duits | [el Ελληνικά] (/. github / README_EL.md) Grieks | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haïtiaanse Creools | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaïaans | [he עִברִית] (/. github / README_HE.md) Hebreeus | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hongaars | [is Íslenska] (/. github / README_IS.md) Yslands | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesië] (/. github / README_ID.md) Yslands | [ga Gaeilge] (/. github / README_GA.md) Iers | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japannees | [jw Wong jawa] (/. github / README_JW.md) Javaans | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazaks | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-suid 韓國 語] (/. github / README_KO_SOUTH.md) Koreaans (Suid) | [ko-noord 문화어] (README_KO_NORTH.md) Koreaans (Noord) (nog nie vertaal nie) | [ku Kurdî] (/. github / README_KU.md) Koerdies (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgisies | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latyn | [lt Lietuvis] (/. github / README_LT.md) Litaus | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgs | [mk Македонски] (/. github / README_MK.md) Masedonies | [mg Malgassies] (/. github / README_MG.md) Malgassies | [ms Bahasa Melayu] (/. github / README_MS.md) Maleis | [ml മലയാളം] (/. github / README_ML.md) Malabaars | [mt Malti] (/. github / README_MT.md) Maltees | [mi Maori] (/. github / README_MI.md) Maori | [mnr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongools | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Birmaans) | [ne नेपाली] (/. github / README_NE.md) Nepalees | [no norsk] (/. github / README_NO.md) Noors | [of ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pasjto | [fa فارسی] (/. github / README_FA.md) | Persies [pl polski] (/. github / README_PL.md) Pools | [pt português] (/. github / README_PT.md) Portugees | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Geen tale beskikbaar wat met die letter Q | begin nie [ro Română] (/. github / README_RO.md) Roemeens | [ru русский] (/. github / README_RU.md) Russies | [sm Faasamoa] (/. github / README_SM.md) Samoaans | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Skotse Gaelies | [sr Српски] (/. github / README_SR.md) Serwies | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slowaaks | [sl Slovenščina] (/. github / README_SL.md) Sloweens | [so Soomaali] (/. github / README_SO.md) Somalies | [[es en español] (/. github / README_ES.md) Spaans | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Sweeds | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tataars | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github /README_TR.md) Turks | [tk Türkmenler] (/. github / README_TK.md) Turkmeens | [uk Український] (/. github / README_UK.md) Oekraïens | [ur اردو] (/. github / README_UR.md) Oerdoe | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Oezbeeks | [vi Tiếng Việt] (/. github / README_VI.md) Viëtnamees | [cy Cymraeg] (/. github / README_CY.md) Wallies | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Jiddisj | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Beskikbaar in 110 tale (108 as Engels en Noord-Koreaans nie getel word nie, aangesien Noord-Koreaans nog nie vertaal is nie [Lees hieroor]] (/ OldVersions / Koreaans (Noord ) /README.md))

Vertalings in ander tale as Engels word masjienvertaal en is nog nie akkuraat nie. Nog geen foute is reggestel vanaf 5 Februarie 2021. Rapporteer asseblief vertaalfoute [hier] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/), maak seker dat u u regstelling rugsteun met bronne en lei my, aangesien ek nie ander tale as Engels ken nie (ek is van plan om uiteindelik 'n vertaler te kry), noem asseblief [wiktionary] (https://en.wiktionary.org) en ander bronne in u verslag. As u dit nie doen nie, sal die regstelling van die hand gewys word.

Opmerking: as gevolg van beperkings met die interpretasie van GitHub van markdown (en bykans elke ander webgebaseerde interpretasie van markdown), klik hierdie skakels u na 'n aparte lêer op 'n aparte bladsy wat nie my GitHub-profielblad is nie. U sal na die [seanpm2001 / seanpm2001-bewaarplek] (https://github.com/seanpm2001/seanpm2001) herlei word, waar die README aangebied word.

Vertalings word met Google Translate gedoen as gevolg van beperkte of geen ondersteuning vir die tale wat ek benodig in ander vertaaldienste soos DeepL en Bing Translate (redelik ironies vir 'n anti-Google-veldtog). Ek is besig om 'n alternatief te vind. Om die een of ander rede is die opmaak (skakels, verdelers, vetdruk, kursief, ens.) Deurmekaar in verskillende vertalings. Dit is vervelig om op te los, en ek weet nie hoe om hierdie probleme in tale met nie-Latynse karakters op te los nie, en van regs na links (soos Arabies) is ekstra hulp nodig om hierdie probleme op te los

As gevolg van instandhoudingsprobleme is baie vertalings verouderd en gebruik 'n verouderde weergawe van hierdie 'README'-artikellêer. 'N Vertaler is nodig. Vanaf 23 April 2021 neem dit my ook 'n rukkie om al die nuwe skakels te laat werk.

***

# Dit is tyd om Widevine te sny

Dit is 'n artikel oor waarom u moet ophou om Google WideVine (DRM) te gebruik en dit te verwyder. DRM moet verwyder word. Hierdie artikel sal u help om u keuse te maak (as u dit nog nie gedoen het nie) WideVine is baie mededingend en baie beperkend en vernietig die vryheid van video's op die internet.

Kom ons sny die WideVine en gebruik 'n oop internet.

***

# Indeks

[00.0 - Top] (# Top)

> [00.1 - Lees hierdie artikel in 'n ander taal]

> [00.2 - Titel] (# Dit is tyd om Widevine te sny)

> [00.3 - Indeks] (# indeks)

[01.0 - Oorsig] (# Oorsig)

[02.0 - Mededingend] (# Mededingend)

[03.0 - Gebrek aan vryheid] (# Gebrek aan vryheid)

[04.0 - Geheugebruik] (# geheugebruik)

[05.0 - Privaatheid] (# privaatheid)

[06.0 - Alternatiewe metodes] (# Alternatiewe metodes)

[07.0 - Wat jy kan doen om te help] (# Wat-jy-kan-doen-om-te-help)

[08.0 - Ander dinge om na te gaan] (# Ander-dinge-om-uit te kyk)

[09.0 - Artikelinligting] (# artikelinligting)

> [09.0.1 - Sagtewarestatus] (# Sagtewarestatus)

> [09.0.2 - Borginligting] (# borginligting)

[10.0 - Lêergeskiedenis] (# Lêergeskiedenis)

[11.0 - Footer] (# Footer)

> [11.9 - EOF] (# EOF)

***

## Oorsig

Vir ander inligting oor waarom DRM 'n probleem is, [klik hier] (https://www.defectivebydesign.org/)

***

## Mededingend

WideVine is 'n DRM wat gelisensieer moet word om saam met 'n blaaier te gebruik. Google is baie traag om mense te hersien en te aanvaar, en weier mense om dit sonder rede te gebruik in hul produkte. [Bron 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Bron 2 (die e-posdraad wat langer as 4 maande aangehou het en niks anders as teleurstelling tot gevolg gehad het nie)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google het dit baie moeiliker vir blaaiers soos Brave of Firefox om te kompeteer met die stoot van hierdie stuk DRM.

***

## Gebrek aan vryheid

WideVine word gebruik om te voorkom dat gebruikers interaksie met video op webwerwe het. Dit is 'n vorm van digitale beperkinge wat u verhinder om die video af te laai, die video vanlyn te sien of selfs 'n kiekie te neem. Dit is 'n eie sagteware en weens die probleme met privaatheid word dit nie by die meeste Linux-verspreidings geïnstalleer nie. Dit beperk die vryhede van die internet weens die gebruik daarvan deur Netflix-, Disney- en YouTube-films. U kan toegang tot die inhoud te eniger tyd sonder enige rede wegneem.

***

## Geheugebruik

WideVine is sleg in die geheue. In vergelyking met die normaalweg kyk na 'n video sonder DRM, gebruik WideVine groot hoeveelhede SVE en RAM. Dit is sleg op balewe, en dit bied geen voordele van standaard HTML5-video-afspeel nie.

***

## Privaatheid

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) [s ](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / waarom-googles-spioenasie-op-gebruik_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritiek) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -monsters / niks-om-weg te steek-argument-het-niks-om-te-sê /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-oor-jou-jy-kan-dit-nou-vind-en-verwyder /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -persoonlike-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -en) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html) [d ](https://www.reuters.com/article/us-alphabet- google-privaatheidsgeding-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html) [o ](https://en.wikipedia.org/wiki/2018_Google_data_breach) [m ](https:// moz.com/bl og / waar-google-teken-die-data-versameling-lyn) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- eis-namens-van-5-miljoen-iphone-gebruikers) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) [e ](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your your -telefoon-is nie-in-gebruik /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / inligtingstechnolo gy / 2014/01 / wat-google-regtig-kan-doen-met-nes-of-regtig-neste-data /) [i] (https://www.cbsnews.com/news/google-education-spies -op-versamel-data-oor-miljoene-kinders-beweer-regsgeding-nuwe-mexico-prokureur-generaal /) [v] (https://www.nationalreview.com/2018/04/the-student- data-mining-skandaal-onder-ons-neuse /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) [y ](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -iets-om-weg te steek-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (ek kan aanhou met bewyse hiervan , maar dit het lank geneem om al hierdie artikels te vind en deur te gaan)

Privaatheid is nie 'n ding met WideVine nie. Eiendomsagteware is so ontwerp dat u glad nie kan sien wat aangaan nie. Met die geskiedenis van Google is dit heel waarskynlikWideVine is 'n ekstra sagteware wat u bespied, u dokumente en ander slegte dinge lees.

As u dink dat u niks het om weg te steek nie, ** is u absoluut verkeerd **. Hierdie argument is al baie keer ontbloot:

[Via Wikipedia] (https://en.wikipedia.org/wiki/Niks_to_verberg_argument#Kritiek)

1. Edward Snowden het opgemerk: 'Om te betoog dat u nie omgee vir die reg op privaatheid nie, omdat u niks het om weg te steek nie, is nie anders as om te sê dat u nie omgee vir vrye spraak nie, omdat u niks het om te sê nie.' As u sê: ' Ek het niks om weg te steek nie, 'sê u,' ek gee nie om vir hierdie reg nie. 'U sê,' ek het nie hierdie reg nie, want ek is op die punt waar ek moet regverdig dit. 'Soos die regte werk, moet die regering sy indringing in u regte regverdig.'

2. Daniel J. Solove het in 'n artikel vir The Chronicle of Higher Education gesê dat hy die argument teenstaan; hy het verklaar dat 'n regering inligting oor 'n persoon kan uitlek en skade aan die persoon kan aanrig, of inligting oor 'n persoon kan gebruik om toegang tot dienste te weier, selfs al het iemand nie daadwerklik gepleeg nie, en dat 'n regering iemand se persoonlike skade kan berokken. lewe deur foute te maak. Solove het geskryf 'Wanneer die niks-om-te-wegsteek-argument direk betrokke is, kan dit dwarsboom, want dit dwing die debat om te fokus op die noue begrip van privaatheid. Maar wanneer dit gekonfronteer word met die veelheid van privaatheidsprobleme wat geïmpliseer word deur die regering se data-insameling en -gebruik buite toesig en openbaarmaking, die niks-om-weg te steek-argument, het uiteindelik niks te sê nie. '

3. Adam D. Moore, skrywer van Privacy Rights: Moral and Legal Foundations, het aangevoer: "dit is die mening dat regte bestand is teen koste / voordeel of gevolglike argumente. Hier verwerp ons die siening dat privaatheidsbelange die soort is van dinge wat vir sekuriteit verhandel kan word. ' Hy het ook verklaar dat toesig sekere groepe in die samelewing buite verhouding kan beïnvloed op grond van voorkoms, etnisiteit, seksualiteit en godsdiens.

4. Bruce Schneier, 'n kenner en kriptograaf op die gebied van rekenaarbeveiliging, het teenstand uitgespreek, met verwysing na kardinaal Richelieu se stelling "As iemand my ses reëls sou gee wat deur die hand van die eerlikste man geskryf is, sou ek iets daarin vind om hom op te hang", met verwysing hoe 'n staatsregering aspekte in 'n persoon se lewe kan vind om daardie individu te vervolg of afpers. Schneier het ook aangevoer 'Te veel kenmerk die debat verkeerdelik as' veiligheid versus privaatheid '. Die regte keuse is vryheid teenoor beheer. '

5. Harvey A. Silverglate het beraam dat die gewone persoon gemiddeld onwetend drie misdade per dag in die VSA pleeg.

6. Emilio Mordini, filosoof en psigoanalis, het aangevoer dat die argument "niks om weg te steek nie" inherent paradoksaal is. Mense hoef nie 'iets te verberg' om 'iets' weg te steek nie. Wat verborge is, is nie noodwendig relevant nie, beweer Mordini. In plaas daarvan voer hy aan dat 'n intieme gebied wat verborge kan wees en toegangsbeperking nodig is, aangesien ons sielkundig individue word deur die ontdekking dat ons iets vir ander kan wegsteek.

7. Julian Assange het gesê: "Daar is nog geen antwoord op die moordenaar nie. Jacob Appelbaum (@ioerror) reageer slim en vra mense wat dit sê, om dan hul foon oop te gee en hul broek af te trek. My weergawe daarvan is om te sê: 'wel, as u so vervelig is, dan moet ons nie met u praat nie, en ook niemand anders nie', maar filosofies, is die werklike antwoord dit: massatoezicht is 'n groot struktuurverandering. As die samelewing sleg gaan, gaan dit om jou mee te neem, al is jy die sagste persoon op aarde. '

8. Ignacio Cofone, professor in die regte, voer aan dat die argument verkeerdelik in sy eie terme verkeerd is omdat, wanneer mense ook relevante inligting aan ander bekend maak, dit ook irrelevante inligting openbaar. Hierdie irrelevante inligting hou privaatheidskoste in en kan lei tot ander skade, soos diskriminasie.

***

# Alternatiewe metodes

Media moet nie beperk word nie, aanlyn of vanlyn. As mense die video sonder die DRM wou kyk, sal hulle altyd 'n manier vind om dit te doen. Elke sagteware kan gekraak word.

[gewysigde uittreksel uit Wikipedia] Valve-president, Gabe Newell, het gesê "die meeste DRM-strategieë is net dom" omdat dit die waarde van 'n speletjie in die oë van die verbruiker verlaag. Newell stel voor dat die doel eerder moet wees "om groter waarde vir klante te skep deur middel van dienswaarde". Let daarop dat Valve Steam bedryf, 'n diens wat dien as 'n aanlynwinkel vir rekenaarspeletjies, sowel as 'n sosiale netwerkdiens en 'n DRM-platform.

Hierdie punt is nie geldig net vir videospeletjies nie, maar kan op enige iets op 'n rekenaar toegepas word. U rekenaar behoort nie heeltemal beheer te hê oor 'n gekke onderneming wat slegte kunsmatige intelligensie gebruik om sy gebruikers en hul werk (YouTube, ens.) Uit te wis nie en wat so sleg is. U rekenaar mag nie beperk word nie, omdat 'n maatskappy weier om te deel soos 'n kind wat sleg gedra word. U rekenaar moet deur u besit word,en niemand anders nie. U moet heeltemal van DRM ontslae raak, want dit is nie die moeite werd om die beheer van u rekenaar op te gee nie. Hierdie maatskappye het honderde miljarde dollars. As hulle so iets dom doen, moet u daarteen betoog. U kan selfs die video elders aflaai en sien, want hulle sou geld verloor omdat hulle sulke dom dinge gedoen het. Skending van kopiereg is nie sleg nie. Mense wat nie films kan bekostig nie, sal dit elders aflaai, dit gebeur sedert die begin van die wêreldwye internet en met die uitvinding van die VHS-band. Dit beïnvloed skaars hul inkomste, aangesien hulle in elk geval nie daardie geld sou kon kry nie. DRM is volgens ontwerp defektief.

***

## Wat u kan doen om te help

U kan DRM betoog. Dit lyk miskien onbeduidend, maar hoe meer mense daarteen gaan, hoe meer word daaraan gedoen.

As u Linux gebruik en Firefox gebruik, moet u seker maak dat DRM nie geïnstalleer is nie (dit is normaalweg nie standaard nie) en hoef dit nie te installeer nie.

As u Windows of MacOS gebruik, het u dalk baie moeiliker tyd, aangesien DRM standaard op hierdie stelsels geïnstalleer is en dit outomaties kan weer installeer.

Probeer die volgende webwerwe vermy:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Eintlik moet byna enige aanlyn videostreamingdiens vermy word, aangesien die meeste van hulle DRM gebruik en u nie die webwerf kan gebruik sonder om u vryheid te verloor nie. Dit is nie die moeite werd nie. Stuur 'n boodskap aan die [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) en hou op om hierdie programme te stroom.

U moet ook op die volgende webwerwe enige "gratis advertensies" -opsies vermy (aangesien hierdie metode DRM benodig)

[YouTube] (https://www.youtube.com)

U kan ook DRM betoog met 'n boodskap op u projekte `README.md`-lêer. Hier is wat ek gebruik:

'' afslag

***

## Sagteware status

Al my werke is gratis, sommige beperkings. DRM (** D ** igital ** R ** estrictions ** M ** anagement) is in geen van my werke aanwesig nie.

! [DRM-vry_label.en.svg] (DRM-vry_label.en.svg)

Hierdie plakker word ondersteun deur die Free Software Foundation. Ek is nooit van plan om DRM by my werke in te sluit nie.

Ek gebruik die afkorting "Digital Restrictions Management" in plaas van die meer bekende "Digital Rights Management", aangesien die algemene manier om dit aan te spreek onwaar is; daar is geen regte met DRM nie. Die spelling "Digital Restrictions Management" is akkurater en word ondersteun deur [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) en die [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Hierdie afdeling word gebruik om bewustheid te verhoog vir die probleme met DRM, en ook om dit te betoog. DRM is gebrekkig van ontwerp en is 'n groot bedreiging vir alle rekenaargebruikers en sagteware-vryheid.

Beeldkrediet: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

''

***
## Ander dinge om na te gaan

[Gebrekkig deur ontwerp - 'n Veldtog van die Free Software Foundation wat werk aan die blootstelling en uitskakeling van DRM-gebruik] (https://www.defectivebydesign.org/)

[Die Google-begraafplaas (killbygoogle.com) - 'n gesorteerde lys van die 224+ produkte wat Google vermoor het] (https://killedbygoogle.com/)

> [GitHub-skakel] (https://github.com/codyogden/killedbygoogle)

[Alfabetwerkersvakbond - Die nuwe werkersvakbond by Google met meer as 800 lede] (https://alphabetworkersunion.org/people/our-union/)

Daar is ander plaasvervangers, soek net na hulle.

***

## Artikelinligting

Lêerstipe: 'Markdown (* .md)'

Lêerweergawe: '4 (Vrydag 23 April 2021 om 15:35 uur)'

Reëntelling (leë reëls en samestellerreël ingesluit): `354`

### Sagtewarestatus

Al my werke is vry van beperkings. DRM (** D ** igital ** R ** estrictions ** M ** anagement) is in geen van my werke aanwesig nie. Hierdie projek bevat geen DRM nie, maar dit gaan direk oor DRM.

! [DRM-vry_label.en.svg] (DRM-vry_label.en.svg)

Hierdie plakker word ondersteun deur die Free Software Foundation. Ek is nooit van plan om DRM by my werke in te sluit nie.

***

### Borginligting

[SponsorButton.png] (SponsorButton.png) <- Dit is nie die amptelike borgknoppie nie, dit is 'n demo-beeld. Moenie daarop klik as u hierdie projek wil borg nie.

U kan hierdie projek borg as u wil, maar spesifiseer asseblief waaraan u wil skenk. [Sien die fondse waaraan u hier kan skenk] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

U kan ander borginligting [hier] sien (https://github.com/seanpm2001/Sponsor-info/)

Probeer dit! Die borgknoppie is reg langs die horlosie / oopknop-knoppie.

***

## Lêergeskiedenis

Weergawe 1 (Sondag 8 Februarie 2021 om 16:41 uur)

> Wysigings:

> * Het die lêer / artikel begin

> * Het die titelgedeelte bygevoeg

> * Het 'n afdeling oor privaatheid bygevoeg

> * Het 'n gedeelte oor die oorsig bygevoeg

> * Het die artikelinligting-afdeling bygevoeg

> * Verwys na die DRM Free-ikoon

> * Het die lêergeskiedenis-afdeling bygevoeg

> * Het die afdeling Gebrek aan vryheid bygevoeg

> * Het die afdeling vir mededinging bygevoeg

> * Het die afdeling alternatiewe metodes bygevoeg

> * Het die memo bygevoegry gebruiksafdeling

> * Het die ander dinge bygevoeg om na die gedeelte te kyk

> * Die indeks bygevoeg

> * Die voetskrif is bygevoeg

> * Geen ander veranderinge in weergawe 1 nie

Weergawe 2 (Donderdag 8 April 2021 om 17:18)

> Wysigings:

> * Die titelafdeling is opgedateer

> * Die indeks is opgedateer

> * Inligting bygevoeg oor wat u kan doen om te help

> * Het die borginligting-afdeling bygevoeg

> * Het die lêerinligting-afdeling opgedateer

> * Die afdeling vir lêergeskiedenis is opgedateer

> * Geen ander veranderinge in weergawe 2 nie

Weergawe 3 (Donderdag 8 April 2021 om 17:27)

> Wysigings:

> * Vaste skakels vir vertaling

> * Die indeks is opgedateer

> * Het 'n dubbele inskrywing van die onderwerp reggestel in die afdeling 'Wat u kan doen om te help'

> * Die afdeling vir borginligting is opgedateer

> * Het die lêerinligting-afdeling opgedateer

> * Die afdeling vir lêergeskiedenis is opgedateer

> * Geen ander veranderinge in weergawe 3 nie

Weergawe 4 (Vrydag 23 April 2021 om 15:35 uur)

> Wysigings:

> * Die lys vir taalskakelaars is opgedateer

> * Het die lêerinligting-afdeling opgedateer

> * Die afdeling vir lêergeskiedenis is opgedateer

> * Geen ander veranderinge in weergawe 4 nie

Weergawe 5 (binnekort beskikbaar)

> Wysigings:

> * Binnekort beskikbaar

> * Geen ander veranderinge in weergawe 5 nie

Weergawe 6 (binnekort beskikbaar)

> Wysigings:

> * Binnekort beskikbaar

> * Geen ander veranderinge in weergawe 6 nie

Weergawe 7 (binnekort beskikbaar)

> Wysigings:

> * Binnekort beskikbaar

> * Geen ander veranderinge in weergawe 7 nie

Weergawe 8 (binnekort beskikbaar)

> Wysigings:

> * Binnekort beskikbaar

> * Geen ander veranderinge in weergawe 8 nie

***

## Voetskrif

U het die einde van hierdie lêer bereik!

##### EOF

***
