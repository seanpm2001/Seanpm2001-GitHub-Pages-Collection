***

### ### Nangunguna

_ Basahin ang artikulong ito sa ibang wika: _

** Kasalukuyang wika ay: ** `English (US)` _ (maaaring kailanganing iwasto ang mga salin upang ayusin ang Ingles na papalit sa tamang wika) _

_🌐 Listahan ng mga wika_

** Pinagsunod-sunod ni: ** `A-Z`

[Hindi magagamit ang mga pagpipilian sa pag-uuri] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanian | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) Arabe | [hy հայերեն] (/. github / README_HY.md) Armenian | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijani | [eu Euskara] (/. github /README_EU.md) Basque | [be Беларуская] (/. Github / README_BE.md) Belarusian | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnian | [bg български] (/. Github / README_BG.md) Bulgarian | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chinese (Pinasimple) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chinese (Tradisyunal) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Croatian | [cs čeština] (/. Github / README_CS .md) Czech | [da dansk] (README_DA.md) Danish | [nl Nederlands] (/. github / README_ NL.md) Dutch | [** en-us English **] (/. github / README.md) English | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonian | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finnish | [fr français] (/. github / README_FR.md) Pranses | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galician | [ka ქართველი] (/. github / README_KA) Georgian | [de Deutsch] (/. github / README_DE.md) Aleman | [el Ελληνικά] (/. github / README_EL.md) Greek | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [siya ay nagsulat] (/. github / README_HE.md) Hebrew | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hungarian | [ay Íslenska] (/. github / README_IS.md) Icelandic | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Icelandic | [ga Gaeilge] (/. github / README_GA.md) Irish | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japanese | [jw Wong jawa] (/. github / README_JW.md) Java | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-southern 韓國 語] (/. github / README_KO_SOUTH.md) Koreano (Timog) | [ko-hilaga 문화어] (README_KO_NORTH.md) Koreano (Hilaga) (HINDI PA NAKASALIN) | [ku Kurdî] (/. github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kyrgyz | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lithuanian | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxembourgish | [mk Македонски] (/. github / README_MK.md) Macedonian | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltese | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolian | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Burmese) | [ne नेेपल]] (/. github / README_NE.md) Nepali | [walang norsk] (/. github / README_NO.md) Norwegian | [o ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persian [pl polski] (/. github / README_PL.md) Polish | [pt português] (/. github / README_PT.md) Portuguese | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Walang mga magagamit na wika na nagsisimula sa titik Q | [ro Română] (/. github / README_RO.md) Romanian | [ru русский] (/. github / README_RU.md) Russian | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scots Gaelic | [sr Српски] (/. github / README_SR.md) Serbiano | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovak | [sl Slovenščina] (/. github / README_SL.md) Slovenian | [so Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spanish | [su Sundanis] (/. github / README_SU.md) Sundan | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Suweko | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github /README_TR.md) Turkish | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukrainian | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamese | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi י:05]] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Magagamit sa 110 mga wika (108 kung hindi binibilang ang Ingles at Hilagang Korea, dahil ang Hilagang Korea ay hindi pa naisasalin [Basahin ang tungkol dito] (/ OldVersions / Korean (North ) /README.md))

Ang mga pagsasalin sa mga wika maliban sa Ingles ay isinalin sa makina at hindi pa tumpak. Walang mga error na naayos pa noong Pebrero 5 2021. Mangyaring iulat ang mga error sa pagsasalin [dito] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) tiyaking i-backup ang iyong pagwawasto sa mga mapagkukunan at gabayan ako, dahil hindi ko alam ang mga wika maliban sa Ingles na mabuti (balak kong makakuha ng tagasalin sa kalaunan) mangyaring banggitin [wiki] (https://en.wiktionary.org) at iba pang mga mapagkukunan sa iyong ulat. Ang kabiguang gawin ito ay magreresulta sa isang pagtanggi sa pagwawasto ng pagwawasto.

Tandaan: dahil sa mga limitasyon sa interpretasyon ng GitHub ng markdown (at halos lahat ng iba pang pagbibigay-kahulugan sa markdown na batay sa web) i-redirect ka sa isang magkahiwalay na file sa isang hiwalay na pahina na hindi ang aking pahina sa profile na GitHub. Ire-redirect ka sa [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), kung saan naka-host ang README.

Ang mga pagsasalin ay tapos na sa Google Translate dahil sa limitado o walang suporta para sa mga wikang kailangan ko sa ibang mga serbisyo sa pagsasalin tulad ng DeepL at Bing Translate (medyo nakakatawa para sa isang kampanya laban sa Google) Nagsusumikap ako sa paghahanap ng isang kahalili. Sa ilang kadahilanan, ang pag-format (mga link, divider, bolding, italics, atbp.) Ay ginulo sa iba't ibang mga pagsasalin. Nakakapagod na ayusin, at hindi ko alam kung paano ayusin ang mga isyung ito sa mga wikang may mga character na hindi pang-latin, at kanan sa kaliwang wika (tulad ng Arabe) na kailangan ng dagdag na tulong sa pag-aayos ng mga isyung ito

Dahil sa mga isyu sa pagpapanatili, maraming mga pagsasalin ang wala sa panahon at gumagamit ng isang hindi napapanahong bersyon ng 'README` na file ng artikulo. Kailangan ng tagasalin. Gayundin, hanggang Abril 232121, tatagal ako ng ilang sandali upang gumana ang lahat ng mga bagong link.

***

# Panahon na upang gupitin ang Widevine

Ito ay isang artikulo kung bakit dapat mong ihinto ang paggamit ng Google WideVine (DRM) at i-uninstall ito. Kailangang alisin ang DRM. Tutulungan ka ng artikulong ito na pumili ka (kung hindi mo pa nagagawa) ang WideVine ay lubos na kontra-kumpetisyon, at labis na mahigpit, at sinisira ang kalayaan ng mga video sa Internet.

Gupitin natin ang WideVine at yakapin ang isang bukas na Internet.

***

# Index

[00.0 - Nangungunang] (# Nangungunang)

> [00.1 - Basahin ang artikulong ito sa ibang wika]

> [00.2 - Pamagat] (# It-is-time-to-cut-Widevine)

> [00.3 - Index] (# Index)

[01.0 - Pangkalahatang-ideya] (# Pangkalahatang-ideya)

[02.0 - Anti-competitive] (# Anti-competitive)

[03.0 - Kakulangan ng kalayaan] (# Kakulangan sa kalayaan)

[04.0 - Paggamit ng memorya] (# Paggamit ng memorya)

[05.0 - Privacy] (# Privacy)

[06.0 - Mga kahaliling pamamaraan] (# Mga alternatibong pamamaraan)

[07.0 - Ano ang maaari mong gawin upang matulungan] (# What-you-can-do-to-help)

[08.0 - Iba pang mga bagay na dapat suriin] (# Iba pang-mga bagay-upang-mag-check-out)

[09.0 - Impormasyon sa artikulo] (# Artikulo-impormasyon)

> [09.0.1 - Status ng software] (# Software-status)

> [09.0.2 - Impormasyon ng sponsor] (# Impormasyon sa sponsor)

[10.0 - Kasaysayan ng file] (# Kasaysayan ng file)

[11.0 - Footer] (# Footer)

> [11.9 - EOF] (# EOF)

***

## Pangkalahatang-ideya

Para sa iba pang impormasyon tungkol sa kung bakit problema ang DRM, [mag-click dito] (https://www.defectivebydesign.org/)

***

## Anti-competitive

Ang WideVine ay isang DRM na dapat na may lisensya upang magamit sa isang browser. Ang Google ay labis na mabagal sa pagrepaso at pagtanggap ng mga tao, at madalas na tumatanggi sa mga tao na gamitin ito sa kanilang mga produkto nang walang pangangatuwiran. [Pinagmulan 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Pinagmulan 2 (ang email thread na nagpatuloy sa higit sa 4 na buwan at nagresulta ng walang anuman kundi pagkabigo)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Ginawang mas mahirap ng Google para sa mga browser tulad ng Brave o Firefox na makipagkumpitensya sa pagtulak nito sa piraso ng DRM.

***

## Kakulangan ng kalayaan

Ginagamit ang WideVine upang maiwasan ang mga gumagamit na makipag-ugnay sa video sa mga website. Ito ay isang uri ng mga pamamahala sa digital na paghihigpit na pumipigil sa iyo mula sa pag-download ng video, pagtingin sa video nang offline, o kahit na pagkuha ng isang screenshot. Ito ay pagmamay-ari ng software at dahil sa mga isyu nito sa privacy, hindi ito naka-install bilang default sa karamihan ng mga pamamahagi ng Linux. Nililimitahan nito ang mga kalayaan ng web dahil sa paggamit nito ng mga pelikulang Netflix, Disney, at YouTube. Ang iyong pag-access sa nilalaman ay maaaring makuha sa anumang oras nang walang dahilan.

***

## Paggamit ng memorya

Ang WideVine ay masama sa memorya. Kung ikukumpara sa normal lamang na panonood ng isang video nang walang DRM, ang WideVine ay gagamit ng mabibigat na halaga ng CPU at RAM. Ito ay masama sa bamatigas ang buhay, at hindi ito nagbibigay ng mga benepisyo mula sa karaniwang pag-playback ng video ng HTML5.

***

## Pagkapribado

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico- Children-privacy-school-chromebook-lawsuit)[sopito(https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https:// Medium.com/digiprivacy/i-stopping-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acqu acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/site/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritika) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -and) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[dopito(https://www.reuters.com/article/us-alphabet- google-privacy-demanda-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks] [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o Ingles(https://en.wikipedia.org/wiki/2018_Google_data_breach)[mopito(https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / teknolohiya / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- claims-on-ngalan-ng-5-milyong-mga-iphone-user) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[eiwan(https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technolo gy / 2014/01 / what-google-can-really-do-with-Nest-or-really-nests-data /) [i] (https://www.cbsnews.com/news/google-edukasyon-spies -on-nangongolekta-ng-data-sa-milyong-mga-bata-na-alegasyon-demanda-bagong-mexico-abogado-heneral /) [v] (https://www.nationalreview.com/2018/04/the-student- data-mining-scandal-under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y Ingles(https:// Medium.com/@hansdezwart/during-world-war-ii-we-did-have -something-to-hide-40689565c550) [.] (https:// Medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Maaari akong magpatuloy na may ebidensya dito , ngunit ito ay tumagal ng mahabang oras upang hanapin at dumaan sa lahat ng mga artikulong ito)

Ang privacy ay hindi isang bagay sa WideVine. Ang pagmamay-ari na software ay dinisenyo upang hindi mo makita kung ano ang nangyayari sa lahat. Sa kasaysayan ng Googles, malamang na ito ayAng WideVine ay isang karagdagang piraso ng software na spying sa iyo, pagbabasa ng iyong mga dokumento, at iba pang masamang bagay.

Kung sa palagay mo wala kang maitago, ** ikaw ay ganap na mali **. Ang argument na ito ay na-debunk ng maraming beses:

[Sa pamamagitan ng Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Sinabi ni Edward Snowden na "Ang pagtatalo na wala kang pakialam sa karapatan sa privacy dahil wala kang maitatago ay hindi naiiba kaysa sabihin na wala kang pakialam sa malayang pagsasalita sapagkat wala kang sasabihin." Kapag sinabi mong, ' Wala akong maitago, 'sinasabi mo,' Wala akong pakialam sa karapatang ito. 'Sinasabi mo,' Wala akong karapatang ito, dahil umabot sa puntong kailangan kong bigyang katwiran Ito. 'Kung paano gumana ang mga karapatan, dapat bigyang katwiran ng gobyerno ang pagpasok sa iyong mga karapatan. "

2. Inilahad ni Daniel J. Solove sa isang artikulo para sa The Chronicle of Higher Education na tinututulan niya ang argumento; sinabi niya na ang isang gobyerno ay maaaring maglabas ng impormasyon tungkol sa isang tao at magdulot ng pinsala sa taong iyon, o gumamit ng impormasyon tungkol sa isang tao upang tanggihan ang pag-access sa mga serbisyo kahit na ang isang tao ay hindi aktwal na gumawa ng maling gawain, at ang isang gobyerno ay maaaring maging sanhi ng pinsala sa personal ng isang tao buhay sa pamamagitan ng paggawa ng mga pagkakamali. Isinulat ni Solove na "Kapag direktang nakikipag-ugnay, maaaring makulong ang walang-pagtatago na argumento, sapagkat pinipilit nito ang debate na ituon ang pansin sa makitid nitong pag-unawa sa privacy. Ngunit nang harapin ang kasaganaan ng mga problema sa privacy na isinangkot ng pangongolekta ng data ng pamahalaan at paggamit nang lampas sa pagsubaybay at ang pagsisiwalat, ang hindi pagtatago na pagtatalo, sa huli, ay walang masabi. "

3. Si Adam D. Moore, may-akda ng Mga Karapatan sa Pagkapribado: Moral at Ligal na Mga Pundasyon, pinagtatalunan, "ito ang pananaw na ang mga karapatan ay lumalaban sa gastos / benepisyo o pang-uri na uri ng mga argumento. Dito tinatanggihan namin ang pananaw na ang mga interes sa privacy ay ang mga uri ng mga bagay na maaaring ipagpalit para sa seguridad. " Inilahad din niya na ang pagsubaybay ay maaaring makaapekto sa ilang mga pangkat sa lipunan batay sa hitsura, lahi, sekswalidad, at relihiyon.

4. Si Bruce Schneier, isang dalubhasa sa computer security at cryptographer, ay nagpahayag ng pagtutol, na binanggit ang pahayag ni Cardinal Richelieu na "Kung bibigyan ako ng anim na linya na sinulat ng kamay ng pinaka matapat na tao, mahahanap ko ang isang bagay sa kanila upang mabitay siya", na tumutukoy sa kung paano makahanap ang isang gobyerno ng estado ng mga aspeto sa buhay ng isang tao upang mausig o ma-blackmail ang indibidwal na iyon. Nagtalo rin si Schneier na "Napakaraming maling nailalarawan sa debate bilang 'seguridad kumpara sa privacy.' Ang totoong pagpipilian ay ang kalayaan laban sa kontrol. "

5. Tinantya ni Harvey A. Silverglate na ang karaniwang tao, sa average, na hindi namamalayan ay gumagawa ng tatlong mga felonies sa isang araw sa US.

6. Si Emilio Mordini, pilosopo at psychoanalyst, ay nagtalo na ang argumento na "walang maitatago" ay likas na kabalintunaan. Ang mga tao ay hindi kailangang magkaroon ng "isang bagay upang maitago" upang maitago ang "isang bagay". Ang nakatago ay hindi kinakailangang nauugnay, inaangkin ni Mordini. Sa halip, pinagtatalunan niya ang isang malapit na lugar na maaaring parehong nakatago at limitado sa pag-access ay kinakailangan dahil, sa pagsasalita ng sikolohikal, tayo ay naging indibidwal sa pamamagitan ng pagtuklas na maaari nating maitago ang isang bagay sa iba.

7. Inilahad ni Julian Assange na "Wala pang sagot sa mamamatay. Si Jacob Appelbaum (@ioerror) ay may matalinong tugon, na tinatanong sa mga taong nagsabi nito upang maibigay sa kanya ang kanilang telepono na naka-unlock at hilahin ang kanilang pantalon. Ang aking bersyon nito ay sasabihin, 'well, if you're so boring then we cannot be pakikipag-usap sa iyo, at hindi dapat ang iba pa', ngunit sa pilosopiya, ang totoong sagot ay ito: Mass surveillance is a mass struktural pagbabago. Kapag ang lipunan ay naging masama, ito ay pagpunta sa upang isama ka, kahit na ikaw ang pinaka masungit na tao sa mundo. "

8. Si Ignacio Cofone, propesor ng batas, ay nagtatalo na ang pagtatalo ay nagkakamali sa sarili nitong mga termino sapagkat, tuwing isiwalat ng mga tao ang nauugnay na impormasyon sa iba, isiniwalat din nila ang hindi kaugnay na impormasyon. Ang hindi kaugnay na impormasyon na ito ay may mga gastos sa privacy at maaaring humantong sa iba pang mga pinsala, tulad ng diskriminasyon.

***

# Mga alternatibong pamamaraan

Ang media ay hindi dapat limitahan, online o offline. Kung nais ng mga tao na panoorin ang video nang walang DRM, palagi silang makakahanap ng isang paraan upang magawa ito. Ang bawat piraso ng software ay maaaring basag.

[binago ang sipi mula sa Wikipedia] Inilahad ng pangulo ng Valve na si Gabe Newell na "karamihan sa mga diskarte ng DRM ay pipi lang" sapagkat binabawasan lamang nila ang halaga ng isang laro sa mata ng mamimili. Iminungkahi ni Newell na ang layunin ay dapat na sa halip ay "[lumilikha] ng higit na halaga para sa mga customer sa pamamagitan ng halaga ng serbisyo". Tandaan na nagpapatakbo ang Valve ng Steam, isang serbisyo na nagsisilbing isang online na tindahan para sa mga laro sa PC, pati na rin isang serbisyo sa social networking at isang platform ng DRM

Ang puntong ito ay hindi wasto para lamang sa mga video game, maaari itong mailapat sa anumang bagay sa isang computer. Ang iyong computer ay hindi dapat na kumpletong makontrol ang isang nakatutuwang kumpanya na gumagamit ng masamang Artipisyal na Intelligence upang tanggalin ang mga gumagamit nito at ang kanilang trabaho (YouTube, atbp.) At mayroong napakahusay na tala. Hindi dapat higpitan ang iyong computer dahil tumanggi ang isang kumpanya na ibahagi tulad ng isang batang masamang ugali. Dapat pagmamay-ari mo ang iyong computer,at wala nang iba. Dapat mong alisan ng kabuuan ang DRM, dahil ang nilalaman ay hindi nagkakahalaga ng pagbibigay ng kontrol sa iyong computer para sa. Ang mga kumpanyang ito ay mayroong daan-daang bilyong dolyar. Kung gumawa sila ng isang bagay na hangal tulad nito, dapat mo itong protesta. Maaari mo ring i-download ang video sa ibang lugar at tingnan ito, dahil dapat sila ay nawawalan ng pera para sa paggawa ng mga hangal tulad nito. Ang paglabag sa copyright ay hindi isang masamang bagay. Ang mga taong hindi kayang bayaran ang mga pelikula ay mai-download ang mga ito sa ibang lugar, nangyayari ito mula nang magsimula ang pandaigdigang Internet at sa pag-imbento ng VHS tape. Halos hindi ito makaapekto sa kanilang kita, dahil hindi nila makukuha pa rin ang perang iyon. Ang DRM ay may sira sa pamamagitan ng disenyo.

***

## Ano ang maaari mong gawin upang matulungan

Maaari kang magprotesta sa DRM. Ito ay maaaring mukhang hindi gaanong mahalaga, ngunit mas maraming mga taong laban dito, mas ginagawa ito tungkol dito.

Kung nasa Linux ka at gumagamit ng Firefox, tiyaking hindi naka-install ang DRM (karaniwang hindi ito bilang default) at huwag mag-abala sa pag-install nito.

Kung ikaw ay nasa Windows o MacOS, maaari kang magkaroon ng isang mas mahirap oras, dahil ang DRM ay naka-install bilang default sa mga sistemang ito, at maaaring awtomatikong muling mai-install.

Subukang iwasan ang mga sumusunod na site:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Karaniwan, dapat na iwasan ang halos anumang serbisyo sa online streaming ng video, dahil ang karamihan sa kanila ay gumagamit ng DRM at hindi mo magagamit ang site nang hindi nawawala ang iyong kalayaan. Hindi ito sulit. Magpadala ng mensahe sa [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) at ihinto ang pag-streaming ng mga palabas na ito.

Dapat mo ring iwasan ang anumang mga pagpipilian na "libre sa mga ad" sa mga sumusunod na site (dahil ang pamamaraang ito ay nangangailangan ng DRM)

[YouTube] (https://www.youtube.com)

Maaari mo ring iprotesta ang DRM sa isang mensahe sa iyong mga proyekto na 'README.md` file. Narito ang ginagamit ko:

"markdown

***

## Katayuan ng software

Lahat ng aking mga gawa ay libre ng ilang mga paghihigpit. Ang DRM (** D ** igital ** R ** mga paghihigpit ** M ** anagement) ay wala sa alinman sa aking mga gawa.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ang sticker na ito ay suportado ng Free Software Foundation. Hindi ko balak na isama ang DRM sa aking mga gawa.

Gumagamit ako ng pagdadaglat na "Pamamahala sa Mga Paghihigpit sa Digital" sa halip na ang mas kilala na "Digital Rights Management" bilang karaniwang paraan ng pagtugon dito ay mali, walang mga karapatan sa DRM. Ang spelling na "Digital Restrictions Management" ay mas tumpak, at sinusuportahan ng [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) at ng [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Ang seksyon na ito ay ginagamit upang taasan ang kamalayan para sa mga problema sa DRM, at upang protesta rin ito. Ang DRM ay may sira sa pamamagitan ng disenyo at isang pangunahing banta sa lahat ng mga gumagamit ng computer at kalayaan sa software.

Kredito sa imahe: [defectivebydesign.org/drm-free/...<<(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

""

***
## Iba pang mga bagay upang suriin

[May sira sa disenyo - Isang kampanya ng Free Software Foundation na nagtatrabaho sa paglantad at pag-aalis ng paggamit ng DRM] (https://www.defectivebydesign.org/)

[The Google Graveyard (killbygoogle.com) - isang pinagsunod-sunod na listahan ng 224+ mga produktong pinatay ng Google] (https://killedbygoogle.com/)

> [Link ng GitHub] (https://github.com/codyogden/killedbygoogle)

[Alphabet worker union - Ang bagong unyon ng mga manggagawa sa Google na may higit sa 800 mga miyembro] (https://alphabetworkersunion.org/people/our-union/)

Mayroong iba pang mga kahalili, hanapin lamang ang mga ito.

***

## Impormasyon sa artikulo

Uri ng file: `Markdown (* .md)`

Bersyon ng file: `4 (Biyernes, Abril 23rd 2021 ng 3:35 pm)`

Bilang ng linya (kabilang ang mga blangko na linya at linya ng tagatala): `354`

### Katayuan ng software

Lahat ng aking mga gawa ay libre mula sa mga paghihigpit. Ang DRM (** D ** igital ** R ** mga paghihigpit ** M ** anagement) ay wala sa alinman sa aking mga gawa. Ang proyektong ito ay hindi naglalaman ng anumang DRM, ngunit ito ay pakikipag-usap tungkol sa DRM nang direkta.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ang sticker na ito ay suportado ng Free Software Foundation. Hindi ko balak na isama ang DRM sa aking mga gawa.

***

### Impormasyon ng sponsor

! [Sponsor Button.png] (Sponsor Button.png) <- Hindi ito ang opisyal na pindutan ng sponsor, ito ay isang imahe ng demo. Huwag i-click ito kung nais mong i-sponsor ang proyektong ito.

Maaari mong i-sponsor ang proyektong ito kung nais mo, ngunit mangyaring tukuyin kung ano ang gusto mong ibigay. [Tingnan ang mga pondo na maaari mong ibigay dito] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Maaari mong tingnan ang iba pang impormasyon sa sponsor [dito] (https://github.com/seanpm2001/Sponsor-info/)

Subukan! Ang pindutan ng sponsor ay nasa tabi mismo ng pindutan ng relo / pag-unsatch.

***

## Kasaysayan ng file

Bersyon 1 (Linggo, Pebrero 8, 2021 ng 4:41 pm)

> Mga pagbabago:

> * Sinimulan ang file / artikulo

> * Idinagdag ang seksyon ng pamagat

> * Nagdagdag ng isang seksyon tungkol sa privacy

> * Nagdagdag ng isang seksyon tungkol sa pangkalahatang-ideya

> * Idinagdag ang seksyon ng impormasyon ng artikulo

> * Sumangguni sa icon na Libreng DRM

> * Idinagdag ang seksyon ng kasaysayan ng file

> * Idinagdag ang seksyon ng Kakulangan ng kalayaan

> * Idinagdag ang seksyon na Anti-mapagkumpitensya

> * Idinagdag ang seksyon ng mga alternatibong pamamaraan

> * Nagdagdag ng memory seksyon ng paggamit

> * Idinagdag ang iba pang mga bagay upang suriin ang seksyon

> * Idinagdag ang index

> * Idinagdag ang footer

> * Walang ibang mga pagbabago sa bersyon 1

Bersyon 2 (Huwebes, Abril 8th 2021 ng 5:18 pm)

> Mga pagbabago:

> * Nai-update ang seksyon ng pamagat

> * Nai-update ang index

> * Nagdagdag ng impormasyon sa kung ano ang maaari mong gawin upang matulungan

> * Idinagdag ang seksyon ng impormasyon ng sponsor

> * Nai-update ang seksyon ng impormasyon ng file

> * Nai-update ang seksyon ng kasaysayan ng file

> * Walang ibang mga pagbabago sa bersyon 2

Bersyon 3 (Huwebes, Abril 8th 2021 ng 5:27 pm)

> Mga pagbabago:

> * Nakapirming mga link sa pagsasalin

> * Nai-update ang index

> * Naayos ang isang duplicate, hindi napapasok ang paksa sa seksyong `kung ano ang maaari mong gawin upang matulungan`

> * Nai-update ang seksyon ng impormasyon ng sponsor

> * Nai-update ang seksyon ng impormasyon ng file

> * Nai-update ang seksyon ng kasaysayan ng file

> * Walang ibang mga pagbabago sa bersyon 3

Bersyon 4 (Biyernes, Abril 23rd 2021 ng 3:35 pm)

> Mga pagbabago:

> * Nai-update ang listahan ng switch ng wika

> * Nai-update ang seksyon ng impormasyon ng file

> * Nai-update ang seksyon ng kasaysayan ng file

> * Walang ibang mga pagbabago sa bersyon 4

Bersyon 5 (Malapit na)

> Mga pagbabago:

> * Malapit na

> * Walang ibang mga pagbabago sa bersyon 5

Bersyon 6 (Malapit na)

> Mga pagbabago:

> * Malapit na

> * Walang ibang mga pagbabago sa bersyon 6

Bersyon 7 (Malapit na)

> Mga pagbabago:

> * Malapit na

> * Walang ibang mga pagbabago sa bersyon 7

Bersyon 8 (Malapit na)

> Mga pagbabago:

> * Malapit na

> * Walang ibang mga pagbabago sa bersyon 8

***

## Footer

Naabot mo na ang dulo ng file na ito!

### ### EOF

***
