***

##### חלק עליון

_ קרא מאמר זה בשפה אחרת: _

** השפה הנוכחית היא: ** `אנגלית (ארה"ב)` _ (יתכן שיהיה צורך לתקן תרגומים כדי לתקן אנגלית שתחליף את השפה הנכונה) _

_🌐 רשימת שפות_

** ממוינים לפי: ** `A-Z`

[אפשרויות המיון אינן זמינות] (https://github.com/Degoogle-your-Life)

([Af אפריקאנס] (/ GitHub / README_AF.md) אפריקאנס |. [ר Shqiptare] (/ GitHub / README_SQ.md) אלבנית |.. [בבוקר አማርኛ] (/ GitHub / README_AM.md) אמהרית | [ar عربى] (/.github/README_AR.md) ערבית | [hy հայերեն] (/. github / README_HY.md) ארמנית | [az Azərbaycan dili] (/. github / README_AZ.md) אזרבייג'נית | [eu Euskara] (/. github /README_EU.md) באסקית | [be Беларуская] (/. Github / README_BE.md) בלארוסית | [bn বাংলা] (/. Github / README_BN.md) בנגלית | [bs Bosanski] (/. Github / README_BS.md) בוסנית | [bg български] (/. Github / README_BG.md) בולגרית | [ca Català] (/. Github / README_CA.md) קטלאנית | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) סינית (פשוטה) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) סינית (מסורתית) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) קרואטית | [cs čeština] (/. Github / README_CS .md) צ'כית | [da dansk] (README_DA.md) דנית | [nl Nederlands] (/. github / README_ NL.md) הולנדית | [** en-us אנגלית **] (/. github / README.md) אנגלית | [EO אספרנטו] (/. Github / README_EO.md) אספרנטו | [et Eestlane] (/. github / README_ET.md) אסטונית | [tl פיליפינית] (/. github / README_TL.md) פיליפינית | [fi Suomalainen] (/. github / README_FI.md) פינית | [fr français] (/. github / README_FR.md) צרפתית | [fy English] (/. github / README_FY.md) פריזית | [gl Galego] (/. github / README_GL.md) גליציאנית | [ka ქართველი] (/. github / README_KA) גרוזיני | [de Deutsch] (/. github / README_DE.md) גרמנית | [el Ελληνικά] (/. github / README_EL.md) יוונית | [gu ગુજરાતી] (/. github / README_GU.md) גוג'ראטי | [ht Kreyòl ayisyen] (/. github / README_HT.md) קריאולית האיטי | [הא האוזה] (/. github / README_HA.md) האוסה | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) הוואי | [he עִברִית] (/. github / README_HE.md) עברית | [היי हिन्दी] (/. github / README_HI.md) הינדית | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) הונגרית | [is Íslenska] (/. github / README_IS.md) איסלנדית | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) איסלנדית | [ga Gaeilge] (/. github / README_GA.md) אירית | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) יפנית | [jw Wong jawa] (/. github / README_JW.md) ג'וואנית | [kn ಕನ್ನಡ] (/. github / README_KN.md) קנדה | [kk Қазақ] (/. github / README_KK.md) קזחית | [ק"מ ខ្មែរ] (/. github / README_KM.md) חמר | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) קוריאנית (דרום) | [ko-north 문화어] (README_KO_NORTH.md) קוריאנית (צפון) (עדיין לא תורגם) | [ku Kurdî] (/. github / README_KU.md) כורדית (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) קירגיזים | [lo ລາວ] (/. github / README_LO.md) לאו | [la Latine] (/. github / README_LA.md) לטינית | [lt Lietuvis] (/. github / README_LT.md) ליטאי | [lb Lëtzebuergesch] (/. github / README_LB.md) לוקסמבורגית | [mk Македонски] (/. github / README_MK.md) מקדונית | [מ"ג מלגית] (/. github / README_MG.md) מלגית | [ms Bahasa Melayu] (/. github / README_MS.md) מלאית | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) מלטזית | [mi Maori] (/. github / README_MI.md) מאורי | [mr मराठी] (/. github / README_MR.md) מארתי | [mn Монгол] (/. github / README_MN.md) מונגולית | [my မြန်မာ] (/. github / README_MY.md) מיאנמר (בורמזית) | [ne नेपाली] (/. github / README_NE.md) נפאלית | [no norsk] (/. github / README_NO.md) נורווגית | [או ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) אודיה (אוריה) | [PS پښتو] (/ GitHub / README_PS.md.) פשטו | [Fa فارسی] (/ GitHub / README_FA.md.) | הפרסי [pl polski] (/ GitHub / README_PL.md.) פולנית | [pt português] (/. github / README_PT.md) פורטוגזית | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) פונג'אבי | אין שפות זמינות שמתחילות באות Q | [ro Română] (/. github / README_RO.md) רומנית | [ru русский] (/. github / README_RU.md) רוסית | [sm Faasamoa] (/. github / README_SM.md) סמואן | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) סקוטית גאלית | [sr Српски] (/. github / README_SR.md) סרבית | [סזוטו הקדוש] (/. github / README_ST.md) סזוטו | [sn Shona] (/. github / README_SN.md) Shona | [Sd سنڌي] (/ GitHub / README_SD.md.) הסינדהית | [si සිංහල] (/. github / README_SI.md) סינהלה | [sk Slovák] (/. github / README_SK.md) סלובקית | [sl Slovenščina] (/. github / README_SL.md) סלובנית | [so Soomaali] (/. github / README_SO.md) סומלית | [[es en español] (/. github / README_ES.md) ספרדית | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) סוואהילי | [sv Svenska] (/. github / README_SV.md) שוודית | [tg Тоҷикӣ] (/. github / README_TG.md) טג'יקית | [ta தமிழ்] (/. github / README_TA.md) טמילית | [tt Татар] (/. github / README_TT.md) טטרית | [te తెలుగు] (/. github / README_TE.md) טלוגו | [th ไทย] (/. github / README_TH.md) תאילנדי | [tr Türk] (/. github /README_TR.md) טורקית | [tk Türkmenler] (/. github / README_TK.md) טורקמני | [בריטניה Український] (/. github / README_UK.md) אוקראינית | [Ur اردو] (/ GitHub / README_UR.md.) אורדו | [UG ئۇيغۇر] (/ GitHub / README_UG.md.) אויגורים | [uz O'zbek] (/. github / README_UZ.md) אוזבקית | [vi Tiếng Việt] (/. github / README_VI.md) וייטנאמית | [cy Cymraeg] (/. github / README_CY.md) וולשית | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [יי יידיש] (/. github / README_YI.md) יידיש | [יו יורובה] (/. github / README_YO.md) יורובה | [zu זולו] (/. github / README_ZU.md) זולו) זמין ב -110 שפות (108 כאשר לא סופרים אנגלית וצפון קוריאנית, מכיוון שעדיין לא תורגמה צפון קוריאנית [קרא על זה כאן] (/ OldVersions / Korean (North ) / README.md))

תרגומים בשפות שאינן אנגלית מתורגמים במכונה ואינם מדויקים עדיין. עדיין לא תוקנו שגיאות החל מה -5 בפברואר 2021. אנא דווח על שגיאות תרגום [כאן] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) הקפד לגבות את התיקון שלך באמצעות מקורות ומדריכים אותי, מכיוון שאיני יודע שפות פרט לאנגלית (אני מתכוון להשיג מתרגם בסופו של דבר) אנא ציטט את [ויקימילון] (https://en.wiktionary.org) ומקורות אחרים בדו"ח שלך. כישלון בכך יביא לדחיית התיקון לפרסום.

הערה: עקב מגבלות הפרשנות של GitHub ל Markdown (וכמעט כל פרשנות אחרת מבוססת רשת של Markdown) לחיצה על קישורים אלה תפנה אותך לקובץ נפרד בעמוד נפרד שאינו עמוד הפרופיל שלי ב- GitHub. תועבר למאגר [seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), שם מתארח ה- README.

תרגומים נעשים עם Google Translate בגלל תמיכה מוגבלת או ללא תמיכה בשפות שאני זקוק לשירותי תרגום אחרים כמו DeepL ו- Bing Translate (די אירוני בקמפיין אנטי-גוגל) אני עובד על מציאת חלופה. משום מה, העיצוב (קישורים, מחיצות, מודגש, נטוי וכו ') מבולגן בתרגומים שונים. זה מייגע לתקן, ואני לא יודע איך לתקן את הבעיות האלה בשפות עם תווים לא לטיניים, ושפות מימין לשמאל (כמו ערבית) נדרשות עזרה נוספת בתיקון הבעיות

עקב בעיות תחזוקה, תרגומים רבים אינם מעודכנים ומשתמשים בגרסה מיושנת של קובץ המאמרים `README 'זה. יש צורך במתרגם. כמו כן, החל מה- 23 באפריל 2021, ייקח לי זמן עד שכל הקישורים החדשים יעבדו.

***

הגיע הזמן לחתוך את Widevine

זהו מאמר מדוע כדאי להפסיק להשתמש ב- Google WideVine (DRM) ולהסיר אותו. צריך להסיר DRM. מאמר זה יעזור לכם בבחירתכם (אם עוד לא עשיתם זאת) WideVine מאוד אנטי-תחרותי, ומגביל ביותר, והורס את חופש הסרטונים באינטרנט.

בואו נחתוך את ה- WideVine ונחבק אינטרנט פתוח.

***

# אינדקס

[00.0 - למעלה] (# למעלה)

> [00.1 - קרא מאמר זה בשפה אחרת]

> [00.2 - כותרת] (# זה הזמן לחתוך Widevine)

> [00.3 - אינדקס] (אינדקס #)

[01.0 - סקירה כללית] (סקירה מספר)

[02.0 - נגד תחרות] (# נגד תחרות)

[03.0 - חוסר חופש] (# חוסר חופש)

[04.0 - שימוש בזיכרון] (שימוש בזיכרון #)

[05.0 - פרטיות] (# פרטיות)

[06.0 - שיטות חלופיות] (# שיטות חלופיות)

[07.0 - מה אתה יכול לעשות כדי לעזור] (# מה שאתה יכול לעשות כדי לעזור)

[08.0 - דברים אחרים שצריך לבדוק] (# דברים אחרים לבדיקה)

[09.0 - מידע על מאמר] (מידע על מאמר)

> [09.0.1 - מצב תוכנה] (# מצב תוכנה)

> [09.0.2 - מידע על נותני חסות] (מידע על נותני חסות)

[10.0 - היסטוריית קבצים] (היסטוריית קבצים #)

[11.0 - כותרת תחתונה] (כותרת תחתונה #)

> [11.9 - EOF] (EOF #)

***

## סקירה כללית

למידע נוסף על מדוע DRM מהווה בעיה, [לחץ כאן] (https://www.defectivebydesign.org/)

***

## נגד תחרות

WideVine הוא DRM שיש להשתמש בו ברישיון לשימוש בדפדפן. גוגל איטית מאוד בבדיקה ובקבלה של אנשים, ולעתים קרובות מסרבת לאנשים להשתמש בה במוצרים שלהם ללא הנמקה. [מקור 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [מקור 2 (שרשור הדוא"ל שנמשך למעלה מארבעה חודשים ולא הביא למעט אכזבה)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) גוגל הקשתה הרבה יותר על דפדפנים כמו אמיץ או פיירפוקס להתחרות בדחיפה שלה לפיסת ה- DRM הזו.

***

## חוסר חופש

WideVine משמש למניעת משתמשים באינטראקציה עם וידאו באתרים. זוהי סוג של ניהול הגבלות דיגיטליות שמונע ממך להוריד את הווידאו, לצפות בווידאו במצב לא מקוון או אפילו לצלם צילום מסך. זוהי תוכנה קניינית ובגלל בעיותיה בפרטיות, היא אינה מותקנת כברירת מחדל ברוב הפצות לינוקס. זה מגביל את חירויות האינטרנט עקב השימוש בו על ידי סרטי נטפליקס, דיסני ויוטיוב. ניתן לקחת את הגישה שלך לתוכן בכל עת ללא סיבה.

***

## שימוש בזיכרון

WideVine רע בזיכרון. בהשוואה לצפייה רגילה בסרטון ללא DRM, WideVine ישתמש בכמויות כבדות של מעבד ו- RAM. זה רע ב- baחיי הטרי, וזה לא נותן שום יתרונות מהשמעת וידיאו HTML5 רגילה.

***

## פרטיות

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (תוכנית מעקב)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit] [s ](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / למה- googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ] [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -דפדפן /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# ביקורת) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -דוגמאות / שום דבר-להסתיר-ויכוח-אין-שום דבר-לומר /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- נתונים אודות-אתה-אתה יכול למצוא ולמחוק את זה עכשיו /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -ו) [c] (https://www.wired.com/story/google-tracks-you -פרטיות /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html) [d ](https://www.reuters.com/article/us-alphabet- google-privacy-תביעה-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -נמכר-מעל-ילדים-איסוף נתונים-על-חינוך-כרומבוקס] [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html) [o] [https://en.wikipedia.org/wiki/2018_Google_data_breach) [m ](https:// moz.com/bl og / איפה- google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- תביעות מטעם 5 מיליון משתמשי אייפון] [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)(e ](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -טלפון אינו בשימוש /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / מידע-טכנולוגו gy / 2014/01 / מה-גוגל-יכול-באמת-לעשות-עם-קן-או-באמת-מקנן-נתונים /) [i] (https://www.cbsnews.com/news/google-education-spies -על-אוספת נתונים-על-מיליוני ילדים-טענות-תביעה-חדש-מקסיקו-התובע הכללי /) [v] (https://www.nationalreview.com/2018/04/the-student- כריית נתונים-שערורייה-מתחת לאף שלנו /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) [y ](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -משהו להסתיר -40689565c550] [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (אני יכול להמשיך ולהמשיך עם עדויות לכך , אבל לקח הרבה זמן למצוא ולעבור את כל המאמרים האלה)

פרטיות אינה דבר עם WideVine. תוכנה קניינית תוכננה כך שלא תוכלו לראות מה קורה בכלל. עם ההיסטוריה של Google, סביר מאוד להניח שזהWideVine היא תוכנה נוספת שמרגלת אחריך, קוראת את המסמכים שלך ודברים רעים אחרים.

אם אתה חושב שאין לך מה להסתיר, ** אתה טועה לחלוטין **. טענה זו הופרכה פעמים רבות:

[דרך ויקיפדיה] (https://en.wikipedia.org/wiki/ Nothing_to_hide_argument#Criticism)

1. אדוארד סנודן העיר "לטעון שלא אכפת לך מהזכות לפרטיות כי אין לך מה להסתיר זה לא שונה מאשר לומר שלא אכפת לך מחופש הביטוי כי אין לך מה להגיד." כשאתה אומר '. אין לי מה להסתיר, 'אתה אומר,' לא אכפת לי מהזכות הזו. 'אתה אומר,' אין לי את הזכות הזו, כי הגעתי למצב שאני צריך להצדיק את זה. זה. 'איך שהזכויות עובדות, על הממשלה להצדיק את חדירתה לזכויותיך. "

2. דניאל ג'יי סולוב הצהיר במאמר ל"כרוניקל ההשכלה הגבוהה "כי הוא מתנגד לטיעון; הוא הצהיר כי ממשלה יכולה לדלוף מידע אודות אדם ולגרום נזק לאותו אדם, או להשתמש במידע אודות אדם כדי למנוע גישה לשירותים גם אם אדם לא עשה מעשה עוול בפועל, וכי ממשלה יכולה לגרום נזק לאיש האישי שלו החיים באמצעות טעויות. סולוב כתב "כשהוא מעורב באופן ישיר, הטיעון חסר הסתר יכול להתפרע, מכיוון שהוא מכריח את הדיון להתמקד בהבנתו הצרה של פרטיות. אך כאשר הוא ניצב מול ריבוי בעיות הפרטיות הכרוכות באיסוף נתונים ממשלתיים ושימוש בהם מעבר למעקב ו לחשיפה, לוויכוח דבר להסתיר, בסופו של דבר אין מה לומר. "

3. אדם ד 'מור, מחבר "זכויות פרטיות: יסודות מוסריים ומשפטיים", טען כי "הדעה היא שזכויות עמידות לטיעונים של עלות / תועלת או תוצאתיים. כאן אנו דוחים את הדעה כי אינטרסים של פרטיות הם מסוגם. של דברים שניתן לסחור עבור אבטחה. " הוא גם הצהיר כי מעקב יכול להשפיע באופן לא פרופורציונלי על קבוצות מסוימות בחברה על סמך מראה, אתניות, מיניות ודת.

4. ברוס שנייר, מומחה לאבטחת מחשבים וקריפטוגרף, הביע התנגדות וציטט את הצהרתו של הקרדינל רישלייה "אם מישהו ייתן לי שש שורות שנכתבו בידו של האדם הכי ישר, הייתי מוצא בהן משהו שיתלה אותו", בהתייחסו כיצד ממשלת מדינה יכולה למצוא היבטים בחייו של אדם על מנת להעמיד לדין או לסחוט את אותו אדם. שניאור טען גם כי "יותר מדי רבים מאפיינים את הוויכוח בטעות כ"אבטחה לעומת פרטיות." הבחירה האמיתית היא חירות לעומת שליטה. "

5. הארווי א. סילברגלייט העריך כי האדם הפשוט, בממוצע, מבצע ללא ידיעה שלושה עבירות ביום בארה"ב.

6. אמיליו מורדיני, פילוסוף ופסיכואנליטיקאי, טען כי הטיעון "אין מה להסתיר" הוא מטבעו פרדוקסלי. אנשים לא צריכים שיהיה להם "משהו להסתיר" כדי להסתיר "משהו". מה שנסתר אינו בהכרח רלוונטי, טוען מורדיני. במקום זאת הוא טוען שיש צורך באיזור אינטימי שניתן להסתיר אותו ולהגביל את הגישה מאחר שמבחינה פסיכולוגית אנו הופכים לאנשים באמצעות הגילוי שנוכל להסתיר משהו לאחרים.

7. ג'וליאן אסאנג 'הצהיר כי "אין עדיין תשובה רוצחת. ליעקב אפלבאום (@ioerror) יש תגובה חכמה ומבקש מאנשים שאומרים זאת ואז למסור לו את הטלפון שלהם נעול ולהוריד את מכנסיהם. הגרסה שלי לזה היא לומר, "ובכן, אם אתה כל כך משעמם אז אנחנו לא צריכים לדבר איתך, וגם לא מישהו אחר צריך לעשות זאת", אך מבחינה פילוסופית, התשובה האמיתית היא זו: מעקב המוני הוא שינוי מבני המוני. כאשר החברה הולכת רע, זה הולך לקחת אותך איתו, גם אם אתה האדם הכי תפל עלי אדמות. "

8. איגנסיו קופון, פרופסור למשפטים, טוען כי הטיעון טועה במונחים שלו כיוון שבכל פעם שאנשים חושפים מידע רלוונטי לאחרים, הם גם חושפים מידע לא רלוונטי. למידע לא רלוונטי זה יש עלויות פרטיות ועלול לגרום לנזקים אחרים, כגון אפליה.

***

# שיטות אלטרנטיביות

אין להגביל מדיה, מקוונת או לא מקוונת. אם אנשים היו רוצים לצפות בסרטון ללא ה- DRM, הם תמיד ימצאו דרך לעשות זאת. כל פיסת תוכנה ניתנת לפיצוח.

[קטע שונה מוויקיפדיה] נשיא השסתום גייב ניואל הצהיר כי "רוב אסטרטגיות ה- DRM פשוט מטומטמות" מכיוון שהן רק מורידות את ערך המשחק בעיני הצרכן. ניואל מציע שהמטרה צריכה להיות "[יצירת] ערך רב יותר עבור לקוחות באמצעות ערך שירות". שימו לב ש- Valve מפעילה Steam, שירות המשמש כחנות מקוונת למשחקי מחשב, כמו גם שירות רשת חברתית ופלטפורמת DRM

נקודה זו אינה תקפה רק למשחקי וידאו, ניתן להחיל אותה על כל דבר במחשב. המחשב שלך לא אמור להיות בשליטה מוחלטת של חברה מטורפת המשתמשת בבינה מלאכותית גרועה כדי למחוק את המשתמשים שלה ואת העבודה שלהם (יוטיוב וכו ') ויש לה רקורד כל כך גרוע. אין להגביל את המחשב שלך מכיוון שחברה מסרבת לשתף כמו ילד שמתנהג בצורה לא טובה. המחשב שלך צריך להיות בבעלותך,ואף אחד אחר. אתה צריך להיפטר מ- DRM לגמרי, מכיוון שלא כדאי לוותר על התוכן על השליטה במחשב שלך. לחברות אלה יש מאות מיליארדי דולרים. אם הם עושים משהו טיפשי כזה, אתה צריך למחות עליו. אתה יכול אפילו פשוט להוריד את הסרטון במקום אחר ולראות אותו, מכיוון שהם אמורים לאבד כסף על ביצוע דברים טיפשים כאלה. הפרת זכויות יוצרים אינה דבר רע. אנשים שלא יכולים להרשות לעצמם סרטים יורידו אותם במקום אחר, זה קורה מאז תחילת האינטרנט העולמי ועם המצאת קלטת ה- VHS. זה כמעט לא משפיע על הכנסותיהם, מכיוון שבכל מקרה הם לא יוכלו להשיג את הכסף הזה. DRM לוקה בתכנון.

***

## מה אתה יכול לעשות כדי לעזור

אתה יכול למחות על DRM. זה אולי נראה חסר משמעות, אבל ככל שאנשים רבים יותר נגד זה, כך עושים יותר בקשר לזה.

אם אתה משתמש ב- Linux ומשתמש ב- Firefox, ודא ש- DRM אינו מותקן (בדרך כלל הוא לא כברירת מחדל) ואל תטרח להתקין אותו.

אם אתה משתמש ב- Windows או MacOS, יתכן שיהיה לך הרבה יותר קשה, מכיוון ש- DRM מותקן כברירת מחדל במערכות אלה ועשוי להתקין מחדש אוטומטית.

נסה להימנע מהאתרים הבאים:

[Hulu] (https://hulu.com)

[דיסני +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

בעיקרון, יש להימנע כמעט מכל שירות הזרמת וידאו מקוון, מכיוון שרובם משתמשים ב- DRM ואינך יכול להשתמש באתר מבלי לאבד את חופשך. זה לא שווה את זה. שלח הודעה ל- [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) והפסיק להזרים תוכניות אלה.

עליכם להימנע גם מכל אפשרויות "בחינם עם מודעות" באתרים הבאים (מכיוון ששיטה זו דורשת DRM)

[YouTube] (https://www.youtube.com)

אתה יכול גם למחות על DRM עם הודעה בקובץ README.md` של הפרויקטים שלך. הנה מה שאני משתמש:

"סימון

***

## מצב תוכנה

כל העבודות שלי הן ללא הגבלות. DRM (** D ** igital ** R ** estrictions ** M ** anagement) אינו קיים באף אחת מהעבודות שלי.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

מדבקה זו נתמכת על ידי קרן התוכנה החופשית. אני אף פעם לא מתכוון לכלול DRM בעבודות שלי.

אני משתמש בקיצור "Digital Restrictions Management" במקום "ניהול זכויות דיגיטליות" הידוע יותר כדרך הנפוצה לטפל בו היא שקרית, אין זכויות על DRM. האיות "ניהול הגבלות דיגיטליות" מדויק יותר, והוא נתמך על ידי [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) ו- [Foundation Free Software (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

חלק זה משמש להעלאת המודעות לבעיות ב- DRM, וגם להפגנה עליו. DRM לקוי מבחינה עיצובית ומהווה איום גדול על כל משתמשי המחשב ועל חופש התוכנה.

קרדיט תמונה: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

""

***
## דברים אחרים שצריך לבדוק

[פגום בתכנון - קמפיין של קרן התוכנה החופשית שעוסק בחשיפה וביטול השימוש ב- DRM] (https://www.defectivebydesign.org/)

[בית הקברות של גוגל (killbygoogle.com) - רשימה ממוינת של 224+ מוצרים ש- Google הרגה] (https://killedbygoogle.com/)

> [קישור GitHub] (https://github.com/codyogden/killedbygoogle)

[התאחדות עובדים באלפבית - איגוד העובדים החדש בגוגל המונה למעלה מ -800 חברים] (https://alphabetworkersunion.org/people/our-union/)

יש חלופות אחרות, פשוט חפש אותם.

***

## מידע על המאמר

סוג קובץ: "Markdown (* .md)"

גרסת הקובץ: "4 (יום שישי, 23 באפריל 2021 בשעה 15:35)"

ספירת שורות (כולל שורות ריקות ושורת מהדר): '354'

### מצב תוכנה

כל העבודות שלי נקיות ממגבלות. DRM (** D ** igital ** R ** estrictions ** M ** anagement) אינו קיים באף אחת מהעבודות שלי. פרויקט זה אינו מכיל DRM כלשהו, ​​אך הוא מדבר ישירות על DRM.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

מדבקה זו נתמכת על ידי קרן התוכנה החופשית. אני אף פעם לא מתכוון לכלול DRM בעבודות שלי.

***

### מידע על נותני חסות

[SponsorButton.png] (SponsorButton.png) <- זה לא כפתור החסות הרשמי, זה תמונת הדגמה. אל תלחץ עליו אם ברצונך לתת חסות לפרויקט זה.

אתה יכול לתת חסות לפרויקט זה אם תרצה, אך אנא ציין למה אתה רוצה לתרום. [ראה את הכספים שתוכל לתרום להם כאן] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

תוכלו להציג מידע נוסף על נותני חסות [כאן] (https://github.com/seanpm2001/Sponsor-info/)

נסה את זה! כפתור החסות נמצא ממש ליד כפתור השעון / ביטול הצפייה.

***

## היסטוריית קבצים

גרסה 1 (יום ראשון, 8 בפברואר 2021 בשעה 16:41)

> שינויים:

> * התחיל את הקובץ / המאמר

> * הוסיף את קטע הכותרת

> * נוסף קטע על פרטיות

> * נוסף קטע על סקירה כללית

> * הוסיף את קטע פרטי המאמר

> * התייחס לסמל DRM Free

> * נוסף החלק של היסטוריית הקבצים

> * הוסיף את החלק חוסר חופש

> * הוסיף את החלק נגד תחרות

> * נוסף לקטע השיטות החלופיות

> * הוסיף את התזכירמדור השימוש ב- ry

> * הוסיף את שאר הדברים שצריך לבדוק

> * נוסף האינדקס

> * הוסיף את כותרת התחתונה

> * אין שינויים אחרים בגרסה 1

גרסה 2 (יום חמישי, 8 באפריל 2021 בשעה 17:18)

> שינויים:

> * עודכן את קטע הכותרת

> * עודכן את האינדקס

> * נוסף מידע על מה שאתה יכול לעשות כדי לעזור

> * הוסיף את קטע פרטי החסות

> * עודכן סעיף פרטי הקבצים

> * עודכן החלק של היסטוריית הקבצים

> * אין שינויים אחרים בגרסה 2

גרסה 3 (יום חמישי, 8 באפריל 2021 בשעה 17:27)

> שינויים:

> * קישורי תרגום קבועים

> * עודכן את האינדקס

> * תוקן כניסה כפולה, מחוץ לרשימת הנושאים, בסעיף 'מה אתה יכול לעשות כדי לעזור'

> * עודכן את סעיף פרטי החסות

> * עודכן סעיף פרטי הקבצים

> * עודכן החלק של היסטוריית הקבצים

> * אין שינויים אחרים בגרסה 3

גרסה 4 (יום שישי, 23 באפריל 2021 בשעה 15:35)

> שינויים:

> * עודכן רשימת מחליפי השפה

> * עודכן סעיף פרטי הקבצים

> * עודכן החלק של היסטוריית הקבצים

> * אין שינויים אחרים בגרסה 4

גרסה 5 (בקרוב)

> שינויים:

> * בקרוב

> * אין שינויים אחרים בגרסה 5

גרסה 6 (בקרוב)

> שינויים:

> * בקרוב

> * אין שינויים אחרים בגרסה 6

גרסה 7 (בקרוב)

> שינויים:

> * בקרוב

> * אין שינויים אחרים בגרסה 7

גרסה 8 (בקרוב)

> שינויים:

> * בקרוב

> * אין שינויים אחרים בגרסה 8

***

## כותרת תחתונה

הגעת לסוף קובץ זה!

##### EOF

***
