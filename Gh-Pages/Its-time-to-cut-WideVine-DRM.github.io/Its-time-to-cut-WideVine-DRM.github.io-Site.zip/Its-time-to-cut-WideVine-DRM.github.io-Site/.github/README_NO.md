***

##### Topp

_Les denne artikkelen på et annet språk: _

** Nåværende språk er: ** `Engelsk (USA)` _ (oversettelser må kanskje rettes for å fikse engelsk som erstatter riktig språk) _

_🌐 Liste over språk_

** Sortert etter: ** `A-Z`

[Sorteringsalternativer utilgjengelige] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albansk | [am አማርኛ] (/. github / README_AM.md) Amharisk | [ar عربى] (/.github/README_AR.md) Arabisk | [hy հայերեն] (/. github / README_HY.md) Armensk | [az Azərbaycan dili] (/. github / README_AZ.md) Aserbajdsjansk | [eu Euskara] (/. github /README_EU.md) Baskisk | [være Беларуская] (/. Github / README_BE.md) Hviterussisk | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnisk | [bg български] (/. Github / README_BG.md) Bulgarsk | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Kinesisk (forenklet) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Kinesisk (tradisjonell) | [co Corsu] (/. Github / README_CO.md) Korsikansk | [hr Hrvatski] (/. Github / README_HR.md) Kroatisk | [cs čeština] (/. Github / README_CS .md) Tsjekkisk | [da dansk] (README_DA.md) Dansk | [nl Nederlands] (/. github / README_ NL.md) Nederlandsk | [** en-us engelsk **] (/. github / README.md) Engelsk | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estisk | [tl Pilipino] (/. github / README_TL.md) Filippinsk | [fi Suomalainen] (/. github / README_FI.md) Finsk | [fr français] (/. github / README_FR.md) Fransk | [fy Frysk] (/. github / README_FY.md) Frisisk | [gl Galego] (/. github / README_GL.md) Galisisk | [ka ქართველი] (/. github / README_KA) Georgian | [de Deutsch] (/. github / README_DE.md) Tysk | [el Ελληνικά] (/. github / README_EL.md) Gresk | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitisk kreolsk | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiisk | [he עִברִית] (/. github / README_HE.md) Hebraisk | [hei हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ungarsk | [er Íslenska] (/. github / README_IS.md) Islandsk | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandsk | [ga Gaeilge] (/. github / README_GA.md) Irsk | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japansk | [jw Wong jawa] (/. github / README_JW.md) Javanesisk | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kasakhisk | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-sør 韓國 語] (/. github / README_KO_SOUTH.md) Koreansk (Sør) | [ko-nord 문화어] (README_KO_NORTH.md) Koreansk (Nord) (IKKE OVERSETT) | [ku Kurdî] (/. github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgisisk | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Litauisk | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxembourgsk | [mk Македонски] (/. github / README_MK.md) Makedonsk | [mg Madagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) Malayisk | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltesisk | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolsk | [min မြန်မာ] (/. github / README_MY.md) Myanmar (burmesisk) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) Norsk | [eller ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persisk [pl polski] (/. github / README_PL.md) Polsk | [pt português] (/. github / README_PT.md) Portugisisk | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Ingen tilgjengelige språk som begynner med bokstaven Q | [ro Română] (/. github / README_RO.md) Rumensk | [ru русский] (/. github / README_RU.md) Russisk | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Skotske gælisk | [sr Српски] (/. github / README_SR.md) Serbisk | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovakisk | [sl Slovenščina] (/. github / README_SL.md) Slovensk | [so Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spansk | [su Sundanis] (/. github / README_SU.md) Sundanesisk | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Svensk | [tg Тоҷикӣ] (/. github / README_TG.md) Tadsjik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github /README_TR.md) Tyrkisk | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukrainsk | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Usbekisk | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamesisk | [cy Cymraeg] (/. github / README_CY.md) walisisk | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jiddisk | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Tilgjengelig på 110 språk (108 når du ikke teller engelsk og nordkoreansk, da nordkoreansk ikke er oversatt ennå [Les om det her] (/ OldVersions / Korean (nord ) /README.md))

Oversettelser på andre språk enn engelsk er maskinoversatt og er ennå ikke nøyaktige. Ingen feil har blitt løst ennå 5. februar 2021. Rapporter rapporteringsfeil [her] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/), sørg for å sikkerhetskopiere korreksjonen din med kilder og veilede meg, ettersom jeg ikke kjenner andre språk enn engelsk godt (jeg planlegger å få en oversetter etter hvert) kan du sitere [wiktionary] (https://en.wiktionary.org) og andre kilder i rapporten din. Unnlatelse av å gjøre det vil føre til at avslag på rettelsen blir publisert.

Merk: på grunn av begrensninger med GitHubs tolkning av markdown (og stort sett alle andre nettbaserte tolkninger av markdown), klikker du på disse lenkene til en egen fil på en egen side som ikke er min GitHub-profilside. Du blir omdirigert til [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), der README er vert.

Oversettelser gjøres med Google Translate på grunn av begrenset eller ingen støtte for språkene jeg trenger i andre oversettelsestjenester som DeepL og Bing Translate (ganske ironisk for en anti-Google-kampanje) Jeg jobber med å finne et alternativ. Av en eller annen grunn er formateringen (lenker, skillelinjer, fet skrift, kursiv osv.) Rotet sammen i forskjellige oversettelser. Det er kjedelig å fikse, og jeg vet ikke hvordan jeg skal løse disse problemene på språk med ikke-latinske tegn, og fra høyre til venstre språk (som arabisk) er det nødvendig med ekstra hjelp til å løse disse problemene

På grunn av vedlikeholdsproblemer er mange oversettelser utdaterte og bruker en utdatert versjon av denne `README`-artikkelfilen. En oversetter er nødvendig. Fra 23. april 2021 vil det også ta litt tid å få alle de nye koblingene til å fungere.

***

# Det er på tide å kutte Widevine

Dette er en artikkel om hvorfor du bør slutte å bruke Google WideVine (DRM) og avinstallere den. DRM må fjernes. Denne artikkelen vil hjelpe deg med å ta ditt valg (hvis du ikke allerede har gjort det) WideVine er svært konkurransedyktig og ekstremt restriktiv og ødelegger friheten til videoer på Internett.

La oss kutte WideVine og omfavne et åpent internett.

***

# Indeks

[00.0 - Topp] (# Topp)

> [00.1 - Les denne artikkelen på et annet språk]

> [00.2 - Tittel] (# It-is-time-to-cut-Widevine)

> [00.3 - Indeks] (# indeks)

[01.0 - Oversikt] (# Oversikt)

[02.0 - Konkurransedyktig] (# Konkurransedyktig)

[03.0 - Mangel på frihet] (# Mangel på frihet)

[04.0 - Minnebruk] (# minnebruk)

[05.0 - Personvern] (# Personvern)

[06.0 - Alternative metoder] (# Alternative-metoder)

[07.0 - Hva du kan gjøre for å hjelpe] (# Hva-du-kan-gjøre-for-hjelp)

[08.0 - Andre ting å sjekke ut] (# Andre ting å sjekke ut)

[09.0 - Artikkelinfo] (# Artikkelinfo)

> [09.0.1 - Programvarestatus] (# Programvarestatus)

> [09.0.2 - Sponsorinfo] (# Sponsorinfo)

[10.0 - Filhistorikk] (# Filhistorikk)

[11.0 - Bunntekst] (# bunntekst)

> [11.9 - EOF] (# EOF)

***

## Oversikt

For annen informasjon om hvorfor DRM er et problem, [klikk her] (https://www.defectivebydesign.org/)

***

## Konkurransedyktig

WideVine er en DRM som må lisensieres for å brukes med en nettleser. Google er ekstremt treg med å gjennomgå og godta folk, og nekter ofte folk å bruke det i sine produkter uten resonnement. [Kilde 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Kilde 2 (e-posttråden som gikk i over 4 måneder og resulterte i ingenting annet enn skuffelse)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google har gjort det mye vanskeligere for nettlesere som Brave eller Firefox å konkurrere med å skyve dette stykket DRM.

***

## Mangel på frihet

WideVine brukes til å forhindre brukere i å samhandle med video på nettsteder. Det er en form for ledelse av digitale restriksjoner som forhindrer deg i å laste ned videoen, se videoen offline, eller til og med ta et skjermbilde. Det er proprietær programvare, og på grunn av problemer med personvern er den ikke installert som standard på de fleste Linux-distribusjoner. Det begrenser nettets friheter på grunn av bruken av Netflix, Disney og YouTube-filmer. Din tilgang til innholdet kan tas bort når som helst uten grunn.

***

## Minnebruk

WideVine har dårlig hukommelse. Sammenlignet med å bare se en video uten DRM, vil WideVine bruke store mengder CPU og RAM. Det er dårlig på baliv, og det gir ingen fordeler med standard HTML5-videoavspilling.

***

## Personvern

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (overvåkingsprogram)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) [s ](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / hvorfor-googles-spionere-på-bruk_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritikk) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -prøver / ingenting-til-skjul-argument-har-ingenting-å-si /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-om-deg-du-kan-finne-og-slette-det-nå /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personlig-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -og) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d ](https://www.reuters.com/article/us-alphabet- google-personvern-søksmål-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html) [o ](https://en.wikipedia.org/wiki/2018_Google_data_breach) [m ](https:// moz.com/bl og / hvor-gjør-google-tegner-data-innsamlingslinjen) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- krav på vegne av 5 millioner iPhone-brukere) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) [e ](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -telefon-er ikke i bruk /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / informasjonsteknologi gy / 2014/01 / hva-google-kan-virkelig-gjøre-med-reir-eller-virkelig-reir-data /) [i] (https://www.cbsnews.com/news/google-education-spies -på-samler-data-på-millioner-av-barn-påstander-søksmål-nye-mexico-advokat-general /) [v] (https://www.nationalreview.com/2018/04/the-student- data-mining-skandale-under-nesen /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y ](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -något å skjule -40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Jeg kunne fortsette og fortsette med bevis på dette , men det tok lang tid å finne og gå gjennom alle disse artiklene)

Personvern er ikke noe med WideVine. Proprietær programvare er designet slik at du ikke kan se hva som skjer i det hele tatt. Med Googles historie er det høyst sannsynlig detWideVine er et ekstra programvare som spionerer på deg, leser dokumentene dine og andre dårlige ting.

Hvis du tror du ikke har noe å skjule, ** tar du helt feil **. Dette argumentet har blitt avslørt mange ganger:

[Via Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden bemerket: "Å argumentere for at du ikke bryr deg om retten til privatliv fordi du ikke har noe å skjule, er ikke annerledes enn å si at du ikke bryr deg om ytringsfrihet fordi du ikke har noe å si." Når du sier, ' Jeg har ingenting å skjule, 'du sier,' jeg bryr meg ikke om denne retten. 'Du sier,' jeg har ikke denne retten, fordi jeg har kommet til det punktet hvor jeg må rettferdiggjøre "Slik rettighetene fungerer, må regjeringen rettferdiggjøre inntrenging i rettighetene dine."

2. Daniel J. Solove uttalte i en artikkel for The Chronicle of Higher Education at han er imot argumentet; han uttalte at en regjering kan lekke informasjon om en person og forårsake skade på den personen, eller bruke informasjon om en person for å nekte tilgang til tjenester selv om en person ikke faktisk gjorde noe galt, og at en regjering kan skade sin personlige livet gjennom å gjøre feil. Solove skrev: "Når det er engasjert direkte, kan det ingenting å skjule argumentet fange seg, for det tvinger debatten til å fokusere på sin snevre forståelse av personvern. Men når den blir konfrontert med mangfoldet av personvernproblemer som er involvert av myndighetsinnsamling og bruk utover overvåking og avsløring, ingenting å skjule argumentet, til slutt, har ingenting å si. "

3. Adam D. Moore, forfatter av Privacy Rights: Moral and Legal Foundations, argumenterte: "det er synet på at rettigheter er motstandsdyktige mot kostnader / fordeler eller konsekvensistiske argumenter. Her avviser vi synspunktet om at personverninteresser er den slags av ting som kan handles for sikkerhet. " Han uttalte også at overvåking uforholdsmessig kan påvirke visse grupper i samfunnet basert på utseende, etnisitet, seksualitet og religion.

4. Bruce Schneier, en datasikkerhetsekspert og kryptograf, uttrykte motstand og siterte kardinal Richelieus uttalelse "Hvis man ville gi meg seks linjer skrevet av den ærligste mannen, ville jeg finne noe i dem for å få ham hengt", med henvisning til hvordan en statsregering kan finne aspekter i en persons liv for å straffeforfølge eller utpresse vedkommende. Schneier hevdet også "Altfor mange karakteriserer debatten feilaktig som" sikkerhet versus personvern. " Det virkelige valget er frihet kontra kontroll. "

5. Harvey A. Silverglate anslår at den vanlige personen i gjennomsnitt uvitende begår tre forbrytelser om dagen i USA.

6. Emilio Mordini, filosof og psykoanalytiker, hevdet at argumentet om "ingenting å skjule" er iboende paradoksalt. Folk trenger ikke å ha "noe å skjule" for å skjule "noe". Det som er skjult, er ikke nødvendigvis relevant, hevder Mordini. I stedet hevder han at et intimt område som både kan skjules og tilgangsbegrenset er nødvendig, siden vi psykologisk sett blir individer gjennom oppdagelsen av at vi kunne skjule noe for andre.

7. Julian Assange uttalte: "Det er ikke noe drapsmannssvar ennå. Jacob Appelbaum (@ioerror) har et smart svar og ber folk som sier dette om å deretter gi ham telefonen ulåst og trekke ned buksene. Min versjon av det er å si, "Vel, hvis du er så kjedelig, burde vi ikke snakke med deg, og heller ikke noen andre", men filosofisk, er det virkelige svaret dette: Masseovervåking er en massestrukturell endring. Når samfunnet går dårlig, går det å ta deg med det, selv om du er den blideste personen på jorden. "

8. Ignacio Cofone, jusprofessor, hevder at argumentet er feilaktig i sine egne ord, fordi når folk avslører relevant informasjon til andre, avslører de også irrelevant informasjon. Denne irrelevante informasjonen har personvernkostnader og kan føre til andre skader, for eksempel diskriminering.

***

# Alternative metoder

Media bør ikke være begrenset, online eller offline. Hvis folk ønsket å se videoen uten DRM, vil de alltid finne en måte å gjøre det på. Hver programvare kan bli sprukket.

[modifisert utdrag fra Wikipedia] Valgpresident Gabe Newell har uttalt "de fleste DRM-strategier er bare dumme" fordi de bare reduserer verdien av et spill i forbrukerens øyne. Newell foreslår at målet i stedet skal være "[skape] større verdi for kunder gjennom serviceverdi". Merk at Valve driver Steam, en tjeneste som fungerer som en nettbutikk for PC-spill, i tillegg til en sosial nettverkstjeneste og en DRM-plattform

Dette punktet er ikke gyldig bare for videospill, det kan brukes på hva som helst på en datamaskin. Datamaskinen din skal ikke ha full kontroll over et gal selskap som bruker dårlig kunstig intelligens for å slette brukere og deres arbeid (YouTube, etc.) og har så dårlig rekord. Datamaskinen din bør ikke være begrenset fordi et selskap nekter å dele som et barn som har dårlig oppførsel. Datamaskinen din bør eies av deg,og ingen andre. Du bør bli kvitt DRM helt, siden innholdet ikke er verdt å gi opp kontrollen over datamaskinen din. Disse selskapene har hundrevis av milliarder dollar. Hvis de gjør noe dumt som dette, bør du protestere mot det. Du kan til og med bare laste ned videoen andre steder og se den, da de burde tape penger på å gjøre dumme ting som dette. Opphavsrettsbrudd er ikke en dårlig ting. Folk som ikke har råd til filmer, vil laste dem ned andre steder. Det har skjedd siden starten på det globale Internett og med oppfinnelsen av VHS-båndet. Det påvirker neppe inntektene deres, da de uansett ikke ville kunne få pengene. DRM er defekt av design.

***

## Hva du kan gjøre for å hjelpe

Du kan protestere mot DRM. Det kan virke ubetydelig, men jo flere som går imot det, jo mer blir det gjort med det.

Hvis du bruker Linux og bruker Firefox, må du sørge for at DRM ikke er installert (det er normalt ikke som standard) og ikke gidder å installere det.

Hvis du bruker Windows eller MacOS, kan det hende du har det mye vanskeligere, ettersom DRM er installert som standard på disse systemene, og kan installere på nytt automatisk.

Prøv å unngå følgende nettsteder:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

I utgangspunktet bør nesten hvilken som helst online videostreamingtjeneste unngås, da de fleste bruker DRM og du ikke kan bruke nettstedet uten å miste friheten din. Det er ikke verdt det. Send [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) en melding og slutte å streame disse showene.

Du bør også unngå "gratis med annonser" -alternativer på følgende nettsteder (ettersom denne metoden krever DRM)

[YouTube] (https://www.youtube.com)

Du kan også protestere mot DRM med en melding på prosjektene `README.md`-filen. Dette er hva jeg bruker:

`` markdown

***

## Programvarestatus

Alle verkene mine er gratis, noen begrensninger. DRM (** D ** igital ** R ** estrictions ** M ** anagement) er ikke tilstede i noen av mine verk.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Dette klistremerket støttes av Free Software Foundation. Jeg har aldri tenkt å inkludere DRM i verkene mine.

Jeg bruker forkortelsen "Digital Restrictions Management" i stedet for den mer kjente "Digital Rights Management" som vanlig måte å adressere den på er falsk, det er ingen rettigheter med DRM. Stavemåten "Digital Restrictions Management" er mer nøyaktig og støttes av [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) og [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Denne delen brukes til å øke bevisstheten om problemene med DRM, og også for å protestere mot den. DRM er defekt av design og er en stor trussel mot alle databrukere og programvarefrihet.

Bildekreditt: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

``

***
## Andre ting å sjekke ut

[Defekt ved design - En kampanje fra Free Software Foundation som jobber med å avsløre og eliminere DRM-bruk] (https://www.defectivebydesign.org/)

[Google Graveyard (killedbygoogle.com) - en sortert liste over de 224+ produktene Google har drept] (https://killedbygoogle.com/)

> [GitHub-lenke] (https://github.com/codyogden/killedbygoogle)

[Alphabet worker union - The new workers union at Google with over 800 members] (https://alphabetworkersunion.org/people/our-union/)

Det er andre suppleanter, bare søk etter dem.

***

## Artikkel info

Filtype: `` Markdown (* .md) '

Filversjon: `` 4 (fredag ​​23. april 2021 kl. 15:35) '

Linjetelling (inkludert blanke linjer og kompileringslinje): `354`

### Programvarestatus

Alle verkene mine er uten begrensninger. DRM (** D ** igital ** R ** estrictions ** M ** anagement) er ikke tilstede i noen av mine verk. Dette prosjektet inneholder ikke DRM, men det snakker direkte om DRM.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Dette klistremerket støttes av Free Software Foundation. Jeg har aldri tenkt å inkludere DRM i verkene mine.

***

### Sponsorinfo

! [SponsorButton.png] (SponsorButton.png) <- Dette er ikke den offisielle sponsorknappen, det er et demo-bilde. Ikke klikk på den hvis du vil sponse dette prosjektet.

Du kan sponse dette prosjektet hvis du vil, men spesifiser hva du vil donere til. [Se midlene du kan donere til her] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Du kan se annen sponsorinfo [her] (https://github.com/seanpm2001/Sponsor-info/)

Prøv det! Sponsorknappen er helt oppe ved siden av klokke / urknappen.

***

## Filhistorikk

Versjon 1 (søndag 8. februar 2021 klokken 16.41)

> Endringer:

> * Startet filen / artikkelen

> * Lagt til tittelseksjonen

> * Lagt til en seksjon om personvern

> * Lagt til et avsnitt om oversikten

> * Lagt til artikkelen info delen

> * Referert til DRM Free-ikonet

> * Lagt til filhistorikk-delen

> * Lagt til delen Mangel på frihet

> * Lagt til konkurransebegrensende seksjon

> * Lagt til delen for alternative metoder

> * Lagt til notatetry bruk seksjon

> * Lagt til de andre tingene for å sjekke ut seksjonen

> * Lagt til indeksen

> * Lagt til bunnteksten

> * Ingen andre endringer i versjon 1

Versjon 2 (torsdag 8. april 2021 kl 17:18)

> Endringer:

> * Oppdaterte tittelseksjonen

> * Oppdatert indeksen

> * Lagt til informasjon om hva du kan gjøre for å hjelpe

> * Lagt til sponsorinfoseksjonen

> * Oppdaterte filinfoseksjonen

> * Oppdaterte filhistorikk-delen

> * Ingen andre endringer i versjon 2

Versjon 3 (torsdag 8. april 2021 klokken 17:27)

> Endringer:

> * Faste oversettelseskoblinger

> * Oppdatert indeksen

> * Fikset en duplikat, av emnet, i delen "hva du kan gjøre for å hjelpe"

> * Oppdaterte sponsorinfoseksjonen

> * Oppdaterte filinfoseksjonen

> * Oppdaterte filhistorikk-delen

> * Ingen andre endringer i versjon 3

Versjon 4 (fredag ​​23. april 2021 kl. 15:35)

> Endringer:

> * Oppdaterte listen over språkbyttere

> * Oppdaterte filinfoseksjonen

> * Oppdaterte filhistorikk-delen

> * Ingen andre endringer i versjon 4

Versjon 5 (Kommer snart)

> Endringer:

> * Kommer snart

> * Ingen andre endringer i versjon 5

Versjon 6 (Kommer snart)

> Endringer:

> * Kommer snart

> * Ingen andre endringer i versjon 6

Versjon 7 (Kommer snart)

> Endringer:

> * Kommer snart

> * Ingen andre endringer i versjon 7

Versjon 8 (Kommer snart)

> Endringer:

> * Kommer snart

> * Ingen andre endringer i versjon 8

***

## Bunntekst

Du har nådd slutten av denne filen!

##### EOF

***
