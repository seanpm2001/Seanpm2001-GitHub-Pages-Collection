***

##### Top

_ Ka nkan yii ni ede miiran: _

** Ede lọwọlọwọ jẹ: ** “Gẹẹsi (AMẸRIKA)“ _ (awọn itumọ le nilo atunṣe lati ṣatunṣe Gẹẹsi ti o rọpo ede to tọ) _

_🌐 Akojọ awọn ede_

** A to lẹsẹsẹ nipasẹ: ** `A-Z`

[Awọn aṣayan tito lẹtọ ko si] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanian | [am English] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) Arabic | [hy հայերեն] (/. github / README_HY.md) Armenian | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijani | [eu Euskara] (/. github /README_EU.md) Basque | [jẹ Беларуская] (/. Github / README_BE.md) Belarus | | bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnian | [bg български] (/. Github / README_BG.md) Bulgarian | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Ṣaina (Irọrun) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Ara Ṣaina (Ibile) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Croatian | [cs čeština] (/. Github / README_CS .md) Czech | [da dansk] (README_DA.md) Danish | [nl Nederlands] (/. github / README_ NL.md) Dutch | [** en-us Gẹẹsi **] (/. github / README.md) Gẹẹsi | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonia | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finnish | [fr Français] (/. github / README_FR.md) Faranse | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galician | [ka ქართველი] (/. github / README_KA) Georgian | [de Deutsch] (/. github / README_DE.md) Jẹmánì | [el Ελληνικά] (/. github / README_EL.md) Giriki | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Ilu Hawahi | [oun עִברִית] (/. github / README_HE.md) Heberu | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ara Ilu Hungary | [jẹ Íslenska] (/. github / README_IS.md) Icelandic | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Icelandic | [ga Gaeilge] (/. github / README_GA.md) Irish | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Ara ilu Japanese | [jw Wong jawa] (/. github / README_JW.md) Javanese | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-guusu 韓國 語] (/. github / README_KO_SOUTH.md) Korean (Guusu) | [ko-north 문화어] (README_KO_NORTH.md) Korean (Ariwa) (KO T TRTUN T YTỌ) | [ku Kurdî] (/. github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kyrgyz | [wo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lithuanian | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxembourgish | [mk Македонски] (/. github / README_MK.md) Macedonian | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [milimita മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Ilu Malta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolian | [mi မြန်မာ] (/. github / README_MY.md) Mianma (Burmese) | [ne नेपाली] (/. github / README_NE.md) Nepali | [ko si norsk] (/. github / README_NO.md) Norwegian | [tabi ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persia [pl polski] (/. github / README_PL.md) Polandii | [pt português] (/. github / README_PT.md) Ilu Pọtugalii | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Ko si awọn ede ti o wa ti o bẹrẹ pẹlu lẹta Q | [ro Română] (/. github / README_RO.md) Romanian | [ru русский] (/. github / README_RU.md) Russian | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scots Gaelic | [sr Српски] (/. github / README_SR.md) Ara Ilu Serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovak | [sl Slovenščina] (/. github / README_SL.md) Ara Slovenia | [nitorina Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Ede Sipeeni | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Swedish | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github /README_TR.md) Tọki | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ti Ukarain | [ur]] / / github / README_UR.md) Ilu Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnam | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | { ) / README.md))

Awọn itumọ ni awọn ede miiran yatọ si Gẹẹsi jẹ itumọ ẹrọ ati pe ko iti pe. Ko si awọn aṣiṣe ti o wa titi sibẹsibẹ ti Oṣu Karun ọjọ 5th 2021. Jọwọ jabo awọn aṣiṣe itumọ [nibi] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) rii daju lati ṣe afẹyinti atunṣe rẹ pẹlu awọn orisun ati itọsọna mi, nitori Emi ko mọ awọn ede miiran yatọ si Gẹẹsi daradara (Mo gbero lati ni onitumọ nikẹhin) jọwọ sọ [wiktionary] (https://en.wiktionary.org) ati awọn orisun miiran ninu ijabọ rẹ. Ti o ba kuna lati ṣe bẹ yoo jẹ ki ijusile ti atunṣe ti n gbejade.

Akiyesi: nitori awọn idiwọn pẹlu itumọ GitHub ti markdown (ati pupọ julọ gbogbo itumọ orisun wẹẹbu miiran ti markdown) tite awọn ọna asopọ wọnyi yoo ṣe atunṣe ọ si faili ọtọtọ lori oju-iwe ọtọ ti kii ṣe oju-iwe profaili GitHub mi. A o darí rẹ si ibi ipamọ [seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), nibiti a ti gbalejo README naa.

Ti ṣe awọn itumọ pẹlu Google Translate nitori opin tabi ko si atilẹyin fun awọn ede ti Mo nilo ninu awọn iṣẹ itumọ miiran bi DeepL ati Bọtini Bing (ẹlẹya ẹlẹwa fun ipolongo Google-anti-Google) Mo n ṣiṣẹ lori wiwa yiyan. Fun idi diẹ, kika (awọn ọna asopọ, awọn pinpin, igboya, awọn italisi, ati bẹbẹ lọ) jẹ idotin ni awọn itumọ oriṣiriṣi. O jẹ ohun ti o nira lati ṣatunṣe, ati pe emi ko mọ bi a ṣe le ṣatunṣe awọn ọran wọnyi ni awọn ede pẹlu awọn ohun kikọ ti kii ṣe latin, ati sọtun si awọn ede apa osi (bii Arabic) nilo iranlọwọ afikun ni titọ awọn ọrọ wọnyi

Nitori awọn ọran itọju, ọpọlọpọ awọn itumọ ti wa ni ọjọ ati lo ẹya ti igba atijọ ti faili nkan “README` yii. O nilo onitumọ kan. Pẹlupẹlu, bi Oṣu Kẹrin Ọjọ 23rd 2021, yoo gba mi ni igba diẹ lati gba gbogbo awọn ọna asopọ tuntun ṣiṣẹ.

***

# O to akoko lati ge Widevine

Eyi jẹ nkan lori idi ti o yẹ ki o da lilo Google WideVine (DRM) ki o yọkuro rẹ. DRM nilo lati yọkuro. Nkan yii yoo ran ọ lọwọ lati ṣe yiyan (ti o ko ba si tẹlẹ) WideVine jẹ alatako-ifigagbaga gíga, ati idiwọ apọju, o si n pa ominira awọn fidio run lori Intanẹẹti.

Jẹ ki a ge WideVine ki a gba Intanẹẹti ṣiṣi kan.

***

Atọka

[00.0 - Top] (# Oke)

> [00.1 - Ka nkan yii ni ede miiran]

> [00.2 - Akọle] (# O jẹ-akoko-lati-ge-Widevine)

> [00.3 - Atọka] (Atọka #)

[01.0 - Akopọ] (# Akopọ)

[02.0 - Alatako-idije] (# Idije alatako)

[03.0 - Aini ominira] (# Aini-ominira)

[04.0 - Lilo Iranti] (# Lilo-iranti)

[05.0 - Asiri] (# Asiri)

[06.0 - Awọn ọna omiiran] (# Awọn ọna miiran)

[07.0 - Kini o le ṣe lati ṣe iranlọwọ] (# Kini-o-le-ṣe-lati ṣe iranlọwọ)

[08.0 - Awọn nkan miiran lati ṣayẹwo] (# Awọn ohun miiran-lati-ṣayẹwo)

[09.0 - Alaye Nkan] [# Abala-alaye]

> [09.0.1 - Ipo sọfitiwia] (# Ipo sọfitiwia)

> [09.0.2 - Alaye Onigbowo] (# Alaye Onigbowo)

[10.0 - Itan faili] (# Itan-faili)

[11.0 - Ẹlẹsẹ] (# Ẹlẹsẹ)

> [11.9 - EOF] (# EOF)

***

## Akopọ

Fun alaye miiran nipa idi ti DRM fi jẹ iṣoro, [tẹ ibi] (https://www.defectivebydesign.org/)

***

## Idije alatako

WideVine jẹ DRM ti o ni lati ni iwe-aṣẹ lati lo pẹlu ẹrọ lilọ kiri ayelujara kan. Google lọra pupọ lori atunyẹwo ati gbigba awọn eniyan, ati nigbagbogbo kọ awọn eniyan lati lo ninu awọn ọja wọn laisi ero. [Orisun 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Orisun 2 (okun imeeli ti o lọ fun ju oṣu mẹrin 4 ati pe ko ṣe nkankan bikoṣe ibanujẹ)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google ti jẹ ki o nira pupọ fun awọn aṣawakiri bii Onígboyà tabi Firefox lati dije pẹlu titari nkan yii ti DRM.

***

## Aini ominira

Ti lo WideVine lati ṣe idiwọ awọn olumulo lati ṣe ibaraenisepo pẹlu fidio lori awọn oju opo wẹẹbu. O jẹ fọọmu awọn iṣakoso awọn ihamọ oni-nọmba ti o ṣe idiwọ fun ọ lati ṣe igbasilẹ fidio, wiwo fidio ni aisinipo, tabi paapaa ya sikirinifoto. O jẹ sọtọ sọfitiwia ati nitori awọn ọran rẹ pẹlu aṣiri, ko fi sii nipasẹ aiyipada lori ọpọlọpọ awọn pinpin kaakiri Linux. O n ṣe idiwọn awọn ominira ti oju opo wẹẹbu nitori lilo rẹ nipasẹ Netflix, Disney, ati awọn fiimu YouTube. Wiwọle rẹ si akoonu ni a le mu ni igbakugba laisi idi kan.

***

## Lilo iranti

WideVine ko dara lori iranti. Ti a ṣe afiwe si wiwo fidio deede kan laisi DRM, WideVine yoo lo awọn oye iwuwo ti Sipiyu ati Ramu. O buru lori baaye ttery, ati pe ko fun awọn anfani lati ṣiṣiṣẹsẹhin fidio HTML5 deede.

***

## Asiri

[G] (https://en.wikipedia.org/wiki/ Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (iwo-kakiri_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / gbogbo-data-facebook-google-has-on-you-ikọkọ) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit).Thes -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / titẹsi / idi-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / bulọọgi / google-ìpamọ-iṣoro /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Alariwisi) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -awọn apẹẹrẹ / nkankan-lati-tọju-ariyanjiyan-ko ni nkankan-lati sọ /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-nipa-o-le-wa-ati-paarẹ-ni bayi /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -ati) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html) [=] // [//https://www.reuters.com/article/us-alphabet- google-ìpamọ-ẹjọ-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)Press] [https://en.wikipedia.org/wiki/2018_Google_data_breach)=m] (https://) moz.com/bl og / ibo-ni-google-fa-laini gbigba-data-naa) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / imọ-ẹrọ / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- awọn ẹtọ-lori-dípò-ti-5-million-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) [] -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / alaye-technolo gy / 2014/01 / kini-google-le-ṣe-ga-ṣe-pẹlu-itẹ-tabi-awọn-itẹ-gidi-data /) [i] (https://www.cbsnews.com/news/google-education-spies -on-collections-on-million-of-kids-alleges-ẹjọ-titun-mexico-Attorney-General /) [v] (https://www.nationalreview.com/2018/04/the-student- data-iwakusa-sikandali-labẹ-imu wa / / [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) [] [https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -kankan-lati-tọju-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Mo le lọ siwaju ati siwaju pẹlu ẹri ti eyi , ṣugbọn o gba akoko pipẹ lati wa ati lọ nipasẹ gbogbo awọn nkan wọnyi)

Asiri kii ṣe nkan pẹlu WideVine. Ti ṣe apẹrẹ software ti ohun-ini ki o ko le rii ohun ti n lọ rara. Pẹlu itan Googles, o ṣee ṣe gaan peWideVine jẹ ẹya afikun ti sọfitiwia ti o n ṣe amí lori rẹ, kika awọn iwe aṣẹ rẹ, ati awọn ohun buburu miiran.

Ti o ba ro pe o ko ni nkankan lati tọju, ** o jẹ aṣiṣe patapata **. A ti ṣe ariyanjiyan ariyanjiyan yii ni ọpọlọpọ awọn igba lori:

[Nipasẹ Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden ṣe akiyesi “Jiyàn pe iwọ ko bikita nipa ẹtọ si ikọkọ nitori o ko ni nkankan lati tọju ko yatọ si ju sisọ pe o ko bikita nipa ọrọ ọfẹ nitori o ko ni nkankan lati sọ.” Nigbati o sọ, ‘ Mi o ni nkankan lati fi pamọ, 'o n sọ pe,' Emi ko fiyesi nipa ẹtọ yii. 'Iwọ n sọ pe,' Emi ko ni ẹtọ yii, nitori Mo ti de aaye ti Mo ni lati lare o. 'Ọna ti awọn ẹtọ n ṣiṣẹ jẹ, ijọba ni lati ṣalaye ifọpa si awọn ẹtọ rẹ. "

2. Daniel J. Solove sọ ninu nkan kan fun The Chronicle of Higher Education pe o tako ariyanjiyan naa; o ṣalaye pe ijọba kan le jo alaye nipa eniyan kan ki o fa ibajẹ si eniyan naa, tabi lo alaye nipa eniyan lati sẹ wiwọle si awọn iṣẹ paapaa ti eniyan ko ba ṣe aiṣedede, ati pe ijọba kan le fa ibajẹ si ti ara ẹni igbesi aye nipasẹ ṣiṣe awọn aṣiṣe. Solove kọwe “Nigbati o ba ṣiṣẹ taara, ariyanjiyan ariyanjiyan ohunkohun lati fi pamọ le dẹkun, fun o fi ipa mu ariyanjiyan naa lati dojukọ oye rẹ ti o ni oye ti aṣiri. Ṣugbọn nigbati o ba dojuko pẹlu ọpọlọpọ awọn iṣoro aṣiri ti o kan nipa gbigba data ijọba ati lilo kọja iwo-kakiri ati ifihan, ariyanjiyan ariyanjiyan-lati-tọju, ni ipari, ko ni nkankan lati sọ. "

3. Adam D. Moore, onkọwe ti Awọn ẹtọ Asiri: Iwa ati Awọn ipilẹ Ofin, jiyan, “o jẹ iwo ti awọn ẹtọ jẹ alatako si idiyele / anfani tabi iru awọn ariyanjiyan. Eyi ni a kọ fun wiwo pe awọn ifẹ aṣiri ni awọn iru. ti awọn ohun ti o le ṣe tita fun aabo. " O tun ṣalaye pe iwo-kakiri le ni ipa aiṣedeede ni ipa awọn ẹgbẹ kan ni awujọ ti o da lori irisi, ẹya, ibalopọ, ati ẹsin.

4. Bruce Schneier, amoye aabo kọnputa ati onitumọ ọrọ, ṣalaye atako, ni atọkasi ọrọ Cardinal Richelieu “Ti ẹnikan ba fun mi ni awọn ila mẹfa ti a kọ nipasẹ ọwọ ọkunrin oloootọ julọ, Emi yoo wa nkan ninu wọn lati jẹ ki o so mọ”, ifilo si bawo ni ijọba ipinlẹ kan ṣe le wa awọn aaye ninu igbesi aye eniyan lati le pe lẹjọ tabi ba ẹni yẹn jẹ. Schneier tun jiyan “Pupọ pupọ ti o ṣe apejuwe jiyan ariyanjiyan bi 'aabo ni ilodi si aṣiri.' Aṣayan gidi ni ominira dipo iṣakoso. ”

5. Harvey A. Silverglate ṣe iṣiro pe eniyan ti o wọpọ, ni apapọ, laimọmọ ṣe awọn odaran mẹta lojoojumọ ni AMẸRIKA.

6. Emilio Mordini, onimọ-jinlẹ ati onimọran nipa imọ-ọrọ, jiyan pe ariyanjiyan “ko si nkan lati fi pamọ” jẹ eyiti o jẹ atako ti ẹda. Awọn eniyan ko nilo lati ni “nkankan lati tọju” lati le fi “nkankan” pamọ. Ohun ti o farapamọ ko jẹ dandan ti o yẹ, Mordini sọ. Dipo, o jiyan agbegbe timotimo eyiti o le farapamọ ati ihamọ-wiwọle jẹ pataki nitori, ni sisọrọ nipa ti imọ-ọrọ, a di ẹni-kọọkan nipasẹ iwari pe a le fi nkan pamọ si awọn miiran.

7. Julian Assange ṣalaye "Ko si idahun apaniyan sibẹsibẹ. Jacob Appelbaum (@ioerror) ni idahun ọlọgbọn, o beere lọwọ awọn eniyan ti o sọ eyi ki wọn fun foonu rẹ ṣiṣi silẹ ki o fa sokoto wọn silẹ. Ẹya mi ti iyẹn ni lati sọ, 'daradara, ti o ba jẹ alaidun nigbana ko yẹ ki a ba ọ sọrọ, ati pe ko yẹ ki ẹnikẹni miiran', ṣugbọn ni ọgbọn-ọgbọn, idahun gidi ni eyi: Ikiyesi ibi-pupọ jẹ iyipada eto igbepọ. Nigba ti awujọ ba buru, o n lọ lati mu ọ pẹlu rẹ, paapaa ti o ba jẹ eniyan abuku julọ ni agbaye. "

8. Ignacio Cofone, olukọ ofin, jiyan pe ariyanjiyan jiyan ni awọn ọrọ tirẹ nitori, nigbakugba ti eniyan ba ṣafihan alaye ti o yẹ fun awọn miiran, wọn tun ṣafihan alaye ti ko ṣe pataki. Alaye ti ko ṣe pataki yii ni awọn idiyele aṣiri ati o le ja si awọn ipalara miiran, bii iyasoto.

***

# Awọn ọna miiran

Media ko yẹ ki o ni ihamọ, lori ayelujara tabi aisinipo. Ti awọn eniyan ba fẹ lati wo fidio laisi DRM, wọn yoo wa ọna nigbagbogbo lati ṣe. Gbogbo nkan ti sọfitiwia le ti fọ.

[iyasọtọ ti a tunṣe lati Wikipedia] Alakoso Valve Gabe Newell ti ṣalaye “ọpọlọpọ awọn ọgbọn DRM jẹ odi” nitori wọn dinku iye ere kan ni oju awọn onibara. Newell ni imọran pe ibi-afẹde yẹ ki o dipo jẹ “[ṣiṣẹda] iye ti o tobi julọ fun awọn alabara nipasẹ iye iṣẹ”. Akiyesi pe Valve n ṣiṣẹ Nya, iṣẹ kan ti o ṣe iṣẹ bi itaja ori ayelujara fun awọn ere PC, bii iṣẹ nẹtiwọọki awujọ kan ati pẹpẹ DRM

Aaye yii ko wulo fun awọn ere fidio, o le lo si ohunkohun lori kọmputa kan. Kọmputa rẹ ko yẹ ki o wa ni iṣakoso pipe ti ile aṣiwere kan ti o lo Imọye Artificial buburu lati paarẹ awọn olumulo rẹ ati iṣẹ wọn (YouTube, ati bẹbẹ lọ) ati pe o ni iru igbasilẹ buburu bẹ. Kọmputa rẹ ko yẹ ki o ni ihamọ nitori ile-iṣẹ kọ lati pin bi ọmọ ti o hu ihuwasi. Kọmputa rẹ yẹ ki o jẹ ohun-ini nipasẹ iwọ,ko si si ẹlomiran. O yẹ ki o yọkuro DRM lapapọ, bi akoonu ko tọ si fifun iṣakoso kọmputa rẹ fun. Awọn ile-iṣẹ wọnyi ni awọn ọgọọgọrun ọkẹ àìmọye dọla. Ti wọn ba ṣe nkan aṣiwere bii eleyi, o yẹ ki o fi ehonu han. O le paapaa gba fidio naa ni ibomiiran ki o wo o, nitori wọn yẹ ki o padanu owo fun ṣiṣe awọn ohun aṣiwere bii eleyi. Ofin aṣẹ-aṣẹ kii ṣe nkan buruju. Awọn eniyan ti ko le irewesi awọn fiimu yoo ṣe igbasilẹ wọn ni ibomiiran, o ti n ṣẹlẹ lati ibẹrẹ Intanẹẹti kariaye ati pẹlu ipilẹṣẹ teepu VHS. Ko ni ipa lori owo-wiwọle wọn, nitori wọn kii yoo ni anfani lati gba owo yẹn bakanna. DRM jẹ alebu nipa apẹrẹ.

***

## Kini o le ṣe lati ṣe iranlọwọ

O le fi ehonu han DRM. O le dabi ẹni ti ko ṣe pataki, ṣugbọn diẹ eniyan ti o lọ lodi si rẹ, diẹ sii ni a nṣe nipa rẹ.

Ti o ba wa lori Linux ati lilo Firefox, rii daju pe a ko fi DRM sii (kii ṣe deede o jẹ aiyipada) ati maṣe yọ ara rẹ lẹnu lati fi sii.

Ti o ba wa lori Windows tabi MacOS, o le ni akoko ti o nira pupọ, bi a ti fi DRM sii nipasẹ aiyipada lori awọn eto wọnyi, ati pe o le tun-fi sori ẹrọ laifọwọyi.

Gbiyanju lati yago fun awọn aaye wọnyi:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Pataki +] (https://www.paramountplus.com/)

Ni ipilẹ, o fẹrẹ to eyikeyi iṣẹ sisanwọle fidio ori ayelujara yẹ ki o yee, bi ọpọlọpọ ninu wọn lo DRM ati pe o ko le lo aaye naa laisi padanu ominira rẹ. Ko tọsi. Firanṣẹ [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) ifiranṣẹ kan ki o da ṣiṣan awọn ifihan wọnyi duro.

O yẹ ki o tun yago fun eyikeyi awọn aṣayan “ọfẹ pẹlu awọn ipolowo” lori awọn aaye wọnyi (nitori ọna yii nilo DRM)

[YouTube] (https://www.youtube.com)

O tun le ṣe ikede DRM pẹlu ifiranṣẹ kan lori faili awọn iṣẹ rẹ “README.md`. Eyi ni ohun ti Mo lo:

“ṣiṣamisi

***

## Ipo sọfitiwia

Gbogbo awọn iṣẹ mi ni ominira diẹ ninu awọn ihamọ. DRM (** D ** igital ** R ** estrictions ** M ** anagement) ko si ni eyikeyi awọn iṣẹ mi.

! [DRM-ọfẹ_label.en.svg] (DRM-free_label.en.svg)

Sitika yii ni atilẹyin nipasẹ Foundation Software ọfẹ. Emi ko pinnu lati fi DRM sinu awọn iṣẹ mi.

Mo n lo abbreviation "Iṣakoso Awọn ihamọ Awọn ihamọ Digital" dipo ti o mọ diẹ sii "Iṣakoso Awọn ẹtọ Onitẹsiwaju" bi ọna ti o wọpọ ti n ba sọrọ jẹ eke, ko si awọn ẹtọ pẹlu DRM. Akọtọ ọrọ “Iṣakoso Awọn ihamọ Awọn ihamọ Digital” jẹ deede julọ, ati pe o ni atilẹyin nipasẹ [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) ati [Foundation Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

A lo apakan yii lati gbe imoye fun awọn iṣoro pẹlu DRM, ati lati ṣe ikede rẹ. DRM jẹ alebu nipa apẹrẹ ati pe o jẹ irokeke nla si gbogbo awọn olumulo kọmputa ati ominira sọfitiwia.

Kirẹditi aworan: [defectivebydesign.org/drm-free/...] (//https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

“

***
## Awọn ohun miiran lati ṣayẹwo

[Pipe nipa apẹrẹ - Ipolongo kan nipasẹ Foundation Free Software ti o n ṣiṣẹ lori ṣiṣafihan ati yiyọ lilo DRM] (https://www.defectivebydesign.org/)

[Ibojì Google (kashebygoogle.com) - atokọ lẹsẹsẹ ti awọn ọja 224 + ti Google ti pa] (https://killedbygoogle.com/)

> [Ọna asopọ GitHub] (https://github.com/codyogden/killedbygoogle)

[Iṣọkan oṣiṣẹ abidi - Ẹgbẹ alabaṣiṣẹpọ tuntun ni Google pẹlu awọn ọmọ ẹgbẹ ti o ju 800] (https://alphabetworkersunion.org/people/our-union/)

Awọn omiiran miiran wa, kan wa fun wọn.

***

## Alaye ti Nkan

Iru faili: “Markdown (* .md)”

Ẹya faili: “4 (Ọjọ Jimọ, Ọjọ Kẹrin ọjọ 23rd 2021 ni 3:35 irọlẹ)“

Nọmba laini (pẹlu awọn laini òfo ati laini akopọ): “354`

### Ipo sọfitiwia

Gbogbo awọn iṣẹ mi ni ominira lati awọn ihamọ. DRM (** D ** igital ** R ** estrictions ** M ** anagement) ko si ni eyikeyi awọn iṣẹ mi. Iṣẹ yii ko ni eyikeyi DRM, ṣugbọn o n sọrọ nipa DRM taara.

! [DRM-ọfẹ_label.en.svg] (DRM-free_label.en.svg)

Sitika yii ni atilẹyin nipasẹ Foundation Software ọfẹ. Emi ko pinnu lati fi DRM sinu awọn iṣẹ mi.

***

### Alaye Onigbowo

! [SponsorButton.png] (SponsorButton.png) <- Eyi kii ṣe bọtini onigbọwọ osise, o jẹ aworan demo kan. Maṣe tẹ ẹ ti o ba fẹ ṣe onigbọwọ iṣẹ yii.

O le ṣe onigbọwọ iṣẹ yii ti o ba fẹ, ṣugbọn jọwọ ṣafihan ohun ti o fẹ lati ṣetọrẹ si. [Wo awọn owo ti o le ṣetọrẹ si ibi] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

O le wo alaye onigbowo miiran [nibi] (https://github.com/seanpm2001/Sponsor-info/)

Gbiyanju o jade! Bọtini onigbọwọ wa ni titọ lẹgbẹẹ bọtini iṣọ / ṣiṣi.

***

## Itan faili

Ẹya 1 (Ọjọ Sundee, Kínní 8th 2021 ni 4: 41 pm)

> Awọn ayipada:

> * Bibẹrẹ faili / nkan

> * Ṣafikun apakan akọle

> * Ṣafikun apakan kan nipa aṣiri

> * Ṣafikun apakan kan nipa iwoye naa

> * Ṣafikun apakan alaye nkan

> * Ti ṣe afihan aami Ọfẹ DRM

> * Fikun apakan apakan itan faili

> * Ṣafikun apakan Aini ominira

> * Ṣafikun apakan Anti-ifigagbaga

> * Ṣafikun apakan awọn ọna yiyan

> * Fi akọsilẹ kunapakan lilo ry

> * Ṣafikun awọn ohun miiran lati ṣayẹwo apakan

> * Ṣafikun atọka naa

> * Ṣafikun ẹlẹsẹ

> * Ko si awọn ayipada miiran ninu ẹya 1

Ẹya 2 (Ọjọbọ, Ọjọ Kẹrin 8th 2021 ni 5:18 pm)

> Awọn ayipada:

> * Imudojuiwọn apakan akọle

> * Imudojuiwọn atọka naa

> * Afikun alaye lori ohun ti o le ṣe lati ṣe iranlọwọ

> * Ṣafikun apakan alaye onigbowo

> * Ṣe imudojuiwọn apakan alaye faili naa

> * Ṣe imudojuiwọn apakan itan itan faili

> * Ko si awọn ayipada miiran ninu ẹya 2

Ẹya 3 (Ọjọbọ, Ọjọ Kẹrin 8th 2021 ni 5: 27 pm)

> Awọn ayipada:

> * Awọn ọna asopọ itumọ ti o wa titi

> * Imudojuiwọn atọka naa

> * Ti o wa titi ẹda kan, kuro ni titẹsi akọle ni “kini o le ṣe lati ṣe iranlọwọ“ apakan

> * Ṣe imudojuiwọn apakan alaye onigbowo

> * Ṣe imudojuiwọn apakan alaye faili naa

> * Ṣe imudojuiwọn apakan itan itan faili

> * Ko si awọn ayipada miiran ninu ẹya 3

Ẹya 4 (Ọjọ Jimọ, Oṣu Kẹrin Ọjọ 23rd 2021 ni 3: 35pm)

> Awọn ayipada:

> * Ṣe imudojuiwọn akojọ switcher ede

> * Ṣe imudojuiwọn apakan alaye faili naa

> * Ṣe imudojuiwọn apakan itan itan faili

> * Ko si awọn ayipada miiran ninu ẹya 4

Ẹya 5 (Wiwa laipe)

> Awọn ayipada:

> * Wiwa laipẹ

> * Ko si awọn ayipada miiran ninu ẹya 5

Ẹya 6 (Wiwa laipe)

> Awọn ayipada:

> * Wiwa laipẹ

> * Ko si awọn ayipada miiran ninu ẹya 6

Ẹya 7 (Wiwa laipe)

> Awọn ayipada:

> * Wiwa laipẹ

> * Ko si awọn ayipada miiran ninu ẹya 7

Ẹya 8 (Wiwa laipe)

> Awọn ayipada:

> * Wiwa laipẹ

> * Ko si awọn ayipada miiran ninu ẹya 8

***

## Ẹsẹ

O ti de opin faili yii!

##### EOF

***
