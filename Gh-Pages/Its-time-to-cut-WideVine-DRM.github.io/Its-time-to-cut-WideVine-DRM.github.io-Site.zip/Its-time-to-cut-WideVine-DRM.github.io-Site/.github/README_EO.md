***

##### Supro

_Legu ĉi tiun artikolon en alia lingvo: _

** Nuna lingvo estas: ** `Angla (Usono)` _ (tradukoj eble devas esti korektitaj por ripari la anglan anstataŭigante la ĝustan lingvon) _

_🌐 Listo de lingvoj_

** Ordigita laŭ: ** `A-Z`

[Ordigaj opcioj neatingeblaj] (https://github.com/Degoogle-your-Life)

([af Afrikansa] (/. github / README_AF.md) Afrikansa | [sq Shqiptare] (/. github / README_SQ.md) Albana | [am አማርኛ] (/. github / README_AM.md) Amhara | [ar عربى] (/.github/README_AR.md) Araba | [hy հայերեն] (/. github / README_HY.md) Armena | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbajĝana | [eu Euskara] (/. github /README_EU.md) Eŭska | [estu Беларуская] (/. Github / README_BE.md) Belorusa | [bn বাংলা] (/. Github / README_BN.md) Bengala | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) Bulgarian | [ca Català] (/. Github / README_CA.md) Kataluna | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Ĉina (Simpligita) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Ĉina (Tradicia) | [co Corsu] (/. Github / README_CO.md) Korsika | [hr Hrvatski] (/. Github / README_HR.md) Kroata | [cs čeština] (/. Github / README_CS .md) ĉe Czecha | [da dansk] (README_DA.md) dana | [nl Nederlands] (/. github / README_ NL.md) nederlanda | [** en-us English **] (/. github / README.md) English | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) estona | [tl Pilipino] (/. github / README_TL.md) Filipina | [fi Suomalainen] (/. github / README_FI.md) Finna | [fr français] (/. github / README_FR.md) franca | [fy Frysk] (/. github / README_FY.md) Frisa | [gl Galego] (/. github / README_GL.md) Galician | [ka ქართველი] (/. github / README_KA) kartvela | [de Deutsch] (/. github / README_DE.md) germana | [el Ελληνικά] (/. github / README_EL.md) Greka | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) havaja | [li Hebreo] (/. github / README_HE.md) Hebrea | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) hungara | [estas Íslenska] (/. github / README_IS.md) Islanda | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonezio] (/. github / README_ID.md) islanda | [ga Gaeilge] (/. github / README_GA.md) irlanda | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) japana | [jw Wong jawa] (/. github / README_JW.md) java | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) mermeroj | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Korea (Suda) | [ko-norda 문화어] (README_KO_NORTH.md) Korea (norda) (NE TRADUTA) | [ku Kurdî] (/. github / README_KU.md) Kurda (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgizo | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latina | [lt Lietuvis] (/. github / README_LT.md) Litova | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksemburgia | [mk Македонски] (/. github / README_MK.md) Makedona | [mg madagaskarano] (/. github / README_MG.md) madagaskarano | [ms Bahasa Melayu] (/. github / README_MS.md) Malaja | [ml മലയാളം] (/. github / README_ML.md) Malajala | [mt Malti] (/. github / README_MT.md) Maltese | [mi maora] (/. github / README_MI.md) maora | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) mongola | [mia မြန်မာ] (/. github / README_MY.md) Mjanmao (birmano) | [ne नेपाली] (/. github / README_NE.md) Nepali | [neniu norsk] (/. github / README_NO.md) norvega | [aŭ ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Paŝto | [fa فارسی] (/. github / README_FA.md) | Persa [pl polski] (/. github / README_PL.md) Pola | [pt português] (/. github / README_PT.md) Portugala | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Panĝaba | Neniuj lingvoj disponeblaj, kiuj komenciĝas per la litero Q | [ro Română] (/. github / README_RO.md) Rumana | [ru русский] (/. github / README_RU.md) rusa | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) skota gaela | [sr Српски] (/. github / README_SR.md) Serba | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovaka | [sl Slovenščina] (/. github / README_SL.md) Slovena | [do Soomaali] (/. github / README_SO.md) Somalo | [[es en español] (/. github / README_ES.md) Hispana | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kisŭahili] (/. github / README_SW.md) Svahila | [sv Svenska] (/. github / README_SV.md) sveda | [tg Тоҷикӣ] (/. github / README_TG.md) Taĝika | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) tataro | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) taja | [tr Türk] (/. github /README_TR.md) Turka | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) ukraina | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vjetnama | [cy Cymraeg] (/. github / README_CY.md) kimra | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jida | [yo Jorubo] (/. github / README_YO.md) Jorubo | [zu Zulu] (/. github / README_ZU.md) Zulu) Havebla en 110 lingvoj (108 se oni ne kalkulas la anglan kaj nordkorean, ĉar nordkorea ankoraŭ ne estis tradukita [Legu pri ĝi ĉi tie] (/ OldVersions / Korea (Norda ) /README.md))

Tradukoj en aliaj lingvoj krom la angla estas aŭtomate tradukitaj kaj ankoraŭ ne estas ĝustaj. Ankoraŭ neniuj eraroj estis riparitaj ekde la 5a de februaro 2021. Bonvolu raporti tradukajn erarojn [ĉi tie] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) certigu rezervi vian korekton per fontoj kaj gvidu min, ĉar mi ne bone scias aliajn lingvojn krom la angla (mi planas akiri tradukiston eventuale) bonvolu citi [vikivortaron] (https://eo.wiktionary.org) kaj aliajn fontojn en via raporto. Malsukceso fari tion rezultigos malakcepton de la korekto publikigita.

Noto: pro limigoj kun la interpreto de GitHub pri markdown (kaj preskaŭ ĉiu alia interreta interpreto de markdown) alklakante ĉi tiujn ligojn redirektos vin al aparta dosiero sur aparta paĝo kiu ne estas mia GitHub-profilpaĝo. Vi estos redirektita al la [seanpm2001 / seanpm2001-deponejo] (https://github.com/seanpm2001/seanpm2001), kie la README estas gastigita.

Tradukoj estas faritaj per Google Translate pro limigita aŭ neniu subteno por la lingvoj, kiujn mi bezonas en aliaj tradukaj servoj kiel DeepL kaj Bing Translate (sufiĉe ironia por kontraŭ-Google-kampanjo). Mi laboras por trovi alternativon. Ial, la formatado (ligoj, dividiloj, grasaj, kursivaj, ktp) estas fuŝita en diversaj tradukoj. Estas tede ripari, kaj mi ne scias kiel solvi ĉi tiujn problemojn en lingvoj kun nelatinaj signoj, kaj dekstre al maldekstraj lingvoj (kiel la araba) kroma helpo necesas por solvi ĉi tiujn problemojn.

Pro prizorgaj problemoj, multaj tradukoj malaktualas kaj uzas malnoviĝintan version de ĉi tiu artikoldosiero 'README'. Tradukisto bezonas. Ankaŭ ekde la 23-a de aprilo 2021 mi bezonos iom da tempo por funkciigi ĉiujn novajn ligojn.

***

# Estas tempo tranĉi Larĝvinon

Jen artikolo pri kial vi devas ĉesi uzi Google WideVine (DRM) kaj malinstali ĝin. DRM devas esti forigita. Ĉi tiu artikolo helpos vin elekti (se vi ne jam faris) WideVine estas tre kontraŭkonkurenca kaj ekstreme restrikta, kaj detruas la liberecon de filmetoj en la interreto.

Ni tranĉu la WideVine kaj ampleksu malferman Interreton.

***

# Indekso

[00.0 - Supra] (# Supra)

> [00.1 - Legu ĉi tiun artikolon en alia lingvo]

> [00.2 - Titolo] (# It-is-time-to-cut-Widevine)

> [00.3 - Indekso] (# Indekso)

[01.0 - Superrigardo] (# Superrigardo)

[02.0 - Kontraŭkonkurenca] (# Kontraŭkonkurenca)

[03.0 - Manko de libereco] (# Manko-de-libereco)

[04.0 - Memoro-uzado] (# Memoro-uzado)

[05.0 - Privateco] (# Privateco)

[06.0 - Alternativaj metodoj] (# Alternaj-metodoj)

[07.0 - Kion vi povas helpi] (# Kio-vi-povas-fari-por-helpi)

[08.0 - Aliaj kontrolendaj aferoj] (# Other-check-out)

[09.0 - Artikola informo] (# Artikola-informo)

> [09.0.1 - Programara stato] (# Programara-stato)

> [09.0.2 - Sponsoraj informoj] (# Sponsor-info)

[10.0 - Dosiera historio] (# Dosiera historio)

[11.0 - Piedo] (# Piedo)

> [11.9 - EOF] (# EOF)

***

## Superrigardo

Por aliaj informoj pri kial DRM estas problemo, [alklaku ĉi tie] (https://www.defectivebydesign.org/)

***

## Kontraŭkonkurenca

WideVine estas DRM, kiu devas esti rajtigita por esti uzata per retumilo. Google treege malrapidas revizii kaj akcepti homojn, kaj ofte rifuzas homojn uzi ĝin en siaj produktoj sen rezonado. [Fonto 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Fonto 2 (la retpoŝta fadeno, kiu daŭris pli ol 4 monatojn kaj rezultigis nur seniluziiĝon)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google multe pli malfaciligis al retumiloj kiel Brave aŭ Firefox konkurenci kun sia antaŭenpuŝo de ĉi tiu DRM-peco.

***

## Manko de libereco

WideVine estas uzata por malebligi uzantojn interagi kun filmetoj en retejoj. Ĝi estas formo de mastrumado de ciferecaj limigoj, kiu malebligas vin elŝuti la filmeton, vidi la filmeton eksterrete aŭ eĉ ekrankopii. Ĝi estas proprieta programaro kaj pro siaj problemoj kun privateco, ĝi ne estas instalita defaŭlte ĉe plej multaj Linuksaj distribuoj. Ĝi limigas la liberecojn de la retejo pro ĝia uzo de Netflix, Disney kaj YouTube-filmoj. Via aliro al la enhavo povas esti forigita iam ajn sen kialo.

***

## Memora uzado

WideVine malbone memoras. Kompare kun nur kutime vidi filmeton sen DRM, WideVine uzos pezajn kvantojn de CPU kaj RAM. Estas malbone pri bamulta vivo, kaj ĝi donas neniujn avantaĝojn de norma HTML5-videoludado.

***

## Privateco

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-google-has-on-you-privacy - [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritiko) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nenio-por-kaŝi-argumenton-havas-nenion-diri /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- datumoj-pri-vi-povas-trovi-kaj-forigi-ĝin-nun /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -kaj) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o[(https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- asertoj-je-nomo-de-5-milionoj-iphone-uzantoj) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-ne-uzu /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technolo gy / 2014/01 / what-google-can-really-do-with-nest-or-really-nest-data /) [i] (https://www.cbsnews.com/news/google-education-spies -on-kolektas-datumojn-pri-milionoj-da-infanoj-akuzoj-proceso-nova-meksika-ĝenerala-prokuroro /) [v] (https://www.nationalreview.com/2018/04/the-student- datumminada skandalo sub niaj nazoj /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y)(https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Mi povus daŭrigi kun pruvoj pri tio , sed necesis longa tempo por trovi kaj trarigardi ĉiujn ĉi tiujn artikolojn)

Privateco ne estas afero kun WideVine. Propra programaro estas desegnita tiel, ke vi tute ne povas vidi, kio okazas. Kun Googles-historio, tre verŝajne tio estasWideVine estas aldona programaro, kiu spionas vin, legas viajn dokumentojn kaj aliajn malbonajn aferojn.

Se vi pensas, ke vi havas nenion por kaŝi, ** vi absolute malpravas **. Ĉi tiu argumento estis malkaŝita multajn fojojn:

[Per Vikipedio] (https://eo.wikipedia.org/wiki/Nenio_por_kaŝi_argumenton # Kritiko)

1. Edward Snowden rimarkis "Argumenti, ke vi ne zorgas pri la rajto al privateco ĉar vi havas nenion por kaŝi, ne diferencas ol diri, ke vi ne zorgas pri libera sinesprimo ĉar vi havas nenion por diri." Kiam vi diras, ' Mi havas nenion por kaŝi, 'vi diras,' mi ne zorgas pri ĉi tiu rajto. 'Vi diras,' Mi ne havas ĉi tiun rajton, ĉar mi alvenis al la punkto, kiam mi devas pravigi. ĝi. 'La rajtoj funkcias, la registaro devas pravigi sian entrudiĝon en viajn rajtojn. "

2. Daniel J. Solove diris en artikolo por La Kroniko de Supera Edukado, ke li kontraŭas la argumenton; li deklaris, ke registaro povas liki informojn pri persono kaj kaŭzi damaĝon al tiu persono, aŭ uzi informojn pri persono por nei aliron al servoj eĉ se persono ne efektive agis malĝuste, kaj ke registaro povas kaŭzi damaĝon al sia persona vivo per farado de eraroj. Solove skribis "Kiam ĝi okupiĝas rekte, la nenio kaŝebla argumento povas kapti, ĉar ĝi devigas la debaton fokusiĝi al sia mallarĝa kompreno pri privateco. Sed kiam ĝi alfrontas la plurecon de privatecaj problemoj implikitaj de registara datumkolekto kaj uzo preter kontrolado kaj malkaŝo, la nenion kaŝebla argumento, finfine, havas nenion por diri. "

3. Adam D. Moore, aŭtoro de Privataj Rajtoj: Moralaj kaj Juraj Fundamentoj, argumentis, "ĝi opinias, ke rajtoj estas rezistaj al kosto / avantaĝo aŭ konsekvencaj argumentoj. Ĉi tie ni malakceptas la opinion, ke privatecaj interesoj estas tiaj. de aferoj interŝanĝeblaj por sekureco. " Li ankaŭ deklaris, ke gvatado povas misproporcie influi iujn grupojn en la socio laŭ aspekto, etneco, sekseco kaj religio.

4. Bruce Schneier, komputila sekureca spertulo kaj kriptografisto, esprimis opozicion, citante la deklaron de kardinalo Richelieu "Se oni donus al mi ses liniojn skribitajn per la mano de la plej honesta viro, mi trovus ion en ili por pendigi lin", aludante al kiel ŝtata registaro povas trovi aspektojn en la vivo de homo por procesigi aŭ ĉantaĝi tiun individuon. Schneier ankaŭ argumentis "Tro multaj erare karakterizas la debaton kiel" sekureco kontraŭ privateco. " La vera elekto estas libereco kontraŭ rego. "

5. Harvey A. Silverglate taksis, ke la ordinara homo averaĝe senscie faras tri krimojn tage en Usono.

6. Emilio Mordini, filozofo kaj psikanalizisto, argumentis, ke la argumento pri "nenio kaŝebla" estas esence paradoksa. Homoj ne bezonas havi "ion por kaŝi" por kaŝi "ion". Kio estas kaŝita ne nepre gravas, asertas Mordini. Anstataŭe li argumentas ke intima areo, kiu povas esti kaŝita kaj alirebla, estas necesa, ĉar psikologie parolante ni fariĝas individuoj per la malkovro, ke ni povus kaŝi ion al aliaj.

7. Julian Assange deklaris "Ankoraŭ ne ekzistas mortiga respondo. Jacob Appelbaum (@ioerror) havas lertan respondon, petante homojn, kiuj diras ĉi tion, ke ili transdonu al li sian telefonon malŝlositan kaj mallevu sian pantalonon. Mia versio de tio estas diri, 'nu, se vi estas tiel enua, ni ne parolu kun vi, kaj ankaŭ neniu alia', sed filozofie, la vera respondo estas jena: Amasa gvatado estas amasa struktura ŝanĝo. Kiam la socio malbonas, ĝi iras. kunporti vin, eĉ se vi estas la plej banala homo sur la tero. "

8. Ignacio Cofone, jura profesoro, argumentas, ke la argumento eraras laŭ siaj propraj terminoj, ĉar, kiam homoj malkaŝas koncernajn informojn al aliaj, ili ankaŭ malkaŝas senrilatajn informojn. Ĉi tiuj senrilataj informoj havas privatajn kostojn kaj povas kaŭzi aliajn damaĝojn, kiel diskriminacio.

***

# Alternativaj metodoj

Amaskomunikiloj ne estu limigitaj, interrete aŭ eksterrete. Se homoj volus spekti la filmeton sen DRM, ili ĉiam trovos manieron fari ĝin. Ĉiu softvaro povas esti fendita.

[modifita ekstrakto de Vikipedio] La prezidanto de Valve, Gabe Newell, diris, ke "plej multaj DRM-strategioj estas nur mutaj", ĉar ili nur malpliigas la valoron de ludo en la okuloj de la konsumanto. Newell sugestas, ke la celo anstataŭe estu "[krei] pli grandan valoron por klientoj per serva valoro". Notu, ke Valve funkciigas Steam, servon, kiu funkcias kiel interreta butiko por komputilaj ludoj, same kiel socia interkonekta servo kaj DRM-platformo.

Ĉi tiu punkto ne validas nur por videoludoj, ĝi aplikeblas al io ajn en komputilo. Via komputilo ne devas regi komplete frenezan kompanion, kiu uzas malbonan Artefaritan Inteligentecon por forigi siajn uzantojn kaj iliajn laborojn (YouTube, ktp) kaj havas tiel malbonan rekordon. Via komputilo ne estu limigita ĉar kompanio rifuzas dividi kiel malbonkonduta infano. Via komputilo estu via posedanto,kaj neniu alia. Vi devas tute forigi DRM, ĉar la enhavo ne indas rezigni pri regado de via komputilo. Ĉi tiuj kompanioj havas centojn da miliardoj da dolaroj. Se ili faras ion stultan tiel, vi devas protesti kontraŭ ĝi. Vi povus eĉ simple elŝuti la filmeton aliloke kaj vidi ĝin, ĉar ili perdus monon pro stultaj aferoj kiel ĉi tio. Kopirajta malobservo ne estas malbona afero. Homoj, kiuj ne povas pagi filmojn, elŝutos ilin aliloke, tio okazis ekde la komenco de la tutmonda interreto kaj kun la invento de la VHS-bendo. Ĝi apenaŭ influas iliajn enspezojn, ĉar ili tamen ne povus akiri tiun monon. DRM estas misa laŭ projektado.

***

## Kion vi povas helpi

Vi povas protesti kontraŭ DRM. Ĝi povas ŝajni sensignifa, sed ju pli multaj homoj kontraŭas ĝin, des pli multe oni faras pri ĝi.

Se vi estas en Linukso kaj uzas Fajrovulpon, certigu, ke DRM ne estas instalita (ĝi kutime ne estas defaŭlte) kaj ne ĝenu instali ĝin.

Se vi estas en Vindozo aŭ MacOS, eble vi havos multe pli malfacilan tempon, ĉar DRM estas instalita defaŭlte en ĉi tiuj sistemoj kaj povas aŭtomate reinstali.

Provu eviti la jenajn retejojn:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Plej grava +] (https://www.paramountplus.com/)

Esence oni devas eviti preskaŭ ĉian interretan filman servon, ĉar la plimulto el ili uzas DRM kaj vi ne povas uzi la retejon sen perdi vian liberecon. Ĝi ne indas. Sendu mesaĝon al la [MPAA] (https://eo.wikipedia.org/wiki/Motion_Picture_Association) kaj ĉesu elsendi ĉi tiujn spektaklojn.

Vi ankaŭ evitu iujn "senpagajn reklamojn" en la sekvaj retejoj (ĉar ĉi tiu metodo bezonas DRM)

[YouTube] (https://www.youtube.com)

Vi ankaŭ povas protesti kontraŭ DRM per mesaĝo en via dosiera projekto `README.md`. Jen kion mi uzas:

"markado

***

## Programara stato

Ĉiuj miaj verkoj estas senpagaj iuj limigoj. DRM (** D ** igital ** R ** limigoj ** M ** administrado) ne ĉeestas en miaj verkoj.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ĉi tiu glumarko estas subtenata de la Free Software Foundation. Mi neniam intencas inkluzivi DRM en miaj verkoj.

Mi uzas la mallongigon "Administrado de Ciferecaj Limigoj" anstataŭ la pli konata "Administrado de Ciferecaj Rajtoj", ĉar la komuna maniero trakti ĝin estas falsa, ne ekzistas rajtoj kun DRM. La literumo "Administrado de Ciferecaj Limigoj" estas pli preciza, kaj estas subtenata de [Richard M. Stallman (RMS)] (https://eo.wikipedia.org/wiki/Richard_Stallman) kaj la [Libera Programaro-Fundamento (FSF)] ( https://eo.wikipedia.org/wiki/Free_Software_Foundation)

Ĉi tiu sekcio estas uzata por konsciigi la problemojn kun DRM, kaj ankaŭ por protesti kontraŭ ĝi. DRM estas misa pro projektado kaj estas grava minaco por ĉiuj komputilaj uzantoj kaj libereco de programaro.

Bildo kredito: [defectivebydesign.org/drm-free/...)(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

""

***
## Aliaj aĵoj por kontroli

[Difektita laŭ projektado - Kampanjo de la Libera Programaro-Fondaĵo, kiu laboras pri malkaŝado kaj forigo de DRM-uzado] (https://www.defectivebydesign.org/)

[La Google-Tombejo (killedbygoogle.com) - ordigita listo de la 224+ produktoj, kiujn Google mortigis] (https://killedbygoogle.com/)

> [GitHub-ligo] (https://github.com/codyogden/killedbygoogle)

[Alfabeta sindikato - La nova laborista sindikato ĉe Google kun pli ol 800 membroj] (https://alphabetworkersunion.org/people/our-union/)

Estas aliaj anstataŭantoj, nur serĉu ilin.

***

## Artikola informo

Dosiera tipo: `Markdown (* .md)`

Dosiera versio: `4 (vendrede, la 23-an de aprilo 2021 je la 15:35)`

Linio-kalkulo (inkluzive malplenajn liniojn kaj kompililan linion): `354`

### Programara stato

Ĉiuj miaj verkoj estas liberaj de limigoj. DRM (** D ** igital ** R ** limigoj ** M ** administrado) ne ĉeestas en miaj verkoj. Ĉi tiu projekto ne enhavas DRM, sed ĝi parolas pri DRM rekte.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ĉi tiu glumarko estas subtenata de la Free Software Foundation. Mi neniam intencas inkluzivi DRM en miaj verkoj.

***

### Sponsoraj informoj

! [SponsorButton.png] (SponsorButton.png) <- Ĉi tio ne estas la oficiala sponsora butono, ĝi estas elmontrila bildo. Ne alklaku ĝin se vi volas sponsori ĉi tiun projekton.

Vi povas sponsori ĉi tiun projekton se vi volas, sed bonvolu specifi al kio vi volas donaci. [Vidu la financojn al kiuj vi povas donaci ĉi tie] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Vi povas vidi aliajn sponsorajn informojn [ĉi tie] (https://github.com/seanpm2001/Sponsor-info/)

Provu ĝin! La butono de sponsoro estas tuj apud la butono de horloĝo / malrigardo.

***

## Dosierhistorio

Versio 1 (dimanĉo, la 8a de februaro 2021 je la 16:41)

> Ŝanĝoj:

> * Komencis la dosieron / artikolon

> * Aldonis la titolan sekcion

> * Aldonis sekcion pri privateco

> * Aldonis sekcion pri la superrigardo

> * Aldonis la artikolan informsekcion

> * Referencis la ikonon DRM Free

> * Aldonis la sekcion pri dosierhistorio

> * Aldonis la sekcion Manko de libereco

> * Aldonis la Kontraŭkonkurencan sekcion

> * Aldonis la sekcion pri alternativaj metodoj

> * Aldonis la notonry uzada sekcio

> * Aldonis la aliajn aferojn por kontroli sekcion

> * Aldonis la indekson

> * Aldonis la piedlinion

> * Neniuj aliaj ŝanĝoj en versio 1

Versio 2 (ĵaŭde la 8-an de aprilo 2021 je la 17:18)

> Ŝanĝoj:

> * Ĝisdatigis la titolan sekcion

> * Ĝisdatigis la indekson

> * Aldonis informojn pri tio, kion vi povas helpi

> * Aldonis la informan sekcion pri sponsoro

> * Ĝisdatigis la sekcion pri dosieraj informoj

> * Ĝisdatigis la sekcion pri dosierhistorio

> * Neniuj aliaj ŝanĝoj en versio 2

Versio 3 (ĵaŭde la 8-an de aprilo 2021 je la 17:27)

> Ŝanĝoj:

> * Fiksitaj tradukaj ligoj

> * Ĝisdatigis la indekson

> * Korektis kopion, ekster teman eniron en la sekcio "Kion vi povas helpi"

> * Ĝisdatigis la informan sekcion pri sponsoro

> * Ĝisdatigis la sekcion pri dosieraj informoj

> * Ĝisdatigis la sekcion pri dosierhistorio

> * Neniuj aliaj ŝanĝoj en versio 3

Versio 4 (vendrede la 23an de aprilo 2021 je la 15:35)

> Ŝanĝoj:

> * Ĝisdatigis la lingvan ŝaltilan liston

> * Ĝisdatigis la sekcion pri dosieraj informoj

> * Ĝisdatigis la sekcion pri dosierhistorio

> * Neniuj aliaj ŝanĝoj en versio 4

Versio 5 (Baldaŭ)

> Ŝanĝoj:

> * Baldaŭ

> * Neniu alia ŝanĝo en versio 5

Versio 6 (Baldaŭ)

> Ŝanĝoj:

> * Baldaŭ

> * Neniuj aliaj ŝanĝoj en versio 6

Versio 7 (Baldaŭ)

> Ŝanĝoj:

> * Baldaŭ

> * Neniuj aliaj ŝanĝoj en versio 7

Versio 8 (Baldaŭ)

> Ŝanĝoj:

> * Baldaŭ

> * Neniuj aliaj ŝanĝoj en versio 8

***

## Piedo

Vi atingis la finon de ĉi tiu dosiero!

##### EOF

***
