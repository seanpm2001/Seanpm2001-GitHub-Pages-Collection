***

##### Sus

_Citiți acest articol într-o altă limbă: _

** Limba actuală este: ** `engleză (SUA)` _ (traducerile ar putea fi necesare pentru a corecta limba engleză înlocuind limba corectă) _

_🌐 Lista limbilor_

** Sortate după: ** `A-Z`

[Opțiunile de sortare nu sunt disponibile] (https://github.com/Degoogle-your-Life)

([af afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albaneză | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) Arabă | [hy հայերեն] (/. github / README_HY.md) Armenian | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijani | [eu Euskara] (/. github /README_EU.md) Bască | [be Беларуская] (/. Github / README_BE.md) Belarusian | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosniacă | [bg български] (/. Github / README_BG.md) Bulgară | [ca Català] (/. Github / README_CA.md) Catalană | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chineză (simplificată) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chineză (tradițională) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Croată | [cs čeština] (/. Github / README_CS .md) Cehă | [da dansk] (README_DA.md) Daneză | [nl Nederlands] (/. github / README_ NL.md) olandeză | [** en-us English **] (/. github / README.md) English | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonian | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finlandeză | [fr français] (/. github / README_FR.md) franceză | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galiciană | [ka ქართველი] (/. github / README_KA) Georgian | [de Deutsch] (/. github / README_DE.md) Germană | [el Ελληνικά] (/. github / README_EL.md) greacă | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Creole Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) ebraică | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) maghiară | [este Íslenska] (/. github / README_IS.md) islandeză | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) islandeză | [ga Gaeilge] (/. github / README_GA.md) irlandez | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) japoneză | [jw Wong jawa] (/. github / README_JW.md) javanez | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Coreeană (Sud) | [ko-nord 문화어] (README_KO_NORTH.md) coreeană (nord) (NEÎNCĂ TRADUSĂ) | [ku Kurdî] (/. github / README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirghiză | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lituanian | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgheză | [mk Македонски] (/. github / README_MK.md) Macedoneană | [mg malgache] (/. github / README_MG.md) malgache | [ms Bahasa Melayu] (/. github / README_MS.md) Malay | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltese | [mi maori] (/. github / README_MI.md) maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolă | [my မြန်မာ] (/. github / README_MY.md) Myanmar (birmaneză) | [ne नेपाली] (/. github / README_NE.md) Nepalieră | [no norsk] (/. github / README_NO.md) Norvegian | [sau ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persană [pl polski] (/. github / README_PL.md) Poloneză | [pt português] (/. github / README_PT.md) portugheză | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Nu există limbi disponibile care încep cu litera Q | [ro Română] (/. github / README_RO.md) română | [ru русский] (/. github / README_RU.md) rusă | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) gaelică scoțiană | [sr Српски] (/. github / README_SR.md) sârbă | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovacă | [sl Slovenščina] (/. github / README_SL.md) slovenă | [deci Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) spaniolă | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Suedeză | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) tătară | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github /README_TR.md) turcă | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) ucraineană | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnameză | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Disponibil în 110 limbi (108 când nu se numără engleza și coreeana de Nord, deoarece Coreea de Nord nu a fost încă tradusă [Citiți despre aceasta aici] (/ OldVersions / Korean (North ) /README.md))

Traducerile în alte limbi decât engleza sunt traduse automat și nu sunt încă exacte. Încă nu au fost remediate erori începând cu 5 februarie 2021. Vă rugăm să raportați erorile de traducere [aici] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) asigurați-vă că faceți o copie de rezervă a corecției cu surse și mă ghidează, deoarece nu știu bine alte limbi decât engleza (intenționez să obțin un traducător în cele din urmă) vă rugăm să citați [wiktionary] (https://en.wiktionary.org) și alte surse în raportul dvs. În caz contrar, va fi publicată respingerea corecției.

Notă: datorită limitării interpretării GitHub a markdown-ului (și aproape a oricărei alte interpretări bazate pe web a markdown-ului), făcând clic pe aceste linkuri vă va redirecționa către un fișier separat pe o pagină separată care nu este pagina mea de profil GitHub. Veți fi redirecționat către [depozitul seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), unde este găzduit README.

Traducerile se fac cu Google Translate datorită asistenței limitate sau absente pentru limbile de care am nevoie în alte servicii de traducere precum DeepL și Bing Translate (destul de ironic pentru o campanie anti-Google) Lucrez la găsirea unei alternative. Din anumite motive, formatarea (linkuri, divizoare, caractere aldine, cursive etc.) este încurcată în diferite traduceri. Este obositor de remediat și nu știu cum să rezolv aceste probleme în limbi cu caractere non-latine, iar limbile de la dreapta la stânga (cum ar fi araba) este nevoie de ajutor suplimentar pentru remedierea acestor probleme.

Din cauza problemelor de întreținere, multe traduceri sunt depășite și utilizează o versiune învechită a acestui fișier de articol „README”. Este nevoie de un traducător. De asemenea, începând cu 23 aprilie 2021, îmi va lua ceva timp să pun în funcțiune toate linkurile noi.

***

# Este timpul să tăiem Widevine

Acesta este un articol despre motivul pentru care ar trebui să încetați să utilizați Google WideVine (DRM) și să îl dezinstalați. DRM trebuie eliminat. Acest articol vă va ajuta să faceți alegerea (dacă nu ați făcut-o deja) WideVine este extrem de anticoncurențial și extrem de restrictiv și distruge libertatea videoclipurilor de pe Internet.

Să tăiem WideVine și să adoptăm un internet deschis.

***

# Index

[00.0 - Sus] (# Sus)

> [00.1 - Citiți acest articol într-o altă limbă]

> [00.2 - Titlu] (# It-is-time-to-cut-Widevine)

> [00.3 - Index] (# Index)

[01.0 - Prezentare generală] (# Prezentare generală)

[02.0 - Anticoncurențial] (# Anticoncurențial)

[03.0 - Lipsa libertății] (# Lipsa libertății)

[04.0 - Utilizarea memoriei] (# Utilizarea memoriei)

[05.0 - Confidențialitate] (# Confidențialitate)

[06.0 - Metode alternative] (# Metode alternative)

[07.0 - Ce puteți face pentru a ajuta] (# What-you-can-do-to-help)

[08.0 - Alte lucruri de verificat] (# Alte lucruri de verificat)

[09.0 - Informații despre articol] (# Articol-informații)

> [09.0.1 - Stare software] (# Stare software)

> [09.0.2 - Informații despre sponsor] (# Informații despre sponsor)

[10.0 - Istoricul fișierelor] (# Istoricul fișierelor)

[11.0 - subsol] (# subsol)

> [11.9 - EOF] (# EOF)

***

## Prezentare generală

Pentru alte informații despre motivul pentru care DRM este o problemă, [faceți clic aici] (https://www.defectivebydesign.org/)

***

## Anticompetitiv

WideVine este un DRM care trebuie să fie autorizat pentru a fi utilizat cu un browser. Google este extrem de lent în examinarea și acceptarea persoanelor și deseori refuză oamenii să o folosească în produsele lor fără niciun motiv. [Sursa 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Sursa 2 (firul de e-mail care a continuat timp de peste 4 luni și nu a dus decât la dezamăgire)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google a făcut mult mai greu ca browserele precum Brave sau Firefox să concureze cu împingerea acestei bucăți de DRM.

***

## Lipsa libertății

WideVine este utilizat pentru a împiedica utilizatorii să interacționeze cu videoclipuri de pe site-uri web. Este o formă de gestionare a restricțiilor digitale care vă împiedică să descărcați videoclipul, să vizionați videoclipul offline sau chiar să faceți o captură de ecran. Este un software proprietar și, din cauza problemelor sale cu confidențialitatea, nu este instalat implicit pe majoritatea distribuțiilor Linux. Limită libertățile internetului datorită utilizării sale de către filmele Netflix, Disney și YouTube. Accesul dvs. la conținut poate fi eliminat în orice moment, fără niciun motiv.

***

## Folosirea memoriei

WideVine nu mai are memorie. În comparație cu vizionarea normală a unui videoclip fără DRM, WideVine va folosi cantități mari de CPU și RAM. Este rău pe badurată de viață și nu oferă niciun beneficiu de la redarea video standard HTML5.

***

## Confidențialitate

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Criticism) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- date-despre-tu-poți-găsi-și-șterge-acum /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -și) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o[(https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- revendicări-în-numele-5-milioane-de-utilizatori-iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technolo gy / 2014/01 / what-google-can-really-do-with-nest-or-really-nests data /) [i] (https://www.cbsnews.com/news/google-education-spies -pe-colectează-date-despre-milioane-de-copii-pretinde-proces-nou-mexico-procuror-general /) [v] (https://www.nationalreview.com/2018/04/the-student- data-mining-scandal-under-our-nases /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (aș putea continua cu dovezi despre acest lucru , dar a durat mult să găsesc și să parcurg toate aceste articole)

Confidențialitatea nu este un lucru cu WideVine. Software-ul proprietar este conceput astfel încât să nu puteți vedea deloc ce se întâmplă. Cu istoria Google, este foarte probabil căWideVine este un software suplimentar care vă spionează, vă citește documentele și alte lucruri rele.

Dacă credeți că nu aveți nimic de ascuns, ** vă înșelați **. Acest argument a fost demis de mai multe ori:

[Via Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden a remarcat „Argumentând că nu îți pasă de dreptul la viață privată, deoarece nu ai nimic de ascuns, nu diferă decât să spui că nu-ți pasă de libertatea de exprimare, deoarece nu ai nimic de spus.” Când spui, Nu am nimic de ascuns, tu spui, „nu-mi pasă de acest drept.” Spui: „Nu am acest drept, pentru că am ajuns la punctul în care trebuie să justific „Modul în care funcționează drepturile este că guvernul trebuie să-și justifice intruziunea în drepturile dumneavoastră”.

2. Daniel J. Solove a declarat într-un articol pentru Cronica învățământului superior că se opune argumentului; el a declarat că un guvern poate divulga informații despre o persoană și poate provoca daune acelei persoane sau poate folosi informații despre o persoană pentru a refuza accesul la servicii chiar dacă o persoană nu s-a angajat efectiv în săvârșirea unei acțiuni greșite și că un guvern poate provoca daune personalului său viața prin comiterea erorilor. Solove a scris: „Atunci când este angajat direct, argumentul„ nimic ascuns ”poate prinde, pentru că forțează dezbaterea să se concentreze pe înțelegerea sa restrânsă a vieții private. dezvăluirea, argumentul nimic ascuns, în cele din urmă, nu are nimic de spus. "

3. Adam D. Moore, autorul drepturilor de confidențialitate: fundamentele morale și juridice, a susținut că „drepturile sunt rezistente la costuri / beneficii sau la argumente consecințialiste. Aici respingem opinia că interesele de confidențialitate sunt genul acesta. de lucruri care pot fi schimbate pentru siguranță ". El a afirmat, de asemenea, că supravegherea poate afecta în mod disproporționat anumite grupuri din societate în funcție de aspect, etnie, sexualitate și religie.

4. Bruce Schneier, expert în securitate informatică și criptograf, și-a exprimat opoziția, citând afirmația cardinalului Richelieu „Dacă cineva mi-ar da șase rânduri scrise de mâna celui mai cinstit om, aș găsi ceva în ele pentru a-l spânzura”, referindu-se la modul în care un guvern de stat poate găsi aspecte în viața unei persoane pentru a urmări sau șantaja persoana respectivă. Schneier a mai argumentat „Prea mulți caracterizează în mod greșit dezbaterea drept„ securitate versus intimitate ”. Alegerea reală este libertatea versus control ".

5. Harvey A. Silverglate a estimat că persoana obișnuită, în medie, comite, fără să știe, trei infracțiuni pe zi în SUA.

6. Emilio Mordini, filosof și psihanalist, a susținut că argumentul „nimic de ascuns” este inerent paradoxal. Oamenii nu trebuie să aibă „ceva de ascuns” pentru a ascunde „ceva”. Ceea ce este ascuns nu este neapărat relevant, susține Mordini. În schimb, el susține că este necesară o zonă intimă care poate fi atât ascunsă, cât și restricționată pentru acces, deoarece, din punct de vedere psihologic, devenim indivizi prin descoperirea că am putea ascunde ceva altora.

7. Julian Assange a declarat: „Nu există încă un răspuns ucigaș. Jacob Appelbaum (@ioerror) are un răspuns inteligent, cerându-i oamenilor care spun asta să-i dea telefonul descuiat și să-și dea jos pantalonii. Versiunea mea este să spun, „Ei bine, dacă ești atât de plictisitor, atunci nu ar trebui să vorbim cu tine și nici cu nimeni altcineva”, dar din punct de vedere filosofic, răspunsul real este următorul: Supravegherea în masă este o schimbare structurală în masă. Când societatea merge prost, merge să te iau cu el, chiar dacă ești cea mai blandă persoană de pe pământ ".

8. Ignacio Cofone, profesor de drept, susține că argumentul este greșit în propriii termeni, deoarece, ori de câte ori oamenii dezvăluie informații relevante altora, ele dezvăluie și informații irelevante. Aceste informații irelevante au costuri de confidențialitate și pot duce la alte prejudicii, cum ar fi discriminarea.

***

# Metode alternative

Media nu trebuie restricționată, online sau offline. Dacă oamenii doreau să vizioneze videoclipul fără DRM, vor găsi întotdeauna o modalitate de ao face. Fiecare software poate fi spart.

[extras modificat din Wikipedia] Președintele Valve, Gabe Newell, a declarat că „majoritatea strategiilor DRM sunt doar stupide”, deoarece scad doar valoarea unui joc în ochii consumatorului. Newell sugerează că obiectivul ar trebui să fie „[crearea] unei valori mai mari pentru clienți prin valoarea serviciului”. Rețineți că Valve operează Steam, un serviciu care servește ca magazin online pentru jocuri pe PC, precum și un serviciu de rețele sociale și o platformă DRM

Acest punct nu este valabil doar pentru jocurile video, poate fi aplicat oricărui computer de pe computer. Computerul dvs. nu ar trebui să dețină controlul complet asupra unei companii nebune care folosește inteligența artificială proastă pentru a-și șterge utilizatorii și munca (YouTube etc.) și care are o înregistrare atât de proastă. Computerul dvs. nu ar trebui să fie restricționat, deoarece o companie refuză să partajeze ca un copil comportat prost. Computerul dvs. ar trebui să fie deținut de dvs.,și nimeni altcineva. Ar trebui să scăpați complet de DRM, deoarece conținutul nu merită să renunțați la controlul computerului. Aceste companii au sute de miliarde de dolari. Dacă fac așa ceva stupid, ar trebui să protestezi. Puteți chiar să descărcați videoclipul în altă parte și să-l vizualizați, deoarece ar trebui să piardă bani pentru a face prostii de genul acesta. Încălcarea drepturilor de autor nu este un lucru rău. Oamenii care nu își permit filmele le vor descărca în altă parte, se întâmplă de la începutul internetului global și cu inventarea benzii VHS. Cu greu le afectează veniturile, deoarece oricum nu ar putea obține acei bani. DRM este defect prin proiectare.

***

## Ce puteți face pentru a ajuta

Puteți protesta împotriva DRM. Poate părea nesemnificativ, dar cu cât sunt mai mulți oameni care se împotrivesc, cu atât se face mai mult în acest sens.

Dacă sunteți pe Linux și utilizați Firefox, asigurați-vă că DRM nu este instalat (în mod normal nu este implicit) și nu vă deranjați să îl instalați.

Dacă sunteți pe Windows sau MacOS, este posibil să aveți un timp mult mai dificil, deoarece DRM este instalat implicit pe aceste sisteme și se poate reinstala automat.

Încercați să evitați următoarele site-uri:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Practic, aproape orice serviciu de streaming video online ar trebui evitat, deoarece majoritatea utilizează DRM și nu puteți utiliza site-ul fără a vă pierde libertatea. Nu merită. Trimiteți un mesaj [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) și opriți transmiterea acestor emisiuni.

De asemenea, ar trebui să evitați orice opțiune „gratuită cu anunțuri” pe următoarele site-uri (deoarece această metodă necesită DRM)

[YouTube] (https://www.youtube.com)

De asemenea, puteți protesta împotriva DRM cu un mesaj în fișierul proiectului `README.md`. Iată ce folosesc:

"" reducere

***

## Starea software-ului

Toate lucrările mele sunt gratuite, unele restricții. DRM (** D ** igital ** R ** restricții ** M ** administrare) nu este prezent în niciuna dintre lucrările mele.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Acest autocolant este acceptat de Free Software Foundation. Nu intenționez niciodată să includ DRM în lucrările mele.

Folosesc abrevierea „Digital Restrictions Management” în locul celei mai cunoscute „Digital Rights Management”, deoarece modul obișnuit de abordare este fals, nu există drepturi cu DRM. Ortografia „Managementul restricțiilor digitale” este mai precisă și este susținută de [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) și de [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Această secțiune este utilizată pentru a crește gradul de conștientizare a problemelor cu DRM și, de asemenea, pentru a protesta împotriva acesteia. DRM este defect prin design și reprezintă o amenințare majoră pentru toți utilizatorii de computer și libertatea software-ului.

Credit de imagine: [defectivebydesign.org/drm-free/...)(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

""

***
## Alte lucruri de verificat

[Defect prin design - O campanie a Free Software Foundation care lucrează la expunerea și eliminarea utilizării DRM] (https://www.defectivebydesign.org/)

[Cimitirul Google (killbygoogle.com) - o listă sortată cu cele peste 224 de produse pe care Google le-a ucis] (https://killedbygoogle.com/)

> [Link GitHub] (https://github.com/codyogden/killedbygoogle)

[Sindicatul lucrătorilor din alfabet - Noul sindicat al lucrătorilor de la Google cu peste 800 de membri] (https://alphabetworkersunion.org/people/our-union/)

Există și alți supleanți, doar căutați-i.

***

## Informații despre articol

Tipul de fișier: `Markdown (* .md)`

Versiunea fișierului: `4 (vineri, 23 aprilie 2021 la 15:35)`

Numărul de linii (inclusiv liniile goale și linia compilatorului): `354`

### Starea software-ului

Toate lucrările mele nu conțin restricții. DRM (** D ** igital ** R ** restricții ** M ** administrare) nu este prezent în niciuna dintre lucrările mele. Acest proiect nu conține niciun DRM, dar vorbește despre DRM direct.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Acest autocolant este acceptat de Free Software Foundation. Nu intenționez niciodată să includ DRM în lucrările mele.

***

### Informații despre sponsor

! [SponsorButton.png] (SponsorButton.png) <- Acesta nu este butonul oficial al sponsorului, este o imagine demonstrativă. Nu faceți clic pe el dacă doriți să sponsorizați acest proiect.

Puteți sponsoriza acest proiect dacă doriți, dar vă rugăm să specificați la ce doriți să donați. [Vedeți fondurile pe care le puteți dona aici] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Puteți vedea alte informații despre sponsori [aici] (https://github.com/seanpm2001/Sponsor-info/)

Încearcă! Butonul de sponsor se află chiar lângă butonul de ceas / de vizionare.

***

## Istoricul fișierelor

Versiunea 1 (duminică, 8 februarie 2021 la 16:41)

> Modificări:

> * A început fișierul / articolul

> * S-a adăugat secțiunea de titlu

> * A fost adăugată o secțiune despre confidențialitate

> * A fost adăugată o secțiune despre prezentarea generală

> * A fost adăugată secțiunea cu informații despre articol

> * A făcut referire la pictograma DRM Free

> * A fost adăugată secțiunea istoric fișiere

> * A fost adăugată secțiunea Lipsa libertății

> * A fost adăugată secțiunea anticoncurențială

> * A fost adăugată secțiunea de metode alternative

> * S-a adăugat notasecțiunea de utilizare

> * S-au adăugat celelalte lucruri pentru a verifica secțiunea

> * A fost adăugat indexul

> * S-a adăugat subsolul

> * Nu există alte modificări în versiunea 1

Versiunea 2 (joi, 8 aprilie 2021 la 17:18)

> Modificări:

> * Actualizat secțiunea titlu

> * Actualizarea indexului

> * S-au adăugat informații despre ce puteți face pentru a vă ajuta

> * A fost adăugată secțiunea de informații despre sponsori

> * Actualizat secțiunea cu informații despre fișier

> * Actualizat secțiunea istoric fișier

> * Nu există alte modificări în versiunea 2

Versiunea 3 (joi, 8 aprilie 2021 la 17:27)

> Modificări:

> * Legături de traducere corecte

> * Actualizarea indexului

> * S-a remediat o intrare duplicat, în afara subiectului, în secțiunea „Ce puteți face pentru a ajuta”

> * Actualizat secțiunea de informații despre sponsori

> * Actualizat secțiunea cu informații despre fișier

> * Actualizat secțiunea istoric fișier

> * Nu există alte modificări în versiunea 3

Versiunea 4 (vineri, 23 aprilie 2021 la 15:35)

> Modificări:

> * Actualizat lista de comutare a limbii

> * Actualizat secțiunea cu informații despre fișier

> * Actualizat secțiunea istoric fișier

> * Nu există alte modificări în versiunea 4

Versiunea 5 (În curând)

> Modificări:

> * În curând

> * Nu există alte modificări în versiunea 5

Versiunea 6 (În curând)

> Modificări:

> * În curând

> * Nu există alte modificări în versiunea 6

Versiunea 7 (În curând)

> Modificări:

> * În curând

> * Nu există alte modificări în versiunea 7

Versiunea 8 (În curând)

> Modificări:

> * În curând

> * Nu există alte modificări în versiunea 8

***

## Subsol

Ați ajuns la sfârșitul acestui fișier!

##### EOF

***
