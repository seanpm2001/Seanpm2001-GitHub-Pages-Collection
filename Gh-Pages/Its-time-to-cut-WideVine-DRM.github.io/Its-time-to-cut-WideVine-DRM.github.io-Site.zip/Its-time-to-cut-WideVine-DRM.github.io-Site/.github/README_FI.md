***

##### Alkuun

_Lue tämä artikkeli toisella kielellä: _

** Nykyinen kieli on: ** `englanti (Yhdysvallat)` _ (käännökset saatetaan joutua korjaamaan oikean kielen korvaamiseksi.

_🌐 Luettelo kielistä_

** Lajiteltu: ** `` A-Z``

[Lajitteluvaihtoehdot eivät ole käytettävissä] (https://github.com/Degoogle-your-Life)

([af afrikaans] (/. github / README_AF.md) afrikaans | [sq Shqiptare] (/. github / README_SQ.md) albania | [am አማርኛ] (/. github / README_AM.md) amhara | [ar عربى] (/.github/README_AR.md) arabia | [hy հայերեն] (/. github / README_HY.md) armenia | [az Azərbaycan dili] (/. github / README_AZ.md) azerbaidžanilainen | [eu Euskara] (/. github /README_EU.md) baski | [be Беларуская] (/. Github / README_BE.md) valkovenäjä | [bn বাংলা] (/. Github / README_BN.md) bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) bulgaria | [ca Català] (/. Github / README_CA.md) katalaani | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichew ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) kiina (yksinkertaistettu) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) kiina (perinteinen) | [co Corsu] (/. Github / README_CO.md) korsikalainen | [hr Hrvatski] (/. Github / README_HR.md) kroatia | [cs čeština] (/. Github / README_CS .md) tšekki | [da dansk] (README_DA.md) tanska | [nl Nederlands] (/. github / README_ NL.md) hollanti | [** fi-fi englanti **] (/. github / README.md) englanti | [EO esperanto] (/. Github / README_EO.md) esperanto | [et Eestlane] (/. github / README_ET.md) viro | [tl Pilipino] (/. github / README_TL.md) filippiiniläinen | [fi Suomalainen] (/. github / README_FI.md) suomi | [fr français] (/. github / README_FR.md) ranska | [fy Frysk] (/. github / README_FY.md) Friisi | [gl Galego] (/. github / README_GL.md) galicia | [ka ქართველი] (/. github / README_KA) georgialainen | [de Deutsch] (/. github / README_DE.md) saksa | [el Ελληνικά] (/. github / README_EL.md) kreikka | [gu ગુજરાતી] (/. github / README_GU.md) gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitin kreoli | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) havaijilainen | [he עִברִית] (/. github / README_HE.md) heprea | [hi हिन्दी] (/. github / README_HI.md) hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) unkari | [on Íslenska] (/. github / README_IS.md) islanti | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) islanti | [ga Gaeilge] (/. github / README_GA.md) irlanti | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) japani | [jw Wong jawa] (/. github / README_JW.md) jaava | [kn ಕನ್ನಡ] (/. github / README_KN.md) kannada | [kk Қазақ] (/. github / README_KK.md) kazakstan | [km ខ្មែរ] (/. github / README_KM.md) khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-etelä 韓國 語] (/. github / README_KO_SOUTH.md) korea (etelä) | [ko-pohjoinen 문화어] (README_KO_NORTH.md) korea (pohjoinen) (EI Vielä Käännetty) | [ku Kurdî] (/. github / README_KU.md) kurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) kirgisia | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) liettua | [lb Lëtzebuergesch] (/. github / README_LB.md) luxemburg | [mk Македонски] (/. github / README_MK.md) makedonia | [mg madagaskaria] (/. github / README_MG.md) madagaskaria | [ms Bahasa Melayu] (/. github / README_MS.md) malaiji | [ml മലയാളം] (/. github / README_ML.md) malajalam | [mt Malti] (/. github / README_MT.md) maltan kieli | [mi maori] (/. github / README_MI.md) maori | [herra मराठी] (/. github / README_MR.md) marathi | [mn Монгол] (/. github / README_MN.md) mongoli | [my မြန်မာ] (/. github / README_MY.md) Myanmar (burmalainen) | [ne नेपाली] (/. github / README_NE.md) Nepali | [ei norsk] (/. github / README_NO.md) norja | [tai ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) pastu | [fa فارسی] (/. github / README_FA.md) | persia [pl polski] (/. github / README_PL.md) puola | [pt português] (/. github / README_PT.md) portugali | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) pandžabi | Q-kirjaimella alkavia kieliä ei ole käytettävissä [ro Română] (/. github / README_RO.md) romania | [ru русский] (/. github / README_RU.md) venäjä | [sm Faasamoa] (/. github / README_SM.md) Samoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) skotti gaeli | [sr Српски] (/. github / README_SR.md) serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) slovakia | [sl Slovenščina] (/. github / README_SL.md) sloveeni | [niin Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) espanja | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) suahili | [sv Svenska] (/. github / README_SV.md) ruotsi | [tg Тоҷикӣ] (/. github / README_TG.md) tadžiki | [ta தமிழ்] (/. github / README_TA.md) tamili | [tt Татар] (/. github / README_TT.md) tataari | [te తెలుగు] (/. github / README_TE.md) telugu | [th ไทย] (/. github / README_TH.md) thai | [tr Türk] (/. github /README_TR.md) turkki | [tk Türkmenler] (/. github / README_TK.md) turkmeeni | [uk Український] (/. github / README_UK.md) ukraina | [ur اردو] (/. github / README_UR.md) urdu | [ug ئۇيغۇر] (/. github / README_UG.md) uiguuri | [uz O'zbek] (/. github / README_UZ.md) uzbekki | [vi Tiếng Việt] (/. github / README_VI.md) vietnam | [cy Cymraeg] (/. github / README_CY.md) kymri | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jiddiš | [yo joruba] (/. github / README_YO.md) joruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Saatavilla 110 kielellä (108, kun ei lasketa englantia ja pohjoiskorealaista, koska pohjoiskorealaista ei ole vielä käännetty [Lue tästä] (/ OldVersions / Korea (pohjoinen) ) /README.md))

Käännökset muille kielille kuin englanniksi käännetään koneella, eivätkä ne ole vielä tarkkoja. Virheitä ei ole vielä korjattu 5. helmikuuta 2021 alkaen. Ilmoita käännösvirheistä [täällä] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) varmista, että varmuuskopioit korjauksesi lähteistä ja ohjaa minua, koska en tiedä muita kieliä kuin englantia hyvin (aion saada kääntäjän lopulta), mainitse [wikisanakirja] (https://fi.wiktionary.org) ja muut lähteet raportissasi. Jos näin ei tehdä, korjauksen julkaiseminen hylätään.

Huomaa: GitHubin tulkinnan rajoitusten vuoksi (ja melkein kaikki muut verkkopohjaiset merkinnät) näiden linkkien napsauttaminen ohjaa sinut erilliseen tiedostoon erilliselle sivulle, joka ei ole minun GitHub-profiilisivu. Sinut ohjataan [seanpm2001 / seanpm2001-arkistoon] (https://github.com/seanpm2001/seanpm2001), jossa README-palvelinta isännöidään.

Käännökset tehdään Google Kääntäjän kanssa, koska tarvitsen vain vähän tai ei lainkaan tarvitsemiani kieliä muissa käännöspalveluissa, kuten DeepL ja Bing Translate (melko ironista Google-vastaista kampanjaa varten). Jostain syystä muotoilu (linkit, jakajat, taivutus, kursivointi jne.) Sekoitetaan erilaisissa käännöksissä. Se on tylsää korjata, enkä tiedä kuinka korjata nämä ongelmat kielillä, joissa ei ole latinankielisiä merkkejä, ja oikealta vasemmalle (kuten arabia) käytetyille kielille tarvitaan lisäapua näiden ongelmien korjaamiseen

Huolto-ongelmien takia monet käännökset ovat vanhentuneita ja käyttävät tämän `` README`` -artikkelitiedoston vanhentunutta versiota. Kääntäjä tarvitaan. Lisäksi 23. huhtikuuta 2021 alkaen minulla kestää jonkin aikaa saada kaikki uudet linkit toimimaan.

***

# On aika leikata Widevine

Tämä on artikkeli siitä, miksi sinun pitäisi lopettaa Google WideVinen (DRM) käyttö ja poistaa se. DRM on poistettava. Tämä artikkeli auttaa sinua tekemään valintasi (jos et ole jo tehnyt niin). WideVine on erittäin kilpailunvastainen ja erittäin rajoittava ja tuhoaa Internetissä olevien videoiden vapauden.

Leikataan WideVine ja omaksutaan avoin Internet.

***

# Indeksi

[00.0 - Yläosa] (# Yläosa)

> [00.1 - Lue tämä artikkeli toisella kielellä]

> [00.2 - Otsikko] (# On aika leikata Widevine)

> [00.3 - Hakemisto] (# Hakemisto)

[01.0 - yleiskatsaus] (# yleiskatsaus)

[02.0 - kilpailunvastainen] (# kilpailunvastainen)

[03.0 - Vapauden puute] (# Vapauden puute)

[04.0 - Muistin käyttö] (# Muistin käyttö)

[05.0 - Tietosuoja] (# Tietosuoja)

[06.0 - Vaihtoehtoiset menetelmät] (# Vaihtoehtoiset menetelmät)

[07.0 - Mitä voit tehdä auttaaksesi] (# Mitä-voit-tehdä-auttamaan)

[08.0 - Muut tarkistettavat asiat] (# Muut - lähtöselvitys)

[09.0 - Artikkelitiedot] (# Artikkeli-info)

> [09.0.1 - Ohjelmiston tila] (# Ohjelmiston tila)

> [09.0.2 - Sponsor info] (# Sponsor-info)

[10.0 - Tiedostohistoria] (# Tiedosto-historia)

[11.0 - alatunniste] (# alatunniste)

> [11.9 - EOF] (# EOF)

***

## Yleiskatsaus

Jos haluat lisätietoja DRM: n ongelmasta, [napsauta tätä] (https://www.defectivebydesign.org/)

***

## Kilpailunvastainen

WideVine on DRM, joka on lisensoitava käytettäväksi selaimen kanssa. Google tarkistaa ja hyväksyy ihmisiä erittäin hitaasti ja kieltäytyy usein käyttämästä sitä tuotteissaan ilman perusteluja. [Lähde 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Lähde 2 (yli 4 kuukautta jatkunut sähköpostiketju, joka ei aiheuttanut muuta kuin pettymystä)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google on tehnyt Braven tai Firefoxin kaltaisille selaimille paljon vaikeammaksi kilpailla tämän DRM-osan työntämisellä.

***

## Vapauden puute

WideVineä käytetään estämään käyttäjiä olemasta vuorovaikutuksessa videoiden kanssa verkkosivustoilla. Se on eräänlainen digitaalisten rajoitusten hallinta, joka estää sinua lataamasta videota, katsomasta videota offline-tilassa tai edes ottamalla kuvakaappausta. Se on oma ohjelmisto, ja yksityisyyden vuoksi se ei ole oletusarvoisesti asennettu useimpiin Linux-jakeluihin. Se rajoittaa verkon vapauksia, koska Netflix-, Disney- ja YouTube-elokuvat käyttävät sitä. Sisältösi käyttöoikeus voidaan poistaa milloin tahansa ilman syytä.

***

## Muistin käyttö

WideVine on huono muistissa. Verrattuna vain normaalisti videon katselemiseen ilman DRM: ää, WideVine käyttää runsaasti suoritinta ja RAM-muistia. On huono baelämästä, eikä siitä ole hyötyä tavalliselle HTML5-videotoistolle.

***

## Yksityisyys

[G] (https://fi.wikipedia.org/wiki/Criticism_of_Google) [o] (https://fi.wikipedia.org/wiki/PRISM_ (valvonta_ohjelma)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -huono /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. fi / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -selain /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://fi.wikipedia.org/wiki/Nothing_to_hide_argument# Kritiikki) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a- pelottava-mount-of- data-sinusta-löydät-ja-poista-se-nyt /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes ja [c] (https://www.wired.com/story/google-tracks-you -tietosuoja /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-do-google-piirtää datakokoelmalinjan) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- väitteet 5 miljoonan iphone-käyttäjän puolesta) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaengerss-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technolo gy / 2014/01 / what-google-can-do-do-with-pesä-tai-todella-pesii-data /) [i] (https://www.cbsnews.com/news/google-education-spies -kerää-tietoja-miljoonista-lapsista-väittää-oikeusjuttu-uusi-meksiko-oikeusasianajaja /) [v] (https://www.nationalreview.com/2018/04/the-student- data-mineing-skandaali-nenämme alla /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Voisin jatkaa ja jatkaa näyttöä tästä , mutta kaikkien näiden artikkeleiden löytäminen ja läpikäyminen kesti kauan)

Yksityisyys ei ole asia WideVinen kanssa. Oma ohjelmisto on suunniteltu niin, että et voi nähdä, mitä tapahtuu ollenkaan. Googlen historian avulla on erittäin todennäköistäWideVine on ylimääräinen ohjelmisto, joka vakoilee sinua, lukee asiakirjojasi ja muita huonoja asioita.

Jos luulet, ettei sinulla ole mitään salattavaa, ** olet ehdottomasti väärässä **. Tämä väite on purettu monta kertaa:

[Wikipedian kautta] (https://fi.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden huomautti, että "väittäen, että et välitä oikeudesta yksityisyyteen, koska sinulla ei ole mitään salattavaa, ei ole eroa kuin sanomalla, ettet välitä sananvapaudesta, koska sinulla ei ole mitään sanottavaa." Kun sanot, Minulla ei ole mitään salattavaa, "sanot," minua ei kiinnosta tämä oikeus. "Sanot:" Minulla ei ole tätä oikeutta, koska olen päässyt siihen pisteeseen, että minun on perusteltava Se, miten oikeudet toimivat, hallituksen on perusteltava tunkeutumisen oikeuksiisi. "

2. Daniel J. Solove ilmoitti artikkelissa The Chronicle of Higher Education, että hän vastustaa väitettä; hän totesi, että hallitus voi vuotaa tietoja henkilöstä ja vahingoittaa henkilöä tai käyttää henkilöä koskevia tietoja palvelujen estämiseksi, vaikka henkilö ei tosiasiallisesti tekisi väärinkäytöksiä, ja että hallitus voi vahingoittaa henkilökohtaista elämää tekemällä virheitä. Solove kirjoitti: "Ollessaan suorassa yhteydessä ei-piilotettava väite voi vallata, sillä se pakottaa keskustelun keskittymään kapeaan yksityisyyden käsitykseen. Mutta kun se joutuu kohtaamaan yksityisyyden ongelmia, joihin valtion tiedonkeruu ja käyttö liittyy valvonnan ulkopuolella paljastamisella, ei-salattavalla argumentilla ei lopulta ole mitään sanottavaa. "

3. Adam D. Moore, julkaisun Privacy Rights: Moral and Legal Foundations kirjoittaja, väitti, että "näkemys on siitä, että oikeudet ovat vastustuskykyisiä kustannus-hyöty tai seuraamuksellisille argumenteille. Tässä hylätään näkemys, että yksityisyyden edut ovat kaikenlaisia asioista, joilla voidaan käydä kauppaa turvallisuuden vuoksi. " Hän totesi myös, että valvonta voi vaikuttaa suhteettomasti tiettyihin yhteiskunnan ryhmiin ulkonäön, etnisen alkuperän, seksuaalisuuden ja uskonnon perusteella.

4. Tietoturva-asiantuntija ja kryptografi Bruce Schneier ilmaisi vastustuksensa vedoten kardinaali Richelieun lausuntoon "Jos minulle annetaan kuusi riviä, jotka on kirjoittanut rehellisimmän miehen käsissä, löytäisin heistä jotain, joka ripustaisi hänet". siihen, kuinka osavaltion hallitus voi löytää näkökohtia ihmisen elämästä syytteeseenpanoa tai kiristämistä varten. Schneier väitti myös, että "liian monet luonnehtivat keskustelua väärin" turvallisuudeksi kuin yksityisyydeksi ". Todellinen valinta on vapaus vs. hallinta. "

5. Harvey A. Silverglate arvioi, että tavallinen henkilö tekee keskimäärin tietämättään kolme rikosta päivässä Yhdysvalloissa.

6. Filosofi ja psykoanalyytikko Emilio Mordini väitti, että "ei mitään salattavaa" -peruste on luonnostaan ​​paradoksaalista. Ihmisillä ei tarvitse olla "jotain piilotettavaa" piilottaakseen "jotain". Piilotettu ei ole välttämättä merkitystä, väittää Mordini. Sen sijaan hän väittää, että intiimi alue, joka voi olla sekä piilotettu että pääsyn rajoitus, on välttämätöntä, koska psykologisesti ottaen meistä tulee yksilöitä havaitsemalla, että voimme piilottaa jotain muille.

7. Julian Assange totesi: "Tappajalle ei ole vielä vastausta. Jacob Appelbaumilla (@ioerror) on älykäs vastaus, joka pyytää tätä sanovia ihmisiä antamaan hänelle puhelimen avattuna ja vetämään housunsa alas. Minun versioni on sanoa: "No, jos olet niin tylsää, meidän ei pitäisi puhua sinulle eikä kenenkään muulle", mutta filosofisesti todellinen vastaus on seuraava: joukkovalvonta on massa rakenteellinen muutos. Kun yhteiskunta menee huonosti, se menee ottaa sinut mukanasi, vaikka olisitkin maan surkein ihminen. "

8. Oikeusprofessori Ignacio Cofone väittää, että väite on virheellinen omin sanoin, koska aina kun ihmiset paljastavat asiaankuuluvia tietoja muille, he paljastavat myös epäolennaisia ​​tietoja. Tällä merkityksettömällä tiedolla on yksityisyyden kustannuksia ja se voi johtaa muihin haitoihin, kuten syrjintään.

***

# Vaihtoehtoiset menetelmät

Mediaa ei tule rajoittaa, online- tai offline-tilassa. Jos ihmiset haluavat katsoa videota ilman DRM: ää, he löytävät aina keinon tehdä se. Jokainen ohjelmisto voidaan murtaa.

[muokattu ote Wikipediasta] Valven presidentti Gabe Newell on todennut, että "useimmat DRM-strategiat ovat vain tyhmä", koska ne vain vähentävät pelin arvoa kuluttajan silmissä. Newell ehdottaa, että tavoitteen pitäisi sen sijaan olla "[luoda] suurempi arvo asiakkaille palvelun arvon avulla". Huomaa, että Valve käyttää Steamia, palvelua, joka toimii verkkokaupana PC-peleille, sekä sosiaalisen verkostoitumisen palvelua ja DRM-alustaa.

Tämä kohta ei päde vain videopeleihin, sitä voidaan soveltaa mihin tahansa tietokoneella. Tietokoneesi ei pitäisi hallita hullua yritystä, joka käyttää huonoa tekoälyä poistamaan käyttäjät ja heidän työnsä (YouTube jne.) Ja jolla on niin huono tulos. Tietokonettasi ei pitäisi rajoittaa, koska yritys kieltäytyy jakamasta kuin huonosti käyttäytynyt lapsi. Tietokoneesi pitäisi olla sinun omistuksessa,eikä kukaan muu. Sinun pitäisi päästä eroon DRM: stä kokonaan, koska sisällön ei kannata luopua tietokoneen hallinnasta. Näillä yrityksillä on satoja miljardeja dollareita. Jos he tekevät jotain tällaista tyhmää, sinun pitäisi protestoida sitä. Voit jopa ladata videon vain muualta ja katsella sitä, koska heidän pitäisi menettää rahaa tällaisten tyhmien asioiden tekemisestä. Tekijänoikeusrikkomus ei ole huono asia. Ihmiset, joilla ei ole varaa elokuviin, lataavat ne muualle, se on tapahtunut maailmanlaajuisen Internetin alusta lähtien ja keksittyään VHS-nauha. Se tuskin vaikuttaa heidän tuloihinsa, koska he eivät silti saisi sitä rahaa. DRM on rakenteeltaan viallinen.

***

## Mitä voit tehdä auttaaksesi

Voit protestoida DRM: ää. Se saattaa tuntua merkityksettömältä, mutta mitä enemmän ihmisiä vastustaa sitä, sitä enemmän siihen tehdään.

Jos käytät Linuxia ja käytät Firefoxia, varmista, että DRM: ää ei ole asennettu (se ei yleensä ole oletusarvoisesti), äläkä vaivaudu asentamaan sitä.

Jos käytössäsi on Windows tai MacOS, sinulla voi olla paljon vaikeampaa aikaa, koska DRM on oletusarvoisesti asennettu näihin järjestelmiin, ja se voi asentaa automaattisesti uudelleen.

Yritä välttää seuraavia sivustoja:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Periaatteessa melkein mitä tahansa online-suoratoistopalvelua tulisi välttää, koska suurin osa heistä käyttää DRM: ää, etkä voi käyttää sivustoa menettämättä vapautta. Se ei ole sen arvoista. Lähetä [MPAA] (https://fi.wikipedia.org/wiki/Motion_Picture_Association) viesti ja lopeta näiden ohjelmien suoratoisto.

Sinun tulisi myös välttää seuraavia sivustoja sisältäviä ilmaisia ​​mainoksia -vaihtoehtoja (koska tämä menetelmä vaatii DRM: n)

[YouTube] (https://www.youtube.com)

Voit myös protestoida DRM: ää sanomalla projektiisi README.md-tiedostoon. Tässä on mitä käytän:

`` markdown

***

## Ohjelmiston tila

Kaikilla teoksillani on joitain rajoituksia. DRM (** D ** igital ** R ** estektiot ** M ** anagement) ei ole missään teoksissani.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Tätä tarraa tukee Free Software Foundation. En koskaan aio sisällyttää DRM: ää teoksihini.

Käytän lyhennettä "Digital Restrictions Management" tunnetumman "Digital Rights Management": n sijaan, koska yleinen tapa puuttua siihen on väärä, DRM: llä ei ole oikeuksia. Oikeinkirjoitus "Digital Restrictions Management" on tarkempi, ja sitä tukevat [Richard M. Stallman (RMS)] (https://fi.wikipedia.org/wiki/Richard_Stallman) ja [Free Software Foundation (FSF)] ( https://fi.wikipedia.org/wiki/Free_Software_Foundation)

Tätä osaa käytetään lisäämään tietoisuutta DRM-ongelmista ja myös vastustamaan sitä. DRM on rakenteeltaan viallinen ja on suuri uhka kaikille tietokoneen käyttäjille ja ohjelmistovapaudelle.

Kuvahyvitys: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

``

***
## Muita tarkistettavia asioita

[Suunniteltu virheellisesti - Free Software Foundationin kampanja, joka pyrkii paljastamaan ja poistamaan DRM-käytön] (https://www.defectivebydesign.org/)

[Google Graveyard (killbygoogle.com) - lajiteltu luettelo yli 224 tuotteesta, jonka Google on tappanut] (https://killedbygoogle.com/)

> [GitHub-linkki] (https://github.com/codyogden/killedbygoogle)

[Aakkosellinen työntekijäliitto - Googlen uusi työntekijäjärjestö, jossa on yli 800 jäsentä] (https://alphabetworkersunion.org/people/our-union/)

On muita vaihtoehtoja, etsi vain niitä.

***

## Artikkelin tiedot

Tiedostotyyppi: `Markdown (* .md)`

Tiedostoversio: "4 (perjantai 23. huhtikuuta 2021 klo 15.35)"

Rivien lukumäärä (tyhjät rivit ja kääntäjärivi mukaan lukien): "354"

### Ohjelmiston tila

Kaikissa teoksissani ei ole rajoituksia. DRM (** D ** igital ** R ** estektiot ** M ** anagement) ei ole missään teoksissani. Tämä projekti ei sisällä DRM: ää, mutta se puhuu suoraan DRM: stä.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Tätä tarraa tukee Free Software Foundation. En koskaan aio sisällyttää DRM: ää teoksihini.

***

### Sponsoritiedot

! [SponsorButton.png] (SponsorButton.png) <- Tämä ei ole virallinen sponsoripainike, se on esittelykuva. Älä napsauta sitä, jos haluat sponsoroida tätä projektia.

Voit sponsoroida tätä projektia, jos haluat, mutta täsmennä, mihin haluat lahjoittaa. [Katso varat, joita voit lahjoittaa täältä] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Voit tarkastella muita sponsoritietoja [täällä] (https://github.com/seanpm2001/Sponsor-info/)

Kokeile! Sponsoripainike on aivan katselu- / katselupainikkeen vieressä.

***

## Tiedostohistoria

Versio 1 (sunnuntaina 8. helmikuuta 2021 klo 16.41)

> Muutokset:

> * Käynnisti tiedosto / artikkeli

> * Lisätty otsikko-osa

> * Lisätty osa yksityisyydestä

> * Lisätty osio yleiskatsauksesta

> * Lisäsi artikkelin tiedot -osion

> * Viitattu DRM Free -kuvakkeeseen

> * Lisätty tiedostohistoria-osio

> * Lisätty Vapauden puute -osio

> * Lisättiin kilpailunvastainen osa

> * Lisätty vaihtoehtoisten menetelmien osio

> * Lisäsi muistionry käyttöosa

> * Lisäsi muut tarkistettavat kohdat

> * Lisätty hakemisto

> * Lisätty alatunniste

> * Ei muita muutoksia versiossa 1

Versio 2 (torstaina 8. huhtikuuta 2021 klo 17.18)

> Muutokset:

> * Päivitetty otsikkokohta

> * Päivitetty hakemisto

> * Lisätty tietoa siitä, mitä voit tehdä auttaaksesi

> * Lisätty sponsorin tiedot -osio

> * Päivitetty tiedostotiedot

> * Päivitetty tiedostohistoria-osio

> * Ei muita muutoksia versiossa 2

Versio 3 (torstaina 8. huhtikuuta 2021 klo 17.27)

> Muutokset:

> * Kiinteät käännöslinkit

> * Päivitetty hakemisto

> * Korjattu kaksoiskappale, aiheen ulkopuolinen merkintä osiossa "Mitä voit tehdä auttamiseksi"

> * Päivitetty sponsorin tiedot -osio

> * Päivitetty tiedostotiedot

> * Päivitetty tiedostohistoria-osio

> * Ei muita muutoksia versiossa 3

Versio 4 (perjantai 23. huhtikuuta 2021 klo 15.35)

> Muutokset:

> * Päivitetty kielenvaihtolista

> * Päivitetty tiedostotiedot

> * Päivitetty tiedostohistoria-osio

> * Ei muita muutoksia versiossa 4

Versio 5 (Tulossa pian)

> Muutokset:

> * Tulossa pian

> * Ei muita muutoksia versiossa 5

Versio 6 (Tulossa pian)

> Muutokset:

> * Tulossa pian

> * Ei muita muutoksia versiossa 6

Versio 7 (Tulossa pian)

> Muutokset:

> * Tulossa pian

> * Ei muita muutoksia versiossa 7

Versio 8 (Tulossa pian)

> Muutokset:

> * Tulossa pian

> * Ei muita muutoksia versiossa 8

***

## Alatunniste

Olet päässyt tämän tiedoston loppuun!

##### EOF

***
