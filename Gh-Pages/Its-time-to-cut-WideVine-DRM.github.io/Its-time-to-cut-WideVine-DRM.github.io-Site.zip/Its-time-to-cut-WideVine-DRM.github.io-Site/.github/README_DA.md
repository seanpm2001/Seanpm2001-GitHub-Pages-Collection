***

##### Top

_Læs denne artikel på et andet sprog: _

** Aktuelt sprog er: ** `Engelsk (USA)` _ (oversættelser skal muligvis rettes for at ordne engelsk, der erstatter det korrekte sprog) _

_🌐 Liste over sprog_

** Sorteret efter: ** `A-Z`

[Sorteringsmuligheder ikke tilgængelige] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albansk | [am አማርኛ] (/. github / README_AM.md) Amharisk | [ar عربى] (/.github/README_AR.md) Arabisk | [hy հայերեն] (/. github / README_HY.md) Armensk | [az Azərbaycan dili] (/. github / README_AZ.md) Aserbajdsjansk | [eu Euskara] (/. github /README_EU.md) Baskisk | [være Беларуская] (/. Github / README_BE.md) Hviderussisk | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnisk | [bg български] (/. Github / README_BG.md) Bulgarsk | [ca Català] (/. Github / README_CA.md) Catalansk | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Kinesisk (forenklet) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Kinesisk (traditionel) | [co Corsu] (/. Github / README_CO.md) Korsikansk | [hr Hrvatski] (/. Github / README_HR.md) Kroatisk | [cs čeština] (/. Github / README_CS .md) Tjekkisk | [da dansk] (README_DA.md) Dansk | [nl Nederlands] (/. github / README_ NL.md) Hollandsk | [** en-us engelsk **] (/. github / README.md) Engelsk | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estisk | [tl Pilipino] (/. github / README_TL.md) Filippinsk | [fi Suomalainen] (/. github / README_FI.md) Finsk | [fr français] (/. github / README_FR.md) Fransk | [fy Frysk] (/. github / README_FY.md) Frisisk | [gl Galego] (/. github / README_GL.md) Galicisk | [ka ქართველი] (/. github / README_KA) Georgisk | [de Deutsch] (/. github / README_DE.md) Tysk | [el Ελληνικά] (/. github / README_EL.md) Græsk | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitisk kreolsk | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiiansk | [he עִברִית] (/. github / README_HE.md) Hebraisk | [hej हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ungarsk | [er Íslenska] (/. github / README_IS.md) Islandsk | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandsk | [ga Gaeilge] (/. github / README_GA.md) Irsk | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japansk | [jw Wong jawa] (/. github / README_JW.md) Javanesisk | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kasakhisk | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-syd 韓國 語] (/. github / README_KO_SOUTH.md) Koreansk (Syd) | [ko-nord 문화어] (README_KO_NORTH.md) Koreansk (Nord) (IKKE OVERSAT) | [ku Kurdî] (/. github / README_KU.md) Kurdisk (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgisisk | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Litauisk | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxembourgsk | [mk Македонски] (/. github / README_MK.md) Makedonsk | [mg madagaskisk] (/. github / README_MG.md) madagaskisk | [ms Bahasa Melayu] (/. github / README_MS.md) Malaysisk | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltesisk | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolsk | [min မြန်မာ] (/. github / README_MY.md) Myanmar (burmesisk) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) Norsk | [eller ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persisk [pl polski] (/. github / README_PL.md) Polsk | [pt português] (/. github / README_PT.md) Portugisisk | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Ingen tilgængelige sprog, der starter med bogstavet Q | [ro Română] (/. github / README_RO.md) Rumænsk | [ru русский] (/. github / README_RU.md) Russisk | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Skotsk gælisk | [sr Српски] (/. github / README_SR.md) Serbisk | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovakisk | [sl Slovenščina] (/. github / README_SL.md) Slovensk | [så Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spansk | [su Sundanis] (/. github / README_SU.md) Sundanesisk | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Svensk | [tg Тоҷикӣ] (/. github / README_TG.md) Tadsjikisk | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatarisk | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github /README_TR.md) Tyrkisk | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukrainsk | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Usbekisk | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamesisk | [cy Cymraeg] (/. github / README_CY.md) Walisisk | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jiddisk | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Fås på 110 sprog (108 når der ikke tælles engelsk og nordkoreansk, da nordkoreansk endnu ikke er oversat [Læs om det her] (/ OldVersions / koreansk (nord ) /README.md))

Oversættelser på andre sprog end engelsk er maskinoversat og er endnu ikke korrekte. Ingen fejl er rettet endnu den 5. februar 2021. Rapporter venligst oversættelsesfejl [her] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) Sørg for at tage backup af din rettelse med kilder og guide mig, da jeg ikke kender andre sprog end engelsk godt (jeg planlægger at få en oversætter til sidst) bedes du citere [wiktionary] (https://en.wiktionary.org) og andre kilder i din rapport. Hvis du ikke gør det, vil en afvisning af rettelsen blive offentliggjort.

Bemærk: på grund af begrænsninger med GitHubs fortolkning af markdown (og stort set alle andre webbaserede fortolkninger af markdown), klikker disse links dig til en separat fil på en separat side, der ikke er min GitHub-profilside. Du vil blive omdirigeret til [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), hvor README er hostet.

Oversættelser foretages med Google Translate på grund af begrænset eller ingen support til de sprog, jeg har brug for i andre oversættelsestjenester som DeepL og Bing Translate (ret ironisk for en anti-Google-kampagne) Jeg arbejder på at finde et alternativ. Af en eller anden grund er formateringen (links, skillevægge, fed skrift, kursiv osv.) Rodet i forskellige oversættelser. Det er kedeligt at rette, og jeg ved ikke, hvordan jeg løser disse problemer på sprog med ikke-latinske tegn, og højre til venstre sprog (som arabisk) er der brug for ekstra hjælp til at løse disse problemer

På grund af vedligeholdelsesproblemer er mange oversættelser forældede og bruger en forældet version af denne `README`-artikelfil. En oversætter er nødvendig. Fra den 23. april 2021 vil det også tage mig et stykke tid at få alle de nye links til at fungere.

***

# Det er tid til at skære Widevine

Dette er en artikel om, hvorfor du skal stoppe med at bruge Google WideVine (DRM) og afinstallere den. DRM skal fjernes. Denne artikel hjælper dig med at træffe dit valg (hvis du ikke allerede har gjort det) WideVine er meget konkurrencebegrænsende og ekstremt restriktiv og ødelægger friheden for videoer på Internettet.

Lad os klippe WideVine og omfavne et åbent internet.

***

# Indeks

[00.0 - Top] (# Top)

> [00.1 - Læs denne artikel på et andet sprog]

> [00.2 - Titel] (# Det er tid til at skære-Widevine)

> [00.3 - Indeks] (# Indeks)

[01.0 - Oversigt] (# Oversigt)

[02.0 - Konkurrencebegrænsende] (# Konkurrencebegrænsende)

[03.0 - Manglende frihed] (# Manglende frihed)

[04.0 - Hukommelsesforbrug] (# Hukommelsesforbrug)

[05.0 - Privacy] (# Privacy)

[06.0 - Alternative metoder] (# Alternative-metoder)

[07.0 - Hvad du kan gøre for at hjælpe] (# Hvad-du-kan-gøre-for-hjælp)

[08.0 - Andre ting at tjekke ud] (# Andre-ting-at-tjekke ud)

[09.0 - Artikel info] (# Article-info)

> [09.0.1 - Software status] (# Software-status)

> [09.0.2 - Sponsoroplysninger] (# Sponsorinfo)

[10.0 - Filhistorik] (# Filhistorik)

[11.0 - Sidefod] (# sidefod)

> [11.9 - EOF] (# EOF)

***

## Oversigt

For yderligere information om hvorfor DRM er et problem, [klik her] (https://www.defectivebydesign.org/)

***

## Konkurrencebegrænsende

WideVine er en DRM, der skal licenseres til at blive brugt sammen med en browser. Google er ekstremt langsom med at gennemgå og acceptere mennesker og nægter ofte folk at bruge det i deres produkter uden nogen begrundelse. [Kilde 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Kilde 2 (e-mail-tråden, der fortsatte i over 4 måneder og resulterede i intet andet end skuffelse)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google har gjort det meget sværere for browsere som Brave eller Firefox at konkurrere med sit skub af dette stykke DRM.

***

## Manglende frihed

WideVine bruges til at forhindre brugere i at interagere med video på websteder. Det er en form for digitale begrænsningsledelser, der forhindrer dig i at downloade videoen, se videoen offline eller endda tage et skærmbillede. Det er proprietær software, og på grund af dets problemer med privatliv er det ikke installeret som standard på de fleste Linux-distributioner. Det begrænser friheden på nettet på grund af dets brug af Netflix-, Disney- og YouTube-film. Din adgang til indholdet kan fjernes når som helst uden grund.

***

## Hukommelsesforbrug

WideVine har dårlig hukommelse. Sammenlignet med normalt at se en video uden DRM, bruger WideVine store mængder CPU og RAM. Det er dårligt på baliv, og det giver ingen fordele ved standard HTML5-videoafspilning.

***

## Privatliv

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (overvågningsprogram)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) [s ](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / hvorfor-googles-spionere-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritik) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -prøver / intet-at-skjule-argument-har-intet-at-sige /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-om-dig-du-kan-finde-og-slette-det-nu /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -og) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html) [d ](https://www.reuters.com/article/us-alphabet- google-privatliv-retssag-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-indsamling-på-uddannelse-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html) [o ](https://en.wikipedia.org/wiki/2018_Google_data_breach) [m ](https:// moz.com/bl og / hvor-gør-google-tegner-data-indsamlingslinjen) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- hævder på vegne af 5 millioner iphone-brugere) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) [e ](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -telefon-er ikke i brug /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technolo gy / 2014/01 / hvad-google-kan-virkelig-gøre-med-rede-eller-virkelig-rede-data /) [i] (https://www.cbsnews.com/news/google-education-spies -på-indsamler-data-om-millioner-af-børn-påstande-retssag-nyt-mexico-advokat-general /) [v] (https://www.nationalreview.com/2018/04/the-student- data-mining-skandale-under-vores-næser /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) [y ](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -noget at skjule-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Jeg kunne fortsætte med at bevise dette , men det tog lang tid at finde og gennemgå alle disse artikler)

Privatliv er ikke noget med WideVine. Proprietær software er designet, så du slet ikke kan se, hvad der foregår. Med Googles historie er det meget sandsynligt, atWideVine er et ekstra stykke software, der spionerer på dig, læser dine dokumenter og andre dårlige ting.

Hvis du tror, ​​du ikke har noget at skjule, ** har du helt forkert **. Dette argument er blevet debunkeret mange gange:

[Via Wikipedia] (https://en.wikipedia.org/wiki/Intet_til_hide_argument#Kritik)

1. Edward Snowden bemærkede "At argumentere for, at du ikke er ligeglad med retten til privatliv, fordi du ikke har noget at skjule, er ikke anderledes end at sige, at du ikke er ligeglad med ytringsfriheden, fordi du ikke har noget at sige." Når du siger, ' Jeg har ikke noget at skjule, 'siger du,' jeg er ligeglad med denne ret. 'Du siger,' jeg har ikke denne ret, for jeg er nået til det punkt, hvor jeg skal retfærdiggøre det. 'Sådan som rettigheder fungerer, er regeringen nødt til at retfærdiggøre sin indtrængen i dine rettigheder. "

2. Daniel J. Solove erklærede i en artikel for The Chronicle of Higher Education, at han er imod argumentet; han erklærede, at en regering kan lække oplysninger om en person og forårsage skade på den pågældende person, eller bruge oplysninger om en person til at nægte adgang til tjenester, selvom en person ikke rent faktisk har begået forseelser, og at en regering kan forårsage skade på ens personlige livet ved at lave fejl. Solove skrev "Når intet-til-skjul-argumentet er engageret direkte, kan det blive fængslet, for det tvinger debatten til at fokusere på dens snævre forståelse af privatlivets fred. Men når den konfronteres med de mange privatlivsproblemer, der er impliceret af regeringsdataindsamling og -brug ud over overvågning og afsløring, argumentet intet at skjule, har i sidste ende intet at sige. "

3. Adam D. Moore, forfatter af Privacy Rights: Moral and Legal Foundations, hævdede, "det er den opfattelse, at rettigheder er modstandsdygtige over for omkostninger / fordele eller konsekventistiske argumenter. Her afviser vi synspunktet om, at privatlivets interesser er de slags af ting, der kan handles for sikkerhed. " Han sagde også, at overvågning uforholdsmæssigt kan påvirke visse grupper i samfundet baseret på udseende, etnicitet, seksualitet og religion.

4. Bruce Schneier, en computersikkerhedsekspert og kryptograf, udtrykte modstand og citerede kardinal Richelieus erklæring "Hvis man ville give mig seks linjer skrevet af den ærligste mand, ville jeg finde noget i dem for at få ham hængt op", med henvisning til hvordan en statsregering kan finde aspekter i en persons liv for at retsforfølge eller afpresse vedkommende. Schneier argumenterede også for "for mange karakteriserer debatten fejlagtigt som 'sikkerhed versus privatliv.' Det virkelige valg er frihed kontra kontrol. "

5. Harvey A. Silverglate vurderede, at den almindelige person i gennemsnit uforvarende begår tre forbrydelser om dagen i USA.

6. Emilio Mordini, filosof og psykoanalytiker, argumenterede for, at argumentet om "intet at skjule" er i sagens natur paradoksalt. Folk behøver ikke at have "noget at skjule" for at skjule "noget". Det skjulte er ikke nødvendigvis relevant, hævder Mordini. I stedet argumenterer han for, at et intimt område, der både kan skjules, og adgangsbegrænset er nødvendigt, da vi psykologisk set bliver enkeltpersoner gennem opdagelsen af, at vi kunne skjule noget for andre.

7. Julian Assange sagde "Der er endnu ikke noget dræbende svar. Jacob Appelbaum (@ioerror) har et klogt svar og beder folk, der siger dette, om derefter at give ham deres telefon ulåst og trække ned deres bukser. Min version af det vil sige, 'Nå, hvis du er så kedelig, så skal vi ikke tale med dig, og heller ikke nogen anden', men filosofisk er det virkelige svar dette: Masseovervågning er en strukturel strukturændring. Når samfundet går dårligt, går det at tage dig med det, selvom du er den blideste person på jorden. "

8. Ignacio Cofone, professor i jura, argumenterer for, at argumentet forveksles med sine egne udtryk, fordi når folk videregiver relevant information til andre, afslører de også irrelevante oplysninger. Disse irrelevante oplysninger har privatlivets omkostninger og kan føre til andre skader, såsom diskrimination.

***

# Alternative metoder

Medier bør ikke være begrænset, online eller offline. Hvis folk ville se videoen uden DRM, vil de altid finde en måde at gøre det på. Hvert stykke software kan knækkes.

[modificeret uddrag fra Wikipedia] Ventilpræsident Gabe Newell har udtalt, at "de fleste DRM-strategier er bare dumme", fordi de kun mindsker værdien af ​​et spil i forbrugerens øjne. Newell foreslår, at målet i stedet skal være "[skabe] større værdi for kunder gennem serviceværdi". Bemærk, at Valve driver Steam, en tjeneste, der fungerer som en onlinebutik til pc-spil, samt en social netværkstjeneste og en DRM-platform

Dette punkt er ikke gyldigt kun til videospil, det kan anvendes på alt på en computer. Din computer skal ikke have fuld kontrol over en skør virksomhed, der bruger dårlig kunstig intelligens til at slette sine brugere og deres arbejde (YouTube osv.) Og har så dårlig rekord. Din computer bør ikke begrænses, fordi en virksomhed nægter at dele som et dårligt opført barn. Din computer skal ejes af dig,og ingen andre. Du skal slippe af med DRM helt, da indholdet ikke er værd at opgive kontrol over din computer til. Disse virksomheder har hundreder af milliarder dollars. Hvis de gør noget dumt som dette, skal du protestere mod det. Du kan endda bare downloade videoen et andet sted og se den, da de skulle miste penge for at lave dumme ting som denne. Krænkelse af ophavsretten er ikke en dårlig ting. Folk, der ikke har råd til film, downloader dem andre steder, det har været siden starten af ​​det globale internet og med opfindelsen af ​​VHS-båndet. Det påvirker næppe deres indtægter, da de alligevel ikke kunne få de penge. DRM er defekt af design.

***

## Hvad du kan gøre for at hjælpe

Du kan protestere mod DRM. Det kan synes ubetydeligt, men jo flere mennesker der går imod det, jo mere gøres der ved det.

Hvis du bruger Linux, skal du sørge for, at DRM ikke er installeret (det er normalt ikke som standard) og ikke gider at installere det.

Hvis du bruger Windows eller MacOS, har du muligvis en meget sværere tid, da DRM er installeret som standard på disse systemer og muligvis geninstallerer automatisk.

Prøv at undgå følgende sider:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Dybest set bør næsten enhver online videostreamingtjeneste undgås, da de fleste af dem bruger DRM, og du ikke kan bruge webstedet uden at miste din frihed. Det er det ikke værd. Send [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) en besked, og stop med at streame disse shows.

Du bør også undgå enhver mulighed for "gratis med annoncer" på følgende websteder (da denne metode kræver DRM)

[YouTube] (https://www.youtube.com)

Du kan også protestere mod DRM med en besked på dine projekter 'README.md`-fil. Her er hvad jeg bruger:

`` markdown

***

## Software status

Alle mine værker er gratis nogle begrænsninger. DRM (** D ** igital ** R ** estrictions ** M ** anagement) er ikke til stede i nogen af ​​mine værker.

! [DRM-fri_label.en.svg] (DRM-fri_label.en.svg)

Dette mærkat understøttes af Free Software Foundation. Jeg har aldrig til hensigt at medtage DRM i mine værker.

Jeg bruger forkortelsen "Digital Restrictions Management" i stedet for den mere kendte "Digital Rights Management", da den almindelige måde at adressere den på er falsk, der er ingen rettigheder til DRM. Stavemåden "Digital Restrictions Management" er mere nøjagtig og understøttes af [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) og [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Dette afsnit bruges til at øge bevidstheden om problemerne med DRM og også til at protestere mod det. DRM er defekt af design og er en stor trussel mod alle computerbrugere og softwarefrihed.

Billedkredit: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

`` ''

***
## Andre ting at tjekke ud

[Defekt ved design - En kampagne fra Free Software Foundation, der arbejder på at udsætte og eliminere DRM-brug] (https://www.defectivebydesign.org/)

[Google Graveyard (killedbygoogle.com) - en sorteret liste over de 224+ produkter, Google har dræbt] (https://killedbygoogle.com/)

> [GitHub-link] (https://github.com/codyogden/killedbygoogle)

[Alfabetarbejderforening - Den nye arbejderforening på Google med over 800 medlemmer] (https://alphabetworkersunion.org/people/our-union/)

Der er andre suppleanter, bare søg efter dem.

***

## Artikelinfo

Filtype: 'Markdown (* .md)'

Filversion: `` 4 (fredag ​​23. april 2021 kl. 15:35) '

Linjetælling (inklusive tomme linjer og kompileringslinje): `354`

### Software status

Alle mine værker er fri for begrænsninger. DRM (** D ** igital ** R ** estrictions ** M ** anagement) er ikke til stede i nogen af ​​mine værker. Dette projekt indeholder ikke nogen DRM, men det taler direkte om DRM.

! [DRM-fri_label.en.svg] (DRM-fri_label.en.svg)

Dette mærkat understøttes af Free Software Foundation. Jeg har aldrig til hensigt at medtage DRM i mine værker.

***

### Sponsorinformation

! [SponsorButton.png] (SponsorButton.png) <- Dette er ikke den officielle sponsorknap, det er et demo-billede. Klik ikke på det, hvis du vil sponsorere dette projekt.

Du kan sponsorere dette projekt, hvis du vil, men angiv venligst, hvad du vil donere til. [Se de midler, du kan donere til her] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Du kan se anden sponsorinformation [her] (https://github.com/seanpm2001/Sponsor-info/)

Prøve det! Sponsorknappen er lige ved siden af ​​uret / uret-knappen.

***

## Filhistorik

Version 1 (søndag 8. februar 2021 kl. 16.41)

> Ændringer:

> * Startede filen / artiklen

> * Tilføjede titelsektionen

> * Tilføjet et afsnit om privatlivets fred

> * Tilføjet et afsnit om oversigten

> * Tilføjede artiklen info sektion

> * Henviste til DRM Free-ikonet

> * Tilføjede filhistorik sektionen

> * Tilføjede sektionen Mangel på frihed

> * Tilføjede sektionen Konkurrencebegrænsende

> * Tilføjede afsnittet om alternative metoder

> * Tilføjet notatetry brug sektion

> * Tilføjet de andre ting at tjekke ud sektion

> * Tilføjet indekset

> * Tilføjet sidefoden

> * Ingen andre ændringer i version 1

Version 2 (torsdag 8. april 2021 kl. 17:18)

> Ændringer:

> * Opdateret titelsektionen

> * Opdateret indekset

> * Tilføjet info om, hvad du kan gøre for at hjælpe

> * Tilføjet sektionen om sponsorinfo

> * Opdateret filinfosektionen

> * Opdateret sektionen med filhistorik

> * Ingen andre ændringer i version 2

Version 3 (torsdag 8. april 2021 kl. 17:27)

> Ændringer:

> * Faste oversættelseslinks

> * Opdateret indekset

> * Rettet en duplikat, uden emneindtastning i afsnittet `hvad du kan gøre for at hjælpe`

> * Opdateret sektionen om sponsorinfo

> * Opdateret filinfosektionen

> * Opdateret sektionen med filhistorik

> * Ingen andre ændringer i version 3

Version 4 (fredag ​​23. april 2021 kl. 15:35)

> Ændringer:

> * Opdateret listen over sprogomskiftere

> * Opdateret filinfosektionen

> * Opdateret sektionen med filhistorik

> * Ingen andre ændringer i version 4

Version 5 (Kommer snart)

> Ændringer:

> * Kommer snart

> * Ingen andre ændringer i version 5

Version 6 (Kommer snart)

> Ændringer:

> * Kommer snart

> * Ingen andre ændringer i version 6

Version 7 (Kommer snart)

> Ændringer:

> * Kommer snart

> * Ingen andre ændringer i version 7

Version 8 (Kommer snart)

> Ændringer:

> * Kommer snart

> * Ingen andre ændringer i version 8

***

## Sidefod

Du har nået slutningen af ​​denne fil!

##### EOF

***
