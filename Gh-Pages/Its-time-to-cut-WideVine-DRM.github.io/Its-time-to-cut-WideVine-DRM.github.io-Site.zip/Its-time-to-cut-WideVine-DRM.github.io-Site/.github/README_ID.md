***

##### Atas

_Baca artikel ini dalam bahasa lain: _

** Bahasa saat ini adalah: ** `` English (US) `_ (terjemahan mungkin perlu diperbaiki untuk memperbaiki bahasa Inggris menggantikan bahasa yang benar) _

_🌐 Daftar bahasa_

** Diurutkan berdasarkan: ** `A-Z`

[Opsi penyortiran tidak tersedia] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albania | [am አማርኛ] (/. github / README_AM.md) Amharik | [ar عربى] (/.github/README_AR.md) Arab | [hy հայերեն] (/. github / README_HY.md) Armenia | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijan | [eu Euskara] (/. github /README_EU.md) Basque | [be Беларуская] (/. Github / README_BE.md) Belarusia | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) Bulgaria | [ca Català] (/. Github / README_CA.md) Catalan | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) China (Sederhana) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) China (Tradisional) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Kroasia | [cs čeština] (/. Github / README_CS .md) Ceko | [da dansk] (README_DA.md) Denmark | [nl Nederlands] (/. github / README_ NL.md) Belanda | [** en-us English **] (/. github / README.md) Inggris | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonia | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finlandia | [fr français] (/. github / README_FR.md) Prancis | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galisia | [ka ქართველი] (/. github / README_KA) Georgia | [de Deutsch] (/. github / README_DE.md) Jerman | [el Ελληνικά] (/. github / README_EL.md) Yunani | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Kreol Haiti | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) Ibrani | [hai हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hungaria | [adalah Íslenska] (/. github / README_IS.md) Islandia | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandia | [ga Gaeilge] (/. github / README_GA.md) Irlandia | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Jepang | [jw Wong jawa] (/. github / README_JW.md) Jawa | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Korea (Selatan) | [ko-north 문화어] (README_KO_NORTH.md) Korea (Utara) (BELUM DITERJEMAHKAN) | [ku Kurdî] (/. github / README_KU.md) Kurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgistan | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Lituavi | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksemburg | [mk Македонски] (/. github / README_MK.md) Makedonia | [mg Malagasi] (/. github / README_MG.md) Malagasi | [ms Bahasa Melayu] (/. github / README_MS.md) Melayu | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Malta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolia | [မြန်မာ saya] (/. github / README_MY.md) Myanmar (Burma) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) Norsk | [atau ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persia [pl polski] (/. github / README_PL.md) Polandia | [pt português] (/. github / README_PT.md) Portugis | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Tidak ada bahasa yang dimulai dengan huruf Q | [ro Română] (/. github / README_RO.md) Rumania | [ru русский] (/. github / README_RU.md) Rusia | [sm Faasamoa] (/. github / README_SM.md) Samoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Gaelik Skotlandia | [sr Српски] (/. github / README_SR.md) Serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slowakia | [sl Slovenščina] (/. github / README_SL.md) Slovenia | [jadi Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spanyol | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Swensk | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github /README_TR.md) Turki | [tk Türkmenler] (/. github / README_TK.md) Turkmenistan | [uk Український] (/. github / README_UK.md) Ukraina | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Vietnam | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Tersedia dalam 110 bahasa (108 jika tidak termasuk Inggris dan Korea Utara, karena Korea Utara belum diterjemahkan [Baca tentang itu di sini] (/ Versi Lama / Korea (Utara ) /README.md))

Terjemahan dalam bahasa selain bahasa Inggris adalah terjemahan mesin dan belum akurat. Belum ada kesalahan yang diperbaiki per 5 Februari 2021. Laporkan kesalahan terjemahan [di sini] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) pastikan untuk mencadangkan koreksi Anda dengan sumber dan bimbing saya, karena saya tidak tahu bahasa selain bahasa Inggris dengan baik (saya berencana untuk mendapatkan penerjemah pada akhirnya) harap kutip [wiktionary] (https://en.wiktionary.org) dan sumber lain dalam laporan Anda. Gagal melakukannya akan mengakibatkan penolakan publikasi koreksi.

Catatan: karena keterbatasan interpretasi GitHub tentang penurunan harga (dan hampir semua interpretasi penurunan harga berbasis web lainnya) mengklik tautan ini akan mengarahkan Anda ke file terpisah di halaman terpisah yang bukan halaman profil GitHub saya. Anda akan dialihkan ke [repositori seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), tempat README dihosting.

Terjemahan dilakukan dengan Google Translate karena terbatas atau tidak ada dukungan untuk bahasa yang saya butuhkan di layanan terjemahan lain seperti DeepL dan Bing Translate (cukup ironis untuk kampanye anti-Google) Saya sedang mencari alternatif. Untuk beberapa alasan, pemformatan (tautan, pemisah, cetak tebal, miring, dll.) Kacau dalam berbagai terjemahan. Membosankan untuk memperbaikinya, dan saya tidak tahu cara memperbaiki masalah ini dalam bahasa dengan karakter non-latin, dan bahasa kanan ke kiri (seperti bahasa Arab) diperlukan bantuan tambahan untuk memperbaiki masalah ini.

Karena masalah pemeliharaan, banyak terjemahan yang kedaluwarsa dan menggunakan versi lama dari file artikel `README` ini. Seorang penerjemah dibutuhkan. Selain itu, mulai 23 April 2021, saya butuh waktu beberapa saat untuk membuat semua tautan baru berfungsi.

***

# Saatnya memotong Widevine

Ini adalah artikel tentang mengapa Anda harus berhenti menggunakan Google WideVine (DRM) dan menghapusnya. DRM perlu dihapus. Artikel ini akan membantu Anda menentukan pilihan (jika Anda belum melakukannya) WideVine sangat anti-persaingan, dan sangat membatasi, dan menghancurkan kebebasan video di Internet.

Mari memotong WideVine dan merangkul Internet terbuka.

***

# Indeks

[00.0 - Atas] (# Atas)

> [00.1 - Baca artikel ini dalam bahasa lain]

> [00.2 - Judul] (# It-is-time-to-cut-Widevine)

> [00.3 - Indeks] (# Indeks)

[01.0 - Ringkasan] (# Ringkasan)

[02.0 - Anti-kompetitif] (# Anti-kompetitif)

[03.0 - Kurangnya kebebasan] (# Kurangnya kebebasan)

[04.0 - Penggunaan memori] (# Penggunaan memori)

[05.0 - Privasi] (# Privasi)

[06.0 - Metode alternatif] (# Metode alternatif)

[07.0 - Apa yang dapat Anda lakukan untuk membantu] (# What-you-can-do-to-help)

[08.0 - Hal lain untuk diperiksa] (# Hal-lain-untuk-check-out)

[09.0 - Info artikel] (# Info-artikel)

> [09.0.1 - Status perangkat lunak] (# Status-perangkat lunak)

> [09.0.2 - Info sponsor] (# Info-Sponsor)

[10.0 - Riwayat file] (# Riwayat file)

[11.0 - Footer] (# Footer)

> [11,9 - EOF] (# EOF)

***

## Gambaran

Untuk informasi lain tentang mengapa DRM menjadi masalah, [klik di sini] (https://www.defectivebydesign.org/)

***

## Anti-kompetitif

WideVine adalah DRM yang harus memiliki lisensi untuk digunakan dengan browser. Google sangat lambat dalam meninjau dan menerima orang, dan sering kali menolak orang untuk menggunakannya di produk mereka tanpa alasan. [Sumber 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Sumber 2 (untaian email yang berlangsung selama lebih dari 4 bulan dan hanya menghasilkan kekecewaan)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google telah mempersulit browser seperti Brave atau Firefox untuk bersaing dalam mendorong DRM ini.

***

## Kurangnya kebebasan

WideVine digunakan untuk mencegah pengguna berinteraksi dengan video di situs web. Ini adalah bentuk manajemen batasan digital yang mencegah Anda mengunduh video, melihat video secara offline, atau bahkan mengambil tangkapan layar. Ini adalah perangkat lunak berpemilik dan karena masalah privasi, itu tidak diinstal secara default di sebagian besar distribusi Linux. Itu membatasi kebebasan web karena digunakan oleh film Netflix, Disney, dan YouTube. Akses Anda ke konten dapat dicabut kapan saja tanpa alasan.

***

## Penggunaan memori

WideVine buruk dalam memori. Dibandingkan dengan hanya menonton video tanpa DRM, WideVine akan menggunakan CPU dan RAM dalam jumlah besar. Ini buruk di batahan baterai, dan tidak memberikan manfaat dari pemutaran video HTML5 standar.

***

## Privasi

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritik) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-tentang-Anda-Anda-dapat-menemukan-dan-menghapus-sekarang /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -dan) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- klaim-atas-nama-5-juta-pengguna-iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / informasi-technolo gy / 2014/01 / what-google-can-really-do-with-nest-or-really-nests-data /) [i] (https://www.cbsnews.com/news/google-education-spies -on-collects-data-on-million-of-kids-alleges-lawsuit-new-mexico-attorney-general /) [v] (https://www.nationalreview.com/2018/04/the-student- data-mining-scandal-under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Saya dapat melanjutkan dan melanjutkan dengan bukti ini , tapi butuh waktu lama untuk menemukan dan membaca semua artikel ini)

Privasi bukanlah masalah dengan WideVine. Perangkat lunak berpemilik dirancang sedemikian rupa sehingga Anda tidak dapat melihat apa yang sedang terjadi sama sekali. Dengan riwayat Google, kemungkinan besar begituWideVine adalah perangkat lunak tambahan yang memata-matai Anda, membaca dokumen Anda, dan hal-hal buruk lainnya.

Jika Anda merasa tidak ada yang perlu disembunyikan, ** Anda salah **. Argumen ini telah dibantah berkali-kali:

[Melalui Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden berkomentar "Mendebat bahwa Anda tidak peduli tentang hak privasi karena Anda tidak memiliki apa pun untuk disembunyikan tidak berbeda dengan mengatakan Anda tidak peduli dengan kebebasan berbicara karena Anda tidak memiliki apa-apa untuk dikatakan." Ketika Anda mengatakan, ' Saya tidak menyembunyikan apa pun, 'Anda berkata,' Saya tidak peduli tentang hak ini. 'Anda berkata,' Saya tidak memiliki hak ini, karena saya sudah sampai pada titik di mana saya harus membenarkan. itu. 'Cara kerja hak adalah, pemerintah harus membenarkan gangguannya terhadap hak-hak Anda. "

2. Daniel J. Solove menyatakan dalam sebuah artikel untuk The Chronicle of Higher Education bahwa ia menentang argumen tersebut; dia menyatakan bahwa pemerintah dapat membocorkan informasi tentang seseorang dan menyebabkan kerusakan pada orang itu, atau menggunakan informasi tentang seseorang untuk menolak akses ke layanan bahkan jika seseorang tidak benar-benar melakukan kesalahan, dan bahwa pemerintah dapat menyebabkan kerusakan pada pribadi seseorang. hidup dengan membuat kesalahan. Solove menulis, "Ketika terlibat secara langsung, argumen tidak ada yang disembunyikan dapat menjerat, karena memaksa debat untuk fokus pada pemahaman sempitnya tentang privasi. Tetapi ketika dihadapkan dengan pluralitas masalah privasi yang terkait dengan pengumpulan dan penggunaan data pemerintah di luar pengawasan dan pengungkapan, argumen tidak ada yang disembunyikan, pada akhirnya, tidak memiliki apa-apa untuk dikatakan. "

3. Adam D. Moore, penulis Privacy Rights: Moral and Legal Foundations, berpendapat, "ini adalah pandangan bahwa hak tahan terhadap biaya / manfaat atau semacam argumen konsekuensialis. Di sini kami menolak pandangan bahwa kepentingan privasi adalah semacam itu. hal-hal yang dapat diperdagangkan untuk keamanan. " Dia juga menyatakan bahwa pengawasan dapat mempengaruhi kelompok tertentu dalam masyarakat secara tidak proporsional berdasarkan penampilan, etnis, seksualitas, dan agama.

4. Bruce Schneier, seorang ahli keamanan komputer dan kriptografer, menyatakan penolakannya, mengutip pernyataan Kardinal Richelieu "Jika seseorang memberi saya enam baris yang ditulis oleh tangan orang yang paling jujur, saya akan menemukan sesuatu di dalamnya untuk membuatnya digantung", merujuk tentang bagaimana pemerintah negara bagian dapat menemukan aspek-aspek dalam kehidupan seseorang untuk menuntut atau memeras individu tersebut. Schneier juga berpendapat, "Terlalu banyak yang secara keliru menggolongkan perdebatan sebagai 'keamanan versus privasi.' Pilihan sebenarnya adalah kebebasan versus kendali. "

5. Harvey A. Silverglate memperkirakan bahwa orang biasa, rata-rata, tanpa sadar melakukan tiga kejahatan sehari di AS.

6. Emilio Mordini, filsuf dan psikoanalis, berpendapat bahwa argumen "tidak ada yang disembunyikan" pada dasarnya bersifat paradoks. Orang tidak perlu memiliki "sesuatu yang disembunyikan" untuk menyembunyikan "sesuatu". Apa yang disembunyikan belum tentu relevan, klaim Mordini. Sebaliknya, dia berpendapat bahwa area intim yang dapat disembunyikan dan akses dibatasi diperlukan karena, secara psikologis, kita menjadi individu melalui penemuan bahwa kita dapat menyembunyikan sesuatu kepada orang lain.

7. Julian Assange menyatakan "Belum ada jawaban yang mematikan. Jacob Appelbaum (@ioerror) memiliki tanggapan yang cerdas, meminta orang-orang yang mengatakan ini untuk kemudian menyerahkan ponsel mereka tidak terkunci dan menurunkan celananya. Versi saya adalah mengatakan, 'well, jika kamu begitu membosankan maka kami tidak boleh berbicara denganmu, begitu juga dengan orang lain', tetapi secara filosofis, jawaban sebenarnya adalah ini: Pengawasan massal adalah perubahan struktural massal. Ketika masyarakat memburuk, itu akan terjadi untuk membawamu bersamanya, bahkan jika kamu adalah orang paling hambar di dunia. "

8. Ignacio Cofone, profesor hukum, berpendapat bahwa argumen tersebut salah dalam istilahnya sendiri karena, setiap kali orang mengungkapkan informasi yang relevan kepada orang lain, mereka juga mengungkapkan informasi yang tidak relevan. Informasi yang tidak relevan ini memiliki biaya privasi dan dapat menyebabkan kerugian lain, seperti diskriminasi.

***

# Metode alternatif

Media tidak boleh dibatasi, online atau offline. Jika orang ingin menonton video tanpa DRM, mereka akan selalu menemukan cara untuk melakukannya. Setiap perangkat lunak dapat di-crack.

[kutipan yang dimodifikasi dari Wikipedia] Presiden Valve Gabe Newell telah menyatakan "sebagian besar strategi DRM hanya bodoh" karena mereka hanya menurunkan nilai permainan di mata konsumen. Newell menyarankan bahwa sasarannya seharusnya "[menciptakan] nilai yang lebih besar bagi pelanggan melalui nilai layanan". Perhatikan bahwa Valve mengoperasikan Steam, layanan yang berfungsi sebagai toko online untuk game PC, serta layanan jejaring sosial dan platform DRM

Poin ini tidak hanya berlaku untuk gim video, tetapi dapat diterapkan pada apa pun di komputer. Komputer Anda seharusnya tidak memiliki kendali penuh atas perusahaan gila yang menggunakan Artificial Intelligence yang buruk untuk menghapus penggunanya dan pekerjaan mereka (YouTube, dll.) Dan memiliki catatan yang buruk. Komputer Anda tidak boleh dibatasi karena sebuah perusahaan menolak untuk berbagi seperti anak yang berperilaku buruk. Komputer Anda harus menjadi milik Anda,dan tidak ada orang lain. Anda harus menyingkirkan DRM sama sekali, karena kontennya tidak layak untuk dilepaskan dari kendali komputer Anda. Perusahaan-perusahaan ini memiliki ratusan miliar dolar. Jika mereka melakukan sesuatu yang bodoh seperti ini, Anda harus memprotesnya. Anda bahkan dapat mengunduh videonya di tempat lain dan melihatnya, karena mereka akan kehilangan uang karena melakukan hal-hal bodoh seperti ini. Pelanggaran hak cipta bukanlah hal yang buruk. Orang-orang yang tidak mampu membeli film akan mengunduhnya di tempat lain, itu telah terjadi sejak dimulainya Internet global dan dengan penemuan pita VHS. Ini hampir tidak mempengaruhi pendapatan mereka, karena mereka tidak akan bisa mendapatkan uang itu. DRM cacat menurut desain.

***

## Apa yang dapat Anda lakukan untuk membantu

Anda dapat memprotes DRM. Ini mungkin tampak tidak penting, tetapi semakin banyak orang yang menentangnya, semakin banyak yang dilakukan untuk mengatasinya.

Jika Anda menggunakan Linux dan menggunakan Firefox, pastikan DRM tidak diinstal (biasanya tidak secara default) dan jangan repot-repot menginstalnya.

Jika Anda menggunakan Windows atau MacOS, Anda mungkin mengalami kesulitan, karena DRM diinstal secara default di sistem ini, dan dapat diinstal ulang secara otomatis.

Cobalah untuk menghindari situs-situs berikut:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Pada dasarnya, hampir semua layanan streaming video online harus dihindari, karena mayoritas dari mereka menggunakan DRM dan Anda tidak dapat menggunakan situs tanpa kehilangan kebebasan Anda. Itu tidak layak. Kirim pesan ke [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) dan hentikan streaming acara ini.

Anda juga harus menghindari opsi "gratis dengan iklan" di situs berikut (karena metode ini memerlukan DRM)

[YouTube] (https://www.youtube.com)

Anda juga dapat memprotes DRM dengan pesan pada file `README.md` proyek Anda. Inilah yang saya gunakan:

`` penurunan harga

***

## Status perangkat lunak

Semua karya saya bebas beberapa batasan. DRM (** D ** igital ** R ** estrictions ** M ** anagement) tidak ada di semua karya saya.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Stiker ini didukung oleh Free Software Foundation. Saya tidak pernah berniat untuk memasukkan DRM ke dalam karya saya.

Saya menggunakan singkatan "Digital Restrictions Management" daripada yang lebih dikenal "Digital Rights Management" karena cara umum untuk mengatasinya salah, tidak ada hak dengan DRM. Ejaan "Digital Restrictions Management" lebih akurat, dan didukung oleh [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) dan [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Bagian ini digunakan untuk meningkatkan kesadaran akan masalah DRM, dan juga untuk memprotesnya. DRM memiliki desain yang rusak dan merupakan ancaman utama bagi semua pengguna komputer dan kebebasan perangkat lunak.

Kredit gambar: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

``

***
## Hal-hal lain untuk diperiksa

[Rusak menurut desain - Kampanye oleh Free Software Foundation yang berupaya mengungkap dan menghapus penggunaan DRM] (https://www.defectivebydesign.org/)

[The Google Graveyard (killbygoogle.com) - daftar yang diurutkan dari 224+ produk yang telah dibunuh oleh Google] (https://killedbygoogle.com/)

> [Tautan GitHub] (https://github.com/codyogden/killedbygoogle)

[Serikat pekerja alfabet - Serikat pekerja baru di Google dengan lebih dari 800 anggota] (https://alphabetworkersunion.org/people/our-union/)

Ada alternatif lain, cari saja.

***

## Info artikel

Jenis file: `Markdown (* .md)`

Versi file: `4 (Friday, April 23rd 2021 at 3:35 pm)`

Jumlah baris (termasuk baris kosong dan baris penyusun): `354`

### Status perangkat lunak

Semua karya saya bebas dari batasan. DRM (** D ** igital ** R ** estrictions ** M ** anagement) tidak ada di semua karya saya. Proyek ini tidak mengandung DRM, tetapi berbicara tentang DRM secara langsung.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Stiker ini didukung oleh Free Software Foundation. Saya tidak pernah berniat untuk memasukkan DRM ke dalam karya saya.

***

### Info sponsor

! [SponsorButton.png] (SponsorButton.png) <- Ini bukan tombol sponsor resmi, ini adalah gambar demo. Jangan klik jika Anda ingin mensponsori proyek ini.

Anda dapat mensponsori proyek ini jika Anda suka, tetapi harap tentukan tujuan donasi Anda. [Lihat dana yang dapat Anda donasikan ke sini] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Anda dapat melihat info sponsor lainnya [di sini] (https://github.com/seanpm2001/Sponsor-info/)

Cobalah! Tombol sponsor berada tepat di sebelah tombol tonton / buka.

***

## Riwayat file

Versi 1 (Minggu, 8 Februari 2021 pukul 16:41)

> Perubahan:

> * Memulai file / artikel

> * Menambahkan bagian judul

> * Menambahkan bagian tentang privasi

> * Menambahkan bagian tentang ikhtisar

> * Menambahkan bagian info artikel

> * Merujuk ikon DRM Gratis

> * Menambahkan bagian riwayat file

> * Menambahkan bagian Kurangnya kebebasan

> * Menambahkan bagian Anti-persaingan

> * Menambahkan bagian metode alternatif

> * Menambahkan memory penggunaan bagian

> * Menambahkan hal-hal lain untuk diperiksa

> * Menambahkan indeks

> * Menambahkan footer

> * Tidak ada perubahan lain di versi 1

Versi 2 (Kamis, 8 April 2021 pukul 17:18)

> Perubahan:

> * Memperbarui bagian judul

> * Memperbarui indeks

> * Menambahkan info tentang apa yang dapat Anda lakukan untuk membantu

> * Menambahkan bagian info sponsor

> * Memperbarui bagian info file

> * Memperbarui bagian riwayat file

> * Tidak ada perubahan lain di versi 2

Versi 3 (Kamis, 8 April 2021 pukul 17:27)

> Perubahan:

> * Memperbaiki tautan terjemahan

> * Memperbarui indeks

> * Memperbaiki duplikat, entri di luar topik di bagian `apa yang dapat Anda lakukan untuk membantu`

> * Memperbarui bagian info sponsor

> * Memperbarui bagian info file

> * Memperbarui bagian riwayat file

> * Tidak ada perubahan lain di versi 3

Versi 4 (Jumat, 23 April 2021 pukul 15:35)

> Perubahan:

> * Memperbarui daftar pengalih bahasa

> * Memperbarui bagian info file

> * Memperbarui bagian riwayat file

> * Tidak ada perubahan lain di versi 4

Versi 5 (Segera hadir)

> Perubahan:

> * Segera hadir

> * Tidak ada perubahan lain di versi 5

Versi 6 (Segera hadir)

> Perubahan:

> * Segera hadir

> * Tidak ada perubahan lain di versi 6

Versi 7 (Segera hadir)

> Perubahan:

> * Segera hadir

> * Tidak ada perubahan lain di versi 7

Versi 8 (Segera hadir)

> Perubahan:

> * Segera hadir

> * Tidak ada perubahan lain di versi 8

***

## Footer

Anda telah mencapai akhir file ini!

##### EOF

***
