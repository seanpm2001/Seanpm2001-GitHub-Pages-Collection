***

##### Yuqoridan

_Maqolani boshqa tilda o'qing: _

** Amaldagi til: ** `Ingliz tili (AQSh)` _ (tarjimalarni to'g'ri til o'rniga ingliz tilini tuzatish uchun tuzatish kerak bo'lishi mumkin)

_🌐 Tillar ro'yxati_

** Saralash: ** `A-Z`

[Saralash parametrlari mavjud emas] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) albancha | [am አማርኛ] (/. github / README_AM.md) amarikcha [[ar |rbى] (/.github/README_AR.md) arabcha | [hy հայերեն] (/. github / README_HY.md) armancha | [az Azarbaycan tili] (/. github / README_AZ.md) ozarbayjoncha | [eu Euskara] (/. github /README_EU.md) Baskcha | [be Belusskaya] (/. Github / README_BE.md) Belorussiya | [bn বাংলা] (/. Github / README_BN.md) Bengalcha | [bs Bosanski] (/. Github / README_BS.md) Bosniya | [bg blgarski] (/. Github / README_BG.md) bolgarcha | [ca Català] (/. Github / README_CA.md) katalancha | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体] (/. github / README_ZH-CN.md) xitoy (soddalashtirilgan) | [zh-t t 中國 的）] (/. github / README_ZH -T.md) xitoycha (an'anaviy) | [co Corsu] (/. Github / README_CO.md) korsikcha | [hr Hrvatski] (/. Github / README_HR.md) xorvatcha | [cs čeština] (/. Github / README_CS .md) Chexiya | [da dansk] (README_DA.md) Daniya | [nl Nederlands] (/. github / README_ NL.md) Gollandiyalik | [** en-us English **] (/. github / README.md) Ingliz tili | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estoniya | [tl Pilipino] (/. github / README_TL.md) Filippincha | [fi Suomalainen] (/. github / README_FI.md) Finlyandiya | [fr français] (/. github / README_FR.md) Frantsiya | [fy Frysk] (/. github / README_FY.md) Frizian | [gl Galego] (/. github / README_GL.md) Galisiya | [ka ქართველი] (/. github / README_KA) Gruziya | [de Deutsch] (/. github / README_DE.md) nemis | [el Ελληνiκά] (/. github / README_EL.md) yunoncha | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Gaiti Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawai'i] (/. github / README_HAW.md) Gavayi | [u arabcha] (/. github / README_HE.md) ibroniycha | [salom निन्दी] (/. github / README_HI.md) hindcha | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) venger | [is Íslenska] (/. github / README_IS.md) Islandcha | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandiya | [ga Gaeilge] (/. github / README_GA.md) Irlandiya | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) yaponcha | [jw Wong jawa] (/. github / README_JW.md) Yava | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Qozoqcha | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [Rw Kinyarvanda] (/. github / README_RW.md) Kinyarvanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Koreys (Janubiy) | [ko-north 문화어] (README_KO_NORTH.md) koreys (shimol) (HOZIR TARJIMA ETILMAYDI) | [ku Kurdî] (/. github / README_KU.md) Kurdcha (Kurmanji) | [ky Kyrgyzcha] (/. github / README_KY.md) Qirg'iz | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latin] (/. github / README_LA.md) Lotin | [lt Lietuvis] (/. github / README_LT.md) Litva | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxembourgish | [mk Makedonski] (/. github / README_MK.md) Makedoniya | [mg Malagas] (/. github / README_MG.md) Malagascha | [ms Bahasa Melayu] (/. github / README_MS.md) Malaycha | [ml മലയാളം] (/. github / README_ML.md) Malayalamcha | [mt Malti] (/. github / README_MT.md) Maltese | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Mo'g'ul] (/. github / README_MN.md) Mo'g'ulcha | [my မြန်မာ] (/. github / README_MY.md) Myanma (Birma) | [ne नेलीाली] (/. github / README_NE.md) nepalcha | [no norsk] (/. github / README_NO.md) Norvegiya | [yoki ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښtw] (/. github / README_PS.md) Pashto | [fa farsiy] (/. github / README_FA.md) | forscha [pl polski] (/. github / README_PL.md) polyak | [pt português] (/. github / README_PT.md) Portugalcha | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Q | harfi bilan boshlanadigan tillar mavjud emas [ro Română] (/. github / README_RO.md) Ruminiya | [ru russkiy] (/. github / README_RU.md) ruscha | [sm Faasamoa] (/. github / README_SM.md) Samoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scots Gaelic | [sr Spski] (/. github / README_SR.md) Serbcha | [st Sesoto] (/. github / README_ST.md) Sesoto | [sn Shona] (/. github / README_SN.md) Shona | [sd snyy] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinxala | [sk Slovák] (/. github / README_SK.md) Slovakiya | [sl Slovenščina] (/. github / README_SL.md) Slovencha | [so Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Ispancha | [su Sundanis] (/. github / README_SU.md) Sunduzcha | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) shved | [tg Tojikiy] (/. github / README_TG.md) tojikcha | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Tatar] (/. github / README_TT.md) Tatarcha | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr turk] (/. github /README_TR.md) turkcha | [tk Türkmenler] (/. github / README_TK.md) Turkman | [uk Ukraisnykiy] (/. github / README_UK.md) Ukraina | [ur رrdu] (/. github / README_UR.md) urdu | [ug ئۇyغۇr] (/. github / README_UG.md) Uyg'ur | [uz O'zbek] (/. github / README_UZ.md) O'zbek | [vi Tiếng Việt] (/. github / README_VI.md) Vetnamcha | [cymaeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xosa | [yi yiדyש] (/. github / README_YI.md) Yahudiycha | [yo yoruba] (/. github / README_YO.md) yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) 110 ta tilda mavjud (108 ta ingliz va shimoliy koreyslarni hisobga olmaganda, chunki shimoliy koreys hali tarjima qilinmagan [Bu haqda bu erda o'qing] (/ OldVersions / koreys (shimoliy) ) /README.md))

Ingliz tilidan boshqa tillardagi tarjimalar mashinada tarjima qilingan va hozircha aniq emas. 2021 yil 5-fevraldan boshlab hech qanday xato aniqlanmagan. Iltimos, tarjima xatolari haqida xabar bering [bu erda] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) sizning tuzatishingizni zaxira nusxasini yaratganingizga ishonch hosil qiling. manba qiling va menga rahbarlik qiling, chunki men ingliz tilidan boshqa tillarni yaxshi bilmayman (oxir-oqibat tarjimon olishni rejalashtirganman) iltimos, [wiktionary] (https://en.wiktionary.org) va boshqa hisobot manbalarini keltiring. Agar buni qilmasangiz, nashr etilgan tuzatish rad etilishiga olib keladi.

Eslatma: GitHub markdownni talqin qilishdagi cheklovlar tufayli (va deyarli har qanday boshqa markdownning veb-ga asoslangan talqini) ushbu havolalarni bosish sizni GitHub profilim sahifasi bo'lmagan alohida sahifadagi alohida faylga yo'naltiradi. Siz README joylashtirilgan [seanpm2001 / seanpm2001 omboriga] (https://github.com/seanpm2001/seanpm2001) yo'naltirilasiz.

DeepL va Bing Translate kabi tarjima xizmatlarida kerakli tillarni cheklanganligi yoki umuman qo'llab-quvvatlamaganligi sababli tarjimalar Google Translate bilan amalga oshiriladi (Google-ga qarshi kampaniya uchun juda kulgili) Shu bilan bir qatorda men alternativani qidirmoqdaman. Ba'zi sabablarga ko'ra formatlash (havolalar, ajratuvchilar, qalin, kursiv va boshqalar) turli xil tarjimalarda buzilgan. Tuzatish juda zerikarli va lotin alifbosi bo'lmagan tillarda bu muammolarni qanday hal qilishni bilmayman va bu muammolarni hal qilishda o'ngdan chapga (masalan, arabcha) qo'shimcha yordam kerak.

Ta'minot muammolari tufayli ko'plab tarjimalar eskirgan va ushbu "README" maqola faylining eskirgan versiyasidan foydalanmoqda. Tarjimon kerak. Bundan tashqari, 2021 yil 23-apreldan boshlab barcha yangi havolalarni ishga tushirish uchun biroz vaqt kerak bo'ladi.

***

# Videvinni kesish vaqti keldi

Bu nima uchun Google WideVine (DRM) dan foydalanishni to'xtatishingiz va uni o'chirishingiz kerakligi haqidagi maqola. DRM olib tashlanishi kerak. Ushbu maqola sizning tanlovingizni amalga oshirishda sizga yordam beradi (agar siz hali ham bo'lmagan bo'lsa) WideVine raqobatbardoshlikka qarshi va juda cheklovli va Internetdagi videolarning erkinligini buzmoqda.

Keling, WideVine-ni kesib, ochiq Internetni qabul qilaylik.

***

# Indeks

[00.0 - Top] (# Top)

> [00.1 - Ushbu maqolani boshqa tilda o'qing]

> [00.2 - Sarlavha] (# Videoning vaqti-vaqti bilan kesilishi kerak)

> [00.3 - indeks] (# indeks)

[01.0 - Umumiy Tasavvur] (# Umumiy Tasavvur)

[02.0 - Raqobatga qarshi] (# Raqobatga qarshi)

[03.0 - erkinlik yo'qligi] (# erkinlik etishmasligi)

[04.0 - Xotiradan foydalanish] (# Xotiradan foydalanish)

[05.0 - Maxfiylik] (# Maxfiylik)

[06.0 - Muqobil usullar] (# Muqobil usullar)

[07.0 - yordam berish uchun nima qilishingiz mumkin] (# yordam uchun nima qilishingiz mumkin)

[08.0 - Tekshirish uchun boshqa narsalar] (# Boshqa tekshiriladigan narsalar)

[09.0 - maqola haqida ma'lumot] (# maqola-ma'lumot)

> [09.0.1 - Dastur holati] (# Dastur holati)

> [09.0.2 - Homiy haqida ma'lumot] (# Homiy-ma'lumot)

[10.0 - Fayllar tarixi] (# Fayllar tarixi)

[11.0 - altbilgi] (# altbilgi)

> [11.9 - EOF] (# EOF)

***

## Umumiy ma'lumot

DRM nima uchun muammo tug'dirishi haqida boshqa ma'lumot uchun [bu yerni bosing] (https://www.defectivebydesign.org/)

***

## raqobatga qarshi

WideVine - bu DRM, uni brauzer bilan ishlatish uchun litsenziyalash kerak. Google odamlarni ko'rib chiqish va qabul qilishda juda sust va ko'pincha odamlarni o'z mahsulotlarida hech qanday sababsiz foydalanishni rad etadi. [Manba 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Manba 2 (4 oydan ortiq davom etgan va umidsizlikdan boshqa narsaga olib kelmagan elektron pochta xabari)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google Brave yoki Firefox singari brauzerlarning DRM-ning ushbu qismi bilan raqobatlashishini ancha qiyinlashtirdi.

***

## Erkinlikning etishmasligi

WideVine foydalanuvchilarning veb-saytlardagi video bilan o'zaro aloqalarini oldini olish uchun ishlatiladi. Bu videoni yuklab olishga, videoni oflayn rejimda ko'rishga yoki hatto skrinshot olishga to'sqinlik qiladigan raqamli cheklovlarni boshqarish shaklidir. Bu shaxsiy dasturiy ta'minot va maxfiylik bilan bog'liq muammolar tufayli u Linux tarqatish dasturlarida sukut bo'yicha o'rnatilmagan. Netflix, Disney va YouTube filmlari tomonidan ishlatilishi tufayli veb erkinliklarini cheklamoqda. Tarkibga kirishingizni istalgan vaqtda sababsiz olib qo'yish mumkin.

***

## Xotiradan foydalanish

WideVine xotirada yomon ishlaydi. Oddiy DRM-larsiz videoni ko'rish bilan taqqoslaganda, WideVine juda ko'p miqdorda protsessor va operativ xotiradan foydalanadi. Bu yomonstandart HTML5 videoni ijro etishdan foyda ko'rmaydi.

***

## Maxfiylik

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / barcha-ma'lumotlar-facebook-google-sizda-maxfiylik bor) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)(s................(https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Tanqid) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -sablonlar / yashirish uchun hech narsa yo'q-argument-aytishga hech narsa yo'q /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- siz-hozirda topishingiz va o'chirishingiz mumkin bo'lgan ma'lumotlar /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -va) [c] (https://www.wired.com/story/google-tracks-you -maxfiylik /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)(d................(https://www.reuters.com/article/us-alphabet- google-privacy-courtuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)(o................(https://en.wikipedia.org/wiki/2018_Google_data_breach)(m] (https:// moz.com/bl og / where-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- 5 million iphone foydalanuvchisi nomidan da'volar) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)(e................(https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-is-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technolo gy / 2014/01 / google-nest-or-really-do-do-can-do-can-do-do-can-do-with / / [i] (https://www.cbsnews.com/news/google-education-spies - yangi-meksikalik-bosh prokuror-da-da'vo-da'vo qilayotgan-millionlab bolalar haqida-ma'lumotlar yig'adi /) [v] (https://www.nationalreview.com/2018/04/the-student- bizning burunlarimiz ostidagi ma'lumotlarni qazib olish bilan bog'liq janjal /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)(y ：(https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -s hide-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (men buni davom ettirishim mumkin edi) , ammo bu maqolalarni topish va ko'rib chiqish uchun ko'p vaqt kerak bo'ldi)

Maxfiylik WideVine bilan bog'liq emas. Xususiy dasturiy ta'minot nima sodir bo'layotganini umuman ko'rmaydigan qilib yaratilgan. Googles tarixi bilan, ehtimol bu ehtimolWideVine - bu sizning orqangizdan josuslik qilish, hujjatlaringizni o'qish va boshqa yomon narsalarni qidiradigan qo'shimcha dasturiy ta'minot.

Agar yashiradigan hech narsa yo'q deb hisoblasangiz, ** siz mutlaqo adashasiz **. Ushbu dalil ko'p marta bekor qilingan:

[Vikipediya orqali] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Tanqid)

1. Edvard Snouden "Shaxsiy hayot huquqi haqida qayg'urmasligingiz haqida bahslashish, chunki yashiradigan hech narsangiz yo'q, chunki siz so'z erkinligi haqida o'ylamasligingizdan farq qilmaydi, chunki siz aytadigan gapingiz yo'q." Yashiradigan hech narsam yo'q, "deb aytasiz," Menga bu huquq muhim emas ". Siz:" Menda bunday huquq yo'q, chunki men oqlashim kerak bo'lgan darajaga yetdim. "Huquqlar qanday ishlaydi, hukumat sizning huquqlaringizga aralashganligini oqlashi kerak."

2. Deniel J. Solove "Oliy ta'lim xronikasi" gazetasida chop etilgan maqolasida argumentga qarshi ekanligini aytdi; u hukumat odam haqida ma'lumotni chiqarib yuborishi va bu shaxsga zarar etkazishi yoki shaxs qonunbuzarlik bilan shug'ullanmagan bo'lsa ham, xizmatlarga kirishni rad etish uchun shaxs to'g'risidagi ma'lumotlardan foydalanishi mumkinligi va hukumat odamning shaxsiy hayotiga zarar etkazishi mumkinligini aytdi. xatolar qilish orqali hayot. Solove "To'g'ridan-to'g'ri ish olib borilganda, yashiradigan hech qanday dalil tuzoqqa tushishi mumkin emas, chunki bu munozaralarni mahfiylikni tor tushunishga qaratishga majbur qiladi. Ammo hukumat ma'lumotlarini yig'ish va kuzatuvdan tashqari foydalanish bilan bog'liq shaxsiy hayotning ko'pgina muammolariga duch kelganda. oshkor qilish, yashirish uchun hech qanday dalil, oxir-oqibat, aytadigan gapi yo'q ".

3. Adam D. Mur, Maxfiylik huquqlari: Axloqiy va huquqiy asoslar muallifi, "bu huquqlar xarajat / foyda yoki natijaviy turdagi dalillarga chidamli degan qarashdir. Bu erda biz maxfiylik manfaatlari turli xil degan qarashni rad etamiz. xavfsizlik uchun sotilishi mumkin bo'lgan narsalar. " Shuningdek, u kuzatuv tashqi ko'rinishiga, millati, shahvoniyligi va diniga qarab jamiyatdagi ayrim guruhlarga nomutanosib ta'sir ko'rsatishi mumkinligini aytdi.

4. Bryus Shnayer, kompyuter xavfsizligi bo'yicha mutaxassis va kriptograf, Kardinal Rishelening "Agar menga eng rostgo'y odamning qo'li bilan yozilgan oltita satrni beradigan bo'lsa, men ularni osib qo'yishi uchun biron bir narsani topar edim" degan so'zlariga asoslanib, qarshilik bildirdi. shtat hukumati ushbu shaxsni ta'qib qilish yoki shantaj qilish uchun qanday qilib inson hayotidagi jihatlarni topishi mumkinligi haqida. Shnayer, shuningdek, "juda ko'pchilik munozaralarni" xavfsizlik va maxfiylik "deb xarakterlaydi. Haqiqiy tanlov - bu erkinlik va nazorat. "

5. Harvi A. Silvergleyt oddiy odam AQShda kuniga o'rtacha uchta jinoyatni bilmasdan sodir etadi deb taxmin qildi.

6. Emilio Mordini, faylasuf va psixoanalit, "yashiradigan hech narsa" argumenti o'z-o'zidan paradoksal ekanligini ta'kidladi. Odamlarga "nimanidir" yashirish uchun "yashiradigan narsa" bo'lishi shart emas. Yashirin narsa, albatta, ahamiyatli emas, deydi Mordini. Buning o'rniga, u yashirin va kirishni cheklash mumkin bo'lgan samimiy maydon zarurligini ta'kidlaydi, chunki psixologik nuqtai nazardan, biz boshqalarga nimanidir yashirishimiz mumkinligi bilan biz shaxs bo'lib qolamiz.

7. Julian Assanj "Hozircha qotilning javobi yo'q. Jeykob Appelbaum (@ioerror) aqlli javob berib, buni aytayotgan odamlardan telefonini qulfdan chiqarib, shimini tushirishini iltimos qiladi. Mening versiyam: "yaxshi, agar siz shunchalik zerikarli bo'lsa, biz ham siz bilan ham, boshqalari bilan ham gaplashmasligimiz kerak", lekin falsafiy jihatdan haqiqiy javob bu: ommaviy kuzatuv - bu ommaviy tarkibiy o'zgarishdir. Jamiyat yomonlashganda, u ketadi er yuzidagi eng yumshoq odam bo'lsang ham, seni o'zi bilan olib ketish ".

8. Ignasio Cofone, huquqshunos professor, argument o'z nuqtai nazaridan yanglishgan deb ta'kidlaydi, chunki odamlar har doim tegishli ma'lumotlarni boshqalarga oshkor qilganda, ular ahamiyatsiz ma'lumotlarni ham oshkor qiladilar. Ushbu ahamiyatsiz ma'lumot maxfiylik xarajatlariga ega va boshqa zararlarga olib kelishi mumkin, masalan, kamsitish.

***

# Muqobil usullar

Ommaviy axborot vositalari cheklanmasligi kerak, onlayn yoki oflayn rejimda. Agar odamlar videoni DRM holda ko'rishni xohlasalar, ular doimo buni amalga oshirishning yo'lini topadilar. Har qanday dasturiy ta'minot yorilib ketishi mumkin.

[Vikipediyadan o'zgartirilgan parcha] Valve prezidenti Gabe Nyuel "DRM strategiyalarining aksariyati shunchaki soqov" ekanligini aytdi, chunki ular iste'molchining ko'zida o'yin qiymatini pasaytiradi. Newell, maqsad o'rniga "[xizmat ko'rsatish qiymati orqali mijozlar uchun katta qiymat yaratish" bo'lishi kerakligini ta'kidlamoqda. Valve shaxsiy kompyuter o'yinlari uchun onlayn-do'kon, shuningdek, ijtimoiy tarmoq xizmati va DRM platformasi sifatida xizmat qiluvchi Steam xizmatini ishlaydi.

Ushbu nuqta faqat video o'yinlar uchun amal qilmaydi, uni kompyuterdagi hamma narsada qo'llash mumkin. Sizning kompyuteringiz yomon sun'iy intellektdan foydalanib, foydalanuvchilarini va ularning ishlarini (YouTube va boshqalarni) yo'q qilish uchun ishlatadigan va yomon ko'rsatkichga ega bo'lgan aqldan kompaniya ustidan to'liq nazorat o'rnatmasligi kerak. Kompyuteringiz cheklanmasligi kerak, chunki kompaniya o'zini yomon tutgan boladek bo'lishishdan bosh tortadi. Sizning kompyuteringiz sizga tegishli bo'lishi kerak,va boshqa hech kim. DRM-dan butunlay xalos bo'lishingiz kerak, chunki tarkib kompyuteringiz boshqaruvidan voz kechishga arzimaydi. Ushbu kompaniyalarda yuzlab milliard dollar mavjud. Agar ular bunday ahmoqona ish qilishsa, siz bunga norozilik bildirishingiz kerak. Siz shunchaki videoni boshqa joydan yuklab olishingiz va uni ko'rishingiz mumkin, chunki ular bu kabi ahmoqona ishlar uchun pul yo'qotishlari kerak. Mualliflik huquqining buzilishi yomon narsa emas. Filmlarni sotib olishga qodir bo'lmagan odamlar ularni boshqa joylarga yuklab olishadi, bu global Internet boshlanganidan beri va VHS lentasi ixtiro qilingandan beri sodir bo'lmoqda. Bu ularning daromadlariga deyarli ta'sir qilmaydi, chunki ular baribir bu pulni ololmaydilar. DRM dizayni bo'yicha nuqsonli.

***

## Siz yordam berish uchun nima qilishingiz mumkin

Siz DRM-ga norozilik bildirishingiz mumkin. Bu ahamiyatsiz bo'lib tuyulishi mumkin, ammo bunga qarshi bo'lganlar qancha ko'p bo'lsa, shuncha ko'p ish qilinmoqda.

Agar siz Linuxda bo'lsangiz va Firefox-dan foydalansangiz, DRM-ning o'rnatilmaganligiga ishonch hosil qiling (u odatda sukut bo'yicha emas) va uni o'rnatishda bezovta qilmang.

Agar siz Windows yoki MacOS-da bo'lsangiz, sizga ancha qiyin bo'lishi mumkin, chunki DRM ushbu tizimlarda sukut bo'yicha o'rnatiladi va avtomatik ravishda qayta o'rnatilishi mumkin.

Quyidagi saytlardan qochishga harakat qiling:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Asosan, deyarli har qanday onlayn video oqim xizmatidan qochish kerak, chunki ularning aksariyati DRM dan foydalanadi va siz erkinligingizni yo'qotmasdan saytdan foydalana olmaysiz. Bunga loyiq emas. [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) xabar yuboring va ushbu shoularni uzatishni to'xtating.

Shuningdek, siz quyidagi saytlarda "reklama bilan bepul" variantlaridan qochishingiz kerak (chunki bu usul DRM talab qiladi)

[YouTube] (https://www.youtube.com)

Siz o'zingizning loyihalaringizda "README.md`" fayli bilan DRM-ga norozilik bildirishingiz mumkin. Men foydalanadigan narsa:

"" pastga tushirish

***

## Dastur holati

Mening barcha asarlarim cheklovlar bepul. DRM (** D ** igital ** R ** estrictions ** M ** anagement) mening biron bir asarimda mavjud emas.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ushbu stiker Free Software Foundation tomonidan qo'llab-quvvatlanadi. Men hech qachon DRMni o'z asarlarimga qo'shishni niyat qilmayman.

Ko'proq tanilgan "Raqamli huquqlarni boshqarish" o'rniga "Raqamli cheklovlarni boshqarish" qisqartmasidan foydalanmoqdaman, chunki uni hal qilishning umumiy usuli noto'g'ri, DRM bilan huquqlar yo'q. "Raqamli cheklovlarni boshqarish" imlosi aniqroq va [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) va [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Ushbu bo'lim DRM bilan bog'liq muammolar to'g'risida xabardorlikni oshirish va unga norozilik bildirish uchun ishlatiladi. DRM dizayni nuqsonli bo'lib, barcha kompyuter foydalanuvchilari va dasturiy ta'minot erkinligi uchun katta tahdiddir.

Rasm krediti: [defectivebydesign.org/drm-free/...................(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

""

***
## Tekshirish uchun boshqa narsalar

[Loyihasi nuqsonli - DRMdan foydalanishni fosh etish va yo'q qilish ustida ish olib borayotgan Bepul Dastur Jamg'armasi tomonidan olib borilgan kampaniya] (https://www.defectivebydesign.org/)

[Google Graveyard (killbygoogle.com) - Google tomonidan o'ldirilgan 224+ mahsulotlarning saralangan ro'yxati] (https://killedbygoogle.com/)

> [GitHub havolasi] (https://github.com/codyogden/killedbygoogle)

[Alifbo ishchilari kasaba uyushmasi - 800 dan ortiq a'zolari bo'lgan Google-dagi yangi ishchilar kasaba uyushmasi] (https://alphabetworkersunion.org/people/our-union/)

Boshqa alternativalar mavjud, ularni qidirib toping.

***

## Maqola haqida ma'lumot

Fayl turi: "Markdown (* .md)"

Fayl versiyasi: "4 (2021 yil 23-aprel, juma, soat 15:35 da)"

Qatorlar soni (bo'sh satrlar va kompilyator qatorini o'z ichiga olgan holda): `354`

### Dastur holati

Mening barcha asarlarim cheklovlardan xoli. DRM (** D ** igital ** R ** estrictions ** M ** anagement) mening biron bir asarimda mavjud emas. Ushbu loyihada hech qanday DRM mavjud emas, lekin to'g'ridan-to'g'ri DRM haqida gap boradi.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ushbu stiker Free Software Foundation tomonidan qo'llab-quvvatlanadi. Men hech qachon DRMni o'z asarlarimga qo'shishni niyat qilmayman.

***

### Homiy haqida ma'lumot

! [SponsorButton.png] (SponsorButton.png) <- Bu rasmiy homiy tugmasi emas, demo tasviridir. Ushbu loyihaga homiylik qilishni istasangiz, uni bosmang.

Agar xohlasangiz, ushbu loyihaga homiylik qilishingiz mumkin, lekin xayr-ehson qilmoqchi bo'lganingizni ko'rsating. [Bu erda o'tkazishingiz mumkin bo'lgan mablag'larni ko'ring] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Homiylarning boshqa ma'lumotlarini [bu erda] ko'rishingiz mumkin (https://github.com/seanpm2001/Sponsor-info/)

Sinab ko'ring! Homiy tugmasi tomosha qilish / ochish tugmasi yonida.

***

## Fayl tarixi

1-versiya (2021 yil 8-fevral, yakshanba, soat 16:41 da)

> O'zgarishlar:

> * Fayl / maqolani ishga tushirdi

> * Sarlavha bo'limi qo'shildi

> * Maxfiylik haqida bo'lim qo'shildi

> * Umumiy ko'rish haqida bo'lim qo'shildi

> * Maqola haqida ma'lumot qismi qo'shildi

> * DRM Free ikonkasiga murojaat qilingan

> * Fayllar tarixi bo'limi qo'shildi

> * Erkinlik yo'qligi bo'limi qo'shildi

> * Raqobatga qarshi bo'lim qo'shildi

> * Muqobil usullar bo'limi qo'shildi

> * Memo qo'shildifoydalanish bo'lim

> * Tekshirish uchun boshqa narsalar qo'shildi

> * Indeks qo'shildi

> * Altbilgi qo'shildi

> * 1-versiyada boshqa o'zgarishlar yo'q

2-versiya (2021 yil 8-aprel, payshanba, soat 17:18 da)

> O'zgarishlar:

> * Sarlavha bo'limi yangilandi

> * Indeks yangilandi

> * Yordam berish uchun nima qilishingiz mumkinligi haqida ma'lumot qo'shildi

> * Homiyning ma'lumot qismi qo'shildi

> * Fayl ma'lumotlari bo'limi yangilandi

> * Fayllar tarixi bo'limi yangilandi

> * 2-versiyada boshqa o'zgarishlar yo'q

3-versiya (2021 yil 8-aprel, payshanba, soat 17:27 da)

> O'zgarishlar:

> * Ruxsat etilgan tarjima havolalari

> * Indeks yangilandi

> * "Siz nima yordam berishingiz mumkin" bo'limida mavzudan tashqari dublikat tuzatildi

> * Homiyning ma'lumot qismi yangilandi

> * Fayl ma'lumotlari bo'limi yangilandi

> * Fayllar tarixi bo'limi yangilandi

> * 3-versiyada boshqa o'zgarishlar yo'q

4-versiya (2021 yil 23-aprel, juma, soat 15:35 da)

> O'zgarishlar:

> * Til almashtiruvchi ro'yxati yangilandi

> * Fayl ma'lumotlari bo'limi yangilandi

> * Fayllar tarixi bo'limi yangilandi

> * 4-versiyada boshqa o'zgarishlar yo'q

5-versiya (Yaqinda)

> O'zgarishlar:

> * Tez orada

> * 5-versiyada boshqa o'zgarishlar yo'q

6-versiya (Yaqinda)

> O'zgarishlar:

> * Tez orada

> * 6-versiyada boshqa o'zgarishlar yo'q

7-versiya (Yaqinda)

> O'zgarishlar:

> * Tez orada

> * 7-versiyada boshqa o'zgarishlar yo'q

8-versiya (Yaqinda)

> O'zgarishlar:

> * Tez orada

> * 8-versiyada boshqa o'zgarishlar yo'q

***

## altbilgi

Siz ushbu faylning oxiriga yetdingiz!

##### EOF

***
