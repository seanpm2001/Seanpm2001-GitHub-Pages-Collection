***

##### Üles

_Lugege seda artiklit muus keeles: _

** Praegune keel on: ** "inglise (USA)" _ (tõlkimine võib osutuda vajalikuks parandada inglise keelt, asendades õige keele) _

_🌐 keelte loend_

** Sorteeritud: ** "A-Z"

[Sorteerimisvalikud pole saadaval] (https://github.com/Degoogle-your-Life)

([af afrikaans] (/. github / README_AF.md) afrikaani | [sq Shqiptare] (/. github / README_SQ.md) albaania | [am አማርኛ] (/. github / README_AM.md) amhari keel | [ar عربى] (/.github/README_AR.md) araabia | [hy հայերեն] (/. github / README_HY.md) armeenia | [az Azərbaycan dili] (/. github / README_AZ.md) aserbaidžaani | [eu Euskara] (/. github /README_EU.md) baski keel | [be Беларуская] (/. Github / README_BE.md) valgevene keel [[bn বাংলা] (/. Github / README_BN.md) bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnia | [bg български] (/. Github / README_BG.md) bulgaaria | [ca Català] (/. Github / README_CA.md) katalaani | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichich ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) hiina (lihtsustatud) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) hiina (traditsiooniline) | [co Corsu] (/. Github / README_CO.md) Korsika | [hr Hrvatski] (/. Github / README_HR.md) horvaadi | [cs čeština] (/. Github / README_CS .md) tšehhi | [da dansk] (README_DA.md) taani | [nl Nederlands] (/. github / README_ NL.md) hollandi | [** et et eesti keel **] (/. github / README.md) inglise keel [EO esperanto] (/. Github / README_EO.md) esperanto | [et Eestlane] (/. github / README_ET.md) eesti keel [tl Pilipino] (/. github / README_TL.md) filipiinlane | [fi Suomalainen] (/. github / README_FI.md) soome keel [fr français] (/. github / README_FR.md) prantsuse | [fy Frysk] (/. github / README_FY.md) friisi | [gl Galego] (/. github / README_GL.md) galeegi keel [ka ქართველი] (/. github / README_KA) gruusia | [de Deutsch] (/. github / README_DE.md) saksa keel [el Ελληνικά] (/. github / README_EL.md) kreeka | [gu ગુજરાતી] (/. github / README_GU.md) gudžarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haiti kreool | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) havai | [ta עִברִית] (/. github / README_HE.md) heebrea | [tere हिन्दी] (/. github / README_HI.md) hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) ungari keel [on Íslenska] (/. github / README_IS.md) islandi keel | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) islandi | [ga Gaeilge] (/. github / README_GA.md) iiri keel [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) jaapani keel [jw Wong jawa] (/. github / README_JW.md) jaava keel | [kn ಕನ್ನಡ] (/. github / README_KN.md) kannada | [kk Қазақ] (/. github / README_KK.md) kasahhi keel | [km ខ្មែរ] (/. github / README_KM.md) khmeeri | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-lõuna 韓國 語] (/. github / README_KO_SOUTH.md) Korea (lõuna) | [ko-põhja 문화어] (README_KO_NORTH.md) korea (põhi) (EI VEEL TÕLKETUD) | [ku Kurdî] (/. github / README_KU.md) kurdi (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kõrgõzstani | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) ladina keel [lt Lietuvis] (/. github / README_LT.md) leedu | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksemburgi keel | [mk Македонски] (/. github / README_MK.md) makedoonia | [mg Madagaskari] (/. github / README_MG.md) Madagaskari | [ms Bahasa Melayu] (/. github / README_MS.md) malai | [ml മലയാളം] (/. github / README_ML.md) malajalami | [mt Malti] (/. github / README_MT.md) malta keel [mi maoori] (/. github / README_MI.md) maoori | [hr मराठी] (/. github / README_MR.md) marathi | [mn Монгол] (/. github / README_MN.md) mongoli keel | [minu မြန်မာ] (/. github / README_MY.md) Myanmar (Birma) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) norra keel [või ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) pastu | [fa فارسی] (/. github / README_FA.md) | pärsia [pl polski] (/. github / README_PL.md) poola keel | [pt português] (/. github / README_PT.md) portugali keel [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) pandžabi | Q-tähega algavaid keeli pole [ro Română] (/. github / README_RO.md) rumeenia keel [ru русский] (/. github / README_RU.md) vene keel [sm Faasamoa] (/. github / README_SM.md) Samoa keel | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) šoti gaeli keel | [sr Српски] (/. github / README_SR.md) serbia | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) slovaki | [sl Slovenščina] (/. github / README_SL.md) sloveeni | [nii Soomaali] (/. github / README_SO.md) somaali | [[es en español] (/. github / README_ES.md) hispaania keel [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) suahiili | [sv Svenska] (/. github / README_SV.md) rootsi | [tg Тоҷикӣ] (/. github / README_TG.md) tadžiki keel | [ta தமிழ்] (/. github / README_TA.md) tamili | [tt Татар] (/. github / README_TT.md) tatari | [te తెలుగు] (/. github / README_TE.md) telugu | [th ไทย] (/. github / README_TH.md) tai | [tr Türk] (/. github /README_TR.md) türgi keel [tk Türkmenler] (/. github / README_TK.md) turkmeeni | [uk Український] (/. github / README_UK.md) ukrainlane | [ur اردو] (/. github / README_UR.md) urdu | [ug ئۇيغۇر] (/. github / README_UG.md) uiguuri | [uz O'zbek] (/. github / README_UZ.md) usbeki keel | [vi Tiếng Việt] (/. github / README_VI.md) vietnami keel [cy Cymraeg] (/. github / README_CY.md) kõmri | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jidiši | [yo joruba] (/. github / README_YO.md) joruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Saadaval 110 keeles (108, kui mitte arvestada inglise ja põhja-korea keelt, kuna põhja-korea keelt pole veel tõlgitud [Loe selle kohta siit] (/ OldVersions / Korea (North ) /README.md))

Tõlked muudesse keeltesse kui inglise keelde tõlgitakse masinaga ja pole veel täpsed. 5. veebruari 2021. aasta seisuga pole veel ühtegi viga parandatud. Palun teatage tõlkevigadest [siin] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) varundage parandus kindlasti allikatest ja juhendage mind, kuna ma ei oska muid keeli peale inglise keele (kavatsen lõpuks tõlgi hankida), siis palun märkige oma aruandes [vikisõnastik] (https://et.wiktionary.org) ja muud allikad. Kui seda ei tehta, lükatakse parandus tagasi.

Märkus. GitHubi märgistuse tõlgendamise piirangute tõttu (ja peaaegu kõigi muude veebipõhiste märgistuste tõlgenduste korral) suunab nende linkide klõpsamine teid eraldi lehele eraldi faili, mis pole minu GitHubi profiilileht. Teid suunatakse [seanpm2001 / seanpm2001 hoidlasse] (https://github.com/seanpm2001/seanpm2001), kus hostitakse README-d.

Tõlked tehakse Google'i tõlkega, kuna muudes tõlketeenustes, nagu näiteks DeepL ja Bing Translate, vajaminevate keelte tugi on piiratud või puudub üldse (Google'i-vastase kampaania puhul on see üsna irooniline), töötan alternatiivi leidmise nimel. Millegipärast on vormindus (lingid, eraldajad, painutamine, kursiiv jne) segatud erinevates tõlgetes. Selle parandamine on tüütu ja ma ei tea, kuidas neid probleeme lahendada keeltes, kus pole ladina tähemärki ja paremalt vasakule (nagu araabia) kasutatavates keeltes on nende probleemide lahendamiseks vaja täiendavat abi

Hooldusprobleemide tõttu on paljud tõlked ajale jalgu jäänud ja kasutavad selle artikli „README“ vananenud versiooni. Vaja on tõlki. Alates 23. aprillist 2021 võtab mul ka aega, et kõik uued lingid tööle saada.

***

# On aeg lõigata Widevine

See on artikkel selle kohta, miks peaksite lõpetama Google WideVine'i (DRM) kasutamise ja selle desinstallima. DRM tuleb eemaldada. See artikkel aitab teil oma valiku teha (kui te pole seda veel teinud). WideVine on väga konkurentsivastane ja äärmiselt piirav ning hävitab videote vabadust Internetis.

Lõigake WideVine ja võtame omaks avatud Interneti.

***

# Indeks

[00.0 - ülemine] (# ülemine)

> [00.1 - lugege seda artiklit teises keeles]

> [00.2 - pealkiri] (# on aeg lõigata Widevine'i)

> [00.3 - register] (# register)

[01.0 - ülevaade] (# ülevaade)

[02.0 - konkurentsivastane] (# konkurentsivastane)

[03.0 - vabaduse puudumine] (# vabaduse puudumine)

[04.0 - Mälukasutus] (# Mälukasutus)

[05.0 - Privaatsus] (# Privaatsus)

[06.0 - alternatiivsed meetodid] (# alternatiivsed meetodid)

[07.0 - Mida saate teha selleks, et aidata] (# Mida-saate-teha-aidata-aidata)

[08.0 - muud asjad, mida tasub kontrollida] (# muud-asjad-väljaregistreerimine)

[09.0 - artikli teave] (# artikli teave)

> [09.0.1 - Tarkvara olek] (# Tarkvara olek)

> [09.0.2 - sponsori teave] (# sponsori teave)

[10.0 - faili ajalugu] (# faili ajalugu)

[11.0 - jalus] (# jalus)

> [11,9 - EOF] (# EOF)

***

## Ülevaade

Lisateavet selle kohta, miks DRM on probleem, [klõpsake siin] (https://www.defectivebydesign.org/)

***

## Konkurentsivastane

WideVine on DRM, millel peab olema brauseriga kasutamiseks litsents. Google on inimeste ülevaatamisel ja vastuvõtmisel äärmiselt aeglane ning keeldub inimestel seda põhjendusteta oma toodetes kasutamast. [Allikas 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Allikas 2 (meilisõnum, mis kestis üle 4 kuu ja mille tulemuseks oli vaid pettumus)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google on teinud selle DRM-i lükkamisega oma brauseritele nagu Brave või Firefox palju raskemaks konkureerida.

***

## Vabaduse puudumine

WideVine'i kasutatakse selleks, et takistada kasutajatel veebisaitidel videotega suhtlemast. See on digitaalsete piirangute haldamise vorm, mis takistab teil videot alla laadida, videot võrguühenduseta vaadata või isegi ekraanipilti teha. See on patenteeritud tarkvara ja privaatsusega seotud probleemide tõttu pole seda enamikus Linuxi distributsioonides vaikimisi installitud. See piirab veebivabadusi tänu Netflixi, Disney ja YouTube'i filmide kasutamisele. Juurdepääsu sisule saab ilma põhjuseta igal ajal ära võtta.

***

## Mälukasutus

WideVine on mälus halb. Võrreldes lihtsalt tavalise video vaatamisega ilma DRM-iga, kasutab WideVine palju CPU-d ja RAM-i. Ba peal on halbja see ei anna HTML5-video tavapärasest taasesitusest mingit kasu.

***

## Privaatsus

[G] (https://et.wikipedia.org/wiki/Criticism_of_Google) [o] (https://et.wikipedia.org/wiki/PRISM_ (valve_programm)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -halb /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-on-teie-privaatsus) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://et.wikipedia.org/wiki/Nothing_to_hide_argument# Kriitika) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -näidised / mitte midagi peita-argumendil pole midagi öelda /) [d] (https://www.cnet.com/how-to/google-collects-a-fightening-amount-of- andmed-leiad-leiad-kustutad-kohe /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes ja [c] (https://www.wired.com/story/google-tracks-you -privaatsus /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / kus-google-joonistab andmekogu-joont) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / tehnoloogia / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- nõuded 5 miljoni iphone-kasutaja nimel) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-is-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaengerss-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technolo gy / 2014/01 / mida-google-saab-tõesti-pesa-või-tõesti-pesa-andmetega / teha [] [i] (https://www.cbsnews.com/news/google-education-spies -on-kogub-andmeid-miljonite-laste kohta-väidab kohtuasja-uus-Mehhiko-peaprokurör /) [v] (https://www.nationalreview.com/2018/04/the-student- andmekaevanduskandaal ninade all /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (võiksin selle tõenditega jätkata , kuid kõigi nende artiklite leidmine ja läbimine võttis kaua aega)

Privaatsus pole WideVine'i asi. Omandatud tarkvara on loodud nii, et te ei näeks üldse, mis toimub. Google'i ajaloo juures on see väga tõenäolineWideVine on täiendav tarkvara, mis luurab teie järele, loeb teie dokumente ja muid halbu asju.

Kui arvate, et teil pole midagi varjata, siis olete täiesti vale **. Seda argumenti on mitu korda ümber lükatud:

[Vikipeedia kaudu] (https://et.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden märkis: "Väites, et te ei hooli privaatsuse õigusest, sest teil pole midagi varjata, ei erine see, kui öelda, et te ei hooli sõnavabadusest, sest teil pole midagi öelda." Kui ütlete: Mul pole midagi varjata, "ütlete sa:" mind ei huvita see õigus. "Sa ütled:" Mul pole seda õigust, sest ma olen jõudnud punkti, kus ma pean õigustama "Kuidas õigused töötavad, peab valitsus õigustama oma õiguste rikkumist."

2. Daniel J. Solove väitis ajakirja The kõrghariduse kroonika artiklis, et ta on argumendi vastu; ta väitis, et valitsus võib lekitada teavet inimese kohta ja tekitada talle kahju, või kasutada teavet isiku kohta teenuste keelamiseks, isegi kui inimene tegelikult ei eksinud, ja et valitsus võib kahjustada tema isiklikke andmeid elu vigade tegemise kaudu. Solove kirjutas: "Otseselt kaasates võib varjata miski, mida varjata, sest see sunnib arutelu keskenduma oma kitsale arusaamale privaatsusest. Kuid kui puutuda kokku paljude privaatsusprobleemidega, mis on seotud valitsuse andmete kogumise ja kasutamisega väljaspool järelevalvet ja avalikustamine, mille varjamiseks pole midagi varjata, pole lõpuks midagi öelda. "

3. Adam D. Moore, raamatu „Privaatsusõigused: moraalsed ja õiguslikud sihtasutused” autor, väitis, et „see on seisukoht, et õigused on vastupidavad kulude / tulude või tagajärjepõhiste argumentide vastu. Siinkohal lükkame tagasi arvamuse, et privaatsuse huvid on sellised asjadest, mida saab turvalisuse nimel kaubelda. " Ta märkis ka, et jälgimine võib ebaproportsionaalselt mõjutada teatud ühiskonnagruppe, mis põhinevad välimusel, rahvusel, seksuaalsusel ja usul.

4. Arvutiturbeekspert ja krüptograaf Bruce Schneier avaldas vastuseisu, tuues välja kardinal Richelieu väite "Kui keegi annaks mulle kuus ausama mehe käega kirjutatud rida, leiaksin neist midagi, mis teda üles pooks", viidates sellele. sellele, kuidas osariigi valitsus võib leida inimese elus aspekte, et seda inimest süüdistada või väljapressida. Schneier väitis ka, et "liiga paljud iseloomustavad arutelu valesti kui" turvalisus versus privaatsus ". Tegelik valik on vabadus versus kontroll. "

5. Harvey A. Silverglate hinnangul paneb tavaline inimene USA-s toime keskmiselt teadmatult kolm süütegu päevas.

6. Filosoof ja psühhoanalüütik Emilio Mordini väitis, et argument "midagi varjata" on oma olemuselt paradoksaalne. Inimestel ei pea olema midagi varjata, et midagi peita. Varjatud pole tingimata asjakohane, väidab Mordini. Selle asemel väidab ta, et vajalik on intiimne ala, mis võib olla nii varjatud kui ka juurdepääsupiiranguga, sest psühholoogiliselt võttes saame me inimesteks avastuse kaudu, et võime midagi teistele varjata.

7. Julian Assange ütles: "Mõrvarile pole veel vastust. Jacob Appelbaum (@ioerror) reageerib nutikalt, paludes seda ütlevatel inimestel anda talle telefon lukust lahti ja tõmmata püksid alla. Minu versioon sellest on öelda: "noh, kui sa oled nii igav, siis me ei peaks teiega rääkima ega peaks ka kedagi teist", kuid filosoofiliselt on tõeline vastus järgmine: massiline järelevalve on massiline struktuurimuutus. Kui ühiskond läheb halvaks, siis see läheb teid kaasa võtma, isegi kui olete kõige õrnem inimene maa peal. "

8. Õigusprofessor Ignacio Cofone väidab, et see argument on ekslik omaette, kuna alati, kui inimesed avaldavad teistele asjakohast teavet, avaldavad nad ka ebaolulist teavet. Sellel ebaolulisel teabel on privaatsuskulud ja see võib põhjustada muid kahjustusi, näiteks diskrimineerimist.

***

# Alternatiivsed meetodid

Meediat ei tohiks piirata, ei võrgus ega võrgus. Kui inimesed tahtsid videot vaadata ilma DRMita, leiavad nad selle alati. Igat tarkvara võib murda.

[muudetud väljavõte Wikipediast] Valve president Gabe Newell on öelnud, et "enamik DRM-i strateegiaid on lihtsalt tummad", kuna need vähendavad ainult mängu väärtust tarbija silmis. Newell soovitab, et eesmärk peaks olema hoopis "teenuse väärtuse kaudu klientidele suurema väärtuse loomine". Pange tähele, et Valve haldab Steami - teenust, mis toimib arvutimängude veebipoena, samuti suhtlusvõrgustiku teenust ja DRM-platvormi.

See punkt ei kehti ainult videomängude kohta, seda saab rakendada mis tahes arvutis. Teie arvuti ei peaks täielikult kontrollima hullumeelset ettevõtet, kes kasutab halba tehisintellekti oma kasutajate ja nende töö (YouTube jne) kustutamiseks ja kellel on nii halb rekord. Teie arvutit ei tohiks piirata, sest ettevõte keeldub jagamast nagu halvasti käitunud laps. Teie arvuti peaks kuuluma teile,ja mitte keegi teine. Te peaksite DRM-ist täielikult lahti saama, kuna sisu ei ole väärt arvuti juhtimisest loobumist. Neil ettevõtetel on sadu miljardeid dollareid. Kui nad teevad midagi sellist rumalust, peaksite selle vastu protestima. Võite isegi video lihtsalt mujalt alla laadida ja seda vaadata, kuna nad peaksid selliste rumaluste tegemisega raha kaotama. Autoriõiguste rikkumine pole halb asi. Inimesed, kellel pole filme endale lubada, laadivad need mujalt alla, see on juhtunud juba ülemaailmse Interneti loomisest alates ja VHS-i lindi leiutamisega. Vaevalt see nende tulusid mõjutab, kuna neil poleks seda raha nagunii võimalik saada. DRM on konstruktsioonilt defektne.

***

## Mida saate aidata

Võite protestida DRM-i vastu. See võib tunduda tähtsusetu, kuid mida rohkem inimesi sellele vastu astub, seda rohkem sellega tehakse.

Kui kasutate Linuxi ja kasutate Firefoxi, veenduge, et DRM-i pole installitud (see pole tavaliselt vaikimisi) ja ärge vaevake selle installimist.

Kui kasutate Windowsi või MacOS-i, võib teil olla palju raskem aeg, kuna DRM on nendesse süsteemidesse vaikimisi installitud ja see võib automaatselt uuesti installida.

Püüdke vältida järgmisi saite:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Põhimõtteliselt tuleks vältida peaaegu kõiki veebi voogesituse teenuseid, kuna enamik neist kasutab DRM-i ja te ei saa seda saiti kasutada ilma oma vabadust kaotamata. See pole seda väärt. Saatke [MPAA] -le (https://et.wikipedia.org/wiki/Motion_Picture_Association) sõnum ja lõpetage nende saadete voogesitus.

Samuti peaksite vältima valikuid "tasuta koos reklaamidega" järgmistel saitidel (kuna see meetod nõuab DRM-i)

[YouTube] (https://www.youtube.com)

Samuti võite DRM-i vastu protestida sõnumiga oma projektide failis README.md. Ma kasutan järgmist:

"hinnalangus

***

## Tarkvara olek

Kõik minu teosed on teatud piiranguteta. DRM-i (** D ** igital ** R ** ehted ** M ** anagement) ei esine üheski minu teoses.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Seda kleebist toetab Free Software Foundation. Ma ei kavatse kunagi DRM-i oma töödesse kaasata.

Ma kasutan lühendit "Digitaalsete piirangute haldamine" tuntuma "Digitaalse õiguste halduse" asemel, kuna levinud viis selle lahendamiseks on vale, DRM-iga pole õigusi. Õigekiri "Digitaalsete piirangute haldamine" on täpsem ja seda toetavad [Richard M. Stallman (RMS)] (https://et.wikipedia.org/wiki/Richard_Stallman) ja [Vaba tarkvara sihtasutus (FSF)] ( https://et.wikipedia.org/wiki/Free_Software_Foundation)

Seda jaotist kasutatakse DRM-i probleemide teadvustamiseks ja ka selle vastu protestimiseks. DRM on disainilt defektne ja ohustab oluliselt kõiki arvutikasutajaid ning tarkvaravabadust.

Pildikrediit: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

""

***
## Muud asjad, mida vaadata

[Disainilahenduse järgi - Free Software Foundationi kampaania, mis töötab DRM-i kasutamise paljastamise ja kõrvaldamise nimel] (https://www.defectivebydesign.org/)

[Google'i surnuaed (killbygoogle.com) - järjestatud loend 224-st Google'i tapetud tootest] (https://killedbygoogle.com/)

> [GitHubi link] (https://github.com/codyogden/killedbygoogle)

[Tähestiku töötajate ametiühing - uus Google'i töötajate ametiühing, millel on üle 800 liikme] (https://alphabetworkersunion.org/people/our-union/)

On ka teisi asendusliikmeid, lihtsalt otsige neid.

***

## Artikliteave

Failitüüp: "Markdown (* .md)"

Failiversioon: "4 (reede, 23. aprill 2021 kell 15.35)"

Ridade arv (sh tühjad read ja koostaja rida): "354"

### Tarkvara olek

Kõik minu teosed on piiranguteta. DRM-i (** D ** igital ** R ** ehted ** M ** anagement) ei esine üheski minu teoses. See projekt ei sisalda ühtegi DRM-i, kuid see räägib otseselt DRM-ist.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Seda kleebist toetab Free Software Foundation. Ma ei kavatse kunagi DRM-i oma töödesse kaasata.

***

### Sponsorite teave

! [SponsorButton.png] (SponsorButton.png) <- see pole ametlik sponsorinupp, see on demopilt. Ärge klõpsake seda, kui soovite seda projekti sponsoreerida.

Soovi korral saate seda projekti sponsoreerida, kuid palun täpsustage, millele soovite annetada. [Vaadake vahendeid, millele saate annetada, siit] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Sponsorite muud teavet saate vaadata [siit] (https://github.com/seanpm2001/Sponsor-info/)

Proovi! Sponsori nupp asub otse vaatamis- / vaatamisnupu kõrval.

***

## Faili ajalugu

Versioon 1 (pühapäev, 8. veebruar 2021 kell 16:41)

> Muudatused:

> * Käivitas faili / artikli

> * Lisatud pealkirjaosa

> * Lisas privaatsust käsitleva jaotise

> * Lisas ülevaate kohta ülevaate

> * Lisatud artikliteabe jaotis

> * Viitas DRM Free ikoonile

> * Lisatud on failiajaloo jaotis

> * Lisatud jaotis Vabaduse puudumine

> * Lisatud konkurentsivastane jaotis

> * Lisatud jaotis alternatiivsed meetodid

> * Lisas memory kasutamise osa

> * Lisas muud asjad, mida vaadata

> * Lisas indeksi

> * Lisati jalus

> * Versioonis 1 muid muudatusi pole

Versioon 2 (neljapäev, 8. aprill 2021 kell 17.18)

> Muudatused:

> * Pealkirjaosa uuendati

> * Uuendas indeksit

> * Lisatud teave selle kohta, mida saate aidata

> * Lisatud sponsoriteabe jaotis

> * Värskendas failiteabe jaotist

> * Värskendas failiajaloo jaotist

> * Versioonis 2 muid muudatusi pole

Versioon 3 (neljapäeval, 8. aprillil 2021 kell 17:27)

> Muudatused:

> * Fikseeritud tõlke lingid

> * Uuendas indeksit

> * Parandatud jaotises „Mida saate teha?” On duplikaat, teemaväline kirje

> * Värskendas sponsorite teabe jaotist

> * Värskendas failiteabe jaotist

> * Värskendas failiajaloo jaotist

> * Versioonis 3 muid muudatusi pole

Versioon 4 (reede, 23. aprill 2021 kell 15.35)

> Muudatused:

> * Uuendati keelevahetajate loendit

> * Värskendas failiteabe jaotist

> * Värskendas failiajaloo jaotist

> * Versioonis 4 muid muudatusi pole

Versioon 5 (varsti saadaval)

> Muudatused:

> * Varsti

> * Versioonis 5 muid muudatusi pole

Versioon 6 (varsti saadaval)

> Muudatused:

> * Varsti

> * Versioonis 6 muid muudatusi pole

Versioon 7 (varsti saadaval)

> Muudatused:

> * Varsti

> * Versioonis 7 muid muudatusi pole

Versioon 8 (varsti saadaval)

> Muudatused:

> * Varsti

> * Versioonis 8 muid muudatusi pole

***

## jalus

Olete jõudnud selle faili lõppu!

##### EOF

***
