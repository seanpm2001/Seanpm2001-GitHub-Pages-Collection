část využití ry

> * Přidány další věci k pokladně

> * Přidán index

> * Přidáno zápatí

> * Žádné další změny ve verzi 1

Verze 2 (čtvrtek 8. dubna 2021 v 17:18)

> Změny:

> * Aktualizována část názvu

> * Aktualizován index

> * Přidány informace o tom, jak můžete pomoci

> * Přidána sekce s informacemi o sponzorovi

> * Aktualizována část s informacemi o souboru

> * Aktualizována část historie souborů

> * Žádné další změny ve verzi 2

Verze 3 (čtvrtek 8. dubna 2021 v 17:27)

> Změny:

> * Opravené překladové odkazy

> * Aktualizován index

> * Opravena duplicitní položka mimo téma v sekci „Co můžete udělat, abyste pomohli“

> * Aktualizována sekce s informacemi o sponzorovi

> * Aktualizována část s informacemi o souboru

> * Aktualizována část historie souborů

> * Žádné další změny ve verzi 3

Verze 4 (pátek 23. dubna 2021 v 15:35)

> Změny:

> * Aktualizován seznam jazykových přepínačů

> * Aktualizována část s informacemi o souboru

> * Aktualizována část historie souborů

> * Žádné další změny ve verzi 4

Verze 5 (již brzy)

> Změny:

> * Již brzy

> * Žádné další změny ve verzi 5

Verze 6 (již brzy)

> Změny:

> * Již brzy

> * Žádné další změny ve verzi 6

Verze 7 (již brzy)

> Změny:

> * Již brzy

> * Žádné další změny ve verzi 7

Verze 8 (již brzy)

> Změny:

> * Již brzy

> * Žádné další změny ve verzi 8

***

## Zápatí

Dostali jste se na konec tohoto souboru!

##### EOF

***
