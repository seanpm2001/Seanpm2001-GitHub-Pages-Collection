***

##### Superiore

_Leggi questo articolo in un'altra lingua: _

** La lingua corrente è: ** `Inglese (USA)` _ (potrebbe essere necessario correggere le traduzioni per correggere l'inglese che sostituisce la lingua corretta) _

_🌐 Elenco delle lingue_

** Ordinati per: ** `A-Z`

[Opzioni di ordinamento non disponibili] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanese | [am አማርኛ] (/. github / README_AM.md) Amarico | [ar عربى] (/.github/README_AR.md) Arabo | [hy հայերեն] (/. github / README_HY.md) Armeno | [az Azərbaycan dili] (/. github / README_AZ.md) Azero | [eu Euskara] (/. github /README_EU.md) Basco | [be Беларуская] (/. Github / README_BE.md) Bielorusso | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosniaco | [bg български] (/. Github / README_BG.md) Bulgaro | [ca Català] (/. Github / README_CA.md) Catalano | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Cinese (semplificato) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Cinese (tradizionale) | [co Corsu] (/. Github / README_CO.md) Corso | [hr Hrvatski] (/. Github / README_HR.md) Croato | [cs čeština] (/. Github / README_CS .md) Ceco | [da dansk] (README_DA.md) Danese | [nl Nederlands] (/. github / README_ NL.md) Olandese | [** en-us English **] (/. github / README.md) Inglese | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estone | [tl Pilipino] (/. github / README_TL.md) Filippino | [fi Suomalainen] (/. github / README_FI.md) Finlandese | [fr français] (/. github / README_FR.md) Francese | [fy Frysk] (/. github / README_FY.md) Frisone | [gl Galego] (/. github / README_GL.md) Galiziano | [ka ქართველი] (/. github / README_KA) Georgiano | [de Deutsch] (/. github / README_DE.md) Tedesco | [el Ελληνικά] (/. github / README_EL.md) Greco | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Creolo haitiano | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiano | [he עִברִית] (/. github / README_HE.md) Ebraico | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ungherese | [è Íslenska] (/. github / README_IS.md) Islandese | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Islandese | [ga Gaeilge] (/. github / README_GA.md) Irlandese | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Giapponese | [jw Wong jawa] (/. github / README_JW.md) Giavanese | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazako | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Coreano (Sud) | [ko-north 문화어] (README_KO_NORTH.md) Coreano (Nord) (NON ANCORA TRADOTTO) | [ku Kurdî] (/. github / README_KU.md) Curdo (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirghizistan | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latino | [lt Lietuvis] (/. github / README_LT.md) Lituano | [lb Lëtzebuergesch] (/. github / README_LB.md) Lussemburghese | [mk Македонски] (/. github / README_MK.md) Macedone | [mg malgascio] (/. github / README_MG.md) malgascio | [ms Bahasa Melayu] (/. github / README_MS.md) Malese | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltese | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolo | [my မြန်မာ] (/. github / README_MY.md) Myanmar (birmano) | [ne नेपाली] (/. github / README_NE.md) Nepalese | [no norsk] (/. github / README_NO.md) Norvegese | [o ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persiano [pl polski] (/. github / README_PL.md) Polacco | [pt português] (/. github / README_PT.md) Portoghese | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Non sono disponibili lingue che iniziano con la lettera Q | [ro Română] (/. github / README_RO.md) Rumeno | [ru русский] (/. github / README_RU.md) Russo | [sm Faasamoa] (/. github / README_SM.md) Samoano | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Gaelico scozzese | [sr Српски] (/. github / README_SR.md) Serbo | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Singalese | [sk Slovák] (/. github / README_SK.md) Slovacco | [sl Slovenščina] (/. github / README_SL.md) Sloveno | [so Soomaali] (/. github / README_SO.md) Somalo | [[es en español] (/. github / README_ES.md) Spagnolo | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Svedese | [tg Тоҷикӣ] (/. github / README_TG.md) Tagicco | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatarico | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Tailandese | [tr Türk] (/. github /README_TR.md) Turco | [tk Türkmenler] (/. github / README_TK.md) Turkmeno | [uk Український] (/. github / README_UK.md) Ucraino | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbeko | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamita | [cy Cymraeg] (/. github / README_CY.md) Gallese | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Disponibile in 110 lingue (108 senza contare l'inglese e il nordcoreano, poiché il nordcoreano non è stato ancora tradotto [Leggi qui] (/ OldVersions / coreano (nord ) /README.md))

Le traduzioni in lingue diverse dall'inglese sono tradotte automaticamente e non sono ancora accurate. Nessun errore è stato ancora corretto a partire dal 5 febbraio 2021. Segnala gli errori di traduzione [qui] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) assicurati di eseguire il backup della correzione con fonti e guidami, dato che non conosco bene altre lingue oltre all'inglese (ho intenzione di trovare un traduttore alla fine) per favore cita [wiktionary] (https://en.wiktionary.org) e altre fonti nel tuo rapporto. In caso contrario, la pubblicazione della correzione verrà rifiutata.

Nota: a causa delle limitazioni con l'interpretazione del markdown di GitHub (e praticamente ogni altra interpretazione del markdown basata sul web) facendo clic su questi collegamenti verrai reindirizzato a un file separato su una pagina separata che non è la mia pagina del profilo GitHub. Verrai reindirizzato al [repository seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), dove è ospitato il README.

Le traduzioni vengono eseguite con Google Translate a causa del supporto limitato o inesistente per le lingue di cui ho bisogno in altri servizi di traduzione come DeepL e Bing Translate (piuttosto ironico per una campagna anti-Google) Sto lavorando per trovare un'alternativa. Per qualche ragione, la formattazione (collegamenti, divisori, grassetto, corsivo, ecc.) È incasinata in varie traduzioni. È noioso da risolvere e non so come risolvere questi problemi nelle lingue con caratteri non latini e per le lingue da destra a sinistra (come l'arabo) è necessario ulteriore aiuto per risolvere questi problemi

A causa di problemi di manutenzione, molte traduzioni non sono aggiornate e utilizzano una versione obsoleta di questo file di articolo "README". Serve un traduttore. Inoltre, a partire dal 23 aprile 2021, mi ci vorrà del tempo per far funzionare tutti i nuovi collegamenti.

***

# È ora di tagliare Widevine

Questo è un articolo sul motivo per cui dovresti smettere di usare Google WideVine (DRM) e disinstallarlo. DRM deve essere rimosso. Questo articolo ti aiuterà a fare la tua scelta (se non l'hai già fatto) WideVine è altamente anticoncorrenziale ed estremamente restrittivo e sta distruggendo la libertà dei video su Internet.

Tagliamo il WideVine e abbracciamo un Internet aperto.

***

# Indice

[00.0 - Top] (# Top)

> [00.1 - Leggi questo articolo in una lingua diversa]

> [00.2 - Titolo] (# It-is-time-to-cut-Widevine)

> [00.3 - Indice] (# Indice)

[01.0 - Panoramica] (# Panoramica)

[02.0 - Anti-competitivo] (# Anti-competitivo)

[03.0 - Mancanza di libertà] (# Mancanza di libertà)

[04.0 - Utilizzo della memoria] (# Utilizzo della memoria)

[05.0 - Privacy] (# Privacy)

[06.0 - Metodi alternativi] (# Metodi alternativi)

[07.0 - Cosa puoi fare per aiutare] (# Cosa-puoi-fare-per-aiutare)

[08.0 - Altre cose da controllare] (# Altre cose da controllare)

[09.0 - Informazioni sull'articolo] (# Informazioni sull'articolo)

> [09.0.1 - Stato del software] (# Stato del software)

> [09.0.2 - Informazioni sullo sponsor] (# Informazioni sullo sponsor)

[10.0 - Cronologia file] (# Cronologia file)

[11.0 - Piè di pagina] (# piè di pagina)

> [11.9 - EOF] (# EOF)

***

## Panoramica

Per altre informazioni sul motivo per cui DRM è un problema, [fare clic qui] (https://www.defectivebydesign.org/)

***

## Anti-competitivo

WideVine è un DRM che deve essere concesso in licenza per essere utilizzato con un browser. Google è estremamente lento nel recensire e accettare le persone e spesso rifiuta che le persone lo utilizzino nei loro prodotti senza ragionamento. [Fonte 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Fonte 2 (il thread di posta elettronica che è andato avanti per oltre 4 mesi e non ha prodotto altro che delusione)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google ha reso molto più difficile per browser come Brave o Firefox competere con la sua spinta a questo pezzo di DRM.

***

## Mancanza di libertà

WideVine viene utilizzato per impedire agli utenti di interagire con i video sui siti Web. È una forma di gestione delle restrizioni digitali che ti impedisce di scaricare il video, visualizzare il video offline o persino fare uno screenshot. È un software proprietario e, a causa dei suoi problemi con la privacy, non è installato di default sulla maggior parte delle distribuzioni Linux. Sta limitando le libertà del web a causa del suo utilizzo da parte di Netflix, Disney e film di YouTube. Il tuo accesso al contenuto può essere revocato in qualsiasi momento senza motivo.

***

## Utilizzo della memoria

WideVine è pessimo sulla memoria. Rispetto alla normale visualizzazione di un video senza DRM, WideVine utilizzerà grandi quantità di CPU e RAM. È un male su battery vita e non offre vantaggi dalla riproduzione di video HTML5 standard.

***

## Privacy

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (sorveglianza_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s”(https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Critica) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -e) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d”(https://www.reuters.com/article/us-alphabet- google-privacy-lawuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o”(https://en.wikipedia.org/wiki/2018_Google_data_breach)[m”(https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 21/01/2019 / tecnologia / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- reclami-per-conto-di-5-milioni-di-utenti-iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e”(https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technolo gy / 2014/01 / what-google-can-really-do-with-nest-or-really-nests-data /) [i] (https://www.cbsnews.com/news/google-education-spies -on-raccoglie-dati-su-milioni-di-bambini-presunti-causa-nuovo-messico-procuratore-generale /) [v] (https://www.nationalreview.com/2018/04/the-student- data-mining-scandal-under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y”(https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -qualcosa-da-nascondere-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Potrei andare avanti con prove di questo , ma ci è voluto molto tempo per trovare e esaminare tutti questi articoli)

La privacy non è una cosa con WideVine. Il software proprietario è progettato in modo che tu non possa vedere cosa sta succedendo. Con la cronologia di Google, è molto probabile cheWideVine è un software aggiuntivo che ti spia, legge i tuoi documenti e altre cose cattive.

Se pensi di non avere nulla da nascondere, ** ti sbagli assolutamente **. Questo argomento è stato smentito molte volte:

[Via Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden ha osservato "Sostenere che non ti interessa il diritto alla privacy perché non hai nulla da nascondere non è diverso dal dire che non ti interessa la libertà di parola perché non hai niente da dire." Quando dici, ' Non ho nulla da nascondere ", stai dicendo," Non mi interessa questo diritto. "Stai dicendo:" Non ho questo diritto, perché sono arrivato al punto in cui devo giustificare "Per come funzionano i diritti, il governo deve giustificare la sua intrusione nei tuoi diritti".

2. Daniel J. Solove ha dichiarato in un articolo per The Chronicle of Higher Education che si oppone all'argomento; ha affermato che un governo può far trapelare informazioni su una persona e causare danni a quella persona, o utilizzare le informazioni su una persona per negare l'accesso ai servizi anche se una persona non ha effettivamente commesso un illecito, e che un governo può causare danni alla propria persona la vita facendo errori. Solove ha scritto: "Quando è coinvolto direttamente, l'argomento del nulla da nascondere può intrappolare, poiché costringe il dibattito a concentrarsi sulla sua ristretta comprensione della privacy. Ma quando si confronta con la pluralità dei problemi di privacy implicati dalla raccolta e dall'uso dei dati del governo oltre la sorveglianza e la divulgazione, l'argomento del nulla da nascondere, alla fine, non ha nulla da dire ".

3. Adam D. Moore, autore di Privacy Rights: Moral and Legal Foundations, ha affermato, "è l'opinione che i diritti siano resistenti al rapporto costi / benefici o ad argomenti di tipo consequenzialista. Qui stiamo rifiutando il punto di vista secondo cui gli interessi della privacy sono il tipo di cose che possono essere scambiate per sicurezza ". Ha anche affermato che la sorveglianza può influenzare in modo sproporzionato alcuni gruppi della società in base all'apparenza, all'etnia, alla sessualità e alla religione.

4. Bruce Schneier, esperto di sicurezza informatica e crittografo, ha espresso opposizione, citando l'affermazione del cardinale Richelieu "Se uno mi desse sei righe scritte dalla mano dell'uomo più onesto, troverei qualcosa in esse per farlo impiccare", riferendosi a come un governo statale può trovare aspetti nella vita di una persona al fine di perseguire o ricattare quell'individuo. Schneier ha anche affermato che "troppi definiscono erroneamente il dibattito come" sicurezza contro privacy ". La vera scelta è libertà contro controllo ".

5. Harvey A. Silverglate ha stimato che la persona comune, in media, commette inconsapevolmente tre crimini al giorno negli Stati Uniti.

6. Emilio Mordini, filosofo e psicoanalista, ha sostenuto che l'argomento "niente da nascondere" è intrinsecamente paradossale. Le persone non hanno bisogno di avere "qualcosa da nascondere" per nascondere "qualcosa". Ciò che è nascosto non è necessariamente rilevante, afferma Mordini. Invece, sostiene che un'area intima che può essere sia nascosta che limitata all'accesso è necessaria poiché, psicologicamente parlando, diventiamo individui attraverso la scoperta che potremmo nascondere qualcosa agli altri.

7. Julian Assange ha dichiarato: "Non c'è ancora una risposta assassina. Jacob Appelbaum (@ioerror) ha una risposta intelligente, chiedendo alle persone che lo dicono di consegnargli il telefono sbloccato e abbassarsi i pantaloni. La mia versione di questo è dire, "beh, se sei così noioso, non dovremmo parlare con te, e nemmeno con chiunque altro", ma filosoficamente, la vera risposta è questa: la sorveglianza di massa è un cambiamento strutturale di massa. Quando la società va male, va per portarti con sé, anche se sei la persona più blanda della terra ".

8. Ignacio Cofone, professore di giurisprudenza, sostiene che l'argomento è errato nei suoi stessi termini perché, ogni volta che le persone rivelano informazioni rilevanti ad altri, rivelano anche informazioni irrilevanti. Queste informazioni irrilevanti hanno costi per la privacy e possono portare ad altri danni, come la discriminazione.

***

# Metodi alternativi

I media non dovrebbero essere limitati, online o offline. Se le persone volessero guardare il video senza DRM, troveranno sempre un modo per farlo. Ogni pezzo di software può essere violato.

[estratto modificato da Wikipedia] Il presidente di Valve Gabe Newell ha affermato che "la maggior parte delle strategie DRM sono semplicemente stupide" perché riducono solo il valore di un gioco agli occhi del consumatore. Newell suggerisce che l'obiettivo dovrebbe invece essere "[creare] maggior valore per i clienti attraverso il valore del servizio". Si noti che Valve gestisce Steam, un servizio che funge da negozio online per giochi per PC, nonché un servizio di social networking e una piattaforma DRM

Questo punto non è valido solo per i videogiochi, può essere applicato a qualsiasi cosa su un computer. Il tuo computer non dovrebbe avere il controllo completo di un'azienda pazza che utilizza una cattiva intelligenza artificiale per eliminare i suoi utenti e il loro lavoro (YouTube, ecc.) E ha un record così negativo. Il tuo computer non dovrebbe essere limitato perché un'azienda si rifiuta di condividere come un bambino che si comporta male. Il tuo computer dovrebbe essere di tua proprietà,e nessun altro. Dovresti sbarazzarti del DRM del tutto, poiché non vale la pena rinunciare al controllo del tuo computer per il contenuto. Queste aziende hanno centinaia di miliardi di dollari. Se fanno qualcosa di stupido come questo, dovresti protestarlo. Potresti anche scaricare il video altrove e guardarlo, poiché dovrebbero perdere soldi per fare cose stupide come questa. La violazione del copyright non è una brutta cosa. Le persone che non possono permettersi i film li scaricheranno altrove, è successo dall'inizio di Internet globale e con l'invenzione del nastro VHS. Difficilmente incide sulle loro entrate, in quanto comunque non sarebbero in grado di ottenere quei soldi. DRM è difettoso in base alla progettazione.

***

## Cosa puoi fare per aiutare

Puoi protestare contro DRM. Può sembrare insignificante, ma più persone sono contrarie, più si fa al riguardo.

Se sei su Linux e utilizzi Firefox, assicurati che DRM non sia installato (normalmente non lo è per impostazione predefinita) e non preoccuparti di installarlo.

Se sei su Windows o MacOS, potresti avere un tempo molto più difficile, poiché DRM è installato di default su questi sistemi e potrebbe reinstallarsi automaticamente.

Cerca di evitare i seguenti siti:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Fondamentalmente, quasi tutti i servizi di streaming video online dovrebbero essere evitati, poiché la maggior parte di essi utilizza DRM e non è possibile utilizzare il sito senza perdere la libertà. Non ne vale la pena. Invia un messaggio all '[MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) e interrompi lo streaming di questi programmi.

Dovresti anche evitare qualsiasi opzione "gratuita con annunci" sui seguenti siti (poiché questo metodo richiede DRM)

[YouTube] (https://www.youtube.com)

Puoi anche protestare contro DRM con un messaggio sul file `README.md` del tuo progetto. Ecco cosa uso:

`` markdown

***

## Stato del software

Tutti i miei lavori sono liberi da alcune restrizioni. DRM (** D ** igital ** R ** estrictions ** M ** anagement) non è presente in nessuno dei miei lavori.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Questo adesivo è supportato dalla Free Software Foundation. Non ho mai intenzione di includere DRM nei miei lavori.

Sto usando l'abbreviazione "Digital Restrictions Management" invece del più noto "Digital Rights Management" poiché il modo comune di affrontarlo è falso, non ci sono diritti con DRM. L'ortografia "Digital Restrictions Management" è più accurata ed è supportata da [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) e dalla [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Questa sezione viene utilizzata per aumentare la consapevolezza dei problemi con DRM e anche per protestare. DRM è difettoso in base alla progettazione ed è una grave minaccia per tutti gli utenti di computer e per la libertà del software.

Credito immagine: [defectivebydesign.org/drm-free/...”(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

`` `

***
## Altre cose da controllare

[Difettoso in base alla progettazione - Una campagna della Free Software Foundation che sta lavorando per esporre ed eliminare l'utilizzo di DRM] (https://www.defectivebydesign.org/)

[The Google Graveyard (killbygoogle.com) - un elenco ordinato degli oltre 224 prodotti che Google ha ucciso] (https://killedbygoogle.com/)

> [GitHub link] (https://github.com/codyogden/killedbygoogle)

[Alphabet worker union - Il nuovo sindacato dei lavoratori di Google con oltre 800 membri] (https://alphabetworkersunion.org/people/our-union/)

Ci sono altre alternative, basta cercarle.

***

## Informazioni sull'articolo

Tipo di file: `Markdown (* .md)`

Versione file: "4 (venerdì 23 aprile 2021 alle 15:35)"

Conteggio righe (comprese le righe vuote e la riga del compilatore): `354`

### Stato del software

Tutti i miei lavori sono liberi da restrizioni. DRM (** D ** igital ** R ** estrictions ** M ** anagement) non è presente in nessuno dei miei lavori. Questo progetto non contiene alcun DRM, ma parla direttamente di DRM.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Questo adesivo è supportato dalla Free Software Foundation. Non ho mai intenzione di includere DRM nei miei lavori.

***

### Informazioni sullo sponsor

! [SponsorButton.png] (SponsorButton.png) <- Questo non è il pulsante sponsor ufficiale, è un'immagine demo. Non fare clic su di esso se desideri sponsorizzare questo progetto.

Puoi sponsorizzare questo progetto se lo desideri, ma specifica a cosa vuoi donare. [Vedi i fondi a cui puoi donare qui] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Puoi visualizzare altre informazioni sugli sponsor [qui] (https://github.com/seanpm2001/Sponsor-info/)

Provalo! Il pulsante sponsor si trova proprio accanto al pulsante guarda / rimuovi.

***

## Cronologia dei file

Versione 1 (domenica 8 febbraio 2021 alle 16:41)

> Modifiche:

> * Avviato il file / articolo

> * Aggiunta la sezione del titolo

> * Aggiunta una sezione sulla privacy

> * Aggiunta una sezione sulla panoramica

> * Aggiunta la sezione delle informazioni sull'articolo

> * Riferimento all'icona DRM Free

> * Aggiunta la sezione della cronologia dei file

> * Aggiunta la sezione Mancanza di libertà

> * Aggiunta la sezione Anticoncorrenziale

> * Aggiunta la sezione dei metodi alternativi

> * Aggiunto il promemoriary sezione utilizzo

> * Aggiunte le altre cose da controllare nella sezione

> * Aggiunto l'indice

> * Aggiunto il piè di pagina

> * Nessun altro cambiamento nella versione 1

Versione 2 (giovedì 8 aprile 2021 alle 17:18)

> Modifiche:

> * Aggiornata la sezione del titolo

> * Aggiornato l'indice

> * Aggiunte informazioni su cosa puoi fare per aiutare

> * Aggiunta la sezione delle informazioni sugli sponsor

> * Aggiornata la sezione delle informazioni sul file

> * Aggiornata la sezione della cronologia dei file

> * Nessun altro cambiamento nella versione 2

Versione 3 (giovedì 8 aprile 2021 alle 17:27)

> Modifiche:

> * Collegamenti di traduzione fissi

> * Aggiornato l'indice

> * Corretta una voce duplicata fuori tema nella sezione "cosa puoi fare per aiutare"

> * Aggiornata la sezione delle informazioni sugli sponsor

> * Aggiornata la sezione delle informazioni sul file

> * Aggiornata la sezione della cronologia dei file

> * Nessun altro cambiamento nella versione 3

Versione 4 (venerdì 23 aprile 2021 alle 15:35)

> Modifiche:

> * Aggiornato l'elenco dei selettori di lingua

> * Aggiornata la sezione delle informazioni sul file

> * Aggiornata la sezione della cronologia dei file

> * Nessun altro cambiamento nella versione 4

Versione 5 (disponibile a breve)

> Modifiche:

> * Prossimamente

> * Nessun altro cambiamento nella versione 5

Versione 6 (disponibile a breve)

> Modifiche:

> * Prossimamente

> * Nessun altro cambiamento nella versione 6

Versione 7 (disponibile a breve)

> Modifiche:

> * Prossimamente

> * Nessun altro cambiamento nella versione 7

Versione 8 (disponibile a breve)

> Modifiche:

> * Prossimamente

> * Nessun altro cambiamento nella versione 8

***

## Piè di pagina

Hai raggiunto la fine di questo file!

##### EOF

***
