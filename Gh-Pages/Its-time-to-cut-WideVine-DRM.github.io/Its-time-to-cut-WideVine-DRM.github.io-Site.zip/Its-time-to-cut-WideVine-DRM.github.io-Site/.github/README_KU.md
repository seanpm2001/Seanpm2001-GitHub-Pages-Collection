***

##### Jor

_ Vê gotarê bi zimanek cûda bixwînin: _

** Zimanê heyî ev e: ** `Englishngilîzî (DY)` _ (dibe ku werger hewce be werin rast kirin ku Englishngilîzî li şûna zimanê rast were rastkirin) _

_🌐 Navnîşa zimanan_

** Bi rêzkirin: ** `A-Z`

[Vebijarkên Rêzkirinê çênabe] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanî | [am አማርኛ] (/. github / README_AM.md) Amharî | [ar عربى] (/.github/README_AR.md) Erebî | [hy Kurdî] (/. github / README_HY.md) Ermenî | [az Azərbaycan dili] (/. github / README_AZ.md) Azerî | [eu Euskara] (/. github /README_EU.md) Baskî | [Be Беларуская] (/. Github / README_BE.md) Belarusî | [bn বাংলা] (/. Github / README_BN.md) Bengalî | [bs Bosanski] (/. Github / README_BS.md) Bosnî | [bg български] (/. Github / README_BG.md) Bulgarî | [ca Català] (/. Github / README_CA.md) Katalanî | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Çînî (Hêsankirî) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Çînî (Kevneşopî) | [co Corsu] (/. Github / README_CO.md) Korsîkî | [hr Hrvatski] (/. Github / README_HR.md) Croatian | [cs čeština] (/. Github / README_CS .md) Çekî | [da dansk] (README_DA.md) Danîmarkî | [nl Nederlands] (/. github / README_ NL.md) Hollandî | [** en-us **ngilîzî **] (/. github / README.md) Englishngilîzî | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estonî | [tl Pîlîpînî] (/. github / README_TL.md) Filîpînî | [fi Suomalainen] (/. github / README_FI.md) Fînî | [fr français] (/. github / README_FR.md) Fransî | [frysk] (/. github / README_FY.md) frîsî | [gl Galego] (/. github / README_GL.md) Galîkî | [ka Kurd] (/. github / README_KA) Gurcî | [de Deutsch] (/. github / README_DE.md) Almanî | [el Ελληνικά] (/. github / README_EL.md) Grekî | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Creole Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawayî | [ew] (/. github / README_HE.md) Hebrewbranî | [silav हिन्दी] (/. github / README_HI.md) Hindî | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Macarîstan | [islenska ye] (/. github / README_IS.md) Icelandiczlandî | [ig Igbo] (/. github / README_IG.md) Igbo | [id Indonesia Indonesia] (/. github / README_ID.md) Icelandiczlandî | [ga Gaeilge] (/. github / README_GA.md) îrlandî | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japonî | [jw Wong jawa] (/. github / README_JW.md) Javayî | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kanada | [kk Қазақ] (/. github / README_KK.md) Kazakî | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-başûr 韓國 語] (/. github / README_KO_SOUTH.md) Koreyî (Başûr) | [ko-bakûr] (README_KO_NORTH.md) Koreyî (Bakurî) (H YN T TRN WERGERAND) | [ku Kurdî] (/. github / README_KU.md) Kurdî (Kurmancî) | [ky Keys] (/. github / README_KY.md) Kirgizîstan | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latînî] (/. github / README_LA.md) Latînî | [lt Lietuvis] (/. github / README_LT.md) Lîtvanî | [lb Lëtzebuergesch] (/. github / README_LB.md) Luksembûrg | [mk Македонски] (/. github / README_MK.md) Makedonî | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Melayu Bahasa] (/. github / README_MS.md) Malayî | [ml മലയാളം] (/. github / README_ML.md) Malayî | [mt Malti] (/. github / README_MT.md) Maltese | [mi Maorî] (/. github / README_MI.md) Maorî | [mr मराठी] (/. github / README_MR.md) Maratî | [mn Mongol] (/. github / README_MN.md) Mongolî | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Burmese) | [ne नेपाली] (/. github / README_NE.md) Nepalî | [no norsk] (/. github / README_NO.md) Norwêcî | [an ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Paştî | [fa فارسی] (/. github / README_FA.md) | Farisî [pl polski] (/. github / README_PL.md) Polonî | [pt português] (/. github / README_PT.md) Portekîzî | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Pencabî | Zimanên ku bi herfa Q | dest pê dikin tune [ro Română] (/. github / README_RO.md) Romanî | [ru руский] (/. github / README_RU.md) Rûsî | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Scottish Gaelic | [sr Српски] (/. github / README_SR.md) Sirbî | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindî | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovakî | [sl Slovenščina] (/. github / README_SL.md) Slovenî | [so Soomaali] (/. github / README_SO.md) Somalî | [[es en español] (/. github / README_ES.md) Spanishspanî | [su Sundanis] (/. github / README_SU.md) Sundanî | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Swêdî | [tg Тоҷикӣ] (/. github / README_TG.md) Tacîkî | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github /README_TR.md) Tirkî | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukranî | [ur اردو] (/. github / README_UR.md) urdû | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Viyetnamî | [cy Cymraeg] (/. github / README_CY.md) Welşî | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Di 110 zimanan de heye (108 dema ku whenngilîzî û Koreya Bakur nayê hesibandin, ji ber ku Koreya Bakur hîn nehatiye wergerandin [Li ser vê yekê bixwînin] (/ OldVersions / Koreyî (Bakur ) /README.md))

Wergerên bi zimanên din ji bilî Englishngilîzî bi makîneyê têne wergerandin û hêj ne rast in. Ji 5-ê Sibata 2021-an û vir ve tu xelet nehatin rast kirin. Ji kerema xwe xeletiyên wergerandinê ragihînin [li vir] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-ine-DRM/issues/) piştrast bikin ku rastkirina xwe bi çavkanî û rêberiya min bikin, ji ber ku ez ji bilî Englishngilîzî bi zimanên din baş nizanim (ez dixwazim ku di dawiyê de wergêrekî wergirim) ji kerema xwe [wiktionary] (https://en.wiktionary.org) û çavkaniyên din di rapora xwe de bi nav bikin. Ku wiya neke dê encama redkirina rastkirina ku hatî weşandin encam bide.

Nîşe: ji ber hûrgelan bi şîrovekirina nîşankirinê ya GitHub (û hema hema her şiroveya tevnavkirina nîşana nîşankirinê) bi tikandina van lînkan dê we ber bi pelê veqetandî ve vegerîne ser rûpelek cûda ku ne rûpelê profîla min a GitHub e. Hûn ê werin veguhastin [embara] seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), ku README lê tê mêvan kirin.

Werger ji hêla Google Translate ve têne kirin ji ber ku ji zimanên ku di karûbarên wergêra yên din ên mîna DeepL û Bing Translate de ji min re hewce ne hewceyê piştgiriyê ne ji bo zimanên ku ez hewce dikim (ji bo kampanyayek dij-Google xweşik îronîk e) Ez li ser dîtina alternatîfek dixebitim. Ji ber hin sedeman, formatkirin (girêdan, dabeşker, qelew, pît, û hwd.) Di wergerandinên cûrbecûr de tevlihev dibe. Çareserkirin westiyayî ye, û ez nizanim çawa van mijaran di zimanên bi tîpên ne-latînî de sererast bikim, û ji zimanên rastê çepê (mîna Erebî) ji bo sererastkirina van pirsgirêkan arîkariyek zêde hewce ye

Ji ber pirsgirêkên parastinê, gelek werger mêjû ne û guhertoyek kevn a vê pelê gotara `README` bikar tînin. Wergêr pêdivî ye. Di heman demê de, ji 23-ê Nîsana 2021-an ve, ew ê demekê bikişîne ku ez hemî girêdanên nû bixebitînim.

***

# Dem dema birrîna Widevine e

Ev gotarek e ku hûn çima dev ji bikaranîna Google WideVine (DRM) berdin û wê rakin. Pêdivî ye ku DRM were rakirin. Ev gotar dê alîkariya we bike ku hûn hilbijartina xwe bikin (heke we berê ne kiribe) WideVine pir dij-pêşbazî ye, û pir tixûbdar e, û azadiya vîdyoyan li ser Internetnternetê tune dike.

Ka em WideVine-ê qut bikin û Internetnternetek vekirî hembêz bikin.

***

# Indexndeks

[00.0 - Top] (# Top)

> [00.1 - Vê gotarê bi zimanek cûda bixwînin]

> [00.2 - Sernav] (# Dem-birîn-birrîna-Winevine)

> [00.3 - Endeks] (# Endeks)

[01.0 - Serpêhatî] (# Pêşandan)

[02.0 - Dijberî pêşbaziyê] (# Dijberî pêşbaziyê)

[03.0 - Tunebûna azadiyê] (# Tunebûna azadiyê)

[04.0 - Bikaranîna bîranînê] (# Bikaranîna bîranînê)

[05.0 - Taybetmendî] (# Taybetmendî)

[06.0 - Rêbazên alternatîf] (# Rêbazên alternatîf)

[07.0 - Ya ku hûn dikarin ji bo alîkariyê bikin] (# Ya-ku-hûn-dikarin-bikin-ku-bibin-alîkar)

[08.0 - Tiştên din ên ku werin kontrol kirin] (# Other-things-to-check-out)

[09.0 - Agahdariya gotarê] (# Agahdarî-gotar)

> [09.0.1 - Rewşa nermalavê] (# Nermalav-statû)

> [09.0.2 - Agahdariya sponsor] (# agahdariya sponsor)

[10.0 - Dîroka Dosyayê] (# Dîroka Dosyayê)

[11.0 - Footer] (# Footer)

> [11.9 - EOF] (# EOF)

***

## Kurtahî

Ji bo agahdariya din di derbarê çima DRM pirsgirêk e, [vir bitikîne] (https://www.defectivebydesign.org/)

***

## Dijberî hevrikiyê

WideVine DRM ye ku pêdivî ye ku were destûr kirin ku bi gerokê re were bikar anîn. Google di pêdaçûn û pejirandina mirovan de pir dereng e, û bi gelemperî mirovan red dike ku ew bêyî sedem di hilberên xwe de bikar bînin. [Çavkaniya 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Çavkaniya 2 (Mijara e-nameyê ku zêdeyî 4 mehan dom kir û ji xeyalşikestinê pê ve tiştek nebû)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google ji bo gerokên mîna Brave an Firefox pir dijwartir kiriye ku bi pêlkirina vê perçeya DRM re hevrikiyê bikin.

***

## Nebûna azadiyê

WideVine tê bikar anîn da ku bikarhêner li ser malperên bi vîdyoyê re nekevin têkiliyê. Ew rengek rêveberiyên sînorkirinên dîjîtal e ku nahêle hûn vîdyoyê dakêşin, vîdyoyê negirêdayî bibînin, an jî dîmenek dîmender bigirin. Ew nermalava xwerû ye û ji ber pirsgirêkên wê yên bi nepeniyê ve, ew ji hêla default ve li piraniya belavkirinên Linux nayê saz kirin. Ew ji ber karanîna fîlimên Netflix, Disney, û YouTube azadiyên tevnê bi sînor dike. Destûra we ya naverokê dikare di her demê de bê sedem were girtin.

***

## Bikaranîna bîranînê

WideVine li ser bîranînê xirab e. Bi nisbet bi tenê normal dîtina vîdyoyek bêyî DRM, WideVine dê mîqdarên giran ên CPU û RAM bikar bîne. Li ba xerab ejiyana ttery, û ew tu sûdê ji playback video HTML5 standard nade.

***

## Taybetmendî

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (Bernameya Çavdêriyê)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-y-privacy-your//) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-heye-li-we-nepenîtiyê heye) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) Counsludes(https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / têketin / çima-googles-sîxurî-bikar-b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he daneyên alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Rexne) [b] (https://spreadprivacy.com/thre-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -mînak / tiştek-ku-ve-veşêrin-nîqaş-tune-tiştek-bêje /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-di derheqê-hûn-de-hûn dikarin-bibînin-û-jê-bikin-wê-an / / [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your- -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-y-bata-data-heres-how-company-shares-monetizes -û) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html))dd((https://www.reuters.com/article/us-alphabet- google-nepenîti-doz-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -bi-ser-li-zarokan-berhevkirina-danasîn-li-perwerdehiyê-krombotan) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)rejnewso((https://en.wikipedia.org/wiki/2018_Google_data_breach))mml(https:// moz.com/bl og / ku-google-ê-xeta-berhevkirina-rêzê-xêz dike) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / teknolojî / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- îdîa-li ser navê-5-mîlyon-bikarhênerên iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) pêşniyar dikin -fon-nayê-bikar anîn /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / agahdarî-teknolojî gy / 2014/01 / çi-google-dikare-bi-hêlînê-an-bi rastî-hêlînê-bike-bike /) [ez] (https://www.cbsnews.com/news/google-education-spies -di-li-bi-mîlyonan-zarok-doz-doz-nû-meksîko-parêzerê-giştî / berhev dike [v] (https://www.nationalreview.com/2018/04/the-student- -skandal-dan-danîn-bin-pozên me /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html))y ](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -di-ve-veşêrin-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Ez dikarim bi delîlên vê yekê herim û herim , lê demek dirêj hewce bû ku em van gotaran bibînin û derbas bibin)

Taybetmendî bi WideVine re ne tiştek e. Nermalava xwedan hatiye sêwirandin da ku hûn nebînin ka çi diqewime her tiştî. Bi dîroka Googles re, pir gengaz e kuWideVine nermalavek pêvek e ku sîxurî li we dike, belgeyên we dixwîne, û tiştên din ên xerab.

Heke hûn difikirin ku tiştek we tune ku hûn veşêrin, ** hûn bi tevahî xelet in **. Ev nîqaş gelek caran hate pûç kirin:

[Bi Wîkîpediya] (https://en.wikipedia.org/wiki/Tiştek_ji_vekirina_argument# rexne)

1. Edward Snowden got "Nîqaşkirina ku hûn ji mafê nepenîtiyê nafikirin ji ber ku tiştek we tune ku hûn veşêrin ji gotina ku hûn ji axaftina azad re naxwazin ji ber ku we tiştek tune ku bibêjin ne cuda ye." Gava ku hûn dibêjin, ' Tiştek min tune ku ez veşêrim, 'tu dibêjî,' Ez ji vî mafî nafikirim. 'Tu dibêjî,' vî mafê min tune, ji ber ku ez gihîştim nuqteya ku divê ez rastdar bikim ew. 'Awayê xebata mafan, hukûmet neçar ma ku destdirêjiya xwe ya nav mafên we bike. "

2. Daniel J. Solove di gotarek xwe de ji bo The Chronicle of Higher Perwerde diyar kir ku ew dijberiya argumanê dike; wî diyar kir ku hukûmetek dikare di derheqê kesek de agahiyan derxe û zirarê bide wî kesî, an jî agahdariya li ser kesek bikar bîne da ku dev ji gihîştina karûbaran bernede her çend ku kesek bi rastî neheqî nekiribe, û ku hikûmetek dikare zirarê bide kesek kesek jiyan bi çêkirina xeletiyan. Solove nivîsand "Gava ku rasterast mijûl dibe, niqaşa tiştek ku were veşartin dikare bikeve bin daviyê, çimkî ew nîqaşê neçar dike ku li ser têgihiştina xweya teng a nepeniyê bisekine. Lê gava ku bi pirjimariya pirsgirêkên nepenîtiyê re têkildar be ku ji hêla berhevkirina daneyên hikûmetê ve girêdayî ye û ji çavdêriyê û bikar tîne eşkerekirin, nîqaşa ku tiştek neyê veşartin, di dawiyê de, tiştek tune ku bêje. "

3. Adam D. Moore, nivîskarê Mafên Nehfiyê: Bingehên Moralî û Hiqûqî, nîqaş kir, "ew nerîn e ku maf li hember lêçûn / sûd an nîqaşên celebîparêz ên bergirî ne. Li vir em nerîna ku berjewendiyên nepenîtiyê cûre ne red dikin. tiştên ku ji bo ewlehiyê dikarin werin bazirganîkirin. " Wî her weha diyar kir ku çavdêrî dikare li ser bingeha xuyangî, etnîsîte, zayendîtî û olî li ser hin komên civakê bêserûber bandor bike.

4. Bruce Schneier, pisporê ewlehiya komputerê û kriptograf, dijberiya xwe anî ziman, gotina Cardinal Richelieu "Ger yek şeş rêzên ku bi destê zilamê herî rast nivîsandî bide min, ez ê tiştek di wan de bibînim ku wî bidarve bikim", ji bo ku çawa hukûmetek eyalet dikare alîyan di jîyana kesek de bibîne da ku ew kes were darizandin an şantaj bike. Schneier her wiha got "Pir pir bi xeletî nîqaşê wekî 'ewlehî li hember nepenîtiyê' vedibêjin. Hilbijartina rastîn azadî li hember kontrolê ye. "

5. Harvey A. Silverglate texmîn kir ku kesê hevpar, navînî, bi nezanî rojê sê felonî li DY dike.

6. Emilio Mordini, fîlozof û psîkoanalîzm, digot ku nîqaşa "tiştek ku were veşartin" bi xwezayî paradoksal e. Ji bo ku "tiştek" veşêrin ne hewce ye ku mirov "tiştek veşêrin". Ya ku veşartî ne pêdivî ye têkildar e, îdîa dike Mordini. Di şûna wî de, ew nîqaş dike ku qadek nezîkî ya ku hem dikare were veşartin û hem jî sînorkirina gihîştinê pêdivî ye ji ber ku, ji hêla derûnî ve, em bi saya vedîtina ku em dikarin tiştek ji yên din re veşêrin dibin kes.

7. Julian Assange got "Hîn bersivek kuştî tune. Jacob Appelbaum (@ioerror) bersivek jêhatî ye, ji kesên ku vê dibêjin re dipirsin ku paşê wî têlefona xwe venebû û pantikên xwe bikişînin. Guhertoya min a wiya ye ku bêje, 'baş e, heke hûn ew qas bêzar in wê hingê divê em ne bi we re bipeyivin, û ne jî divê kesek din jî', lê bi felsefî, bersiva rast ev e: Çavdêriya girseyî guherînek pêkhatî ya girseyî ye. Dema ku civak xirab bibe, ew ê da ku tu bi xwe re bibî, heke tu kesê herî şermok ê li ser rûyê erdê bî. "

8. Ignacio Cofone, profesorê hiqûqê, dibêje ku nîqaş di warê xwe de çewt e ji ber ku, her ku mirov agahdariya pêwendîdar ji yên din re eşkere dike, ew jî agahdariya bêbandor eşkere dikin. Ev agahdariya bêkêmasî lêçûnên nepenîtiyê hene û dikare bibe sedema zirarên din, wekî cûdakariyê.

***

# Rêbazên alternatîf

Pêdivî ye ku çapemenî neyê qedexekirin, serhêl an jî negirêdayî. Heke mirov dixwest vîdyoyê bêyî DRM temaşe bike, ew ê her dem awayek vê yekê bibînin. Her perçeyek nermalavê dikare were şikandin.

[Beşê ji Wikipedia-yê hate guherandin] Serokê Valve Gabe Newell got "pir stratejiyên DRM tenê lal in" ji ber ku ew tenê nirxa lîstikek di çavên xerîdar de kêm dikin. Newell pêşniyar dike ku armanc divê li şûna "[afirandina] nirxa ji bo xerîdaran bi hêla nirxa xizmetê ve". Têbînî ku Valve Steam-ê kar dike, karûbarek ku ji bo lîstikên PC-yê wekî dikanek serhêl, û her weha karûbarek torgiloka civakî û platformek DRM-yê

Ev xal tenê ji bo lîstikên vîdyoyê ne derbasdar e, ew dikare li ser her tiştî li ser komputerê were sepandin. Pêdivî ye ku komputera we bi tevahî di bin kontrola pargîdaniyek dîn de nebe ku Intellistîxbarata Artificial ya xerab bikar tîne da ku bikarhênerên xwe û karê wan (YouTube, û hwd.) Jê bibire û tomarek wusa xirab hebe. Pêdivî ye ku komputera we neyê tixûbdar kirin ji ber ku pargîdaniyek red dike ku mîna zarokek nebaş parve bike. Pêdivî ye ku komputera we ji we re be,û kesek din tune. Divê hûn bi tevahî ji DRM-ê xilas bibin, ji ber ku naverok ne hêja ye ku hûn dev ji kontrola komputera xwe berdin. Bi sedan mîlyar dolarên van pargîdaniyan hene. Ger ew tiştek ehmeqiyek wusa bikin, divê hûn wê protesto bikin. Hûn dikarin tenê vîdyoyê li cîhek din dakêşînin û lê binihêrin, ji ber ku divê ew ji bo kirina ehmeqên bi vî rengî drav winda bikin. Binpêkirina mafparêziyê ne tiştek xirab e. Mirovên ku nekarin fîlim bistînin dê wan li deverek din dakêşînin, ew ji destpêka Internetnterneta cîhanî ve û bi dahênana kaseta VHS çêdibe. Ew bi zor bandor li dahata wan nake, ji ber ku ew ê neçar bimînin ku wiya bi her awayî bigirin. DRM ji hêla sêwiranê ve kêmas e.

***

## Hûn dikarin ji bo alîkariyê çi bikin

Hûn dikarin DRM protesto bikin. Dibe ku ew bêwate xuya bike, lê çiqas bêtir kesên ku li dijî derdikevin, ew qas di derbarê wê de tê kirin.

Ger hûn li Linux-ê ne û Firefox-ê bikar tînin, bila DRM neyê saz kirin (ew bi gelemperî ne bi rêkûpêk e) û xwe ji bo sazkirinê neêşînin.

Heke hûn li ser Windows an MacOS in, dibe ku we demek pir dijwartir hebe, ji ber ku DRM li ser van pergalên bi default ve hatî saz kirin, û dibe ku ji nû ve were sazkirin.

Biceribînin ku ji malperên jêrîn dûr bixin:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Di bingeh de, hema hema ji her karûbarê weşana vîdyoyê ya serhêl divê bête dûr xistin, ji ber ku pirraniya wan DRM bikar tînin û hûn nikarin bêyî ku azadiya xwe winda bikin malperê bikar bînin. Ew ne hêja ye. [MPAA] -yê (https://en.wikipedia.org/wiki/Motion_Picture_Association) peyamek bişînin û weşana van pêşandan rawestînin.

Her weha divê hûn li ser malperên jêrîn ji vebijarkên "belaş bi reklaman" dûr bisekinin (ji ber ku ev rêbaz DRM hewce dike)

[YouTube] (https://www.youtube.com)

Her weha hûn dikarin li ser pelê projeyên xwe `README.md` bi peyamek DRM protesto bikin. Ya ku ez bikar tînim ev e:

`` nîşankirin

***

## Rewşa nermalavê

Hemî xebatên min belaş hin qedexe ne. DRM (** D ** igital ** R ** vegotin ** M ** tevger) di tu xebatên min de tune.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ev sticker ji hêla Weqfa Nermalava Azad ve tê piştgirî kirin. Ez qet naxwazim ku DRM têxim nav karên xwe.

Ez kurteya "Birêvebirina Qedexeyên Dîjîtal" li şûna ku bêtir tê zanîn "Birêvebiriya Mafên Dîjîtal" bikar tîne ji ber ku awayê hevpar ê xîtabê wê derew e, tu mafên DRM tune. Nivîsîna "Birêvebirina Qedexeyên Dîjîtal" rasttir e, û ji hêla [Richard M. Stallman (RMS)]] (https://en.wikipedia.org/wiki/Richard_Stallman) û [Weqfa Nermalava Azad (FSF)] ve tê piştgirî kirin () https://en.wikipedia.org/wiki/Found_Software_Foundation_Free)

Ev beş tête bikar anîn ku ji bo pirsgirêkên bi DRM re hişyar bikin, û her weha protesto bikin. DRM ji hêla sêwiranê ve kêmas e û ji bo hemî bikarhênerên computer û azadiya nermalavê xeterek mezin e.

Baweriya wêneyê: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

""

***
## Tiştên din ên ku derketin

[Ji hêla sêwiranê ve kêmas - Ji hêla Weqfa Nermalava Belaş ve kampanyayek ku li ser eşkerekirin û ji holê rakirina karanîna DRM dixebite] (https://www.defectivebydesign.org/)

[Google Graveyard (kuştinbygoogle.com) - navnîşek dabeşkirî ya 224+ hilberên ku Google kuştîye] (https://killedbygoogle.com/)

> [Girêdana GitHub] (https://github.com/codyogden/killedbygoogle)

[Sendîkaya karkerên alfabeyê - Sendîkaya karkerên nû li Google bi zêdeyî 800 endamên xwe] (https://alphabetworkersunion.org/people/our-union/)

Alternatîfên din hene, tenê li wan bigerin.

***

## Agahdariya gotarê

Pelê pelê: `Markdown (* .md)`

Guhertoya pelê: `4 (Fridayn, 23ê Avrêl 2021 di 3:35 danê êvarê de)`

Hejmara rêzikan (xetên vala û rêza berhevkar jî tê de): `354`

### Rewşa nermalavê

Hemî xebatên min ji tixûban bêpar in. DRM (** D ** igital ** R ** vegotin ** M ** tevger) di tu xebatên min de tune. Di vê projeyê de DRM tune, lê ew rasterast qala DRM dike.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Ev sticker ji hêla Weqfa Nermalava Azad ve tê piştgirî kirin. Ez qet naxwazim ku DRM têxim nav karên xwe.

***

### Agahdariya sponsor

! [SponsorButton.png] (SponsorButton.png) <- Ev ne pişkoka fermî ya sponsor e, ew wêneyek demo ye. Heke hûn dixwazin sponsoriya vê projeyê bikin wê bikirtînin.

Heke hûn bixwazin hûn dikarin sponsoriya vê projeyê bikin, lê ji kerema xwe tiştê ku hûn dixwazin bexş bikin diyar bikin. [Darayên ku hûn dikarin bexş bikin li vir bibînin] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Hûn dikarin agahdariyên sponsor ên din jî bibînin [li vir] (https://github.com/seanpm2001/Sponsor-info/)

Biceribînin! Bişkoka sponsor li tenişta bişkoja temaşekirinê / nehiştinê rast e.

***

## Dîroka pelê

Guhertoya 1 (Yekşem, 8ê Sibatê 2021 li 4:41 danê êvarê)

> Guherandin:

> * Pel / gotar dest pê kir

> * Beşa sernavê zêde kir

> * Di derbarê nepeniyê de beşek zêde kir

> * Derbarê dîmenê de beşek zêde kir

> * Beşa agahdariya gotarê zêde kir

> * Nîqaşa DRM Free îkonê

> * Beşa dîroka pelê lê zêde kir

> * Beşa Kêmbûna azadiyê zêde kir

> * Beşa Dij-pêşbazî zêde kir

> * Beşa rêbazên alternatîf zêde kir

> * Memo zêde kirbeşa karanîna ry

> * Tiştên din jî zêdekirin da ku hûn beşê seh bikin

> * Sermaseyê zêde kir

> * Pêpelok zêde kir

> * Di guhertoya 1 de guhertinên din çênabin

Guhertoya 2 (Pêncşem, 8ê Avrêl 2021 li 5:18 danê êvarê)

> Guherandin:

> * Beşa sernavê nûve kir

> * Indeksa nû kir

> * Li ser ku hûn dikarin ji bo alîkariyê bikin agahdariyê zêde kirin

> * Beşa agahdariya sponsor zêde kir

> * Beşa agahdariya pelê nûve kir

> * Beşa dîroka pelê nûve kir

> * Di guhertoya 2-an de guherînek din çênebû

Guhertoya 3 (Pêncşem, Nîsana 8th 2021 li 5:27 danê êvarê)

> Guherandin:

> * Zencîreyên wergerandinê yên sabît

> * Indeksa nû kir

> * Di beşa `hûn dikarin çi bikin da ku bibin alîkar` dupatîkek, têketina mijarê sererast kir

> * Beşa agahdariya sponsor nûve kir

> * Beşa agahdariya pelê nûve kir

> * Beşa dîroka pelê nûve kir

> * Di guhertoya 3-an de guherînek din çênebû

Guhertoya 4 (Fridayn, 23 Nîsan 2021 li 3:35 danê êvarê)

> Guherandin:

> * Navnîşa veguherîna zimên nûve kir

> * Beşa agahdariya pelê nûve kir

> * Beşa dîroka pelê nûve kir

> * Di guhertoya 4-an de guherînek din çênebû

Guhertoya 5 (Di nêzîk de tê)

> Guherandin:

> * Zûtir tê

> * Di guhertoya 5-an de guherînek din çênebû

Guhertoya 6 (Di nêzîk de tê)

> Guherandin:

> * Zûtir tê

> * Di guhertoya 6-an de tu guhertinek din tune

Guhertoya 7 (Di nêzîk de tê)

> Guherandin:

> * Zûtir tê

> * Di guhertoya 7-an de tu guherînek din tune

Guhertoya 8 (Di nêzîk de tê)

> Guherandin:

> * Zûtir tê

> * Di guhertoya 8-an de guherînek din çênebû

***

## Footer

Hûn gihîştine dawiya vê pelê!

##### EOF

***
