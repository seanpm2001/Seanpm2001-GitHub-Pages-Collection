***

＃＃＃＃＃ 顶部

_以另一种语言阅读本文：_

**当前语言是：**`英语（美国）`_（翻译可能需要更正以修复英语，以替换正确的语言）_

_🌐语言列表_

**排序：**`A-Z`

[排序选项不可用]（https://github.com/Degoogle-your-Life）

（[af Afrikaans]（/。github / README_AF.md）Afrikaans | [sq Shqiptare]（/。github / README_SQ.md）阿尔巴尼亚语| [amአማርኛ]（/。github / README_AM.md）Amharic | [arعربى] （/.github/README_AR.md）阿拉伯语| [hyհայերեն]（/。github / README_HY.md）亚美尼亚语| [azAzərbaycandili]（/。github / README_AZ.md）阿塞拜疆| [eu Euskara]（/。github /README_EU.md）巴斯克语| [beБеларуская]（/。github / README_BE.md）白俄罗斯语| [bnবাংলা]（/。github / README_BN.md）孟加拉语| [bs Bosanski]（/。github / README_BS.md）波斯尼亚语| [bgбългарски]（/。github / README_BG.md）保加利亚语| [caCatalà]（/。github / README_CA.md）加泰罗尼亚语| [ceb Sugbuanon]（/ .. github / README_CEB.md）Cebuano | [ny Chichewa ]（/。github / README_NY.md）Chichewa | [zh-CN简体中文]（/。github / README_ZH-CN.md）简体中文| [zh-t中国传统的）]（/。github / README_ZH -T.md）中文（繁体）| [co Corsu]（/。github / README_CO.md）科西嘉语| [hr Hrvatski]（/。github / README_HR.md）克罗地亚语| [csčeština]（/。github / README_CS .md）捷克语| [da dansk]（README_DA.md）丹麦语| [nl Nederlands]（/。github / README_ NL.md）荷兰语| [** zh-cn英语**]（/。github / README.md）英语| [EO世界语]（/。github / README_EO.md）世界语| [et Eestlane]（/。github / README_ET.md）爱沙尼亚语| [tl Pilipino]（/。github / README_TL.md）菲律宾| [fi Suomalainen]（/。github / README_FI.md）芬兰语| [frfrançais]（/。github / README_FR.md）法语| [fy Frysk]（/。github / README_FY.md）弗里斯兰语| [gl Galego]（/。github / README_GL.md）加利西亚语| [kaქართველი]（/。github / README_KA）格鲁吉亚语| [de Deutsch]（/。github / README_DE.md）德语| [elΕλληνικά]（/。github / README_EL.md）希腊语| [guગુજરાતી]（/。github / README_GU.md）古吉拉特语| [htKreyòlayisyen]（/。github / README_HT.md）海地克里奥尔语| [ha Hausa]（/。github / README_HA.md）Hausa | [hawŌleloHawaiʻi]（/。github / README_HAW.md）夏威夷语| [heעִברִית]（/。github / README_HE.md）希伯来语| [hiहिन्दी]（/。github / README_HI.md）印地语| [hmn Hmong]（/。github / README_HMN.md）Hmong | [hu Magyar]（/。github / README_HU.md）匈牙利语| [是Íslenska]（/。github / README_IS.md）冰岛语| [ig Igbo]（/。github / README_IG.md）Igbo | [id bahasa Indonesia]（/。github / README_ID.md）冰岛语| [ga Gaeilge]（/。github / README_GA.md）爱尔兰语| [it Italiana / Italiano]（/。github / README_IT.md）| [ja日本语]（/。github / README_JA.md）日语| [jw Wong颌骨]（/。github / README_JW.md）Javanese | [knಕನ್ನಡ]（/。github / README_KN.md）卡纳达语| [kkҚазақ]（/。github / README_KK.md）哈萨克语| [kmខ្មែរ]（/。github / README_KM.md）高棉语| [rw Kinyarwanda]（/。github / README_RW.md）Kinyarwanda | [ko-south韩国语]（/。github / README_KO_SOUTH.md）韩语（南）| [ko-north문화어]（README_KO_NORTH.md）朝鲜语（北部）（尚未翻译）| [kuKurdî]（/。github / README_KU.md）库尔德语（Kurmanji）| [kyКыргызча]（/。github / README_KY.md）吉尔吉斯语| [loລາວ]（/。github / README_LO.md）老挝| [la Latine]（/。github / README_LA.md）拉丁语| [lt Lietuvis]（/。github / README_LT.md）立陶宛语| [lbLëtzebuergesch]（/。github / README_LB.md）卢森堡语| [mkМакедонски]（/。github / README_MK.md）马其顿语| [mg马达加斯加语]（/。github / README_MG.md）马达加斯加语| [ms Bahasa Melayu]（/。github / README_MS.md）马来语| [mlമലയാളം]（/。github / README_ML.md）马拉雅拉姆语| [mt Malti]（/。github / README_MT.md）马耳他语| [mi Maori]（/。github / README_MI.md）毛利人| [mrमराठी]（/。github / README_MR.md）马拉地语| [mnМонгол]（/。github / README_MN.md）蒙古语| [myမြန်မာ]（/。github / README_MY.md）缅甸（缅甸）| [neनेपाली]（/。github / README_NE.md）尼泊尔语| [no norsk]（/。github / README_NO.md）挪威文| [或ଓଡିଆ（ଓଡିଆ）]（/。github / README_OR.md）Odia（奥里亚语）| [psپښتو]（/。github / README_PS.md）普什图语| [faفارسی]（/。github / README_FA.md）|波斯语[pl polski]（/。github / README_PL.md）波兰语| [ptportuguês]（/。github / README_PT.md）葡萄牙语| [paਪੰਜਾਬੀ]（/。github / README_PA.md）旁遮普语|没有可用字母Q |开头的语言。 [roRomână]（/。github / README_RO.md）罗马尼亚语| [ruрусский]（/。github / README_RU.md）俄语| [sm Faasamoa]（/。github / README_SM.md）萨摩亚语| [gdGàidhligna h-Alba]（/。github / README_GD.md）Scots Gaelic | [srСрпски]（/。github / README_SR.md）塞尔维亚语| [st Sesotho]（/。github / README_ST.md）Sesotho | [sn Shona]（/。github / README_SN.md）Shona | [sdسنڌي]（/。github / README_SD.md）信德语| [siසිංහල]（/。github / README_SI.md）僧伽罗语| [sk斯洛伐克语]（/。github / README_SK.md）斯洛伐克语| [slSlovenščina]（/。github / README_SL.md）斯洛文尼亚语| [so Soomaali]（/。github / README_SO.md）索马里文| [[es enespañol]（/。github / README_ES.md）西班牙语| [su Sundanis]（/。github / README_SU.md）Sundanese | [sw Kiswahili]（/。github / README_SW.md）斯瓦希里语| [sv Svenska]（/。github / README_SV.md）瑞典语| [tgТоҷикӣ]（/。github / README_TG.md）塔吉克语| [taதமிழ்]（/。github / README_TA.md）泰米尔语| [ttТатар]（/。github / README_TT.md）塔塔尔语| [teతెలుగు]（/。github / README_TE.md）泰卢固语| [thไทย]（/。github / README_TH.md）泰国语| [trTürk]（/。github /README_TR.md）土耳其语| [tkTürkmenler]（/。github / README_TK.md）土库曼人| [ukУкраїнський]（/。github / README_UK.md）乌克兰语| [urاردو]（/。github / README_UR.md）乌尔都语| [ugئۇيغۇر]（/。github / README_UG.md）维吾尔语| [uz O'zbek]（/。github / README_UZ.md）乌兹别克语| [viTiếngViệt]（/。github / README_VI.md）越南语| [cy Cymraeg]（/。github / README_CY.md）威尔士语| [xh isiXhosa]（/。github / README_XH.md）Xhosa | [yiיידיש]（/。github / README_YI.md）意第绪语| [yo Yoruba]（/。github / README_YO.md）Yoruba | [zu Zulu]（/。github / README_ZU.md）Zulu）有110种语言版本（不算英语和朝鲜语时为108种语言，因为朝鲜语尚未翻译。 ）/README.md））

除英语以外的其他语言的翻译是机器翻译的，尚不准确。截至2021年2月5日，尚未修复任何错误，请在此处报告翻译错误（https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/）确保使用以下方法备份您的更正资料来源并为我提供指导，因为我不太了解英语（我打算最终聘请翻译人员）以外的其他语言，请在报告中引用[wiktionary]（https://en.wiktionary.org）和其他来源。否则，将拒绝发布更正。

注意：由于GitHub对markdown的解释（以及几乎所有其他基于Web的markdown解释）的限制，单击这些链接会将您重定向到单独页面上的单独文件，该页面不是我的GitHub个人资料页面。您将被重定向到托管README的[seanpm2001 / seanpm2001存储库]（https://github.com/seanpm2001/seanpm2001）。

由于我在其他翻译服务（例如DeepL和Bing Translate（对于反Google广告系列而言颇具讽刺意味））中需要的语言有限或不提供支持，因此使用Google Translate进行翻译。我正在寻找替代方案。由于某种原因，格式（链接，分隔符，粗体，斜体等）在各种翻译中都被弄乱了。解决起来很繁琐，而且我不知道如何使用非拉丁字符的语言来解决这些问题，从右到左的语言（例如阿拉伯语）需要额外的帮助来解决这些问题。

由于维护问题，许多翻译版本已经过时，并且使用的是本“ README”文章文件的过时版本。需要翻译器。另外，从2021年4月23日开始，要使所有新链接正常工作还需要一段时间。

***

＃是时候剪掉Widevine

本文是有关为何应停止使用Google WideVine（DRM）并将其卸载的文章。 DRM需要删除。本文将帮助您做出选择（如果您尚未选择）WideVine具有高度的反竞争性和限制性，并且正在破坏Internet上视频的自由度。

让我们切入WideVine并拥抱开放的Internet。

***

＃ 指数

[00.0-页首]（＃Top）

> [00.1-用另一种语言阅读本文]

> [00.2-标题]（＃Witvine的时间到了）

> [00.3-索引]（＃Index）

[01.0-概述]（＃概述）

[02.0-反竞争]（＃反竞争）

[03.0-缺乏自由]（＃缺乏自由）

[04.0-内存使用率]（＃Memory-usage）

[05.0-隐私]（＃Privacy）

[06.0-替代方法]（＃Alternate-methods）

[07.0-您可以提供的帮助]（＃您可以提供的帮助）

[08.0-其他要签出的东西]

[09.0-文章信息]（＃Article-info）

> [09.0.1-软件状态]（＃Software-status）

> [09.0.2-赞助商信息]（＃Sponsor-info）

[10.0-文件历史记录]（＃File-history）

[11.0-页脚]（＃Footer）

> [11.9-EOF]（＃EOF）

***

＃＃ 概述

有关为什么DRM会引起问题的其他信息，请单击此处（https://www.defectivebydesign.org/）

***

##反竞争

WideVine是一种DRM，必须获得许可才能与浏览器一起使用。 Google在审查和接受人们方面非常慢，并且经常拒绝人们在没有任何理由的情况下在其产品中使用它。 [源1]（https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/）[源2（持续4个月以上的电子邮件线程，除了令人失望之外，没有其他结果）] （https://blog.samuelmaddock.com/widevine/gmail-thread.html）Google使得像Brave或Firefox这样的浏览器很难与它推动这一DRM竞争。

***

＃＃ 缺乏自由

WideVine用于防止用户与网站上的视频进行交互。这是一种数字限制管理形式，可防止您下载视频，离线观看视频，甚至无法截屏。它是专有软件，由于存在隐私问题，因此在大多数Linux发行版中均未默认安装。由于Netflix，迪士尼和YouTube电影都在使用网络，因此它限制了网络的自由。您对内容的访问权可随时无缘无故被带走。

***

＃＃ 内存使用情况

WideVine的内存不足。与仅观看不带DRM的视频相比，WideVine将使用大量的CPU和RAM。爸不好寿命长，并且无法从标准HTML5视频播放中受益。

***

＃＃ 隐私

[G]（https://en.wikipedia.org/wiki/Criticism_of_Google）[o]（https://en.wikipedia.org/wiki/PRISM_（surveillance_program））[o]（https：//www.reddit .com / r / degoogle /）[g]（https://www.wired.com/2012/06/opinion-google-is-evil/）[l]（https://securitygladiators.com/chrome-privacy -bad /）[e]（https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/）[h]（https：// www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy）[a]（https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1）[a]（https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html）[v]（https：//www.huffpost .com / entry / why-googles-spying-on-use_b_3530296）[e]（https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ）[r]（https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data）[y]（https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html）[v]（https：// protonmail。 com / blog / google-privacy-problem /）[e]（https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /）[r]（https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy）[y]（https://en.wikipedia.org/wiki/Nothing_to_hide_argument#批评）[b]（https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/）[a]（https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /）[d]（https://www.cnet.com/how-to/google-collects-a-frightening-amount-of-关于您的数据可以找到并删除，现在/）[r]（https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501）[e]（https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -and）[c]（https://www.wired.com/story/google-tracks-you -privacy /）[o]（https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy）[r]（https： //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H）[w]（https://www.wired.com/story/health-fitness-data-privacy/）[h]（https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks）[e]（https://mashable.com/article/google-android-data-collection-study/）[n]（https：// www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html）[i]（https://www.maketecheasier.com/studyandroid-data-google-ios-apple/）[t] （https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/）[c]（https：// www。 cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line）[e]（https://mashable.com/article/google-android-data-collection-study/）[s]（https：/ /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/）[t]（https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html）[o]（https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data-代表5百万名iPhone用户代表）[u]（https://time.com/23782/google-flu-trends-big-data-problems/）[s]（https：/ /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /）[r]（https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you。 html）[p]（https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/）[r]（https：// arstechnica .com / information-technolo gy / 2014/01 / what-google-can-really-do-with-nest-or-really-nests-data /）[i]（https://www.cbsnews.com/news/google-education-spies -on-collects-on-collects-data-on-millions-of-kids-alleges-lawsuit-new-mexico-attorney-general /）[v]（https://www.nationalreview.com/2018/04/the-student- data-mining-scandal-under-our-noses /）[a]（https://www.wired.com/insights/2012/10/google-opt-out/）[c]（https：// www。 nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -something-to-hide-40689565c550）[。]（https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c）（我可以继续对此进行论证，但是花了很长时间才找到并阅读所有这些文章）

隐私与WideVine无关。专有软件经过精心设计，因此您根本看不到正在发生的事情。根据Google的历史，很可能WideVine是另一种监视您，阅读文档和其他不良信息的软件。

如果您认为自己没有什么可隐藏的，那么**您绝对是错误的**。这个论点被多次揭穿：

[通过维基百科]（https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism）

1.爱德华·斯诺登（Edward Snowden）说：“争辩说您不关心隐私权是因为您没有什么可隐瞒的，这与说您不在乎言论自由是因为您无话可说。”我没什么可隐瞒的，”您说，“我不在乎这项权利。”您在说，“我没有这项权利，因为我必须要证明自己是正确的。权利的运作方式是，政府必须证明其侵犯您权利的合理性。”

2. Daniel J. Solove在《高等教育纪事》的一篇文章中说，他反对这一论点。他说，政府可能泄漏有关某人的信息并对该人造成损害，或者即使某人实际上没有从事不正当行为，也可能利用有关某人的信息拒绝获得服务，并且政府可能对某人的个人造成损害通过犯错误来生活。索洛夫（Solove）写道：“直接参与时，无所不包的论点可能会令人反感，因为它迫使辩论集中在对隐私的狭understanding理解上。但是，当面对由政府数据收集和使用所带来的众多隐私问题时，就超出了监视和监视的范围。披露，最后无话可说的说法无话可说。”

3.隐私权：道德与法律基金会的作者亚当·D·摩尔认为：“这是权利抗拒成本/收益或因果主义之类的论点。在这里，我们拒绝认为隐私利益属于这种观点。可以交易以换取安全性的东西。”他还指出，监视可以根据外观，种族，性取向和宗教对社会中的某些群体产生不成比例的影响。

4.计算机安全专家和密码学家布鲁斯·施耐尔（Bruce Schneier）表示反对，他引用枢机主教黎塞留（Richelieu）的话说：“如果给我六句由最诚实的人手写的文字，我会发现其中有些东西使他被绞死”。州政府如何起诉或勒索该人的生活。施耐尔还指出：“太多人错误地将辩论描述为'安全与隐私'。真正的选择是自由与控制。”

5. Harvey A. Silverglate估计，普通百姓平均每天在美国不知情的情况下犯下三项重罪。

6.哲学家和心理分析家埃米利奥·莫迪尼（Emilio Mordini）认为，“无可掩盖”的论点本质上是自相矛盾的。人们不需要具有“隐藏的东西”即可隐藏“某些东西”。莫迪尼说，隐藏的东西不一定是相关的。相反，他认为必须同时隐藏和限制访问的私密区域是必要的，因为从心理上讲，我们通过发现可以向他人隐藏某些东西而成为个人。

7.朱利安·阿桑奇（Julian Assange）表示：“尚无杀手.。雅各布·阿佩尔鲍姆（@ioerror）做出了明智的回应，要求说这话的人将手机解锁并放下裤子，我的意思是， “好吧，如果你是如此无聊，那么我们不应该和你说话，其他任何人也不要说话。”但从哲学上讲，真正的答案是：大规模监视是一种大规模的结构性变化。即使你是地球上最卑鄙的人，也要接受它。”

8.法学教授伊格纳西奥·科丰（Ignacio Cofone）辩称，该论点本身是错误的，因为每当人们向他人披露相关信息时，他们也会披露不相关的信息。这些不相关的信息会增加隐私成本，并可能导致其他危害，例如歧视。

***

＃替代方法

媒体不受限制，无论是在线还是离线。如果人们想在没有DRM的情况下观看视频，他们将总是找到一种方法。每个软件都可以破解。

Valve总裁Gabe Newell指出，“大多数DRM策略只是愚蠢的”，因为它们只会降低消费者眼中的游戏价值。 Newell建议目标应该是“通过服务价值为客户创造更大的价值”。请注意，Valve经营着Steam，该服务可以充当PC游戏的在线商店，还提供社交网络服务和DRM平台。

这一点不仅对视频游戏有效，还可以应用于计算机上的任何东西。您的计算机不应完全控制一个疯狂的公司，该公司使用不良的AI来删除其用户及其工作（YouTube等），并拥有如此糟糕的记录。您的计算机不应受到限制，因为公司拒绝像行为不端的孩子一样分享信息。您的计算机应归您所有，再没有其他人了。您应该完全摆脱DRM，因为其中的内容不值得放弃对计算机的控制。这些公司拥有数千亿美元的资产。如果他们这样做是愚蠢的，您应该抗议。您甚至可以将视频下载到其他地方然后观看，因为他们做这种愚蠢的事情应该会亏本。侵犯版权不是一件坏事。买不起电影的人可以将它们下载到其他地方，这是自全球互联网开始以来以及VHS磁带发明以来一直在发生的事情。这几乎不会影响他们的收入，因为他们无论如何也无法获得这笔钱。 DRM设计有缺陷。

***

##您可以做些什么来帮助您

您可以抗议DRM。它看起来似乎微不足道，但是反对它的人越多，它所做的就越多。

如果您使用的是Linux并使用Firefox，请确保未安装DRM（通常默认情况下未安装DRM）并且不要费心安装它。

如果您使用的是Windows或MacOS，则可能会遇到很多困难，因为DRM默认安装在这些系统上，并且可能会自动重新安装。

尽量避免以下站点：

[Hulu]（https://hulu.com）

[迪士尼+]（https://www.disneyplus.com/）

[Paramount +]（https://www.paramountplus.com/）

基本上，几乎所有在线视频流服务都应避免使用，因为其中大多数使用DRM，并且您不能在失去自由的情况下使用该网站。这是不值得的。向[MPAA]（https://en.wikipedia.org/wiki/Motion_Picture_Association）发送消息，然后停止流式传输这些节目。

您还应该避免在以下网站上使用任何“免费广告”选项（因为此方法需要DRM）

[YouTube]（https://www.youtube.com）

您也可以在项目的“ README.md”文件中使用一条消息来抗议DRM。这是我使用的：

降价

***

##软件状态

我所有的作品都是免费的，有一些限制。我的任何作品中都没有DRM（** D **原始** R **限制** M **管理）。

！[DRM-free_label.en.svg]（DRM-free_label.en.svg）

此标签由自由软件基金会支持。我从不打算在自己的作品中加入DRM。

我使用的缩写是“数字限制管理”，而不是更广为人知的“数字权限管理”，因为解决它的常见方法是错误的，DRM没有权限。 [Richard M. Stallman（RMS）]（https://en.wikipedia.org/wiki/Richard_Stallman）和[Free Software Foundation（FSF）]支持拼写“数字限制管理”， https://zh.wikipedia.org/wiki/Free_Software_Foundation）

本部分用于提高对DRM问题的认识，并进行抗议。 DRM在设计上是有缺陷的，并且是对所有计算机用户和软件自由的重大威胁。

图片来源：[defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label）

***

```

***
##其他要检查的东西

[设计有缺陷-自由软件基金会的一项活动，致力于公开和消除DRM使用情况]（https://www.defectivebydesign.org/）

[Google Graveyard（killedbygoogle.com）-Google杀死了224种以上产品的排序列表]（https://killedbygoogle.com/）

> [GitHub链接]（https://github.com/codyogden/killedbygoogle）

[字母工会-Google的新工会有800多名成员]（https://alphabetworkersunion.org/people/our-union/）

还有其他替代品，只需搜索它们即可。

***

##文章信息

文件类型：`Markdown（* .md）`

档案版本：`4（2021年4月23日，星期五，下午3:35）`

行数（包括空行和编译器行）：354

###软件状态

我所有的作品都不受限制。我的任何作品中都没有DRM（** D **原始** R **限制** M **管理）。该项目不包含任何DRM，但直接讨论DRM。

！[DRM-free_label.en.svg]（DRM-free_label.en.svg）

此标签由自由软件基金会支持。我从不打算在自己的作品中加入DRM。

***

###赞助商信息

！[SponsorButton.png]（SponsorButton.png）<-这不是官方的赞助商按钮，它是演示图像。如果您想赞助这个项目，请不要单击它。

您可以根据需要赞助此项目，但请指定您要捐赠的内容。 [在这里查看您可以捐赠的资金]（https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors）

您可以在此处查看其他赞助商信息（https://github.com/seanpm2001/Sponsor-info/）

试试看！赞助商按钮在观看/取消观看按钮旁边。

***

##文件历史

版本1（2021年2月8日，星期日，下午4:41）

>变更：

> *开始文件/文章

> *添加了标题部分

> *添加了有关隐私的部分

> *添加了有关概述的部分

> *添加了文章信息部分

> *引用了DRM Free图标

> *添加了文件历史记录部分

> *添加了缺乏自由部分

> *添加了反竞争部分

> *添加了替代方法部分

> *添加了备忘录ry使用部分

> *添加了其他要签出的部分

> *添加索引

> *添加了页脚

> *版本1中没有其他更改

第2版​​（2021年4月8日，星期四，下午5:18）

>变更：

> *更新了标题部分

> *更新了索引

> *添加了有关您可以做什么的信息

> *添加了赞助商信息部分

> *更新了文件信息部分

> *更新了文件历史记录部分

> *版本2中没有其他更改

版本3（2021年4月8日，星期四，下午5:27）

>变更：

> *固定翻译链接

> *更新了索引

> *修复了“您可以做些什么”部分中的重复的，脱离主题的条目

> *更新了赞助商信息部分

> *更新了文件信息部分

> *更新了文件历史记录部分

> *版本3中没有其他更改

第4版（2021年4月23日，星期五，下午3:35）

>变更：

> *更新了语言切换器列表

> *更新了文件信息部分

> *更新了文件历史记录部分

> *版本4中没有其他更改

版本5（即将推出）

>变更：

> *即将推出

> *版本5中没有其他更改

版本6（即将推出）

>变更：

> *即将推出

> *版本6中没有其他更改

版本7（即将推出）

>变更：

> *即将推出

> *版本7中没有其他更改

版本8（即将推出）

>变更：

> *即将推出

> *版本8中没有其他更改

***

##页脚

您已到达此文件的末尾！

##### EOF

***
