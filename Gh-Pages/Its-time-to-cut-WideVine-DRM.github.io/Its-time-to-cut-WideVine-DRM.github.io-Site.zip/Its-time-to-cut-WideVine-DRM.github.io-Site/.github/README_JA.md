***

＃＃＃＃＃ 上

_この記事を別の言語で読む：_

**現在の言語は次のとおりです：** `英語（米国）` _（正しい言語を置き換える英語を修正するには、翻訳を修正する必要がある場合があります）_

_🌐言語のリスト_

**並べ替え：** `A-Z`

[並べ替えオプションは利用できません]（https://github.com/Degoogle-your-Life）

（[af Afrikaans]（/。github / README_AF.md）Afrikaans | [sq Shqiptare]（/。github / README_SQ.md）アルバニア語| [amአርኛ]（/。github / README_AM.md）アルメニア語| [arعربى] （/.github/README_AR.md）アラビア語| [hyհայերեն]（/。github / README_HY.md）アルメニア語| [azAzərbaycandili]（/。github / README_AZ.md）Azerbaijani | [eu Euskara]（/。github /README_EU.md）バスク語| [beБеларуская]（/。github / README_BE.md）ベラルーシ語| [bnবাংলা]（/。github / README_BN.md）ベンガリ語| [bs Bosanski]（/。github / README_BSバスク語| [bgбългарски]（/。github / README_BG.md）ブルガリア語| [caCatalà]（/。github / README_CA.md）カタロニア語| [ceb Sugbuanon]（/。github / README_CEB.md）Cebuano | [ny Chichewa ]（/。github / README_NY.md）Chichewa | [zh-CN简体中文]（/。github / README_ZH-CN.md）中国語（簡略化）| [zh-t中國傳統的）]（/。github / README_ZH -T.md）中国語（従来）| [co Corsu]（/。github / README_CO.md）コルシカ語| [hr Hrvatski]（/。github / README_HR.md）クロアチア語| [csčeština]（/。github / README_CS .md）チェコ語| [da dansk]（README_DA.md）デンマーク語| [nl Nederlands]（/。github / README_ NL.md）オランダ語| [** en-us英語**]（/。github / README.md）英語| [EOエスペラント]（/。github / README_EO.md）エスペラント| [et Eestlane]（/。github / README_ET.md）エストニア語| [tl Pilipino]（/。github / README_TL.md）フィリピン人| [fi Suomalainen]（/。github / README_FI.md）フィンランド語| [frfrançais]（/。github / README_FR.md）フランス語| [fy Frysk]（/。github / README_FY.md）フリジア語| [gl Galego]（/。github / README_GL.md）ガリシア語| [kaქართველი]（/。github / README_KA）グルジア語| [de Deutsch]（/。github / README_DE.md）ドイツ語| [elΕλληνικά]（/。github / README_EL.md）ギリシャ語| [guગુજરાતી]（/。github / README_GU.md）グジャラート語| [htKreyòlayisyen]（/。github / README_HT.md）ハイチ語クレオール語| [haハウサ語]（/。github / README_HA.md）ハウサ語| [hawŌleloHawaiʻi]（/。github / README_HAW.md）ハワイ語| [彼はעִברִית]（/。github / README_HE.md）ヘブライ語| [こんにちはहिन्दी]（/。github / README_HI.md）ヒンディー語| [hmn Hmong]（/。github / README_HMN.md）モン族| [hu Magyar]（/。github / README_HU.md）ハンガリー語| [isÍslenska]（/。github / README_IS.md）アイスランド語| [ig Igbo]（/。github / README_IG.md）Igbo | [id bahasa Indonesia]（/。github / README_ID.md）アイスランド語| [ga Gaeilge]（/。github / README_GA.md）アイルランド語| [イタリア語/イタリア語]（/。github / README_IT.md）| [ja日本語]（/。github / README_JA.md）日本語| [jw Wongjawa]（/。github / README_JW.md）ジャワ語| [knಕನ್ನಡ]（/。github / README_KN.md）カンナダ語| [kkҚазақ]（/。github / README_KK.md）カザフ語| [kmខ្មែរ]（/。github / README_KM.md）クメール語| [rw Kinyarwanda]（/。github / README_RW.md）Kinyarwanda | [ko-south韓國語]（/。github / README_KO_SOUTH.md）韓国語（南）| [ko-north문화어]（README_KO_NORTH.md）韓国語（北）（まだ翻訳されていません）| [kuKurdî]（/。github / README_KU.md）クルド語（クルマンジー）| [kyКыргызча]（/。github / README_KY.md）キルギス語| [loລາວ]（/。github / README_LO.md）ラオス| [la Latine]（/。github / README_LA.md）ラテン語| [lt Lietuvis]（/。github / README_LT.md）リトアニア語| [lbLëtzebuergesch]（/。github / README_LB.md）ルクセンブルク語| [mkМакедонски]（/。github / README_MK.md）マケドニア語| [mgマダガスカル]（/。github / README_MG.md）マダガスカル| [ms Bahasa Melayu]（/。github / README_MS.md）マレー語| [mlമലയാളം]（/。github / README_ML.md）マラヤーラム語| [mt Malti]（/。github / README_MT.md）マルタ語| [miマオリ]（/。github / README_MI.md）マオリ| [mrमराठी]（/。github / README_MR.md）マラーティー語| [mnМонгол]（/。github / README_MN.md）モンゴル語| [myမြန်မာ]（/。github / README_MY.md）ミャンマー（ビルマ語）| [neनेपाली]（/。github / README_NE.md）ネパール語| [norskなし]（/。github / README_NO.md）ノルウェー語| [またはଓଡିଆ（ଓଡିଆ）]（/。github / README_OR.md）オディア語（オリヤー語）| [psپښتو]（/。github / README_PS.md）パシュトゥー語| [faفارسی]（/。github / README_FA.md）|ペルシア語[pl polski]（/。github / README_PL.md）ポーランド語| [ptportuguês]（/。github / README_PT.md）ポルトガル語| [paਪੰਜਾਬੀ]（/。github / README_PA.md）パンジャブ語|文字Qで始まる言語はありません| [roRomână]（/。github / README_RO.md）ルーマニア語| [ruрусский]（/。github / README_RU.md）ロシア語| [sm Faasamoa]（/。github / README_SM.md）サモア語| [gdGàidhlignah-Alba]（/。github / README_GD.md）スコットランドゲール語| [srСрпски]（/。github / README_SR.md）セルビア語| [st Sesotho]（/。github / README_ST.md）セソト語| [snショナ語]（/。github / README_SN.md）ショナ語| [sdسنڌي]（/。github / README_SD.md）シンド語| [siසිංහල]（/。github / README_SI.md）シンハラ語| [skスロバキア語]（/。github / README_SK.md）スロバキア語| [slSlovenščina]（/。github / README_SL.md）スロベニア語| [so Soomaali]（/。github / README_SO.md）ソマリア語| [[esenespañol]（/。github / README_ES.md）スペイン語| [su Sundanis]（/。github / README_SU.md）スンダ語| [sw Kiswahili]（/。github / README_SW.md）スワヒリ語| [sv Svenska]（/。github / README_SV.md）スウェーデン語| [tgТоҷикӣ]（/。github / README_TG.md）タジク語| [taதமிழ்]（/。github / README_TA.md）タミル語| [ttТатар]（/。github / README_TT.md）タタール| [teతెలుగు]（/。github / README_TE.md）テルグ語| [thไทย]（/。github / README_TH.md）タイ語| [trTürk]（/。github /README_TR.md）トルコ語| [tkTürkmenler]（/。github / README_TK.md）トルクメン語| [ukУкраїнський]（/。github / README_UK.md）ウクライナ語| [urاردو]（/。github / README_UR.md）ウルドゥー語| [ugئۇيغۇر]（/。github / README_UG.md）ウイグル| [uz O'zbek]（/。github / README_UZ.md）ウズベク語| [viTiếngViệt]（/。github / README_VI.md）ベトナム語| [cy Cymraeg]（/。github / README_CY.md）ウェールズ語| [xh isiXhosa]（/。github / README_XH.md）コサ語| [yiיידיש]（/。github / README_YI.md）イディッシュ語| [ヨルバ語]（/。github / README_YO.md）ヨルバ語| [zu Zulu]（/。github / README_ZU.md）Zulu）110言語で利用可能（北朝鮮語はまだ翻訳されていないため、英語と北朝鮮語を数えない場合は108言語[ここで読む]（/ OldVersions / Korean（North ）/README.md））

英語以外の言語での翻訳は機械翻訳されており、まだ正確ではありません。 2021年2月5日の時点では、エラーはまだ修正されていません。翻訳エラーを報告してください[ここ]（https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/）必ず修正内容をバックアップしてください。英語以外の言語はよくわからないので（最終的には翻訳者を雇う予定です）、レポートで[wiktionary]（https://en.wiktionary.org）やその他の情報源を引用してください。そうしないと、公開されている修正が拒否されます。

注：GitHubのマークダウンの解釈（および他のほとんどすべてのWebベースのマークダウンの解釈）の制限により、これらのリンクをクリックすると、GitHubプロファイルページではない別のページの別のファイルにリダイレクトされます。 READMEがホストされている[seanpm2001 / seanpm2001リポジトリ]（https://github.com/seanpm2001/seanpm2001）にリダイレクトされます。

DeepLやBingTranslate（反Googleキャンペーンにとってはかなり皮肉なことです）のような他の翻訳サービスで必要な言語のサポートが制限されているか、まったくサポートされていないため、翻訳はGoogle翻訳で行われます。何らかの理由で、フォーマット（リンク、仕切り、太字、斜体など）がさまざまな翻訳で混乱しています。修正するのは面倒で、ラテン文字以外の言語でこれらの問題を修正する方法がわかりません。これらの問題を修正するには、右から左への言語（アラビア語など）で追加のヘルプが必要です。

メンテナンスの問題により、多くの翻訳は古く、この「README」記事ファイルの古いバージョンを使用しています。翻訳者が必要です。また、2021年4月23日の時点で、すべての新しいリンクが機能するようになるまでしばらく時間がかかります。

***

＃ワイドバインを切る時が来ました

これは、Google WideVine（DRM）の使用を停止してアンインストールする必要がある理由に関する記事です。 DRMを削除する必要があります。この記事は、選択を行うのに役立ちます（まだ選択していない場合）。WideVineは非常に反競争的で、非常に制限的であり、インターネット上のビデオの自由を破壊しています。

WideVineをカットして、オープンインターネットを採用しましょう。

***

＃インデックス

[00.0-トップ]（＃Top）

> [00.1-この記事を別の言語で読む]

> [00.2-タイトル]（＃It-is-time-to-cut-Widevine）

> [00.3-インデックス]（＃インデックス）

[01.0-概要]（＃概要）

[02.0-反競争的]（＃反競争的）

[03.0-自由の欠如]（＃自由の欠如）

[04.0-メモリ使用量]（＃Memory-usage）

[05.0-プライバシー]（＃プライバシー）

[06.0-代替方法]（＃Alternate-methods）

[07.0-あなたが助けるためにできること]（＃What-you-can-do-to-help）

[08.0-その他のチェックアウト]（＃Other-things-to-check-out）

[09.0-記事情報]（＃Article-info）

> [09.0.1-ソフトウェアステータス]（＃Software-status）

> [09.0.2-スポンサー情報]（＃Sponsor-info）

[10.0-ファイル履歴]（＃File-history）

[11.0-フッター]（＃フッター）

> [11.9-EOF]（＃EOF）

***

##概要

DRMが問題となる理由に関するその他の情報については、[ここをクリック]（https://www.defectivebydesign.org/）

***

##反競争的

WideVineは、ブラウザで使用するためにライセンスが必要なDRMです。グーグルは人々のレビューと受け入れに非常に時間がかかり、多くの場合、人々が理由もなく製品にそれを使用することを拒否します。 [出典1]（https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/）[出典2（4か月以上続いたため、失望しただけのメールスレッド）] （https://blog.samuelmaddock.com/widevine/gmail-thread.html）Googleは、BraveやFirefoxなどのブラウザーがこのDRMのプッシュと競合することをはるかに困難にしました。

***

##自由の欠如

WideVineは、ユーザーがWebサイト上のビデオを操作できないようにするために使用されます。これは、ビデオをダウンロードしたり、ビデオをオフラインで表示したり、スクリーンショットを撮ったりすることを防ぐデジタル制限管理の一形態です。これはプロプライエタリソフトウェアであり、プライバシーの問題があるため、ほとんどのLinuxディストリビューションにデフォルトでインストールされていません。 Netflix、Disney、およびYouTubeの映画で使用されているため、Webの自由が制限されています。コンテンツへのアクセスは、理由もなくいつでも奪われる可能性があります。

***

＃＃ メモリ使用量

WideVineはメモリに問題があります。通常、DRMなしでビデオを表示する場合と比較して、WideVineは大量のCPUとRAMを使用します。バに悪い寿命が長く、標準のHTML5ビデオ再生のメリットはありません。

***

##プライバシー

[G]（https://en.wikipedia.org/wiki/Criticism_of_Google）[o]（https://en.wikipedia.org/wiki/PRISM_（surveillance_program））[o]（https：//www.reddit .com / r / degoogle /）[g]（https://www.wired.com/2012/06/opinion-google-is-evil/）[l]（https://securitygladiators.com/chrome-privacy -bad /）[e]（https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/）[h]（https：// www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy）[a]（https://www.vox.com/recode/2020/2 / 21/21146998 / google-new-mexico-children-privacy-school-chromebook-lawsuit）[s]（https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1）[a]（https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html）[v]（https：//www.huffpost .com / entry / why-googles-spying-on-use_b_3530296）[e]（https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ）[r]（https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data）[y]（https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html）[v]（https：// protonmail。 com / blog / google-privacy-problem /）[e]（https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -ブラウザ/）[r]（https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy)[y](https://en.wikipedia.org/wiki/Nothing_to_hide_argument#批判）[b]（https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/）[a]（https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /）[d]（https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-about-you-you-can-find-and-delete-it-now /）[r]（https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501）[e]（https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -および）[c]（https://www.wired.com/story/google-tracks-you -privacy /）[o]（https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy)[r](https： //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H）[w]（https://www.wired.com/story/health-fitness-data-privacy/）[h]（https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks）[e]（https://mashable.com/article/google-android-data-collection-study/）[n]（https：// www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html）[i]（https://www.maketecheasier.com/studyandroid-data-google-ios-apple/)[t] （https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/）[c]（https：//www。 cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line）[e]（https://mashable.com/article/google-android-data-collection-study/）[s]（https：/ /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/）[t]（https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html）[o]（https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- Claims-on-behalf-of-5-million-iphone-users）[u]（https://time.com/23782/google-flu-trends-big-data-problems/）[s]（https：/ /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /）[r]（https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you。 html）[p]（https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/）[r]（https：// arstechnica .com / information-technolo gy / 2014/01 / what-google-can-really-do-with-nest-or-really-nests-data /）[i]（https://www.cbsnews.com/news/google-education-spies -on-collects-data-on-millions-of-kids-alleges-lawsuit-new-mexico-attorney-general /）[v]（https://www.nationalreview.com/2018/04/the-student- data-mining-scandal-under-our-noses /）[a]（https://www.wired.com/insights/2012/10/google-opt-out/）[c]（https：//www。 nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html）[y]（https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -something-to-hide-40689565c550）[。]（https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c）（私はこれの証拠を続けていくことができます、しかし、これらすべての記事を見つけて通過するのに長い時間がかかりました）

プライバシーはWideVineの問題ではありません。プロプライエタリソフトウェアは、何が起こっているのかをまったく見ることができないように設計されています。グーグルの歴史で、それは可能性が高いですWideVineは、あなたをスパイしたり、ドキュメントを読んだり、その他の悪いことをしたりする追加のソフトウェアです。

隠すものがないと思うなら、**あなたは絶対に間違っています**。この議論は何度も暴かれてきました：

[ウィキペディア経由]（https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism）

1.エドワード・スノーデンは、「隠すものがないのでプライバシーの権利を気にしないと主張することは、言うことがないので言論の自由を気にしないと言うことと同じです。私には隠すものは何もない」とあなたは言っている、「私はこの権利を気にしない」とあなたは言っている、「私は正当化する必要があるところまで来ているので、私はこの権利を持っていない。 「権利が機能する方法は、政府があなたの権利への侵入を正当化する必要があるということです。」

2. Daniel J. Soloveは、The Chronicle of Higher Educationの記事で、この議論に反対していると述べました。彼は、政府は人に関する情報を漏らしてその人に損害を与える可能性がある、または人が実際に不正行為を行っていなくてもサービスへのアクセスを拒否するために人に関する情報を使用する可能性があり、政府は個人に損害を与える可能性があると述べた間違いを犯すことによる人生。 Soloveは次のように書いています。「直接関与する場合、プライバシーの狭い理解に焦点を当てる議論を余儀なくされるため、隠すことのない議論が巻き込まれる可能性があります。しかし、政府のデータ収集と監視を超えた使用に関係する複数のプライバシー問題に直面した場合、開示、隠すべきことのない議論は、結局、何も言うことはありません。」

3. Privacy Rights：Moral and LegalFoundationsの著者であるAdamD。Mooreは、「権利は費用便益または結果主義的な種類の議論に抵抗するという見解です。ここでは、プライバシーの利益が一種であるという見解を拒否しています。セキュリティと交換できるものの」彼はまた、監視は外見、民族性、性別、宗教に基づいて社会の特定のグループに不釣り合いに影響を与える可能性があると述べた。

4.コンピューターセキュリティの専門家で暗号学者のブルース・シュナイアーは、リシュリュー枢機卿の「最も正直な人の手によって書かれた6行を私に渡せば、彼を絞首刑にする何かを見つけるだろう」と述べ、反対を表明した。州政府がその個人を起訴またはブラックメールするためにその個人の生活の側面をどのように見つけることができるかについて。シュナイアーはまた、「あまりにも多くの人が、議論を「セキュリティ対プライバシー」として誤って特徴付けている」と主張した。本当の選択は自由対支配です。」

5.ハーベイ・A・シルバーグラートは、一般人が平均して、米国で1日に3人のフェロニーを無意識のうちに犯していると推定しました。

6.哲学者で精神分析医のエミリオ・モルディーニは、「隠すものは何もない」という議論は本質的に逆説的であると主張した。人々は「何か」を隠すために「隠すもの」を持っている必要はありません。隠されているものは必ずしも関連性があるとは限らない、とMordiniは主張します。代わりに、心理的に言えば、私たちは他人に何かを隠すことができるという発見を通じて個人になるので、隠され、アクセスが制限される可能性のある親密な領域が必要であると彼は主張します。

7.ジュリアン・アサンジは、「まだキラーな答えはありません。ジェイコブ・アッペルバウム（@ioerror）は巧妙な反応を示し、これを言う人々に、電話のロックを解除してズボンを下ろすように頼みます。私のバージョンでは、 「まあ、あなたがとても退屈なら、私たちはあなたと話すべきではありませんし、他の誰も話すべきではありません」が、哲学的には、本当の答えはこれです：大量監視は大規模な構造変化です。社会が悪くなると、それは起こりますたとえあなたが地球上で最も素朴な人であったとしても、それを持ってあなたを連れて行くために。」

8.法学教授のIgnacioCofoneは、人々が関連情報を他人に開示するときはいつでも、無関係な情報も開示するため、議論はそれ自体の用語で誤っていると主張します。この無関係な情報にはプライバシーコストがかかり、差別などの他の危害につながる可能性があります。

***

＃代替方法

メディアは、オンラインでもオフラインでも制限されるべきではありません。人々がDRMなしでビデオを見たいと思った場合、彼らは常にそれを行う方法を見つけるでしょう。ソフトウェアのすべての部分がクラックされる可能性があります。

[ウィキペディアからの抜粋を修正] Valveの社長であるGabeNewellは、消費者の目にはゲームの価値を下げるだけなので、「ほとんどのDRM戦略はばかげている」と述べています。 Newellは、代わりに「サービスの価値を通じて顧客にとってより大きな価値を生み出す」ことを目標にすべきだと提案しています。 Valveは、PCゲームのオンラインストアとして機能するサービスであるSteam、およびソーシャルネットワーキングサービスとDRMプラットフォームを運営していることに注意してください。

この点はビデオゲームだけに当てはまるわけではなく、コンピュータ上のあらゆるものに適用できます。あなたのコンピュータは、悪い人工知能を使ってユーザーと彼らの仕事（YouTubeなど）を削除し、そのような悪い記録を持っている狂った会社を完全に制御するべきではありません。会社が行儀の悪い子供のように共有することを拒否するので、あなたのコンピュータは制限されるべきではありません。あなたのコンピュータはあなたが所有しているべきです、そして他の誰も。コンテンツはコンピュータの制御を放棄する価値がないため、DRMを完全に取り除く必要があります。これらの企業は数千億ドルを持っています。彼らがこのような愚かなことをするなら、あなたはそれに抗議するべきです。彼らはこのような愚かなことをするためにお金を失っているはずなので、あなたは他の場所でビデオをダウンロードしてそれを見ることができます。著作権侵害は悪いことではありません。映画を買う余裕がない人は他の場所でそれらをダウンロードするでしょう、それは世界的なインターネットの始まり以来そしてVHSテープの発明で起こっています。彼らはとにかくそのお金を得ることができないので、それは彼らの収入にほとんど影響を与えません。 DRMは設計上欠陥があります。

***

##あなたが助けるためにできること

あなたはDRMに抗議することができます。それは取るに足らないように思えるかもしれませんが、それに反対する人が多ければ多いほど、それについてより多くのことが行われています。

Linuxを使用していてFirefoxを使用している場合は、DRMがインストールされていないことを確認し（通常はデフォルトではインストールされていません）、わざわざインストールしないでください。

WindowsまたはMacOSを使用している場合、DRMはこれらのシステムにデフォルトでインストールされ、自動再インストールされる可能性があるため、はるかに困難な時間がかかる可能性があります。

次のサイトは避けてください。

[Hulu]（https://hulu.com）

[ディズニー+]（https://www.disneyplus.com/）

[Paramount +]（https://www.paramountplus.com/）

基本的に、ほとんどすべてのオンラインビデオストリーミングサービスは避ける必要があります。それらの大部分はDRMを使用しており、自由を失うことなくサイトを使用することはできないからです。それは価値がありません。 [MPAA]（https://en.wikipedia.org/wiki/Motion_Picture_Association）にメッセージを送信し、これらの番組のストリーミングを停止します。

また、次のサイトでは「広告付き無料」オプションを避ける必要があります（この方法ではDRMが必要です）

[YouTube]（https://www.youtube.com）

プロジェクトの `README.md`ファイルにメッセージを表示してDRMに抗議することもできます。これが私が使用するものです：

`` `マークダウン

***

##ソフトウェアステータス

私の作品はすべて無料ですが、いくつかの制限があります。 DRM（** D ** igital ** R ** estrictions ** M ** anagement）は私の作品のいずれにも存在しません。

！[DRM-free_label.en.svg]（DRM-free_label.en.svg）

このステッカーは、フリーソフトウェアファウンデーションによってサポートされています。私は自分の作品にDRMを含めるつもりはありません。

よく知られている「デジタル著作権管理」の代わりに「デジタル制限管理」という略語を使用しています。これは、DRMには権利がないという一般的な対処方法です。 「デジタル制限管理」のスペルはより正確であり、[Richard M. Stallman（RMS）]（https://en.wikipedia.org/wiki/Richard_Stallman）および[Free Software Foundation（FSF）]（ https://en.wikipedia.org/wiki/Free_Software_Foundation）

このセクションは、DRMの問題に対する認識を高め、それに抗議するために使用されます。 DRMは設計上欠陥があり、すべてのコンピューターユーザーとソフトウェアの自由に対する大きな脅威です。

画像クレジット：[defectivebydesign.org/drm-free /...]（https://www.defectivebydesign.org/drm-free/how-to-use-label）

***

`` `

***
##その他のチェックアウト

[設計による欠陥-DRM使用の公開と排除に取り組んでいるフリーソフトウェアファウンデーションによるキャンペーン]（https://www.defectivebydesign.org/）

[Google Graveyard（killedbygoogle.com）-Googleが殺した224以上の製品のソートされたリスト]（https://killedbygoogle.com/）

> [GitHubリンク]（https://github.com/codyogden/killedbygoogle）

[アルファベット労働者組合-800人以上のメンバーを擁するGoogleの新しい労働者組合]（https://alphabetworkersunion.org/people/our-union/）

他にも選択肢があります。それらを検索してください。

***

＃＃ 記事情報

ファイルタイプ： `Markdown（* .md）`

ファイルバージョン： `4（2021年4月23日金曜日午後3時35分）`

行数（空白行とコンパイラ行を含む）： `354`

###ソフトウェアステータス

私の作品はすべて制限がありません。 DRM（** D ** igital ** R ** estrictions ** M ** anagement）は私の作品のいずれにも存在しません。このプロジェクトにはDRMは含まれていませんが、DRMについて直接話し合っています。

！[DRM-free_label.en.svg]（DRM-free_label.en.svg）

このステッカーは、フリーソフトウェアファウンデーションによってサポートされています。私は自分の作品にDRMを含めるつもりはありません。

***

###スポンサー情報

！[SponsorButton.png]（SponsorButton.png）<-これは公式のスポンサーボタンではなく、デモ画像です。このプロジェクトを後援したい場合はクリックしないでください。

必要に応じてこのプロジェクトを後援することができますが、寄付したいものを指定してください。 [ここに寄付できる資金を参照してください]（https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors）

他のスポンサー情報を表示できます[ここ]（https://github.com/seanpm2001/Sponsor-info/）

やってみて！スポンサーボタンは、ウォッチ/アンウォッチボタンのすぐ隣にあります。

***

##ファイル履歴

バージョン1（2021年2月8日日曜日午後4時41分）

>変更：

> *ファイル/記事を開始しました

> *タイトルセクションを追加しました

> *プライバシーに関するセクションを追加しました

> *概要に関するセクションを追加しました

> *記事情報セクションを追加しました

> * DRMフリーアイコンを参照

> *ファイル履歴セクションを追加しました

> *自由の欠如のセクションを追加しました

> *反競争セクションを追加しました

> *代替方法のセクションを追加しました

> *メモを追加しましたry使用セクション

> *チェックアウトセクションに他のものを追加しました

> *インデックスを追加しました

> *フッターを追加しました

> *バージョン1で他の変更はありません

バージョン2（2021年4月8日木曜日午後5時18分）

>変更：

> *タイトルセクションを更新しました

> *インデックスを更新しました

> *あなたが助けるために何ができるかについての情報を追加しました

> *スポンサー情報セクションを追加しました

> *ファイル情報セクションを更新しました

> *ファイル履歴セクションを更新しました

> *バージョン2で他の変更はありません

バージョン3（2021年4月8日木曜日午後5時27分）

>変更：

> *翻訳リンクを修正しました

> *インデックスを更新しました

> *「ヘルプにできること」セクションの重複したトピック外のエントリを修正しました

> *スポンサー情報セクションを更新しました

> *ファイル情報セクションを更新しました

> *ファイル履歴セクションを更新しました

> *バージョン3で他の変更はありません

バージョン4（2021年4月23日金曜日午後3時35分）

>変更：

> *言語スイッチャーリストを更新しました

> *ファイル情報セクションを更新しました

> *ファイル履歴セクションを更新しました

> *バージョン4で他の変更はありません

バージョン5（近日公開）

>変更：

> *近日公開

> *バージョン5で他の変更はありません

バージョン6（近日公開）

>変更：

> *近日公開

> *バージョン6で他の変更はありません

バージョン7（近日公開）

>変更：

> *近日公開

> *バージョン7で他の変更はありません

バージョン8（近日公開）

>変更：

> *近日公開

> *バージョン8で他の変更はありません

***

##フッター

このファイルの終わりに到達しました！

##### EOF

***
