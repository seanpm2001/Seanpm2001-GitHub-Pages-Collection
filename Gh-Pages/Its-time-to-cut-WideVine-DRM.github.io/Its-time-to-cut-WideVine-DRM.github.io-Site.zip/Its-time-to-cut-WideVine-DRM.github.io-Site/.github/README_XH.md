***

##### Phezulu

_Funda eli nqaku ngolwimi olwahlukileyo: _

Ulwimi lwangoku ngu:

Uluhlu lweelwimi_

** Kuhlelwe ngo: ** `AZ`

[Ukhetho lokuhlela alufumaneki] (https://github.com/Degoogle-your-Life)

([Afrika Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shareptare] (/. github / README_SQ.md) Albanian | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/.github/README_AR.md) IsiArabhu | [hy հայերեն] (/. github / README_HY.md) iArmenia | [az Azrbaycan dili] (/. github / README_AZ.md) isiAzerbaijani | [eu Euskara] (/. /README_EU.md) Basque | [be Беларуская] (/. Github / README_BE.md) Belarusian | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) IBosnia | ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) IsiTshayina (Esenziwe lula) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) IsiTshayina (Esiqhelekileyo) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) isiCroatia | [cs čeština] (/. Github / README_CS .md) Czech | [da dansk] (README_DA.md) Danish | [nl Nederlands] (/. github / README_ NL.md) IsiDatshi | [** en-us English **] (/. github / README.md) IsiNgesi | [EO Esperanto] (/. Github / README_EO.md) Isi-Esperanto | [et Eestlane] (/. github / README_ET.md) Isi-Estonia | [tl isiPhilippines] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) IsiFinnish | [fr français] (/. github / README_FR.md) IsiFrentshi | [Fy Frysk] (/. github / FUNDAE_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) IsiGalician | [ka ქართველი] (/. github / README_KA) IsiGeorgia | [de Deutsch] (/. github / README_DE.md) isiJamani | [el Ελληνικά] (/. github / README_EL.md) isiGrike | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) IsiCreole saseHaiti | [ha Hausa] (/. github / FUNDAE_HA.md) isiHausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) IsiHebhere | [molo हिन्दी] (/. github / README_HI.md) IsiHindi | [hmn Hmong] (/. github / README_HMN.md) IHmong | [hu Magyar] (/. github / README_HU.md) IsiHungary | [yi Íslenska] (/. github / README_IS.md) Isi-Icelandic | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Isi-Icelandic | [ga Gaeilge] (/. github / README_GA.md) isi-Irish | [Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) IsiJapan | [jw Wong jawa] (/. github / README_JW.md) iJavanese | [kn ಕನ್ನಡ] (/. github / FUNDAE_KN.md) IsiKannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / FUNDAE_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) isiKinyarwanda | [ko-mzantsi 韓國 語] (/. github / README_KO_SOUTH.md) IsiKorea (eMzantsi) | [ko-north 문화어] (README_KO_NORTH.md) isiKorea (eMantla) (ASIKUGUQULWA) | [ku Kurdî] (/. github / README_KU.md) isiKurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) isiKyrgyz | [jonga ລາວ] (/. github / README_LO.md) iLao | [la Latine] (/. github / README_LA.md) IsiLatin | [lt Lietuvis] (/. github / README_LT.md) IsiLithuania | [lb Lëtzebuergesch] (/. github / README_LB.md) Isingesi | [mk Македонски] (/. github / README_MK.md) IsiMacedonia | [mg Malagasy] (/. github / README_MG.md) IsiMalagasy | [ms Bahasa Melayu] (/. github / README_MS.md) IsiMalay | [ml മലയാളം] (/. github / README_ML.md) IsiMalayalam | [mt Malti] (/. github / README_MT.md) IsiMalta | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) IsiMarathi | [mn Монгол] (/. github / README_MN.md) IsiMongolia | [yam မြန်မာ] (/. github / README_MY.md) iMyanmar (Burmese) | [ne नेपाली] (/. github / README_NE.md) Nepali | [akukho norsk] (/. github / README_NO.md) IsiNorway | [okanye ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (isiOriya) | [ps پښتو] (/. github / README_PS.md) IsiPashto | [fa فارسی] (/. github / README_FA.md) | isiPersi [pl polski] (/. github / README_PL.md) IsiPolish | [pt português] (/. github / README_PT.md) IsiPhuthukezi | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) isiPunjabi | Akukho lwimi lufumanekayo oluqala ngonobumba Q | [ro Română] (/. github / README_RO.md) isiRomania | [ru русский] (/. github / README_RU.md) IsiRashiya | [sm Faasamoa] (/. github / README_SM.md) isiSamoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) iScots Gaelic | [sr Српски] (/. github / README_SR.md) IsiSerbia | [st Sesotho] (/. github / README_ST.md) IsiSuthu | [sn Shona] (/. github / README_SN.md) isiShona | [sd سنڌي] (/. github / README_SD.md) iSindhi | [si සිංහල] (/. github / README_SI.md) ISinhala | [sk Slovák] (/. github / README_SK.md) IsiSlovak | [sl Slovenščina] (/. github / README_SL.md) IsiSlovenia | [soomaali] (/. github / README_SO.md) Somali | [[es español] (/. github / README_ES.md) IsiSpanish | [su Sundanis] (/. github / README_SU.md) iSundanese | [sw Kiswahili] (/. github / README_SW.md) isiSwahili | [sv Svenska] (/. github / README_SV.md) IsiSwedish | [tg Тоҷикӣ] (/. github / README_TG.md) iTajik | [ta தமிழ்] (/. github / README_TA.md) IsiTamil | [tt Татар] (/. github / README_TT.md) isiTatar | [te తెలుగు] (/. github / README_TE.md) IsiTelugu | [th ไทย] (/. github / README_TH.md) isiThai | [tr Türk] (/. github /README_TR.md) IsiTurkish | [tk Türkmenler] (/. github / README_TK.md) iTurkmen | [uk Український] (/. github / README_UK.md) IsiUkraine | [ur اردو] (/. github / README_UR.md) IsiUrdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) IsiVietnam | [cy Cymraeg] (/. github / README_CY.md) IsiWales | [xh isiXhosa] (/. github / README_XH.md) isiXhosa | [yi יידיש] (/. github / README_YI.md) IsiYiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Iyafumaneka ngeelwimi ezili-110 (108 xa kungabalwa isiNgesi noMntla Korea, nanjengoko iNorth Korea ingekaguqulelwa okwangoku [Funda malunga nayo apha] (/ OldVersions / Korean (North) /README.md))

Ukuguqulelwa kwezinye iilwimi ngaphandle kwesiNgesi kuguqulwe ngomatshini kwaye akukachaneki okwangoku. Akukho mpazamo zilungisiweyo okwangoku ukusukela nge-5 kaFebruwari 2021. Nceda uxele iimpazamo zokuguqulela [apha] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) qiniseka ukuba ugcina ulungiso imithombo kwaye undikhokele, njengoko ndingazazi ezinye iilwimi ngaphandle kwesiNgesi kakuhle (ndiceba ukufumana umguquli ekugqibeleni) nceda khankanya [wiktionary] (https://en.wiktionary.org) kunye neminye imithombo kwingxelo yakho. Ukusilela ukwenza njalo kuya kubangela ukwaliwa kolungiso kupapashwe.

Qaphela: ngenxa yokusikelwa umda kutoliko lwe-GitHub yokumakisha (kwaye intle kakhulu kuyo yonke into esekwe kutoliko olusekwe kwiwebhu lokumakisha) ukucofa la makhonkco kuyakuthumela kwifayile eyahlukileyo kwiphepha elahlukileyo elingelilo iphepha leprofayile yeGitHub. Uya kuthunyelwa kwenye indawo [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), apho iREADME isingathwa khona.

Iinguqulelo zenziwa noToliko lukaGoogle ngenxa yokuncitshiswa okanye ukungabikho kwenkxaso kwiilwimi endizifunayo kwezinye iinkonzo zokuguqulela ezinje nge-DeepL kunye ne-Bing Translator (into ehlekisayo yephulo elichasene noGoogle) ndiyasebenza ukufumana enye indlela. Ngesizathu esithile, ukufomatha (amakhonkco, ukwahlulahlula, ukuqaqambisa, italics, njl.) Kuphazamisekile kwiinguqulelo ezahlukeneyo. Kuyadinisa ukulungisa, kwaye andazi ukuba ndiyilungisa njani le micimbi kwiilwimi ezinabalinganiswa abanga-latin, kwaye nasekunene kwiilwimi zasekhohlo (njengeArabhu) uncedo olongezelelekileyo luyafuneka ukulungisa le micimbi.

Ngenxa yemicimbi yolondolozo, iinguqulelo ezininzi ziphelelwe lixesha kwaye zisebenzisa uhlobo lwakudala lwale fayile yenqaku elithi `README`. Kufuneka umguquleli. Kwakhona, ukusukela nge-23 ka-Epreli 2021, kuzakundithatha ixesha ukufumana lonke ikhonkco elitsha lisebenza.

***

# Lixesha lokusika uMdiliya omde

Eli linqaku lokuba kutheni uyeke ukusebenzisa iGoogle WideVine (DRM) kwaye uyikhuphe. I-DRM kufuneka isuswe. Eli nqaku liza kukunceda wenze ukhetho lwakho (ukuba awukabikho) iWideVine iyakhuphisana kakhulu, kwaye ibekelwe imiqathango kakhulu, kwaye itshabalalisa inkululeko yeevidiyo ezikwi-Intanethi.

Masisike uMdiliya omkhulu kwaye samkele i-Intanethi evulekileyo.

***

# Isalathiso

[00.0 - Phezulu] (# Phezulu)

> [00.1 - Funda eli nqaku ngolunye ulwimi]

> [00.2-Isihloko] (# Lixesha-lokusika-iVidevine)

> [00.3 - Index] (# Isalathiso)

[01.0 - Amagqabantshintshi] (# Amagqabantshintshi)

[02.0 - Ukuchasana nokhuphiswano] (# Ukhuphiswano)

[03.0-Ukungabikho kwenkululeko] (# Ukungabikho-kwenkululeko)

[04.0-Ukusetyenziswa kwememori] (# Ukusetyenziswa kweMemori)

[05.0 - Ubungasese] (# Imfihlo)

[06.0 - Iindlela ezizezinye] (# Enye indlela)

[07.0-Yintoni ongayenza ukunceda] (# Yintoni-ongayenza ukuze uncede)

[08.0-Ezinye izinto oza kuzijonga] (# Ezinye izinto-zokukhangela)

[09.0-Inqaku lolwazi] (# Inqaku-ulwazi)

> [09.0.1-Isimo sesoftware] (# Ubume beSoftware)

> [09.0.2 - Ulwazi lomxhasi] (# Inkxaso-mali)

[10.0 - Imbali yeFayile] (# Ifayile-imbali)

[11.0-Umbhalo osezantsi ephepheni] (# Umbhalo osemazantsi)

> [11.9 - EOF] (# EOF)

***

## Amagqabantshintshi

Ngolunye ulwazi malunga nokuba kutheni i-DRM yingxaki, [cofa apha] (https://www.defectivebydesign.org/)

***

## Ukhuphiswano

I-WideVine yi-DRM ekufuneka ilayisensi ukuba isetyenziswe kwisikhangeli. UGoogle ucotha kakhulu ekuphononongeni nasekwamkeleni abantu, kwaye uhlala enqaba abantu ukuba bayisebenzise kwiimveliso zabo ngaphandle kwesizathu. [Umthombo 1] (Umthombo 2) (Umthombo 2 (umsonto we-imeyile oqhubeke ngaphezulu kweenyanga ezi-4 kwaye awukhange ubangele ukuphoxeka) UGoogle wenze kwanzima kakhulu kwizikhangeli ezinjengeBrave okanye iFirefox ukukhuphisana nokutyhala kwesi siqwenga se-DRM.

***

## Ukungabikho kwenkululeko

I-WideVine isetyenziselwa ukukhusela abasebenzisi ekunxibelelaneni nevidiyo kwiiwebhusayithi. Yindlela yolawulo lwezithintelo kwidijithali ekuthintela ukuba ukhuphele ividiyo, ubukele ividiyo ngaphandle kweintanethi, okanye uthathe umfanekiso weskrini. Yisoftware ephetheyo kwaye ngenxa yemicimbi yayo yabucala, ayifakwanga ngokungagqibekanga kuninzi losasazo lweLinux. Ithintela inkululeko yewebhu ngenxa yokusebenzisa kwayo iNetflix, iDisney, kunye neemovie zeYouTube. Ukufikelela kwakho kumxholo kungasuswa nangaliphi na ixesha ngaphandle kwesizathu.

***

Ukusetyenziswa kwememori

WideVine imbi kwimemori. Xa kuthelekiswa nokujonga nje ividiyo ngaphandle kwe-DRM, iWideVine iya kusebenzisa ii-CPU kunye ne-RAM. Kubi kwi baUbomi bettery, kwaye ayiniki zibonelelo zisuka kumgangatho wokudlala wevidiyo we-HTML5.

***

## Ubumfihlo

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / yonke idatha-ye-facebook-google-in-kuwe-ngasese) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit))ss (http://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spy-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ] [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he idatha ye-alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-yabucala-ingxaki /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Ukugxeka) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -iisampulu / akukho nto-yokufihla-impikiswano-ayina-nto-yokuthetha /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- idatha-malunga nawe-ungayifumana-kwaye uyicime-ngoku /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your idatha-yobuqu-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -and) [c] (https://www.wired.com/story/google-tracks-you -ubucala /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/I-Googles-vision-TOTAL-data-collection-revealed.html)letondhttps: //www.reuters.com/article/us-alphabet- google-ubumfihlo-ityala-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)letono-https://en.wikipedia.org/wiki/2018_Google_data_breach)[m)(https://:// moz.com/bl og / apho-ukwenza-google-ukuzoba-idatha-yokuqokelela-umgca) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / iteknoloji / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- amabango-egameni-le-5-yezigidi-ze-iphone-abasebenzisi) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) [e) (https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your- -ifowuni-ayisebenziswanga /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassaction.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica) .com / ulwazi-iteknoloji gy / 2014/01 / yintoni-google-enokwenza-inyani-okanye-izidleke-zedatha /) [i] (https://www.cbsnews.com/news/google-education-spies -kuqokelelwa-idatha-kwizigidi-zabantwana-izityholo-ityala-elitsha-eMexico-igqwetha-jikelele /) [v] (https://www.nationalreview.com/2018/04/the-student- idatha-yezimbiwa-iscandal-phantsi-kweempumlo zethu /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)inglyy )(https://medium.com/@hansdezwart/during-world-war-ii-did-have- -into-yokufihla-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Ndingaqhubeka ndiqhubeke nobungqina boku , kodwa kwathatha ixesha elide ukufumana nokuwafumana onke la manqaku)

Ubumfihlo akuyona into ngeWideVine. Isoftware yobunini yenzelwe ukuba ungaboni okwenzekayo nakanye. Ngembali yeGoogles, kunokwenzeka kakhulu ukubaI-WideVine sisiqwengana sesoftware esihlola wena, sifunda amaxwebhu akho, kunye nezinye izinto ezimbi.

Ukuba ucinga ukuba akukho nto uyifihlayo, ** uphazamile ngokupheleleyo **. Le ngxoxo ichithwe amaxesha amaninzi ngaphezulu:

[Nge-Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. U-Edward Snowden wathi "Ukuxambulisana ukuba awukhathalelanga ilungelo labucala kuba awunanto uyifihlayo akufani nokuthi uthi awuyikhathalelanga intetho yasimahla kuba awunanto yakuthetha." Xa usithi, ' Andinanto ndiyifihlayo, utsho, 'andikhathali ngeli lungelo.' Uthi, 'andinalo eli lungelo, kuba ndiye kwinqanaba lokuba ndizithethelele Indlela esebenza ngayo amalungelo, urhulumente kufuneka azithethelele ngokungenelela kwakhe kumalungelo akho. "

2. UDaniel J. Solove uxele inqaku leThe Chronicle yeMfundo ePhakamileyo ukuba uyayichasa ingxoxo; Uye wathi urhulumente angakwazi ukuvuza ulwazi malunga nomntu kwaye enze umonakalo kuloo mntu, okanye asebenzise ulwazi malunga nomntu ukwala ukufikelela kwiinkonzo nokuba umntu khange abandakanyeke kwisenzo esingalunganga, kwaye urhulumente angadala umonakalo kubuntu bakhe. ubomi ngokwenza iimpazamo. I-Solove ibhale "Xa uzibandakanya ngokuthe ngqo, impikiswano engenanto yokufihla inokubambisa, kuba inyanzela ingxoxo-mpikiswano ukuba ijolise kulwazi oluncinci lobumfihlo. Kodwa xa ujongene nobuninzi beengxaki zabucala ezichaphazeleka kukuqokelelwa kwedatha kukarhulumente kunye nokusetyenziswa ngaphaya kokugadwa kwaye ukuziveza, impikiswano engenanto yokufihla, ekugqibeleni, ayinanto yakuthetha. "

3. UAdam D. Moore, umbhali wamaLungelo aBucala: iMilinganiselo yokuZiphatha kunye nezoMthetho, wathi, "luvo lokuba amalungelo ayamelana nexabiso / isibonelelo okanye uhlobo lwempikiswano. Apha siyayikhaba imbono yokuba umdla wabucala ziluhlobo yezinto ezinokuthengiswa zikhuseleke. Uye wathi ukubekwa kweliso kunokuchaphazela ngokungafaniyo amaqela athile kuluntu ngokusekwe kwinkangeleko, ubuhlanga, isini kunye nenkolo.

4. UBruce Schneier, ingcali yezokhuseleko kwikhompyuter kunye nomlobi we-cryptographer, uvakalise inkcaso, ecaphula ingxelo kaKhadinali Richelieu "Ukuba umntu angandinika imigca emithandathu ebhalwe ngesandla yeyona ndoda inyanisekileyo, ndingafumana into kubo yokuxhonywa", ebhekisa indlela urhulumente woburhulumente anokufumana ngayo iinkalo kubomi bomntu ukuze atshutshise okanye ahlasele loo mntu. U-Schneier uphinde wathi "Zininzi kakhulu izinto ezingalunganga ezichaza ingxoxo njenge 'ukhuseleko xa kuthelekiswa nemfihlo.' Olona khetho lufanelekileyo yinkululeko nxamnye nolawulo. "

5. UHarvey A. Silverglate uqikelele ukuba umntu oqhelekileyo, ngokomndilili, ngokungazi wenza amatyala amathathu ngosuku e-US.

6. U-Emilio Mordini, ifilosofi kunye nochwephesha kwengqondo, wathi "akukho nto ifihliweyo" iyimpikiswano yendalo. Abantu akufuneki babenayo "into yokufihla" ukuze bakwazi ukufihla "into". Into efihliweyo ayisiyomfuneko, ubanga uMordini. Endaweni yoko, uphikisa indawo esondeleyo enokuthi ifihlwe kwaye ukufikelela kuthintelo kuyimfuneko kuba, xa sithetha ngokwasemphefumlweni, siba ngabantu ngokufumanisa ukuba sinokufihla okuthile kwabanye.

7. UJulian Assange wathi "Akukabikho mpendulo ibulalayo. UJacob Appelbaum (@ioerror) uphendule ngobukrelekrele, ebuza abantu abatsho oku ukuba bamnike ifowuni yabo ivulwe kwaye behlise ibhulukhwe yabo. Inguqulelo yam ithi, Kulungile, ukuba uyadika ngoko ke akufuneki ukuba sithethe nawe, kwaye akufuneki nokuba kungomnye umntu ', kodwa ngokwentanda-bulumko, eyona mpendulo yile: Ukujongwa kweMisa lutshintsho olukhulu kulwakhiwo. ukuthatha nawe, nokuba ungoyena mntu ucekisekayo emhlabeni.

8. UIgnacio Cofone, unjingalwazi wezomthetho, uthi impikiswano iphosakele ngokwemigaqo yayo kuba, nanini na xa abantu beveza ulwazi olufanelekileyo kwabanye, bakwadiza ulwazi olungabalulekanga. Olu lwazi lungabalulekanga luneendleko zabucala kwaye lunokukhokelela kolunye ukonzakala, njengokucalulwa.

***

# Iindlela ezizezinye

Imithombo yeendaba akufuneki ithintelwe, kwi-Intanethi okanye ngaphandle kweintanethi. Ukuba abantu bafuna ukubukela ividiyo ngaphandle kwe-DRM, baya kuhlala befumana indlela yokwenza. Yonke into yesoftware inokuqhekeka.

[iguqulelwe kwisicatshulwa esivela kwiWikipedia] Umongameli weValve uGabe Newell uthe "uninzi lwezicwangciso ze-DRM zizidenge nje" kuba zinciphisa ixabiso lomdlalo emehlweni womthengi. UNewell ucebisa ukuba injongo kufuneka endaweni yoko "[idale] ixabiso elikhulu kubathengi ngexabiso lenkonzo". Qaphela ukuba iValve isebenza ngeSteam, inkonzo esebenza njengevenkile ye-Intanethi kwimidlalo yePC, kunye nenkonzo yokunxibelelana nabantu kunye neqonga le-DRM

Eli nqaku alisebenzi kwimidlalo yevidiyo, inokusetyenziswa kuyo nayiphi na into ekhompyuter. Ikhompyuter yakho akufuneki ibe kulawulo olupheleleyo lwenkampani ephambeneyo esebenzisa ubukrelekrele obuGwenxa bokucima abasebenzisi bayo kunye nomsebenzi wabo (iYouTube, njl.njl.) Kwaye inerekhodi elibi. Ikhompyuter yakho akufuneki ithintelwe kuba inkampani iyala ukwaba njengomntwana oziphethe kakubi. Ikhompyuter yakho yeyakho,kwaye akukho mntu wumbi. Kuya kufuneka ulahle i-DRM xa iyonke, njengoko umxholo ungakulungelanga ukuyeka ukulawula ikhompyuter yakho. Ezi nkampani zinamakhulu ezigidi zeedola. Ukuba benza into ebubudenge ngolu hlobo, kuya kufuneka uyiqhankqalaze. Unokude ukhuphele ividiyo kwenye indawo kwaye uyijonge, njengoko kufanele ukuba baphulukana nemali ngokwenza izinto ezibubudenge ezinje. Ukophula umthetho asiyonto imbi. Abantu abangakwaziyo ukufikelela kumabhanyabhanya baya kuzikhuphela kwenye indawo, oko bekusenzeka oko kwaqala i-Intanethi kunye nokuyilwa kwe VHS tape. Ayichaphazeli ingeniso yabo, kuba ngekhe bakwazi ukuyifumana loo mali. I-DRM inesiphene kuyilo.

***

## Yintoni onokuyenza ukunceda

Ungaqhankqalaza nge-DRM. Ingabonakala ingabalulekanga, kodwa abantu abachasene nayo, kokukhona isenziwa malunga nayo.

Ukuba ukuLinux kwaye usebenzisa iFirefox, qiniseka ukuba i-DRM ayifakwanga (ngesiqhelo ayizenzeki) kwaye ungazikhathazi ngokuyifaka.

Ukuba ukuWindows okanye iMacOS, unokuba nexesha elinzima kakhulu, njengoko i-DRM ifakwe ngokungagqibekanga kwezi nkqubo, kwaye unokufaka kwakhona ngokuzenzekelayo.

Zama ukunqanda ezi ndawo zilandelayo:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Ubukhulu +] (https://www.paramountplus.com/)

Ngokusisiseko, phantse nayiphi na inkonzo yokusasaza ividiyo kwi-Intanethi kufuneka ithintelwe, njengoko uninzi lwazo lusebenzisa i-DRM kwaye awukwazi ukusebenzisa indawo ngaphandle kokulahlekelwa yinkululeko. Akufanelekanga. Thumela i [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) umyalezo uyeke ukusasaza le nkqubo.

Kuya kufuneka uphephe nayiphi na into "yasimahla eneentengiso" kwezi ndawo zilandelayo (njengoko le ndlela ifuna i-DRM)

[YouTube] (https://www.youtube.com)

Ungaqhankqalaza i-DRM ngomyalezo kwiiprojekthi zakho `README.md` ifayile. Nantsi into endiyisebenzisayo:

`` Ukuphawula

***

# # Ubume beSoftware

Yonke imisebenzi yam isimahla kwezinye izithintelo. I-DRM (** D ** igital ** R ** izithintelo ** M ** ukulawulwa) ayikho kuyo nayiphi na imisebenzi yam.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Esi sincamatheliso sixhaswa yiFree Software Foundation. Andizimiselanga kufaka i-DRM kwimisebenzi yam.

Ndisebenzisa isifinyezo esithi "Ulawulo lweZithintelo zedijithali" endaweni yaziwa kakhulu "uLawulo lwamalungelo edijithali" njengendlela eqhelekileyo yokujongana nobuxoki, akukho malungelo nge DRM. Upelo "Ulawulo lwezithintelo zedijithali" luchanekile, kwaye luxhaswa ngu- [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) kunye ne- [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Eli candelo lisetyenziselwa ukuphakamisa ulwazi malunga neengxaki ze-DRM, kunye nokuqhankqalaza. I-DRM inesiphene kuyilo kwaye isisongelo esikhulu kubo bonke abasebenzisi bekhompyuter kunye nenkululeko yesoftware.

Ityala lemifanekiso: [defectivebydesign.org/drm-free/...] (https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

``

***
## Ezinye izinto oza kuzijonga

[Inesiphene kuyilo-Iphulo leFree Software Foundation esebenza ekubhenceni nasekupheliseni ukusetyenziswa kwe-DRM] (https://www.defectivebydesign.org/)

[Amangcwaba kaGoogle (killbygoogle.com) - uluhlu oluhleliweyo lweemveliso ezingama-224 + ezibulewe nguGoogle] (https://killedbygoogle.com/)

> [Ikhonkco leGitHub] (https://github.com/codyogden/killedbygoogle)

[Umanyano wabasebenzi beAlfabhethi - Umanyano wabasebenzi kuGoogle onamalungu angaphezu kwe-800] (https://alphabetworkersunion.org/people/our-union/)

Kukho ezinye iindlela, khangela nje.

***

## Inqaku lolwazi

Uhlobo lwefayile: `Uphawu (* .md)`

Inguqulelo yefayile: `` 4 (ngolwesiHlanu, Epreli 23rd 2021 nge-3: 35 pm) ''

Ukubalwa kwemigca (kubandakanya imigca engenanto kunye nomgca wokuhlanganisa): `354`

### Isimo seSoftware

Yonke imisebenzi yam ikhululekile kwizithintelo. I-DRM (** D ** igital ** R ** izithintelo ** M ** ukulawulwa) ayikho kuyo nayiphi na imisebenzi yam. Le projekthi ayiqulathanga nayiphi na i-DRM, kodwa ithetha nge-DRM ngqo.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Esi sincamatheliso sixhaswa yiFree Software Foundation. Andizimiselanga kufaka i-DRM kwimisebenzi yam.

***

### Ulwazi lomxhasi

! [SponsorButton.png] (SponsorButton.png) <- Eli ayisilo iqhosha lomxhasi elisemthethweni, ngumfanekiso wedemo. Sukucofa kuyo ukuba ufuna ukuxhasa le projekthi.

Ungayixhasa le projekthi ukuba uyathanda, kodwa nceda ucacise ukuba ufuna ukunikela ngantoni. [Jonga imali onokuthi unikele ngayo apha] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Ungalujonga olunye ulwazi lomxhasi [apha] (https://github.com/seanpm2001/Sponsor-info/)

Yizame! Iqhosha labaxhasi lilungile ecaleni kwewotshi / iqhosha lokungajongi.

***

# # Imbali yefayile

Inguqulelo 1 (ngeCawa, nge-8 kaFebruwari 2021 ngo-4: 41 pm)

> Utshintsho:

> * Uqale ifayile / inqaku

> * Yongeze icandelo lesihloko

> * Yongeze icandelo malunga nemfihlo

> * Yongeze icandelo malunga nokujonga ngokubanzi

> * Yongeze icandelo lolwazi lwenqaku

> * Ebhekisa kwi icon ye-DRM yasimahla

> * Yongeze icandelo lembali yefayile

> * Yongeze ukungabikho kwenkululeko

> * Yongeze icandelo loKhuphiswano

> * Yongeze ezinye iindlela zendlela

> * Yongeze imemory icandelo lokusetyenziswa

> * Yongeze ezinye izinto ukujonga icandelo

> * Yongeze isalathiso

> * Yongeza i-footer

> * Alukho olunye utshintsho kuhlobo 1

Inguqulelo yesi-2 (Lwesine, Epreli 8th 2021 nge-5: 18 pm)

> Utshintsho:

> * Uhlaziye icandelo lesihloko

> * Uhlaziyo lwesalathiso

> * Ulwazi olongeziweyo kwinto onokuyenza ukunceda

> * Yongeze icandelo lolwazi lomxhasi

> * Uhlaziye icandelo lolwazi lwefayile

> * Uhlaziye icandelo lembali yefayile

> * Alukho olunye utshintsho kuhlobo 2

Inguqulelo yesi-3 (Lwesine, Epreli 8th 2021 nge-5: 27 pm)

> Utshintsho:

> Amakhonkco otoliko ahleliweyo

> * Uhlaziyo lwesalathiso

> * Ukulungiswa kwempinda, ukungena kwesihloko 'kwinto onokuyenza ukunceda icandelo

> * Ukuhlaziywa kwecandelo lolwazi lomxhasi

> * Uhlaziye icandelo lolwazi lwefayile

> * Uhlaziye icandelo lembali yefayile

> * Alukho olunye utshintsho kuhlobo 3

Inguqulelo 4 (ngolwesiHlanu, Epreli 23rd 2021 nge-3: 35 pm)

> Utshintsho:

> * Uhlaziyo loluhlu lokutshintsha ulwimi

> * Uhlaziye icandelo lolwazi lwefayile

> * Uhlaziye icandelo lembali yefayile

> * Alukho olunye utshintsho kuhlobo 4

Inguqulelo yesi-5 (Iyeza kwakamsinya)

> Utshintsho:

> * Iyeza kungekudala

> * Alukho olunye utshintsho kuhlobo 5

Inguqulelo 6 (Iyeza kwakamsinya)

> Utshintsho:

> * Iyeza kungekudala

> * Alukho olunye utshintsho kuhlobo 6

Inguqulelo 7 (Iyeza kungekudala)

> Utshintsho:

> * Iyeza kungekudala

> * Alukho olunye utshintsho kuhlobo 7

Inguqulelo 8 (Iyeza kwakamsinya)

> Utshintsho:

> * Iyeza kungekudala

> * Alukho olunye utshintsho kuhlobo 8

***

## Imibhalo engezantsi

Ufikelele esiphelweni sale fayile!

##### EOF

***
