***

##### Phezulu

_Funda le ndatshana ngolunye ulimi: _

** Ulimi lwamanje luthi: ** `English (US)` _ (izinguqulo zingadinga ukulungiswa ukulungisa isiNgisi esikhundleni solimi olufanele) _

_🌐 Uhlu lwezilimi_

** Kuhlungwe nge: ** `A-Z`

[Izinketho zokuhlunga azitholakali] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanian | [am አማርኛ] (/. github / README_AM.md) Amharic | [ar عربى] (/. /README_EU.md) Basque | [be Беларуская] (/. Github / README_BE.md) Belarusian | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. I-Bosnia | ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) IsiShayina (Esenziwe Lula) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) IsiShayina (Esijwayelekile) | [co Corsu] (/. Github / README_CO.md) IsiCorsican | [hr Hrvatski] (/. Github / README_HR.md) isiCroatia | [cs čeština] (/. Github / README_CS .md) IsiCzech | [da dansk] (README_DA.md) IsiDanish | [nl Nederlands] (/. github / README_ NL.md) isiDashi | [** en-us English **] (/. github / README.md) isiZulu | [EO Esperanto] (/. Github / README_EO.md) Isi-Esperanto | [et Eestlane] (/. github / README_ET.md) Isi-Estonia | [tl Pilipino] (/. github / README_TL.md) isiFilipino | [fi Suomalainen] (/. github / README_FI.md) IsiFinnish | [fr français] (/. github / README_FR.md) IsiFulentshi | [fy Frysk] (/. github / README_FY.md) IsiFrisia | [gl Galego] (/. github / README_GL.md) IsiGalician | [ka ქართველი] (/. github / README_KA) IsiGeorgia | [de Deutsch] (/. github / README_DE.md) IsiJalimane | [el Ελληνικά] (/. github / README_EL.md) isiGreki | [gu ગુજરાતી] (/. github / README_GU.md) IsiGujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) IsiCreole SaseHaiti | [ha Hausa] (/. github / README_HA.md) IsiHausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) isiHeberu | [hi हिन्दी] (/. github / README_HI.md) isiHindi | [hmn Hmong] (/. github / README_HMN.md) iHmong | [hu Magyar] (/. github / README_HU.md) isiHungary | [is Íslenska] (/. github / README_IS.md) Isi-Icelandic | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Isi-Icelandic | [ga Gaeilge] (/. github / README_GA.md) isi-Irish | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) IsiJapane | [jw Wong jawa] (/. github / README_JW.md) isiJavanese | [kn ಕನ್ನಡ] (/. github / README_KN.md) IsiKannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw isiKinyarwanda] (/. github / README_RW.md) isiKinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) IsiKorea (eNingizimu) | [ko-north 문화어] (README_KO_NORTH.md) Isi-Korean (North) (AKAHHUNYULWA) | [ku Kurdî] (/. github / README_KU.md) isiKurdish (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) isiKyrgyz | [bheka ລາວ] (/. github / README_LO.md) iLao | [la Latine] (/. github / README_LA.md) isiLatin | [lt Lietuvis] (/. github / README_LT.md) Isi-Lithuanian | [lb Lëtzebuergesch] (/. github / README_LB.md) Isi-Luxembourgish | [mk Македонски] (/. github / README_MK.md) IsiMacedonia | [mg Malagasy] (/. github / README_MG.md) IsiMalagasy | [ms Bahasa Melayu] (/. github / README_MS.md) IsiMalay | [ml മലയാളം] (/. github / README_ML.md) IsiMalayalam | [mt Malti] (/. github / README_MT.md) Isi-Maltese | [mi Maori] (/. github / README_MI.md) AmaMaori | [mr मराठी] (/. github / README_MR.md) IsiMarathi | [mn Монгол] (/. github / README_MN.md) IsiMongolia | [my မြန်မာ] (/. github / README_MY.md) iMyanmar (isiBurma) | [ne नेपाली] (/. github / README_NE.md) isiNepali | [ayikho i-norsk] (/. github / README_NO.md) isiNorway | [noma ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) IsiPashto | [fa فارسی] (/. github / README_FA.md) | Persian [pl polski] (/. github / README_PL.md) IsiPolish | [pt português] (/. github / README_PT.md) IsiPutukezi | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) isiPunjabi | Azikho izilimi ezitholakalayo eziqala ngohlamvu Q | [ro Română] (/. github / README_RO.md) isiRomania | [ru русский] (/. github / README_RU.md) isiRashiya | [sm Faasamoa] (/. github / README_SM.md) isiSamoa | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) AmaScot Gaelic | [sr Српски] (/. github / README_SR.md) IsiSerbia | [st Sesotho] (/. github / README_ST.md) isiSuthu | [sn Shona] (/. github / README_SN.md) isiShona | [sd سنڌي] (/. github / README_SD.md) isiSindhi | [si සිංහල] (/. github / README_SI.md) ISinhala | [sk Slovák] (/. github / README_SK.md) IsiSlovak | [sl Slovenščina] (/. github / README_SL.md) isiSlovenia | [so Soaliali] (/. github / README_SO.md) iSomalia | [[es es español] (/. github / README_ES.md) IsiSpanish | [su Sundanis] (/. github / README_SU.md) iSundanese | [sw Kiswahili] (/. github / README_SW.md) isiSwahili | [sv Svenska] (/. github / README_SV.md) IsiSwidi | [tg Тоҷикӣ] (/. github / README_TG.md) IsiTajik | [ta தமிழ்] (/. github / README_TA.md) IsiTamil | [tt Татар] (/. github / README_TT.md) isiTatar | [te తెలుగు] (/. github / README_TE.md) IsiTelugu | [th ไทย] (/. github / README_TH.md) isiThai | [tr Türk] (/. github /README_TR.md) IsiTurkish | [tk Türkmenler] (/. github / README_TK.md) AmaTurkmen | [uk Український] (/. github / README_UK.md) Isi-Ukraine | [ur اردو] (/. github / README_UR.md) Isi-Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbek | [vi Tiếng Việt] (/. github / README_VI.md) Isi-Vietnamese | [cy Cymraeg] (/. github / README_CY.md) Isi-Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) IsiYiddish | [yo Yoruba] (/. github / README_YO.md) IsiYoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Kutholakala ngezilimi eziyi-110 (108 uma singabalwa isiNgisi neNyakatho Korea, njengoba iNorth Korea ingakahunyushwa kuze kube manje [Funda ngakho lapha] (/ OldVersions / Korean (North ) /README.md))

Ukuhumusha kwezinye izilimi ngaphandle kwesiNgisi kuhunyushwe ngomshini futhi akukacaci okwamanje. Awekho amaphutha alungisiwe okwamanje kusuka ngoFebhuwari 5, 2021. Sicela ubike amaphutha wokuhumusha [lapha] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) qiniseka ukwenza isipele ukulungiswa kwakho nge imithombo futhi ungiqondise, ngoba angizazi kahle ezinye izilimi ngaphandle kwesiNgisi (ngihlela ukuthola umhumushi ekugcineni) ngicela usho [wiktionary] (https://en.wiktionary.org) neminye imithombo embikweni wakho. Ukwehluleka ukwenza lokho kuzoholela ekwenqabeni ukulungiswa okushicilelwa.

Qaphela: ngenxa yemikhawulo ngokuchazwa kweGitHub yokumaka (futhi kuhle kakhulu konke okunye okususelwa kuwebhu kokumakwa) ngokuchofoza lezi zixhumanisi kuzokuqondisa kabusha kufayela elihlukile ekhasini elihlukile okungelona ikhasi lami le-GitHub. Uzoqondiswa kabusha uye e- [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), lapho kubanjelwa khona i-README.

Ukuhumusha kwenziwa nge-Google Translate ngenxa yokusekelwa okulinganiselwe noma okungekho kwezilimi engizidingayo kwezinye izinsizakalo zokuhumusha njenge-DeepL ne-Bing Translate (okuhlekisayo emkhankasweni wokulwa ne-Google) ngisebenza ukuthola enye indlela. Ngasizathu simbe, ukufomatha (izixhumanisi, ukwahlukanisa, ukugqama, ama-ithalikhi, njll.) Kudidekile ekuhumusheni okuhlukahlukene. Kuyadina ukulungisa, futhi angazi ukuthi zingalungiswa kanjani lezi zinkinga ngezilimi nezinhlamvu ezingezona ezesi-latin, futhi izilimi ezingakwesokunxele (njenge-Arabhu) kudingeka usizo olwengeziwe ekulungiseni lezi zinkinga

Ngenxa yezinkinga zokulungiswa, ukuhumusha okuningi kuphelelwe yisikhathi futhi kusetshenziswa inguqulo ephelelwe yisikhathi yaleli fayela le-athikili elithi `README`. Kudingeka umhumushi. Futhi, kusukela ngo-Ephreli 23rd 2021, kuzongithatha isikhashana ukwenza zonke izixhumanisi ezintsha zisebenze.

***

# Isikhathi sokusika i-Widevine

Le yindatshana yokuthi kungani kufanele uyeke ukusebenzisa iGoogle WideVine (DRM) bese uyikhipha. I-DRM idinga ukususwa. Le ndatshana izokusiza wenze ukukhetha kwakho (uma ungakakwenzi) iWideVine iphikisana kakhulu nokuncintisana, futhi inemikhawulo ngokweqile, futhi icekela phansi inkululeko yamavidiyo akwi-Intanethi.

Masisike i-WideVine bese samukela i-Intanethi evulekile.

***

# Inkomba

[00.0 - Phezulu] (# Phezulu)

> [00.1 - Funda le ndatshana ngolimi oluhlukile]

> [00.2 - Isihloko] (# Isikhathi-sokusika-Umugqa Womzimba)

> [00.3 - Index] (# Inkomba)

[01.0 - Ukubuka konke] (# Ukubuka konke)

[02.0 - Ukulwa nokuncintisana] (# Ukuncintisana)

[03.0 - Ukuntuleka kwenkululeko] (# Ukungabi nenkululeko)

[04.0 - Ukusetshenziswa kwememori] (# Ukusetshenziswa kwememori)

[05.0 - Ubumfihlo] (# Ubumfihlo)

[06.0 - Ezinye izindlela] (# Ezinye izindlela)

[07.0 - Ongakwenza ukusiza] (# Yini-wena-ongakwenza ukusiza)

[08.0 - Ezinye izinto ozozihlola] (# Ezinye izinto-okufanele uhlole)

[09.0 - Imininingwane ye-Article] (# Imininingwane ye-Article)

> [09.0.1 - Isimo seSoftware] (# Isimo sesoftware)

> [09.0.2 - Ulwazi lomxhasi] (# Ulwazi lomxhasi)

[10.0 - Umlando wefayela] (# Umlando wefayela)

[11.0 - Unyaweni] (# Unyaweni)

> [11.9 - EOF] (# EOF)

***

# # Ukubuka konke

Ngeminye imininingwane yokuthi kungani i-DRM iyinkinga, [chofoza lapha] (https://www.defectivebydesign.org/)

***

## Ukuncintisana

I-WideVine yi-DRM okufanele inikezwe ilayisense ukuthi isetshenziswe nesiphequluli. I-Google ihamba kancane kakhulu ekubuyekezeni nasekwamukeleni abantu, futhi ivame ukwenqaba abantu ukuthi bayisebenzise emikhiqizweni yabo ngaphandle kwesizathu. [Umthombo 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Umthombo 2 (intambo ye-imeyili eqhubeke izinyanga ezingaphezu kwezingu-4 futhi ayibanga nalutho ngaphandle kokuphoxeka)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) I-Google yenze kwaba nzima kakhulu ukuthi iziphequluli ezinjengeBrave noma iFirefox zincintisane ngokuphusha kwayo le ngxenye ye-DRM.

***

## Ukuntuleka kwenkululeko

I-WideVine isetshenziselwa ukuvimbela abasebenzisi ekuxhumaneni nevidiyo ekumawebhusayithi. Kuyindlela yokuphathwa kwemikhawulo yedijithali ekuvimbela ekulandeni ividiyo, ukubuka ividiyo ungaxhunyiwe ku-inthanethi, noma ukuthatha isithombe-skrini. Kuyisoftware ephathelene futhi ngenxa yezinkinga zayo ngobumfihlo, ayifakiwe ngokuzenzakalela kuningi lokusatshalaliswa kweLinux. Kukhawulela inkululeko yewebhu ngenxa yokusebenzisa kwayo ama-movie we-Netflix, Disney, ne-YouTube. Ukufinyelela kwakho kokuqukethwe kungasuswa nganoma yisiphi isikhathi ngaphandle kwesizathu.

***

## Ukusetshenziswa kwememori

I-WideVine ayilungile kwimemori. Uma kuqhathaniswa nokubuka ividiyo evamile ngaphandle kwe-DRM, iWideVine izosebenzisa amanani asindayo we-CPU ne-RAM. Kubi ku-battery life, futhi akuniki mihlomulo ngokudlala ividiyo okujwayelekile kwe-HTML5.

***

# # Ubumfihlo

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / konke-idatha-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit))ss (( https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spy-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he idatha ye-alth) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Ukugxekwa) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -izibonelo / lutho-ukufihla-ukuphikisana-akanalutho-lokuzisho /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- idatha-mayelana nawe-ungayithola futhi uyisuse-manje /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -izimele-idatha-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -futhi [c] (https://www.wired.com/story/google-tracks-you -ubumfihlo /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)letondhttps: //www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)letono-https://en.wikipedia.org/wiki/2018_Google_data_breach)inglymimele(https://:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- izimangalo-ze-ze-5-million-iphone-users) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W))e)(https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technolo gy / 2014/01 / yini-google-engakwenza-ngempela-ngesidleke-noma-izidleke-zedatha /) [i] (https://www.cbsnews.com/news/google-education-spies -on-collects-data-on-millions-of-kids-alleges-lawsuit-new-mexico-attorney-general /) [v] (https://www.nationalreview.com/2018/04/the-student- idatha-yezimayini-ihlazo-ngaphansi-kwamakhala ethu /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)letony )(https://medium.com/@hansdezwart/during-world-war-ii-did-have -nto-ukufihla-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (ngingaqhubeka nokuqhubeka nobufakazi balokhu , kepha kuthathe isikhathi eside ukuthola nokufunda zonke lezi zihloko)

Ubumfihlo akuyona into nge-WideVine. Isoftware ephathelene nayo yenzelwe ukuthi ungaboni okwenzekayo nhlobo. Ngomlando weGoogles, kungenzeka kakhulu ukuthiI-WideVine ucezu olwengeziwe lwesoftware ekuhlolelayo, ifunda amadokhumenti akho, nezinye izinto ezimbi.

Uma ucabanga ukuthi awunakho okufihlayo, ** awunaphutha ngokuphelele **. Le mpikiswano ikhishwe kaningi ngaphezulu:

[Nge-Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. U-Edward Snowden uphawule "Ukuphikisana ngokuthi awunandaba nelungelo lokuba nemfihlo ngoba awunakho okufihlayo akufani nokuthi uthi awunandaba nenkululeko yokukhuluma ngoba awunalutho ongalusho." Uma uthi, ' Akukho engikufihlayo, 'usho,' Anginandaba naleli lungelo. 'Uthi,' Anginalo leli lungelo, ngoba ngifikile lapho kufanele ngikhulume khona Indlela okusebenza ngayo amalungelo, uhulumeni kufanele athethelele ukungenela kwakhe emalungelweni akho. "

2. UDaniel J. Solove usho ku-athikili yeThe Chronicle of Higher Education ukuthi uyayiphikisa le mpikiswano; wathi uhulumeni angavuza imininingwane ngomuntu futhi adale umonakalo kulowo muntu, noma asebenzise imininingwane ephathelene nomuntu ukwenqaba ukufinyelela ezinsizakalweni noma ngabe umuntu ubengazibandakanyi nokwenza okungalungile, nokuthi uhulumeni angalimaza umuntu impilo ngokwenza amaphutha. USolove ubhale ukuthi "Uma kuxoxiswana ngqo, impikiswano yokufihla okuthile ingacupha, ngoba iphoqa impikiswano ukuthi igxile ekuqondeni kwayo okuncane mayelana nobumfihlo. Kepha lapho ibhekene nobuningi bezinkinga zobumfihlo ezithintwa ukuqoqwa kwedatha kahulumeni nokusetshenziswa ngaphandle kokubhekwa futhi ukudalulwa, impikiswano yokufihla lutho, ekugcineni, ayinalutho olungakusho. "

3. U-Adam D. Moore, umbhali wamaLungelo Obumfihlo: Izisekelo Zokuziphatha Nezomthetho, wathi, "umbono wokuthi amalungelo aphikisana nezindleko / inzuzo noma uhlobo lwezimpikiswano. Lapha senqaba umbono wokuthi izintshisekelo zobumfihlo ziyizinhlobo ezithile wezinto ezingathengiselwa ukuphepha. " Ubuye wathi ukubhekwa kungathinta ngokungalingani amaqembu athile emphakathini ngokususelwa ekubukekeni, ubuhlanga, ubulili nenkolo.

4. UBruce Schneier, uchwepheshe wezokuphepha kwamakhompiyutha nomlobi we-cryptographer, uzwakalise ukuphikisa, ecaphuna isitatimende sikaKhadinali Richelieu esithi "Uma umuntu enganginika imigqa eyisithupha ebhalwe ngesandla sendoda ethembeke kakhulu, ngingathola okuthile kuyo ukuze alengiswe", ebhekisa ukuthi uhulumeni wezwe angazithola kanjani izici empilweni yomuntu ukuze ashushise noma ahlasele lowo muntu. USchneier uphinde wathi "Kuningi kakhulu okufanisa impikiswano ngokuthi 'ukuphepha kuqhathaniswa nobumfihlo.' Inketho yangempela inkululeko yokuqhathanisa nokulawula. "

5. UHarvey A. Silverglate ulinganisele ukuthi umuntu ovamile, ngokwesilinganiso, ngokungazi wenza izigilamkhuba ezintathu ngosuku e-US.

6. U-Emilio Mordini, isazi sefilosofi kanye nomqondo wezengqondo, waphikisa ngokuthi impikiswano yokuthi "akukho okufihlwayo" iyindida. Abantu abadingi ukuthi babe "nokuthile abakufihlayo" ukuze bakwazi ukufihla "okuthile". Okufihliwe akubalulekile, kusho uMordini. Esikhundleni salokho, uthi indawo esondelene kakhulu engafihlwa nokuvinjelwa ukufinyelela ayidingeki ngoba, ukukhuluma ngokwengqondo, siba ngabantu ngokutholwa ukuthi singafihla okuthile kwabanye.

7. UJulian Assange uthe "Akukabikho mpendulo ebulalayo. UJacob Appelbaum (@ioerror) unempendulo ehlakaniphile, ebuza abantu abasho lokhu ukuthi bamnikeze ifoni yabo ivuliwe bese behlisa amabhulukwe abo. Uhlobo lwami lalokho ukuthi, "Uma unesicefe ngakho-ke bekungafanele ukuthi sikhulume nawe, futhi kungafanele futhi kube omunye umuntu", kodwa ngokwefilosofi, impendulo yangempela yilena: Ukuqashwa kweMisa wushintsho olukhulu lwesakhiwo. Uma umphakathi uqhubeka kabi, kuyahamba ukuhamba nawe, noma ngabe ungumuntu oyisicefe kunabo bonke emhlabeni. "

8. U-Ignacio Cofone, uprofesa wezomthetho, uthi ingxabano iyiphutha ngokwemibandela yayo ngoba, noma nini lapho abantu bedalula imininingwane efanele kwabanye, badalula nemininingwane engabalulekile. Lolu lwazi olungabalulekile lunezindleko zobumfihlo futhi lungaholela kokunye ukulimala, njengokubandlululwa.

***

# Izindlela ezihlukile

Imidiya akufanele ivinjelwe, ku-inthanethi noma ku-inthanethi. Uma abantu befuna ukubuka ividiyo ngaphandle kwe-DRM, bayohlala bethola indlela yokwenza. Yonke ingxenye yesoftware ingaqhekeka.

[Ingcaphuno eguquliwe evela kuWikipedia] Umongameli weValve uGabe Newell uthe "amasu amaningi e-DRM ayizithutha nje" ngoba anciphisa inani lomdlalo emehlweni womthengi. UNewell uphakamisa ukuthi esikhundleni salokho injongo kufanele "[idale] inani elikhulu lamakhasimende ngenani lensizakalo" Qaphela ukuthi iValve isebenza ngeSteam, insizakalo esebenza njengesitolo esiku-inthanethi semidlalo ye-PC, kanye nensizakalo yokuxhumana nabantu kanye nesikhulumi se-DRM

Leli phuzu alivumelekile emidlalweni yevidiyo kuphela, lingasetshenziswa kunoma yini ekukhompyutha. Ikhompyutha yakho akufanele ilawulwe ngokuphelele yinkampani engasile esebenzisa i-Artificial Intelligence embi ukususa abasebenzisi bayo nomsebenzi wabo (i-YouTube, njll.) Futhi inerekhodi elibi kangako. Ikhompyutha yakho akufanele ivinjelwe ngoba inkampani iyenqaba ukwabelana njengengane eziphatha kabi. Ikhompyutha yakho kufanele ibe ngeyakho,futhi akekho omunye. Kufanele ulahle i-DRM ngokuphelele, ngoba okuqukethwe akukufanele ukuyeka ukulawula ikhompyutha yakho. Lezi zinkampani zinamakhulu ezigidigidi zamadola. Uma benza into ewubuwula kanjena, kufanele uyibhikishe. Ungavele ulande ividiyo kwenye indawo bese uyibuka, ngoba kufanele ngabe balahlekelwa yimali ngokwenza izinto eziwubuphukuphuku ezinjengalezi. Ukuphulwa kwe-copyright akuyona into embi. Abantu abangakwazi ukukhokhela ama-movie bazowalanda kwenye indawo, bekulokhu kwenzeka kusukela kuqale i-Intanethi yomhlaba kanye nokusungulwa kwetape VHS. Akuthinti neze imali yabo, ngoba bebengeke bakwazi ukuyithola leyo mali noma kunjalo. I-DRM ayilungile ngokwakhiwa.

***

## Ongakwenza ukusiza

Ungabhikisha i-DRM. Kungabonakala kungabalulekile, kepha lapho abantu abaningi bephikisana nakho, kulapho kwenziwa khona ngakho.

Uma ukuLinux futhi usebenzisa iFirefox, qiniseka ukuthi i-DRM ayifakiwe (imvamisa ayizenzeki) futhi ungazihluphi ngokuyifaka.

Uma uku-Windows noma i-MacOS, ungaba nesikhathi esinzima kakhulu, njengoba i-DRM ifakwa ngokuzenzakalela kulezi zinhlelo, futhi ingafaka kabusha ngokuzenzakalela.

Zama ukugwema amasayithi alandelayo:

[Hulu] (https://hulu.com)

[I-Disney +] (https://www.disneyplus.com/)

[Okubalulekile +] (https://www.paramountplus.com/)

Ngokuyinhloko, cishe noma iyiphi insizakalo yokusakaza ividiyo eku-inthanethi kufanele igwenywe, njengoba iningi lazo lisebenzisa i-DRM futhi awukwazi ukusebenzisa isayithi ngaphandle kokulahlekelwa yinkululeko yakho. Akufanele. Thumela i- [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) umyalezo bese uyeka ukusakaza le mibukiso.

Kufanele futhi ugweme noma yiziphi izinketho "zamahhala ezinezikhangiso" kumasayithi alandelayo (njengoba le ndlela idinga i-DRM)

[YouTube] (https://www.youtube.com)

Ungabhikisha ne-DRM ngomyalezo kumaphrojekthi wakho we-`README.md` file. Nakhu engikusebenzisayo:

`` Ukumaka

***

# # Isimo seSoftware

Yonke imisebenzi yami imahhala eminye imikhawulo. I-DRM (** D ** igital ** R ** estrictions ** M ** anagement) ayikho kunoma yimuphi umsebenzi wami.

! [I-DRM-free_label.en.svg] (i-DRM-free_label.en.svg)

Lesi sitika sisekelwa yiFree Software Foundation. Angikaze ngihlose ukufaka i-DRM emisebenzini yami.

Ngisebenzisa isifinyezo esithi "Ukuphathwa Kwemikhawulo Yedijithali" esikhundleni se- "Digital Rights Management" esaziwa kakhulu njengoba indlela ejwayelekile yokubhekana nayo ingamanga, awekho amalungelo ane-DRM. Isipelingi "Ukuphathwa Kwemikhawulo Yedijithali" sinembe kakhudlwana, futhi sisekelwa ngu- [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) kanye ne- [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Lesi sigaba sisetshenziselwa ukuqwashisa ngezinkinga nge-DRM, nokuphikisana nayo. I-DRM inamaphutha ngokwakhiwa futhi iyingozi enkulu kubo bonke abasebenzisi bekhompyutha kanye nenkululeko yesoftware.

Isikweletu sesithombe: [defectivebydesign.org/drm-free/...] (https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

``

***
## Ezinye izinto ozozihlola

[Iphutha ngokwakhiwa - Umkhankaso weFree Software Foundation osebenza ekudaluleni nasekuqedeni ukusetshenziswa kwe-DRM] (https://www.defectivebydesign.org/)

[Amathuna eGoogle (killbygoogle.com) - uhlu oluhleliwe lwemikhiqizo engama-224 + i-Google eyibulele] (https://killedbygoogle.com/)

> [Isixhumanisi seGitHub] (https://github.com/codyogden/killedbygoogle)

[Inyunyana yabasebenzi bama-alfabhethi - Inyunyana entsha yabasebenzi kwaGoogle enamalungu angaphezu kuka-800] (https://alphabetworkersunion.org/people/our-union/)

Kukhona okunye okushintshanayo, vele useshe.

***

## Imininingwane ye-Article

Uhlobo lwefayela: `Markdown (* .md)`

Uhlobo lwefayela: `4 (NgoLwesihlanu, Ephreli 23rd 2021 ngo-3: 35 ntambama)`

Ukubalwa kolayini (kufaka phakathi imigqa engenalutho nomugqa wokuhlanganisa): `354`

# # # Isimo sesoftware

Yonke imisebenzi yami ayinayo imikhawulo. I-DRM (** D ** igital ** R ** estrictions ** M ** anagement) ayikho kunoma yimuphi umsebenzi wami. Le phrojekthi ayiqukethe i-DRM, kepha ikhuluma nge-DRM ngqo.

! [I-DRM-free_label.en.svg] (i-DRM-free_label.en.svg)

Lesi sitika sisekelwa yiFree Software Foundation. Angikaze ngihlose ukufaka i-DRM emisebenzini yami.

***

### Ulwazi lomxhasi

! [SponsorButton.png] (SponsorButton.png) <- Le akuyona inkinobho esemthethweni yomxhasi, isithombe sedemo. Ungayichofozi uma ufuna ukuxhasa le phrojekthi.

Ungaxhasa le phrojekthi uma uthanda, kodwa sicela ucacise ukuthi ufuna ukunikela kuphi. [Bona izimali onganikela ngazo lapha) (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Ungabuka eminye imininingwane yabaxhasi [lapha] (https://github.com/seanpm2001/Sponsor-info/)

Izame! Inkinobho yabaxhasi ilungile eduze kwenkinobho yokubuka / yokuqaqa.

***

# # Umlando wefayela

Inguqulo 1 (NgeSonto, ngoFebhuwari 8, 2021 ngo-4: 41 ntambama)

> Izinguquko:

> * Kuqale ifayili / i-athikili

> * Kungezwe isigaba sesihloko

> * Kungezwe isigaba mayelana nobumfihlo

> * Kungezwe isigaba mayelana nokubuka konke

> * Kungezwe isigaba semininingwane yolwazi

> * Ikhombe isithonjana samahhala se-DRM

> * Kungezwe isigaba somlando wefayela

> * Kungezwe ukuntuleka kwenkululeko

> * Kungezwe isigaba se-Anti-yokuncintisana

> * Kungezwe isigaba sezinye izindlela

> * Kungezwe imemory isigaba sokusetshenziswa

> * Kungezwe ezinye izinto ukuhlola isigaba

> * Kungezwe inkomba

> * Kungezwe unyaweni

> * Azikho ezinye izinguquko enguqulweni 1

Uhlobo 2 (NgoLwesine, Ephreli 8th 2021 ngo-5: 18 ntambama)

> Izinguquko:

> * Kubuyekezwe isigaba sesihloko

> * Kubuyekezwe inkomba

> * Imininingwane engeziwe yokuthi yini ongayenza ukusiza

> * Kungezwe isigaba semininingwane yomxhasi

> * Kubuyekezwe isigaba semininingwane yefayela

> * Kubuyekezwe isigaba somlando wefayela

> * Azikho ezinye izinguquko enguqulweni 2

Inguqulo 3 (ngoLwesine, Ephreli 8th 2021 ngo-5: 27 ntambama)

> Izinguquko:

> * Izixhumanisi zokuhumusha ezihleliwe

> * Kubuyekezwe inkomba

> * Kulungiswe impinda, kufakwe isihloko esihlokweni esithi `ongakwenza ukusiza`

> * Kubuyekezwe isigaba semininingwane yabaxhasi

> * Kubuyekezwe isigaba semininingwane yefayela

> * Kubuyekezwe isigaba somlando wefayela

> * Azikho ezinye izinguquko enguqulweni 3

Uhlobo 4 (NgoLwesihlanu, Ephreli 23rd 2021 ngo-3: 35 ntambama)

> Izinguquko:

> * Kubuyekezwe uhlu lwezishintshi zolimi

> * Kubuyekezwe isigaba semininingwane yefayela

> * Kubuyekezwe isigaba somlando wefayela

> * Azikho ezinye izinguquko kunguqulo 4

Inguqulo 5 (Iyeza maduze)

> Izinguquko:

> * Iyeza maduze

> * Azikho ezinye izinguquko enguqulweni 5

Inguqulo 6 (Iyeza maduze)

> Izinguquko:

> * Iyeza maduze

> * Azikho ezinye izinguquko enguqulweni 6

Inguqulo 7 (Iyeza maduze)

> Izinguquko:

> * Iyeza maduze

> * Azikho ezinye izinguquko enguqulweni 7

Inguqulo 8 (Iyeza maduze)

> Izinguquko:

> * Iyeza maduze

> * Azikho ezinye izinguquko enguqulweni 8

***

## Unyaweni

Usufike ekugcineni kwaleli fayela!

##### EOF

***
