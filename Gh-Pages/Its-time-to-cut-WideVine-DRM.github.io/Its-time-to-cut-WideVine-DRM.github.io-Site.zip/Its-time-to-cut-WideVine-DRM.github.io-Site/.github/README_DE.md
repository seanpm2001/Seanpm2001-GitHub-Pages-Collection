***.

##### Oben

_Lesen Sie diesen Artikel in einer anderen Sprache: _

** Aktuelle Sprache ist: ** `Englisch (USA)` _ (Übersetzungen müssen möglicherweise korrigiert werden, um zu korrigieren, dass Englisch die richtige Sprache ersetzt) ​​_

_🌐 Liste der Sprachen_

** Sortiert nach: ** `A-Z`

[Sortieroptionen nicht verfügbar] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanisch | [am አማርኛ] (/. github / README_AM.md) Amharisch | [ar عربى] (/.github/README_AR.md) Arabisch | [hy հայերեն] (/. github / README_HY.md) Armenisch | [az Azərbaycan dili] (/. github / README_AZ.md) Aserbaidschanisch | [eu Euskara] (/. github /README_EU.md) Baskisch | [be Беларуская] (/. Github / README_BE.md) Weißrussisch | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnisch | [bg български] (/. Github / README_BG.md) Bulgarisch | [ca Català] (/. Github / README_CA.md) Katalanisch | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chinesisch (vereinfacht) | [zh-t 中國 傳統）] (/. github / README_ZH -T.md) Chinesisch (traditionell) | [co Corsu] (/. Github / README_CO.md) Korsisch | [hr Hrvatski] (/. Github / README_HR.md) Kroatisch | [cs čeština] (/. Github / README_CS .md) Tschechisch | [da dansk] (README_DA.md) Dänisch | [nl Niederlande] (/. github / README_ NL.md) Niederländisch | [** en-us English **] (/. github / README.md) English | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estnisch | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finnisch | [fr français] (/. github / README_FR.md) Französisch | [fy Frysk] (/. github / README_FY.md) Friesisch | [gl Galego] (/. github / README_GL.md) Galizisch | [ka ქართველი] (/. github / README_KA) Georgisch | [de Deutsch] (/. github / README_DE.md) Deutsch | [el Ελληνικά] (/. github / README_EL.md) Griechisch | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitianisches Kreol | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) Hebräisch | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ungarisch | [is Íslenska] (/. github / README_IS.md) Isländisch | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Isländisch | [ga Gaeilge] (/. github / README_GA.md) Irisch | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japanisch | [jw Wong jawa] (/. github / README_JW.md) Javanisch | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kasachisch | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Koreanisch (Süd) | [ko-north 문화어] (README_KO_NORTH.md) Koreanisch (Nord) (NOCH NICHT ÜBERSETZT) | [ku Kurdî] (/. github / README_KU.md) Kurdisch (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgisisch | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latein | [lt Lietuvis] (/. github / README_LT.md) Litauisch | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgisch | [mk Македонски] (/. github / README_MK.md) Mazedonisch | [mg Madagassisch] (/. github / README_MG.md) Madagassisch | [ms Bahasa Melayu] (/. github / README_MS.md) Malaiisch | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltesisch | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolisch | [mein မြန်မာ] (/. github / README_MY.md) Myanmar (Burmesisch) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) Norwegisch | [oder ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persisch [pl polski] (/. github / README_PL.md) Polnisch | [pt português] (/. github / README_PT.md) Portugiesisch | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Keine Sprachen verfügbar, die mit dem Buchstaben Q | beginnen [ro Română] (/. github / README_RO.md) Rumänisch | [ru русский] (/. github / README_RU.md) Russisch | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Schottisch-Gälisch | [sr Српски] (/. github / README_SR.md) Serbisch | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Singhalesisch | [sk Slovák] (/. github / README_SK.md) Slowakisch | [sl Slovenščina] (/. github / README_SL.md) Slowenisch | [so Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spanisch | [su Sundanis] (/. github / README_SU.md) Sundanesisch | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Schwedisch | [tg Тоҷикӣ] (/. github / README_TG.md) Tadschikisch | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github /README_TR.md) Türkisch | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukrainisch | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uigurisch | [uz O'zbek] (/. github / README_UZ.md) Usbekisch | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamesisch | [cy Cymraeg] (/. github / README_CY.md) Walisisch | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Jiddisch | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Verfügbar in 110 Sprachen (108 ohne Englisch und Nordkoreanisch, da Nordkoreanisch noch nicht übersetzt wurde [Lesen Sie hier darüber] (/ OldVersions / Koreanisch (Nord) ) /README.md))

Übersetzungen in andere Sprachen als Englisch sind maschinell übersetzt und noch nicht korrekt. Bis zum 5. Februar 2021 wurden noch keine Fehler behoben. Bitte melden Sie Übersetzungsfehler [hier] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/). Stellen Sie sicher, dass Sie Ihre Korrektur mit sichern Quellen und Anleitung, da ich keine anderen Sprachen als Englisch gut kenne (ich plane, irgendwann einen Übersetzer zu bekommen), zitieren Sie bitte [wiktionary] (https://en.wiktionary.org) und andere Quellen in Ihrem Bericht. Andernfalls wird die veröffentlichte Korrektur der Korrektur abgelehnt.

Hinweis: Aufgrund von Einschränkungen bei der Interpretation von Markdown durch GitHub (und so ziemlich jeder anderen webbasierten Interpretation von Markdown) werden Sie durch Klicken auf diese Links zu einer separaten Datei auf einer separaten Seite weitergeleitet, die nicht meine GitHub-Profilseite ist. Sie werden zum [seanpm2001 / seanpm2001-Repository] (https://github.com/seanpm2001/seanpm2001) weitergeleitet, in dem die README gehostet wird.

Übersetzungen werden mit Google Translate durchgeführt, da die Sprachen, die ich in anderen Übersetzungsdiensten wie DeepL und Bing Translate benötige (ziemlich ironisch für eine Anti-Google-Kampagne), nur eingeschränkt oder gar nicht unterstützt werden. Ich arbeite daran, eine Alternative zu finden. Aus irgendeinem Grund ist die Formatierung (Links, Teiler, Fettdruck, Kursivschrift usw.) in verschiedenen Übersetzungen durcheinander. Die Behebung ist mühsam, und ich weiß nicht, wie diese Probleme in Sprachen mit nicht-lateinischen Zeichen behoben werden können. Bei der Behebung dieser Probleme ist zusätzliche Hilfe von rechts nach links (wie Arabisch) erforderlich

Aufgrund von Wartungsproblemen sind viele Übersetzungen veraltet und verwenden eine veraltete Version dieser README-Artikeldatei. Ein Übersetzer wird benötigt. Ab dem 23. April 2021 werde ich außerdem eine Weile brauchen, um alle neuen Links zum Laufen zu bringen.

***.

# Es ist Zeit, Widevine zu schneiden

Dies ist ein Artikel darüber, warum Sie Google WideVine (DRM) nicht mehr verwenden und deinstallieren sollten. DRM muss entfernt werden. Dieser Artikel hilft Ihnen bei der Auswahl (falls Sie dies noch nicht getan haben). WideVine ist äußerst wettbewerbswidrig und äußerst restriktiv und zerstört die Freiheit von Videos im Internet.

Lassen Sie uns die WideVine abschneiden und ein offenes Internet nutzen.

***.

# Index

[00.0 - Oben] (# Oben)

> [00.1 - Lesen Sie diesen Artikel in einer anderen Sprache]

> [00.2 - Titel] (# Es ist Zeit, Widevine zu schneiden)

> [00.3 - Index] (# Index)

[01.0 - Übersicht] (# Übersicht)

[02.0 - wettbewerbswidrig] (# wettbewerbswidrig)

[03.0 - Mangel an Freiheit] (# Mangel an Freiheit)

[04.0 - Speichernutzung] (# Speichernutzung)

[05.0 - Datenschutz] (# Datenschutz)

[06.0 - Alternative Methoden] (# Alternative Methoden)

[07.0 - Was Sie tun können, um zu helfen] (# Was Sie tun können, um zu helfen)

[08.0 - Andere Dinge zum Auschecken] (# Andere Dinge zum Auschecken)

[09.0 - Artikelinfo] (# Artikelinfo)

> [09.0.1 - Softwarestatus] (# Softwarestatus)

> [09.0.2 - Sponsorinfo] (# Sponsorinfo)

[10.0 - Dateiversionsverlauf] (# Dateiversionsverlauf)

[11.0 - Fußzeile] (# Fußzeile)

> [11.9 - EOF] (# EOF)

***.

## Überblick

Weitere Informationen darüber, warum DRM ein Problem darstellt, finden Sie [hier klicken] (https://www.defectivebydesign.org/).

***.

## Wettbewerbswidrig

WideVine ist ein DRM, der lizenziert werden muss, um mit einem Browser verwendet zu werden. Google überprüft und akzeptiert Personen nur sehr langsam und lehnt es häufig ab, sie ohne Begründung in ihren Produkten zu verwenden. [Quelle 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Quelle 2 (der E-Mail-Thread, der über 4 Monate andauerte und nur zu Enttäuschungen führte)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google hat es Browsern wie Brave oder Firefox viel schwerer gemacht, mit der Verbreitung dieses DRM-Teils zu konkurrieren.

***.

## Mangel an Freiheit

WideVine wird verwendet, um zu verhindern, dass Benutzer mit Videos auf Websites interagieren. Es handelt sich um eine Form der Verwaltung digitaler Einschränkungen, die Sie daran hindert, das Video herunterzuladen, das Video offline anzuzeigen oder sogar einen Screenshot zu erstellen. Es handelt sich um proprietäre Software, die aufgrund ihrer Datenschutzprobleme auf den meisten Linux-Distributionen nicht standardmäßig installiert ist. Es schränkt die Freiheiten des Webs aufgrund seiner Verwendung durch Netflix-, Disney- und YouTube-Filme ein. Ihr Zugriff auf die Inhalte kann jederzeit ohne Angabe von Gründen entzogen werden.

***.

## Speichernutzung

WideVine hat einen schlechten Speicher. Im Vergleich zum normalen Anzeigen eines Videos ohne DRM benötigt WideVine viel CPU und RAM. Es ist schlecht auf battery life, und es bietet keine Vorteile aus der Standard-HTML5-Videowiedergabe.

***.

## Privatsphäre

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (Überwachungsprogramm)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s‹(https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritik) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nichts-zu-verbergen-Argument-hat-nichts-zu-sagen /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- Daten über Sie, die Sie jetzt finden und löschen können /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -und) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d‹(https://www.reuters.com/article/us-alphabet- google-privacy-Klage-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o‹(https://en.wikipedia.org/wiki/2018_Google_data_breach)[m‹(https:/// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- Ansprüche im Namen von 5 Millionen iPhone-Nutzern) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e weibl -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technolo gy / 2014/01 / Was-Google-kann-wirklich-mit-Nest-oder-wirklich-Nestern-Daten tun /) [i] (https://www.cbsnews.com/news/google-education-spies -on-sammelt-Daten-über-Millionen-von-Kindern-behauptet-Klage-New-Mexico-Generalstaatsanwalt /) [v] (https://www.nationalreview.com/2018/04/the-student- Data-Mining-Skandal unter unserer Nase /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y‹(https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Ich könnte mit Beweisen dafür weitermachen , aber es hat lange gedauert, all diese Artikel zu finden und durchzugehen.)

Datenschutz ist bei WideVine keine Sache. Proprietäre Software ist so konzipiert, dass Sie überhaupt nicht sehen können, was gerade passiert. Mit der Geschichte von Googles ist es sehr wahrscheinlich, dassWideVine ist eine zusätzliche Software, die Sie ausspioniert, Ihre Dokumente liest und andere schlechte Dinge.

Wenn Sie denken, Sie haben nichts zu verbergen, ** liegen Sie absolut falsch **. Dieses Argument wurde mehrfach entlarvt:

[Über Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden bemerkte: "Das Argument, dass Ihnen das Recht auf Privatsphäre egal ist, weil Sie nichts zu verbergen haben, ist nichts anderes als zu sagen, dass Ihnen die Redefreiheit egal ist, weil Sie nichts zu sagen haben." Ich habe nichts zu verbergen «, sagen Sie,» dieses Recht interessiert mich nicht. «Sie sagen:» Ich habe dieses Recht nicht, weil ich an einem Punkt angelangt bin, an dem ich es rechtfertigen muss it. "So wie Rechte funktionieren, muss die Regierung ihren Eingriff in Ihre Rechte rechtfertigen."

2. Daniel J. Solove erklärte in einem Artikel für The Chronicle of Higher Education, dass er sich dem Argument widersetzt; Er erklärte, dass eine Regierung Informationen über eine Person verlieren und dieser Person Schaden zufügen oder Informationen über eine Person verwenden kann, um den Zugang zu Diensten zu verweigern, selbst wenn eine Person tatsächlich kein Fehlverhalten begangen hat, und dass eine Regierung ihrer Person Schaden zufügen kann Leben durch Fehler. Solove schrieb: "Wenn das Argument, das nicht zu verbergen ist, direkt verwickelt wird, kann es die Debatte verführen, da es die Debatte dazu zwingt, sich auf sein enges Verständnis der Privatsphäre zu konzentrieren Offenlegung, das Argument, nichts zu verbergen, hat am Ende nichts zu sagen. "

3. Adam D. Moore, Autor von Privacy Rights: Moral and Legal Foundations, argumentierte: "Es ist die Ansicht, dass Rechte gegen Kosten / Nutzen- oder konsequentialistische Argumente resistent sind. Hier lehnen wir die Ansicht ab, dass Datenschutzinteressen die Art sind." von Dingen, die gegen Sicherheit eingetauscht werden können. " Er erklärte auch, dass die Überwachung bestimmte Gruppen in der Gesellschaft aufgrund ihres Aussehens, ihrer ethnischen Zugehörigkeit, ihrer Sexualität und ihrer Religion überproportional beeinflussen kann.

4. Bruce Schneier, ein Experte für Computersicherheit und Kryptograf, sprach sich dagegen aus und zitierte die Aussage von Kardinal Richelieu: "Wenn man mir sechs Zeilen geben würde, die von der Hand des ehrlichsten Mannes geschrieben wurden, würde ich in ihnen etwas finden, das ihn hängen lässt." wie eine Landesregierung Aspekte im Leben einer Person finden kann, um diese Person zu verfolgen oder zu erpressen. Schneier argumentierte auch: "Zu viele charakterisieren die Debatte fälschlicherweise als" Sicherheit versus Datenschutz ". Die wirkliche Wahl ist Freiheit gegen Kontrolle. "

5. Harvey A. Silverglate schätzte, dass die gewöhnliche Person in den USA im Durchschnitt unwissentlich drei Verbrechen pro Tag begeht.

6. Emilio Mordini, Philosoph und Psychoanalytiker, argumentierte, dass das Argument "nichts zu verbergen" von Natur aus paradox sei. Menschen müssen nicht "etwas zu verbergen" haben, um "etwas" zu verbergen. Was verborgen ist, ist nicht unbedingt relevant, behauptet Mordini. Stattdessen argumentiert er, dass ein intimer Bereich, der sowohl verborgen als auch zugriffsbeschränkt sein kann, notwendig ist, da wir psychologisch gesehen Individuen werden, indem wir entdecken, dass wir etwas vor anderen verbergen könnten.

7. Julian Assange erklärte: "Es gibt noch keine mörderische Antwort. Jacob Appelbaum (@ioerror) hat eine kluge Antwort und bittet Leute, die dies sagen, ihm ihr Telefon zu entsperren und ihre Hose herunterzuziehen. Meine Version davon heißt: "Nun, wenn Sie so langweilig sind, sollten wir nicht mit Ihnen sprechen und niemand anders", aber philosophisch lautet die wahre Antwort: Massenüberwachung ist ein Massenstrukturwandel. Wenn die Gesellschaft schlecht wird, geht es dich mitzunehmen, auch wenn du der langweiligste Mensch auf Erden bist. "

8. Ignacio Cofone, Rechtsprofessor, argumentiert, dass das Argument in seinen eigenen Begriffen falsch ist, weil Menschen, wenn sie relevante Informationen an andere weitergeben, auch irrelevante Informationen weitergeben. Diese irrelevanten Informationen verursachen Datenschutzkosten und können zu anderen Schäden wie Diskriminierung führen.

***.

# Alternative Methoden

Medien sollten weder online noch offline eingeschränkt werden. Wenn Leute das Video ohne DRM sehen wollten, werden sie immer einen Weg finden, dies zu tun. Jede Software kann geknackt werden.

[modifizierter Auszug aus Wikipedia] Valve-Präsident Gabe Newell hat erklärt, dass "die meisten DRM-Strategien einfach nur dumm sind", weil sie den Wert eines Spiels in den Augen des Verbrauchers nur verringern. Newell schlägt vor, dass das Ziel stattdessen darin bestehen sollte, "durch den Servicewert einen höheren Wert für die Kunden zu schaffen". Beachten Sie, dass Valve Steam betreibt, einen Dienst, der als Online-Shop für PC-Spiele dient, sowie einen Social-Networking-Dienst und eine DRM-Plattform

Dieser Punkt gilt nicht nur für Videospiele, sondern kann auf alles auf einem Computer angewendet werden. Dein Computer sollte nicht die vollständige Kontrolle über ein verrücktes Unternehmen haben, das schlechte künstliche Intelligenz verwendet, um seine Benutzer und ihre Arbeit (YouTube usw.) zu löschen, und eine so schlechte Bilanz hat. Ihr Computer sollte nicht eingeschränkt werden, da sich ein Unternehmen weigert, wie ein schlecht benommenes Kind zu teilen. Ihr Computer sollte Ihnen gehören,und niemand anderes. Sie sollten DRM insgesamt loswerden, da es sich nicht lohnt, die Kontrolle über Ihren Computer aufzugeben. Diese Unternehmen haben Hunderte von Milliarden Dollar. Wenn sie so etwas Dummes tun, sollten Sie dagegen protestieren. Sie können das Video sogar einfach an eine andere Stelle herunterladen und ansehen, da sie Geld verlieren sollten, wenn sie solche dummen Dinge tun. Urheberrechtsverletzung ist keine schlechte Sache. Leute, die sich Filme nicht leisten können, werden sie woanders herunterladen. Dies geschieht seit dem Beginn des globalen Internets und mit der Erfindung des VHS-Bandes. Es wirkt sich kaum auf ihre Einnahmen aus, da sie das Geld sowieso nicht bekommen könnten. DRM ist konstruktionsbedingt defekt.

***.

## Was Sie tun können, um zu helfen

Sie können gegen DRM protestieren. Es mag unbedeutend erscheinen, aber je mehr Leute dagegen sind, desto mehr wird dagegen unternommen.

Wenn Sie unter Linux arbeiten und Firefox verwenden, stellen Sie sicher, dass DRM nicht installiert ist (normalerweise nicht standardmäßig), und installieren Sie es nicht.

Wenn Sie unter Windows oder MacOS arbeiten, fällt es Ihnen möglicherweise viel schwerer, da DRM auf diesen Systemen standardmäßig installiert ist und möglicherweise automatisch neu installiert wird.

Vermeiden Sie die folgenden Websites:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Grundsätzlich sollte fast jeder Online-Video-Streaming-Dienst vermieden werden, da die meisten von ihnen DRM verwenden und Sie die Website nicht nutzen können, ohne Ihre Freiheit zu verlieren. Das ist es nicht wert. Senden Sie der [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) eine Nachricht und beenden Sie das Streaming dieser Shows.

Sie sollten auch alle Optionen "Kostenlos mit Anzeigen" auf den folgenden Websites vermeiden (da für diese Methode DRM erforderlich ist).

[YouTube] (https://www.youtube.com)

Sie können auch gegen DRM mit einer Nachricht in der README.md-Datei Ihres Projekts protestieren. Folgendes benutze ich:

`` `Abschlag

***.

## Softwarestatus

Alle meine Arbeiten sind frei von einigen Einschränkungen. DRM (** D ** igital ** R ** Einschränkungen ** M ** Management) ist in keinem meiner Werke vorhanden.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Dieser Aufkleber wird von der Free Software Foundation unterstützt. Ich habe nie vor, DRM in meine Arbeiten aufzunehmen.

Ich verwende die Abkürzung "Digital Restrictions Management" anstelle des bekannteren "Digital Rights Management", da die übliche Vorgehensweise falsch ist. Es gibt keine Rechte bei DRM. Die Schreibweise "Digital Restrictions Management" ist genauer und wird von [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) und der [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Dieser Abschnitt dient dazu, das Bewusstsein für die Probleme mit DRM zu schärfen und dagegen zu protestieren. DRM ist von Natur aus fehlerhaft und stellt eine große Bedrohung für alle Computerbenutzer und die Softwarefreiheit dar.

Bildnachweis: [defectivebydesign.org/drm-free/... lightboxes(https://www.defectivebydesign.org/drm-free/how-to-use-label]

***.

`` `

***.
## Andere Dinge zum Auschecken

[Defected by Design - Eine Kampagne der Free Software Foundation, die daran arbeitet, die DRM-Nutzung aufzudecken und zu beseitigen] (https://www.defectivebydesign.org/)

[Der Google-Friedhof (killbygoogle.com) - eine sortierte Liste der über 224 Produkte, die Google getötet hat] (https://killedbygoogle.com/)

> [GitHub-Link] (https://github.com/codyogden/killedbygoogle)

[Alphabet Worker Union - Die neue Gewerkschaft bei Google mit über 800 Mitgliedern] (https://alphabetworkersunion.org/people/our-union/)

Es gibt andere Alternativen, suchen Sie einfach nach ihnen.

***.

## Artikel Information

Dateityp: `Markdown (* .md)`

Dateiversion: `4 (Freitag, 23. April 2021 um 15.35 Uhr)`

Zeilenanzahl (einschließlich Leerzeilen und Compilerzeile): `354`

### Softwarestatus

Alle meine Arbeiten sind frei von Einschränkungen. DRM (** D ** igital ** R ** Einschränkungen ** M ** Management) ist in keinem meiner Werke vorhanden. Dieses Projekt enthält kein DRM, es handelt sich jedoch direkt um DRM.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Dieser Aufkleber wird von der Free Software Foundation unterstützt. Ich habe nie vor, DRM in meine Arbeiten aufzunehmen.

***.

### Sponsorinfo

! [SponsorButton.png] (SponsorButton.png) <- Dies ist nicht der offizielle Sponsor-Button, sondern ein Demo-Image. Klicken Sie nicht darauf, wenn Sie dieses Projekt sponsern möchten.

Sie können dieses Projekt sponsern, wenn Sie möchten, aber bitte geben Sie an, wofür Sie spenden möchten. [Siehe die Mittel, für die Sie hier spenden können] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Sie können andere Sponsoreninformationen [hier] anzeigen (https://github.com/seanpm2001/Sponsor-info/).

Versuch es! Der Sponsor-Button befindet sich direkt neben dem Watch / Unwatch-Button.

***.

## Dokumentenhistorie

Version 1 (Sonntag, 8. Februar 2021 um 16:41 Uhr)

> Änderungen:

> * Startete die Datei / den Artikel

> * Der Titelabschnitt wurde hinzugefügt

> * Ein Abschnitt zum Datenschutz wurde hinzugefügt

> * Ein Abschnitt über die Übersicht wurde hinzugefügt

> * Der Artikelinfo-Bereich wurde hinzugefügt

> * Referenziert auf das DRM-freie Symbol

> * Der Dateiversionsabschnitt wurde hinzugefügt

> * Der Abschnitt "Mangel an Freiheit" wurde hinzugefügt

> * Der wettbewerbswidrige Bereich wurde hinzugefügt

> * Der Abschnitt über alternative Methoden wurde hinzugefügt

> * Memo hinzugefügtVerwendungsabschnitt

> * Die anderen Dinge zum Auschecken wurden hinzugefügt

> * Index hinzugefügt

> * Die Fußzeile wurde hinzugefügt

> * Keine weiteren Änderungen in Version 1

Version 2 (Donnerstag, 8. April 2021 um 17:18 Uhr)

> Änderungen:

> * Der Titelbereich wurde aktualisiert

> * Der Index wurde aktualisiert

> * Informationen darüber hinzugefügt, was Sie tun können, um zu helfen

> * Der Sponsor-Info-Bereich wurde hinzugefügt

> * Der Abschnitt mit den Dateiinformationen wurde aktualisiert

> * Der Abschnitt zum Dateiversionsverlauf wurde aktualisiert

> * Keine weiteren Änderungen in Version 2

Version 3 (Donnerstag, 8. April 2021 um 17:27 Uhr)

> Änderungen:

> * Übersetzungslinks behoben

> * Der Index wurde aktualisiert

> * Ein doppelter Eintrag außerhalb des Themas im Abschnitt "Was können Sie tun, um zu helfen" wurde behoben

> * Der Abschnitt mit den Sponsoreninformationen wurde aktualisiert

> * Der Abschnitt mit den Dateiinformationen wurde aktualisiert

> * Der Abschnitt zum Dateiversionsverlauf wurde aktualisiert

> * Keine weiteren Änderungen in Version 3

Version 4 (Freitag, 23. April 2021 um 15:35 Uhr)

> Änderungen:

> * Die Liste der Sprachumschalter wurde aktualisiert

> * Der Abschnitt mit den Dateiinformationen wurde aktualisiert

> * Der Abschnitt zum Dateiversionsverlauf wurde aktualisiert

> * Keine weiteren Änderungen in Version 4

Version 5 (in Kürze erhältlich)

> Änderungen:

> * Bald erhältlich

> * Keine weiteren Änderungen in Version 5

Version 6 (in Kürze erhältlich)

> Änderungen:

> * Bald erhältlich

> * Keine weiteren Änderungen in Version 6

Version 7 (in Kürze erhältlich)

> Änderungen:

> * Bald erhältlich

> * Keine weiteren Änderungen in Version 7

Version 8 (in Kürze erhältlich)

> Änderungen:

> * Bald erhältlich

> * Keine weiteren Änderungen in Version 8

***.

## Fusszeile

Sie haben das Ende dieser Datei erreicht!

##### EOF

***.
