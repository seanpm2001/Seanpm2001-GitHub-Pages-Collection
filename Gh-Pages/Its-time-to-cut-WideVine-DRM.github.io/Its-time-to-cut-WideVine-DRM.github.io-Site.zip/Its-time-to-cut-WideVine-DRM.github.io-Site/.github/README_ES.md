***

##### Cima

_ Lee este artículo en otro idioma: _

** El idioma actual es: ** `Inglés (EE. UU.)` _ (Es posible que sea necesario corregir las traducciones para corregir el inglés y reemplazar el idioma correcto) _

_🌐 Lista de idiomas_

** Ordenado por: ** `A-Z`

[Opciones de clasificación no disponibles] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikáans | [sq Shqiptare] (/. github / README_SQ.md) Albanés | [am አማርኛ] (/. github / README_AM.md) Amárico | [ar عربى] (/.github/README_AR.md) Árabe | [hy հայերեն] (/. github / README_HY.md) Armenio | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaiyano | [eu Euskara] (/. github /README_EU.md) Vasco | [be Беларуская] (/. Github / README_BE.md) Bielorruso | [bn বাংলা] (/. Github / README_BN.md) Bengalí | [bs Bosanski] (/. Github / README_BS.md) Bosnio | [bg български] (/. Github / README_BG.md) Búlgaro | [ca Català] (/. Github / README_CA.md) Catalán | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chino (simplificado) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chino (tradicional) | [co Corsu] (/. Github / README_CO.md) Corso | [hr Hrvatski] (/. Github / README_HR.md) Croata | [cs čeština] (/. Github / README_CS .md) checo | [dansk] (README_DA.md) danés | [nl Nederlands] (/. github / README_ NL.md) holandés | [** en-us inglés **] (/. github / README.md) Inglés | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) estonio | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) finlandés | [fr français] (/. github / README_FR.md) francés | [fy Frysk] (/. github / README_FY.md) Frisón | [gl Galego] (/. github / README_GL.md) Gallego | [ka ქართველი] (/. github / README_KA) georgiano | [de Deutsch] (/. github / README_DE.md) Alemán | [el Ελληνικά] (/. github / README_EL.md) Griego | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Criollo haitiano | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiano | [he עִברִית] (/. github / README_HE.md) Hebreo | [hola हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Húngaro | [es Íslenska] (/. github / README_IS.md) Islandés | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) islandés | [ga Gaeilge] (/. github / README_GA.md) Irlandés | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japonés | [jw Wong jawa] (/. github / README_JW.md) javanés | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazajo | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Coreano (Sur) | [ko-north 문화어] (README_KO_NORTH.md) Coreano (Norte) (NO ESTÁ TRADUCIDO) | [ku Kurdî] (/. github / README_KU.md) Kurdo (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirguistán | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latín | [lt Lietuvis] (/. github / README_LT.md) Lituano | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgués | [mk Македонски] (/. github / README_MK.md) macedonio | [mg malgache] (/. github / README_MG.md) malgache | [ms Bahasa Melayu] (/. github / README_MS.md) Malayo | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltés | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongol | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Birmano) | [ne नेपाली] (/. github / README_NE.md) Nepalí | [no norsk] (/. github / README_NO.md) Noruego | [o ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persa [pl polski] (/. github / README_PL.md) Polaco | [pt português] (/. github / README_PT.md) Portugués | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | No hay idiomas disponibles que comiencen con la letra Q | [ro Română] (/. github / README_RO.md) Rumano | [ru русский] (/. github / README_RU.md) Ruso | [sm Faasamoa] (/. github / README_SM.md) Samoano | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Gaélico escocés | [sr Српски] (/. github / README_SR.md) Serbio | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Eslovaco | [sl Slovenščina] (/. github / README_SL.md) esloveno | [Soomaali] (/. github / README_SO.md) Somalí | [[es en español] (/. github / README_ES.md) Español | [su Sundanis] (/. github / README_SU.md) Sundanés | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Sueco | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Tailandés | [tr Türk] (/. github /README_TR.md) Turco | [tk Türkmenler] (/. github / README_TK.md) Turcomano | [uk Український] (/. github / README_UK.md) Ucraniano | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uigur | [uz O'zbek] (/. github / README_UZ.md) Uzbeko | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamita | [cy Cymraeg] (/. github / README_CY.md) Galés | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Disponible en 110 idiomas (108 sin contar el inglés y el norcoreano, ya que el norcoreano aún no se ha traducido [Leer más aquí] (/ OldVersions / Korean (North ) /README.md))

Las traducciones en otros idiomas además del inglés se traducen automáticamente y aún no son precisas. Aún no se han corregido errores hasta el 5 de febrero de 2021. Informe los errores de traducción [aquí] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) asegúrese de hacer una copia de seguridad de su corrección con fuentes y guíeme, ya que no conozco bien otros idiomas además del inglés (planeo conseguir un traductor eventualmente) por favor cite [wiktionary] (https://en.wiktionary.org) y otras fuentes en su informe. De no hacerlo, se rechazará la publicación de la corrección.

Nota: debido a las limitaciones con la interpretación de rebajas de GitHub (y casi todas las demás interpretaciones de rebajas basadas en web), hacer clic en estos enlaces lo redireccionará a un archivo separado en una página separada que no es mi página de perfil de GitHub. Se le redirigirá al [repositorio seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), donde está alojado el archivo README.

Las traducciones se realizan con Google Translate debido a la compatibilidad limitada o nula para los idiomas que necesito en otros servicios de traducción como DeepL y Bing Translate (bastante irónico para una campaña anti-Google). Estoy trabajando para encontrar una alternativa. Por alguna razón, el formato (enlaces, separadores, negrita, cursiva, etc.) está desordenado en varias traducciones. Es tedioso de solucionar, y no sé cómo solucionar estos problemas en idiomas con caracteres no latinos, y en idiomas de derecha a izquierda (como el árabe) se necesita ayuda adicional para solucionar estos problemas.

Debido a problemas de mantenimiento, muchas traducciones están desactualizadas y utilizan una versión desactualizada de este archivo de artículo "README". Se necesita un traductor. Además, a partir del 23 de abril de 2021, me llevará un tiempo conseguir que funcionen todos los enlaces nuevos.

***

# Es hora de cortar Widevine

Este es un artículo sobre por qué debería dejar de usar Google WideVine (DRM) y desinstalarlo. DRM debe eliminarse. Este artículo lo ayudará a tomar su decisión (si aún no lo ha hecho). WideVine es altamente anticompetitivo y extremadamente restrictivo, y está destruyendo la libertad de los videos en Internet.

Cortemos el WideVine y adoptemos una Internet abierta.

***

# Índice

[00.0 - Arriba] (# arriba)

> [00.1 - Leer este artículo en otro idioma]

> [00.2 - Título] (# Es-hora-de-cortar-Widevine)

> [00.3 - Índice] (# índice)

[01.0 - Descripción general] (# descripción general)

[02.0 - Anticompetitivo] (# Anticompetitivo)

[03.0 - Falta de libertad] (# Falta de libertad)

[04.0 - Uso de memoria] (# uso de memoria)

[05.0 - Privacidad] (# Privacidad)

[06.0 - Métodos alternativos] (# métodos-alternativos)

[07.0 - Qué puede hacer para ayudar] (# What-you-can-do-do-help)

[08.0 - Otras cosas para verificar] (# Otras-cosas-para-verificar)

[09.0 - Información del artículo] (# Información del artículo)

> [09.0.1 - Estado del software] (# estado del software)

> [09.0.2 - Información del patrocinador] (# Información del patrocinador)

[10.0 - Historial de archivos] (# Historial de archivos)

[11.0 - Pie de página] (# pie de página)

> [11.9 - EOF] (# EOF)

***

## Descripción general

Para obtener más información sobre por qué DRM es un problema, [haga clic aquí] (https://www.defectivebydesign.org/)

***

## Anti-competitivo

WideVine es un DRM que debe tener licencia para usarse con un navegador. Google es extremadamente lento en revisar y aceptar a las personas y, a menudo, se niega a usarlo en sus productos sin ningún razonamiento. [Fuente 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Fuente 2 (el hilo de correo electrónico que se prolongó durante más de 4 meses y resultó en nada más que decepción)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google ha hecho que sea mucho más difícil para navegadores como Brave o Firefox competir con su impulso de esta pieza de DRM.

***

## Falta de libertad

WideVine se utiliza para evitar que los usuarios interactúen con videos en sitios web. Es una forma de administración de restricciones digitales que le impide descargar el video, ver el video sin conexión o incluso tomar una captura de pantalla. Es un software propietario y, debido a sus problemas de privacidad, no se instala de forma predeterminada en la mayoría de las distribuciones de Linux. Está limitando las libertades de la web debido a su uso por películas de Netflix, Disney y YouTube. Su acceso al contenido puede ser cancelado en cualquier momento sin ningún motivo.

***

## Uso de memoria

WideVine tiene mala memoria. En comparación con la visualización normal de un video sin DRM, WideVine utilizará grandes cantidades de CPU y RAM. Es malo en bavida útil y no ofrece ningún beneficio de la reproducción de vídeo HTML5 estándar.

***

## Privacidad

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (programa_vigilancia)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Crítica) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nada-que-ocultar-argumento-no-tiene-nada-que-decir /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- datos-sobre-usted-puede-encontrar-y-eliminar-ahora /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -y) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d](https://www.reuters.com/article/us-alphabet- google-privacy-lawuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- reclamaciones-en-nombre-de-5-millones-de-usuarios-de-iphone) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / information-technolo gy / 2014/01 / what-google-can-really-do-with-nest-or-really-nests-data /) [i] (https://www.cbsnews.com/news/google-education-spies -on-recopila-datos-sobre-millones-de-niños-alega-demanda-fiscal-general-de-nuevo-méxico /) [v] (https://www.nationalreview.com/2018/04/the-student- data-mining-scandal-under-our-narices /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Podría seguir y seguir con evidencia de esto , pero tomó mucho tiempo encontrar y revisar todos estos artículos)

La privacidad no es una cosa con WideVine. El software patentado está diseñado para que no pueda ver lo que está sucediendo en absoluto. Con la historia de Google, es muy probable queWideVine es una pieza adicional de software que lo está espiando, leyendo sus documentos y otras cosas malas.

Si crees que no tienes nada que ocultar, ** estás absolutamente equivocado **. Este argumento ha sido desacreditado muchas veces:

[A través de Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden comentó: "Argumentar que no te importa el derecho a la privacidad porque no tienes nada que ocultar no es diferente a decir que no te importa la libertad de expresión porque no tienes nada que decir". Cuando dices: ' No tengo nada que ocultar ', estás diciendo:' No me importa esto bien '. Estás diciendo:' No tengo este derecho, porque he llegado al punto en el que tengo que justificar "La forma en que funcionan los derechos, el gobierno tiene que justificar su intromisión en sus derechos".

2. Daniel J. Solove declaró en un artículo para The Chronicle of Higher Education que se opone al argumento; Afirmó que un gobierno puede filtrar información sobre una persona y causarle daño, o usar información sobre una persona para denegar el acceso a los servicios, incluso si una persona no cometió un delito, y que un gobierno puede causar daño a su persona. la vida cometiendo errores. Solove escribió: "Cuando se involucra directamente, el argumento de nada que ocultar puede atrapar, ya que obliga al debate a centrarse en su comprensión limitada de la privacidad. Pero cuando se enfrenta a la pluralidad de problemas de privacidad implicados por la recopilación y el uso de datos gubernamentales más allá de la vigilancia y revelación, el argumento de nada que ocultar, al final, no tiene nada que decir ".

3. Adam D. Moore, autor de Privacy Rights: Moral and Legal Foundations, argumentó que "es la opinión de que los derechos son resistentes al costo / beneficio o argumentos de tipo consecuencialista. Aquí estamos rechazando la opinión de que los intereses de privacidad son el tipo de de cosas que se pueden canjear por seguridad ". También afirmó que la vigilancia puede afectar de manera desproporcionada a ciertos grupos de la sociedad en función de la apariencia, la etnia, la sexualidad y la religión.

4. Bruce Schneier, un experto en seguridad informática y criptógrafo, expresó su oposición, citando la declaración del cardenal Richelieu "Si uno me diera seis líneas escritas por la mano del hombre más honesto, encontraría algo en ellas para colgarlo", refiriéndose a cómo un gobierno estatal puede encontrar aspectos en la vida de una persona para enjuiciar o chantajear a esa persona. Schneier también argumentó "Demasiados caracterizan erróneamente el debate como 'seguridad versus privacidad'. La verdadera elección es libertad versus control ".

5. Harvey A. Silverglate estimó que la persona común, en promedio, comete sin saberlo tres delitos graves al día en los Estados Unidos.

6. Emilio Mordini, filósofo y psicoanalista, argumentó que el argumento de "nada que ocultar" es intrínsecamente paradójico. La gente no necesita tener "algo que esconder" para poder esconder "algo". Lo que está oculto no es necesariamente relevante, afirma Mordini. En cambio, argumenta que es necesario un área íntima que puede estar oculta y con acceso restringido, ya que, psicológicamente hablando, nos convertimos en individuos a través del descubrimiento de que podemos ocultar algo a los demás.

7. Julian Assange declaró: "Todavía no hay una respuesta asesina. Jacob Appelbaum (@ioerror) tiene una respuesta inteligente, pidiendo a las personas que dicen esto que luego le entreguen el teléfono desbloqueado y se bajen los pantalones. Mi versión de eso es decir, "Bueno, si eres tan aburrido, entonces no deberíamos estar hablando contigo, ni nadie más", pero filosóficamente, la respuesta real es esta: la vigilancia masiva es un cambio estructural masivo. Cuando la sociedad va mal, va para llevarte con él, incluso si eres la persona más blanda del mundo ".

8. Ignacio Cofone, profesor de derecho, sostiene que el argumento es erróneo en sus propios términos porque, siempre que las personas revelan información relevante a otros, también revelan información irrelevante. Esta información irrelevante tiene costos de privacidad y puede provocar otros daños, como la discriminación.

***

# Metodos alternativos

Los medios no deben estar restringidos, en línea o fuera de línea. Si las personas quisieran ver el video sin DRM, siempre encontrarán la manera de hacerlo. Cada pieza de software se puede descifrar.

[extracto modificado de Wikipedia] El presidente de Valve, Gabe Newell, ha declarado que "la mayoría de las estrategias de DRM son simplemente tontas" porque solo disminuyen el valor de un juego a los ojos del consumidor. Newell sugiere que el objetivo debería ser "[crear] un mayor valor para los clientes a través del valor del servicio". Tenga en cuenta que Valve opera Steam, un servicio que sirve como una tienda en línea para juegos de PC, así como un servicio de redes sociales y una plataforma DRM.

Este punto no es válido solo para videojuegos, se puede aplicar a cualquier cosa en una computadora. Tu computadora no debería tener el control total de una empresa loca que usa Inteligencia Artificial mala para eliminar a sus usuarios y su trabajo (YouTube, etc.) y tiene un historial tan malo. Su computadora no debe estar restringida porque una empresa se niega a compartir como un niño que se porta mal. Tu computadora debe ser tuya,y nadie mas. Debe deshacerse de DRM por completo, ya que no vale la pena ceder el control de su computadora por el contenido. Estas empresas tienen cientos de miles de millones de dólares. Si hacen algo estúpido como esto, debes protestar. Incluso podría descargar el video en otro lugar y verlo, ya que deberían estar perdiendo dinero por hacer cosas estúpidas como esta. La infracción de derechos de autor no es algo malo. Las personas que no pueden pagar las películas las descargarán en otro lugar, ha estado sucediendo desde el inicio de Internet global y con la invención de la cinta VHS. Apenas afecta sus ingresos, ya que de todos modos no podrían obtener ese dinero. DRM está defectuoso por diseño.

***

## Qué puedes hacer para ayudar

Puedes protestar contra DRM. Puede parecer insignificante, pero cuanta más gente se oponga, más se hará al respecto.

Si está en Linux y usa Firefox, asegúrese de que DRM no esté instalado (normalmente no lo es por defecto) y no se moleste en instalarlo.

Si está en Windows o MacOS, es posible que tenga más dificultades, ya que DRM se instala de forma predeterminada en estos sistemas y es posible que se reinstale automáticamente.

Intente evitar los siguientes sitios:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Básicamente, se debe evitar casi cualquier servicio de transmisión de video en línea, ya que la mayoría de ellos usa DRM y no puede usar el sitio sin perder su libertad. No vale la pena. Envíe un mensaje a la [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) y deje de transmitir estos programas.

También debe evitar cualquier opción "gratis con anuncios" en los siguientes sitios (ya que este método requiere DRM)

[YouTube] (https://www.youtube.com)

También puede protestar contra DRM con un mensaje en el archivo `README.md` de sus proyectos. Esto es lo que uso:

`` rebaja

***

## Estado del software

Todos mis trabajos están libres de algunas restricciones. DRM (** D ** igital ** R ** estrictions ** M ** anagement) no está presente en ninguna de mis obras.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Esta pegatina cuenta con el apoyo de la Free Software Foundation. Nunca pretendo incluir DRM en mis trabajos.

Estoy usando la abreviatura "Administración de restricciones digitales" en lugar de la más conocida "Administración de derechos digitales", ya que la forma común de abordarla es falsa, no hay derechos con DRM. La ortografía "Digital Restrictions Management" es más precisa y es compatible con [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) y la [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Esta sección se utiliza para crear conciencia sobre los problemas con la DRM y también para protestar. DRM tiene un diseño defectuoso y es una gran amenaza para todos los usuarios de computadoras y la libertad de software.

Crédito de la imagen: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

''

***
## Otras cosas para revisar

[Defectuoso por diseño: una campaña de la Free Software Foundation que está trabajando para exponer y eliminar el uso de DRM] (https://www.defectivebydesign.org/)

[El cementerio de Google (killbygoogle.com): una lista ordenada de los más de 224 productos que Google ha matado] (https://killedbygoogle.com/)

> [Enlace de GitHub] (https://github.com/codyogden/killedbygoogle)

[Sindicato de trabajadores del alfabeto: el nuevo sindicato de trabajadores de Google con más de 800 miembros] (https://alphabetworkersunion.org/people/our-union/)

Hay otras alternativas, solo búsquelas.

***

## Información del artículo

Tipo de archivo: `Markdown (* .md)`

Versión del archivo: `4 (viernes 23 de abril de 2021 a las 3:35 pm)`

Recuento de líneas (incluidas las líneas en blanco y la línea del compilador): `354`

### Estado del software

Todos mis trabajos están libres de restricciones. DRM (** D ** igital ** R ** estrictions ** M ** anagement) no está presente en ninguna de mis obras. Este proyecto no contiene ningún DRM, pero está hablando de DRM directamente.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Esta pegatina cuenta con el apoyo de la Free Software Foundation. Nunca pretendo incluir DRM en mis trabajos.

***

### Información del patrocinador

! [SponsorButton.png] (SponsorButton.png) <- Este no es el botón oficial del patrocinador, es una imagen de demostración. No haga clic en él si desea patrocinar este proyecto.

Puede patrocinar este proyecto si lo desea, pero especifique a qué desea donar. [Vea los fondos a los que puede donar aquí] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Puede ver otra información del patrocinador [aquí] (https://github.com/seanpm2001/Sponsor-info/)

¡Pruébalo! El botón de patrocinador está justo al lado del botón de ver / dejar de mirar.

***

## Historial del archivo

Versión 1 (domingo 8 de febrero de 2021 a las 4:41 pm)

> Cambios:

> * Comenzó el archivo / artículo

> * Añadida la sección de título

> * Se agregó una sección sobre privacidad.

> * Se agregó una sección sobre la descripción general.

> * Añadida la sección de información del artículo

> * Se hizo referencia al ícono DRM Free

> * Añadida la sección de historial de archivos

> * Añadida la sección Falta de libertad

> * Añadida la sección Anticompetitiva

> * Añadida la sección de métodos alternativos

> * Añadida la notasección de uso de ry

> * Se agregaron las otras cosas para revisar la sección

> * Agregado el índice

> * Se agregó el pie de página.

> * No hay otros cambios en la versión 1

Versión 2 (jueves 8 de abril de 2021 a las 5:18 pm)

> Cambios:

> * Se actualizó la sección de título

> * Actualizado el índice

> * Información agregada sobre lo que puede hacer para ayudar

> * Añadida la sección de información del patrocinador

> * Se actualizó la sección de información del archivo

> * Se actualizó la sección de historial de archivos

> * No hay otros cambios en la versión 2

Versión 3 (jueves 8 de abril de 2021 a las 5:27 pm)

> Cambios:

> * Enlaces de traducción fijos

> * Actualizado el índice

> * Se corrigió una entrada duplicada y fuera de tema en la sección "Qué puedes hacer para ayudar".

> * Se actualizó la sección de información del patrocinador

> * Se actualizó la sección de información del archivo

> * Se actualizó la sección de historial de archivos

> * No hay otros cambios en la versión 3

Versión 4 (viernes 23 de abril de 2021 a las 3:35 pm)

> Cambios:

> * Actualización de la lista de cambio de idioma

> * Se actualizó la sección de información del archivo

> * Se actualizó la sección de historial de archivos

> * No hay otros cambios en la versión 4

Versión 5 (próximamente)

> Cambios:

> * Próximamente

> * No hay otros cambios en la versión 5

Versión 6 (próximamente)

> Cambios:

> * Próximamente

> * No hay otros cambios en la versión 6

Versión 7 (próximamente)

> Cambios:

> * Próximamente

> * No hay otros cambios en la versión 7

Versión 8 (próximamente)

> Cambios:

> * Próximamente

> * No hay otros cambios en la versión 8

***

## Pie de página

¡Ha llegado al final de este archivo!

##### EOF

***
