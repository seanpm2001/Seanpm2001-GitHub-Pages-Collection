***

##### Top

_ Darllenwch yr erthygl hon mewn iaith wahanol: _

** Yr iaith gyfredol yw: ** `Saesneg (UD)` _ (efallai y bydd angen cywiro cyfieithiadau i drwsio'r Saesneg yn lle'r iaith gywir) _

_🌐 Rhestr o ieithoedd_

** Trefnwyd gan: ** `A-Z`

[Nid yw'r opsiynau didoli ar gael] (https://github.com/Degoogle-your-Life)

([af Affricanaidd] (/. github / README_AF.md) Affricaneg | [sq Shqiptare] (/. github / README_SQ.md) Albaneg | [am አማርኛ] (/. github / README_AM.md) Amhareg | [ar عربى] (/.github/README_AR.md) Arabeg | [hy հայերեն] (/. github / README_HY.md) Armeneg | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijani | [eu Euskara] (/. github /README_EU.md) Basg | Bosnia | [bg български] (/. Github / README_BG.md) Bwlgareg | [ca Català] (/. Github / README_CA.md) Catalwnia ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Tsieineaidd (Syml) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Tsieineaidd (Traddodiadol) | [co Corsu] (/. Github / README_CO.md) Corsican | [hr Hrvatski] (/. Github / README_HR.md) Croateg | [cs čeština] (/. Github / README_CS .md) Tsiec | [da dansk] (README_DA.md) Daneg | [nl Nederlands] (/. github / README_ NL.md) Iseldireg | [** en-us Saesneg **] (/. github / README.md) Saesneg | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estoneg | [tl Pilipino] (/. github / README_TL.md) Ffilipineg | [fi Suomalainen] (/. github / README_FI.md) Ffinneg | [fr français] (/. github / README_FR.md) Ffrangeg | [fy Frysk] (/. github / README_FY.md) Ffriseg | [gl Galego] (/. github / README_GL.md) Galisia | [ka ქართველი] (/. github / README_KA) Sioraidd | [de Deutsch] (/. github / README_DE.md) Almaeneg | [el Ελληνικά] (/. github / README_EL.md) Groeg | [gu ગુજરાતી] (/. github / README_GU.md) Gwjarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitian Creole | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [ef עִברִית] (/. github / README_HE.md) Hebraeg | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hwngari | [yw Íslenska] (/. github / README_IS.md) Gwlad yr Iâ | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Gwlad yr Iâ | [ga Gaeilge] (/. github / README_GA.md) Gwyddeleg | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japaneaidd | [jw Wong jawa] (/. github / README_JW.md) Javanese | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakh | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-de 韓國 語] (/. github / README_KO_SOUTH.md) Corea (De) | [ko-gogledd 문화어] (README_KO_NORTH.md) Corea (Gogledd) (NID YW'N CYFIEITHU) | [ku Kurdî] (/. github / README_KU.md) Cwrdeg (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Cirgise | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Lladin | [lt Lietuvis] (/. github / README_LT.md) Lithwaneg | [lb Lëtzebuergesch] (/. github / README_LB.md) Lwcsembwrg | [mk Македонски] (/. github / README_MK.md) Macedoneg | [mg Malagasy] (/. github / README_MG.md) Malagasy | [ms Bahasa Melayu] (/. github / README_MS.md) Maleieg | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Malteg | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongoleg | [fy မြန်မာ] (/. github / README_MY.md) Myanmar (Byrmaneg) | [ne नेपाली] (/. github / README_NE.md) Nepali | [dim norsk] (/. github / README_NO.md) Norwyeg | [neu ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Perseg [pl polski] (/. github / README_PL.md) Pwyleg | [pt português] (/. github / README_PT.md) Portiwgaleg | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Nid oes unrhyw ieithoedd ar gael sy'n dechrau gyda'r llythyren Q | [ro Română] (/. github / README_RO.md) Rwmaneg | [ru русский] (/. github / README_RU.md) Rwseg | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Gaeleg yr Alban | [sr Српски] (/. github / README_SR.md) Serbeg | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slofacia | [sl Slovenščina] (/. github / README_SL.md) Slofenia | [felly Soomaali] (/. github / README_SO.md) Somalïaidd | [[es en español] (/. github / README_ES.md) Sbaeneg | [su Sundanis] (/. github / README_SU.md) Sundaneg | [sw Kiswlarus] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Sweden | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github /README_TR.md) Twrceg | [tk Türkmenler] (/. github / README_TK.md) Tyrcmeneg | [uk Український] (/. github / README_UK.md) Wcreineg | [ur اردو] (/. github / README_UR.md) Wrdw | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Wsbeceg | [vi Tiếng Việt] (/. github / README_VI.md) Fietnam | [cy Cymraeg] (/. github / README_CY.md) Cymraeg | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Iddeweg | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Ar gael mewn 110 o ieithoedd (108 wrth beidio â chyfrif Saesneg a Gogledd Corea, gan nad yw Gogledd Corea wedi'i gyfieithu eto [Darllenwch amdano yma] (/ OldVersions / Korean (Gogledd) ) /README.md))

Mae cyfieithiadau mewn ieithoedd heblaw Saesneg yn cael eu cyfieithu â pheiriant ac nid ydyn nhw'n gywir eto. Nid oes unrhyw wallau wedi'u gosod eto ar 5 Chwefror 2021. Rhowch wybod am wallau cyfieithu [yma] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) gwnewch yn siŵr eich bod yn gwneud copi wrth gefn o'ch cywiriad gyda ffynonellau a fy arwain, gan nad wyf yn gwybod ieithoedd heblaw Saesneg yn dda (rwy'n bwriadu cael cyfieithydd yn y pen draw) dyfynnwch [wiktionary] (https://en.wiktionary.org) a ffynonellau eraill yn eich adroddiad. Bydd methu â gwneud hynny yn arwain at gyhoeddi gwrthod y cywiriad.

Sylwch: oherwydd cyfyngiadau gyda dehongliad GitHub o markdown (a bron pob dehongliad arall ar y we o markdown) bydd clicio ar y dolenni hyn yn eich ailgyfeirio i ffeil ar wahân ar dudalen ar wahân nad fy nhudalen proffil GitHub. Fe'ch ailgyfeirir i ystorfa [seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), lle cynhelir y README.

Gwneir cyfieithiadau gyda Google Translate oherwydd cefnogaeth gyfyngedig neu ddim cefnogaeth i'r ieithoedd sydd eu hangen arnaf mewn gwasanaethau cyfieithu eraill fel DeepL a Bing Translate (eironig eithaf ar gyfer ymgyrch gwrth-Google) Rwy'n gweithio ar ddod o hyd i ddewis arall. Am ryw reswm, mae'r fformatio (dolenni, rhanwyr, beiddgar, italig, ac ati) yn cael ei gyboli mewn amryw gyfieithiadau. Mae'n ddiflas trwsio, ac nid wyf yn gwybod sut i ddatrys y materion hyn mewn ieithoedd â chymeriadau nad ydynt yn Lladin, ac mae angen cymorth ychwanegol ar yr iaith dde i'r chwith (fel Arabeg) i ddatrys y materion hyn.

Oherwydd materion cynnal a chadw, mae llawer o gyfieithiadau wedi dyddio ac yn defnyddio fersiwn hen ffasiwn o'r ffeil erthygl hon 'README`. Mae angen cyfieithydd. Hefyd, o Ebrill 23ain 2021, bydd yn cymryd ychydig o amser i mi gael yr holl gysylltiadau newydd i weithio.

***

# Mae'n bryd torri Widevine

Dyma erthygl ar pam y dylech roi'r gorau i ddefnyddio Google WideVine (DRM) a'i ddadosod. Mae angen cael gwared ar DRM. Bydd yr erthygl hon yn eich helpu i wneud eich dewis (os nad ydych chi eisoes) mae WideVine yn hynod wrth-gystadleuol, ac yn hynod gyfyngol, ac mae'n dinistrio rhyddid fideos ar y Rhyngrwyd.

Gadewch i ni dorri'r WideVine a chofleidio Rhyngrwyd agored.

***

# Mynegai

[00.0 - Uchaf] (# Uchaf)

> [00.1 - Darllenwch yr erthygl hon mewn iaith wahanol]

> [00.2 - Teitl] (# It-is-time-to-cut-Widevine)

> [00.3 - Mynegai] (# Mynegai)

[01.0 - Trosolwg] (# Trosolwg)

[02.0 - Gwrth-gystadleuol] (# Gwrth-gystadleuol)

[03.0 - Diffyg rhyddid] (# Diffyg rhyddid)

[04.0 - Defnydd cof] (# Cof-ddefnydd)

[05.0 - Preifatrwydd] (# Preifatrwydd)

[06.0 - Dulliau amgen] (# Dulliau amgen)

[07.0 - Beth allwch chi ei wneud i helpu] (# Beth-allwch-ei-wneud-i-helpu)

[08.0 - Pethau eraill i edrych arnyn nhw] (# Other-things-to-check-out)

[09.0 - Gwybodaeth erthygl] (# Erthygl-wybodaeth)

> [09.0.1 - Statws meddalwedd] (# Statws meddalwedd)

> [09.0.2 - Gwybodaeth Noddwr] (# Noddwr-wybodaeth)

[10.0 - Hanes ffeiliau] (# Hanes ffeiliau)

[11.0 - Troedyn] (# Troedyn)

> [11.9 - EOF] (# EOF)

***

## Trosolwg

Am wybodaeth arall ynghylch pam mae DRM yn broblem, [cliciwch yma] (https://www.defectivebydesign.org/)

***

## Gwrth-gystadleuol

Mae WideVine yn DRM y mae'n rhaid ei drwyddedu i'w ddefnyddio gyda porwr. Mae Google yn hynod araf yn adolygu a derbyn pobl, ac yn aml mae'n gwrthod pobl i'w ddefnyddio yn eu cynhyrchion heb unrhyw resymu. [Ffynhonnell 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Ffynhonnell 2 (yr edefyn e-bost a aeth ymlaen am dros 4 mis ac a arweiniodd at ddim byd ond siom)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Mae Google wedi ei gwneud hi'n llawer anoddach i borwyr fel Brave neu Firefox gystadlu â'i wthio i'r darn hwn o DRM.

***

## Diffyg rhyddid

Defnyddir WideVine i atal defnyddwyr rhag rhyngweithio â fideo ar wefannau. Mae'n fath o reoliadau cyfyngiadau digidol sy'n eich atal rhag lawrlwytho'r fideo, gwylio'r fideo all-lein, neu hyd yn oed dynnu llun. Meddalwedd perchnogol ydyw ac oherwydd ei broblemau gyda phreifatrwydd, nid yw wedi'i osod yn ddiofyn ar y mwyafrif o ddosbarthiadau Linux. Mae'n cyfyngu ar ryddid y we oherwydd ei ddefnydd gan Netflix, Disney, a ffilmiau YouTube. Gellir cymryd eich mynediad i'r cynnwys ar unrhyw adeg am ddim rheswm.

***

## Defnydd cof

Mae WideVine yn ddrwg ar y cof. O'i gymharu â gwylio fideo heb DRM fel rheol, bydd WideVine yn defnyddio llawer iawn o CPU a RAM. Mae'n ddrwg ar babywyd ttery, ac nid yw'n rhoi unrhyw fuddion o chwarae fideo safonol HTML5.

***

## Preifatrwydd

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (gwyliadwriaeth_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / preifatrwydd all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)05s400(https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / why-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Beirniadaeth) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / nothing-to-hide-argument-has-nothing-to-say /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-about-you-you-can-find-and-delete-it-now /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -a) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)05d400(https://www.reuters.com/article/us-alphabet- google-privacy-lawsuit-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/ uair-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)05o400(https://en.wikipedia.org/wiki/2018_Google_data_breach)05m400(https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technoleg / google-ewrop-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- hawliadau-ar ran-5-miliwn-iphone-ddefnyddwyr) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)05e400(https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / gwybodaeth-technolo gy / 2014/01 / beth-google-can-really-do-with-nest-or-really-nests-data /) [i] (https://www.cbsnews.com/news/google-education-spies -on-collects-data-on-million-of-kids-alleges-lawsuit-new-mexico-atwrnai-general /) [v] (https://www.nationalreview.com/2018/04/the-student- data-mwyngloddio-sgandal-under-our-noses /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)05y400(https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (gallwn fynd ymlaen ac ymlaen gyda thystiolaeth o hyn , ond cymerodd amser hir i ddarganfod a mynd trwy'r holl erthyglau hyn)

Nid yw preifatrwydd yn beth gyda WideVine. Mae meddalwedd perchnogol wedi'i ddylunio fel na allwch weld beth sy'n digwydd o gwbl. Gyda hanes Googles, mae'n debygol iawn hynnyMae WideVine yn ddarn ychwanegol o feddalwedd sy'n ysbïo arnoch chi, yn darllen eich dogfennau, a phethau drwg eraill.

Os credwch nad oes gennych unrhyw beth i'w guddio, ** rydych yn hollol anghywir **. Datgelwyd y ddadl hon lawer gwaith drosodd:

[Trwy Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Dywedodd Edward Snowden "Nid yw dadlau nad ydych yn poeni am yr hawl i breifatrwydd oherwydd nad oes gennych unrhyw beth i'w guddio yn ddim gwahanol na dweud nad ydych yn poeni am leferydd rhad ac am ddim oherwydd nad oes gennych unrhyw beth i'w ddweud." Pan ddywedwch, ' Nid oes gennyf unrhyw beth i'w guddio, 'rydych chi'n ei ddweud,' Nid wyf yn poeni am hyn yn iawn. 'Rydych chi'n dweud,' Nid oes gen i hyn yn iawn, oherwydd rydw i wedi cyrraedd y pwynt lle mae'n rhaid i mi gyfiawnhau it. 'Y ffordd y mae hawliau'n gweithio, mae'n rhaid i'r llywodraeth gyfiawnhau ei ymyrraeth â'ch hawliau. "

2. Nododd Daniel J. Solove mewn erthygl ar gyfer The Chronicle of Higher Education ei fod yn gwrthwynebu'r ddadl; dywedodd y gall llywodraeth ollwng gwybodaeth am berson ac achosi niwed i'r unigolyn hwnnw, neu ddefnyddio gwybodaeth am berson i wrthod mynediad i wasanaethau hyd yn oed os na wnaeth person gymryd rhan mewn camwedd mewn gwirionedd, ac y gall llywodraeth achosi niwed i'w bersonol. bywyd trwy wneud gwallau. Ysgrifennodd Solove "Wrth ymgysylltu'n uniongyrchol, gall y ddadl dim byd i'w chuddio, oherwydd mae'n gorfodi'r ddadl i ganolbwyntio ar ei ddealltwriaeth gul o breifatrwydd. Ond wrth wynebu lluosogrwydd problemau preifatrwydd sy'n gysylltiedig â chasglu a defnyddio data'r llywodraeth y tu hwnt i wyliadwriaeth a datgeliad, nid oes gan y ddadl dim i'w guddio, yn y diwedd, unrhyw beth i'w ddweud. "

3. Dadleuodd Adam D. Moore, awdur Hawliau Preifatrwydd: Sylfeini Moesol a Chyfreithiol, "y farn yw bod hawliau yn gwrthsefyll cost / budd neu ddadleuon canlyniadol o'r fath. Yma rydym yn gwrthod y farn mai buddiannau preifatrwydd yw'r mathau o bethau y gellir eu masnachu er diogelwch. " Dywedodd hefyd y gall gwyliadwriaeth effeithio'n anghymesur ar rai grwpiau mewn cymdeithas ar sail ymddangosiad, ethnigrwydd, rhywioldeb a chrefydd.

4. Mynegodd Bruce Schneier, arbenigwr diogelwch cyfrifiadurol a chryptograffydd, wrthwynebiad, gan nodi datganiad Cardinal Richelieu "Pe bai rhywun yn rhoi chwe llinell i mi wedi'u hysgrifennu â llaw'r dyn mwyaf gonest, byddwn yn dod o hyd i rywbeth ynddynt i'w gael i'w grogi", gan gyfeirio i sut y gall llywodraeth y wladwriaeth ddod o hyd i agweddau ym mywyd unigolyn er mwyn erlyn neu flacmelio'r unigolyn hwnnw. Dadleuodd Schneier hefyd "Mae gormod yn nodweddu'r ddadl yn anghywir fel 'diogelwch yn erbyn preifatrwydd.' Y gwir ddewis yw rhyddid yn erbyn rheolaeth. "

5. Amcangyfrifodd Harvey A. Silverglate fod y person cyffredin, ar gyfartaledd, yn ddiarwybod yn cyflawni tair ffeloniaeth y dydd yn yr UD.

6. Dadleuodd Emilio Mordini, athronydd a seicdreiddiwr, fod y ddadl "dim byd i'w guddio" yn baradocsaidd yn ei hanfod. Nid oes angen i bobl fod â "rhywbeth i'w guddio" er mwyn cuddio "rhywbeth". Nid yw'r hyn sy'n gudd o reidrwydd yn berthnasol, yn ôl Mordini. Yn lle hynny, mae'n dadlau bod angen ardal agos atoch a all fod yn gudd ac yn gyfyngedig o ran mynediad oherwydd, wrth siarad yn seicolegol, rydyn ni'n dod yn unigolion trwy'r darganfyddiad y gallem guddio rhywbeth i eraill.

7. Dywedodd Julian Assange "Nid oes ateb llofrudd eto. Mae gan Jacob Appelbaum (@ioerror) ymateb clyfar, gan ofyn i bobl sy'n dweud hyn wedyn roi eu ffôn heb ei gloi a thynnu eu pants i lawr. Fy fersiwn i o hynny yw dweud, 'wel, os ydych chi mor ddiflas yna ni ddylem fod yn siarad â chi, ac ni ddylai unrhyw un arall chwaith', ond yn athronyddol, yr ateb go iawn yw hyn: Mae gwyliadwriaeth dorfol yn newid strwythurol torfol. Pan fydd cymdeithas yn mynd yn ddrwg, mae'n mynd i fynd â chi gydag ef, hyd yn oed os mai chi yw'r person mwyaf diflas ar y ddaear. "

8. Mae Ignacio Cofone, athro'r gyfraith, yn dadlau bod y ddadl yn cael ei chamgymryd yn ei thelerau ei hun oherwydd, pryd bynnag y mae pobl yn datgelu gwybodaeth berthnasol i eraill, maen nhw hefyd yn datgelu gwybodaeth amherthnasol. Mae gan y wybodaeth amherthnasol hon gostau preifatrwydd a gall arwain at niwed eraill, megis gwahaniaethu.

***

# Dulliau amgen

Ni ddylid cyfyngu'r cyfryngau, ar-lein nac oddi ar-lein. Pe bai pobl eisiau gwylio'r fideo heb y DRM, byddant bob amser yn dod o hyd i ffordd i'w wneud. Gellir cracio pob darn o feddalwedd.

[dyfyniad wedi'i addasu o Wikipedia] Mae llywydd y falf Gabe Newell wedi nodi bod y mwyafrif o strategaethau DRM yn fud yn unig oherwydd eu bod ond yn lleihau gwerth gêm yng ngolwg y defnyddiwr. Mae Newell yn awgrymu y dylai'r nod yn lle hynny fod yn [[creu] mwy o werth i gwsmeriaid trwy werth gwasanaeth ". Sylwch fod Valve yn gweithredu Steam, gwasanaeth sy'n gwasanaethu fel siop ar-lein ar gyfer gemau PC, yn ogystal â gwasanaeth rhwydweithio cymdeithasol a llwyfan DRM

Nid yw'r pwynt hwn yn ddilys ar gyfer gemau fideo yn unig, gellir ei gymhwyso i unrhyw beth ar gyfrifiadur. Ni ddylai eich cyfrifiadur fod â rheolaeth lwyr dros gwmni gwallgof sy'n defnyddio Deallusrwydd Artiffisial gwael i ddileu ei ddefnyddwyr a'u gwaith (YouTube, ac ati) ac sydd â record mor wael. Ni ddylid cyfyngu eich cyfrifiadur oherwydd bod cwmni'n gwrthod rhannu fel plentyn sy'n ymddwyn yn wael. Dylai eich cyfrifiadur fod yn eiddo i chi,a neb arall. Dylech gael gwared â DRM yn gyfan gwbl, gan nad yw'r cynnwys yn werth ildio rheolaeth ar eich cyfrifiadur. Mae gan y cwmnïau hyn gannoedd o biliynau o ddoleri. Os ydyn nhw'n gwneud rhywbeth gwirion fel hyn, dylech chi ei wrthwynebu. Fe allech chi hyd yn oed lawrlwytho'r fideo yn rhywle arall a'i weld, gan y dylen nhw fod yn colli arian am wneud pethau gwirion fel hyn. Nid yw torri hawlfraint yn beth drwg. Bydd pobl na allant fforddio ffilmiau yn eu lawrlwytho mewn man arall, mae wedi bod yn digwydd ers dechrau'r Rhyngrwyd fyd-eang a chyda dyfeisio'r tâp VHS. Go brin ei fod yn effeithio ar eu refeniw, gan na fyddent yn gallu cael yr arian hwnnw beth bynnag. Mae DRM yn ddiffygiol o ran dyluniad.

***

## Beth allwch chi ei wneud i helpu

Gallwch brotestio DRM. Efallai ei fod yn ymddangos yn ddibwys, ond po fwyaf o bobl sy'n mynd yn ei erbyn, y mwyaf sy'n cael ei wneud yn ei gylch.

Os ydych chi ar Linux ac yn defnyddio Firefox, gwnewch yn siŵr nad yw DRM wedi'i osod (nid yw fel arfer yn ddiofyn) a pheidiwch â thrafferthu ei osod.

Os ydych chi ar Windows neu MacOS, efallai y bydd gennych amser llawer anoddach, gan fod DRM wedi'i osod yn ddiofyn ar y systemau hyn, ac efallai y bydd yn ailosod yn awtomatig.

Ceisiwch osgoi'r gwefannau canlynol:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Yn y bôn, dylid osgoi bron unrhyw wasanaeth ffrydio fideo ar-lein, gan fod y mwyafrif ohonynt yn defnyddio DRM ac ni allwch ddefnyddio'r wefan heb golli'ch rhyddid. Nid yw'n werth chweil. Anfonwch neges i'r [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) a stopiwch ffrydio'r sioeau hyn.

Dylech hefyd osgoi unrhyw opsiynau "am ddim gyda hysbysebion" ar y gwefannau a ganlyn (gan fod y dull hwn yn gofyn am DRM)

[YouTube] (https://www.youtube.com)

Gallwch hefyd brotestio DRM gyda neges ar ffeil `README.md` eich prosiectau. Dyma beth dwi'n ei ddefnyddio:

`` `marcio i lawr

***

## Statws meddalwedd

Mae fy holl waith yn rhad ac am ddim rhai cyfyngiadau. Nid yw DRM (** D ** igital ** R ** estrictions ** M ** anagement) yn bresennol yn unrhyw un o fy ngweithiau.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Cefnogir y sticer hwn gan y Free Software Foundation. Nid wyf byth yn bwriadu cynnwys DRM yn fy ngweithiau.

Rwy'n defnyddio'r talfyriad "Rheoli Cyfyngiadau Digidol" yn lle'r "Rheoli Hawliau Digidol" mwy adnabyddus gan fod y ffordd gyffredin o fynd i'r afael ag ef yn ffug, nid oes unrhyw hawliau gyda DRM. Mae'r sillafu "Digital Restrictions Management" yn fwy cywir, ac fe'i cefnogir gan [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) a'r [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Defnyddir yr adran hon i godi ymwybyddiaeth am y problemau gyda DRM, a hefyd i'w wrthwynebu. Mae DRM yn ddiffygiol o ran dyluniad ac mae'n fygythiad mawr i bob defnyddiwr cyfrifiadur a rhyddid meddalwedd.

Credyd delwedd: [defectivebydesign.org/drm-free/…400(https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

`` `

***
## Pethau eraill i edrych arnyn nhw

[Diffygiol trwy ddyluniad - Ymgyrch gan y Free Software Foundation sy'n gweithio ar ddatgelu a dileu defnydd DRM] (https://www.defectivebydesign.org/)

[Mynwent Google (killbygoogle.com) - rhestr wedi'i didoli o'r 224+ o gynhyrchion y mae Google wedi'u lladd] (https://killedbygoogle.com/)

> [Dolen GitHub] (https://github.com/codyogden/killedbygoogle)

[Undeb gweithwyr yr wyddor - Yr undeb gweithwyr newydd yn Google gyda dros 800 o aelodau] (https://alphabetworkersunion.org/people/our-union/)

Mae yna eilyddion eraill, dim ond chwilio amdanynt.

***

## Gwybodaeth am yr erthygl

Math o ffeil: `Markdown (* .md)`

Fersiwn ffeil: `4 (dydd Gwener, Ebrill 23ain 2021 am 3:35 yp)`

Cyfrif llinell (gan gynnwys llinellau gwag a llinell grynhowr): `354`

### Statws meddalwedd

Mae fy holl weithiau'n rhydd o gyfyngiadau. Nid yw DRM (** D ** igital ** R ** estrictions ** M ** anagement) yn bresennol yn unrhyw un o fy ngweithiau. Nid yw'r prosiect hwn yn cynnwys unrhyw DRM, ond mae'n sôn am DRM yn uniongyrchol.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Cefnogir y sticer hwn gan y Free Software Foundation. Nid wyf byth yn bwriadu cynnwys DRM yn fy ngweithiau.

***

### Gwybodaeth noddwr

! [SponsorButton.png] (SponsorButton.png) <- Nid hwn yw'r botwm noddwr swyddogol, mae'n ddelwedd arddangos. Peidiwch â'i glicio os ydych chi am noddi'r prosiect hwn.

Gallwch noddi'r prosiect hwn os dymunwch, ond nodwch yr hyn yr ydych am gyfrannu ato. [Gweler yr arian y gallwch chi roi iddo yma] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Gallwch weld gwybodaeth noddwr arall [yma] (https://github.com/seanpm2001/Sponsor-info/)

Rhowch gynnig arni! Mae'r botwm noddwr wrth ymyl y botwm gwylio / dad-anfon.

***

## Hanes ffeiliau

Fersiwn 1 (dydd Sul, Chwefror 8fed 2021 am 4:41 yp)

> Newidiadau:

> * Dechreuwyd y ffeil / erthygl

> * Ychwanegwyd yr adran deitl

> * Ychwanegwyd adran am breifatrwydd

> * Ychwanegwyd adran am y trosolwg

> * Ychwanegwyd adran wybodaeth yr erthygl

> * Cyfeiriodd yr eicon DRM Free

> * Ychwanegwyd yr adran hanes ffeiliau

> * Ychwanegwyd yr adran Diffyg rhyddid

Ychwanegodd yr adran Gwrth-gystadleuol

> * Ychwanegwyd yr adran dulliau amgen

> * Ychwanegwyd y memoadran defnydd ry

> * Ychwanegwyd y pethau eraill i edrych ar yr adran

> * Ychwanegwyd y mynegai

> * Ychwanegwyd y troedyn

> * Dim newidiadau eraill yn fersiwn 1

Fersiwn 2 (Dydd Iau, Ebrill 8fed 2021 am 5:18 yp)

> Newidiadau:

> * Wedi diweddaru'r adran deitl

> * Wedi diweddaru'r mynegai

> * Ychwanegwyd gwybodaeth am yr hyn y gallwch ei wneud i helpu

> * Ychwanegwyd yr adran gwybodaeth noddwr

> * Wedi diweddaru'r adran gwybodaeth ffeil

> * Wedi diweddaru'r adran hanes ffeiliau

> * Dim newidiadau eraill yn fersiwn 2

Fersiwn 3 (Dydd Iau, Ebrill 8fed 2021 am 5:27 yp)

> Newidiadau:

> * Dolenni cyfieithu sefydlog

> * Wedi diweddaru'r mynegai

> * Wedi gosod cofnod dyblyg, oddi ar y pwnc yn yr adran `beth allwch chi ei wneud i helpu '

> * Wedi diweddaru'r adran gwybodaeth noddwr

> * Wedi diweddaru'r adran gwybodaeth ffeil

> * Wedi diweddaru'r adran hanes ffeiliau

> * Dim newidiadau eraill yn fersiwn 3

Fersiwn 4 (Dydd Gwener, Ebrill 23ain 2021 am 3:35 yp)

> Newidiadau:

> * Wedi diweddaru'r rhestr switcher iaith

> * Wedi diweddaru'r adran gwybodaeth ffeil

> * Wedi diweddaru'r adran hanes ffeiliau

> * Dim newidiadau eraill yn fersiwn 4

Fersiwn 5 (Yn dod yn fuan)

> Newidiadau:

> * Yn dod yn fuan

> * Dim newidiadau eraill yn fersiwn 5

Fersiwn 6 (Yn dod yn fuan)

> Newidiadau:

> * Yn dod yn fuan

> * Dim newidiadau eraill yn fersiwn 6

Fersiwn 7 (Yn dod yn fuan)

> Newidiadau:

> * Yn dod yn fuan

> * Dim newidiadau eraill yn fersiwn 7

Fersiwn 8 (Yn dod yn fuan)

> Newidiadau:

> * Yn dod yn fuan

> * Dim newidiadau eraill yn fersiwn 8

***

## Troedyn

Rydych chi wedi cyrraedd diwedd y ffeil hon!

##### EOF

***
