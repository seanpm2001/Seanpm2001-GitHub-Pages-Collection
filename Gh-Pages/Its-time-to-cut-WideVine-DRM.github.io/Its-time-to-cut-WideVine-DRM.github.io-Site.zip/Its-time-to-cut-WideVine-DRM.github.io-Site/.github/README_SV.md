***

##### Topp

_Läs den här artikeln på ett annat språk: _

** Aktuellt språk är: ** `Engelska (USA)` _ (översättningar kan behöva korrigeras för att fixa engelska som ersätter rätt språk) _

_🌐 Lista över språk_

** Sorterat efter: ** `A-Z`

[Sorteringsalternativ är inte tillgängliga] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanska | [am አማርኛ] (/. github / README_AM.md) Amhariska | [ar عربى] (/.github/README_AR.md) Arabiska | [hy հայերեն] (/. github / README_HY.md) Armeniska | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbajdzjanska | [eu Euskara] (/. github /README_EU.md) Baskiska | [vara Беларуская] (/. Github / README_BE.md) Vitryska | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosniska | [bg български] (/. Github / README_BG.md) Bulgariska | [ca Català] (/. Github / README_CA.md) Katalanska | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Kinesiska (förenklad) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Kinesiska (traditionell) | [co Corsu] (/. Github / README_CO.md) Korsikansk | [hr Hrvatski] (/. Github / README_HR.md) Kroatiska | [cs čeština] (/. Github / README_CS .md) Tjeckiska | [da dansk] (README_DA.md) Danska | [nl Nederlands] (/. github / README_ NL.md) nederländska | [** en-us engelska **] (/. github / README.md) Engelska | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estniska | [tl Pilipino] (/. github / README_TL.md) Filippinska | [fi Suomalainen] (/. github / README_FI.md) Finska | [fr français] (/. github / README_FR.md) Franska | [fy Frysk] (/. github / README_FY.md) Frisiska | [gl Galego] (/. github / README_GL.md) Galiciska | [ka ქართველი] (/. github / README_KA) Georgiska | [de Deutsch] (/. github / README_DE.md) Tyska | [el Ελληνικά] (/. github / README_EL.md) Grekiska | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitisk kreolsk | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) Hebreiska | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ungerska | [är Íslenska] (/. github / README_IS.md) isländska | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Isländska | [ga Gaeilge] (/. github / README_GA.md) Irländska | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japanska | [jw Wong jawa] (/. github / README_JW.md) Javanesiska | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazakiska | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Koreanska (South) | [ko-north 문화어] (README_KO_NORTH.md) Koreanska (North) (INTE ÄN TRANSLERAT) | [ku Kurdî] (/. github / README_KU.md) Kurdiska (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgizistan | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latin | [lt Lietuvis] (/. github / README_LT.md) Litauiska | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgiska | [mk Македонски] (/. github / README_MK.md) Makedonska | [mg madagassiska] (/. github / README_MG.md) madagaskiska | [ms Bahasa Melayu] (/. github / README_MS.md) Malajiska | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltesiska | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongoliska | [min မြန်မာ] (/. github / README_MY.md) Myanmar (burmesiska) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) Norska | [eller ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persiska [pl polski] (/. github / README_PL.md) Polska | [pt português] (/. github / README_PT.md) Portugisiska | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Inga tillgängliga språk som börjar med bokstaven Q | [ro Română] (/. github / README_RO.md) Rumänska | [ru русский] (/. github / README_RU.md) Ryska | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Skotska gäliska | [sr Српски] (/. github / README_SR.md) Serbiska | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slovakiska | [sl Slovenščina] (/. github / README_SL.md) Slovenska | [so Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spanska | [su Sundanis] (/. github / README_SU.md) Sundanese | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Svenska | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github /README_TR.md) Turkiska | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukrainska | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uyghur | [uz O'zbek] (/. github / README_UZ.md) Uzbekiska | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamesiska | [cy Cymraeg] (/. github / README_CY.md) Walesiska | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) jiddiska | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Finns på 110 språk (108 när man inte räknar med engelska och nordkoreanska, eftersom nordkoreanska inte har översatts ännu [Läs om det här] (/ OldVersions / Korean (North ) /README.md))

Översättningar på andra språk än engelska är maskinöversatta och är ännu inte korrekta. Inga fel har fixats ännu den 5 februari 2021. Rapportera översättningsfel [här] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/) se till att säkerhetskopiera din korrigering med källor och vägleda mig, eftersom jag inte känner till andra språk än engelska bra (jag planerar att få en översättare så småningom) hänvisa till [wiktionary] (https://en.wiktionary.org) och andra källor i din rapport. Underlåtenhet att göra det kommer att leda till att korrigeringen avslås publiceras.

Obs: på grund av begränsningar med GitHubs tolkning av markdown (och i stort sett alla andra webbaserade tolkningar av markdown), klickar du på dessa länkar till en separat fil på en separat sida som inte är min GitHub-profilsida. Du kommer att omdirigeras till [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), där README är värd.

Översättningar görs med Google Translate på grund av begränsat eller inget stöd för de språk jag behöver i andra översättningstjänster som DeepL och Bing Translate (ganska ironiskt för en anti-Google-kampanj) Jag jobbar med att hitta ett alternativ. Av någon anledning är formateringen (länkar, avdelare, fetstil, kursiv, etc.) trasslad i olika översättningar. Det är tråkigt att fixa, och jag vet inte hur man fixar dessa problem på språk med icke-latinska tecken, och från höger till vänster-språk (som arabiska) behövs extra hjälp för att lösa dessa problem

På grund av underhållsproblem är många översättningar föråldrade och använder en föråldrad version av denna `README`-artikelfil. En översättare behövs. Från och med den 23 april 2021 kommer det att ta mig ett tag att få alla nya länkar att fungera.

***

# Det är dags att klippa Widevine

Det här är en artikel om varför du bör sluta använda Google WideVine (DRM) och avinstallera den. DRM måste tas bort. Den här artikeln hjälper dig att göra ditt val (om du inte redan har gjort det) WideVine är mycket konkurrensbegränsande och extremt restriktivt och förstör videofriheten på Internet.

Låt oss klippa WideVine och omfamna ett öppet internet.

***

# Index

[00.0 - Top] (# Top)

> [00.1 - Läs den här artikeln på ett annat språk]

> [00.2 - Titel] (# It-is-time-to-cut-Widevine)

> [00.3 - Index] (# index)

[01.0 - Översikt] (# Översikt)

[02.0 - Konkurrensbegränsande] (# Konkurrensbegränsande)

[03.0 - Brist på frihet] (# Brist på frihet)

[04.0 - Minnesanvändning] (# minnesanvändning)

[05.0 - Sekretess] (# Sekretess)

[06.0 - Alternativa metoder] (# Alternativa metoder)

[07.0 - Vad du kan göra för att hjälpa till] (# Vad-du-kan-göra-för-hjälp)

[08.0 - Andra saker att kolla in] (# Andra saker att checka ut)

[09.0 - Artikelinfo] (# artikelinfo)

> [09.0.1 - Programvarustatus] (# Programvarustatus)

> [09.0.2 - Sponsorinformation] (# sponsorinformation)

[10.0 - Filhistorik] (# Filhistorik)

[11.0 - Sidfot] (# sidfot)

> [11.9 - EOF] (# EOF)

***

## Översikt

För mer information om varför DRM är ett problem, [klicka här] (https://www.defectivebydesign.org/)

***

## Konkurrensbegränsande

WideVine är en DRM som måste licensieras för att användas med en webbläsare. Google är extremt långsamt med att granska och acceptera människor och vägrar ofta människor att använda det i sina produkter utan resonemang. [Källa 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Källa 2 (e-posttråden som pågick i över 4 månader och resulterade i ingenting annat än besvikelse)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google har gjort det mycket svårare för webbläsare som Brave eller Firefox att konkurrera med att trycka på denna bit DRM.

***

## Brist på frihet

WideVine används för att förhindra att användare interagerar med video på webbplatser. Det är en form av digitala begränsningar som hindrar dig från att ladda ner videon, visa videon offline eller till och med ta en skärmdump. Det är proprietär programvara och på grund av dess problem med sekretess är den inte installerad som standard på de flesta Linux-distributioner. Det begränsar friheterna på nätet på grund av dess användning av Netflix-, Disney- och YouTube-filmer. Din tillgång till innehållet kan tas bort när som helst utan anledning.

***

## Minnesanvändning

WideVine är dåligt i minnet. Jämfört med att normalt bara titta på en video utan DRM kommer WideVine att använda stora mängder CPU och RAM. Det är dåligt på balivslängd och det ger inga fördelar med standard HTML5-videouppspelning.

***

## Integritet

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (övervakningsprogram)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit) [s ](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / varför-googles-spionera-på-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritik) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -prover / ingenting-att-dölja-argument-har-ingenting-att-säga /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- data-om-dig-du-kan-hitta-och-radera-det-nu /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personlig-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -och) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html) [d ](https://www.reuters.com/article/us-alphabet- google-sekretess-stämning-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html) [o ](https://en.wikipedia.org/wiki/2018_Google_data_breach) [m ](https:// moz.com/bl og / var-gör-google-ritar-datainsamlingslinjen) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- anspråk på uppdrag av 5 miljoner iPhone-användare) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W) [e ](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -telefon-är inte i bruk /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / informationsteknik gy / 2014/01 / vad-google-kan-verkligen-göra-med-bo-eller-verkligen-bo-data /) [i] (https://www.cbsnews.com/news/google-education-spies -på-samlar-data-om-miljoner-barn-påståenden-rättegång-nya-mexico-advokat-general /) [v] (https://www.nationalreview.com/2018/04/the-student- data-mining-skandal-under-våra-näsor /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html) [y ](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -något att dölja-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Jag skulle kunna fortsätta och fortsätta med bevis på detta , men det tog lång tid att hitta och gå igenom alla dessa artiklar)

Sekretess är inte en sak med WideVine. Egen programvara är utformad så att du inte kan se vad som händer alls. Med Googles historia är det mycket troligt attWideVine är en extra mjukvara som spionerar på dig, läser dina dokument och andra dåliga saker.

Om du tror att du inte har något att dölja, ** har du helt fel **. Detta argument har debunkats många gånger:

[Via Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden anmärkte: "Att argumentera för att du inte bryr dig om rätten till integritet eftersom du inte har något att dölja är inte annorlunda än att säga att du inte bryr dig om yttrandefrihet eftersom du inte har något att säga." När du säger, ' Jag har inget att dölja, säger du, jag bryr mig inte om den här rätten. Du säger, jag har inte den här rätten, för jag har kommit till den punkt där jag måste motivera det. ”Så som rättigheter fungerar, måste regeringen motivera sitt intrång i dina rättigheter."

2. Daniel J. Solove uppgav i en artikel för The Chronicle of Higher Education att han motsätter sig argumentet; han uppgav att en regering kan läcka information om en person och orsaka skada på den personen, eller använda information om en person för att neka tillgång till tjänster även om en person inte faktiskt gjorde något fel, och att en regering kan skada sin personliga livet genom att göra fel. Solove skrev "När det är engagerat direkt kan ingenting att dölja argumentet förneka, för det tvingar debatten att fokusera på dess snäva förståelse för integritet. Men när den konfronteras med de många integritetsproblem som impliceras av regeringens datainsamling och användning utöver övervakning och avslöjande, argumentet ingenting att dölja, har i slutändan inget att säga. "

3. Adam D. Moore, författare till Privacy Rights: Moral and Legal Foundations, hävdade, "det är uppfattningen att rättigheter är motståndskraftiga mot kostnad / nytta eller konsekventistiska argument. Här förkastar vi uppfattningen att sekretessintressen är de slags av saker som kan bytas för säkerhet. " Han uppgav också att övervakning kan oproportionerligt påverka vissa grupper i samhället baserat på utseende, etnicitet, sexualitet och religion.

4. Bruce Schneier, en datasäkerhetsexpert och kryptograf, uttryckte motstånd och citerade kardinal Richelieus uttalande "Om man skulle ge mig sex rader skrivna av den ärligaste mannen, skulle jag hitta något i dem för att få honom hängd", med hänvisning till hur en statlig regering kan hitta aspekter i en människas liv för att åtala eller utpressa den personen. Schneier hävdade också att "alltför många felaktigt karakteriserar debatten som" säkerhet kontra integritet. " Det verkliga valet är frihet kontra kontroll. "

5. Harvey A. Silverglate uppskattade att den vanliga personen i genomsnitt omedvetet begår tre brott per dag i USA.

6. Emilio Mordini, filosof och psykoanalytiker, hävdade att argumentet "inget att dölja" är i sig paradoxalt. Människor behöver inte ha "något att dölja" för att dölja "något". Vad som är dolt är inte nödvändigtvis relevant, hävdar Mordini. Istället argumenterar han för att ett intimt område som kan vara både dolt och åtkomstbegränsat är nödvändigt eftersom vi, psykologiskt sett, blir individer genom upptäckten att vi kan dölja något för andra.

7. Julian Assange uttalade "Det finns inget mördarsvar ännu. Jacob Appelbaum (@ioerror) har ett smart svar och ber folk som säger detta för att sedan ge honom telefonen upplåst och dra ner byxorna. Min version av det är att säga, "Tja, om du är så tråkig så borde vi inte prata med dig, och inte heller någon annan", men filosofiskt är det verkliga svaret detta: Massövervakning är en massstrukturell förändring. När samhället går dåligt går det att ta dig med det, även om du är den trögaste personen på jorden. "

8. Ignacio Cofone, juridikprofessor, hävdar att argumentet är felaktigt i sina egna termer, för när människor avslöjar relevant information till andra, avslöjar de också irrelevant information. Denna irrelevanta information har integritetskostnader och kan leda till andra skador, såsom diskriminering.

***

# Alternativa metoder

Media bör inte vara begränsade, online eller offline. Om folk ville titta på videon utan DRM, kommer de alltid att hitta ett sätt att göra det. Varje programvara kan knäckas.

[modifierat utdrag från Wikipedia] Ventilpresident Gabe Newell har sagt "de flesta DRM-strategier är bara dumma" eftersom de bara minskar värdet av ett spel i konsumentens ögon. Newell föreslår att målet istället ska vara "[skapa] större värde för kunderna genom servicevärde". Observera att Valve driver Steam, en tjänst som fungerar som en onlinebutik för PC-spel, samt en social nätverkstjänst och en DRM-plattform

Denna punkt är inte giltig bara för videospel, den kan tillämpas på vad som helst på en dator. Din dator borde inte ha fullständig kontroll över ett galen företag som använder dålig artificiell intelligens för att radera sina användare och deras arbete (YouTube, etc.) och har en sådan dålig rekord. Din dator bör inte begränsas eftersom ett företag vägrar att dela som ett dåligt uppfört barn. Din dator bör ägas av dig,och ingen annan. Du bör bli av med DRM helt, eftersom innehållet inte är värt att ge upp kontrollen över din dator för. Dessa företag har hundratals miljarder dollar. Om de gör något så dumt bör du protestera mot det. Du kan till och med bara ladda ner videon någon annanstans och se den, eftersom de borde förlora pengar för att göra dumma saker som detta. Upphovsrättsintrång är inte en dålig sak. Människor som inte har råd med filmer kommer att ladda ner dem någon annanstans, det har hänt sedan början av det globala Internet och med uppfinningen av VHS-bandet. Det påverkar knappast deras intäkter, eftersom de inte skulle kunna få de pengarna ändå. DRM är defekt av design.

***

## Vad du kan göra för att hjälpa till

Du kan protestera mot DRM. Det kan verka obetydligt, men ju fler människor som går emot det desto mer görs det åt det.

Om du är på Linux och använder Firefox, se till att DRM inte är installerat (det är normalt inte som standard) och bry dig inte om att installera det.

Om du använder Windows eller MacOS kan du ha mycket svårare, eftersom DRM är installerat som standard på dessa system och kan installera om automatiskt.

Försök att undvika följande webbplatser:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

I grund och botten bör nästan alla onlinestreamingtjänster online undvikas, eftersom majoriteten av dem använder DRM och du inte kan använda webbplatsen utan att förlora din frihet. Det är inte värt det. Skicka ett meddelande till [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) och sluta streama dessa program.

Du bör också undvika alternativet "gratis med annonser" på följande webbplatser (eftersom den här metoden kräver DRM)

[YouTube] (https://www.youtube.com)

Du kan också protestera mot DRM med ett meddelande på din projekt `README.md`-fil. Här är vad jag använder:

`` markdown

***

## Programvarustatus

Alla mina verk är gratis några begränsningar. DRM (** D ** igital ** R ** estrictions ** M ** anagement) finns inte i något av mina verk.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Denna klistermärke stöds av Free Software Foundation. Jag tänker aldrig inkludera DRM i mina verk.

Jag använder förkortningen "Digital Restrictions Management" istället för den mer kända "Digital Rights Management" eftersom det vanliga sättet att ta itu med det är falskt, det finns inga rättigheter med DRM. Stavningen "Digital Restrictions Management" är mer exakt och stöds av [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) och [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Detta avsnitt används för att öka medvetenheten om problemen med DRM och också för att protestera mot det. DRM är defekt av design och är ett stort hot mot alla datoranvändare och programvarufrihet.

Bildkredit: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

`` ''

***
## Andra saker att kolla in

[Defective by design - En kampanj från Free Software Foundation som arbetar med att avslöja och eliminera DRM-användning] (https://www.defectivebydesign.org/)

[Google Graveyard (killadbygoogle.com) - en sorterad lista över de 224+ produkter som Google har dödat] (https://killedbygoogle.com/)

> [GitHub-länk] (https://github.com/codyogden/killedbygoogle)

[Alphabet workers union - The new workers union at Google with over 800 members] (https://alphabetworkersunion.org/people/our-union/)

Det finns andra suppleanter, sök bara efter dem.

***

## Artikelinfo

Filtyp: 'Markdown (* .md)'

Filversion: '4 (fredag ​​23 april 2021 kl. 15:35)'

Radantal (inklusive tomma rader och kompilatorrad): `354`

### Programvarustatus

Alla mina verk är fria från begränsningar. DRM (** D ** igital ** R ** estrictions ** M ** anagement) finns inte i något av mina verk. Detta projekt innehåller ingen DRM, men det talar om DRM direkt.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Denna klistermärke stöds av Free Software Foundation. Jag tänker aldrig inkludera DRM i mina verk.

***

### Sponsorinformation

! [SponsorButton.png] (SponsorButton.png) <- Det här är inte den officiella sponsorknappen, det är en demobild. Klicka inte på det om du vill sponsra detta projekt.

Du kan sponsra detta projekt om du vill, men ange vad du vill donera till. [Se de medel du kan donera till här] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Du kan se annan sponsorinformation [här] (https://github.com/seanpm2001/Sponsor-info/)

Testa! Sponsorknappen är alldeles intill klockan.

***

## Filhistorik

Version 1 (söndag 8 februari 2021 kl 16:41)

> Ändringar:

> * Startade filen / artikeln

> * Lade till rubriken

> * Lade till ett avsnitt om sekretess

> * Lade till ett avsnitt om översikten

> * Lade till artikelinformationsavsnittet

> * Hänvisade till DRM Free-ikonen

> * Lade till filhistorikavsnittet

> * Lade till avsnittet Brist på frihet

> * Lade till avsnittet Konkurrensbegränsande

> * Lade till avsnittet om alternativa metoder

> * Lade till memotry användningsavsnitt

> * Lade till de andra sakerna för att kolla in avsnittet

> * Lade till indexet

> * Lagt till sidfoten

> * Inga andra ändringar i version 1

Version 2 (torsdag 8 april 2021 kl 17:18)

> Ändringar:

> * Uppdaterade titelavsnittet

> * Uppdaterat index

> * Lagt till information om vad du kan göra för att hjälpa till

> * Lade till avsnittet om sponsorinformation

> * Uppdaterade avsnittet om filinformation

> * Uppdaterade filhistorikavsnittet

> * Inga andra ändringar i version 2

Version 3 (torsdag 8 april 2021 kl 17:27)

> Ändringar:

> * Länkar för fasta översättningar

> * Uppdaterat index

> * Fixade en dubblett, utanför ämnesinmatningen i avsnittet `vad du kan göra för att hjälpa till

> * Uppdaterade avsnittet om sponsorinformation

> * Uppdaterade avsnittet om filinformation

> * Uppdaterade filhistorikavsnittet

> * Inga andra ändringar i version 3

Version 4 (fredag ​​23 april 2021 kl. 15:35)

> Ändringar:

> * Uppdaterade språkväxlarlistan

> * Uppdaterade avsnittet om filinformation

> * Uppdaterade filhistorikavsnittet

> * Inga andra ändringar i version 4

Version 5 (Kommer snart)

> Ändringar:

> * Kommer snart

> * Inga andra ändringar i version 5

Version 6 (Kommer snart)

> Ändringar:

> * Kommer snart

> * Inga andra ändringar i version 6

Version 7 (kommer snart)

> Ändringar:

> * Kommer snart

> * Inga andra ändringar i version 7

Version 8 (kommer snart)

> Ändringar:

> * Kommer snart

> * Inga andra ändringar i version 8

***

## Sidfot

Du har nått slutet av den här filen!

##### EOF

***
