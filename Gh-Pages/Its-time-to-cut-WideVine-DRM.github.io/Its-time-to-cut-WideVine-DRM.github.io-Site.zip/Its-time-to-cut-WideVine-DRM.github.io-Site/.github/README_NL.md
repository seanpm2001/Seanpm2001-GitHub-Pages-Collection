***

##### Boven

_Lees dit artikel in een andere taal: _

** Huidige taal is: ** `Engels (VS)` _ (vertalingen moeten mogelijk worden gecorrigeerd om ervoor te zorgen dat Engels de juiste taal vervangt) _

_🌐 Lijst met talen_

** Gesorteerd op: ** `A-Z`

[Sorteeropties niet beschikbaar] (https://github.com/Degoogle-your-Life)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanees | [ben አማርኛ] (/. github / README_AM.md) Amhaars | [ar عربى] (/.github/README_AR.md) Arabisch | [hy հայերեն] (/. github / README_HY.md) Armeens | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbeidzjaans | [eu Euskara] (/. github /README_EU.md) Baskisch | [be Беларуская] (/. Github / README_BE.md) Wit-Russisch | [bn বাংলা] (/. Github / README_BN.md) Bengaals | [bs Bosanski] (/. Github / README_BS.md) Bosnisch | [bg български] (/. Github / README_BG.md) Bulgaars | [ca Català] (/. Github / README_CA.md) Catalaans | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chinees (vereenvoudigd) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chinees (traditioneel) | [co Corsu] (/. Github / README_CO.md) Corsicaans | [hr Hrvatski] (/. Github / README_HR.md) Kroatisch | [cs čeština] (/. Github / README_CS .md) Tsjechisch | [da dansk] (README_DA.md) Deens | [nl Nederlands] (/. github / README_ NL.md) Nederlands | [** en-us Engels **] (/. github / README.md) Engels | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Ests | [tl Pilipino] (/. github / README_TL.md) Filipijns | [fi Suomalainen] (/. github / README_FI.md) Fins | [fr français] (/. github / README_FR.md) Frans | [fy Frysk] (/. github / README_FY.md) Fries | [gl Galego] (/. github / README_GL.md) Galicisch | [ka ქართველი] (/. github / README_KA) Georgisch | [de Deutsch] (/. github / README_DE.md) Duits | [el Ελληνικά] (/. github / README_EL.md) Grieks | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haïtiaans Creools | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiiaans | [he עִברִית] (/. github / README_HE.md) Hebreeuws | [hoi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Hongaars | [is Íslenska] (/. github / README_IS.md) IJslands | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) IJslands | [ga Gaeilge] (/. github / README_GA.md) Iers | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japans | [jw Wong jawa] (/. github / README_JW.md) Javaans | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazachs | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Koreaans (Zuid) | [ko-north 문화어] (README_KO_NORTH.md) Koreaans (Noord) (NOG NIET VERTAALD) | [ku Kurdî] (/. github / README_KU.md) Koerdisch (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgizisch | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latijn | [lt Lietuvis] (/. github / README_LT.md) Litouws | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgs | [mk Македонски] (/. github / README_MK.md) Macedonisch | [mg Malagasy] (/. github / README_MG.md) Malagasi | [ms Bahasa Melayu] (/. github / README_MS.md) Maleis | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltees | [mi Maori] (/. github / README_MI.md) Maori | [dhr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongools | [mijn မြန်မာ] (/. github / README_MY.md) Myanmar (Birmaans) | [ne नेपाली] (/. github / README_NE.md) Nepalees | [no norsk] (/. github / README_NO.md) Noors | [of ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pasjtoe | [fa فارسی] (/. github / README_FA.md) | Perzisch [pl polski] (/. github / README_PL.md) Pools | [pt português] (/. github / README_PT.md) Portugees | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Geen talen beschikbaar die beginnen met de letter Q | [ro Română] (/. github / README_RO.md) Roemeens | [ru русский] (/. github / README_RU.md) Russisch | [sm Faasamoa] (/. github / README_SM.md) Samoaans | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Schots-Gaelisch | [sr Српски] (/. github / README_SR.md) Servisch | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Slowaaks | [sl Slovenščina] (/. github / README_SL.md) Sloveens | [dus Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spaans | [su Sundanis] (/. github / README_SU.md) Sundanees | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Zweeds | [tg Тоҷикӣ] (/. github / README_TG.md) Tadzjieks | [ta தமிழ்] (/. github / README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tataars | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thais | [tr Türk] (/. github /README_TR.md) Turks | [tk Türkmenler] (/. github / README_TK.md) Turkmeens | [uk Український] (/. github / README_UK.md) Oekraïens | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Oeigoers | [uz O'zbek] (/. github / README_UZ.md) Oezbeeks | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamees | [cy Cymraeg] (/. github / README_CY.md) Welsh | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Jiddisch | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Beschikbaar in 110 talen (108 als Engels en Noord-Koreaans niet meegeteld worden, aangezien Noord-Koreaans nog niet vertaald is [Lees er hier meer over] (/ OldVersions / Korean (North ) /README.md))

Vertalingen in andere talen dan het Engels zijn automatisch vertaald en zijn nog niet nauwkeurig. Vanaf 5 februari 2021 zijn er nog geen fouten opgelost. Meld vertaalfouten [hier] (https://github.com/seanpm2001/Its-time-to-cut0WideVine-DRM/issues/). Zorg ervoor dat u een back-up van uw correctie maakt met bronnen en leid mij, aangezien ik geen andere talen dan Engels goed ken (ik ben van plan om uiteindelijk een vertaler te krijgen), gelieve [wiktionary] (https://en.wiktionary.org) en andere bronnen in uw rapport te vermelden. Als u dit niet doet, wordt de publicatie van de correctie afgewezen.

Opmerking: vanwege beperkingen met GitHub's interpretatie van markdown (en vrijwel elke andere webgebaseerde interpretatie van markdown), zal het klikken op deze links je doorverwijzen naar een apart bestand op een aparte pagina die niet mijn GitHub-profielpagina is. U wordt doorgestuurd naar de [seanpm2001 / seanpm2001 repository] (https://github.com/seanpm2001/seanpm2001), waar de README wordt gehost.

Vertalingen worden gedaan met Google Translate vanwege beperkte of geen ondersteuning voor de talen die ik nodig heb in andere vertaaldiensten zoals DeepL en Bing Translate (behoorlijk ironisch voor een anti-Google-campagne). Ik ben bezig een alternatief te vinden. Om de een of andere reden is de opmaak (links, scheidingslijnen, vetgedrukt, cursief, enz.) In verschillende vertalingen verknoeid. Het is vervelend om op te lossen en ik weet niet hoe ik deze problemen moet oplossen in talen met niet-Latijnse tekens, en talen van rechts naar links (zoals Arabisch) extra hulp is nodig bij het oplossen van deze problemen

Vanwege onderhoudsproblemen zijn veel vertalingen verouderd en gebruiken ze een verouderde versie van dit "README" -artikelbestand. Er is een vertaler nodig. Ook zal het vanaf 23 april 2021 even duren voordat alle nieuwe links werken.

***

# Het is tijd om Widevine te schrappen

Dit is een artikel over waarom u moet stoppen met het gebruik van Google WideVine (DRM) en het moet verwijderen. DRM moet worden verwijderd. Dit artikel zal je helpen bij het maken van je keuze (als je dat nog niet hebt gedaan). WideVine is zeer concurrentievervalsend en extreem beperkend, en vernietigt de vrijheid van video's op internet.

Laten we de WideVine afsnijden en een open internet omarmen.

***

# Inhoudsopgave

[00.0 - Top] (# Top)

> [00.1 - Lees dit artikel in een andere taal]

> [00.2 - Titel] (# It-is-time-to-cut-Widevine)

> [00.3 - Index] (# Index)

[01.0 - Overzicht] (# Overzicht)

[02.0 - Concurrentieverstorend] (# Concurrentieverstorend)

[03.0 - Gebrek aan vrijheid] (# Gebrek aan vrijheid)

[04.0 - Geheugengebruik] (# Geheugengebruik)

[05.0 - Privacy] (# Privacy)

[06.0 - Alternatieve methoden] (# Alternatieve methoden)

[07.0 - Wat u kunt doen om te helpen] (# Wat-u-kunt-doen-om te helpen)

[08.0 - Andere dingen om uit te checken] (# Andere dingen om uit te checken)

[09.0 - Artikel info] (# Artikel-info)

> [09.0.1 - Softwarestatus] (# Softwarestatus)

> [09.0.2 - Sponsor info] (# Sponsor-info)

[10.0 - Bestandsgeschiedenis] (# Bestandsgeschiedenis)

[11.0 - Voettekst] (# Voettekst)

> [11.9 - EOF] (# EOF)

***

## Overzicht

Voor andere informatie over waarom DRM een probleem is, [klik hier] (https://www.defectivebydesign.org/)

***

## Concurrentiebeperkend

WideVine is een DRM waarvoor een licentie vereist is om met een browser te worden gebruikt. Google is extreem traag in het beoordelen en accepteren van mensen, en weigert vaak mensen om het zonder reden in hun producten te gebruiken. [Bron 1] (https://blog.samuelmaddock.com/posts/google-widevine-blocked-my-browser/) [Bron 2 (de e-mailthread die meer dan 4 maanden duurde en alleen maar tot teleurstelling leidde)] (https://blog.samuelmaddock.com/widevine/gmail-thread.html) Google heeft het veel moeilijker gemaakt voor browsers zoals Brave of Firefox om te concurreren met het pushen van dit stukje DRM.

***

## Gebrek aan vrijheid

WideVine wordt gebruikt om te voorkomen dat gebruikers interactie hebben met video op websites. Het is een vorm van beheer van digitale beperkingen die voorkomen dat u de video downloadt, de video offline bekijkt of zelfs een screenshot maakt. Het is bedrijfseigen software en vanwege zijn privacykwesties wordt het niet standaard geïnstalleerd op de meeste Linux-distributies. Het beperkt de vrijheden van internet vanwege het gebruik ervan door Netflix-, Disney- en YouTube-films. Uw toegang tot de inhoud kan op elk moment zonder reden worden ontnomen.

***

## Geheugengebruik

WideVine heeft een slecht geheugen. Vergeleken met het normaal bekijken van een video zonder DRM, gebruikt WideVine grote hoeveelheden CPU en RAM. Het is slecht op battery leven, en het biedt geen voordelen van standaard HTML5-videoweergave.

***

## Privacy

[G] (https://en.wikipedia.org/wiki/Criticism_of_Google) [o] (https://en.wikipedia.org/wiki/PRISM_ (surveillance_program)) [o] (https: //www.reddit .com / r / degoogle /) [g] (https://www.wired.com/2012/06/opinion-google-is-evil/) [l] (https://securitygladiators.com/chrome-privacy -bad /) [e] (https://www.zdnet.com/article/goodbye-google-why-and-how-to-take-back-your-privacy/) [h] (https: // www .theguardian.com / commentisfree / 2018 / mar / 28 / all-the-data-facebook-google-has-on-you-privacy) [a] (https://www.vox.com/recode/2020/2 /21/21146998/google-new-mexico-children-privacy-school-chromebook-lawsuit)[s ](https://www.eff.org/deeplinks/2019/08/dont-play-googles-privacy-sandbox -1) [a] (https://money.cnn.com/2017/10/11/technology/google-home-mini-security-flaw/index.html) [v] (https: //www.huffpost .com / entry / waarom-googles-spying-on-use_b_3530296) [e] (https://medium.com/digiprivacy/i-stopped-using-google-as-my-search-engine-heres-why-7a3a1b4fef81 ) [r] (https://www.theguardian.com/technology/2019/nov/05/fitbit-google-acquisition-he alth-data) [y] (https://www.computerworld.com/article/3128791/how-google-homes-always-on-will-affect-privacy.html) [v] (https: // protonmail. com / blog / google-privacy-problem /) [e] (https://www.forbes.com/sites/gordonkelly/2020/02/23/google-chrome-80-upgrade-deep-linking-update-chrome -browser /) [r] (https://www.wired.co.uk/article/duckduckgo-google-alternative-search-privacy) [y] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument# Kritiek) [b] (https://spreadprivacy.com/three-reasons-why-the-nothing-to-hide-argument-is-flawed/) [a] (https://eduzaurus.com/free-essay -samples / niets-te-verbergen-argument-heeft-niets-te-zeggen /) [d] (https://www.cnet.com/how-to/google-collects-a-frightening-amount-of- gegevens-over-u-kunt-vinden-en-verwijderen-het-nu /) [r] (https://www.nbcnews.com/tech/tech-news/google-sells-future-powered-your -personal-data-n870501) [e] (https://www.eff.org/deeplinks/2020/03/google-says-it-doesnt-sell-your-data-heres-how-company-shares-monetizes -en) [c] (https://www.wired.com/story/google-tracks-you -privacy /) [o] (https://www.theguardian.com/commentisfree/2018/mar/28/all-the-data-facebook-google-has-on-you-privacy) [r] (https: //www.dailymail.co.uk/sciencetech/article-5743829/Googles-vision-TOTAL-data-collection-revealed.html)[d ](https://www.reuters.com/article/us-alphabet- google-privacy-rechtszaak-idUSKBN23933H) [w] (https://www.wired.com/story/health-fitness-data-privacy/) [h] (https://www.pcmag.com/news/google -sued-over-kids-data-collection-on-education-Chromebooks) [e] (https://mashable.com/article/google-android-data-collection-study/) [n] (https: // www.engadget.com/australian-government-google-data-collection-lawsuit-182043643.html) [i] (https://www.maketecheasier.com/studyandroid-data-google-ios-apple/) [t] (https://www.washingtonpost.com/technology/2019/07/23/never-googlers-web-users-take-ultimate-step-guard-their-data/) [c] (https: // www. cnn.com/2019/11/12/business/google-project-nightingale-ascension/index.html)[o ](https://en.wikipedia.org/wiki/2018_Google_data_breach)[m ](https:// moz.com/bl og / where-does-google-draw-the-data-collection-line) [e] (https://mashable.com/article/google-android-data-collection-study/) [s] (https: / /eandt.theiet.org/content/articles/2020/06/google-sued-over-data-collection-from-users-in-incognito-mode/) [t] (https://www.nytimes.com/ 2019/01/21 / technology / google-europe-gdpr-fine.html) [o] (https://www.bloomberg.com/news/articles/2017-11-30/google-sued-over-data- claims-namens-5-miljoen-iphone-gebruikers) [u] (https://time.com/23782/google-flu-trends-big-data-problems/) [s] (https: / /www.reuters.com/article/dataprivacy-googleyoutube-kidsdata-idUSL1N2J306W)[e ](https://www.adweek.com/performance-marketing/google-is-collecting-your-data-even-when-your -phone-isnt-in-use /) [r] (https://www.computerworld.com/article/2914838/project-fi-will-help-google-amass-even-more-data-about-you. html) [p] (https://topclassactions.com/lawsuit-settlements/privacy/google-says-class-action-lawsuit-plaintiffs-consented-to-data-collection/) [r] (https: // arstechnica .com / informatie-technolo gy / 2014/01 / wat-google-echt-kan-doen-met-nest-of-echt-nesten-gegevens /) [i] (https://www.cbsnews.com/news/google-education-spies -on-verzamelt-gegevens-over-miljoenen-kinderen-beweert-rechtszaak-nieuwe-mexico-procureur-generaal /) [v] (https://www.nationalreview.com/2018/04/the-student- datamining-schandaal-onder-onze-neus /) [a] (https://www.wired.com/insights/2012/10/google-opt-out/) [c] (https: // www. nytimes.com/2019/09/04/technology/google-youtube-fine-ftc.html)[y ](https://medium.com/@hansdezwart/during-world-war-ii-we-did-have -something-to-hide-40689565c550) [.] (https://medium.com/digitalprivacywise/why-you-should-stop-using-google-chrome-6c934c9a827c) (Ik zou door kunnen gaan met bewijs hiervan , maar het kostte veel tijd om al deze artikelen te vinden en door te nemen)

Privacy is geen ding met WideVine. Eigen software is zo ontworpen dat u helemaal niet kunt zien wat er aan de hand is. Met de geschiedenis van Google is dat zeer waarschijnlijkWideVine is een extra stuk software dat u bespioneert, uw documenten leest en andere slechte dingen.

Als je denkt dat je niets te verbergen hebt, ** heb je het absoluut mis **. Dit argument is vele malen ontkracht:

[Via Wikipedia] (https://en.wikipedia.org/wiki/Nothing_to_hide_argument#Criticism)

1. Edward Snowden merkte op: "Beweren dat je niet geeft om het recht op privacy omdat je niets te verbergen hebt, is niet anders dan zeggen dat je niets geeft om vrijheid van meningsuiting omdat je niets te zeggen hebt." Ik heb niets te verbergen '', zegt u, `` ik geef niet om dit recht. '' U zegt: `` Ik heb dit recht niet, omdat ik op het punt ben gekomen dat ik het moet rechtvaardigen 'De manier waarop rechten werken, is dat de regering haar inbreuk op uw rechten moet rechtvaardigen.'

2. Daniel J. Solove verklaarde in een artikel voor The Chronicle of Higher Education dat hij tegen het argument is; hij verklaarde dat een overheid informatie over een persoon kan lekken en schade kan toebrengen aan die persoon, of informatie over een persoon kan gebruiken om de toegang tot diensten te ontzeggen, zelfs als een persoon zich niet daadwerkelijk schuldig heeft gemaakt aan wangedrag, en dat een overheid persoonlijke schade kan toebrengen leven door fouten te maken. Solove schreef: "Als je rechtstreeks betrokken bent, kan het niets-te-verbergen-argument verstrikt raken, want het dwingt het debat om zich te concentreren op zijn enge begrip van privacy. Maar wanneer het wordt geconfronteerd met de veelheid aan privacyproblemen die gepaard gaan met het verzamelen en gebruiken van overheidsgegevens buiten bewaking en openbaarmaking, het niets-te-verbergen-argument, heeft uiteindelijk niets te zeggen. "

3. Adam D. Moore, auteur van Privacy Rights: Moral and Legal Foundations, betoogde, "het is de opvatting dat rechten bestand zijn tegen kosten / baten of consequentialistische argumenten. Hier verwerpen we de opvatting dat privacybelangen de soorten zijn. van dingen die kunnen worden verhandeld voor zekerheid. " Hij verklaarde ook dat surveillance onevenredige gevolgen kan hebben voor bepaalde groepen in de samenleving op basis van uiterlijk, etniciteit, seksualiteit en religie.

4. Bruce Schneier, een computerbeveiligingsexpert en cryptograaf, uitte zijn verzet, daarbij verwijzend naar de verklaring van kardinaal Richelieu: "Als iemand me zes regels zou geven die zijn geschreven door de hand van de meest eerlijke man, zou ik er iets in vinden om hem op te hangen", verwijzend naar hoe een deelstaatregering aspecten in iemands leven kan vinden om die persoon te vervolgen of te chanteren. Schneier voerde ook aan: "Te veel mensen typeren het debat ten onrechte als 'veiligheid versus privacy'. ' De echte keuze is vrijheid versus controle. "

5. Harvey A. Silverglate schatte dat de gewone persoon in de VS gemiddeld zonder het te weten drie misdrijven per dag pleegt.

6. Emilio Mordini, filosoof en psychoanalyticus, voerde aan dat het 'niets te verbergen'-argument inherent paradoxaal is. Mensen hoeven niet "iets te verbergen" te hebben om "iets" te verbergen. Wat verborgen is, is niet per se relevant, stelt Mordini. In plaats daarvan betoogt hij dat een intiem gebied dat zowel verborgen kan zijn als beperkt toegankelijk is, noodzakelijk is omdat we psychologisch gezien individuen worden door de ontdekking dat we iets voor anderen zouden kunnen verbergen.

7. Julian Assange verklaarde: "Er is nog geen killer-antwoord. Jacob Appelbaum (@ioerror) heeft een slimme reactie en vraagt ​​mensen die dit zeggen om hem hun telefoon ontgrendeld te geven en hun broek naar beneden te trekken. Mijn versie daarvan is te zeggen, 'nou, als je zo saai bent, dan zouden we niet met je moeten praten, en ook niet met iemand anders', maar filosofisch gezien is het echte antwoord dit: massasurveillance is een massale structurele verandering. om je mee te nemen, zelfs als je de flauwste persoon op aarde bent. "

8. Ignacio Cofone, hoogleraar rechten, stelt dat het argument in zijn eigen bewoordingen onjuist is, omdat, telkens wanneer mensen relevante informatie aan anderen onthullen, ze ook irrelevante informatie onthullen. Deze irrelevante informatie brengt privacykosten met zich mee en kan leiden tot andere schade, zoals discriminatie.

***

# Alternatieve methoden

Media mogen niet worden beperkt, online of offline. Als mensen de video zonder DRM willen bekijken, zullen ze altijd een manier vinden om het te doen. Elk stukje software kan worden gekraakt.

[aangepast fragment van Wikipedia] Valve-president Gabe Newell heeft verklaard dat "de meeste DRM-strategieën gewoon dom zijn" omdat ze de waarde van een spel in de ogen van de consument alleen maar verminderen. Newell suggereert dat het doel in plaats daarvan zou moeten zijn "[creëren] meer waarde voor klanten door middel van servicewaarde". Merk op dat Valve Steam beheert, een service die dient als een online winkel voor pc-games, evenals een sociale netwerkdienst en een DRM-platform

Dit punt is niet alleen geldig voor videogames, het kan op alles op een computer worden toegepast. Je computer zou niet de volledige controle moeten hebben over een gek bedrijf dat slechte kunstmatige intelligentie gebruikt om zijn gebruikers en hun werk (YouTube, enz.) Te verwijderen en zo'n slechte staat van dienst heeft. Uw computer mag niet worden beperkt omdat een bedrijf weigert te delen als een slecht opgevoed kind. Uw computer moet uw eigendom zijn,en niemand anders. U moet DRM helemaal verwijderen, aangezien de inhoud het niet waard is om de controle over uw computer op te geven. Deze bedrijven hebben honderden miljarden dollars. Als ze zoiets stoms doen, moet je ertegen protesteren. Je zou de video zelfs ergens anders kunnen downloaden en bekijken, want ze zouden geld moeten verliezen door domme dingen zoals deze te doen. Schending van het auteursrecht is geen slechte zaak. Mensen die zich geen films kunnen veroorloven, zullen ze elders downloaden, dit gebeurt al sinds het begin van het wereldwijde internet en met de uitvinding van de VHS-tape. Het heeft nauwelijks invloed op hun inkomsten, want dat geld zouden ze toch niet kunnen krijgen. DRM is door het ontwerp defect.

***

## Wat u kunt doen om te helpen

U kunt tegen DRM protesteren. Het lijkt misschien onbeduidend, maar hoe meer mensen ertegen ingaan, hoe meer er aan wordt gedaan.

Als u Linux gebruikt en Firefox gebruikt, zorg er dan voor dat DRM niet is geïnstalleerd (dit is normaal gesproken niet standaard) en neem geen moeite om het te installeren.

Als u Windows of MacOS gebruikt, heeft u het misschien veel moeilijker, aangezien DRM standaard op deze systemen is geïnstalleerd en mogelijk automatisch opnieuw wordt geïnstalleerd.

Probeer de volgende sites te vermijden:

[Hulu] (https://hulu.com)

[Disney +] (https://www.disneyplus.com/)

[Paramount +] (https://www.paramountplus.com/)

Kortom, bijna elke online videostreamingservice moet worden vermeden, aangezien de meerderheid van hen DRM gebruikt en u de site niet kunt gebruiken zonder uw vrijheid te verliezen. Het is het niet waard. Stuur de [MPAA] (https://en.wikipedia.org/wiki/Motion_Picture_Association) een bericht en stop met het streamen van deze shows.

U moet ook alle 'gratis met advertenties'-opties op de volgende sites vermijden (aangezien deze methode DRM vereist)

[YouTube] (https://www.youtube.com)

U kunt DRM ook protesteren met een bericht in het bestand README.md van uw projecten. Hier is wat ik gebruik:

`` prijsverlaging

***

## Softwarestatus

Al mijn werken zijn gratis, sommige beperkingen. DRM (** D ** igital ** R ** beperkingen ** M ** anagement) is in geen van mijn werken aanwezig.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Deze sticker wordt ondersteund door de Free Software Foundation. Ik ben nooit van plan DRM in mijn werken op te nemen.

Ik gebruik de afkorting "Digital Restrictions Management" in plaats van het meer bekende "Digital Rights Management", aangezien de gebruikelijke manier om dit aan te pakken onjuist is, er zijn geen rechten met DRM. De spelling "Digital Restrictions Management" is nauwkeuriger en wordt ondersteund door [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) en de [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Dit gedeelte wordt gebruikt om mensen bewust te maken van de problemen met DRM, en ook om ertegen te protesteren. DRM is defect door ontwerp en vormt een grote bedreiging voor alle computergebruikers en softwarevrijheid.

Afbeeldingskrediet: [defectivebydesign.org/drm-free/... ](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

''

***
## Andere dingen om uit te checken

[Defect by design - Een campagne van de Free Software Foundation die werkt aan het blootleggen en elimineren van DRM-gebruik] (https://www.defectivebydesign.org/)

[The Google Graveyard (Killbygoogle.com) - een gesorteerde lijst van de 224+ producten die Google heeft vermoord] (https://killedbygoogle.com/)

> [GitHub-link] (https://github.com/codyogden/killedbygoogle)

[Alfabet arbeidersvakbond - De nieuwe vakbond bij Google met meer dan 800 leden] (https://alphabetworkersunion.org/people/our-union/)

Er zijn andere alternatieven, zoek ze gewoon.

***

## Artikel info

Bestandstype: `Markdown (* .md)`

Bestandsversie: `4 (vrijdag 23 april 2021 om 15:35 uur)`

Aantal regels (inclusief lege regels en compilerregel): `354`

### Softwarestatus

Al mijn werken zijn vrij van beperkingen. DRM (** D ** igital ** R ** beperkingen ** M ** anagement) is in geen van mijn werken aanwezig. Dit project bevat geen DRM, maar er wordt direct over DRM gesproken.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Deze sticker wordt ondersteund door de Free Software Foundation. Ik ben nooit van plan DRM in mijn werken op te nemen.

***

### Info sponsor

! [SponsorButton.png] (SponsorButton.png) <- Dit is niet de officiële sponsorknop, het is een demo-afbeelding. Klik er niet op als u dit project wilt sponsoren.

U kunt dit project sponsoren als u dat wilt, maar geef aan waaraan u wilt doneren. [Bekijk hier het geld dat u kunt doneren] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

U kunt andere sponsorinformatie [hier] bekijken (https://github.com/seanpm2001/Sponsor-info/)

Probeer het! De sponsorknop bevindt zich direct naast de watch / unwatch-knop.

***

## Bestandsgeschiedenis

Versie 1 (zondag 8 februari 2021 om 16:41 uur)

> Veranderingen:

> * Startte het bestand / artikel

> * De titelsectie toegevoegd

> * Een sectie toegevoegd over privacy

> * Een sectie toegevoegd over het overzicht

> * De artikelinfo-sectie toegevoegd

> * Verwijst naar het DRM Free-pictogram

> * De sectie bestandsgeschiedenis toegevoegd

> * De sectie Gebrek aan vrijheid toegevoegd

> * De sectie concurrentiebeperking toegevoegd

> * De sectie alternatieve methoden toegevoegd

> * Memo toegevoegdry gebruiksgedeelte

> * De andere dingen toegevoegd om uit te checken sectie

> * Toegevoegd de index

> * Voettekst toegevoegd

> * Geen andere wijzigingen in versie 1

Versie 2 (donderdag 8 april 2021 om 17:18 uur)

> Veranderingen:

> * De titelsectie bijgewerkt

> * Bijgewerkt de index

> * Informatie toegevoegd over wat u kunt doen om te helpen

> * De sponsor info sectie toegevoegd

> * De bestandsinfo-sectie bijgewerkt

> * De sectie bestandsgeschiedenis bijgewerkt

> * Geen andere wijzigingen in versie 2

Versie 3 (donderdag 8 april 2021 om 17:27 uur)

> Veranderingen:

> * Vaste vertalingslinks

> * Bijgewerkt de index

> * Een duplicaat, niet op het onderwerp gericht item in de sectie `wat u kunt doen om te helpen 'opgelost

> * Het gedeelte met informatie over de sponsor bijgewerkt

> * De bestandsinfo-sectie bijgewerkt

> * De sectie bestandsgeschiedenis bijgewerkt

> * Geen andere wijzigingen in versie 3

Versie 4 (vrijdag 23 april 2021 om 15:35 uur)

> Veranderingen:

> * De lijst met taalwisselaars bijgewerkt

> * De bestandsinfo-sectie bijgewerkt

> * De sectie bestandsgeschiedenis bijgewerkt

> * Geen andere wijzigingen in versie 4

Versie 5 (binnenkort beschikbaar)

> Veranderingen:

> * Binnenkort beschikbaar

> * Geen andere wijzigingen in versie 5

Versie 6 (binnenkort beschikbaar)

> Veranderingen:

> * Binnenkort beschikbaar

> * Geen andere wijzigingen in versie 6

Versie 7 (binnenkort beschikbaar)

> Veranderingen:

> * Binnenkort beschikbaar

> * Geen andere wijzigingen in versie 7

Versie 8 (binnenkort beschikbaar)

> Veranderingen:

> * Binnenkort beschikbaar

> * Geen andere wijzigingen in versie 8

***

## Voettekst

U heeft het einde van dit bestand bereikt!

##### EOF

***
