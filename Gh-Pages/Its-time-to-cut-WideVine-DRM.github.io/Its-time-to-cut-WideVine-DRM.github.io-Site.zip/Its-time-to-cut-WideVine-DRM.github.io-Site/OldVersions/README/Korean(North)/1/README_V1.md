
***

# Why North Korea?

I live in hopes that someday in the future, Korea will unite again. However, North Korea has their own version of the Korean language family, and it should be respected, as we need to be as ready as possible, because due to differences in the South and North variants of the Korean language, there is expected to be hostility that will occur when Korea reunites. Knowing history, there will be a lot of discrimination from South Koreans against North Koreans, and vice versa.

_Is this paragraph written in proper English syntax?_ - Currently I think it is, but I might be wrong, as I thought it wasn't yesterday before I made todays edits, which didn't change what I thought was wrong yesterday.

## Translation not available yet

There currently is no point in making a North Korean translation, as there are `0` GitHub users in North Korea, but I have to keep the opportunity open to when/if it happens.

### Then what is the current translation?

Just so the file would be ready, I translated Version 4 of the document and placed it here. The translation is in South Korean, not North Korean.

***
