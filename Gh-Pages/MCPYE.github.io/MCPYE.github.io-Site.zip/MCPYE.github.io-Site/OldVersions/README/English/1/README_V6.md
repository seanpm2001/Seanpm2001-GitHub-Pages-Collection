
***

# MCPYE

A free and open source recreation of the popular game Minecraft, with more functionality and more features. Codenamed Minecraft Python Edition (not the official name)

**old description**

## ABOUT
**MINECRAFT2/MINECRAFT PYTHON EDITION/PYCRAFT**

***

[UNTITLED](https://github.com/seanpm2001/MCPYE/) is a game based on Minecraft that offers loads of improvements over the Microsoft versions. These versions are free and open source, and are free of microtransactions, and Microsoft

***

## Pros of MC PYE

***

▪ it is written in Python, so it is a lot lighter
**Example:**

***

1. Java Hello World program 5-10 lines
2. Python Hello World program 1-2 lines
1. Open source
2. It is like Minecraft but with every good mod installed and functional
3. Not owned by Microsoft, this is either a pro or a con depending on how you look at it
4. Thousands of features
5. Works online/offline
6. Game files are easy to modify and changable by all
7. Thousands of features

***

Now over 2000 blocks/mobs/items total

**More codenames**

***

1. • Minecraft Python Edition
2. • Pycraft
3. • Minecraft 2
4. • Pymine
5. • Python Super Sandbox

***

## Development progress

I decided to create a GitHub repository for this project on May 25th 2020, so that I could have help developing this project.
I would have just uploaded the repository, but I needed to make some changes to the file structure. I also wanted to document
it better.
As of 4:25 pm on May 26th 2020, I have added in all the files from my local repository, and I will begin working on changes soon

***

## Current contributers

1. [owner - Seanpm2001](https://github.com/seanpm2001/) - 149 commits (As of Thursday, June 18th 2020 at 11:20 pm)

2. [Channa-my](https://github.com/Channa-my) - 1 commit (As of Thursday, June 18th 2020 at 11:20 pm)

3. No other contributers at the moment

***

## Contributing rules

[Main article: Contributing.md](https://github.com/seanpm2001/MCPYE/Contributing.md)

**Do not modify version files.**

Files ending with V and a number are separate archived versions of a program. They are complete, and should not be modified.
Always make sure to copy your changes to a new version file after you make each commit.

### Other Commit rules:

1. ¤ Don't modify files with a version number at the end of them

2. ¤ Create a separate file for each revision

3. ¤ No excessive unnecessary profanity in commits (only 1 unnecessary swear allowed)

4. ¤ Program must be as light as possible with all features

5. ¤ Source code must be documented

6. ¤ Python files must begin with #start of script and end with #end of script (this might get deprecated)

7. ¤ Program cannot mine personal data, or set trackers

**No other rules currently available**

***

## About local repository

_a local repository for this project has been in development since Wednesday, July 17th 2019. It has been moved to GitHub on May 25th 2020, where I can manage it better._

**There are still some files and folders that need to be moved over**

***

## Version history

1. Version 0.0.1.0 [pre-release] - Marks the full conversion of all Python data from the offline local repository to the online GitHub repository. Still highly incomplete. **_released May 26th 2020_** [commit count: 124]

2. Version 0.0.1.1 [pre-release] - coming soon [commit count: 125, 1 total commit for this release]

3. Other future releases not yet listed

Readme version: 6 (Thursday, June 18th 2020, 11:20 pm)

***

# End of ReadMe
Blank space for compiler below this line:

***
