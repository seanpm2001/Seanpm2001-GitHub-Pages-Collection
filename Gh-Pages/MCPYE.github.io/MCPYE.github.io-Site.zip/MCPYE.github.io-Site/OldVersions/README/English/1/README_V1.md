# MCPYE
A free and open source recreation of the popular game Minecraft, with more functionality and more features. Codenamed Minecraft Python Edition (not the official name)

# old description
ABOUT
MINECRAFT2/MINECRAFT PYTHON EDITION/PYCRAFT

[UNTITLED] is a game based on Minecraft that offers loads of improvements over the Microsoft versions. These versions are free and open source, and are free of microtransactions, and Microsoft

Pros of MC PYE
▪Written in Python, so it is a lot lighter
Ex:
Java Hello World program 5-10 lines
Python Hello World program 1-2 lines
▪Open source
▪It is like Minecraft but with every good mod installed and functional
▪Not owned by Microsoft
▪Thousands of features
▪Works online/offline
▪Game files are easy to modify and changable by all
▪Thousands of features
Now over 2000 blocks/mobs/items total
More codenames
• Minecraft Python Edition
• Pycraft
• Minecraft 2
• Pymine
• Python Super Sandbox
