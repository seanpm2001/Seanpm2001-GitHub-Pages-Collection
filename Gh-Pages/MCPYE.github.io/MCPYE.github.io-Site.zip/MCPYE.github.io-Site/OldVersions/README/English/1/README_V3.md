# MCPYE
A free and open source recreation of the popular game Minecraft, with more functionality and more features. Codenamed Minecraft Python Edition (not the official name)

old description
-----------
# ABOUT
MINECRAFT2/MINECRAFT PYTHON EDITION/PYCRAFT
-----------
---
[UNTITLED] is a game based on Minecraft that offers loads of improvements over the Microsoft versions. These versions are free and open source, and are free of microtransactions, and Microsoft
---
# Pros of MC PYE
---
▪ it is written in Python, so it is a lot lighter
Example:
-----------
1. Java Hello World program 5-10 lines
2. Python Hello World program 1-2 lines
1. ▪Open source
2. ▪It is like Minecraft but with every good mod installed and functional
3. ▪Not owned by Microsoft
4. ▪Thousands of features
5. ▪Works online/offline
6. ▪Game files are easy to modify and changable by all
7. ▪Thousands of features
---
Now over 2000 blocks/mobs/items total
*More codenames
---
1. • *Minecraft Python Edition
2. • *Pycraft
3. • *Minecraft 2
4. • *Pymine
5. • *Python Super Sandbox
---

# Development progress

I decided to create a GitHub repository for this project on May 25th 2020, so that I could have help developing this project.
I would have just uploaded the repository, but I needed to make some changes to the file structure. I also wanted to document
it better.
As of 4:25 pm on May 26th 2020, I have added in all the files from my local repository, and I will begin working on changes soon

# Current contributers

1. [owner] Seanpm2001 - 123 commits (As of 5:02 pm, May 26th 2020)
2. Channa-my - 0 commits (As of 5:02 pm, May 26th 2020)

# Rules

Do not modify version files.
-----------
Files ending with V and a number are separate archived versions of a program. They are complete, and should not be modified.
Always make sure to copy your changes to a new version file after you make each commit.

No other rules currently available
-----------

# End of ReadMe
