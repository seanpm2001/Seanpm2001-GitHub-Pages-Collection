---

# `README.md`

---

# SNU_2D_DennisRitchieMemorial
A memorial center for Dennis Ritchie, the grandfather of  UNIX, B, BCPL, ALTRAN, and Multics. One of the most underrated people in the history of computing.

---

# About

See above

---

# Wiki

[Click/tap here to view this projects Wiki](https://github.com/seanpm2001/SNU_2D_DennisRitchieMemorial/wiki)

---

# Version history

This section is coming soon

---

# Contributers

Currently, I am the only contributer.

> * 1. [seanpm2001](https://github.com/seanpm2001/) - 10 commits (As of Thursday, June 4th 2020 at 3:13 pm)

> * 2. No other contributers at the moment

> * 3. Contributer slot 3

> * 4. Contributer slot 4

> * 5. Contributer slot 5

> * 6. Contributer slot 6

> * 7. Contributer slot 7

> * 8. Contributer slot 8

> * 9. Contributer slot 9

> * 10. Contributer slot 10

---

# About README.md

File type: `Markdown (*.md)`

File version: `1 (Thursday, June 4th 2020 at 3:13 pm)`

Line count: `0,069`

---

## You have reached the end of the README file

---
