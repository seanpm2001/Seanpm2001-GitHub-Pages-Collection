# Start of script
# I have decided to have the second project language for this project (uOffice) be Python, as Python is a good language to use for this purpose, as I prefer its usage. I don't know of any open source office suites like this written in Python, so it is also a first. It will be supplemented with other languages as well. It is also the main language used in the original uOffice project.
''' '''
class projectLanguageFileTwo()
print("Project Language File 2\n")
print("For: uOffice/uOffice.github.io")
print("I have decided to have the second project language for this project (uOffice) be Python, as Python is a good language to use for this purpose, as I prefer its usage. I don't know of any open source office suites like this written in Python, so it is also a first. It will be supplemented with other languages as well. It is also the main language used in the original uOffice project.")
noMore = input("Press [ENTER] key to quit")
print("The program should now be closed. If the program is still running, try closing the window with the close button. If this doen't work, end the task/process with a task/process manager")
break
""" """
# File info
# File version: 1 (Thursday, 2021 October 21st at 5:31 pm)
# File type: Python 3 source file (*.py)
# Line count (including blank lines and compiler line): 17
# End of script
