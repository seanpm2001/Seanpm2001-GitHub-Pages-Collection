
***

# Source projects

## YKDefender website

This project has 2 source projects:

- 1. [YKDefender](https://github.com/seanpm2001/YKDefender/) - The general place for the YKDefender script kit

- 2. [YKDefenderVM](https://github.com/seanpm2001/YKDefenderVM/) - A specialized virtual machine for correcting the Y2K, Y2K38, and other time related bugs within the operating system you want to virtualize.

***
