
***

# /OldVersions/

This directory contains old versions of template root pages for this template project.

## Pages

( [404 pages](/OldVersions/404/) | [404.htm (at root)](/404.htm) - [404.md (at root)](/404.md) )

( [CONTRIBUTING.md](/OldVersions/CONTRIBUTING/) | [CONTRIBUTING.md (at root)](/CONTRIBUTING.md) )

( [LICENSE.txt](/OldVersions/LICENSE/GPL3/) | [LICENSE.txt (at root)](/LICENSE.txt) )

( [README.md (English, root)](/OldVersions/README/English/1/) | [README.md (at root)](/README.md) )

( [SECURITY_INCIDENTS.md](/OldVersions/SECURITY_INCIDENTS/1/1-100/) | [SECURITY_INCIDENTS.md (at root)](/SECURITY_INCIDENTS.md) )

( [README.md (/OldVersions/)](/README_OLDVERSIONS/1/1-100/) )

***
