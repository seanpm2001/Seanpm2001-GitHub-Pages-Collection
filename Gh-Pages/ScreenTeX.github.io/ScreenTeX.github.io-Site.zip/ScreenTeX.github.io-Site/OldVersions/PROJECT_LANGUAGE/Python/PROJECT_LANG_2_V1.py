# Start of script
# I have decided to have the second project language for this project (ScreenTeX.github.io) be Python, as although the website is not written in Python, the project it is hosting relies heavily on the language.
''' '''
class projectLanguageFileOne()
print("Project Language File 2\n")
print("For: ScreenTeX.github.io")
print("I have decided to have the second project language for this project (ScreenTeX.github.io) be Python, as although the website is not written in Python, the project it is hosting relies heavily on the language.")
noMore = input("Press [ENTER] key to quit")
print("The program should now be closed. If the program is still running, try closing the window with the close button. If this doen't work, end the task/process with a task/process manager")
break
""" """
# File info
# File version: 1 (Tuesday, 2021 September 21st at 4:16 pm)
# File type: Python 3 source file (*.py)
# Line count (including blank lines and compiler line): 17
# End of script
