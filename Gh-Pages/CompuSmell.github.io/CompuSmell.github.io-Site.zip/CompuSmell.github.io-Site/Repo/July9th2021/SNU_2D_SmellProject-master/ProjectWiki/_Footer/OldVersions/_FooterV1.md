
***

# SNU 2D Smell project module - Project Wiki (Footer)

***

## Info

SNU - `2018-2020`

SNU 2D Smell project Module - `February 27th 2020-2020`

***

Footer version: `1 (Sunday, June 28th 2020 at 4:30 pm)`

### End of footer

***
