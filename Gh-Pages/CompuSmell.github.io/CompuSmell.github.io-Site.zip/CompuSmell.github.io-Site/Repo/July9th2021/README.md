
***

# Source repositories

## As of July 9th 2021

The source repositories will be used as a reference for this site. The following directory contains an archive of them (minus the `.github` folder) as of July 9th 2021, as they are very small.

## Credits (to myself)

1. [SNU_2D_CompuSmell](https://github.com/seanpm2001/SNU_2D_CompuSmell/)

2. [SNU_2D_SmellProject](https://github.com/seanpm2001/SNU_2D_SmellProject)

***
