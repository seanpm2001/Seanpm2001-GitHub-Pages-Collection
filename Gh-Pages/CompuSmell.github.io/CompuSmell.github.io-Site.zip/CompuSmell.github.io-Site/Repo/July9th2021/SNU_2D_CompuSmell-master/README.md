
***

### Top

# SNU_2D_CompuSmell
The SNU CompuSmell project module for 2D mode. Research for a future where computers can omit odor. This module currently isn't required for your SNU distribution. [Click/tap here to learn how to build SNU](https://gist.github.com/seanpm2001/745564a46186888e829fdeb9cda584de)

***

# README Index

[00.0 - Title](#SNU_2D_CompuSmell)

[01.0 - README Index](#README-Index)

[02.0 - About](#About)

[03.0 - Project Wiki](#Project-Wiki)

[04.0 - Version history](#Version-history)

[05.0 - Contributers](#Contributers)

[06.0 - Contributing](#Contributing)

[07.0 - README info](#README-info)

[08.0 - Footer](#End-of-README-file)

***

# About

See above

***

## Project Wiki

[Click/tap here to view this projects Wiki](https://github.com/seanpm2001/SNU_2D_CompuSmell/Wiki/)

***

## Version history

Unavailable

[More versions coming soon](https://www.example.com/)

***

## Contributers

Currently, I am the only contributer, but if you follow ther CONTRIBUTING rules, you can contribute as well.

1. [seanpm2001](https://github.com/seanpm2001/) - 18 commits (As of Saturday, June 27th 2020 at 12:23 am)

2. No other contributers at the moment

***

## Contributing

Please abide by the contributing rules for this project. They are listed [here.](https://github.com/seanpm2001/SNU_2D_CompuSmell/blob/master/CONTRIBUTING.md)

***

## README info

File type: `Markdown (*.md)`

Line count (including blank lines): `84`

File version: `1 (Saturday, June 27th 2020 at 12:13 am)`

***

### End of README file

( [Back to top](#Top) | [Exit](https://github.com) )

***
