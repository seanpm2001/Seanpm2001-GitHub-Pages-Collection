
***

# About the ProjectWiki directory

The ProjectWiki directory is a directory that contains markup copies of the GitHub project Wiki. This directory normally is not a main or original part of the project, but its purpose is archiving the project Wiki.

That is pretty much it.

***
