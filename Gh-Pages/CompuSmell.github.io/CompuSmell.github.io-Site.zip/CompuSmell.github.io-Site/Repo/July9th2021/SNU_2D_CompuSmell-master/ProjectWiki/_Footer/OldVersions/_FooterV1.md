
***

# SNU 2D CompuSmell Project Wiki footer

***

## Info

SNU - `2018-2020`

SNU 2D CompuSmell - `2020-2020`

***

Footer version: `1 (Saturday, June 27th 2020 at 12:14 am)`

### End of footer

***
