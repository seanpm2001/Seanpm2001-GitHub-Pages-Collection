***

！[DoorCrete.jpeg]（/ DoorCrete.jpeg）

＃门卫
Doorcrete目前只是一个概念：Doorcrete分解监视/遥测后门，并用二元混凝土填充它们。

***

_以另一种语言阅读本文：_

**当前语言是：**`英语（美国）`_（翻译可能需要更正以修复英语，以替换正确的语言）_

_🌐语言列表_

**排序：**`A-Z`

[排序选项不可用]（https://github.com/Doorcrete）

（[af Afrikaans]（/。github / README_AF.md）Afrikaans | [sq Shqiptare]（/。github / README_SQ.md）阿尔巴尼亚语| [amአማርኛ]（/。github / README_AM.md）Amharic | [arعربى] （/.github/README_AR.md）阿拉伯语| [hyհայերեն]（/。github / README_HY.md）亚美尼亚语| [azAzərbaycandili]（/。github / README_AZ.md）阿塞拜疆| [eu Euskara]（/。github /README_EU.md）巴斯克语| [beБеларуская]（/。github / README_BE.md）白俄罗斯语| [bnবাংলা]（/。github / README_BN.md）孟加拉语| [bs Bosanski]（/。github / README_BS.md）波斯尼亚语| [bgбългарски]（/。github / README_BG.md）保加利亚语| [caCatalà]（/。github / README_CA.md）加泰罗尼亚语| [ceb Sugbuanon]（/ .. github / README_CEB.md）Cebuano | [ny Chichewa ]（/。github / README_NY.md）Chichewa | [zh-CN简体中文]（/。github / README_ZH-CN.md）简体中文| [zh-t中国传统的）]（/。github / README_ZH -T.md）中文（繁体）| [co Corsu]（/。github / README_CO.md）科西嘉语| [hr Hrvatski]（/。github / README_HR.md）克罗地亚语| [csčeština]（/。github / README_CS .md）捷克语| [da dansk]（README_DA.md）丹麦语| [nl Nederlands]（/。github / README_ NL.md）荷兰语| [** zh-cn英语**]（/。github / README.md）英语| [EO世界语]（/。github / README_EO.md）世界语| [et Eestlane]（/。github / README_ET.md）爱沙尼亚语| [tl Pilipino]（/。github / README_TL.md）菲律宾| [fi Suomalainen]（/。github / README_FI.md）芬兰语| [frfrançais]（/。github / README_FR.md）法语| [fy Frysk]（/。github / README_FY.md）弗里斯兰语| [gl Galego]（/。github / README_GL.md）加利西亚语| [kaქართველი]（/。github / README_KA）格鲁吉亚语| [de Deutsch]（/。github / README_DE.md）德语| [elΕλληνικά]（/。github / README_EL.md）希腊语| [guગુજરાતી]（/。github / README_GU.md）古吉拉特语| [htKreyòlayisyen]（/。github / README_HT.md）海地克里奥尔语| [ha Hausa]（/。github / README_HA.md）Hausa | [hawŌleloHawaiʻi]（/。github / README_HAW.md）夏威夷语| [heעִברִית]（/。github / README_HE.md）希伯来语| [hiहिन्दी]（/。github / README_HI.md）印地语| [hmn Hmong]（/。github / README_HMN.md）Hmong | [hu Magyar]（/。github / README_HU.md）匈牙利语| [是Íslenska]（/。github / README_IS.md）冰岛语| [ig Igbo]（/。github / README_IG.md）Igbo | [id bahasa Indonesia]（/。github / README_ID.md）冰岛语| [ga Gaeilge]（/。github / README_GA.md）爱尔兰语| [it Italiana / Italiano]（/。github / README_IT.md）| [ja日本语]（/。github / README_JA.md）日语| [jw Wong颌骨]（/。github / README_JW.md）Javanese | [knಕನ್ನಡ]（/。github / README_KN.md）卡纳达语| [kkҚазақ]（/。github / README_KK.md）哈萨克语| [kmខ្មែរ]（/。github / README_KM.md）高棉语| [rw Kinyarwanda]（/。github / README_RW.md）Kinyarwanda | [ko-south韩国语]（/。github / README_KO_SOUTH.md）韩语（南）| [ko-north문화어]（README_KO_NORTH.md）朝鲜语（北部）（尚未翻译）| [kuKurdî]（/。github / README_KU.md）库尔德语（Kurmanji）| [kyКыргызча]（/。github / README_KY.md）吉尔吉斯语| [loລາວ]（/。github / README_LO.md）老挝| [la Latine]（/。github / README_LA.md）拉丁语| [lt Lietuvis]（/。github / README_LT.md）立陶宛语| [lbLëtzebuergesch]（/。github / README_LB.md）卢森堡语| [mkМакедонски]（/。github / README_MK.md）马其顿语| [mg马达加斯加语]（/。github / README_MG.md）马达加斯加语| [ms Bahasa Melayu]（/。github / README_MS.md）马来语| [mlമലയാളം]（/。github / README_ML.md）马拉雅拉姆语| [mt Malti]（/。github / README_MT.md）马耳他语| [mi Maori]（/。github / README_MI.md）毛利人| [mrमराठी]（/。github / README_MR.md）马拉地语| [mnМонгол]（/。github / README_MN.md）蒙古语| [myမြန်မာ]（/。github / README_MY.md）缅甸（缅甸）| [neनेपाली]（/。github / README_NE.md）尼泊尔语| [no norsk]（/。github / README_NO.md）挪威文| [或ଓଡିଆ（ଓଡିଆ）]（/。github / README_OR.md）Odia（奥里亚语）| [psپښتو]（/。github / README_PS.md）普什图语| [faفارسی]（/。github / README_FA.md）|波斯语[pl polski]（/。github / README_PL.md）波兰语| [ptportuguês]（/。github / README_PT.md）葡萄牙语| [paਪੰਜਾਬੀ]（/。github / README_PA.md）旁遮普语|没有可用字母Q |开头的语言。 [roRomână]（/。github / README_RO.md）罗马尼亚语| [ruрусский]（/。github / README_RU.md）俄语| [sm Faasamoa]（/。github / README_SM.md）萨摩亚语| [gdGàidhligna h-Alba]（/。github / README_GD.md）Scots Gaelic | [srСрпски]（/。github / README_SR.md）塞尔维亚语| [st Sesotho]（/。github / README_ST.md）Sesotho | [sn Shona]（/。github / README_SN.md）Shona | [sdسنڌي]（/。github / README_SD.md）信德语| [siසිංහල]（/。github / README_SI.md）僧伽罗语| [sk斯洛伐克语]（/。github / README_SK.md）斯洛伐克语| [slSlovenščina]（/。github / README_SL.md）斯洛文尼亚语| [so Soomaali]（/。github / README_SO.md）索马里文| [[es enespañol]（/。github / README_ES.md）西班牙语| [su Sundanis]（/。github / README_SU.md）Sundanese | [sw Kiswahili]（/。github / README_SW.md）斯瓦希里语| [sv Svenska]（/。github / README_SV.md）瑞典语| [tgТоҷикӣ]（/。github / README_TG.md）塔吉克语| [taதமிழ்]（/。github/README_TA.md）泰米尔语| [ttТатар]（/。github / README_TT.md）塔塔尔语| [teతెలుగు]（/。github / README_TE.md）泰卢固语| [thไทย]（/。github / README_TH.md）泰国语| [trTürk]（/。github / README_TR.md）土耳其语| [tkTürkmenler]（/。github / README_TK.md）土库曼人| [ukУкраїнський]（/。github / README_UK.md）乌克兰语| [urاردو]（/。github / README_UR.md）乌尔都语| [ugئۇيغۇر]（/。github / README_UG.md）维吾尔语| [uz O'zbek]（/。github / README_UZ.md）乌兹别克语| [viTiếngViệt]（/。github / README_VI.md）越南语| [cy Cymraeg]（/。github / README_CY.md）威尔士语| [xh isiXhosa]（/。github / README_XH.md）Xhosa | [yiיידיש]（/。github / README_YI.md）意第绪语| [yo Yoruba]（/。github / README_YO.md）Yoruba | [zu Zulu]（/。github / README_ZU.md）Zulu）支持110种语言（不算英语和朝鲜语时为108种语言，因为朝鲜语尚未翻译[请在此处阅读] [/ OldVersions / Korean（North ）/README.md））

除英语以外的其他语言的翻译是机器翻译的，尚不准确。截至2021年2月5日，尚未修复错误。请在此处报告翻译错误[https://github.com/seanpm2001/Degoogle-your-life/issues/）确保备份您的更正并提供指导，因为我不太懂英语（我打算最终聘请翻译）以外的语言，所以请在报告中引用[wiktionary]（https://en.wiktionary.org）和其他来源。否则，将拒绝发布更正。

注意：由于GitHub对markdown的解释（以及几乎所有其他基于Web的markdown解释）的限制，单击这些链接会将您重定向到另一个页面上的单独文件，该页面不是我的GitHub个人资料页面。您将被重定向到托管README的[seanpm2001 / seanpm2001存储库]（https://github.com/seanpm2001/seanpm2001）。

由于我在其他翻译服务（如DeepL和Bing Translate（对于反Google类型的项目而言颇具讽刺意味））中需要的语言有限或不支持，因此使用Google Translate进行翻译。我正在寻找替代方案。由于某种原因，格式（链接，分隔符，粗体，斜体等）在各种翻译中都被弄乱了。解决起来很麻烦，而且我不知道如何使用非拉丁字符的语言来解决这些问题，从右到左的语言（如阿拉伯语）需要额外的帮助来解决这些问题。

由于维护问题，许多翻译版本已经过时，并且使用的是本“ README”文章文件的过时版本。需要翻译器。另外，从2021年4月9日开始，要使所有新链接正常工作还需要一段时间。

***

＃ 指数

[00.0-页首]（＃Top）

> [00.1-标题]（＃Doorcrete）

> [00.2-用另一种语言阅读本文]（＃Read-this-article-in-a-language语言）

> [00.3-索引]（＃Index）

[01.0-可能]（＃可能）

[02.0-遥测移除]（＃遥测移除）

[03.0-后门删除]（＃Backdoor-removal）

[04.0-说明]（＃Doorcrete）

[05.0-关于]（＃About）

[06.0-Wiki]（＃Wiki）

[07.0-版本历史]（＃Version-history）

[08.0-软件状态]（＃Software-status）

[09.0-赞助商信息]（＃Sponsor-info）

[10.0-贡献者]（＃贡献者）

[11.0-问题]（＃问题）

> [11.1-当前问题]（＃当前问题）

> [11.2-过去的问题]（＃过去的问题）

> [11.3-过去的拉取请求]（＃Past-pull-requests）

> [11.4-活动请求请求]（＃Active-pull-requests）

[12.0-资源]（＃Resources）

[13.0-贡献]（＃贡献）

[14.0-关于自述文件]（＃About-README）

[15.0-自述版本历史记录]（＃README-version-history）

[16.0-页脚]（＃您已到达自述文件的结尾）

> [16.1-文件结束]（＃EOF）

***

##有可能

后门并非完全像这样工作，但可以填充/移除后门。

Doorcrete会删除混合源软件（当开放源包含专有元素时）以及通用开放源软件上的后门。使用专有软件很难。

##遥测移除

Doorcrete可以删除以下情况的遥测：

* Audacity（即将发布的未来版本3.0.2预计将包含Google遥测，并且对该产品的抵制开始增长-2021年5月6日）

* Ubuntu 12.04 LTS / 12.10及更高版本

* GNOME（可能不包含遥测）

* Firefox（包含可选的遥测）

* 和更多

##后门移除

后门将被“用二进制混凝土填充”（遥测部分将被删除，并被具有相似功能的相同大小的二进制数据均等地替换，因此不会检测到后门爱好者以创建后门的方式对其进行了修改。

##说起来容易做起来难

同样，这只是一个概念。可能无法从软件中完全删除遥测和后门，如果确实如此，那肯定不容易。现在，您可以尝试使该软件脱离您的生活，并获得更好的隐私。

***

***

＃＃ 关于

参见上面和下面。

***

##维基

[单击/点击此处以查看此项目Wiki]（https://github.com/seanpm2001/Doorcrete/wiki）

如果项目有被分叉后，Wiki可能已被删除。幸运的是，我包含一个嵌入式版本。您可以在[此处]（/ External / ProjectWiki /）进行查看。

***

##赞助商信息

！[SponsorButton.png]（SponsorButton.png）

您可以根据需要赞助此项目，但请指定您要捐赠的内容。 [在这里查看您可以捐赠的资金]（https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors）

您可以在此处查看其他赞助商信息（https://github.com/seanpm2001/Sponsor-info/）

试试看！赞助商按钮在观看/取消观看按钮旁边。

***

##版本历史

**当前版本历史不可用**

**未列出其他版本**

***

##软件状态

我所有的作品都是免费的，有一些限制。我的任何作品中都没有DRM（** D **原始** R **限制** M **管理）。

！[DRM-free_label.en.svg]（DRM-free_label.en.svg）

此标签由自由软件基金会支持。我从不打算在自己的作品中加入DRM。

我使用的缩写是“数字限制管理”，而不是更广为人知的“数字权限管理”，因为解决它的常见方法是错误的，DRM没有权限。 [Richard M. Stallman（RMS）]（https://en.wikipedia.org/wiki/Richard_Stallman）和[Free Software Foundation（FSF）]支持拼写“数字限制管理”， https://zh.wikipedia.org/wiki/Free_Software_Foundation）

本部分用于提高对DRM问题的认识，并进行抗议。 DRM在设计上是有缺陷的，并且是对所有计算机用户和软件自由的重大威胁。

图片来源：[defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label）

***

##贡献者

目前，我是唯一的贡献者。不允许为他人做贡献，因为这是一个个人项目。

> * 1. [seanpm2001]（https://github.com/seanpm2001/）-x提交（截至##：## a / pm的DoW，Month，DoM，Yr）

> * 2.没有其他贡献者。

***

＃＃ 问题

＃＃＃ 当前的问题

*目前没有

*没有其他当前问题

如果存储库已分叉，则可能已消除了问题。幸运的是，我在此处保存了某些图像的存档（/.github/Issues/）

[在此处阅读有关问题存档的隐私政策]（/。github / Issues / README.md）

** TL; DR **

我将自己的问题存档。除非您要求存档，否则不会存档您的问题。

###过去的问题

*目前没有

*没有其他过去的问题

如果存储库已分叉，则可能已消除了问题。幸运的是，我在此处保存了某些图像的存档（/.github/Issues/）

[在此处阅读有关问题存档的隐私政策]（/。github / Issues / README.md）

** TL; DR **

我将自己的问题存档。除非您要求存档，否则不会存档您的问题。

###过去的拉取请求

*目前没有

*没有其他过去的拉取请求

如果存储库已分叉，则可能已消除了问题。幸运的是，我在此处保存了某些图像的存档（/.github/Issues/）

[在此处阅读有关问题存档的隐私政策]（/。github / Issues / README.md）

** TL; DR **

我将自己的问题存档。除非您要求存档，否则不会存档您的问题。

###活动拉取请求

*目前没有

*没有其他活动的请求请求

如果存储库已分叉，则可能已消除了问题。幸运的是，我在此处保存了某些图像的存档（/.github/Issues/）

[在此处阅读有关问题存档的隐私政策]（/。github / Issues / README.md）

** TL; DR **

我将自己的问题存档。除非您要求存档，否则不会存档您的问题。

***

＃＃ 资源

这是该项目的其他一些资源：

[项目语言文件]（PROJECT_LANG。<fileExtensionForProgrammingLanguage>）

[在GitHub上加入讨论]（https://github.com/seanpm2001/ <repoName> / discussions）

目前没有其他资源。

***

##贡献

不允许为此项目做贡献，因为这是一个个人项目。

[点击/点击此处查看该项目的贡献规则]（CONTRIBUTING.md）

***

##关于自述文件

文件类型：`Markdown（* .md）`

档案版本：`2（2021年5月7日，星期五，晚上10:12）`

行数：`0,352`

***

##自述版本历史

版本1（2021年5月6日，星期四，晚上10:01）

>变更：

> *开始文件

> *添加了标题部分

> *添加了“可能”部分

> *添加了“遥测去除”部分

> *添加了“后门移除”部分

> *版本1中没有其他更改

版本2（2021年5月7日，星期五，晚上10:12）

>变更：

> *添加索引

> *添加了关于部分

> *添加了Wiki部分

> *添加了版本历史记录部分

> *添加了问题部分。

> *添加了“过去的问题”部分

> *添加了过去的拉取请求部分

> *添加了活动拉取请求部分

> *添加了贡献者部分

> *添加了贡献部分

> *添加了关于README部分

> *添加了自述版本历史记录部分

> *添加了资源部分

> *添加了软件状态部分，并带有DRM免费贴纸和消息

> *添加了赞助商信息部分

> *添加了文件信息部分

> *添加了文件历史记录部分

> *版本2中没有其他更改

版本3（即将推出）

>变更：

> *即将推出

> *版本3中没有其他更改

版本4（即将推出）

>变更：

> *即将推出

> *版本4中没有其他更改

***

###您已到达README文件的末尾

[返回页首]（＃Top）[退出]（https://github.com）

### EOF

***
