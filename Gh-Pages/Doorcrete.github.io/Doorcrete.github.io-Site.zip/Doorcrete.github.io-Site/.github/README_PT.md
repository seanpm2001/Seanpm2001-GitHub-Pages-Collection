***

! [DoorCrete.jpeg] (/ DoorCrete.jpeg)

# Doorcrete
O Doorcrete é atualmente apenas um conceito: o Doorcrete quebra as portas dos fundos de vigilância / telemetria e as enche de concreto binário.

***

_Leia este artigo em um idioma diferente: _

** O idioma atual é: ** `Inglês (EUA)` _ (as traduções podem precisar ser corrigidas para corrigir o inglês substituindo o idioma correto) _

_🌐 Lista de idiomas_

** Classificado por: ** `A-Z`

[Opções de classificação indisponíveis] (https://github.com/Doorcrete)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanês | [am አማርኛ] (/. github / README_AM.md) Amárico | [ar عربى] (/.github/README_AR.md) Árabe | [hy հայերեն] (/. github / README_HY.md) Armênio | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaijani | [eu Euskara] (/. github /README_EU.md) Basco | [ser Беларуская] (/. Github / README_BE.md) Bielo-russo | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bósnio | [bg български] (/. Github / README_BG.md) Búlgaro | [ca Català] (/. Github / README_CA.md) Catalão | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chinês (simplificado) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chinês (tradicional) | [co Corsu] (/. Github / README_CO.md) Corso | [hr Hrvatski] (/. Github / README_HR.md) Croata | [cs čeština] (/. Github / README_CS .md) Tcheco | [da dansk] (README_DA.md) Dinamarquês | [nl Nederlands] (/. github / README_ NL.md) Holandês | [** en-us Inglês **] (/. github / README.md) Inglês | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estoniano | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finlandês | [français] (/. github / README_FR.md) Francês | [fy Frysk] (/. github / README_FY.md) Frisian | [gl Galego] (/. github / README_GL.md) Galego | [ka ქართველი] (/. github / README_KA) Georgiano | [de Deutsch] (/. github / README_DE.md) Alemão | [el Ελληνικά] (/. github / README_EL.md) Grego | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Crioulo haitiano | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Havaiano | [he עִברִית] (/. github / README_HE.md) Hebraico | [oi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Húngaro | [é Íslenska] (/. github / README_IS.md) Islandês | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonésia] (/. github / README_ID.md) Islandês | [ga Gaeilge] (/. github / README_GA.md) Irlandês | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japonês | [jw Wong jawa] (/. github / README_JW.md) Javanês | [kn ಕನ್ನಡ] (/. github / README_KN.md) Canará | [kk Қазақ] (/. github / README_KK.md) Cazaque | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Coreano (Sul) | [ko-north 문화어] (README_KO_NORTH.md) Coreano (Norte) (AINDA NÃO TRADUZIDO) | [ku Kurdî] (/. github / README_KU.md) Curdo (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Quirguistão | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latim | [lt Lietuvis] (/. github / README_LT.md) Lituano | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburguês | [mk Македонски] (/. github / README_MK.md) Macedônio | [mg malgaxe] (/. github / README_MG.md) Malgaxe | [ms Bahasa Melayu] (/. github / README_MS.md) Malaio | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltês | [mi Maori] (/. github / README_MI.md) Maori | [sr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongol | [meu မြန်မာ] (/. github / README_MY.md) Mianmar (Birmanês) | [ne नेपाली] (/. github / README_NE.md) Nepalês | [sem norsk] (/. github / README_NO.md) Norueguês | [ou ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persa [pl polski] (/. github / README_PL.md) Polonês | [pt português] (/. github / README_PT.md) Português | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Nenhum idioma disponível que comece com a letra Q | [ro Română] (/. github / README_RO.md) Romeno | [ru русский] (/. github / README_RU.md) Russo | [sm Faasamoa] (/. github / README_SM.md) Samoano | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Gaélico escocês | [sr Српски] (/. github / README_SR.md) Sérvio | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Eslovaco | [sl Slovenščina] (/. github / README_SL.md) Esloveno | [então Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Espanhol | [su Sundanis] (/. github / README_SU.md) Sundanês | [sw Kiswahili] (/. github / README_SW.md) Suaíli | [sv Svenska] (/. github / README_SV.md) Sueco | [tg Тоҷикӣ] (/. github / README_TG.md) Tajique | [ta தமிழ்] (/. github/README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Tailandês | [tr Türk] (/. github / README_TR.md) Turco | [tk Türkmenler] (/. github / README_TK.md) Turquemeno | [uk Український] (/. github / README_UK.md) Ucraniano | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uigur | [uz O'zbek] (/. github / README_UZ.md) Usbeque | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamita | [cy Cymraeg] (/. github / README_CY.md) Galês | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Iídiche | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Disponível em 110 idiomas (108 sem contar o inglês e o norte-coreano, pois o norte-coreano ainda não foi traduzido [Leia sobre isso aqui] (/ OldVersions / Korean (norte) ) /README.md))

As traduções em outros idiomas além do inglês são traduzidas automaticamente e ainda não são precisas. Nenhum erro foi corrigido até 5 de fevereiro de 2021. Relate os erros de tradução [aqui] (https://github.com/seanpm2001/Degoogle-your-life/issues/) certifique-se de fazer backup de sua correção com as fontes e me orientar , como não conheço outros idiomas além do inglês (pretendo eventualmente contratar um tradutor), cite [wiktionary] (https://en.wiktionary.org) e outras fontes em seu relatório. Não fazer isso resultará na rejeição da correção que está sendo publicada.

Observação: devido às limitações da interpretação de markdown do GitHub (e quase todas as outras interpretações de markdown baseadas na web), clicar nesses links o redirecionará para um arquivo separado em uma página separada que não é minha página de perfil do GitHub. Você será redirecionado para o [repositório seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), onde o README está hospedado.

As traduções são feitas com o Google Translate devido ao suporte limitado ou nenhum suporte para os idiomas que preciso em outros serviços de tradução como DeepL e Bing Translate (bastante irônico para um projeto do tipo anti-Google). Estou trabalhando para encontrar uma alternativa. Por algum motivo, a formatação (links, divisórias, negrito, itálico, etc.) está confusa em várias traduções. É tedioso de corrigir e não sei como corrigir esses problemas em idiomas com caracteres não latinos e em idiomas da direita para a esquerda (como o árabe) é necessária ajuda extra para corrigir esses problemas

Devido a problemas de manutenção, muitas traduções estão desatualizadas e usam uma versão desatualizada deste arquivo de artigo `README`. É necessário um tradutor. Além disso, a partir de 9 de abril de 2021, vou demorar um pouco para que todos os novos links funcionem.

***

# Índice

[00,0 - Superior] (# superior)

> [00.1 - Título] (# Doorcrete)

> [00.2 - Leia este artigo em um idioma diferente] (# Leia este artigo em um idioma diferente)

> [00.3 - Índice] (# Índice)

[01.0 - Pode ser possível] (# Pode ser possível)

[02.0 - Remoção de telemetria] (# Remoção de telemetria)

[03.0 - Remoção da porta traseira] (# remoção da porta traseira)

[04.0 - Descrição] (# Doorcrete)

[05.0 - Sobre] (# Sobre)

[06.0 - Wiki] (# Wiki)

[07.0 - Histórico da versão] (# histórico da versão)

[08.0 - Status do software] (# status do software)

[09.0 - Informações do patrocinador] (# informações do patrocinador)

[10.0 - Contribuintes] (# Contribuintes)

[11.0 - Problemas] (# Problemas)

> [11.1 - Questões atuais] (# Questões atuais)

> [11.2 - Problemas anteriores] (# Problemas anteriores)

> [11.3 - Solicitações de pull anteriores] (# Solicitações de pull anteriores)

> [11.4 - Solicitações pull ativas] (# solicitações pull ativas)

[12.0 - Recursos] (# Recursos)

[13.0 - Contribuindo] (# Contribuindo)

[14.0 - Sobre README] (# About-README)

[15.0 - Histórico da versão README] (# README-version-history)

[16.0 - Rodapé] (# Você atingiu o final do arquivo LEIA-ME)

> [16.1 - Fim do arquivo] (# EOF)

***

## Pode ser possível

As backdoors não funcionam exatamente assim, mas podem ser preenchidas / removidas.

O Doorcrete remove backdoors em software de código-fonte misto (quando o código-fonte aberto contém elementos proprietários) e também software de código aberto geral. É muito mais difícil fazer com software proprietário.

## Remoção de telemetria

O doorcrete pode remover a telemetria em:

* Audacity (espera-se que um futuro lançamento pós 3.0.2 contenha a telemetria do Google e um boicote ao produto está começando a crescer - 6 de maio de 2021)

* Ubuntu 12.04 LTS / 12.10 e superior

* GNOME (não pode conter telemetria)

* Firefox (contém telemetria opcional)

* e mais

## Remoção de backdoor

As backdoors serão "preenchidas com concreto binário" (as seções de telemetria serão removidas e substituídas igualmente por dados binários do mesmo tamanho com funções semelhantes, de modo que não seja detectado que foi modificado de uma forma que o amante da backdoor criou a backdoor.

## É mais fácil falar do que fazer

Novamente, este é apenas um conceito. Pode não ser possível remover totalmente a telemetria e backdoors do software e, se for, certamente não será fácil. Por enquanto, você pode tentar tirar esse software da sua vida e obter mais privacidade.

***

***

## Cerca de

Veja acima e abaixo.

***

## Wiki

[Clique / toque aqui para ver este projeto Wiki] (https://github.com/seanpm2001/Doorcrete/wiki)

Se o projeto tiverfoi bifurcado, o Wiki provavelmente foi removido. Felizmente, incluí uma versão incorporada. Você pode visualizá-lo [aqui] (/ External / ProjectWiki /).

***

## Informações do patrocinador

! [SponsorButton.png] (SponsorButton.png)

Você pode patrocinar este projeto se quiser, mas especifique para quem deseja doar. [Veja os fundos para os quais você pode doar] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Você pode ver outras informações do patrocinador [aqui] (https://github.com/seanpm2001/Sponsor-info/)

Experimente! O botão do patrocinador fica ao lado do botão assistir / desbloquear.

***

## Histórico da versão

** Histórico de versão atualmente indisponível **

** Nenhuma outra versão listada **

***

## Status do software

Todos os meus trabalhos estão livres de algumas restrições. DRM (** D ** igital ** R ** estrições ** M ** anagement) não está presente em nenhum dos meus trabalhos.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Este adesivo é apoiado pela Free Software Foundation. Nunca pretendo incluir DRM em meus trabalhos.

Estou usando a abreviatura "Digital Restrictions Management" em vez da mais conhecida "Digital Rights Management", pois a forma comum de lidar com isso é falsa, não há direitos com DRM. A grafia "Digital Restrictions Management" é mais precisa e é apoiada por [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) e pela [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Esta seção é usada para aumentar a conscientização sobre os problemas com o DRM e também para protestar contra ele. O DRM apresenta defeitos de design e é uma grande ameaça a todos os usuários de computador e à liberdade do software.

Crédito da imagem: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Contribuidores

Atualmente, sou o único contribuidor. Contribuir não é permitido para terceiros, pois este é um projeto pessoal.

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - x confirmações (em DoW, Mês, DoM, Ano em ##: ## a / pm)

> * 2. Nenhum outro contribuidor.

***

## Questões

### Problemas atuais

* Nenhum no momento

* Nenhum outro problema atual

Se o repositório foi bifurcado, provavelmente os problemas foram removidos. Felizmente, mantenho um arquivo de certas imagens [aqui] (/. Github / Issues /)

[Leia a política de privacidade sobre o arquivamento de problemas aqui] (/. Github / Issues / README.md)

** TL; DR **

Eu arquivo meus próprios problemas. Seu problema não será arquivado a menos que você solicite o arquivamento.

### Problemas anteriores

* Nenhum no momento

* Nenhum outro problema anterior

Se o repositório foi bifurcado, provavelmente os problemas foram removidos. Felizmente, mantenho um arquivo de certas imagens [aqui] (/. Github / Issues /)

[Leia a política de privacidade sobre o arquivamento de problemas aqui] (/. Github / Issues / README.md)

** TL; DR **

Eu arquivo meus próprios problemas. Seu problema não será arquivado a menos que você solicite o arquivamento.

### Solicitações pull anteriores

* Nenhum no momento

* Nenhuma outra solicitação anterior de pull

Se o repositório foi bifurcado, provavelmente os problemas foram removidos. Felizmente, mantenho um arquivo de certas imagens [aqui] (/. Github / Issues /)

[Leia a política de privacidade sobre o arquivamento de problemas aqui] (/. Github / Issues / README.md)

** TL; DR **

Eu arquivo meus próprios problemas. Seu problema não será arquivado a menos que você solicite o arquivamento.

### Solicitações pull ativas

* Nenhum no momento

* Nenhuma outra solicitação pull ativa

Se o repositório foi bifurcado, provavelmente os problemas foram removidos. Felizmente, mantenho um arquivo de certas imagens [aqui] (/. Github / Issues /)

[Leia a política de privacidade sobre o arquivamento de problemas aqui] (/. Github / Issues / README.md)

** TL; DR **

Eu arquivo meus próprios problemas. Seu problema não será arquivado a menos que você solicite o arquivamento.

***

## Recursos

Aqui estão alguns outros recursos para este projeto:

[Arquivo de idioma do projeto] (PROJECT_LANG. <fileExtensionForProgrammingLanguage>)

[Participe da discussão no GitHub] (https://github.com/seanpm2001/ <repoName> / discussões)

Nenhum outro recurso no momento.

***

## Contribuindo

Contribuir não é permitido para este projeto, pois este é um projeto pessoal.

[Clique / toque aqui para ver as regras de contribuição para este projeto] (CONTRIBUTING.md)

***

## Sobre README

Tipo de arquivo: `Markdown (* .md)`

Versão do arquivo: `2 (sexta-feira, 7 de maio de 2021 às 10:12 pm)`

Contagem de linha: `0,352`

***

## README histórico da versão

Versão 1 (quinta-feira, 6 de maio de 2021 às 22:01)

> Mudanças:

> * Iniciou o arquivo

> * Adicionada a seção de título

> * Adicionada a seção `pode ser possível`

> * Adicionada a seção `remoção de telemetria`

> * Adicionada a seção `remoção de backdoor`

> * Nenhuma outra mudança na versão 1

Versão 2 (sexta-feira, 7 de maio de 2021 às 22h12)

> Mudanças:

> * Adicionado o índice

> * Adicionada a seção sobre

> * Adicionada a seção Wiki

> * Adicionada a seção de histórico de versão

> * Adicionada a seção de problemas.

> * Adicionada a seção de problemas anteriores

> * Adicionada a seção de solicitações de pull anteriores

> * Adicionada a seção de solicitações de pull ativas

> * Adicionada seção de contribuidores

> * Adicionada seção de contribuição

> * Adicionada a seção sobre README

> * Adicionada a seção README do histórico da versão

> * Adicionada a seção de recursos

> * Adicionada uma seção de status do software, com umAdesivo e mensagem sem DRM

> * Adicionada a seção de informações do patrocinador

> * Adicionada a seção de informações do arquivo

> * Adicionada a seção de histórico de arquivos

> * Nenhuma outra mudança na versão 2

Versão 3 (em breve)

> Mudanças:

> * Em breve

> * Nenhuma outra mudança na versão 3

Versão 4 (em breve)

> Mudanças:

> * Em breve

> * Nenhuma outra mudança na versão 4

***

### Você alcançou o final do arquivo README

[Voltar ao início] (# Início) [Sair] (https://github.com)

### EOF

***
