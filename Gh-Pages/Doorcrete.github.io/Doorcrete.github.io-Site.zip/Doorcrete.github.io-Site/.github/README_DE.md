***.

! [DoorCrete.jpeg] (/ DoorCrete.jpeg)

# Türbeton
Türbeton ist derzeit nur ein Konzept: Türbeton zerlegt Überwachungs- / Telemetrie-Hintertüren und füllt sie mit Binärbeton.

***.

_Lesen Sie diesen Artikel in einer anderen Sprache: _

** Aktuelle Sprache ist: ** `Englisch (USA)` _ (Übersetzungen müssen möglicherweise korrigiert werden, um zu korrigieren, dass Englisch die richtige Sprache ersetzt) ​​_

_🌐 Liste der Sprachen_

** Sortiert nach: ** `A-Z`

[Sortieroptionen nicht verfügbar] (https://github.com/Doorcrete)

([af Afrikaans] (/. github / README_AF.md) Afrikaans | [sq Shqiptare] (/. github / README_SQ.md) Albanisch | [am አማርኛ] (/. github / README_AM.md) Amharisch | [ar عربى] (/.github/README_AR.md) Arabisch | [hy հայերեն] (/. github / README_HY.md) Armenisch | [az Azərbaycan dili] (/. github / README_AZ.md) Aserbaidschanisch | [eu Euskara] (/. github /README_EU.md) Baskisch | [be Беларуская] (/. Github / README_BE.md) Weißrussisch | [bn বাংলা] (/. Github / README_BN.md) Bengali | [bs Bosanski] (/. Github / README_BS.md) Bosnisch | [bg български] (/. Github / README_BG.md) Bulgarisch | [ca Català] (/. Github / README_CA.md) Katalanisch | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chinesisch (vereinfacht) | [zh-t 中國 傳統）] (/. github / README_ZH -T.md) Chinesisch (traditionell) | [co Corsu] (/. Github / README_CO.md) Korsisch | [hr Hrvatski] (/. Github / README_HR.md) Kroatisch | [cs čeština] (/. Github / README_CS .md) Tschechisch | [da dansk] (README_DA.md) Dänisch | [nl Niederlande] (/. github / README_ NL.md) Niederländisch | [** en-us English **] (/. github / README.md) English | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) Estnisch | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) Finnisch | [fr français] (/. github / README_FR.md) Französisch | [fy Frysk] (/. github / README_FY.md) Friesisch | [gl Galego] (/. github / README_GL.md) Galizisch | [ka ქართველი] (/. github / README_KA) Georgisch | [de Deutsch] (/. github / README_DE.md) Deutsch | [el Ελληνικά] (/. github / README_EL.md) Griechisch | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Haitianisches Kreol | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiian | [he עִברִית] (/. github / README_HE.md) Hebräisch | [hi हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Ungarisch | [is Íslenska] (/. github / README_IS.md) Isländisch | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) Isländisch | [ga Gaeilge] (/. github / README_GA.md) Irisch | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japanisch | [jw Wong jawa] (/. github / README_JW.md) Javanisch | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kasachisch | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Koreanisch (Süd) | [ko-north 문화어] (README_KO_NORTH.md) Koreanisch (Nord) (NOCH NICHT ÜBERSETZT) | [ku Kurdî] (/. github / README_KU.md) Kurdisch (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirgisisch | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latein | [lt Lietuvis] (/. github / README_LT.md) Litauisch | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgisch | [mk Македонски] (/. github / README_MK.md) Mazedonisch | [mg Madagassisch] (/. github / README_MG.md) Madagassisch | [ms Bahasa Melayu] (/. github / README_MS.md) Malaiisch | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltesisch | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongolisch | [mein မြန်မာ] (/. github / README_MY.md) Myanmar (Burmesisch) | [ne नेपाली] (/. github / README_NE.md) Nepali | [no norsk] (/. github / README_NO.md) Norwegisch | [oder ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persisch [pl polski] (/. github / README_PL.md) Polnisch | [pt português] (/. github / README_PT.md) Portugiesisch | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | Keine Sprachen verfügbar, die mit dem Buchstaben Q | beginnen [ro Română] (/. github / README_RO.md) Rumänisch | [ru русский] (/. github / README_RU.md) Russisch | [sm Faasamoa] (/. github / README_SM.md) Samoan | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Schottisch-Gälisch | [sr Српски] (/. github / README_SR.md) Serbisch | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Singhalesisch | [sk Slovák] (/. github / README_SK.md) Slowakisch | [sl Slovenščina] (/. github / README_SL.md) Slowenisch | [so Soomaali] (/. github / README_SO.md) Somali | [[es en español] (/. github / README_ES.md) Spanisch | [su Sundanis] (/. github / README_SU.md) Sundanesisch | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Schwedisch | [tg Тоҷикӣ] (/. github / README_TG.md) Tadschikisch | [ta தமிழ்] (/. Github/README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Thai | [tr Türk] (/. github / README_TR.md) Türkisch | [tk Türkmenler] (/. github / README_TK.md) Turkmen | [uk Український] (/. github / README_UK.md) Ukrainisch | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uigurisch | [uz O'zbek] (/. github / README_UZ.md) Usbekisch | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamesisch | [cy Cymraeg] (/. github / README_CY.md) Walisisch | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Jiddisch | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Verfügbar in 110 Sprachen (108 ohne Englisch und Nordkoreanisch, da Nordkoreanisch noch nicht übersetzt wurde [Lesen Sie hier darüber] (/ OldVersions / Koreanisch (Nord) ) /README.md))

Übersetzungen in andere Sprachen als Englisch sind maschinell übersetzt und noch nicht korrekt. Bis zum 5. Februar 2021 wurden noch keine Fehler behoben. Bitte melden Sie Übersetzungsfehler [hier] (https://github.com/seanpm2001/Degoogle-your-life/issues/). Sichern Sie Ihre Korrektur mit Quellen und leiten Sie mich Da ich keine anderen Sprachen als Englisch gut kenne (ich plane, irgendwann einen Übersetzer zu bekommen), zitieren Sie bitte [wiktionary] (https://en.wiktionary.org) und andere Quellen in Ihrem Bericht. Andernfalls wird die veröffentlichte Korrektur der Korrektur abgelehnt.

Hinweis: Aufgrund von Einschränkungen bei der Interpretation von Markdown durch GitHub (und so ziemlich jeder anderen webbasierten Interpretation von Markdown) werden Sie durch Klicken auf diese Links zu einer separaten Datei auf einer separaten Seite weitergeleitet, die nicht meine GitHub-Profilseite ist. Sie werden zum [seanpm2001 / seanpm2001-Repository] (https://github.com/seanpm2001/seanpm2001) weitergeleitet, in dem die README gehostet wird.

Übersetzungen werden mit Google Translate durchgeführt, da die Sprachen, die ich in anderen Übersetzungsdiensten wie DeepL und Bing Translate benötige (ziemlich ironisch für ein Anti-Google-Projekt), nur eingeschränkt oder gar nicht unterstützt werden. Ich arbeite daran, eine Alternative zu finden. Aus irgendeinem Grund ist die Formatierung (Links, Teiler, Fettdruck, Kursivschrift usw.) in verschiedenen Übersetzungen durcheinander. Die Behebung ist mühsam, und ich weiß nicht, wie diese Probleme in Sprachen mit nicht-lateinischen Zeichen behoben werden können. Bei der Behebung dieser Probleme ist zusätzliche Hilfe von rechts nach links (wie Arabisch) erforderlich

Aufgrund von Wartungsproblemen sind viele Übersetzungen veraltet und verwenden eine veraltete Version dieser README-Artikeldatei. Ein Übersetzer wird benötigt. Ab dem 9. April 2021 werde ich außerdem eine Weile brauchen, um alle neuen Links zum Laufen zu bringen.

***.

# Index

[00.0 - Oben] (# Oben)

> [00.1 - Titel] (# Türbeton)

> [00.2 - Diesen Artikel in einer anderen Sprache lesen] (# Diesen Artikel in einer anderen Sprache lesen)

> [00.3 - Index] (# Index)

[01.0 - Es kann möglich sein] (# Es kann möglich sein)

[02.0 - Telemetrieentfernung] (# Telemetrieentfernung)

[03.0 - Backdoor-Entfernung] (# Backdoor-Entfernung)

[04.0 - Beschreibung] (# Türbeton)

[05.0 - Info] (# Info)

[06.0 - Wiki] (# Wiki)

[07.0 - Versionsverlauf] (# Versionsverlauf)

[08.0 - Softwarestatus] (# Softwarestatus)

[09.0 - Sponsorinfo] (# Sponsorinfo)

[10.0 - Mitwirkende] (# Mitwirkende)

[11.0 - Probleme] (# Probleme)

> [11.1 - Aktuelle Probleme] (# Aktuelle Probleme)

> [11.2 - Frühere Ausgaben] (# Frühere Ausgaben)

> [11.3 - Frühere Pull-Anfragen] (# Frühere Pull-Anfragen)

> [11.4 - Aktive Pull-Anfragen] (# Active-Pull-Anfragen)

[12.0 - Ressourcen] (# Ressourcen)

[13.0 - Mitwirken] (# Mitwirken)

[14.0 - Über README] (# About-README)

[15.0 - README-Versionsverlauf] (# README-Versionsverlauf)

[16.0 - Fußzeile] (# Sie haben das Ende der README-Datei erreicht)

> [16.1 - Dateiende] (# EOF)

***.

## Es könnte möglich sein

Hintertüren funktionieren nicht genau so, aber sie können gefüllt / entfernt werden.

Doorcrete entfernt Hintertüren von Mixed-Source-Software (wenn Open Source proprietäre Elemente enthält) und allgemeiner Open Source-Software. Mit proprietärer Software ist es viel schwieriger.

## Entfernung der Telemetrie

Türbeton kann Telemetrie entfernen auf:

* Audacity (eine bevorstehende zukünftige Veröffentlichung nach 3.0.2 wird voraussichtlich Google-Telemetrie enthalten, und ein Boykott für das Produkt beginnt zu wachsen - 6. Mai 2021)

* Ubuntu 12.04 LTS / 12.10 und höher

* GNOME (enthält möglicherweise keine Telemetrie)

* Firefox (enthält optionale Telemetrie)

* und mehr

## Hintertür entfernen

Hintertüren werden "mit Binärbeton gefüllt" (Telemetrieabschnitte werden entfernt und gleichermaßen durch Binärdaten gleicher Größe mit ähnlichen Funktionen ersetzt, sodass nicht erkannt wird, dass sie so geändert wurden, wie der Backdoor-Liebhaber die Hintertür erstellt hat.

## Es ist leichter gesagt als getan

Auch dies ist nur ein Konzept. Es ist möglicherweise nicht möglich, Telemetrie und Hintertüren vollständig aus der Software zu entfernen, und wenn dies der Fall ist, ist dies sicher nicht einfach. Im Moment können Sie versuchen, diese Software aus Ihrem Leben zu nehmen und eine bessere Privatsphäre zu erhalten.

***.

***.

## Über

Siehe oben und unten.

***.

## Wiki

[Klicken / tippen Sie hier, um das Projekt-Wiki anzuzeigen] (https://github.com/seanpm2001/Doorcrete/wiki)

Wenn das Projekt hatwurde gegabelt, das Wiki wurde wahrscheinlich entfernt. Zum Glück habe ich eine eingebettete Version. Sie können es [hier] anzeigen (/ External / ProjectWiki /).

***.

## Sponsoreninfo

! [SponsorButton.png] (SponsorButton.png)

Sie können dieses Projekt sponsern, wenn Sie möchten, aber bitte geben Sie an, wofür Sie spenden möchten. [Siehe die Mittel, für die Sie hier spenden können] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Sie können andere Sponsoreninformationen [hier] anzeigen (https://github.com/seanpm2001/Sponsor-info/).

Versuch es! Der Sponsor-Button befindet sich direkt neben dem Watch / Unwatch-Button.

***.

## Versionsgeschichte

** Versionsverlauf derzeit nicht verfügbar **

** Keine anderen Versionen aufgelistet **

***.

## Softwarestatus

Alle meine Arbeiten sind frei von einigen Einschränkungen. DRM (** D ** igital ** R ** Einschränkungen ** M ** Management) ist in keinem meiner Werke vorhanden.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Dieser Aufkleber wird von der Free Software Foundation unterstützt. Ich habe nie vor, DRM in meine Arbeiten aufzunehmen.

Ich verwende die Abkürzung "Digital Restrictions Management" anstelle des bekannteren "Digital Rights Management", da die übliche Vorgehensweise falsch ist. Es gibt keine Rechte bei DRM. Die Schreibweise "Digital Restrictions Management" ist genauer und wird von [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) und der [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Dieser Abschnitt dient dazu, das Bewusstsein für die Probleme mit DRM zu schärfen und dagegen zu protestieren. DRM ist von Natur aus fehlerhaft und stellt eine große Bedrohung für alle Computerbenutzer und die Softwarefreiheit dar.

Bildnachweis: [defectivebydesign.org/drm-free/... lightboxes(https://www.defectivebydesign.org/drm-free/how-to-use-label]

***.

## Mitwirkende

Derzeit bin ich der einzige Mitwirkende. Beiträge sind für andere nicht erlaubt, da dies ein persönliches Projekt ist.

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - x Commits (Stand DoW, Monat, DoM, Jahr um ##: ## a / pm)

> * 2. Keine anderen Mitwirkenden.

***.

## Probleme

### Aktuelle Probleme

* Im Moment keine

* Keine weiteren aktuellen Probleme

Wenn das Repository gegabelt wurde, wurden wahrscheinlich Probleme entfernt. Zum Glück habe ich ein Archiv bestimmter Bilder [hier] (/. Github / Issues /)

[Lesen Sie hier die Datenschutzbestimmungen zur Problemarchivierung] (/. Github / Issues / README.md)

** TL; DR **

Ich archiviere meine eigenen Ausgaben. Ihr Problem wird erst archiviert, wenn Sie die Archivierung anfordern.

### Frühere Ausgaben

* Im Moment keine

* Keine anderen früheren Ausgaben

Wenn das Repository gegabelt wurde, wurden wahrscheinlich Probleme entfernt. Zum Glück habe ich ein Archiv bestimmter Bilder [hier] (/. Github / Issues /)

[Lesen Sie hier die Datenschutzbestimmungen zur Problemarchivierung] (/. Github / Issues / README.md)

** TL; DR **

Ich archiviere meine eigenen Ausgaben. Ihr Problem wird erst archiviert, wenn Sie die Archivierung anfordern.

### Frühere Pull-Anfragen

* Im Moment keine

* Keine anderen früheren Pull-Anfragen

Wenn das Repository gegabelt wurde, wurden wahrscheinlich Probleme entfernt. Zum Glück habe ich ein Archiv bestimmter Bilder [hier] (/. Github / Issues /)

[Lesen Sie hier die Datenschutzbestimmungen zur Problemarchivierung] (/. Github / Issues / README.md)

** TL; DR **

Ich archiviere meine eigenen Ausgaben. Ihr Problem wird erst archiviert, wenn Sie die Archivierung anfordern.

### Aktive Pull-Anfragen

* Im Moment keine

* Keine anderen aktiven Pull-Anfragen

Wenn das Repository gegabelt wurde, wurden wahrscheinlich Probleme entfernt. Zum Glück habe ich ein Archiv bestimmter Bilder [hier] (/. Github / Issues /)

[Lesen Sie hier die Datenschutzbestimmungen zur Problemarchivierung] (/. Github / Issues / README.md)

** TL; DR **

Ich archiviere meine eigenen Ausgaben. Ihr Problem wird erst archiviert, wenn Sie die Archivierung anfordern.

***.

## Ressourcen

Hier sind einige andere Ressourcen für dieses Projekt:

[Projektsprachendatei] (PROJECT_LANG. <FileExtensionForProgrammingLanguage>)

[An der Diskussion auf GitHub teilnehmen] (https://github.com/seanpm2001/ <repoName> / Diskussionen)

Derzeit keine weiteren Ressourcen.

***.

## Mitwirken

Beiträge sind für dieses Projekt nicht zulässig, da es sich um ein persönliches Projekt handelt.

[Klicken / tippen Sie hier, um die Regeln für dieses Projekt anzuzeigen] (CONTRIBUTING.md)

***.

## Über README

Dateityp: `Markdown (* .md)`

Dateiversion: `2 (Freitag, 7. Mai 2021 um 22:12 Uhr)`

Zeilenanzahl: `0,352`

***.

## README Versionsverlauf

Version 1 (Donnerstag, 6. Mai 2021 um 22:01 Uhr)

> Änderungen:

> * Die Datei wurde gestartet

> * Der Titelabschnitt wurde hinzugefügt

> * Der Abschnitt "Möglicherweise ist es möglich" wurde hinzugefügt

> * Der Abschnitt "Telemetrieentfernung" wurde hinzugefügt

> * Der Abschnitt "Entfernen der Hintertür" wurde hinzugefügt

> * Keine weiteren Änderungen in Version 1

Version 2 (Freitag, 7. Mai 2021 um 22:12 Uhr)

> Änderungen:

> * Index hinzugefügt

> * Der About-Abschnitt wurde hinzugefügt

> * Der Wiki-Bereich wurde hinzugefügt

> * Der Abschnitt zum Versionsverlauf wurde hinzugefügt

> * Der Abschnitt "Probleme" wurde hinzugefügt.

> * Der Abschnitt mit früheren Ausgaben wurde hinzugefügt

> * Der Abschnitt mit den letzten Pull-Anforderungen wurde hinzugefügt

> * Der Abschnitt "Aktive Pull-Anforderungen" wurde hinzugefügt

> * Der Bereich für Mitwirkende wurde hinzugefügt

> * Der beitragende Abschnitt wurde hinzugefügt

> * Der Abschnitt über README wurde hinzugefügt

> * Der Abschnitt README-Versionsverlauf wurde hinzugefügt

> * Der Ressourcenbereich wurde hinzugefügt

> * Ein Softwarestatusabschnitt mit a wurde hinzugefügtDRM-freier Aufkleber und Nachricht

> * Der Sponsor-Info-Bereich wurde hinzugefügt

> * Der Abschnitt mit den Dateiinformationen wurde hinzugefügt

> * Der Dateiverlaufsabschnitt wurde hinzugefügt

> * Keine weiteren Änderungen in Version 2

Version 3 (in Kürze erhältlich)

> Änderungen:

> * Bald erhältlich

> * Keine weiteren Änderungen in Version 3

Version 4 (in Kürze erhältlich)

> Änderungen:

> * Bald erhältlich

> * Keine weiteren Änderungen in Version 4

***.

### Sie haben das Ende der README-Datei erreicht

[Zurück nach oben] (# Oben) [Beenden] (https://github.com)

### EOF

***.
