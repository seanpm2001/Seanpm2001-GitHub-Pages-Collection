***

! [DoorCrete.jpeg] (/ DoorCrete.jpeg)

# Doorcrete
Doorcrete es actualmente solo un concepto: Doorcrete rompe las puertas traseras de vigilancia / telemetría y las llena con concreto binario.

***

_ Lee este artículo en otro idioma: _

** El idioma actual es: ** `Inglés (EE. UU.)` _ (Es posible que sea necesario corregir las traducciones para corregir el inglés y reemplazar el idioma correcto) _

_🌐 Lista de idiomas_

** Ordenado por: ** `A-Z`

[Opciones de clasificación no disponibles] (https://github.com/Doorcrete)

([af Afrikaans] (/. github / README_AF.md) Afrikáans | [sq Shqiptare] (/. github / README_SQ.md) Albanés | [am አማርኛ] (/. github / README_AM.md) Amárico | [ar عربى] (/.github/README_AR.md) Árabe | [hy հայերեն] (/. github / README_HY.md) Armenio | [az Azərbaycan dili] (/. github / README_AZ.md) Azerbaiyano | [eu Euskara] (/. github /README_EU.md) Vasco | [be Беларуская] (/. Github / README_BE.md) Bielorruso | [bn বাংলা] (/. Github / README_BN.md) Bengalí | [bs Bosanski] (/. Github / README_BS.md) Bosnio | [bg български] (/. Github / README_BG.md) Búlgaro | [ca Català] (/. Github / README_CA.md) Catalán | [ceb Sugbuanon] (/. Github / README_CEB.md) Cebuano | [ny Chichewa ] (/. github / README_NY.md) Chichewa | [zh-CN 简体 中文] (/. github / README_ZH-CN.md) Chino (simplificado) | [zh-t 中國 傳統 的）] (/. github / README_ZH -T.md) Chino (tradicional) | [co Corsu] (/. Github / README_CO.md) Corso | [hr Hrvatski] (/. Github / README_HR.md) Croata | [cs čeština] (/. Github / README_CS .md) checo | [dansk] (README_DA.md) danés | [nl Nederlands] (/. github / README_ NL.md) holandés | [** en-us inglés **] (/. github / README.md) Inglés | [EO Esperanto] (/. Github / README_EO.md) Esperanto | [et Eestlane] (/. github / README_ET.md) estonio | [tl Pilipino] (/. github / README_TL.md) Filipino | [fi Suomalainen] (/. github / README_FI.md) finlandés | [fr français] (/. github / README_FR.md) francés | [fy Frysk] (/. github / README_FY.md) Frisón | [gl Galego] (/. github / README_GL.md) Gallego | [ka ქართველი] (/. github / README_KA) georgiano | [de Deutsch] (/. github / README_DE.md) Alemán | [el Ελληνικά] (/. github / README_EL.md) Griego | [gu ગુજરાતી] (/. github / README_GU.md) Gujarati | [ht Kreyòl ayisyen] (/. github / README_HT.md) Criollo haitiano | [ha Hausa] (/. github / README_HA.md) Hausa | [haw Ōlelo Hawaiʻi] (/. github / README_HAW.md) Hawaiano | [he עִברִית] (/. github / README_HE.md) Hebreo | [hola हिन्दी] (/. github / README_HI.md) Hindi | [hmn Hmong] (/. github / README_HMN.md) Hmong | [hu Magyar] (/. github / README_HU.md) Húngaro | [es Íslenska] (/. github / README_IS.md) Islandés | [ig Igbo] (/. github / README_IG.md) Igbo | [id bahasa Indonesia] (/. github / README_ID.md) islandés | [ga Gaeilge] (/. github / README_GA.md) Irlandés | [it Italiana / Italiano] (/. github / README_IT.md) | [ja 日本語] (/. github / README_JA.md) Japonés | [jw Wong jawa] (/. github / README_JW.md) javanés | [kn ಕನ್ನಡ] (/. github / README_KN.md) Kannada | [kk Қазақ] (/. github / README_KK.md) Kazajo | [km ខ្មែរ] (/. github / README_KM.md) Khmer | [rw Kinyarwanda] (/. github / README_RW.md) Kinyarwanda | [ko-south 韓國 語] (/. github / README_KO_SOUTH.md) Coreano (Sur) | [ko-north 문화어] (README_KO_NORTH.md) Coreano (Norte) (NO ESTÁ TRADUCIDO) | [ku Kurdî] (/. github / README_KU.md) Kurdo (Kurmanji) | [ky Кыргызча] (/. github / README_KY.md) Kirguistán | [lo ລາວ] (/. github / README_LO.md) Lao | [la Latine] (/. github / README_LA.md) Latín | [lt Lietuvis] (/. github / README_LT.md) Lituano | [lb Lëtzebuergesch] (/. github / README_LB.md) Luxemburgués | [mk Македонски] (/. github / README_MK.md) macedonio | [mg malgache] (/. github / README_MG.md) malgache | [ms Bahasa Melayu] (/. github / README_MS.md) Malayo | [ml മലയാളം] (/. github / README_ML.md) Malayalam | [mt Malti] (/. github / README_MT.md) Maltés | [mi Maori] (/. github / README_MI.md) Maori | [mr मराठी] (/. github / README_MR.md) Marathi | [mn Монгол] (/. github / README_MN.md) Mongol | [my မြန်မာ] (/. github / README_MY.md) Myanmar (Birmano) | [ne नेपाली] (/. github / README_NE.md) Nepalí | [no norsk] (/. github / README_NO.md) Noruego | [o ଓଡିଆ (ଓଡିଆ)] (/. github / README_OR.md) Odia (Oriya) | [ps پښتو] (/. github / README_PS.md) Pashto | [fa فارسی] (/. github / README_FA.md) | Persa [pl polski] (/. github / README_PL.md) Polaco | [pt português] (/. github / README_PT.md) Portugués | [pa ਪੰਜਾਬੀ] (/. github / README_PA.md) Punjabi | No hay idiomas disponibles que comiencen con la letra Q | [ro Română] (/. github / README_RO.md) Rumano | [ru русский] (/. github / README_RU.md) Ruso | [sm Faasamoa] (/. github / README_SM.md) Samoano | [gd Gàidhlig na h-Alba] (/. github / README_GD.md) Gaélico escocés | [sr Српски] (/. github / README_SR.md) Serbio | [st Sesotho] (/. github / README_ST.md) Sesotho | [sn Shona] (/. github / README_SN.md) Shona | [sd سنڌي] (/. github / README_SD.md) Sindhi | [si සිංහල] (/. github / README_SI.md) Sinhala | [sk Slovák] (/. github / README_SK.md) Eslovaco | [sl Slovenščina] (/. github / README_SL.md) esloveno | [Soomaali] (/. github / README_SO.md) Somalí | [[es en español] (/. github / README_ES.md) Español | [su Sundanis] (/. github / README_SU.md) Sundanés | [sw Kiswahili] (/. github / README_SW.md) Swahili | [sv Svenska] (/. github / README_SV.md) Sueco | [tg Тоҷикӣ] (/. github / README_TG.md) Tajik | [ta தமிழ்] (/. github/README_TA.md) Tamil | [tt Татар] (/. github / README_TT.md) Tatar | [te తెలుగు] (/. github / README_TE.md) Telugu | [th ไทย] (/. github / README_TH.md) Tailandés | [tr Türk] (/. github / README_TR.md) Turco | [tk Türkmenler] (/. github / README_TK.md) Turcomano | [uk Український] (/. github / README_UK.md) Ucraniano | [ur اردو] (/. github / README_UR.md) Urdu | [ug ئۇيغۇر] (/. github / README_UG.md) Uigur | [uz O'zbek] (/. github / README_UZ.md) Uzbeko | [vi Tiếng Việt] (/. github / README_VI.md) Vietnamita | [cy Cymraeg] (/. github / README_CY.md) Galés | [xh isiXhosa] (/. github / README_XH.md) Xhosa | [yi יידיש] (/. github / README_YI.md) Yiddish | [yo Yoruba] (/. github / README_YO.md) Yoruba | [zu Zulu] (/. github / README_ZU.md) Zulu) Disponible en 110 idiomas (108 sin contar el inglés y el norcoreano, ya que el norcoreano aún no se ha traducido [Leer más aquí] (/ OldVersions / Korean (North ) /README.md))

Las traducciones en otros idiomas además del inglés se traducen automáticamente y aún no son precisas. Aún no se han corregido errores hasta el 5 de febrero de 2021. Informe los errores de traducción [aquí] (https://github.com/seanpm2001/Degoogle-your-life/issues/) asegúrese de hacer una copia de seguridad de su corrección con las fuentes y guiarme , como no conozco bien otros idiomas además del inglés (planeo conseguir un traductor eventualmente), cite [wiktionary] (https://en.wiktionary.org) y otras fuentes en su informe. De no hacerlo, se rechazará la publicación de la corrección.

Nota: debido a las limitaciones con la interpretación de rebajas de GitHub (y casi todas las demás interpretaciones de rebajas basadas en web), hacer clic en estos enlaces lo redireccionará a un archivo separado en una página separada que no es mi página de perfil de GitHub. Se le redirigirá al [repositorio seanpm2001 / seanpm2001] (https://github.com/seanpm2001/seanpm2001), donde está alojado el archivo README.

Las traducciones se realizan con Google Translate debido al soporte limitado o nulo para los idiomas que necesito en otros servicios de traducción como DeepL y Bing Translate (bastante irónico para un proyecto de tipo anti-Google). Estoy trabajando para encontrar una alternativa. Por alguna razón, el formato (enlaces, separadores, negrita, cursiva, etc.) está desordenado en varias traducciones. Es tedioso de solucionar, y no sé cómo solucionar estos problemas en idiomas con caracteres no latinos, y en idiomas de derecha a izquierda (como el árabe) se necesita ayuda adicional para solucionar estos problemas.

Debido a problemas de mantenimiento, muchas traducciones están desactualizadas y utilizan una versión desactualizada de este archivo de artículo "README". Se necesita un traductor. Además, a partir del 9 de abril de 2021, me llevará un tiempo conseguir que funcionen todos los enlaces nuevos.

***

# Índice

[00.0 - Arriba] (# arriba)

> [00.1 - Título] (# Doorcrete)

> [00.2 - Leer este artículo en un idioma diferente] (# Leer-este-artículo-en-un-idioma-diferente)

> [00.3 - Índice] (# índice)

[01.0 - Puede ser posible] (# Puede-ser-posible)

[02.0 - Eliminación de telemetría] (# Eliminación de telemetría)

[03.0 - Eliminación de puerta trasera] (# eliminación de puerta trasera)

[04.0 - Descripción] (# Doorcrete)

[05.0 - Acerca de] (# Acerca de)

[06.0 - Wiki] (# Wiki)

[07.0 - Historial de versiones] (# Historial de versiones)

[08.0 - Estado del software] (# estado del software)

[09.0 - Información del patrocinador] (# Información del patrocinador)

[10.0 - Contribuyentes] (# contribuyentes)

[11.0 - Problemas] (# problemas)

> [11.1 - Problemas actuales] (# problemas actuales)

> [11.2 - Problemas pasados] (# números pasados)

> [11.3 - Solicitudes de extracción anteriores] (# solicitudes de extracción anteriores)

> [11.4 - Solicitudes de extracción activas] (# solicitudes de extracción activas)

[12.0 - Recursos] (# recursos)

[13.0 - Contribuyendo] (# Contribuyendo)

[14.0 - Acerca de README] (# Acerca de-README)

[15.0 - Historial de versiones README] (# README-version-history)

[16.0 - Pie de página] (# Has-llegado-al-final-del-archivo-README)

> [16.1 - Fin de archivo] (# EOF)

***

## Puede ser posible

Las puertas traseras no funcionan exactamente así, pero se pueden llenar / eliminar.

Doorcrete elimina las puertas traseras en el software de código mixto (cuando el código abierto contiene elementos patentados) y también en el software de código abierto en general. Es mucho más difícil de hacer con software propietario.

## Eliminación de telemetría

Doorcrete puede eliminar la telemetría en:

* Audacity (se espera que una próxima versión futura, la versión 3.0.2 contenga la telemetría de Google, y el boicot del producto está comenzando a crecer - 6 de mayo de 2021)

* Ubuntu 12.04 LTS / 12.10 y posteriores

* GNOME (puede que no contenga telemetría)

* Firefox (contiene telemetría opcional)

* y más

## Eliminación de puerta trasera

Las puertas traseras se "llenarán con hormigón binario" (las secciones de telemetría se eliminarán y se reemplazarán igualmente con datos binarios del mismo tamaño con funciones similares, de modo que no se detecte que se modifique de una manera que el amante de la puerta trasera creó la puerta trasera.

## Es más fácil decirlo que hacerlo

Nuevamente, esto es solo un concepto. Puede que no sea posible eliminar completamente la telemetría y las puertas traseras del software, y si lo es, seguro que no es fácil. Por ahora, puede intentar quitarse este software de su vida y obtener una mayor privacidad.

***

***

## Acerca de

Vea arriba y abajo.

***

## Wiki

[Haga clic / toque aquí para ver la Wiki de este proyecto] (https://github.com/seanpm2001/Doorcrete/wiki)

Si el proyecto tienebifurcado, la Wiki probablemente fue eliminada. Por suerte, incluyo una versión incrustada. Puede verlo [aquí] (/ External / ProjectWiki /).

***

## Información del patrocinador

! [SponsorButton.png] (SponsorButton.png)

Puede patrocinar este proyecto si lo desea, pero especifique a qué desea donar. [Vea los fondos a los que puede donar aquí] (https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors)

Puede ver otra información del patrocinador [aquí] (https://github.com/seanpm2001/Sponsor-info/)

¡Pruébalo! El botón de patrocinador está justo al lado del botón de ver / dejar de mirar.

***

## Historial de versiones

** El historial de versiones no está disponible actualmente **

** No se enumeran otras versiones **

***

## Estado del software

Todos mis trabajos están libres de algunas restricciones. DRM (** D ** igital ** R ** estrictions ** M ** anagement) no está presente en ninguna de mis obras.

! [DRM-free_label.en.svg] (DRM-free_label.en.svg)

Esta pegatina cuenta con el apoyo de la Free Software Foundation. Nunca pretendo incluir DRM en mis trabajos.

Estoy usando la abreviatura "Administración de restricciones digitales" en lugar de la más conocida "Administración de derechos digitales", ya que la forma común de abordarla es falsa, no hay derechos con DRM. La ortografía "Digital Restrictions Management" es más precisa y es compatible con [Richard M. Stallman (RMS)] (https://en.wikipedia.org/wiki/Richard_Stallman) y la [Free Software Foundation (FSF)] ( https://en.wikipedia.org/wiki/Free_Software_Foundation)

Esta sección se utiliza para crear conciencia sobre los problemas con la DRM y también para protestar. DRM tiene un diseño defectuoso y es una gran amenaza para todos los usuarios de computadoras y la libertad de software.

Crédito de la imagen: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label)

***

## Contribuyentes

Actualmente, soy el único contribuyente. Contribuir no está permitido para otros, ya que este es un proyecto personal.

> * 1. [seanpm2001] (https://github.com/seanpm2001/) - x confirmaciones (a partir de DoW, Month, DoM, Yr en ##: ## a / pm)

> * 2. Ningún otro contribuyente.

***

## Asuntos

### Asuntos actuales

* Ninguno por el momento

* No hay otros problemas actuales

Si el repositorio se ha bifurcado, es probable que se hayan eliminado los problemas. Afortunadamente guardo un archivo de ciertas imágenes [aquí] (/. Github / Issues /)

[Lea la política de privacidad sobre el archivo de problemas aquí] (/. Github / Issues / README.md)

** TL; DR **

Archivo mis propios problemas. Tu problema no se archivará a menos que lo solicites.

### Problemas pasados

* Ninguno por el momento

* No hay otros problemas pasados

Si el repositorio se ha bifurcado, es probable que se hayan eliminado los problemas. Afortunadamente guardo un archivo de ciertas imágenes [aquí] (/. Github / Issues /)

[Lea la política de privacidad sobre el archivo de problemas aquí] (/. Github / Issues / README.md)

** TL; DR **

Archivo mis propios problemas. Tu problema no se archivará a menos que lo solicites.

### Solicitudes de extracción anteriores

* Ninguno por el momento

* No hay otras solicitudes de extracción anteriores

Si el repositorio se ha bifurcado, es probable que se hayan eliminado los problemas. Afortunadamente guardo un archivo de ciertas imágenes [aquí] (/. Github / Issues /)

[Lea la política de privacidad sobre el archivo de problemas aquí] (/. Github / Issues / README.md)

** TL; DR **

Archivo mis propios problemas. Tu problema no se archivará a menos que lo solicites.

### Solicitudes de extracción activas

* Ninguno por el momento

* No hay otras solicitudes de extracción activas

Si el repositorio se ha bifurcado, es probable que se hayan eliminado los problemas. Afortunadamente guardo un archivo de ciertas imágenes [aquí] (/. Github / Issues /)

[Lea la política de privacidad sobre el archivo de problemas aquí] (/. Github / Issues / README.md)

** TL; DR **

Archivo mis propios problemas. Tu problema no se archivará a menos que lo solicites.

***

## Recursos

Aquí hay algunos otros recursos para este proyecto:

[Archivo de idioma del proyecto] (PROJECT_LANG. <fileExtensionForProgrammingLanguage>)

[Únase a la discusión en GitHub] (https://github.com/seanpm2001/ <repoName> / discusiones)

No hay otros recursos por el momento.

***

## Contribuyendo

No se permite contribuir para este proyecto, ya que es un proyecto personal.

[Haga clic / toque aquí para ver las reglas de contribución para este proyecto] (CONTRIBUTING.md)

***

## Acerca de README

Tipo de archivo: `Markdown (* .md)`

Versión del archivo: `2 (viernes 7 de mayo de 2021 a las 10:12 pm)`

Recuento de líneas: `0,352`

***

## Historial de versiones de README

Versión 1 (jueves 6 de mayo de 2021 a las 10:01 pm)

> Cambios:

> * Comenzó el archivo

> * Añadida la sección de título

> * Se agregó la sección `puede ser posible`

> * Se agregó la sección `eliminación de telemetría`

> * Se agregó la sección `eliminación de puerta trasera`

> * No hay otros cambios en la versión 1

Versión 2 (viernes 7 de mayo de 2021 a las 10:12 pm)

> Cambios:

> * Agregado el índice

> * Añadida la sección acerca de

> * Añadida la sección Wiki

> * Añadida la sección de historial de versiones

> * Añadida la sección de problemas.

> * Añadida la sección de problemas pasados

> * Se agregó la sección de solicitudes de extracción anteriores

> * Se agregó la sección de solicitudes de extracción activas

> * Añadida la sección de colaboradores

> * Añadida la sección de contribución

> * Se agregó la sección acerca de README

> * Se agregó la sección de historial de versiones README

> * Añadida la sección de recursos

> * Se agregó una sección de estado del software, con unEtiqueta y mensaje sin DRM

> * Añadida la sección de información del patrocinador

> * Añadida la sección de información del archivo

> * Añadida la sección de historial de archivos

> * No hay otros cambios en la versión 2

Versión 3 (próximamente)

> Cambios:

> * Próximamente

> * No hay otros cambios en la versión 3

Versión 4 (próximamente)

> Cambios:

> * Próximamente

> * No hay otros cambios en la versión 4

***

### Ha llegado al final del archivo README

[Volver arriba] (# arriba) [Salir] (https://github.com)

### EOF

***
