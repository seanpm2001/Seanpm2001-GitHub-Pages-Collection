***

！[DoorCrete.jpeg]（/ DoorCrete.jpeg）

＃ドアクリート
Doorcreteは現在、単なる概念です。Doorcreteは、監視/テレメトリのバックドアを分解し、バイナリコンクリートで埋めます。

***

_この記事を別の言語で読む：_

**現在の言語は次のとおりです：** `英語（米国）` _（正しい言語を置き換える英語を修正するには、翻訳を修正する必要がある場合があります）_

_🌐言語のリスト_

**並べ替え：** `A-Z`

[並べ替えオプションは利用できません]（https://github.com/Doorcrete）

（[af Afrikaans]（/。github / README_AF.md）Afrikaans | [sq Shqiptare]（/。github / README_SQ.md）アルバニア語| [amአርኛ]（/。github / README_AM.md）Amharic | [arعربى] （/.github/README_AR.md）アラビア語| [hyհայերեն]（/。github / README_HY.md）アルメニア語| [azAzərbaycandili]（/。github / README_AZ.md）アゼルバイジャン語| [eu Euskara]（/。github /README_EU.md）バスク語| [beБеларуская]（/。github / README_BE.md）ベラルーシ語| [bnবাংলা]（/。github / README_BN.md）ベンガリ語| [bs Bosanski]（/。github / README_BSボスニア語| [bgбългарски]（/。github / README_BG.md）ブルガリア語| [caCatalà]（/。github / README_CA.md）カタロニア語| [ceb Sugbuanon]（/。github / README_CEB.md）Cebuano | [ny Chichewa ]（/。github / README_NY.md）Chichewa | [zh-CN简体中文]（/。github / README_ZH-CN.md）中国語（簡略化）| [zh-t中國傳統的）]（/。github / README_ZH -T.md）中国語（従来）| [co Corsu]（/。github / README_CO.md）コルシカ語| [hr Hrvatski]（/。github / README_HR.md）クロアチア語| [csčeština]（/。github / README_CS .md）チェコ語| [da dansk]（README_DA.md）デンマーク語| [nl Nederlands]（/。github / README_ NL.md）オランダ語| [** en-us英語**]（/。github / README.md）英語| [EOエスペラント]（/。github / README_EO.md）エスペラント| [et Eestlane]（/。github / README_ET.md）エストニア語| [tl Pilipino]（/。github / README_TL.md）フィリピン人| [fi Suomalainen]（/。github / README_FI.md）フィンランド語| [frfrançais]（/。github / README_FR.md）フランス語| [fy Frysk]（/。github / README_FY.md）フリジア語| [gl Galego]（/。github / README_GL.md）ガリシア語| [kaქართველი]（/。github / README_KA）グルジア語| [de Deutsch]（/。github / README_DE.md）ドイツ語| [elΕλληνικά]（/。github / README_EL.md）ギリシャ語| [guગુજરાતી]（/。github / README_GU.md）グジャラート語| [htKreyòlayisyen]（/。github / README_HT.md）ハイチ語クレオール語| [haハウサ語]（/。github / README_HA.md）ハウサ語| [hawŌleloHawaiʻi]（/。github / README_HAW.md）ハワイ語| [彼はעִברִית]（/。github / README_HE.md）ヘブライ語| [こんにちはहिन्दी]（/。github / README_HI.md）ヒンディー語| [hmn Hmong]（/。github / README_HMN.md）モン族| [hu Magyar]（/。github / README_HU.md）ハンガリー語| [isÍslenska]（/。github / README_IS.md）アイスランド語| [ig Igbo]（/。github / README_IG.md）Igbo | [id bahasa Indonesia]（/。github / README_ID.md）アイスランド語| [ga Gaeilge]（/。github / README_GA.md）アイルランド語| [イタリア語/イタリア語]（/。github / README_IT.md）| [ja日本語]（/。github / README_JA.md）日本語| [jw Wongjawa]（/。github / README_JW.md）ジャワ語| [knಕನ್ನಡ]（/。github / README_KN.md）カンナダ語| [kkҚазақ]（/。github / README_KK.md）カザフ語| [kmខ្មែរ]（/。github / README_KM.md）クメール語| [rw Kinyarwanda]（/。github / README_RW.md）Kinyarwanda | [ko-south韓國語]（/。github / README_KO_SOUTH.md）韓国語（南）| [ko-north문화어]（README_KO_NORTH.md）韓国語（北）（まだ翻訳されていません）| [kuKurdî]（/。github / README_KU.md）クルド語（クルマンジー）| [kyКыргызча]（/。github / README_KY.md）キルギス語| [loລາວ]（/。github / README_LO.md）ラオス| [la Latine]（/。github / README_LA.md）ラテン語| [lt Lietuvis]（/。github / README_LT.md）リトアニア語| [lbLëtzebuergesch]（/。github / README_LB.md）ルクセンブルク語| [mkМакедонски]（/。github / README_MK.md）マケドニア語| [mgマダガスカル]（/。github / README_MG.md）マダガスカル| [ms Bahasa Melayu]（/。github / README_MS.md）マレー語| [mlമലയാളം]（/。github / README_ML.md）マラヤーラム語| [mt Malti]（/。github / README_MT.md）マルタ語| [miマオリ]（/。github / README_MI.md）マオリ| [mrमराठी]（/。github / README_MR.md）マラーティー語| [mnМонгол]（/。github / README_MN.md）モンゴル語| [myမြန်မာ]（/。github / README_MY.md）ミャンマー（ビルマ語）| [neनेपाली]（/。github / README_NE.md）ネパール語| [norskなし]（/。github / README_NO.md）ノルウェー語| [またはଓଡିଆ（ଓଡିଆ）]（/。github / README_OR.md）オディア語（オリヤー語）| [psپښتو]（/。github / README_PS.md）パシュトゥー語| [faفارسی]（/。github / README_FA.md）|ペルシア語[pl polski]（/。github / README_PL.md）ポーランド語| [ptportuguês]（/。github / README_PT.md）ポルトガル語| [paਪੰਜਾਬੀ]（/。github / README_PA.md）パンジャブ語|文字Qで始まる言語はありません| [roRomână]（/。github / README_RO.md）ルーマニア語| [ruрусский]（/。github / README_RU.md）ロシア語| [sm Faasamoa]（/。github / README_SM.md）サモア語| [gdGàidhlignah-Alba]（/。github / README_GD.md）スコットランドゲール語| [srСрпски]（/。github / README_SR.md）セルビア語| [st Sesotho]（/。github / README_ST.md）セソト語| [sn Shona]（/。github / README_SN.md）Shona | [sdسنڌي]（/。github / README_SD.md）シンド語| [siසිංහල]（/。github / README_SI.md）シンハラ語| [skスロバキア語]（/。github / README_SK.md）スロバキア語| [slSlovenščina]（/。github / README_SL.md）スロベニア語| [so Soomaali]（/。github / README_SO.md）ソマリア語| [[esenespañol]（/。github / README_ES.md）スペイン語| [su Sundanis]（/。github / README_SU.md）スンダ語| [sw Kiswahili]（/。github / README_SW.md）スワヒリ語| [sv Svenska]（/。github / README_SV.md）スウェーデン語| [tgТоҷикӣ]（/。github / README_TG.md）タジク語| [taதமிழ்]（/。github/README_TA.md）タミル語| [ttТатар]（/。github / README_TT.md）タタール| [teతెలుగు]（/。github / README_TE.md）テルグ語| [thไทย]（/。github / README_TH.md）タイ語| [trTürk]（/。github / README_TR.md）トルコ語| [tkTürkmenler]（/。github / README_TK.md）トルクメン語| [ukУкраїнський]（/。github / README_UK.md）ウクライナ語| [urاردو]（/。github / README_UR.md）ウルドゥー語| [ugئۇيغۇر]（/。github / README_UG.md）ウイグル| [uz O'zbek]（/。github / README_UZ.md）ウズベク語| [viTiếngViệt]（/。github / README_VI.md）ベトナム語| [cy Cymraeg]（/。github / README_CY.md）ウェールズ語| [xh isiXhosa]（/。github / README_XH.md）コサ語| [yiיידיש]（/。github / README_YI.md）イディッシュ語| [ヨルバ語]（/。github / README_YO.md）ヨルバ語| [zu Zulu]（/。github / README_ZU.md）Zulu）110の言語で利用可能（北朝鮮はまだ翻訳されていないため、英語と北朝鮮を数えない場合は108）[ここでそれについて読む]（/ OldVersions / Korean（North ）/README.md））

英語以外の言語での翻訳は機械翻訳されており、まだ正確ではありません。 2021年2月5日の時点で、エラーはまだ修正されていません。翻訳エラーを報告してください[ここ]（https://github.com/seanpm2001/Degoogle-your-life/issues/）必ずソースを使用して修正をバックアップし、ガイドしてください、英語以外の言語はよくわからないので（最終的には翻訳者を雇う予定です）、レポートで[wiktionary]（https://en.wiktionary.org）やその他の情報源を引用してください。そうしないと、公開されている修正が拒否されます。

注：GitHubのマークダウンの解釈（および他のほとんどすべてのWebベースのマークダウンの解釈）の制限により、これらのリンクをクリックすると、GitHubプロファイルページではない別のページの別のファイルにリダイレクトされます。 READMEがホストされている[seanpm2001 / seanpm2001リポジトリ]（https://github.com/seanpm2001/seanpm2001）にリダイレクトされます。

DeepLやBingTranslate（反Googleタイプのプロジェクトにとってはかなり皮肉なことです）のような他の翻訳サービスで必要な言語のサポートが制限されているか、まったくサポートされていないため、翻訳はGoogle翻訳で行われます。何らかの理由で、フォーマット（リンク、仕切り、太字、斜体など）がさまざまな翻訳で混乱しています。修正するのは面倒で、ラテン文字以外の言語でこれらの問題を修正する方法がわかりません。これらの問題を修正するには、右から左への言語（アラビア語など）で追加のヘルプが必要です。

メンテナンスの問題により、多くの翻訳は古く、この「README」記事ファイルの古いバージョンを使用しています。翻訳者が必要です。また、2021年4月9日の時点で、すべての新しいリンクが機能するようになるまでしばらく時間がかかります。

***

＃インデックス

[00.0-トップ]（＃Top）

> [00.1-タイトル]（＃Doorcrete）

> [00.2-この記事を別の言語で読む]（＃Read-this-article-in-a-different-language）

> [00.3-インデックス]（＃インデックス）

[01.0-可能かもしれない]（＃It-may-be-possible）

[02.0-テレメトリの削除]（＃Telemetry-removal）

[03.0-バックドアの削除]（＃Backdoor-削除）

[04.0-説明]（＃Doorcrete）

[05.0-概要]（＃概要）

[06.0-Wiki]（＃Wiki）

[07.0-バージョン履歴]（＃Version-history）

[08.0-ソフトウェアステータス]（＃Software-status）

[09.0-スポンサー情報]（＃Sponsor-info）

[10.0-寄稿者]（＃寄稿者）

[11.0-問題]（＃問題）

> [11.1-現在の問題]（＃Current-issues）

> [11.2-過去の問題]（＃過去の問題）

> [11.3-過去のプルリクエスト]（＃Past-pull-requests）

> [11.4-アクティブなプルリクエスト]（＃Active-pull-requests）

[12.0-リソース]（＃Resources）

[13.0-寄稿]（＃寄稿）

[14.0-READMEについて]（＃About-README）

[15.0-READMEバージョン履歴]（＃README-バージョン履歴）

[16.0-フッター]（＃You-have-reached-the-end-of-the-README-file）

> [16.1-ファイルの終わり]（＃EOF）

***

##可能かもしれません

バックドアはこのように正確に機能するわけではありませんが、埋めたり削除したりすることはできます。

Doorcreteは、混合ソースソフトウェア（オープンソースにプロプライエタリ要素が含まれている場合）および一般的なオープンソースソフトウェアのバックドアを削除します。プロプライエタリソフトウェアで行うのははるかに困難です。

##テレメトリの削除

Doorcreteは、次の場所でテレメトリを削除できます。

* Audacity（3.0.2以降の今後のリリースにはGoogleテレメトリが含まれる予定であり、製品のボイコットが拡大し始めています-2021年5月6日）

* Ubuntu 12.04 LTS /12.10以降

* GNOME（テレメトリが含まれていない場合があります）

* Firefox（オプションのテレメトリを含む）

* もっと

##バックドアの削除

バックドアは「バイナリコンクリートで埋められ」ます（テレメトリセクションは削除され、同様の機能を持つ同じサイズのバイナリデータに等しく置き換えられるため、バックドア愛好家がバックドアを作成した方法で変更されたことが検出されません。

##言うのは簡単です

繰り返しますが、これは単なる概念です。テレメトリとバックドアをソフトウェアから完全に削除することは不可能な場合があります。削除できる場合は、簡単ではありません。今のところ、あなたはこのソフトウェアをあなたの人生から取り除き、より良いプライバシーを手に入れることを試みることができます。

***

***

＃＃ 約

上と下を参照してください。

***

## Wiki

[このプロジェクトを表示するには、ここをクリック/タップしてくださいWiki]（https://github.com/seanpm2001/Doorcrete/wiki）

プロジェクトにフォークされたため、Wikiは削除された可能性があります。幸いなことに、私は埋め込みバージョンを含めています。あなたはそれを[ここ]（/ External / ProjectWiki /）で見ることができます。

***

##スポンサー情報

！[SponsorButton.png]（SponsorButton.png）

必要に応じてこのプロジェクトを後援することができますが、寄付したいものを指定してください。 [ここに寄付できる資金を参照してください]（https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors）

他のスポンサー情報は[こちら]（https://github.com/seanpm2001/Sponsor-info/）で確認できます。

やってみて！スポンサーボタンは、ウォッチ/アンウォッチボタンのすぐ隣にあります。

***

##バージョン履歴

**バージョン履歴は現在利用できません**

**他のバージョンはリストされていません**

***

##ソフトウェアステータス

私の作品はすべて無料ですが、いくつかの制限があります。 DRM（** D ** igital ** R ** estrictions ** M ** anagement）は私の作品のいずれにも存在しません。

！[DRM-free_label.en.svg]（DRM-free_label.en.svg）

このステッカーは、フリーソフトウェアファウンデーションによってサポートされています。私は自分の作品にDRMを含めるつもりはありません。

よく知られている「デジタル著作権管理」の代わりに「デジタル制限管理」という略語を使用しています。これは、DRMには権利がないという一般的な対処方法です。 「デジタル制限管理」のスペルはより正確であり、[Richard M. Stallman（RMS）]（https://en.wikipedia.org/wiki/Richard_Stallman）および[Free Software Foundation（FSF）]（ https://en.wikipedia.org/wiki/Free_Software_Foundation）

このセクションは、DRMの問題に対する認識を高め、それに抗議するために使用されます。 DRMは設計上欠陥があり、すべてのコンピューターユーザーとソフトウェアの自由に対する大きな脅威です。

画像クレジット：[defectivebydesign.org/drm-free /...]（https://www.defectivebydesign.org/drm-free/how-to-use-label）

***

##寄稿者

現在、私が唯一の貢献者です。これは個人的なプロジェクトであるため、他の人への寄付は許可されていません。

> * 1. [seanpm2001]（https://github.com/seanpm2001/）-xコミット（DoW、Month、DoM、Yrの時点で##：## a / pm）

> * 2。他の貢献者はいません。

***

##問題

###現在の問題

*現時点ではありません

*その他の現在の問題はありません

リポジトリがフォークされている場合は、問題が削除されている可能性があります。幸いなことに、私は特定の画像のアーカイブを保持しています[ここ]（/。github / Issues /）

[問題のアーカイブに関するプライバシーポリシーをここで読んでください]（/。github / Issues / README.md）

** TL; DR **

私は自分の問題をアーカイブします。アーカイブをリクエストしない限り、問題はアーカイブされません。

###過去の問題

*現時点ではありません

*他の過去の問題はありません

リポジトリがフォークされている場合は、問題が削除されている可能性があります。幸いなことに、私は特定の画像のアーカイブを保持しています[ここ]（/。github / Issues /）

[問題のアーカイブに関するプライバシーポリシーをここで読んでください]（/。github / Issues / README.md）

** TL; DR **

私は自分の問題をアーカイブします。アーカイブをリクエストしない限り、問題はアーカイブされません。

###過去のプルリクエスト

*現時点ではありません

*他の過去のプルリクエストはありません

リポジトリがフォークされている場合は、問題が削除されている可能性があります。幸いなことに、私は特定の画像のアーカイブを保持しています[ここ]（/。github / Issues /）

[問題のアーカイブに関するプライバシーポリシーをここで読んでください]（/。github / Issues / README.md）

** TL; DR **

私は自分の問題をアーカイブします。アーカイブをリクエストしない限り、問題はアーカイブされません。

###アクティブなプルリクエスト

*現時点ではありません

*他のアクティブなプルリクエストはありません

リポジトリがフォークされている場合は、問題が削除されている可能性があります。幸いなことに、私は特定の画像のアーカイブを保持しています[ここ]（/。github / Issues /）

[問題のアーカイブに関するプライバシーポリシーをここで読んでください]（/。github / Issues / README.md）

** TL; DR **

私は自分の問題をアーカイブします。アーカイブをリクエストしない限り、問題はアーカイブされません。

***

##リソース

このプロジェクトの他のリソースは次のとおりです。

[プロジェクト言語ファイル]（PROJECT_LANG。<fileExtensionForProgrammingLanguage>）

[GitHubのディスカッションに参加]（https://github.com/seanpm2001/ <repoName> / discussions）

現在、他のリソースはありません。

***

##貢献

これは個人的なプロジェクトであるため、このプロジェクトへの寄付は許可されていません。

[このプロジェクトの貢献ルールを表示するには、ここをクリック/タップしてください]（CONTRIBUTING.md）

***

## READMEについて

ファイルタイプ： `Markdown（* .md）`

ファイルバージョン： `2（2021年5月7日金曜日午後10時12分）`

行数： `0,352`

***

## READMEのバージョン履歴

バージョン1（2021年5月6日木曜日午後10時1分）

>変更：

> *ファイルを開始しました

> *タイトルセクションを追加しました

> *「可能かもしれない」セクションを追加

> *「テレメトリの削除」セクションを追加しました

> *「バックドアの削除」セクションを追加しました

> *バージョン1で他の変更はありません

バージョン2（2021年5月7日金曜日午後10時12分）

>変更：

> *インデックスを追加しました

> * aboutセクションを追加しました

> * Wikiセクションを追加しました

> *バージョン履歴セクションを追加しました

> *問題のセクションを追加しました。

> *過去の問題のセクションを追加しました

> *過去のプルリクエストセクションを追加しました

> *アクティブなプルリクエストセクションを追加しました

> *寄稿者セクションを追加しました

> *寄稿セクションを追加しました

> * READMEについてのセクションを追加しました

> * READMEバージョン履歴セクションを追加しました

> *リソースセクションを追加しました

> *ソフトウェアステータスセクションを追加しました。DRMフリーのステッカーとメッセージ

> *スポンサー情報セクションを追加しました

> *ファイル情報セクションを追加しました

> *ファイル履歴セクションを追加しました

> *バージョン2で他の変更はありません

バージョン3（近日公開）

>変更：

> *近日公開

> *バージョン3で他の変更はありません

バージョン4（近日公開）

>変更：

> *近日公開

> *バージョン4で他の変更はありません

***

### READMEファイルの最後に到達しました

[トップに戻る]（＃Top）[終了]（https://github.com）

### EOF

***
