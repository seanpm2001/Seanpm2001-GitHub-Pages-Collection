
***

# Branches

This project currently has 2 branches

[Site](https://github.com/seanpm2001/Template_GitHubPages_Default_V4/tree/Site/) - For the finalized revision of the site

[Development](https://github.com/seanpm2001/Template_GitHubPages_Default_V4/tree/Development/) - For the development of the site (possibly deprecated)

***
