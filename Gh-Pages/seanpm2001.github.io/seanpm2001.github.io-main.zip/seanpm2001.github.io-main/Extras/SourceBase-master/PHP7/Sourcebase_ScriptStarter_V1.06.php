<?
// PHP section
// "Echo"
echo ("Hello World"); // Output: Hello World
/* Or
* "Print"
*/
print ("Hello World"); // Output: Hello World
?>
