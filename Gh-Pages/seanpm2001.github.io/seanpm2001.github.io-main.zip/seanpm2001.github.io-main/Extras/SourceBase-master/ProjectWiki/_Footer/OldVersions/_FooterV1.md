---

Footer
-----------

_SourceBase web development project Wiki._

`By [seanpm2001](https://github.com/seanpm2001/) on GitHub.`

**`Project originally started on: Friday, August 9th 2019.`**

**`Hosted to GitHub starting: Thursday, May 28th 2020.`**

August 9th 2019-2020

`Licensed under the GNU General Public License 3.0`

---
