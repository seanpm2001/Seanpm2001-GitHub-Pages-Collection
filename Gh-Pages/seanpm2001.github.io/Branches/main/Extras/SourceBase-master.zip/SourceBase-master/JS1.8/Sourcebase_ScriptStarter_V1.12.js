<script type="text/JavaScript" lang="en">
// Start of script
// Start of page JavaScript console
console.log("[Brand] web console for [browser]");
console.log("The [section] console");
console.log(">>>");
// End of page JavaScript console
// End of script
</script>
<script type="text/JavaScript" lang="en" id="CSSRuleCountScript">
// CSS rule count script
inlineStyShe1 = 2; // Rule count for Inline Stylesheet 1
inlineStyShe2 = 3; // Rule count for Inline Stylesheet 2
inlineStyShe3 = 5; // Rule count for Inline Stylesheet 3
inlineStyShe4 = 7; // Rule count for Inline Stylesheet 4
inlineStyShe5 = 6; // Rule count for Inline Stylesheet 5
inlineStyShe6 = 2; // Rule count for Inline Stylesheet 6
inlineStyShe7 = 6; // Rule count for Inline Stylesheet 7
inlineStyShe8 = 2; // Rule count for Inline Stylesheet 8
inlineStyShe9 = 12; // Rule count for Inline Stylesheet 9
inlineStyShe10 = 1; // Rule count for Inline Stylesheet 10
inlineStyShe11 = 4; // Rule count for Inline Stylesheet 11
inlineStyShe12 = 11; // Rule count for Inline Stylesheet 12
inlineStyShe13 = 1; // Rule count for Inline Stylesheet 13
inlineStyShe14 = 4; // Rule count for Inline Stylesheet 14
inlineStyShe15 = 6; // Rule count for Inline Stylesheet 15
inlineStyShe16 = 1; // Rule count for Inline Stylesheet 16
inlineStyShe17 = 1; // Rule count for Inline Stylesheet 17
inlineStyShe18 = 5; // Rule count for Inline Stylesheet 18
inlineCount = (inlineStyShe1 + inlineStyShe2 + inlineStyShe3 + inlineStyShe4 + inlineStyShe5 + inlineStyShe6 + inlineStyShe7 + inlineStyShe8 + inlineStyShe9 + inlineStyShe10 + inlineStyShe11 + inlineStyShe12 + inlineStyShe13 + inlineStyShe14 + inlineStyShe15 + inlineStyShe16 + inlineStyShe17 + inlineStyShe18);
console.log("CSS rule count:\nInline: " + inlineCount + " \nExternal: Coming soon");
console.log("Inline count");
console.log("Inline stylesheet 1: " + inlineStyShe1 + " ");
console.log("Inline stylesheet 2: " + inlineStyShe2 + " ");
console.log("Inline stylesheet 3: " + inlineStyShe3 + " ");
console.log("Inline stylesheet 4: " + inlineStyShe4 + " ");
console.log("Inline stylesheet 5: " + inlineStyShe5 + " ");
console.log("Inline stylesheet 6: " + inlineStyShe6 + " ");
console.log("Inline stylesheet 7: " + inlineStyShe7 + " ");
console.log("Inline stylesheet 8: " + inlineStyShe8 + " ");
console.log("Inline stylesheet 9: " + inlineStyShe9 + " ");
console.log("Inline stylesheet 10: " + inlineStyShe10 + " ");
console.log("Inline stylesheet 11: " + inlineStyShe11 + " ");
console.log("Inline stylesheet 12: " + inlineStyShe12 + " ");
console.log("Inline stylesheet 13: " + inlineStyShe13 + " ");
console.log("Inline stylesheet 14: " + inlineStyShe14 + " ");
console.log("Inline stylesheet 15: " + inlineStyShe15 + " ");
console.log("Inline stylesheet 16: " + inlineStyShe16 + " ");
console.log("Inline stylesheet 17: " + inlineStyShe17 + " ");
console.log("Inline stylesheet 18: " + inlineStyShe18 + " ");
console.log("External count");
console.log("Coming soon");
// End of CSS rule count script
</script>
