// Start of script
// Page JavaScript console
console.log("[Brand] web console for [browser]");
console.log("The [section] console");
console.log(">>>");
// End of script
