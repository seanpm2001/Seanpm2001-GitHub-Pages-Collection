<?php
// PHP section
// "Echo"
echo ("Hello World"); // Output: Hello World
/* Or
* "Print"
*/
print ("Hello World"); // Output: Hello World
// Variable list
$piSimple = "3.14";
$HelloWorldStr = "Hello World";
$HelloworldStr = "Hello world";
$Int2__16 = "65536"; // My #1 memorized power of 2
// End of variable list
// Var list
var x = 0; // X Coordinate
var y = 0; // Y Coordinate
var z = 0; // Z Coordinate
var a = 0; // A Coordinate [4D MODE ONLY]
// End ov Var list
// Int list
int testInt1 = "101";
// End of int list
// float list
float decimal1 = "1.01";
// End of float list
// End of PHP section
?>
