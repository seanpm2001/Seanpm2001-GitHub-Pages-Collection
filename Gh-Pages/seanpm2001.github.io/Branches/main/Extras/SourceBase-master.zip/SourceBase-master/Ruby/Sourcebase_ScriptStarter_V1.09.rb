# Start of script
runtime1 = 1;
while (runtime1 == 1):
	puts "Hello world";
	# Ruby web template (Ruby Sourcebase 1.09)
	puts "Ruby web template";
	puts "Sourcebase 1.09 (Ruby)";
	# Generate a random number and print whether it's even or odd.
	if rand(100).even?
		puts "It's even"
	else
		puts "It's odd"
	end
	'''
	<rt><rb></rb></rt>
	'''
end
# File version: 1 (January 7th 2020)
'''
First version: 1 (January 7th 2020)
'''
# End of script
