
***

### Top

# `README.md`

***

# Index

[00.0 - Top](#Top)

[01.0 - Index](#Index)

[02.0 - Description](#iBlast)

[03.0 - About](#About)

[04.0 - Wiki](#Wiki)

[05.0 - Version history](#Version-history)

[06.0 - Contributers](#Contributers)

[07.0 - About README](#About-README)

[08.0 - Footer](#You-have-reached-the-end-of-the-README-file)

***

# iBlast
A recreation of the award winning mobile games iBlast Moki and iBlast Moki 2, as the apps are no longer updates (they no longer work as of Android 7.0 and iOS 11) I also want to build on the concept, and also provide an open-source, and less buggy version of the games, plus a new version that is fan-made.

***

## About

See above

***

## Wiki

[Click/tap here to view this projects Wiki](https://github.com/seanpm2001/iBlast/wiki)

***

## Version history

[More versions coming soon](https://www.example.com)

***

## Contributers

Currently, I am the only contributer. You are welcome to contribute if you follow the `CONTRIBUTING.md` file.

> * 1. [seanpm2001](https://github.com/seanpm2001/) - 37 commits (As of Tuesday, July 14th 2020 at 5:28 pm)

> * 2. No other contributers allowed

***

## About README

File type: `Markdown (*.md)`

File version: `1 (Tuesday, July 14th 2020 at 5:28 pm)`

Line count: `0,080`

***

### You have reached the end of the README file

[Back to top](#Top) [Exit](https://github.com)

***
